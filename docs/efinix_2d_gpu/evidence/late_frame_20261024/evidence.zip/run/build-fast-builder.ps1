param([int]$Frames=3600,[string]$Suffix='r1',[switch]$Normal)
$ErrorActionPreference='Stop'
Set-Location 'D:/ZYNQ/smallproject/.worktrees/pango-riscv-cpu'
$soc='D:/efinity_builds/competition_day1_20260906/sapphire/soc'
$bsp="$soc/bsp/efinix/EfxSapphireSoc"
$line=Get-Content 'sw/efinix_gpu/Makefile'|Where-Object {$_ -match '^SOURCES = '}
$sources=@(($line -replace '^SOURCES = ','') -split '\s+'|ForEach-Object {"sw/efinix_gpu/$_"})
foreach($enabled in 0,1) {
 $out="generated/verification/v3/late-frame-20261024/$(if($Normal){'normal'}else{'probe'})-$(if($enabled){'fast'}else{'old'})-$Suffix"
 if(Test-Path -LiteralPath $out){throw 'Fresh output required'}
 New-Item -ItemType Directory -Path $out|Out-Null
 $flags=@('-DBULLET_DEMO_DEFAULT=1','-DV3_INTERACTIVE=1','-DBULLET_OBJECT_CAPACITY=1024',"-DV3_FAST_GPU_BUILD=$enabled",'-DV3_COPY_AHEAD=1','-DV3_LOGIC_COPY=1','-DREPLAY_CRC_NIBBLE=1','-DV3_REPLAY_SEAL_BUDGET=1','-DV3_FRAME_LIST=1','-DV3_HUD_DIRECT=1')
 if($Normal){$flags+='-DV3_PERFORMANCE_CHALLENGE=1'}else{$flags+=@('-DV3_START_COUNT=1024',"-DV3_PROBE_FRAMES=$Frames")}
 & D:/efinity/risc_v_gcc/toolchain/bin/riscv-none-elf-gcc.exe -std=gnu11 -Os -Wall -Wextra -Werror '-Wstack-usage=2048' -march=rv32im_zicsr -mabi=ilp32 -ffreestanding -ffunction-sections -fdata-sections '-DNETWORK_LOCAL_IP=0xc0a80103' '-DNETWORK_PEER_IP=0xc0a80102' @flags -Isw/efinix_gpu/include -Isw/efinix_gpu/assets/v2 -Isw/efinix_gpu/assets/bullet -isystem "$bsp/include" -isystem "$soc/software/standalone/driver" -DUSE_GP -DNO_LIBC_INIT_ARRAY -nostartfiles "-T$bsp/linker/default.ld" '-Tsw/efinix_gpu/linker.ld' '-Wl,--gc-sections' "-Wl,-Map,$out/gpu_demo.map" "$soc/software/standalone/common/start.S" @sources -o "$out/gpu_demo.elf"
 if($LASTEXITCODE -ne 0){throw "Firmware build failed: $out"}
 & D:/efinity/risc_v_gcc/toolchain/bin/riscv-none-elf-objcopy.exe -O binary "$out/gpu_demo.elf" "$out/gpu_demo.bin"
 if($LASTEXITCODE -ne 0){throw 'BIN conversion failed'}
}
