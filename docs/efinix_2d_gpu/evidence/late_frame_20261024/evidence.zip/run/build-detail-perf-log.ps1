$ErrorActionPreference='Stop'
$root='D:/ZYNQ/smallproject/.worktrees/pango-riscv-cpu'
Set-Location $root
$out='generated/verification/v3/late-frame-20261024/detail-perf1200-r1'
if(Test-Path -LiteralPath $out){throw 'Fresh diagnostic directory required'}
New-Item -ItemType Directory -Path $out|Out-Null
$soc='D:/efinity_builds/competition_day1_20260906/sapphire/soc'
$bsp="$soc/bsp/efinix/EfxSapphireSoc"
$compiler='D:/efinity/risc_v_gcc/toolchain/bin/riscv-none-elf-gcc.exe'
$line=Get-Content 'sw/efinix_gpu/Makefile'|Where-Object {$_ -match '^SOURCES = '}
$sources=@(($line -replace '^SOURCES = ','') -split '\s+'|ForEach-Object {"sw/efinix_gpu/$_"})
$flags=@('-DBULLET_DEMO_DEFAULT=1','-DV3_INTERACTIVE=1','-DBULLET_OBJECT_CAPACITY=1024','-DV3_START_COUNT=1024','-DV3_PROBE_FRAMES=1200','-DV3_DETAIL_PROBE=1','-DV3_DETAIL_KEEP_PERF_LOG=1','-DV3_COPY_AHEAD=1','-DV3_LOGIC_COPY=1','-DREPLAY_CRC_NIBBLE=1','-DV3_REPLAY_SEAL_BUDGET=1','-DV3_FRAME_LIST=1','-DV3_HUD_DIRECT=1')
& $compiler -std=gnu11 -Os -Wall -Wextra -Werror '-Wstack-usage=2048' -march=rv32im_zicsr -mabi=ilp32 -ffreestanding -ffunction-sections -fdata-sections '-DNETWORK_LOCAL_IP=0xc0a80103' '-DNETWORK_PEER_IP=0xc0a80102' @flags -Isw/efinix_gpu/include -Isw/efinix_gpu/assets/v2 -Isw/efinix_gpu/assets/bullet -isystem "$bsp/include" -isystem "$soc/software/standalone/driver" -DUSE_GP -DNO_LIBC_INIT_ARRAY -nostartfiles "-T$bsp/linker/default.ld" '-Tsw/efinix_gpu/linker.ld' '-Wl,--gc-sections' "-Wl,-Map,$out/gpu_demo.map" "$soc/software/standalone/common/start.S" @sources -o "$out/gpu_demo.elf"
if($LASTEXITCODE -ne 0){throw 'Diagnostic ELF link failed'}
& D:/efinity/risc_v_gcc/toolchain/bin/riscv-none-elf-objcopy.exe -O binary "$out/gpu_demo.elf" "$out/gpu_demo.bin"
if($LASTEXITCODE -ne 0){throw 'Diagnostic BIN conversion failed'}
