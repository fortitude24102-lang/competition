#!/usr/bin/env bash
set -euo pipefail
cd '/mnt/d/ZYNQ/smallproject/.worktrees/pango-riscv-cpu'
out=generated/verification/v3/late-frame-20261024/host-shape-r1
mkdir -p "$out"
flags=(-std=c11 -Os -DV3_SHAPE_LUT=1 -DBULLET_OBJECT_CAPACITY=1024 -Wall -Wextra -Werror -fsanitize=undefined
 -DGPU_TEST_BACKEND -ffunction-sections -Wl,--gc-sections -Isw/efinix_gpu/include)
for test in gpu_instances gpu_instances_driver gpu_frame_list; do
 extra=()
 if [[ $test == gpu_instances_driver ]]; then extra=(sw/efinix_gpu/src/gpu.c); fi
 if [[ $test == gpu_frame_list ]]; then extra=(-Isw/efinix_gpu/tests/include sw/efinix_gpu/src/v3_demo.c sw/efinix_gpu/src/interactive_game.c sw/efinix_gpu/src/golden_renderer.c sw/efinix_gpu/src/rgb565.c); fi
 gcc "${flags[@]}" "sw/efinix_gpu/tests/test_$test.c" \
  sw/efinix_gpu/src/gpu_instances.c sw/efinix_gpu/src/bullet_demo.c "${extra[@]}" -o "$out/test_$test"
 "$out/test_$test"
done
