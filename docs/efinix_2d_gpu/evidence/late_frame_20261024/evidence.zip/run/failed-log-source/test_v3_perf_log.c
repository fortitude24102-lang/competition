#include "v3_perf_log.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>
#include <limits.h>
int main(void) {
 int32_t v[13]={0,1231,0,480,480,1010,600,3523,14898,0,0,0,-1};
 char text[320],expected[320];
 for(unsigned test=0;test<3;test++) {
  if(test==1)for(unsigned i=0;i<13;i++)v[i]=INT32_MIN;
  if(test==2)for(unsigned i=0;i<13;i++)v[i]=INT32_MAX;
  snprintf(expected,sizeof expected,"V3_PERF,mode=%d,tick=%d,seq=%d,x=%d,y=%d,visible=%d,fps_x10=%d,scene_us=%d,p95_work_us=%d,under=%d,miss=%d,keys=%08x,age=%d\r\n",v[0],v[1],v[2],v[3],v[4],v[5],v[6],v[7],v[8],v[9],v[10],(unsigned)v[11],v[12]);
  assert(v3_perf_log_format(text,sizeof text,v)==strlen(expected));
  assert(!strcmp(text,expected));
  for(unsigned cap=1;cap<=strlen(expected);cap++) {
   memset(text,0x5a,sizeof text);
   assert(!v3_perf_log_format(text,cap,v));
   assert((unsigned char)text[cap]==0x5a);
  }
 }
 assert(!v3_perf_log_format(NULL,0,v));
 assert(!v3_perf_log_format(text,sizeof text,NULL));
 puts("V3_PERF_LOG,PASS,exact_fields,signed_limits,hex8,bounds");
}
