#ifndef V3_PERF_LOG_H
#define V3_PERF_LOG_H
#include <stddef.h>
#include <stdint.h>
/* Fixed V3_PERF record; signed decimals and eight hex digits match the BSP. */
static inline size_t v3_perf_log_format(char *out,size_t capacity,const int32_t v[13]) {
 static const char *const names[]={"V3_PERF,mode=",",tick=",",seq=",",x=",",y=",",visible=",",fps_x10=",",scene_us=",",p95_work_us=",",under=",",miss=",",keys=",",age="};
 if(!out || !v || !capacity)return 0;
 size_t n=0;
#define V3_LOG_PUT(c) do {if(n+1>=capacity){out[0]=0;return 0;}out[n++]=(char)(c);}while(0)
 for(unsigned i=0;i<13;i++) {
  for(const char *p=names[i];*p;p++)V3_LOG_PUT(*p);
  if(i==11) {
   for(int shift=28;shift>=0;shift-=4)V3_LOG_PUT("0123456789abcdef"[((uint32_t)v[i]>>shift)&15u]);
  } else {
   uint32_t value=(uint32_t)v[i];char digits[10];unsigned count=0;
   if(v[i]<0){V3_LOG_PUT('-');value=0u-value;}
   do {digits[count++]=(char)('0'+value%10u);value/=10u;}while(value);
   while(count)V3_LOG_PUT(digits[--count]);
  }
 }
 V3_LOG_PUT('\r');V3_LOG_PUT('\n');out[n]=0;
#undef V3_LOG_PUT
 return n;
}
#endif
