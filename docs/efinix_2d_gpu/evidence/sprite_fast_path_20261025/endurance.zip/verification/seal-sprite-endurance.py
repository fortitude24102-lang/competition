import hashlib
import json
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

root = Path.cwd()
cpu = root / 'generated/verification/v3/cpu-builder-20261025'
dest = root / 'docs/efinix_2d_gpu/evidence/sprite_fast_path_20261025'
archive = dest / 'endurance.zip'
assert not archive.exists(), 'Never overwrite sealed evidence'
summary = json.loads((cpu / 'sprite-long-summary-r1.json').read_text(encoding='utf-8-sig'))
assert summary['frames'] == 108000
assert all(summary[k] == 0 for k in ('work_miss', 'late_present', 'under', 'errors'))
assert summary['work_max_us'] < 16666 and summary['wall_max_us'] < 16666
assert [summary[k] for k in ('visible_min', 'visible_max', 'alpha_min', 'alpha_max')] == [1006, 1016, 130, 131]
base = dest / 'evidence.zip'
assert hashlib.sha256(base.read_bytes()).hexdigest() == '4c39d3a339450dabfb2258e6794875b9ef0f86d6a4ba8e577dcca5e27fee78a3'
with ZipFile(base) as prior:
    assert prior.read('source/sw/efinix_gpu/src/bullet_demo.c') == (cpu / 'logic-baseline-bullet_demo.c').read_bytes()
raw = (cpu / 'sprite-long-r1-uart.log').read_text()
assert raw.count('V3_PROBE,target=1024,frames=108000,') == 1
assert 'V3_PROBE_STOP,result=0' in raw and 'V3_PROBE_HEALTH_FAIL' not in raw
assert 'V3_SEAL_STATE,count=600,sealed=1,words=256,offset=9836,crc=a7bd652f' in raw
files = {name: cpu / name for name in (
    'sprite-long-r1-uart.log', 'sprite-long-r1-capture.log', 'sprite-long-exec-r1.log',
    'sprite-long-summary-r1.json', 'sprite-selected-after-long-r1.json',
    'sprite-after-long-state-r1.json', 'sprite-after-long-menu-r1.log', 'run-sprite-long-r1.ps1')}
for child in (cpu / 'sprite-after-long-menu-r1').rglob('*'):
    if child.is_file():
        files['menu/' + child.relative_to(cpu / 'sprite-after-long-menu-r1').as_posix()] = child
files['ENDURANCE.md'] = dest / 'ENDURANCE.md'
files['verification/seal-sprite-endurance.py'] = Path(__file__)
rows = 0
manifest = []
with ZipFile(archive, 'x', ZIP_DEFLATED, compresslevel=9) as zipped:
    for name, path in sorted(files.items()):
        data = path.read_bytes()
        if path.suffix == '.jsonl':
            for line in data.decode('utf-8-sig').splitlines():
                value = json.loads(line)
                assert not any('"' + key + '"' in line for key in ('token', 'authorization', 'password', 'secret'))
                rows += 1
        manifest.append(dict(path=name, size=len(data), sha256=hashlib.sha256(data).hexdigest()))
        zipped.writestr(name, data)
    body = json.dumps(dict(payloads=manifest, parsed_status_rows=rows, ordinary_frames=108000,
                           implementation_commit='65881b9', continuous_long_run_proven=True), indent=2).encode()
    zipped.writestr('manifest.json', body)
with ZipFile(archive) as zipped:
    assert len(zipped.namelist()) == len(manifest)+1 == len(set(zipped.namelist()))
    for item in manifest:
        data = zipped.read(item['path'])
        assert len(data) == item['size'] and hashlib.sha256(data).hexdigest() == item['sha256']
digest = hashlib.sha256(archive.read_bytes()).hexdigest()
(dest / 'ENDURANCE_SHA256SUMS').write_text(digest + '  endurance.zip\n')
(dest / 'endurance-manifest.json').write_bytes(body)
result = dict(sha256=digest, bytes=archive.stat().st_size, entries=len(manifest)+1, status_rows=rows)
(cpu / 'sprite-endurance-seal-summary.json').write_text(json.dumps(result, indent=2))
print(json.dumps(result))
