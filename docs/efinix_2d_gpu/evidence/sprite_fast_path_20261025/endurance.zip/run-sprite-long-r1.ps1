$ErrorActionPreference='Stop'
Set-Location 'D:/ZYNQ/smallproject/.worktrees/pango-riscv-cpu'
$out='generated/verification/v3/cpu-builder-20261025'
$bit='D:/efinity_builds/alpha_early_candidate_20261025_r1/outflow/efinix_2d_gpu.bit'
$normal="$out/normal-sprite-fast-r1/gpu_demo.bin"
$fallback="$out/normal-shift-r1/gpu_demo.bin"
$probe="$out/probe-sprite-long-r1/gpu_demo.bin"
$python='C:/Users/fortiutde/AppData/Local/Programs/Python/Python39/python.exe'
foreach($file in @(@($bit,'ef240664097d115b1e2fbc60f336a9190d4e8a2941a760642627e3563fcebcb1'),@($normal,'808c2c51a35a71c309ff432307d6b239e82f00e6911527030a5b2b355f3752ab'),@($probe,'25b5fe36bd65cc4d289b5041553aa7a41de11ed347066366ae716dde334d865c'),@($fallback,'0070c5e03300e920d25ac84d1ffae3cebaa17111a7e20143fd535d315844efb1'))) {
 if((Get-FileHash -LiteralPath $file[0]).Hash.ToLowerInvariant() -ne $file[1]){throw 'Long validation input identity mismatch'}
}
$state=Invoke-RestMethod 'http://127.0.0.1:8765/api/status' -TimeoutSec 5
if($state.simulated -or $state.owned -or $state.stale -or !(1024 -band $state.telemetry.raw.status_flags)){throw 'Fresh real released MENU required'}
$accepted=$false
try {
 & scripts/test-game-menu-board.ps1 -Bin $normal -Bit $bit -LoadBit -SerialPort COM9 -OutDirectory "$out/sprite-normal-menu-r1" -ExpectedBuild 0x20261015 -LevelCount 6 -Python $python *> "$out/sprite-normal-menu-r1.log"
 if(!(Select-String -LiteralPath "$out/sprite-normal-menu-r1.log" -SimpleMatch 'PASS real 6-tier')){throw 'New sprite normal MENU not accepted'}
 'PASS sprite normal real six-tier MENU'
 & scripts/capture-game-probe.ps1 -Bin $probe -Log "$out/sprite-long-r1-uart.log" -SerialPort COM9 -LogicCopy 1 -SealWords 256 -HudDirect 1 -Seconds 1870 *> "$out/sprite-long-r1-capture.log"
 $raw=Get-Content -LiteralPath "$out/sprite-long-r1-uart.log" -Raw
 if($raw -notmatch 'V3_PROBE_STOP,result=0' -or $raw -notmatch 'V3_SEAL_STATE,count=600,sealed=1,words=256,offset=9836,crc=a7bd652f'){throw 'Long probe or replay input seal incomplete'}
 $match=[regex]::Matches($raw,'(?m)^V3_PROBE,target=1024,frames=108000,[^\r\n]+')
 if($match.Count -ne 1){throw 'Missing/duplicate full108000 summary'}
 $row=[ordered]@{}
 foreach($field in $match[0].Value.Split(',')|Select-Object -Skip 1){$parts=$field.Split('=');$row[$parts[0]]=[long]$parts[1]}
 $row|ConvertTo-Json|Set-Content -LiteralPath "$out/sprite-long-summary-r1.json" -Encoding utf8
 foreach($field in @{work_miss=0;late_present=0;under=0;errors=0;visible_min=1006;visible_max=1016;alpha_min=130;alpha_max=131}.GetEnumerator()){if($row[$field.Key] -ne $field.Value){throw "Long qualification failed: $($field.Key)"}}
 if($row.work_max_us -gt 16667 -or $row.wall_max_us -gt 16667){throw 'Long frame budget exceeded'}
 $accepted=$true
 $match[0].Value
} finally {
 $restore=if($accepted){$normal}else{$fallback}
 & scripts/test-game-menu-board.ps1 -Bin $restore -Bit $bit -LoadBit -SerialPort COM9 -OutDirectory "$out/sprite-after-long-menu-r1" -ExpectedBuild 0x20261015 -LevelCount 6 -Python $python *> "$out/sprite-after-long-menu-r1.log"
 $state=Invoke-RestMethod 'http://127.0.0.1:8765/api/status' -TimeoutSec 5
 if($state.simulated -or $state.owned -or $state.stale -or !(1024 -band $state.telemetry.raw.status_flags)){throw 'Long validation cleanup not fresh/released MENU'}
 $state|ConvertTo-Json -Depth 8|Set-Content -LiteralPath "$out/sprite-after-long-state-r1.json" -Encoding utf8
 [ordered]@{long_accepted=$accepted;bin=$restore;bin_sha256=(Get-FileHash -LiteralPath $restore).Hash.ToLowerInvariant();bit_sha256=(Get-FileHash -LiteralPath $bit).Hash.ToLowerInvariant();fresh_released_menu=$true}|ConvertTo-Json|Set-Content -LiteralPath "$out/sprite-selected-after-long-r1.json" -Encoding utf8
 'PASS sprite long validation cleanup returned to a verified normal MENU'
}
