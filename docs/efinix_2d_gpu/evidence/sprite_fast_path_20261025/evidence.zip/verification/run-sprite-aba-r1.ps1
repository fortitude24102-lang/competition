$ErrorActionPreference='Stop'
Set-Location 'D:/ZYNQ/smallproject/.worktrees/pango-riscv-cpu'
$out='generated/verification/v3/cpu-builder-20261025'
$bit='D:/efinity_builds/alpha_early_candidate_20261025_r1/outflow/efinix_2d_gpu.bit'
$normal="$out/normal-shift-r1/gpu_demo.bin"
foreach($file in @(@($bit,'ef240664097d115b1e2fbc60f336a9190d4e8a2941a760642627e3563fcebcb1'),@("$out/probe-sprite-control-r1/gpu_demo.bin",'515af700850bc51b9e26d72a574796f09bb3f6e1828c8855e33a7eecb60600ff'),@("$out/probe-sprite-fast-r1/gpu_demo.bin",'81e31110c2b055a10994aab6bb11242903b34e31942aa3593c7781b239a40f22'),@($normal,'0070c5e03300e920d25ac84d1ffae3cebaa17111a7e20143fd535d315844efb1'))) {
 if((Get-FileHash -LiteralPath $file[0] -Algorithm SHA256).Hash.ToLowerInvariant() -ne $file[1]){throw 'Sprite cohort input identity mismatch'}
}
if(!(Get-Content -LiteralPath "$out/selected-after-capacity-pair-r4.json" -Raw|ConvertFrom-Json).pair_qualified){throw 'Previous board cohort not accepted'}
$state=Invoke-RestMethod 'http://127.0.0.1:8765/api/status' -TimeoutSec 5
if($state.simulated -or $state.owned -or $state.stale -or !(1024 -band $state.telemetry.raw.status_flags)){throw 'Fresh real released MENU required'}
$results=@()
try {
 & D:/efinity/pgm/bin/ftdi_pgm.bat $bit -m jtag *> "$out/sprite-bit-load-r1.log"
 if($LASTEXITCODE -ne 0){throw 'Sprite cohort BIT load failed'}
 Start-Sleep -Seconds 3
 foreach($name in @('sprite-control-a1','sprite-fast-b1','sprite-control-a2','sprite-fast-b2')) {
  $bin=if($name.StartsWith('sprite-fast')){"$out/probe-sprite-fast-r1/gpu_demo.bin"}else{"$out/probe-sprite-control-r1/gpu_demo.bin"}
  & scripts/capture-game-probe.ps1 -Bin $bin -Log "$out/$name-uart.log" -SerialPort COM9 -LogicCopy 1 -SealWords 256 -HudDirect 1 -Seconds 140 *> "$out/$name-capture.log"
  $raw=Get-Content -LiteralPath "$out/$name-uart.log" -Raw
  if($raw -notmatch 'V3_PROBE_STOP,result=0' -or $raw -notmatch 'V3_SEAL_STATE,count=600,sealed=1,words=256,offset=9836,crc=a7bd652f'){throw "Incomplete or altered workload: $name"}
  $match=[regex]::Matches($raw,'(?m)^V3_PROBE,target=1024,frames=3600,[^\r\n]+')
  if($match.Count -ne 1){throw 'Missing/duplicate complete probe'}
  $row=[ordered]@{name=$name}
  foreach($field in $match[0].Value.Split(',')|Select-Object -Skip 1){$parts=$field.Split('=');$row[$parts[0]]=[long]$parts[1]}
  foreach($field in @{under=0;errors=0;visible_min=1006;visible_max=1016;alpha_min=130;alpha_max=131}.GetEnumerator()){if($row[$field.Key] -ne $field.Value){throw "Workload/health mismatch: $name/$($field.Key)"}}
  $results+=[pscustomobject]$row
  $match[0].Value
  $results|ConvertTo-Json -Depth 4|Set-Content -LiteralPath "$out/sprite-cohort-summary-r1.json" -Encoding utf8
 }
} finally {
 & scripts/test-game-menu-board.ps1 -Bin $normal -Bit $bit -LoadBit -SerialPort COM9 -OutDirectory "$out/sprite-final-menu-r1" -ExpectedBuild 0x20261015 -LevelCount 6 -Python C:/Users/fortiutde/AppData/Local/Programs/Python/Python39/python.exe *> "$out/sprite-final-menu-r1.log"
 $state=Invoke-RestMethod 'http://127.0.0.1:8765/api/status' -TimeoutSec 5
 if($state.simulated -or $state.owned -or $state.stale -or !(1024 -band $state.telemetry.raw.status_flags)){throw 'Sprite cohort final real MENU not fresh/released'}
 $state|ConvertTo-Json -Depth 8|Set-Content -LiteralPath "$out/sprite-final-state-r1.json" -Encoding utf8
 'PASS sprite cohort returned to accepted Alpha-early plus Q8 normal six-tier MENU'
}
