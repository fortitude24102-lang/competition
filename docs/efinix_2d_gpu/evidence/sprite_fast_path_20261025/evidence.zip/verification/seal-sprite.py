import hashlib
import json
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

root = Path.cwd()
cpu = root / 'generated/verification/v3/cpu-builder-20261025'
dest = root / 'docs/efinix_2d_gpu/evidence/sprite_fast_path_20261025'
archive = dest / 'evidence.zip'
assert not archive.exists(), 'Never overwrite sealed evidence'
files = {}

def add(path, name):
    assert path.is_file(), path
    assert name not in files, name
    files[name] = path

def tree(path, prefix):
    assert path.is_dir(), path
    for child in sorted(path.rglob('*')):
        if child.is_file() and '__pycache__' not in child.parts:
            add(child, prefix + '/' + child.relative_to(path).as_posix())

for name in ('probe-sprite-control-r1', 'probe-sprite-fast-r1', 'normal-sprite-fast-r1',
             'probe-sprite-long-r1', 'sprite-final-menu-r1', 'sprite-normal-menu-r1', 'github-sources'):
    tree(cpu / name, name)
for name in ('sprite-codegen-red.log', 'sprite-codegen-green.log', 'sprite-boundary-green.log',
             'sprite-boundary-1024-green.log', 'software-sprite-r1.log',
             'sprite-baseline-gpu_instances.c', 'build-sprite-control.ps1',
             'build-sprite-control-r1.log', 'build-sprite-fast-r1.log',
             'build-normal-sprite-fast-r1.log', 'build-sprite-long-r1.log',
             'sprite-fast-linked.asm', 'sprite-control-linked.asm',
             'run-sprite-aba-r1.ps1', 'run-sprite-long-r1.ps1', 'sprite-bit-load-r1.log',
             'sprite-board-cohort-r1.log', 'sprite-cohort-summary-r1.json',
             'sprite-analysis-r1.json', 'sprite-final-state-r1.json',
             'sprite-final-menu-r1.log', 'sprite-normal-menu-r1.log'):
    add(cpu / name, 'verification/' + name)
for name in ('sprite-control-a1', 'sprite-fast-b1', 'sprite-control-a2', 'sprite-fast-b2'):
    for kind in ('uart', 'capture'):
        add(cpu / (name + '-' + kind + '.log'), 'board/' + name + '-' + kind + '.log')
for name in ('src', 'include', 'tests'):
    tree(root / 'sw/efinix_gpu' / name, 'source/sw/efinix_gpu/' + name)
for name in ('scripts/test-gpu-sprite-codegen.ps1', 'scripts/test-gpu-coordinate-codegen.ps1',
             'scripts/test-v3-instances.sh', 'scripts/test-v3-integration.ps1',
             'scripts/test-efinix-software.ps1', 'scripts/capture-game-probe.ps1',
             'scripts/test-game-menu-board.ps1', 'scripts/control-keepalive.py',
             'sw/efinix_gpu/Makefile', 'sw/efinix_gpu/linker.ld'):
    add(root / name, 'source/' + name)
for name in ('sprite-codegen-c2e37b4fa439489c8e6ddda727890d90',
             'sprite-codegen-1b69206245264507ba50b00089b3956a'):
    path = root / 'generated/verification/v3' / name
    add(path / 'instances.su', 'codegen/' + name + '/instances.su')
    add(path / 'instances.o', 'codegen/' + name + '/instances.o')
add(dest / 'README.md', 'README.md')
add(Path(__file__), 'verification/seal-sprite.py')

def private_fields(value):
    if isinstance(value, dict):
        for key, child in value.items():
            assert key.lower() not in ('token', 'password', 'secret', 'authorization', 'cookie'), key
            private_fields(child)
    elif isinstance(value, list):
        for child in value:
            private_fields(child)

manifest = []
rows = 0
with ZipFile(archive, 'x', ZIP_DEFLATED, compresslevel=9) as zipped:
    for name, path in sorted(files.items()):
        data = path.read_bytes()
        if path.suffix == '.jsonl':
            for line in data.decode('utf-8-sig').splitlines():
                private_fields(json.loads(line))
                rows += 1
        elif path.suffix == '.json':
            private_fields(json.loads(data.decode('utf-8-sig')))
        manifest.append(dict(path=name, size=len(data), sha256=hashlib.sha256(data).hexdigest()))
        zipped.writestr(name, data)
    body = json.dumps(dict(payloads=manifest, parsed_status_rows=rows,
                           implementation_commit='65881b9', continuous_long_run_proven=False), indent=2).encode()
    zipped.writestr('manifest.json', body)
with ZipFile(archive) as zipped:
    assert len(zipped.namelist()) == len(manifest) + 1
    assert len(set(zipped.namelist())) == len(zipped.namelist())
    for record in manifest:
        data = zipped.read(record['path'])
        assert len(data) == record['size']
        assert hashlib.sha256(data).hexdigest() == record['sha256']
digest = hashlib.sha256(archive.read_bytes()).hexdigest()
(dest / 'SHA256SUMS').write_text(digest + '  evidence.zip\n')
(dest / 'manifest.json').write_bytes(body)
summary = dict(sha256=digest, bytes=archive.stat().st_size, entries=len(manifest)+1, parsed_status_rows=rows)
(cpu / 'sprite-seal-summary.json').write_text(json.dumps(summary, indent=2))
print(json.dumps(summary))
