# Four-write-credit whole-round review

Checkout D:/ZYNQ/smallproject/.worktrees/pango-riscv-cpu, branch codex/efinix-2d-gpu.
Base c6cbc8658779bac63505c449798d10c3679805be; head58a9bc36f5cc865387305b135cb5cc32e4aae296. Review the entire range, not HEAD~1.
Spec docs/superpowers/specs/2026-10-20-four-write-credits-design.md; plan docs/superpowers/plans/2026-10-20-four-write-credits.md. Progress/rulings adjacent progress.md. Inline/manual helper equivalent because WSL can't read Windows gitdir.

Only production change: optional writeCredits2/4, queue capacity in AxiWritePipeline and DdrQosArbiter plus row-counter width in CachedKeyStream; one trailing parameter propagated across Top/Render/Dense and CLI flag. No CPU/software/clock/ABI/scene/network changes. Default2,4requires existing untrimmed write pipeline. Prior SmallCopy code is BASE and out of new diff except relevant integration.

Review Focus verbatim: Four pending rows must not wrap to zero; a fifth AW must not overrun the owner FIFO; B errors at positions three/four or wrong BID must drain; split4KiB markers must retain request attribution; emergency must not withdraw offered AW or block promised W/B. Task1 pins these with real component tests.

Evidence root generated/verification/v3/four-write-credits-20261020/. red-r1.log missing feature; green-r1.log26/26 affected suites plus1/1 complete-Render; no errors, exit0. New Render fixture two2511/four1750 cycles, not boardFPS. Tests include writer, mixed-owner QoS, cached-row retirement, Copy/Fill/cached even-widthKey/Alpha+fault recovery. Unchanged full CPU/SoC suites deliberately not rerun per human instruction; two historic SoC firmware failures remain.

Generated60 single-module HDL, isolated Efinity final16 strictlypositive: core+.192/.026ns, globalhold+.012; XLR52918,RAM179,DSP37. resource-cdc-gate-r1.log and compile-r1.log; full reports at D:/efinity_builds/four_write_credits_20261020_r1/outflow. CandidateBIT07011f45516d2e028678a3ceadd4940fd8279b2d44e02fad0bac632e447e138a. ControlBIT118491... (previous round).

Same diagnosticBIN427430ee... A/B/A1040Key204096.667/163459.333/203979cycles, full955433/918886.333/956239.667; same fixture CRC/bytes, allAW/Bbalanced/health0. Same1024probe bd5489... A/B/A3600: work14178/13776/14183us, FPS59.0/59.0/59.2, late64/62/53; allhealth0 andCRC a7bd652f. ClaimGPU-specific gain, NOT ordinary1024stable60 or FPS gain. HUD B765.75/A2 756.625us no gain. Candidate20-round glyph oracle passed raw stop+all20, but original capture stop regex typo caused collector timeout/exit1; preserved transparently, no rerun or false success.

Same normalBIN33aac5... challenge session775101248 qualified2194+275Alpha,3600frames60.10FPS,workmax16609/wallmax16642us,miss/late/under/error0; five seconds samefreshowner/session stage4/best2194, performance-final.json. Collector/keepalive exit0. Board back normalMENU/released, no JTAG running. No Flash/mainpush/release update. Previous same normalBIN/controlBIT qualified2065; not an absolute/long-term limit.

Please verify real code paths, burst-credit reservation and error attribution, test validity and measurement claims. Do not re-run long tests/board sessions, edit files, dispatch subagents, merge/push or touch user-untracked files. Return precise Critical/Important/Minor and every Declined-to-judge item. No per-task rereview; parent will re-grade and TDD-fix important issues in one pass.
