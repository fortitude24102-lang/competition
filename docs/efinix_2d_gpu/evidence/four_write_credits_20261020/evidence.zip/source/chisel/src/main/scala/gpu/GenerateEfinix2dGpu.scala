package gpu

import circt.stage.ChiselStage

object GenerateEfinix2dGpu extends App {
  // Build-time A/B switch; the old software register ABI is unchanged.
  private val legacyCopy = args.contains("--legacy-copy")
  private val instances = args.contains("--instances")
  private val lists = args.contains("--frame-lists")
  private val keyPrefetch = args.contains("--key-prefetch")
  private val stripes = args.contains("--stripe-scratchpad")
  private val burstBuffer = args.contains("--copy-burst-buffer")
  private val scanoutPipeline = args.contains("--scanout-word-pipeline")
  private val keyTrim = args.contains("--key-row-trim")
  private val transform = args.contains("--transform-blit")
  private val alphaPipeline = args.contains("--alpha-pipeline")
  private val axiDiagnostics = args.contains("--axi-diagnostics")
  private val keyWritePipeline = args.contains("--key-write-pipeline")
  private val extendedArena = args.contains("--extended-list-arena")
  private val smallCopyPrefetch = args.contains("--small-copy-prefetch")
  private val writeCredits = if(args.contains("--four-write-credits")) 4 else 2
  require(!extendedArena || lists, "Extended list arena requires frame lists")
  require(!keyTrim || keyPrefetch, "Key row trim requires Key prefetch")
  ChiselStage.emitSystemVerilogFile(new Efinix2dGpuTop(!legacyCopy, instances,lists,keyPrefetch,stripes,burstBuffer,scanoutPipeline,keyTrim,transform,alphaPipeline,axiDiagnostics,keyWritePipeline,extendedArena,smallCopyPrefetch,writeCredits),
    args.filterNot(a => Set("--legacy-copy", "--instances", "--frame-lists", "--key-prefetch", "--stripe-scratchpad", "--copy-burst-buffer", "--scanout-word-pipeline", "--key-row-trim", "--transform-blit", "--alpha-pipeline", "--axi-diagnostics", "--key-write-pipeline", "--extended-list-arena", "--small-copy-prefetch", "--four-write-credits")(a)))
}
