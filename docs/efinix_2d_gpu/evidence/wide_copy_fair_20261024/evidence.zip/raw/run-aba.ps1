$ErrorActionPreference='Stop'
$root='D:/ZYNQ/smallproject/.worktrees/pango-riscv-cpu'
Set-Location $root
$experiment=Join-Path $root 'generated/verification/v3/wide-copy-fair-20261024'
$control='D:/efinity_builds/wide_copy_fair_control_20261024_r1'
$candidate='D:/efinity_builds/wide_copy_fair_20261024_r1'
$restore='D:/efinity_builds/alpha_row_prefetch_20261021_r1/outflow/efinix_2d_gpu.bit'
if((Get-FileHash -LiteralPath $restore).Hash.ToLowerInvariant() -cne 'd594d395e016353b8a4724bb5fca8400ff08d443712a6ba4171e8372143167ce'){throw 'Restoration BIT identity mismatch'}
if(!(Select-String -LiteralPath "$experiment/directed-gpu-r1.log" -SimpleMatch 'All tests passed.')){throw 'Directed GPU regression has not passed'}
foreach($pair in @(@($control,'control'),@($candidate,'candidate'))) {
 $log=Get-Content -Raw -LiteralPath "$experiment/resource-cdc-$($pair[1])-r1.log"
 if($log -notmatch 'PASS routed data CDC: 1488 paths' -or $log -notmatch 'PASS final setup/hold'){throw 'Missing routed acceptance gate'}
 $timing=Get-Content -Raw -LiteralPath "$($pair[0])/outflow/efinix_2d_gpu.timing.rpt"
 $rows=[regex]::Matches($timing,'(?m)^\S+\s+\S+\s+(-?[\d.]+)\s+(-?[\d.]+)\s+\(R-R\)\s*$')
 if($rows.Count -ne 16 -or @($rows|Where-Object {[double]$_.Groups[2].Value -le 0}).Count){throw 'Physical timing must be strictly positive'}
}
& "$root/scripts/compare-gpu-build.ps1" -ReferenceGpuRtlDirectory "$experiment/rtl-control-r2" -CandidateGpuRtlDirectory "$experiment/rtl-candidate-r2" -AllowedFeatureDifference wideCopyDma
$out=Join-Path $experiment 'board-aba-r1'
if(Test-Path -LiteralPath $out){throw 'Refusing to overwrite a board experiment'}
New-Item -ItemType Directory -Path $out | Out-Null
try {
 foreach($name in @('control-a1','candidate-b1','control-a2')) {
  $build=if($name -eq 'candidate-b1'){$candidate}else{$control}
  & D:/efinity/pgm/bin/ftdi_pgm.bat "$build/outflow/efinix_2d_gpu.bit" -m jtag *> "$out/$name-bit-load.log"
  if($LASTEXITCODE -ne 0){throw "BIT load failed: $name"}
  Start-Sleep -Seconds 3
  foreach($test in @(@('copy-aligned','COPY_BOARD_STOP'),@('axi-phases','SPRITE_PHASE_STOP'),@('alpha-oracle','ALPHA_PIPELINE_BOARD_STOP'))) {
   $kind=$test[0]
   & "$root/scripts/measure-hud-glyphs-board.ps1" -Bin "$experiment/input-bins/$kind.bin" -Log "$out/$name-$kind-uart.log" -StopPattern $test[1] -SerialPort COM9 -Seconds 100 *> "$out/$name-$kind-capture.log"
   $raw=Get-Content -Raw -LiteralPath "$out/$name-$kind-uart.log"
   if($raw -notmatch ($test[1]+',result=0') -or $raw -match 'hardware=[1-9]'){throw "Board diagnostic failed: $name/$kind"}
  }
  & "$root/scripts/capture-game-probe.ps1" -Bin "$experiment/input-bins/probe1024.bin" -Log "$out/$name-probe1024-uart.log" -SerialPort COM9 -LogicCopy 1 -SealWords 256 -HudDirect 1 -Seconds 140 *> "$out/$name-probe1024-capture.log"
  $raw=Get-Content -Raw -LiteralPath "$out/$name-probe1024-uart.log"
  $probe=[regex]::Match($raw,'(?m)^V3_PROBE,target=1024,frames=3600,[^\r\n]+').Value
  if(!$probe -or $probe -notmatch ',under=0,errors=0,' -or $raw -notmatch 'V3_SEAL_STATE,count=600,sealed=1,words=256,offset=9836,crc=a7bd652f'){throw "Probe health/identity failed: $name"}
  Write-Output "$name $probe"
 }
} finally {
 # A failed or successful experiment always returns the known primary to MENU.
 & "$root/scripts/test-game-menu-board.ps1" -Bin "$experiment/input-bins/normal.bin" -Bit $restore -LoadBit -SerialPort COM9 -OutDirectory "$experiment/final-menu-r1" -ExpectedBuild 0x20261015 -LevelCount 6 -Python 'D:/efinity/python311/bin/python.exe' *> "$experiment/final-menu-r1.log"
 Write-Output 'RESTORED,old-Alpha-row-prefetch-BIT,normal-six-level-MENU,control-released'
}
