set -euo pipefail
export JAVA_HOME=/mnt/d/Chisel-environment/wsl/java17-root/usr/lib/jvm/java-17-openjdk-amd64
export PATH="$JAVA_HOME/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
export COURSIER_CACHE=/mnt/d/Chisel-environment/cache/coursier
export CHISEL_FIRTOOL_CACHE=/mnt/d/Chisel-environment/wsl/firtool-cache
export SBT_OPTS="-Dsbt.boot.directory=/mnt/d/Chisel-environment/cache/sbt/boot-wsl -Dsbt.global.base=/mnt/d/Chisel-environment/cache/sbt/global-wsl -Dsbt.ivy.home=/mnt/d/Chisel-environment/cache/ivy-wsl"
unset CHISEL_FIRTOOL_PATH


cd '/mnt/d/ZYNQ/smallproject/.worktrees/pango-riscv-cpu/chisel'
exec bash /mnt/d/Chisel-environment/sbt/bin/sbt 'set Compile / unmanagedSources := (Compile / unmanagedSources).value.filter(_.getPath.contains("/gpu/"))' 'runMain gpu.GenerateEfinix2dGpu --target-dir ../generated/verification/v3/wide-copy-fair-20261024/rtl-control-r2 --instances --frame-lists --key-prefetch --scanout-word-pipeline --transform-blit --alpha-pipeline --axi-diagnostics --key-write-pipeline --extended-list-arena --small-copy-prefetch --four-write-credits --alpha-row-prefetch --split-verilog' 'runMain gpu.GenerateEfinix2dGpu --target-dir ../generated/verification/v3/wide-copy-fair-20261024/rtl-candidate-r2 --instances --frame-lists --key-prefetch --scanout-word-pipeline --transform-blit --alpha-pipeline --axi-diagnostics --key-write-pipeline --extended-list-arena --small-copy-prefetch --four-write-credits --alpha-row-prefetch --split-verilog --wide-copy-dma'
