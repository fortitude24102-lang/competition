set -euo pipefail
export JAVA_HOME=/mnt/d/Chisel-environment/wsl/java17-root/usr/lib/jvm/java-17-openjdk-amd64
export CHISEL_FIRTOOL_CACHE=/mnt/d/Chisel-environment/wsl/firtool-cache
cd /mnt/d/ZYNQ/smallproject/.worktrees/pango-riscv-cpu/chisel
classpath="target/scala-2.13/classes:$(cat target/streams/runtime/externalDependencyClasspath/_global/streams/export)"
exec "$JAVA_HOME/bin/java" -cp "$classpath" gpu.GenerateEfinix2dGpu --target-dir ../generated/verification/v3/wide-copy-fair-20261024/rtl-singlefile-r1
