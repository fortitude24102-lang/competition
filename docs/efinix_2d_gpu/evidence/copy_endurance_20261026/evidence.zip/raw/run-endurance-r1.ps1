$ErrorActionPreference='Stop'
Set-Location 'D:/ZYNQ/smallproject/.worktrees/pango-riscv-cpu'
$root='generated/verification/v3/copy-endurance-20261026'
$out="$root/capture-r1"
$probe="$root/probe108000-r1/gpu_demo.bin"
$normal='generated/verification/v3/cpu-builder-20261025/normal-logic-shift-r1/gpu_demo.bin'
$bit='D:/efinity_builds/wide_copy_prefetch_20261026_r1/outflow/efinix_2d_gpu.bit'
$fallback='D:/efinity_builds/alpha_early_candidate_20261025_r1/outflow/efinix_2d_gpu.bit'
function Record([string]$raw,[string]$prefix) {
 $lines=@($raw -split '\r?\n'|Where-Object {$_.StartsWith($prefix+',')})
 if($lines.Count -ne 1){throw "Missing/duplicate $prefix"}
 $fields=[ordered]@{}
 foreach($field in $lines[0].Split(',')|Select-Object -Skip 1){$p=$field.Split('=',2);if($p.Count -ne 2 -or $fields.Contains($p[0])){throw 'Invalid/duplicate field'};$fields[$p[0]]=$p[1]}
 return $fields
}
if(Test-Path -LiteralPath $out){throw 'Endurance capture must be fresh'}
if('COM9' -notin [IO.Ports.SerialPort]::GetPortNames()){throw 'Required serial device absent'}
foreach($pair in @(@($probe,'ab85b3d6c273b72b4064e2b6ffddec68378879b40565207c51c905adcd2bcf2b'),@($normal,'6000d1559cccaa91b340e2881db2afaed5c693cac2aa2e863f0340edb9c50b3c'),@($bit,'de149efdc78e1dded2c0e070efe52cd8e5e70fdc52e577dd7061c94902c72879'),@($fallback,'ef240664097d115b1e2fbc60f336a9190d4e8a2941a760642627e3563fcebcb1'))){if((Get-FileHash -LiteralPath $pair[0]).Hash.ToLowerInvariant() -ne $pair[1]){throw 'Endurance input changed'}}
& 'C:/Users/fortiutde/AppData/Local/Programs/Python/Python39/python.exe' generated/verification/v3/wide-copy-prefetch-20261026/verify-physical-inputs.py --manifest generated/verification/v3/wide-copy-prefetch-20261026/physical-inputs-after-build-r1.json
if($LASTEXITCODE){throw 'Physical inputs changed'}
$s=Invoke-RestMethod 'http://127.0.0.1:8765/api/status' -TimeoutSec 5
if($s.simulated -or $s.stale -or $s.owned -or !(1024 -band $s.telemetry.raw.status_flags)){throw 'Fresh real released normal MENU required'}
New-Item -ItemType Directory -Path $out | Out-Null
$accepted=$false
try {
 & D:/efinity/pgm/bin/ftdi_pgm.bat $bit -m jtag *> "$out/bit-load.log"
 if($LASTEXITCODE){throw 'Endurance JTAG load failed'}
 Start-Sleep -Seconds 3
 & scripts/capture-game-probe.ps1 -Bin $probe -Log "$out/uart.log" -SerialPort COM9 -LogicCopy 1 -SealWords 256 -HudDirect 1 -Seconds 1870 *> "$out/capture.log"
 $raw=Get-Content -LiteralPath "$out/uart.log" -Raw
 $stop=Record $raw 'V3_PROBE_STOP'
 if(!$stop.Contains('result') -or [long]$stop.result -ne 0){throw 'Endurance STOP failed'}
 $ready=Record $raw 'V3_READY'
 foreach($p in @{build='20261015';epoch='00030002';network='1';mode='LIVE';count='1024'}.GetEnumerator()){if(!$ready.Contains($p.Key) -or $ready[$p.Key] -ne $p.Value){throw 'Endurance workload identity changed'}}
 $seal=Record $raw 'V3_SEAL_STATE'
 foreach($p in @{count='600';sealed='1';words='256';offset='9836';crc='a7bd652f'}.GetEnumerator()){if(!$seal.Contains($p.Key) -or $seal[$p.Key] -ne $p.Value){throw 'Endurance input seal changed'}}
 $r=Record $raw 'V3_PROBE'
 $r|ConvertTo-Json|Set-Content -LiteralPath "$out/summary.json" -Encoding utf8
 foreach($p in @{target=1024;frames=108000;work_miss=0;late_present=0;under=0;errors=0;visible_min=1006;visible_max=1016;alpha_min=130;alpha_max=131}.GetEnumerator()){if(!$r.Contains($p.Key) -or [long]$r[$p.Key] -ne $p.Value){throw "Endurance qualification failed: $($p.Key)"}}
 if(!$r.Contains('work_max_us') -or !$r.Contains('wall_max_us') -or [long]$r.work_max_us -ge 16666 -or [long]$r.wall_max_us -ge 16666){throw 'Observed long frame maximum exceeded strict60 budget'}
 $accepted=$true
 'PASS full108000 ordinary frames and independent strict60 maximum checks'
} catch {
 $_|Out-String|Set-Content -LiteralPath "$out/failure.txt" -Encoding utf8
 throw
} finally {
 $restore=if($accepted){$bit}else{$fallback}
 & scripts/test-game-menu-board.ps1 -Bin $normal -Bit $restore -LoadBit -SerialPort COM9 -OutDirectory "$out/final-menu" -ExpectedBuild 0x20261015 -LevelCount 6 -Python C:/Users/fortiutde/AppData/Local/Programs/Python/Python39/python.exe *> "$out/final-menu.log"
 $s=Invoke-RestMethod 'http://127.0.0.1:8765/api/status' -TimeoutSec 5
 if($s.simulated -or $s.stale -or $s.owned -or !(1024 -band $s.telemetry.raw.status_flags)){throw 'Endurance final MENU not fresh/released'}
 $s|ConvertTo-Json -Depth 8|Set-Content -LiteralPath "$out/final-state.json" -Encoding utf8
 @{long_accepted=$accepted;bit_sha256=(Get-FileHash -LiteralPath $restore).Hash.ToLowerInvariant();normal_sha256=(Get-FileHash -LiteralPath $normal).Hash.ToLowerInvariant();fresh_released_menu=$true}|ConvertTo-Json|Set-Content -LiteralPath "$out/selected-after-long.json" -Encoding utf8
 'PASS endurance final normal MENU restored and released'
}
