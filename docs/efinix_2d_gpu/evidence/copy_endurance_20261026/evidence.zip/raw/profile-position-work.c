#include <assert.h>
#include <stdio.h>
#include "bullet_demo.c"
static unsigned positions,hashes;
void __attribute__((no_instrument_function)) __cyg_profile_func_enter(void *fn,void *caller) {
 (void)caller;if(fn==(void *)bullet_enemy_position)++positions;if(fn==(void *)waypoint)++hashes;
}
void __attribute__((no_instrument_function)) __cyg_profile_func_exit(void *fn,void *caller) {(void)fn;(void)caller;}
static bullet_state state,initial;
int main(void) {
 assert(!bullet_reset_player(&state,1024,7));initial=state;
 unsigned long long total=0,total_hashes=0;unsigned maximum=0,max_hashes=0,zero=0,small=0;
 for(unsigned tick=0;tick<12000;tick++) {
  positions=hashes=0;assert(!bullet_step_player_cached(&state,480,480,&initial));
  total+=positions;total_hashes+=hashes;if(positions>maximum)maximum=positions;if(hashes>max_hashes)max_hashes=hashes;
  if(!positions)++zero;
  if(positions<=3)++small;
 }
 printf("POSITION_WORK,steps=12000,position_calls=%llu,hash_calls=%llu,max_position_calls=%u,max_hash_calls=%u,zero_call_steps=%u,at_most3_steps=%u\n",total,total_hashes,maximum,max_hashes,zero,small);
}
