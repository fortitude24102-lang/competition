// Derived from official ddr3_example_top; CPU and DDR controller remain vendor instances.
//***************************************************************/
//
// Moudel Name    : ddr3_example_top.v
// Version        : 1.1
// Date Created   : 2023-02-23 10:37:59
// Last Modified  : 2023-02-24 15:27:41
// Abstract       : ---
//
//***************************************************************/
//Modification History
//1.initial
//***************************************************************/
`include "ddr3_controller/ddr3_parameter.vh"

`define Efinity_Debug
`timescale 1ps/1ps
// `define SOFT_JTAG

module efinix_sapphire_adapter #
(
parameter                       RANK_RATIO         = 1,       // # of unique CS outputs per rank
parameter                       CK_RATIO           = `CK_RATIO, 
parameter                       ASYN_AXI_CLK       = `ASYN_AXI_CLK, 
parameter                       RANKS              = `RANKS,
parameter                       CK_WIDTH           = `CK_WIDTH,       // # of CK/CK# outputs to memory   
parameter                       CKE_WIDTH          = `CKE_WIDTH,       // # of cke outputs
parameter                       CS_WIDTH           = `CS_WIDTH,       // # of unique CS outputs
parameter                       BANK_WIDTH         = `BANK_WIDTH,       // # of bank bits
parameter                       ROW_WIDTH          = `ROW_WIDTH,       // DRAM address bus width
parameter                       COL_WIDTH          = `COL_WIDTH,      // column address width
parameter                       DM_WIDTH           = `DM_WIDTH,       // # of DM (data mask)
parameter                       DQS_WIDTH          = `DQS_WIDTH,       // # of DQS (strobe)
parameter                       DQ_WIDTH           = `DQ_WIDTH,      // # of DQ (data)
parameter                       ODT_WIDTH          = `ODT_WIDTH,
parameter                       DQ_CNT_WIDTH       = `DQ_CNT_WIDTH,       // = ceil(log2(DQ_WIDTH))
parameter                       DQS_CNT_WIDTH      = `DQS_CNT_WIDTH,       // = ceil(log2(DQS_WIDTH))  
parameter                       DRAM_WIDTH         = `DRAM_WIDTH,       // # of DQ per DQS   
parameter                       DATA_WIDTH         = `DATA_WIDTH,
parameter                       ADDR_WIDTH         = `ADDR_WIDTH,    
// Sapphire's DDR arbiter uses ID[7] to route responses between CPU and the
// external GPU master.  The stock DDR3 demo's 4-bit default truncates it.
parameter                       AXI_ID_WIDTH       = 8,
parameter                       AXI_ADDR_WIDTH     = `AXI_ADDR_WIDTH,
parameter                       AXI_DATA_WIDTH     = `AXI_DATA_WIDTH
)
(

   // Clock and reset ports
   input                              axi_clk,      
   input                              core_clk,     // CORE CLK @ 100MHz
   input                              sdram_clk,    // SDRAM CK @ 400MHz
   input                              rx_cal_clk,   // SDRAM CK @ 400MHz
   input                              tx_cal_clk,   // SDRAM CK @ 400MHz
   input                              tx_cal_clk_90edge,   // SDRAM CK @ 400MHz
   input                              pll_locked,
   input                              user_pll_locked,
  //  input                              peripheralClk,
   //&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
   output  wire                       system_uart_0_io_txd,
   input                              system_uart_0_io_rxd,   
   input  [3:0]                       soc_gpio_IN,
   input  [4:0]                       nav_keys_n,
   output [3:0]                       soc_gpio_OUT,
   output [3:0]                       soc_gpio_OE,
    // debug core ports
`ifdef  Efinity_Debug  //&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&& 
`ifdef SOFT_JTAG
  input                               io_jtag_tms,
  input                               io_jtag_tdi,
  output  wire                        io_jtag_tdo,
  input                               io_jtag_tck,
`else
  input                               jtag_inst1_CAPTURE ,
  input                               jtag_inst1_DRCK    ,
  input                               jtag_inst1_RESET   ,
  input                               jtag_inst1_RUNTEST ,
  input                               jtag_inst1_SEL     ,
  input                               jtag_inst1_SHIFT   ,
  input                               jtag_inst1_TCK     ,
  input                               jtag_inst1_TDI     ,
  input                               jtag_inst1_TMS     ,
  input                               jtag_inst1_UPDATE  ,
  output                              jtag_inst1_TDO     ,
`endif 

`endif  //&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
   // PLL status flags  
   output [2:0]                       pll_shift,  
   output [4:0]                       pll_shift_sel,
   output                             pll_shift_ena,  
   // memory interface ports
   output                             ddr_ck_hi,
   output                             ddr_ck_lo,
   output                             ddr_reset_n,
   output [CKE_WIDTH-1:0]             ddr_cke,     
   output [ROW_WIDTH-1:0]             ddr_addr,
   output [BANK_WIDTH-1:0]            ddr_ba,
   output                             ddr_cas_n,

   output [CS_WIDTH*RANK_RATIO-1:0]   ddr_cs_n,
   output                             ddr_ras_n,
   output                             ddr_we_n,
   
   input  [DQS_WIDTH-1:0]             ddr_dqs_in_hi,
   input  [DQS_WIDTH-1:0]             ddr_dqs_in_lo,
   input  [DQ_WIDTH-1:0]              ddr_dq_in_hi,
   input  [DQ_WIDTH-1:0]              ddr_dq_in_lo,
   
   output [DQS_WIDTH-1:0]             ddr_dqs_oe,
   output [DQS_WIDTH-1:0]             ddr_dqs_oe_n,
   output [DQ_WIDTH-1:0]              ddr_dq_oe,  
   output [DQS_WIDTH-1:0]             ddr_dqs_out_hi,
   output [DQS_WIDTH-1:0]             ddr_dqs_out_lo,
   output [DQ_WIDTH-1:0]              ddr_dq_out_hi,
   output [DQ_WIDTH-1:0]              ddr_dq_out_lo,
   output [DM_WIDTH-1:0]              ddr_dm_hi,
   output [DM_WIDTH-1:0]              ddr_dm_lo,
   output [ODT_WIDTH-1:0]             ddr_odt,

   input                              system_spi_0_io_data_0_IN,
   input                              system_spi_0_io_data_1_IN,
   output                             system_spi_0_io_ss,
   output                             system_spi_0_io_sclk_write,
   output                             system_spi_0_io_data_0_OUT,
   output                             system_spi_0_io_data_0_OE,
   output                             system_spi_0_io_data_1_OUT,
   output                             system_spi_0_io_data_1_OE
,
   output                             gpu_stream_clk,
   output                             gpu_stream_reset,
   output [15:0]                      gpu_display_pixel,
   output                             gpu_display_valid,
   output                             gpu_display_line_last,
   output                             gpu_display_frame_last,
   input                              gpu_display_ready,
   input [11:0]                       gpu_scanout_level,
   input                              gpu_vblank,
   input                              gpu_underflow_pulse_gpu,
   input                              ge_clk, ge_reset,
   input                              gmii_rx_valid,
   input [7:0]                        gmii_rx_data,
   output                             gmii_tx_valid,
   output [7:0]                       gmii_tx_data
   );


      
//Parameter Define
parameter FREQ = 200;			// default is 100 MHz.  Redefine as needed.
`ifndef SIM
    localparam CNT_INIT = 1.5*FREQ*1000;
`else
    localparam CNT_INIT = 10;
`endif    
  localparam   AIW               = AXI_ID_WIDTH      ;
  localparam   ADW               = AXI_DATA_WIDTH    ;
  localparam   ABN               = AXI_DATA_WIDTH/8   ;
  /////////////////////////////////////////////////////////
  // Wire declarations
  reg  [19:0]                       cnt;    
  wire                              clk;
  wire                              rst;
  wire                              mmcm_locked;
  reg                               aresetn;
  wire                              app_sr_active;
  wire                              app_ref_ack;
  wire                              app_zq_ack;

  wire                              cal_done;

  // Slave Interface Write Address Ports
  wire [AXI_ID_WIDTH-1:0]           s_axi_awid;
  wire [AXI_ADDR_WIDTH-1:0]         s_axi_awaddr;
  wire [7:0]                        s_axi_awlen;
  wire [2:0]                        s_axi_awsize;
  wire [1:0]                        s_axi_awburst;
  wire [0:0]                        s_axi_awlock;
  wire [3:0]                        s_axi_awcache;
  wire [2:0]                        s_axi_awprot;
  wire                              s_axi_awvalid;
  wire                              s_axi_awready;
   // Slave Interface Write Data Ports
  wire [AXI_DATA_WIDTH-1:0]         s_axi_wdata;
  wire [(AXI_DATA_WIDTH/8)-1:0]     s_axi_wstrb;
  wire                              s_axi_wlast;
  wire                              s_axi_wvalid;
  wire                              s_axi_wready;
   // Slave Interface Write Response Ports
  wire                              s_axi_bready;
  wire [AXI_ID_WIDTH-1:0]           s_axi_bid;
  wire [1:0]                        s_axi_bresp;
  wire                              s_axi_bvalid;
   // Slave Interface Read Address Ports
  wire [AXI_ID_WIDTH-1:0]           s_axi_arid;
  wire [AXI_ADDR_WIDTH-1:0]         s_axi_araddr;
  wire [7:0]                        s_axi_arlen;
  wire [2:0]                        s_axi_arsize;
  wire [1:0]                        s_axi_arburst;
  wire [0:0]                        s_axi_arlock;
  wire [3:0]                        s_axi_arcache;
  wire [2:0]                        s_axi_arprot;
  wire                              s_axi_arvalid;
  wire                              s_axi_arready;
   // Slave Interface Read Data Ports
  wire                              s_axi_rready;
  wire [AXI_ID_WIDTH-1:0]           s_axi_rid;
  wire [AXI_DATA_WIDTH-1:0]         s_axi_rdata;
  wire [1:0]                        s_axi_rresp;
  wire                              s_axi_rlast;
  wire                              s_axi_rvalid;

  // Sapphire APB Slave 0 and external AXI Master 0 connect the generated GPU.
  wire [15:0]                       gpu_apb_paddr;
  wire                              gpu_apb_psel;
  wire                              gpu_apb_penable;
  wire                              gpu_apb_pwrite;
  wire [31:0]                       gpu_apb_pwdata;
  wire [31:0]                       gpu_apb_prdata;
  wire                              gpu_apb_pready;
  wire                              gpu_apb_pslverror;
  wire                              gpu_irq;
  wire                              gpu_reset;
  wire                              gpu_awready;
  wire                              gpu_awvalid;
  wire [31:0]                       gpu_awaddr;
  wire [3:0]                        gpu_awid;
  wire [7:0]                        gpu_awlen;
  wire [2:0]                        gpu_awsize;
  wire [1:0]                        gpu_awburst;
  wire                              gpu_awlock;
  wire [3:0]                        gpu_awcache;
  wire [2:0]                        gpu_awprot;
  wire [3:0]                        gpu_awqos;
  wire [3:0]                        gpu_awregion;
  wire                              gpu_wready;
  wire                              gpu_wvalid;
  wire [31:0]                       gpu_wdata;
  wire [3:0]                        gpu_wstrb;
  wire                              gpu_wlast;
  wire                              gpu_bready;
  wire                              gpu_bvalid;
  wire [3:0]                        gpu_bid;
  wire [1:0]                        gpu_bresp;
  wire                              gpu_arready;
  wire                              gpu_arvalid;
  wire [31:0]                       gpu_araddr;
  wire [3:0]                        gpu_arid;
  wire [7:0]                        gpu_arlen;
  wire [2:0]                        gpu_arsize;
  wire [1:0]                        gpu_arburst;
  wire                              gpu_arlock;
  wire [3:0]                        gpu_arcache;
  wire [2:0]                        gpu_arprot;
  wire [3:0]                        gpu_arqos;
  wire [3:0]                        gpu_arregion;
  wire                              gpu_rready;
  wire                              gpu_rvalid;
  wire [3:0]                        gpu_rid;
  wire [31:0]                       gpu_rdata;
  wire [1:0]                        gpu_rresp;
  wire                              gpu_rlast;
//***************************************************************************
  wire [2:0]                        vio_pll_shift;  
  wire [4:0]                        vio_pll_shift_sel;
  wire                              vio_pll_shift_ena; 
  wire                              pos_pll_shift_ena; 
  wire [2:0]                        phy_pll_shift;  
  wire [4:0]                        phy_pll_shift_sel;
  wire                              phy_pll_shift_ena; 
  wire                              ddr_reset; 
  wire                              sys_rst;
  wire  [2:0]                       phy_wr_pll_shift;
  wire                              idelay_ld       ;
  wire                              mpr_rdlvl_dly   ;
  wire  [7:0]                       wrlvl_dq_check  ;
  wire  [7:0]                       rd_level_dqs_check;  
  wire  [2:0]                       rdlvl_shift;  
  wire  [2:0]                       wrlvl_shift;  
  wire  [15:0]                      debug_fifo;  
  wire  [15:0]                      overflow_fifo;  
  wire  [6:0]                       init_cur_state;  
  wire  [35:0]                      ddr_debug_port;  
  wire                              app_rdy;  
  wire                              user_clk;  
  wire                              ddr_rstn;  
  wire                                phy_rddata_valid;
  wire [2*CK_RATIO*DQ_WIDTH-1:0]      phy_rd_data;
  wire [2*CK_RATIO*DATA_WIDTH-1:0]    app_rd_data_to_axi; 
  wire                                app_rd_data_end;
  wire                                app_rd_data_valid;
  wire [2*CK_RATIO*DQ_WIDTH-1:0]      rd_data;          
  wire                                rd_data_en;            
  wire                                rd_data_end;   
   
  
// Start of User Design top instance
//***************************************************************************
// The User design is instantiated below. The memory interface ports are
// connected to the top-level and the application interface ports are
// connected to the traffic generator module. This provides a reference
// for connecting the memory controller to system.
//***************************************************************************
always @(posedge user_clk or negedge sys_rst) begin
	if (!sys_rst)
		cnt <= 0;
    else if (cnt != CNT_INIT) 
        cnt <= cnt + 20'd1;
	else 
        cnt <= cnt;
end
assign ddr_rstn = (cnt == CNT_INIT);


generate
if (ASYN_AXI_CLK) begin
assign user_clk = axi_clk;

end else begin
assign user_clk = core_clk;
end
endgenerate
assign gpu_stream_clk = user_clk;
assign gpu_stream_reset = !sys_rst | gpu_reset;
//***************************************************************************
// The traffic generation module instantiated below drives traffic (patterns)
// on the application interface of the memory controller
//***************************************************************************
//***************************************************************************

assign sys_rst       = pll_locked & user_pll_locked;

// The build script derives this macro from the selected generated GPU interface.
// Legacy mode keeps the original SoC -> DDR direct wires without a mux stage.
`ifdef GPU_WIDE_COPY_DMA
  wire [AXI_ID_WIDTH-1:0] wide_awid, wide_bid, wide_arid, wide_rid;
  wire [31:0] wide_awaddr, wide_araddr;
  wire [7:0] wide_awlen, wide_arlen;
  wire [2:0] wide_awsize, wide_arsize, wide_awprot, wide_arprot;
  wire [1:0] wide_awburst, wide_arburst, wide_bresp, wide_rresp;
  wire wide_awlock, wide_arlock;
  wire [3:0] wide_awcache, wide_arcache, wide_awqos, wide_arqos;
  wire wide_awvalid, wide_awready, wide_wvalid, wide_wready, wide_wlast;
  wire wide_bvalid, wide_bready, wide_arvalid, wide_arready, wide_rvalid, wide_rready, wide_rlast;
  wire [AXI_DATA_WIDTH-1:0] wide_wdata, wide_rdata;
  wire [(AXI_DATA_WIDTH/8)-1:0] wide_wstrb;
`endif

//***************************************************************************
ddr3_top #(.AXI_ID_WIDTH(AXI_ID_WIDTH)) u_ddr3_top
      (
      
    .axi_clk                (user_clk             ),
    .core_clk               (core_clk            ),
    .sdram_clk              (sdram_clk           ),  
    .rx_cal_clk             (rx_cal_clk          ),
    .tx_cal_clk             (tx_cal_clk          ),
    .tx_cal_clk_90edge      (tx_cal_clk_90edge   ),
    .rstn                   (ddr_rstn            ),      
    .pll_shift              (pll_shift           ),
    .pll_shift_sel          (pll_shift_sel       ),
    .pll_shift_ena          (pll_shift_ena       ), 
///////////////DDR BUS
    .ddr_ck_hi              (ddr_ck_hi           ),
    .ddr_ck_lo              (ddr_ck_lo           ),
    .ddr_cke                (ddr_cke             ),    
    .ddr_reset_n            (ddr_reset_n         ),
    .ddr_cs_n               (ddr_cs_n            ),
    .ddr_ras_n              (ddr_ras_n           ),
    .ddr_cas_n              (ddr_cas_n           ),
    .ddr_we_n               (ddr_we_n            ),     
    .ddr_addr               (ddr_addr            ),
    .ddr_ba                 (ddr_ba              ),

    .ddr_dqs_oe             (ddr_dqs_oe          ),
    .ddr_dqs_oe_n           (ddr_dqs_oe_n        ),
    .ddr_dq_oe              (ddr_dq_oe           ),
    .ddr_dqs_in_hi          (ddr_dqs_in_hi       ),
    .ddr_dqs_in_lo          (ddr_dqs_in_lo       ),
    .ddr_dq_in_hi           (ddr_dq_in_hi        ),
    .ddr_dq_in_lo           (ddr_dq_in_lo        ),

    .ddr_dqs_out_hi         (ddr_dqs_out_hi      ),
    .ddr_dqs_out_lo         (ddr_dqs_out_lo      ),
    .ddr_dq_out_hi          (ddr_dq_out_hi       ),
    .ddr_dq_out_lo          (ddr_dq_out_lo       ),
    
    .ddr_dm_hi              (ddr_dm_hi           ),
    .ddr_dm_lo              (ddr_dm_lo           ),
    .ddr_odt                (ddr_odt             ),

// Application interface ports
       .app_sr_req                     (1'b0),
       .app_ref_req                    (1'b0),
       .app_zq_req                     (1'b0),
       .app_sr_active                  (app_sr_active),
       .app_ref_ack                    (app_ref_ack),
       .app_zq_ack                     (app_zq_ack),

// Slave Interface Write Address Ports
`ifdef GPU_WIDE_COPY_DMA
       .s_axi_awid(wide_awid), .s_axi_awaddr(wide_awaddr[AXI_ADDR_WIDTH-1:0]),
       .s_axi_awlen(wide_awlen), .s_axi_awsize(wide_awsize), .s_axi_awburst(wide_awburst),
       .s_axi_awlock(wide_awlock), .s_axi_awcache(wide_awcache), .s_axi_awprot(wide_awprot),
       .s_axi_awqos(wide_awqos), .s_axi_awvalid(wide_awvalid), .s_axi_awready(wide_awready),
       .s_axi_wdata(wide_wdata), .s_axi_wstrb(wide_wstrb), .s_axi_wlast(wide_wlast),
       .s_axi_wvalid(wide_wvalid), .s_axi_wready(wide_wready),
       .s_axi_bid(wide_bid), .s_axi_bresp(wide_bresp), .s_axi_bvalid(wide_bvalid), .s_axi_bready(wide_bready),
       .s_axi_arid(wide_arid), .s_axi_araddr(wide_araddr[AXI_ADDR_WIDTH-1:0]),
       .s_axi_arlen(wide_arlen), .s_axi_arsize(wide_arsize), .s_axi_arburst(wide_arburst),
       .s_axi_arlock(wide_arlock), .s_axi_arcache(wide_arcache), .s_axi_arprot(wide_arprot),
       .s_axi_arqos(wide_arqos), .s_axi_arvalid(wide_arvalid), .s_axi_arready(wide_arready),
       .s_axi_rid(wide_rid), .s_axi_rdata(wide_rdata), .s_axi_rresp(wide_rresp),
       .s_axi_rvalid(wide_rvalid), .s_axi_rready(wide_rready), .s_axi_rlast(wide_rlast),
`else
       .s_axi_awid                     (s_axi_awid        ),
       .s_axi_awaddr                   (s_axi_awaddr      ),
       .s_axi_awlen                    (s_axi_awlen       ),
       .s_axi_awsize                   (s_axi_awsize      ),
       .s_axi_awburst                  (s_axi_awburst     ),
       .s_axi_awlock                   (s_axi_awlock      ),
       .s_axi_awcache                  (s_axi_awcache     ),
       .s_axi_awprot                   (s_axi_awprot      ),
       .s_axi_awqos                    (4'h0              ),
       .s_axi_awvalid                  (s_axi_awvalid     ),
       .s_axi_awready                  (s_axi_awready     ),
// Slave Interface Write Data Ports
       .s_axi_wdata                    (s_axi_wdata       ),
       .s_axi_wstrb                    (s_axi_wstrb       ),
       .s_axi_wlast                    (s_axi_wlast       ),
       .s_axi_wvalid                   (s_axi_wvalid      ),
       .s_axi_wready                   (s_axi_wready      ),
// Slave Interface Write Response Ports
       .s_axi_bid                      (s_axi_bid         ),
       .s_axi_bresp                    (s_axi_bresp       ),
       .s_axi_bvalid                   (s_axi_bvalid      ),
       .s_axi_bready                   (s_axi_bready      ),
// Slave Interface Read Address Ports
       .s_axi_arid                     (s_axi_arid        ),
       .s_axi_araddr                   (s_axi_araddr      ),
       .s_axi_arlen                    (s_axi_arlen       ),
       .s_axi_arsize                   (s_axi_arsize      ),
       .s_axi_arburst                  (s_axi_arburst     ),
       .s_axi_arlock                   (s_axi_arlock      ),
       .s_axi_arcache                  (s_axi_arcache     ),
       .s_axi_arprot                   (s_axi_arprot      ),
       .s_axi_arqos                    (4'h0              ),
       .s_axi_arvalid                  (s_axi_arvalid     ),
       .s_axi_arready                  (s_axi_arready     ),
// Slave Interface Read Data Ports
       .s_axi_rid                      (s_axi_rid         ),
       .s_axi_rdata                    (s_axi_rdata       ),
       .s_axi_rresp                    (s_axi_rresp       ),
       .s_axi_rlast                    (s_axi_rlast       ),
       .s_axi_rvalid                   (s_axi_rvalid      ),
       .s_axi_rready                   (s_axi_rready      ),
`endif
//DEBUG       
       .wrlvl_dq_check                 (wrlvl_dq_check    ) ,
       .rd_level_dqs_check             (rd_level_dqs_check) ,
       .rdlvl_shift                    (rdlvl_shift) ,
       .wrlvl_shift                    (wrlvl_shift) ,
       .init_cur_state                 (init_cur_state    ) ,
       .idelay_ld                      (idelay_ld         ) ,
       .mpr_rdlvl_dly                  (mpr_rdlvl_dly     ) ,
       .ddr_debug_port                 (ddr_debug_port    ) ,
       .cal_done                       (cal_done          ) 
       );
// End of User Design top instance

//***************************************************************************


//***************************************************************************
wire network_select = gpu_apb_paddr[15:8] == 8'h02 || gpu_apb_paddr[15:8] == 8'h03;
wire [31:0] core_prdata, network_prdata;
wire core_pready, core_pslverror, network_pready, network_pslverror;
wire [31:0] local_prdata;
efinix_nav_keys nav_keys (
 .clk(user_clk), .reset(gpu_stream_reset), .keys_n(nav_keys_n),
 .address(gpu_apb_paddr[15:0]), .core_data(core_prdata), .data(local_prdata)
);
assign gpu_apb_prdata = network_select ? network_prdata : local_prdata;
assign gpu_apb_pready = network_select ? network_pready : core_pready;
assign gpu_apb_pslverror = network_select ? network_pslverror : core_pslverror;
wire asset_meta_valid, asset_meta_ready, asset_payload_valid, asset_payload_ready;
wire [31:0] asset_session, meta_session, meta_asset_id, meta_offset, meta_sequence, meta_crc32;
wire [15:0] meta_length, meta_flags;
wire [7:0] asset_payload_data;
wire asset_payload_last, asset_active, asset_abort, asset_drop, asset_stream_error;
efinix_network_subsystem u_asset_network (
    .gpu_clk(user_clk), .gpu_reset(gpu_stream_reset), .ge_clk(ge_clk), .ge_reset(ge_reset),
    .paddr(gpu_apb_paddr), .psel(gpu_apb_psel && network_select),
    .penable(gpu_apb_penable), .pwrite(gpu_apb_pwrite), .pwdata(gpu_apb_pwdata),
    .prdata(network_prdata), .pready(network_pready), .pslverror(network_pslverror),
    .gmii_rx_valid(gmii_rx_valid), .gmii_rx_data(gmii_rx_data),
    .gmii_tx_valid(gmii_tx_valid), .gmii_tx_data(gmii_tx_data),
    .asset_session(asset_session), .asset_active(asset_active),
    .asset_abort(asset_abort), .asset_drop(asset_drop),
    .meta_valid(asset_meta_valid), .meta_ready(asset_meta_ready),
    .meta_session(meta_session), .meta_asset_id(meta_asset_id), .meta_offset(meta_offset),
    .meta_sequence(meta_sequence), .meta_crc32(meta_crc32),
    .meta_length(meta_length), .meta_flags(meta_flags),
    .payload_valid(asset_payload_valid), .payload_ready(asset_payload_ready),
    .payload_data(asset_payload_data), .payload_last(asset_payload_last),
    .stream_error(asset_stream_error)
);
Efinix2dGpuTop u_efinix_2d_gpu (
    .clock                     (user_clk),
    .reset                     (gpu_stream_reset),
`ifdef GPU_WIDE_COPY_DMA
    // COMMON DDR reset, not the GPU/CPU debug reset: preserve outstanding DDR.
    .io_fabricReset(!ddr_rstn),
    .io_legacyDdr_aw_valid(s_axi_awvalid), .io_legacyDdr_aw_ready(s_axi_awready),
    .io_legacyDdr_aw_bits_addr({{(32-AXI_ADDR_WIDTH){1'b0}},s_axi_awaddr}),
    .io_legacyDdr_aw_bits_id(s_axi_awid), .io_legacyDdr_aw_bits_len(s_axi_awlen),
    .io_legacyDdr_aw_bits_size(s_axi_awsize), .io_legacyDdr_aw_bits_burst(s_axi_awburst),
    .io_legacyDdr_aw_bits_lock(s_axi_awlock), .io_legacyDdr_aw_bits_cache(4'b0),
    .io_legacyDdr_aw_bits_prot(3'b0), .io_legacyDdr_aw_bits_qos(4'b0), .io_legacyDdr_aw_bits_region(4'b0),
    .io_legacyDdr_w_valid(s_axi_wvalid), .io_legacyDdr_w_ready(s_axi_wready),
    .io_legacyDdr_w_bits_data(s_axi_wdata), .io_legacyDdr_w_bits_strb(s_axi_wstrb), .io_legacyDdr_w_bits_last(s_axi_wlast),
    .io_legacyDdr_b_valid(s_axi_bvalid), .io_legacyDdr_b_ready(s_axi_bready),
    .io_legacyDdr_b_bits_id(s_axi_bid), .io_legacyDdr_b_bits_resp(s_axi_bresp),
    .io_legacyDdr_ar_valid(s_axi_arvalid), .io_legacyDdr_ar_ready(s_axi_arready),
    .io_legacyDdr_ar_bits_addr({{(32-AXI_ADDR_WIDTH){1'b0}},s_axi_araddr}),
    .io_legacyDdr_ar_bits_id(s_axi_arid), .io_legacyDdr_ar_bits_len(s_axi_arlen),
    .io_legacyDdr_ar_bits_size(s_axi_arsize), .io_legacyDdr_ar_bits_burst(s_axi_arburst),
    .io_legacyDdr_ar_bits_lock(s_axi_arlock), .io_legacyDdr_ar_bits_cache(4'b0),
    .io_legacyDdr_ar_bits_prot(3'b0), .io_legacyDdr_ar_bits_qos(4'b0), .io_legacyDdr_ar_bits_region(4'b0),
    .io_legacyDdr_r_valid(s_axi_rvalid), .io_legacyDdr_r_ready(s_axi_rready),
    .io_legacyDdr_r_bits_id(s_axi_rid), .io_legacyDdr_r_bits_data(s_axi_rdata),
    .io_legacyDdr_r_bits_resp(s_axi_rresp), .io_legacyDdr_r_bits_last(s_axi_rlast),
    .io_wideDdr_aw_valid(wide_awvalid), .io_wideDdr_aw_ready(wide_awready),
    .io_wideDdr_aw_bits_addr(wide_awaddr), .io_wideDdr_aw_bits_id(wide_awid),
    .io_wideDdr_aw_bits_len(wide_awlen), .io_wideDdr_aw_bits_size(wide_awsize), .io_wideDdr_aw_bits_burst(wide_awburst),
    .io_wideDdr_aw_bits_lock(wide_awlock), .io_wideDdr_aw_bits_cache(wide_awcache),
    .io_wideDdr_aw_bits_prot(wide_awprot), .io_wideDdr_aw_bits_qos(wide_awqos), .io_wideDdr_aw_bits_region(),
    .io_wideDdr_w_valid(wide_wvalid), .io_wideDdr_w_ready(wide_wready),
    .io_wideDdr_w_bits_data(wide_wdata), .io_wideDdr_w_bits_strb(wide_wstrb), .io_wideDdr_w_bits_last(wide_wlast),
    .io_wideDdr_b_valid(wide_bvalid), .io_wideDdr_b_ready(wide_bready),
    .io_wideDdr_b_bits_id(wide_bid), .io_wideDdr_b_bits_resp(wide_bresp),
    .io_wideDdr_ar_valid(wide_arvalid), .io_wideDdr_ar_ready(wide_arready),
    .io_wideDdr_ar_bits_addr(wide_araddr), .io_wideDdr_ar_bits_id(wide_arid),
    .io_wideDdr_ar_bits_len(wide_arlen), .io_wideDdr_ar_bits_size(wide_arsize), .io_wideDdr_ar_bits_burst(wide_arburst),
    .io_wideDdr_ar_bits_lock(wide_arlock), .io_wideDdr_ar_bits_cache(wide_arcache),
    .io_wideDdr_ar_bits_prot(wide_arprot), .io_wideDdr_ar_bits_qos(wide_arqos), .io_wideDdr_ar_bits_region(),
    .io_wideDdr_r_valid(wide_rvalid), .io_wideDdr_r_ready(wide_rready),
    .io_wideDdr_r_bits_id(wide_rid), .io_wideDdr_r_bits_data(wide_rdata),
    .io_wideDdr_r_bits_resp(wide_rresp), .io_wideDdr_r_bits_last(wide_rlast),
`endif
    .io_apb_paddr              (gpu_apb_paddr),
    .io_apb_psel               (gpu_apb_psel && !network_select),
    .io_apb_penable            (gpu_apb_penable),
    .io_apb_pwrite             (gpu_apb_pwrite),
    .io_apb_pwdata             (gpu_apb_pwdata),
    .io_apb_prdata             (core_prdata),
    .io_apb_pready             (core_pready),
    .io_apb_pslverror          (core_pslverror),
    .io_assetMeta_valid(asset_meta_valid), .io_assetMeta_ready(asset_meta_ready),
    .io_assetMeta_bits_session(meta_session), .io_assetMeta_bits_assetId(meta_asset_id),
    .io_assetMeta_bits_offset(meta_offset), .io_assetMeta_bits_length(meta_length),
    .io_assetMeta_bits_flags(meta_flags), .io_assetMeta_bits_sequence(meta_sequence),
    .io_assetMeta_bits_crc32(meta_crc32),
    .io_assetPayload_valid(asset_payload_valid), .io_assetPayload_ready(asset_payload_ready),
    .io_assetPayload_bits_data(asset_payload_data), .io_assetPayload_bits_last(asset_payload_last),
    .io_assetSession(asset_session), .io_assetActive(asset_active),
    .io_assetAbort(asset_abort), .io_assetDropPacket(asset_drop),
    .io_assetStreamError(asset_stream_error),
    .io_axi_aw_ready           (gpu_awready),
    .io_axi_aw_valid           (gpu_awvalid),
    .io_axi_aw_bits_addr       (gpu_awaddr),
    .io_axi_aw_bits_id         (gpu_awid),
    .io_axi_aw_bits_len        (gpu_awlen),
    .io_axi_aw_bits_size       (gpu_awsize),
    .io_axi_aw_bits_burst      (gpu_awburst),
    .io_axi_aw_bits_lock       (gpu_awlock),
    .io_axi_aw_bits_cache      (gpu_awcache),
    .io_axi_aw_bits_prot       (gpu_awprot),
    .io_axi_aw_bits_qos        (gpu_awqos),
    .io_axi_aw_bits_region     (gpu_awregion),
    .io_axi_w_ready            (gpu_wready),
    .io_axi_w_valid            (gpu_wvalid),
    .io_axi_w_bits_data        (gpu_wdata),
    .io_axi_w_bits_strb        (gpu_wstrb),
    .io_axi_w_bits_last        (gpu_wlast),
    .io_axi_b_ready            (gpu_bready),
    .io_axi_b_valid            (gpu_bvalid),
    .io_axi_b_bits_id          (gpu_bid),
    .io_axi_b_bits_resp        (gpu_bresp),
    .io_axi_ar_ready           (gpu_arready),
    .io_axi_ar_valid           (gpu_arvalid),
    .io_axi_ar_bits_addr       (gpu_araddr),
    .io_axi_ar_bits_id         (gpu_arid),
    .io_axi_ar_bits_len        (gpu_arlen),
    .io_axi_ar_bits_size       (gpu_arsize),
    .io_axi_ar_bits_burst      (gpu_arburst),
    .io_axi_ar_bits_lock       (gpu_arlock),
    .io_axi_ar_bits_cache      (gpu_arcache),
    .io_axi_ar_bits_prot       (gpu_arprot),
    .io_axi_ar_bits_qos        (gpu_arqos),
    .io_axi_ar_bits_region     (gpu_arregion),
    .io_axi_r_ready            (gpu_rready),
    .io_axi_r_valid            (gpu_rvalid),
    .io_axi_r_bits_id          (gpu_rid),
    .io_axi_r_bits_data        (gpu_rdata),
    .io_axi_r_bits_resp        (gpu_rresp),
    .io_axi_r_bits_last        (gpu_rlast),
    .io_vblank                 (gpu_vblank),
    .io_scanoutLevel           (gpu_scanout_level),
    .io_underflow_pulse_gpu    (gpu_underflow_pulse_gpu),
    .io_displayReady           (gpu_display_ready),
    .io_displayPixel           (gpu_display_pixel),
    .io_displayValid           (gpu_display_valid),
    .io_displayLineLast        (gpu_display_line_last),
    .io_displayFrameLast       (gpu_display_frame_last),
    .io_irq                    (gpu_irq)
);

 soc u_sapphire_soc(
    .axiA_awready(1'b0),
    .axiA_arready(1'b0),
    .axiAInterrupt(1'b0),
    .axiA_rlast(1'b0),
    .axiA_wready(1'b0),
    .axiA_bvalid(1'b0),
    .axiA_bid(1'b0),
    .axiA_bresp(1'b0),
    .axiA_rvalid(1'b0),
    .axiA_rdata(1'b0),
    .axiA_rid(1'b0),
    .axiA_rresp(1'b0),
    .userInterruptA(gpu_irq),
    .system_i2c_0_io_scl_read(1'b1),
    .system_i2c_0_io_sda_read(1'b1),
    .io_ddrMasters_0_clk(user_clk),
    .io_ddrMasters_0_reset(gpu_reset),
    .io_ddrMasters_0_r_payload_last(gpu_rlast),
    .io_ddrMasters_0_r_payload_resp(gpu_rresp),
    .io_ddrMasters_0_r_payload_id(gpu_rid),
    .io_ddrMasters_0_r_payload_data(gpu_rdata),
    .io_ddrMasters_0_r_ready(gpu_rready),
    .io_ddrMasters_0_r_valid(gpu_rvalid),
    .io_ddrMasters_0_ar_payload_prot(gpu_arprot),
    .io_ddrMasters_0_ar_payload_qos(gpu_arqos),
    .io_ddrMasters_0_ar_payload_cache(gpu_arcache),
    .io_ddrMasters_0_ar_payload_lock(gpu_arlock),
    .io_ddrMasters_0_ar_payload_burst(gpu_arburst),
    .io_ddrMasters_0_ar_payload_size(gpu_arsize),
    .io_ddrMasters_0_ar_payload_len(gpu_arlen),
    .io_ddrMasters_0_ar_payload_region(gpu_arregion),
    .io_ddrMasters_0_ar_payload_id(gpu_arid),
    .io_ddrMasters_0_ar_payload_addr(gpu_araddr),
    .io_ddrMasters_0_ar_ready(gpu_arready),
    .io_ddrMasters_0_ar_valid(gpu_arvalid),
    .io_ddrMasters_0_b_payload_resp(gpu_bresp),
    .io_ddrMasters_0_b_payload_id(gpu_bid),
    .io_ddrMasters_0_b_ready(gpu_bready),
    .io_ddrMasters_0_b_valid(gpu_bvalid),
    .io_ddrMasters_0_w_payload_last(gpu_wlast),
    .io_ddrMasters_0_w_payload_strb(gpu_wstrb),
    .io_ddrMasters_0_w_payload_data(gpu_wdata),
    .io_ddrMasters_0_w_ready(gpu_wready),
    .io_ddrMasters_0_w_valid(gpu_wvalid),
    .io_ddrMasters_0_aw_payload_prot(gpu_awprot),
    .io_ddrMasters_0_aw_payload_qos(gpu_awqos),
    .io_ddrMasters_0_aw_payload_cache(gpu_awcache),
    .io_ddrMasters_0_aw_payload_lock(gpu_awlock),
    .io_ddrMasters_0_aw_payload_burst(gpu_awburst),
    .io_ddrMasters_0_aw_payload_size(gpu_awsize),
    .io_ddrMasters_0_aw_payload_len(gpu_awlen),
    .io_ddrMasters_0_aw_payload_region(gpu_awregion),
    .io_ddrMasters_0_aw_payload_id(gpu_awid),
    .io_ddrMasters_0_aw_payload_addr(gpu_awaddr),
    .io_ddrMasters_0_aw_ready(gpu_awready),
    .io_ddrMasters_0_aw_valid(gpu_awvalid),
    .io_asyncReset                      (!pll_locked                        ),
    .io_systemClk                       (user_clk                           ),

    //UART 0
    .system_uart_0_io_txd               (system_uart_0_io_txd               ),
    .system_uart_0_io_rxd               (system_uart_0_io_rxd               ),
    .io_memoryClk                       (user_clk                           ),
    .io_memoryReset                     (                                   ),
    .io_systemReset                     (                                   ),
    //External Memory AXI4 Interface
    .io_ddrA_aw_payload_prot            (                                  ),//(                                  ),
    .io_ddrA_aw_payload_qos             (                                  ),//(                                  ),
    .io_ddrA_aw_payload_cache           (                                  ),//(                                  ),
    .io_ddrA_aw_payload_lock            (s_axi_awlock                     ),//(m1_axi_awlock                     ),
    .io_ddrA_aw_payload_burst           (s_axi_awburst                    ),//(m1_axi_awburst                    ),
    .io_ddrA_aw_payload_size            (s_axi_awsize                     ),//(m1_axi_awsize                     ),
    .io_ddrA_aw_payload_len             (s_axi_awlen                      ),//(m1_axi_awlen                      ),
    .io_ddrA_aw_payload_region          (                                 ),//(                                  ),
    .io_ddrA_aw_payload_id              (s_axi_awid                       ),//(m1_axi_awid                       ),
    .io_ddrA_aw_payload_addr            (s_axi_awaddr                     ),//(m1_axi_awaddr                     ),
    .io_ddrA_aw_ready                   (s_axi_awready                    ),//(m1_axi_awready                    ),
    .io_ddrA_aw_valid                   (s_axi_awvalid                    ),//(m1_axi_awvalid                    ),
    .io_ddrA_w_payload_last             (s_axi_wlast                      ),//(m1_axi_wlast                      ),
    .io_ddrA_w_ready                    (s_axi_wready                     ),//(m1_axi_wready                     ),
    .io_ddrA_w_valid                    (s_axi_wvalid                     ),  //(m1_axi_wvalid                     ),    
    .io_ddrA_w_payload_strb             (s_axi_wstrb                      ),//(m1_axi_wstrb                      ),
    .io_ddrA_w_payload_data             (s_axi_wdata                      ),//(m1_axi_wdata                      ),
    .io_ddrA_b_payload_resp             (s_axi_bresp),//(                                  ),
    .io_ddrA_b_payload_id               (s_axi_bid                        ),//(m1_axi_bid                        ),
    .io_ddrA_b_ready                    (s_axi_bready                     ),//(m1_axi_bready                     ),
    .io_ddrA_b_valid                    (s_axi_bvalid                     ),//(m1_axi_bvalid                     ),
    .io_ddrA_ar_payload_prot            (                                 ),//(                                  ),
    .io_ddrA_ar_payload_qos             (                                 ),//(                                  ),
    .io_ddrA_ar_payload_cache           (                                 ),//(                                  ),
    .io_ddrA_ar_payload_region          (                                 ),//(                                  ),
    .io_ddrA_ar_payload_lock            (s_axi_arlock                     ),//(m1_axi_arlock                     ),
    .io_ddrA_ar_payload_burst           (s_axi_arburst                    ),//(m1_axi_arburst                    ),
    .io_ddrA_ar_payload_size            (s_axi_arsize                     ),//(m1_axi_arsize                     ),
    .io_ddrA_ar_payload_len             (s_axi_arlen                      ),//(m1_axi_arlen                      ),
    .io_ddrA_ar_payload_id              (s_axi_arid                       ),//(m1_axi_arid                       ),
    .io_ddrA_ar_payload_addr            (s_axi_araddr                     ),//(m1_axi_araddr                     ),
    .io_ddrA_ar_ready                   (s_axi_arready                    ),//(m1_axi_arready                    ),
    .io_ddrA_ar_valid                   (s_axi_arvalid                    ),//(m1_axi_arvalid                    ),
    .io_ddrA_r_payload_last             (s_axi_rlast                      ),//(m1_axi_rlast                      ),
    .io_ddrA_r_payload_resp             (s_axi_rresp                      ),//(m1_axi_rresp                      ),
    .io_ddrA_r_payload_id               (s_axi_rid                        ),//(m1_axi_rid                        ),
    .io_ddrA_r_payload_data             (s_axi_rdata                      ),//(m1_axi_rdata                      ),
    .io_ddrA_r_ready                    (s_axi_rready                     ),//(m1_axi_rready                     ),
    .io_ddrA_r_valid                    (s_axi_rvalid                     ),//(m1_axi_rvalid                     ),
     //SPI 0
    .system_spi_0_io_sclk_write         (system_spi_0_io_sclk_write         ),
    .system_spi_0_io_data_0_writeEnable (system_spi_0_io_data_0_OE ),
    .system_spi_0_io_data_0_read        (system_spi_0_io_data_0_IN        ),
    .system_spi_0_io_data_0_write       (system_spi_0_io_data_0_OUT       ),
    .system_spi_0_io_data_1_writeEnable (system_spi_0_io_data_1_OE ),
    .system_spi_0_io_data_1_read        (system_spi_0_io_data_1_IN        ),
    .system_spi_0_io_data_1_write       (system_spi_0_io_data_1_OUT       ),
    .system_spi_0_io_data_2_writeEnable (                                   ),
    .system_spi_0_io_data_2_read        (1'b0),
    .system_spi_0_io_data_2_write       (                                   ),
    .system_spi_0_io_data_3_writeEnable (                                   ),
    .system_spi_0_io_data_3_read        (1'b0),
    .system_spi_0_io_data_3_write       (                                   ),
    .system_spi_0_io_ss                 (system_spi_0_io_ss                 ),
    //APB 0
    .io_apbSlave_0_PADDR                (gpu_apb_paddr),
    .io_apbSlave_0_PSEL                 (gpu_apb_psel),
    .io_apbSlave_0_PENABLE              (gpu_apb_penable),
    .io_apbSlave_0_PREADY               (gpu_apb_pready),
    .io_apbSlave_0_PWRITE               (gpu_apb_pwrite),
    .io_apbSlave_0_PWDATA               (gpu_apb_pwdata),
    .io_apbSlave_0_PRDATA               (gpu_apb_prdata),
    .io_apbSlave_0_PSLVERROR            (gpu_apb_pslverror),

    .system_gpio_0_io_write             ( soc_gpio_OUT                      ),//,
    .system_gpio_0_io_read              ( soc_gpio_IN                       ),//
    .system_gpio_0_io_writeEnable       ( soc_gpio_OE                       ),//, 


    //Hard Jtag Tap
    .jtagCtrl_tck                       (jtag_inst1_TCK                     ),
    .jtagCtrl_tdi                       (jtag_inst1_TDI                     ),
    .jtagCtrl_tdo                       (jtag_inst1_TDO                     ),
    .jtagCtrl_enable                    (jtag_inst1_SEL                     ),
    .jtagCtrl_capture                   (jtag_inst1_CAPTURE                 ),
    .jtagCtrl_shift                     (jtag_inst1_SHIFT                   ),
    .jtagCtrl_update                    (jtag_inst1_UPDATE                  ),
    .jtagCtrl_reset                     (jtag_inst1_RESET                   )

);

//***************************************************************************


//***************************************************************************

endmodule
