import hashlib
import json
import sys
from pathlib import Path
import xml.etree.ElementTree as ET

root = Path.cwd()
out = root / 'generated/verification/v3/local-keys-20261026'
build = Path('D:/efinity_builds/local_keys_20261026_r2')
project = build / 'efinix_2d_gpu.xml'
paths = {project, build / 'efinix_2d_gpu.peri.xml', build / 'gpu-build.json'}
def digest(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()
def canonical(node):
    return [node.tag, [[k, v] for k, v in sorted(node.attrib.items())], (node.text or '').strip(), [canonical(c) for c in node]]
tree = ET.parse(project)
for node in tree.iter():
    kind = node.tag.split('}')[-1]
    if kind in ('design_file', 'sdc_file'):
        paths.add(Path(node.attrib['name']))
    elif kind == 'ip':
        settings = Path(node.attrib['path'])
        paths.add(settings)
        for child in node:
            if child.tag.split('}')[-1] == 'ip_src_file':
                paths.add(settings.parent / child.attrib['name'])
allowed = {'board/efinix_ti60/rtl/board_top.v', 'board/efinix_ti60/rtl/efinix_sapphire_adapter.v',
           'board/efinix_ti60/rtl/efinix_user_keys_gpio.v', 'board/efinix_ti60/efinix_2d_gpu.sdc'}
common = json.loads((root / 'generated/verification/v3/wide-copy-fair-20261024/wide_copy_fair_20261024_r1-board-inputs.json').read_text(encoding='utf-8-sig'))
for record in common:
    path = Path(record['Path'])
    if path.relative_to(root).as_posix() not in allowed:
        assert digest(path) == record['Sha256'], 'Unexpected shared input change: ' + str(path)
    paths.add(path)
paths.update(root / 'board/efinix_ti60' / n for n in ('efinix_2d_gpu.xml', 'efinix_2d_gpu.peri.xml'))
assert (build / 'efinix_2d_gpu.peri.xml').read_bytes() == (root / 'board/efinix_ti60/efinix_2d_gpu.peri.xml').read_bytes()
rtl = root / 'generated/verification/v3/wide-copy-prefetch-20261026/rtl-candidate-r1'
gpu = json.loads((rtl / 'gpu-build.json').read_text(encoding='utf-8-sig'))
assert json.loads((build / 'gpu-build.json').read_text(encoding='utf-8-sig')) == gpu
for name, sha in gpu['rtlSha256'].items():
    assert digest(rtl / name) == sha
    paths.add(rtl / name)
rom_source = root / 'board/efinix_ti60/vendor/sapphire_ddr3/par/ddr_demo_ti60/ip/soc'
roms = list(build.glob('*.bin'))
assert len(roms) == 4
for rom in roms:
    assert rom.read_bytes() == (rom_source / rom.name).read_bytes()
    paths.update((rom, rom_source / rom.name))
result = dict(scope='Snapshot captured after build launch, around completion; not a prebuild freeze. Verify subsequent input stability. Five local inputs are an intentional board configuration change.',
              project_canonical=canonical(tree.getroot()),
              files={str(p.resolve()): digest(p) for p in sorted(paths) if p != project})
snapshot = out / 'physical-inputs-after-launch-r2.json'
if '--freeze' in sys.argv:
    assert not snapshot.exists()
    snapshot.write_text(json.dumps(result, indent=2))
else:
    assert json.loads(snapshot.read_text()) == result, 'Inputs changed after P&R snapshot'
print('PASS selected GPU hashes, shared board inputs, four ROMs and input snapshot:', len(paths))
