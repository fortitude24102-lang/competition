import hashlib
import json
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

root = Path.cwd()
raw = root / 'generated/verification/v3/local-keys-20261026'
build = Path('D:/efinity_builds/local_keys_20261026_r2')
dest = root / 'docs/efinix_2d_gpu/evidence/local_keys_20261026'
archive = dest / 'evidence.zip'
assert not archive.exists()
entries = {}
def add(path, name):
    assert path.is_file(), str(path)
    assert name not in entries or entries[name] == path
    entries[name] = path
snapshot = json.loads((raw / 'physical-inputs-after-launch-r2.json').read_text())
for name, digest in snapshot['files'].items():
    path = Path(name)
    assert hashlib.sha256(path.read_bytes()).hexdigest() == digest
    prefix, rel = ('source', path.relative_to(root)) if path.is_relative_to(root) else ('physical', path.relative_to(build))
    add(path, prefix + '/' + rel.as_posix())
for path in raw.rglob('*'):
    if path.is_file() and ('normal-r1' not in path.parts) and path.suffix not in ('.vvp',) and not path.name.startswith(('local-keys', 'test_local_keys')):
        add(path, 'raw/' + path.relative_to(raw).as_posix())
for path in build.rglob('*'):
    if path.is_file() and (path.suffix in ('.rpt', '.log', '.bit', '.sdc', '.csv') or path.name.endswith('.map.v') or path.name == 'efinix_2d_gpu.xml'):
        add(path, 'physical/' + path.relative_to(build).as_posix())
for directory in ('sw/efinix_gpu/include', 'sw/efinix_gpu/src', 'sw/efinix_gpu/tests'):
    for path in (root / directory).rglob('*'):
        if path.is_file() and path.suffix in ('.c', '.h'):
            add(path, 'source/' + path.relative_to(root).as_posix())
for name in ('sw/efinix_gpu/Makefile', 'scripts/test-v3-integration.ps1', 'scripts/test-stripe-hud-route.sh', 'tb/verilog/tb_nav_keys.sv', 'docs/superpowers/plans/2026-10-26-local-five-way.md'):
    add(root / name, 'source/' + name)
add(dest / 'README.md', 'README.md')
inventory = {}
with ZipFile(archive, 'w', ZIP_DEFLATED, compresslevel=6) as zipped:
    for name, path in sorted(entries.items()):
        data = path.read_bytes()
        inventory[name] = hashlib.sha256(data).hexdigest()
        zipped.writestr(name, data)
    zipped.writestr('inventory.json', json.dumps(inventory, indent=2))
with ZipFile(archive) as zipped:
    assert zipped.testzip() is None
    for name, digest in inventory.items():
        assert hashlib.sha256(zipped.read(name)).hexdigest() == digest
digest = hashlib.sha256(archive.read_bytes()).hexdigest()
(dest / 'evidence.sha256').write_text(digest + '  evidence.zip\n')
print(json.dumps(dict(entries=len(inventory) + 1, bytes=archive.stat().st_size, sha256=digest, verified=True)))
