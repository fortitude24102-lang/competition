
generated/verification/v3/cpu-builder-20261025/probe-logic-shift-r1/gpu_demo.elf:     file format elf32-littleriscv


Disassembly of section .init:

00001000 <_start>:
    1000:	0000e197          	auipc	gp,0xe
    1004:	d6818193          	addi	gp,gp,-664 # ed68 <__global_pointer$>

00001008 <init>:
    1008:	0001d117          	auipc	sp,0x1d
    100c:	a7810113          	addi	sp,sp,-1416 # 1da80 <__freertos_irq_stack_top>
    1010:	0000c517          	auipc	a0,0xc
    1014:	28450513          	addi	a0,a0,644 # d294 <_data>
    1018:	0000c597          	auipc	a1,0xc
    101c:	27c58593          	addi	a1,a1,636 # d294 <_data>
    1020:	0000d617          	auipc	a2,0xd
    1024:	56860613          	addi	a2,a2,1384 # e588 <logo_enabled>
    1028:	00c5fc63          	bgeu	a1,a2,1040 <init+0x38>
    102c:	00052283          	lw	t0,0(a0)
    1030:	0055a023          	sw	t0,0(a1)
    1034:	00450513          	addi	a0,a0,4
    1038:	00458593          	addi	a1,a1,4
    103c:	fec5e8e3          	bltu	a1,a2,102c <init+0x24>
    1040:	0000d517          	auipc	a0,0xd
    1044:	54850513          	addi	a0,a0,1352 # e588 <logo_enabled>
    1048:	0001c597          	auipc	a1,0x1c
    104c:	a3858593          	addi	a1,a1,-1480 # 1ca80 <_end>
    1050:	00b57863          	bgeu	a0,a1,1060 <init+0x58>
    1054:	00052023          	sw	zero,0(a0)
    1058:	00450513          	addi	a0,a0,4
    105c:	feb56ce3          	bltu	a0,a1,1054 <init+0x4c>
    1060:	448000ef          	jal	14a8 <main>

00001064 <mainDone>:
    1064:	0000006f          	j	1064 <mainDone>

00001068 <_init>:
    1068:	00008067          	ret

Disassembly of section .text:

0000106c <memcmp>:
    106c:	00300793          	li	a5,3
    1070:	02c7fe63          	bgeu	a5,a2,10ac <memcmp+0x40>
    1074:	00a5e7b3          	or	a5,a1,a0
    1078:	0037f793          	andi	a5,a5,3
    107c:	02079463          	bnez	a5,10a4 <memcmp+0x38>
    1080:	00300693          	li	a3,3
    1084:	0140006f          	j	1098 <memcmp+0x2c>
    1088:	ffc60613          	addi	a2,a2,-4
    108c:	00450513          	addi	a0,a0,4
    1090:	00458593          	addi	a1,a1,4
    1094:	00c6fc63          	bgeu	a3,a2,10ac <memcmp+0x40>
    1098:	00052703          	lw	a4,0(a0)
    109c:	0005a783          	lw	a5,0(a1)
    10a0:	fef704e3          	beq	a4,a5,1088 <memcmp+0x1c>
    10a4:	fff60693          	addi	a3,a2,-1
    10a8:	00c0006f          	j	10b4 <memcmp+0x48>
    10ac:	fff60693          	addi	a3,a2,-1
    10b0:	02060863          	beqz	a2,10e0 <memcmp+0x74>
    10b4:	00168693          	addi	a3,a3,1
    10b8:	00d506b3          	add	a3,a0,a3
    10bc:	0080006f          	j	10c4 <memcmp+0x58>
    10c0:	02a68063          	beq	a3,a0,10e0 <memcmp+0x74>
    10c4:	00054783          	lbu	a5,0(a0)
    10c8:	0005c703          	lbu	a4,0(a1)
    10cc:	00150513          	addi	a0,a0,1
    10d0:	00158593          	addi	a1,a1,1
    10d4:	fee786e3          	beq	a5,a4,10c0 <memcmp+0x54>
    10d8:	40e78533          	sub	a0,a5,a4
    10dc:	00008067          	ret
    10e0:	00000513          	li	a0,0
    10e4:	00008067          	ret

000010e8 <strchr>:
    10e8:	0ff5f693          	zext.b	a3,a1
    10ec:	00357793          	andi	a5,a0,3
    10f0:	0c068063          	beqz	a3,11b0 <strchr+0xc8>
    10f4:	00078e63          	beqz	a5,1110 <strchr+0x28>
    10f8:	00054783          	lbu	a5,0(a0)
    10fc:	0a078663          	beqz	a5,11a8 <strchr+0xc0>
    1100:	0ad78663          	beq	a5,a3,11ac <strchr+0xc4>
    1104:	00150513          	addi	a0,a0,1
    1108:	00357793          	andi	a5,a0,3
    110c:	fe0796e3          	bnez	a5,10f8 <strchr+0x10>
    1110:	0ff5f593          	zext.b	a1,a1
    1114:	00859893          	slli	a7,a1,0x8
    1118:	00052703          	lw	a4,0(a0)
    111c:	00b888b3          	add	a7,a7,a1
    1120:	01089793          	slli	a5,a7,0x10
    1124:	00f888b3          	add	a7,a7,a5
    1128:	feff0837          	lui	a6,0xfeff0
    112c:	00e8c633          	xor	a2,a7,a4
    1130:	eff80813          	addi	a6,a6,-257 # fefefeff <__gpu_framebuffer_a+0xfcfefeff>
    1134:	010707b3          	add	a5,a4,a6
    1138:	010605b3          	add	a1,a2,a6
    113c:	fff74713          	not	a4,a4
    1140:	fff64613          	not	a2,a2
    1144:	00e7f7b3          	and	a5,a5,a4
    1148:	80808337          	lui	t1,0x80808
    114c:	00c5f733          	and	a4,a1,a2
    1150:	00e7e7b3          	or	a5,a5,a4
    1154:	08030313          	addi	t1,t1,128 # 80808080 <__gpu_framebuffer_a+0x7e808080>
    1158:	0067f7b3          	and	a5,a5,t1
    115c:	02079a63          	bnez	a5,1190 <strchr+0xa8>
    1160:	00452703          	lw	a4,4(a0)
    1164:	00450513          	addi	a0,a0,4
    1168:	01174633          	xor	a2,a4,a7
    116c:	010707b3          	add	a5,a4,a6
    1170:	010605b3          	add	a1,a2,a6
    1174:	fff74713          	not	a4,a4
    1178:	fff64613          	not	a2,a2
    117c:	00e7f7b3          	and	a5,a5,a4
    1180:	00c5f733          	and	a4,a1,a2
    1184:	00e7e7b3          	or	a5,a5,a4
    1188:	0067f7b3          	and	a5,a5,t1
    118c:	fc078ae3          	beqz	a5,1160 <strchr+0x78>
    1190:	00054783          	lbu	a5,0(a0)
    1194:	00078a63          	beqz	a5,11a8 <strchr+0xc0>
    1198:	08f68663          	beq	a3,a5,1224 <strchr+0x13c>
    119c:	00154783          	lbu	a5,1(a0)
    11a0:	00150513          	addi	a0,a0,1
    11a4:	fe079ae3          	bnez	a5,1198 <strchr+0xb0>
    11a8:	00000513          	li	a0,0
    11ac:	00008067          	ret
    11b0:	00078c63          	beqz	a5,11c8 <strchr+0xe0>
    11b4:	00054783          	lbu	a5,0(a0)
    11b8:	fe078ae3          	beqz	a5,11ac <strchr+0xc4>
    11bc:	00150513          	addi	a0,a0,1
    11c0:	00357793          	andi	a5,a0,3
    11c4:	fe0798e3          	bnez	a5,11b4 <strchr+0xcc>
    11c8:	00052703          	lw	a4,0(a0)
    11cc:	feff0637          	lui	a2,0xfeff0
    11d0:	eff60613          	addi	a2,a2,-257 # fefefeff <__gpu_framebuffer_a+0xfcfefeff>
    11d4:	00c707b3          	add	a5,a4,a2
    11d8:	808086b7          	lui	a3,0x80808
    11dc:	fff74713          	not	a4,a4
    11e0:	00e7f7b3          	and	a5,a5,a4
    11e4:	08068693          	addi	a3,a3,128 # 80808080 <__gpu_framebuffer_a+0x7e808080>
    11e8:	00d7f7b3          	and	a5,a5,a3
    11ec:	02079063          	bnez	a5,120c <strchr+0x124>
    11f0:	00452703          	lw	a4,4(a0)
    11f4:	00450513          	addi	a0,a0,4
    11f8:	00c707b3          	add	a5,a4,a2
    11fc:	fff74713          	not	a4,a4
    1200:	00e7f7b3          	and	a5,a5,a4
    1204:	00d7f7b3          	and	a5,a5,a3
    1208:	fe0784e3          	beqz	a5,11f0 <strchr+0x108>
    120c:	00054783          	lbu	a5,0(a0)
    1210:	f8078ee3          	beqz	a5,11ac <strchr+0xc4>
    1214:	00154783          	lbu	a5,1(a0)
    1218:	00150513          	addi	a0,a0,1
    121c:	fe079ce3          	bnez	a5,1214 <strchr+0x12c>
    1220:	00008067          	ret
    1224:	00008067          	ret

00001228 <memset>:
    1228:	00f00313          	li	t1,15
    122c:	00050713          	mv	a4,a0
    1230:	02c37e63          	bgeu	t1,a2,126c <memset+0x44>
    1234:	00f77793          	andi	a5,a4,15
    1238:	0a079063          	bnez	a5,12d8 <memset+0xb0>
    123c:	08059263          	bnez	a1,12c0 <memset+0x98>
    1240:	ff067693          	andi	a3,a2,-16
    1244:	00f67613          	andi	a2,a2,15
    1248:	00e686b3          	add	a3,a3,a4
    124c:	00b72023          	sw	a1,0(a4)
    1250:	00b72223          	sw	a1,4(a4)
    1254:	00b72423          	sw	a1,8(a4)
    1258:	00b72623          	sw	a1,12(a4)
    125c:	01070713          	addi	a4,a4,16
    1260:	fed766e3          	bltu	a4,a3,124c <memset+0x24>
    1264:	00061463          	bnez	a2,126c <memset+0x44>
    1268:	00008067          	ret
    126c:	40c306b3          	sub	a3,t1,a2
    1270:	00269693          	slli	a3,a3,0x2
    1274:	00000297          	auipc	t0,0x0
    1278:	005686b3          	add	a3,a3,t0
    127c:	00c68067          	jr	12(a3)
    1280:	00b70723          	sb	a1,14(a4)
    1284:	00b706a3          	sb	a1,13(a4)
    1288:	00b70623          	sb	a1,12(a4)
    128c:	00b705a3          	sb	a1,11(a4)
    1290:	00b70523          	sb	a1,10(a4)
    1294:	00b704a3          	sb	a1,9(a4)
    1298:	00b70423          	sb	a1,8(a4)
    129c:	00b703a3          	sb	a1,7(a4)
    12a0:	00b70323          	sb	a1,6(a4)
    12a4:	00b702a3          	sb	a1,5(a4)
    12a8:	00b70223          	sb	a1,4(a4)
    12ac:	00b701a3          	sb	a1,3(a4)
    12b0:	00b70123          	sb	a1,2(a4)
    12b4:	00b700a3          	sb	a1,1(a4)
    12b8:	00b70023          	sb	a1,0(a4)
    12bc:	00008067          	ret
    12c0:	0ff5f593          	zext.b	a1,a1
    12c4:	00859693          	slli	a3,a1,0x8
    12c8:	00d5e5b3          	or	a1,a1,a3
    12cc:	01059693          	slli	a3,a1,0x10
    12d0:	00d5e5b3          	or	a1,a1,a3
    12d4:	f6dff06f          	j	1240 <memset+0x18>
    12d8:	00279693          	slli	a3,a5,0x2
    12dc:	00000297          	auipc	t0,0x0
    12e0:	005686b3          	add	a3,a3,t0
    12e4:	00008293          	mv	t0,ra
    12e8:	fa0680e7          	jalr	-96(a3)
    12ec:	00028093          	mv	ra,t0
    12f0:	ff078793          	addi	a5,a5,-16
    12f4:	40f70733          	sub	a4,a4,a5
    12f8:	00f60633          	add	a2,a2,a5
    12fc:	f6c378e3          	bgeu	t1,a2,126c <memset+0x44>
    1300:	f3dff06f          	j	123c <memset+0x14>

00001304 <memcpy>:
    1304:	00a5c7b3          	xor	a5,a1,a0
    1308:	0037f793          	andi	a5,a5,3
    130c:	00c508b3          	add	a7,a0,a2
    1310:	06079463          	bnez	a5,1378 <memcpy+0x74>
    1314:	00300793          	li	a5,3
    1318:	06c7f063          	bgeu	a5,a2,1378 <memcpy+0x74>
    131c:	00357793          	andi	a5,a0,3
    1320:	00050713          	mv	a4,a0
    1324:	06079a63          	bnez	a5,1398 <memcpy+0x94>
    1328:	ffc8f613          	andi	a2,a7,-4
    132c:	40e606b3          	sub	a3,a2,a4
    1330:	02000793          	li	a5,32
    1334:	08d7ce63          	blt	a5,a3,13d0 <memcpy+0xcc>
    1338:	00058693          	mv	a3,a1
    133c:	00070793          	mv	a5,a4
    1340:	02c77863          	bgeu	a4,a2,1370 <memcpy+0x6c>
    1344:	0006a803          	lw	a6,0(a3)
    1348:	00478793          	addi	a5,a5,4
    134c:	00468693          	addi	a3,a3,4
    1350:	ff07ae23          	sw	a6,-4(a5)
    1354:	fec7e8e3          	bltu	a5,a2,1344 <memcpy+0x40>
    1358:	fff60793          	addi	a5,a2,-1
    135c:	40e787b3          	sub	a5,a5,a4
    1360:	ffc7f793          	andi	a5,a5,-4
    1364:	00478793          	addi	a5,a5,4
    1368:	00f70733          	add	a4,a4,a5
    136c:	00f585b3          	add	a1,a1,a5
    1370:	01176863          	bltu	a4,a7,1380 <memcpy+0x7c>
    1374:	00008067          	ret
    1378:	00050713          	mv	a4,a0
    137c:	05157863          	bgeu	a0,a7,13cc <memcpy+0xc8>
    1380:	0005c783          	lbu	a5,0(a1)
    1384:	00170713          	addi	a4,a4,1
    1388:	00158593          	addi	a1,a1,1
    138c:	fef70fa3          	sb	a5,-1(a4)
    1390:	fee898e3          	bne	a7,a4,1380 <memcpy+0x7c>
    1394:	00008067          	ret
    1398:	0005c683          	lbu	a3,0(a1)
    139c:	00170713          	addi	a4,a4,1
    13a0:	00377793          	andi	a5,a4,3
    13a4:	fed70fa3          	sb	a3,-1(a4)
    13a8:	00158593          	addi	a1,a1,1
    13ac:	f6078ee3          	beqz	a5,1328 <memcpy+0x24>
    13b0:	0005c683          	lbu	a3,0(a1)
    13b4:	00170713          	addi	a4,a4,1
    13b8:	00377793          	andi	a5,a4,3
    13bc:	fed70fa3          	sb	a3,-1(a4)
    13c0:	00158593          	addi	a1,a1,1
    13c4:	fc079ae3          	bnez	a5,1398 <memcpy+0x94>
    13c8:	f61ff06f          	j	1328 <memcpy+0x24>
    13cc:	00008067          	ret
    13d0:	ff010113          	addi	sp,sp,-16
    13d4:	00812623          	sw	s0,12(sp)
    13d8:	02000413          	li	s0,32
    13dc:	0005a383          	lw	t2,0(a1)
    13e0:	0045a283          	lw	t0,4(a1)
    13e4:	0085af83          	lw	t6,8(a1)
    13e8:	00c5af03          	lw	t5,12(a1)
    13ec:	0105ae83          	lw	t4,16(a1)
    13f0:	0145ae03          	lw	t3,20(a1)
    13f4:	0185a303          	lw	t1,24(a1)
    13f8:	01c5a803          	lw	a6,28(a1)
    13fc:	0205a683          	lw	a3,32(a1)
    1400:	02470713          	addi	a4,a4,36
    1404:	40e607b3          	sub	a5,a2,a4
    1408:	fc772e23          	sw	t2,-36(a4)
    140c:	fe572023          	sw	t0,-32(a4)
    1410:	fff72223          	sw	t6,-28(a4)
    1414:	ffe72423          	sw	t5,-24(a4)
    1418:	ffd72623          	sw	t4,-20(a4)
    141c:	ffc72823          	sw	t3,-16(a4)
    1420:	fe672a23          	sw	t1,-12(a4)
    1424:	ff072c23          	sw	a6,-8(a4)
    1428:	fed72e23          	sw	a3,-4(a4)
    142c:	02458593          	addi	a1,a1,36
    1430:	faf446e3          	blt	s0,a5,13dc <memcpy+0xd8>
    1434:	00058693          	mv	a3,a1
    1438:	00070793          	mv	a5,a4
    143c:	02c77863          	bgeu	a4,a2,146c <memcpy+0x168>
    1440:	0006a803          	lw	a6,0(a3)
    1444:	00478793          	addi	a5,a5,4
    1448:	00468693          	addi	a3,a3,4
    144c:	ff07ae23          	sw	a6,-4(a5)
    1450:	fec7e8e3          	bltu	a5,a2,1440 <memcpy+0x13c>
    1454:	fff60793          	addi	a5,a2,-1
    1458:	40e787b3          	sub	a5,a5,a4
    145c:	ffc7f793          	andi	a5,a5,-4
    1460:	00478793          	addi	a5,a5,4
    1464:	00f70733          	add	a4,a4,a5
    1468:	00f585b3          	add	a1,a1,a5
    146c:	01176863          	bltu	a4,a7,147c <memcpy+0x178>
    1470:	00c12403          	lw	s0,12(sp)
    1474:	01010113          	addi	sp,sp,16
    1478:	00008067          	ret
    147c:	0005c783          	lbu	a5,0(a1)
    1480:	00170713          	addi	a4,a4,1
    1484:	00158593          	addi	a1,a1,1
    1488:	fef70fa3          	sb	a5,-1(a4)
    148c:	fee882e3          	beq	a7,a4,1470 <memcpy+0x16c>
    1490:	0005c783          	lbu	a5,0(a1)
    1494:	00170713          	addi	a4,a4,1
    1498:	00158593          	addi	a1,a1,1
    149c:	fef70fa3          	sb	a5,-1(a4)
    14a0:	fce89ee3          	bne	a7,a4,147c <memcpy+0x178>
    14a4:	fcdff06f          	j	1470 <memcpy+0x16c>

000014a8 <main>:
    14a8:	fd010113          	addi	sp,sp,-48
    14ac:	02112623          	sw	ra,44(sp)
    14b0:	02812423          	sw	s0,40(sp)
    14b4:	f80107b7          	lui	a5,0xf8010
    14b8:	06b00713          	li	a4,107
    14bc:	00e7a423          	sw	a4,8(a5) # f8010008 <__gpu_framebuffer_a+0xf6010008>
    14c0:	f80107b7          	lui	a5,0xf8010
    14c4:	00700713          	li	a4,7
    14c8:	00e7a623          	sw	a4,12(a5) # f801000c <__gpu_framebuffer_a+0xf601000c>
    14cc:	f81005b7          	lui	a1,0xf8100
    14d0:	00810513          	addi	a0,sp,8
    14d4:	4f8000ef          	jal	19cc <gpu_init>
    14d8:	02050463          	beqz	a0,1500 <main+0x58>
    14dc:	00050593          	mv	a1,a0
    14e0:	0000d537          	lui	a0,0xd
    14e4:	30850513          	addi	a0,a0,776 # d308 <_data+0x74>
    14e8:	110000ef          	jal	15f8 <bsp_printf>
    14ec:	00100513          	li	a0,1
    14f0:	02c12083          	lw	ra,44(sp)
    14f4:	02812403          	lw	s0,40(sp)
    14f8:	03010113          	addi	sp,sp,48
    14fc:	00008067          	ret
    1500:	328000ef          	jal	1828 <gpu_platform_cycles>
    1504:	00050593          	mv	a1,a0
    1508:	00051463          	bnez	a0,1510 <main+0x68>
    150c:	00100593          	li	a1,1
    1510:	f8100537          	lui	a0,0xf8100
    1514:	3c1050ef          	jal	70d4 <bullet_prepare_assets>
    1518:	00050413          	mv	s0,a0
    151c:	0000e537          	lui	a0,0xe
    1520:	00700613          	li	a2,7
    1524:	02000593          	li	a1,32
    1528:	69450513          	addi	a0,a0,1684 # e694 <bullets>
    152c:	735030ef          	jal	5460 <bullet_reset>
    1530:	fa051ee3          	bnez	a0,14ec <main+0x44>
    1534:	318000ef          	jal	184c <gpu_platform_sync>
    1538:	00989637          	lui	a2,0x989
    153c:	68060613          	addi	a2,a2,1664 # 989680 <__freertos_irq_stack_top+0x96bc00>
    1540:	00040593          	mv	a1,s0
    1544:	00810513          	addi	a0,sp,8
    1548:	3b5050ef          	jal	70fc <bullet_prepare_texture_cache>
    154c:	00050593          	mv	a1,a0
    1550:	02c00637          	lui	a2,0x2c00
    1554:	00041463          	bnez	s0,155c <main+0xb4>
    1558:	02a00637          	lui	a2,0x2a00
    155c:	00143413          	seqz	s0,s0
    1560:	000016b7          	lui	a3,0x1
    1564:	0000d537          	lui	a0,0xd
    1568:	00040713          	mv	a4,s0
    156c:	c2068693          	addi	a3,a3,-992 # c20 <CUSTOM2+0xbc5>
    1570:	32050513          	addi	a0,a0,800 # d320 <_data+0x8c>
    1574:	084000ef          	jal	15f8 <bsp_printf>
    1578:	00010513          	mv	a0,sp
    157c:	78c010ef          	jal	2d08 <framebuffer_init>
    1580:	2cc020ef          	jal	384c <hud_init_glyph_atlas>
    1584:	2c8000ef          	jal	184c <gpu_platform_sync>
    1588:	f81007b7          	lui	a5,0xf8100
    158c:	3007a703          	lw	a4,768(a5) # f8100300 <__gpu_framebuffer_a+0xf6100300>
    1590:	4d4757b7          	lui	a5,0x4d475
    1594:	43178793          	addi	a5,a5,1073 # 4d475431 <__gpu_framebuffer_a+0x4b475431>
    1598:	02f71663          	bne	a4,a5,15c4 <main+0x11c>
    159c:	0000e7b7          	lui	a5,0xe
    15a0:	000136b7          	lui	a3,0x13
    15a4:	58c78793          	addi	a5,a5,1420 # e58c <hud_cache>
    15a8:	02d80737          	lui	a4,0x2d80
    15ac:	6c068693          	addi	a3,a3,1728 # 136c0 <scene>
    15b0:	00040613          	mv	a2,s0
    15b4:	00010593          	mv	a1,sp
    15b8:	00810513          	addi	a0,sp,8
    15bc:	4ec080ef          	jal	9aa8 <v3_demo_run>
    15c0:	f31ff06f          	j	14f0 <main+0x48>
    15c4:	0000d537          	lui	a0,0xd
    15c8:	35850513          	addi	a0,a0,856 # d358 <_data+0xc4>
    15cc:	02c000ef          	jal	15f8 <bsp_printf>
    15d0:	f1dff06f          	j	14ec <main+0x44>

000015d4 <_putchar>:
    15d4:	f80107b7          	lui	a5,0xf8010
    15d8:	00478793          	addi	a5,a5,4 # f8010004 <__gpu_framebuffer_a+0xf6010004>
    15dc:	0007a703          	lw	a4,0(a5)
    15e0:	01075693          	srli	a3,a4,0x10
    15e4:	0ff6f693          	zext.b	a3,a3
    15e8:	fe068ae3          	beqz	a3,15dc <_putchar+0x8>
    15ec:	f80107b7          	lui	a5,0xf8010
    15f0:	00a7a023          	sw	a0,0(a5) # f8010000 <__gpu_framebuffer_a+0xf6010000>
    15f4:	00008067          	ret

000015f8 <bsp_printf>:
    15f8:	f8010113          	addi	sp,sp,-128
    15fc:	06f12a23          	sw	a5,116(sp)
    1600:	06410793          	addi	a5,sp,100
    1604:	05212823          	sw	s2,80(sp)
    1608:	05312623          	sw	s3,76(sp)
    160c:	05412423          	sw	s4,72(sp)
    1610:	05512223          	sw	s5,68(sp)
    1614:	05612023          	sw	s6,64(sp)
    1618:	03712e23          	sw	s7,60(sp)
    161c:	04112e23          	sw	ra,92(sp)
    1620:	04812c23          	sw	s0,88(sp)
    1624:	04912a23          	sw	s1,84(sp)
    1628:	03812c23          	sw	s8,56(sp)
    162c:	03912a23          	sw	s9,52(sp)
    1630:	00050993          	mv	s3,a0
    1634:	06b12223          	sw	a1,100(sp)
    1638:	06c12423          	sw	a2,104(sp)
    163c:	06d12623          	sw	a3,108(sp)
    1640:	06e12823          	sw	a4,112(sp)
    1644:	07012c23          	sw	a6,120(sp)
    1648:	07112e23          	sw	a7,124(sp)
    164c:	00f12623          	sw	a5,12(sp)
    1650:	00000913          	li	s2,0
    1654:	02500a13          	li	s4,37
    1658:	06600a93          	li	s5,102
    165c:	06600b13          	li	s6,102
    1660:	06300b93          	li	s7,99
    1664:	012987b3          	add	a5,s3,s2
    1668:	0007c503          	lbu	a0,0(a5)
    166c:	02051c63          	bnez	a0,16a4 <bsp_printf+0xac>
    1670:	05c12083          	lw	ra,92(sp)
    1674:	05812403          	lw	s0,88(sp)
    1678:	05412483          	lw	s1,84(sp)
    167c:	05012903          	lw	s2,80(sp)
    1680:	04c12983          	lw	s3,76(sp)
    1684:	04812a03          	lw	s4,72(sp)
    1688:	04412a83          	lw	s5,68(sp)
    168c:	04012b03          	lw	s6,64(sp)
    1690:	03c12b83          	lw	s7,60(sp)
    1694:	03812c03          	lw	s8,56(sp)
    1698:	03412c83          	lw	s9,52(sp)
    169c:	08010113          	addi	sp,sp,128
    16a0:	00008067          	ret
    16a4:	0d451863          	bne	a0,s4,1774 <bsp_printf+0x17c>
    16a8:	00190913          	addi	s2,s2,1
    16ac:	012987b3          	add	a5,s3,s2
    16b0:	0007c783          	lbu	a5,0(a5)
    16b4:	0e078063          	beqz	a5,1794 <bsp_printf+0x19c>
    16b8:	17578263          	beq	a5,s5,181c <bsp_printf+0x224>
    16bc:	04fb6c63          	bltu	s6,a5,1714 <bsp_printf+0x11c>
    16c0:	0b778263          	beq	a5,s7,1764 <bsp_printf+0x16c>
    16c4:	06400713          	li	a4,100
    16c8:	0ee78063          	beq	a5,a4,17a8 <bsp_printf+0x1b0>
    16cc:	05800713          	li	a4,88
    16d0:	fce79ce3          	bne	a5,a4,16a8 <bsp_printf+0xb0>
    16d4:	00c12783          	lw	a5,12(sp)
    16d8:	0000d4b7          	lui	s1,0xd
    16dc:	01c00413          	li	s0,28
    16e0:	0007ac83          	lw	s9,0(a5)
    16e4:	00478713          	addi	a4,a5,4
    16e8:	00e12623          	sw	a4,12(sp)
    16ec:	2e048493          	addi	s1,s1,736 # d2e0 <_data+0x4c>
    16f0:	ffc00c13          	li	s8,-4
    16f4:	008cd7b3          	srl	a5,s9,s0
    16f8:	00f7f793          	andi	a5,a5,15
    16fc:	00f487b3          	add	a5,s1,a5
    1700:	0007c503          	lbu	a0,0(a5)
    1704:	ffc40413          	addi	s0,s0,-4
    1708:	ecdff0ef          	jal	15d4 <_putchar>
    170c:	ff8414e3          	bne	s0,s8,16f4 <bsp_printf+0xfc>
    1710:	0840006f          	j	1794 <bsp_printf+0x19c>
    1714:	07300713          	li	a4,115
    1718:	06e78263          	beq	a5,a4,177c <bsp_printf+0x184>
    171c:	07800713          	li	a4,120
    1720:	f8e794e3          	bne	a5,a4,16a8 <bsp_printf+0xb0>
    1724:	00c12783          	lw	a5,12(sp)
    1728:	0000d4b7          	lui	s1,0xd
    172c:	01c00413          	li	s0,28
    1730:	0007ac83          	lw	s9,0(a5)
    1734:	00478713          	addi	a4,a5,4
    1738:	00e12623          	sw	a4,12(sp)
    173c:	2f448493          	addi	s1,s1,756 # d2f4 <_data+0x60>
    1740:	ffc00c13          	li	s8,-4
    1744:	008cd7b3          	srl	a5,s9,s0
    1748:	00f7f793          	andi	a5,a5,15
    174c:	00f487b3          	add	a5,s1,a5
    1750:	0007c503          	lbu	a0,0(a5)
    1754:	ffc40413          	addi	s0,s0,-4
    1758:	e7dff0ef          	jal	15d4 <_putchar>
    175c:	ff8414e3          	bne	s0,s8,1744 <bsp_printf+0x14c>
    1760:	0340006f          	j	1794 <bsp_printf+0x19c>
    1764:	00c12783          	lw	a5,12(sp)
    1768:	0007c503          	lbu	a0,0(a5)
    176c:	00478713          	addi	a4,a5,4
    1770:	00e12623          	sw	a4,12(sp)
    1774:	e61ff0ef          	jal	15d4 <_putchar>
    1778:	01c0006f          	j	1794 <bsp_printf+0x19c>
    177c:	00c12783          	lw	a5,12(sp)
    1780:	0007a403          	lw	s0,0(a5)
    1784:	00478713          	addi	a4,a5,4
    1788:	00e12623          	sw	a4,12(sp)
    178c:	00044503          	lbu	a0,0(s0)
    1790:	00051663          	bnez	a0,179c <bsp_printf+0x1a4>
    1794:	00190913          	addi	s2,s2,1
    1798:	ecdff06f          	j	1664 <bsp_printf+0x6c>
    179c:	00140413          	addi	s0,s0,1
    17a0:	e35ff0ef          	jal	15d4 <_putchar>
    17a4:	fe9ff06f          	j	178c <bsp_printf+0x194>
    17a8:	00c12783          	lw	a5,12(sp)
    17ac:	0007a483          	lw	s1,0(a5)
    17b0:	00478713          	addi	a4,a5,4
    17b4:	00e12623          	sw	a4,12(sp)
    17b8:	0004d863          	bgez	s1,17c8 <bsp_printf+0x1d0>
    17bc:	02d00513          	li	a0,45
    17c0:	e15ff0ef          	jal	15d4 <_putchar>
    17c4:	409004b3          	neg	s1,s1
    17c8:	01010413          	addi	s0,sp,16
    17cc:	00040c13          	mv	s8,s0
    17d0:	00a00713          	li	a4,10
    17d4:	00049e63          	bnez	s1,17f0 <bsp_printf+0x1f8>
    17d8:	01840c63          	beq	s0,s8,17f0 <bsp_printf+0x1f8>
    17dc:	fff44503          	lbu	a0,-1(s0)
    17e0:	fff40413          	addi	s0,s0,-1
    17e4:	df1ff0ef          	jal	15d4 <_putchar>
    17e8:	ff841ae3          	bne	s0,s8,17dc <bsp_printf+0x1e4>
    17ec:	fa9ff06f          	j	1794 <bsp_printf+0x19c>
    17f0:	02e4e7b3          	rem	a5,s1,a4
    17f4:	00140413          	addi	s0,s0,1
    17f8:	03078793          	addi	a5,a5,48
    17fc:	02e4c4b3          	div	s1,s1,a4
    1800:	fef40fa3          	sb	a5,-1(s0)
    1804:	fd1ff06f          	j	17d4 <bsp_printf+0x1dc>
    1808:	00140413          	addi	s0,s0,1
    180c:	dc9ff0ef          	jal	15d4 <_putchar>
    1810:	00044503          	lbu	a0,0(s0)
    1814:	fe051ae3          	bnez	a0,1808 <bsp_printf+0x210>
    1818:	f7dff06f          	j	1794 <bsp_printf+0x19c>
    181c:	0000d437          	lui	s0,0xd
    1820:	29440413          	addi	s0,s0,660 # d294 <_data>
    1824:	fedff06f          	j	1810 <bsp_printf+0x218>

00001828 <gpu_platform_cycles>:
    1828:	f8b0c7b7          	lui	a5,0xf8b0c
    182c:	f8b0c737          	lui	a4,0xf8b0c
    1830:	ffc78793          	addi	a5,a5,-4 # f8b0bffc <__gpu_framebuffer_a+0xf6b0bffc>
    1834:	ff870713          	addi	a4,a4,-8 # f8b0bff8 <__gpu_framebuffer_a+0xf6b0bff8>
    1838:	0007a583          	lw	a1,0(a5)
    183c:	00072503          	lw	a0,0(a4)
    1840:	0007a683          	lw	a3,0(a5)
    1844:	fed59ae3          	bne	a1,a3,1838 <gpu_platform_cycles+0x10>
    1848:	00008067          	ret

0000184c <gpu_platform_sync>:
    184c:	0ff0000f          	fence
    1850:	0000500f          	.word	0x0000500f
    1854:	0ff0000f          	fence
    1858:	00008067          	ret

0000185c <refresh>:
    185c:	00052703          	lw	a4,0(a0)
    1860:	00050793          	mv	a5,a0
    1864:	00300513          	li	a0,3
    1868:	03470813          	addi	a6,a4,52
    186c:	03870713          	addi	a4,a4,56
    1870:	00082583          	lw	a1,0(a6)
    1874:	00072603          	lw	a2,0(a4)
    1878:	00082683          	lw	a3,0(a6)
    187c:	01059593          	slli	a1,a1,0x10
    1880:	0105d593          	srli	a1,a1,0x10
    1884:	01069693          	slli	a3,a3,0x10
    1888:	0106d693          	srli	a3,a3,0x10
    188c:	02d59c63          	bne	a1,a3,18c4 <refresh+0x68>
    1890:	00c7d683          	lhu	a3,12(a5)
    1894:	0ff67613          	zext.b	a2,a2
    1898:	40d586b3          	sub	a3,a1,a3
    189c:	01069693          	slli	a3,a3,0x10
    18a0:	0106d693          	srli	a3,a3,0x10
    18a4:	04068863          	beqz	a3,18f4 <refresh+0x98>
    18a8:	0127c703          	lbu	a4,18(a5)
    18ac:	ffa00513          	li	a0,-6
    18b0:	02d76063          	bltu	a4,a3,18d0 <refresh+0x74>
    18b4:	00c789a3          	sb	a2,19(a5)
    18b8:	00060e63          	beqz	a2,18d4 <refresh+0x78>
    18bc:	ff900513          	li	a0,-7
    18c0:	00008067          	ret
    18c4:	fff50513          	addi	a0,a0,-1
    18c8:	fa0514e3          	bnez	a0,1870 <refresh+0x14>
    18cc:	ffa00513          	li	a0,-6
    18d0:	00008067          	ret
    18d4:	40d70733          	sub	a4,a4,a3
    18d8:	0ff77713          	zext.b	a4,a4
    18dc:	00e78923          	sb	a4,18(a5)
    18e0:	00e03733          	snez	a4,a4
    18e4:	00b79623          	sh	a1,12(a5)
    18e8:	00e788a3          	sb	a4,17(a5)
    18ec:	00000513          	li	a0,0
    18f0:	00008067          	ret
    18f4:	00c789a3          	sb	a2,19(a5)
    18f8:	fe060ae3          	beqz	a2,18ec <refresh+0x90>
    18fc:	fc1ff06f          	j	18bc <refresh+0x60>

00001900 <texture_cache_idle>:
    1900:	00050793          	mv	a5,a0
    1904:	04050263          	beqz	a0,1948 <texture_cache_idle+0x48>
    1908:	01054703          	lbu	a4,16(a0)
    190c:	ff800513          	li	a0,-8
    1910:	02070e63          	beqz	a4,194c <texture_cache_idle+0x4c>
    1914:	0127c703          	lbu	a4,18(a5)
    1918:	ffd00513          	li	a0,-3
    191c:	02071863          	bnez	a4,194c <texture_cache_idle+0x4c>
    1920:	0007a703          	lw	a4,0(a5)
    1924:	02000693          	li	a3,32
    1928:	00872783          	lw	a5,8(a4)
    192c:	0a07f793          	andi	a5,a5,160
    1930:	00d79e63          	bne	a5,a3,194c <texture_cache_idle+0x4c>
    1934:	09c72783          	lw	a5,156(a4)
    1938:	0027f793          	andi	a5,a5,2
    193c:	00079863          	bnez	a5,194c <texture_cache_idle+0x4c>
    1940:	00000513          	li	a0,0
    1944:	00008067          	ret
    1948:	ff800513          	li	a0,-8
    194c:	00008067          	ret

00001950 <surface>:
    1950:	00050713          	mv	a4,a0
    1954:	00200513          	li	a0,2
    1958:	06060463          	beqz	a2,19c0 <surface+0x70>
    195c:	06068663          	beqz	a3,19c8 <surface+0x78>
    1960:	00b767b3          	or	a5,a4,a1
    1964:	0017f793          	andi	a5,a5,1
    1968:	00300513          	li	a0,3
    196c:	04079e63          	bnez	a5,19c8 <surface+0x78>
    1970:	00161613          	slli	a2,a2,0x1
    1974:	00400513          	li	a0,4
    1978:	04c5e863          	bltu	a1,a2,19c8 <surface+0x78>
    197c:	fff68693          	addi	a3,a3,-1
    1980:	02b687b3          	mul	a5,a3,a1
    1984:	00500513          	li	a0,5
    1988:	02b6b6b3          	mulhu	a3,a3,a1
    198c:	00c78633          	add	a2,a5,a2
    1990:	00f637b3          	sltu	a5,a2,a5
    1994:	00d787b3          	add	a5,a5,a3
    1998:	00e606b3          	add	a3,a2,a4
    199c:	00c6b633          	sltu	a2,a3,a2
    19a0:	00f60633          	add	a2,a2,a5
    19a4:	020007b7          	lui	a5,0x2000
    19a8:	02f76063          	bltu	a4,a5,19c8 <surface+0x78>
    19ac:	00061c63          	bnez	a2,19c4 <surface+0x74>
    19b0:	100007b7          	lui	a5,0x10000
    19b4:	00d7e863          	bltu	a5,a3,19c4 <surface+0x74>
    19b8:	00000513          	li	a0,0
    19bc:	00008067          	ret
    19c0:	00008067          	ret
    19c4:	00500513          	li	a0,5
    19c8:	00008067          	ret

000019cc <gpu_init>:
    19cc:	0a050463          	beqz	a0,1a74 <gpu_init+0xa8>
    19d0:	ff010113          	addi	sp,sp,-16
    19d4:	00912223          	sw	s1,4(sp)
    19d8:	00112623          	sw	ra,12(sp)
    19dc:	00812423          	sw	s0,8(sp)
    19e0:	0035f713          	andi	a4,a1,3
    19e4:	00058493          	mv	s1,a1
    19e8:	ff800793          	li	a5,-8
    19ec:	06071863          	bnez	a4,1a5c <gpu_init+0x90>
    19f0:	01800613          	li	a2,24
    19f4:	00000593          	li	a1,0
    19f8:	00050413          	mv	s0,a0
    19fc:	82dff0ef          	jal	1228 <memset>
    1a00:	0004a683          	lw	a3,0(s1)
    1a04:	32444737          	lui	a4,0x32444
    1a08:	00942023          	sw	s1,0(s0)
    1a0c:	75070713          	addi	a4,a4,1872 # 32444750 <__gpu_framebuffer_a+0x30444750>
    1a10:	fff00793          	li	a5,-1
    1a14:	04e69463          	bne	a3,a4,1a5c <gpu_init+0x90>
    1a18:	0044a683          	lw	a3,4(s1)
    1a1c:	00010737          	lui	a4,0x10
    1a20:	10070713          	addi	a4,a4,256 # 10100 <__global_pointer$+0x1398>
    1a24:	ffe00793          	li	a5,-2
    1a28:	02e69a63          	bne	a3,a4,1a5c <gpu_init+0x90>
    1a2c:	0344a783          	lw	a5,52(s1)
    1a30:	01079793          	slli	a5,a5,0x10
    1a34:	0107d793          	srli	a5,a5,0x10
    1a38:	00f41623          	sh	a5,12(s0)
    1a3c:	00178793          	addi	a5,a5,1 # 10000001 <__gpu_framebuffer_a+0xe000001>
    1a40:	01079793          	slli	a5,a5,0x10
    1a44:	0107d793          	srli	a5,a5,0x10
    1a48:	00f41523          	sh	a5,10(s0)
    1a4c:	00f41423          	sh	a5,8(s0)
    1a50:	00100793          	li	a5,1
    1a54:	00f40823          	sb	a5,16(s0)
    1a58:	00000793          	li	a5,0
    1a5c:	00c12083          	lw	ra,12(sp)
    1a60:	00812403          	lw	s0,8(sp)
    1a64:	00412483          	lw	s1,4(sp)
    1a68:	00078513          	mv	a0,a5
    1a6c:	01010113          	addi	sp,sp,16
    1a70:	00008067          	ret
    1a74:	ff800793          	li	a5,-8
    1a78:	00078513          	mv	a0,a5
    1a7c:	00008067          	ret

00001a80 <gpu_try_submit>:
    1a80:	04051663          	bnez	a0,1acc <gpu_try_submit+0x4c>
    1a84:	ff800513          	li	a0,-8
    1a88:	00008067          	ret
    1a8c:	ff800513          	li	a0,-8
    1a90:	03c12083          	lw	ra,60(sp)
    1a94:	03812403          	lw	s0,56(sp)
    1a98:	03412483          	lw	s1,52(sp)
    1a9c:	03012903          	lw	s2,48(sp)
    1aa0:	02c12983          	lw	s3,44(sp)
    1aa4:	02812a03          	lw	s4,40(sp)
    1aa8:	02412a83          	lw	s5,36(sp)
    1aac:	02012b03          	lw	s6,32(sp)
    1ab0:	01c12b83          	lw	s7,28(sp)
    1ab4:	01812c03          	lw	s8,24(sp)
    1ab8:	01412c83          	lw	s9,20(sp)
    1abc:	01012d03          	lw	s10,16(sp)
    1ac0:	00c12d83          	lw	s11,12(sp)
    1ac4:	04010113          	addi	sp,sp,64
    1ac8:	00008067          	ret
    1acc:	fc010113          	addi	sp,sp,-64
    1ad0:	02912a23          	sw	s1,52(sp)
    1ad4:	02112e23          	sw	ra,60(sp)
    1ad8:	02812c23          	sw	s0,56(sp)
    1adc:	03212823          	sw	s2,48(sp)
    1ae0:	03312623          	sw	s3,44(sp)
    1ae4:	03412423          	sw	s4,40(sp)
    1ae8:	03512223          	sw	s5,36(sp)
    1aec:	03612023          	sw	s6,32(sp)
    1af0:	01712e23          	sw	s7,28(sp)
    1af4:	01812c23          	sw	s8,24(sp)
    1af8:	01912a23          	sw	s9,20(sp)
    1afc:	01a12823          	sw	s10,16(sp)
    1b00:	01b12623          	sw	s11,12(sp)
    1b04:	01054783          	lbu	a5,16(a0)
    1b08:	00050493          	mv	s1,a0
    1b0c:	f80780e3          	beqz	a5,1a8c <gpu_try_submit+0xc>
    1b10:	00060a13          	mv	s4,a2
    1b14:	f6060ce3          	beqz	a2,1a8c <gpu_try_submit+0xc>
    1b18:	00058413          	mv	s0,a1
    1b1c:	f60588e3          	beqz	a1,1a8c <gpu_try_submit+0xc>
    1b20:	01c5ca83          	lbu	s5,28(a1) # f810001c <__gpu_framebuffer_a+0xf610001c>
    1b24:	00700793          	li	a5,7
    1b28:	20fa9e63          	bne	s5,a5,1d44 <gpu_try_submit+0x2c4>
    1b2c:	0105dc83          	lhu	s9,16(a1)
    1b30:	00200513          	li	a0,2
    1b34:	f40c8ee3          	beqz	s9,1a90 <gpu_try_submit+0x10>
    1b38:	0125d983          	lhu	s3,18(a1)
    1b3c:	f4098ae3          	beqz	s3,1a90 <gpu_try_submit+0x10>
    1b40:	0145db83          	lhu	s7,20(a1)
    1b44:	f40b86e3          	beqz	s7,1a90 <gpu_try_submit+0x10>
    1b48:	01a5d903          	lhu	s2,26(a1)
    1b4c:	f40902e3          	beqz	s2,1a90 <gpu_try_submit+0x10>
    1b50:	0185d783          	lhu	a5,24(a1)
    1b54:	00a00513          	li	a0,10
    1b58:	fcc7f793          	andi	a5,a5,-52
    1b5c:	f2079ae3          	bnez	a5,1a90 <gpu_try_submit+0x10>
    1b60:	0005ab03          	lw	s6,0(a1)
    1b64:	0085ac03          	lw	s8,8(a1)
    1b68:	00090693          	mv	a3,s2
    1b6c:	000b8613          	mv	a2,s7
    1b70:	000c0593          	mv	a1,s8
    1b74:	000b0513          	mv	a0,s6
    1b78:	dd9ff0ef          	jal	1950 <surface>
    1b7c:	f0051ae3          	bnez	a0,1a90 <gpu_try_submit+0x10>
    1b80:	00442d03          	lw	s10,4(s0)
    1b84:	00c42d83          	lw	s11,12(s0)
    1b88:	00098693          	mv	a3,s3
    1b8c:	000c8613          	mv	a2,s9
    1b90:	000d8593          	mv	a1,s11
    1b94:	000d0513          	mv	a0,s10
    1b98:	db9ff0ef          	jal	1950 <surface>
    1b9c:	ee051ae3          	bnez	a0,1a90 <gpu_try_submit+0x10>
    1ba0:	fff98993          	addi	s3,s3,-1
    1ba4:	03b987b3          	mul	a5,s3,s11
    1ba8:	001c9c93          	slli	s9,s9,0x1
    1bac:	01ac8733          	add	a4,s9,s10
    1bb0:	01973cb3          	sltu	s9,a4,s9
    1bb4:	03b9b9b3          	mulhu	s3,s3,s11
    1bb8:	00e78733          	add	a4,a5,a4
    1bbc:	00f737b3          	sltu	a5,a4,a5
    1bc0:	019989b3          	add	s3,s3,s9
    1bc4:	013787b3          	add	a5,a5,s3
    1bc8:	00079463          	bnez	a5,1bd0 <gpu_try_submit+0x150>
    1bcc:	02eb7a63          	bgeu	s6,a4,1c00 <gpu_try_submit+0x180>
    1bd0:	fff90913          	addi	s2,s2,-1
    1bd4:	038907b3          	mul	a5,s2,s8
    1bd8:	001b9b93          	slli	s7,s7,0x1
    1bdc:	016b8b33          	add	s6,s7,s6
    1be0:	017b3bb3          	sltu	s7,s6,s7
    1be4:	03893933          	mulhu	s2,s2,s8
    1be8:	01678b33          	add	s6,a5,s6
    1bec:	00fb37b3          	sltu	a5,s6,a5
    1bf0:	01790933          	add	s2,s2,s7
    1bf4:	012787b3          	add	a5,a5,s2
    1bf8:	28079463          	bnez	a5,1e80 <gpu_try_submit+0x400>
    1bfc:	296d6263          	bltu	s10,s6,1e80 <gpu_try_submit+0x400>
    1c00:	0004a783          	lw	a5,0(s1)
    1c04:	ff900513          	li	a0,-7
    1c08:	0387a703          	lw	a4,56(a5)
    1c0c:	0ff77713          	zext.b	a4,a4
    1c10:	00e489a3          	sb	a4,19(s1)
    1c14:	e6071ee3          	bnez	a4,1a90 <gpu_try_submit+0x10>
    1c18:	0087a703          	lw	a4,8(a5)
    1c1c:	00700693          	li	a3,7
    1c20:	02da9063          	bne	s5,a3,1c40 <gpu_try_submit+0x1c0>
    1c24:	00e71693          	slli	a3,a4,0xe
    1c28:	e606d2e3          	bgez	a3,1a8c <gpu_try_submit+0xc>
    1c2c:	01845683          	lhu	a3,24(s0)
    1c30:	0206f693          	andi	a3,a3,32
    1c34:	00068663          	beqz	a3,1c40 <gpu_try_submit+0x1c0>
    1c38:	00d71693          	slli	a3,a4,0xd
    1c3c:	e406d8e3          	bgez	a3,1a8c <gpu_try_submit+0xc>
    1c40:	0144c603          	lbu	a2,20(s1)
    1c44:	01f77693          	andi	a3,a4,31
    1c48:	00d67463          	bgeu	a2,a3,1c50 <gpu_try_submit+0x1d0>
    1c4c:	00d48a23          	sb	a3,20(s1)
    1c50:	04077713          	andi	a4,a4,64
    1c54:	ffc00513          	li	a0,-4
    1c58:	e2071ce3          	bnez	a4,1a90 <gpu_try_submit+0x10>
    1c5c:	0124c683          	lbu	a3,18(s1)
    1c60:	00f00713          	li	a4,15
    1c64:	e2d766e3          	bltu	a4,a3,1a90 <gpu_try_submit+0x10>
    1c68:	00a4d683          	lhu	a3,10(s1)
    1c6c:	00000613          	li	a2,0
    1c70:	00168713          	addi	a4,a3,1
    1c74:	00e49523          	sh	a4,10(s1)
    1c78:	0157a823          	sw	s5,16(a5)
    1c7c:	00042703          	lw	a4,0(s0)
    1c80:	00e7aa23          	sw	a4,20(a5)
    1c84:	00442703          	lw	a4,4(s0)
    1c88:	00e7ac23          	sw	a4,24(a5)
    1c8c:	01042703          	lw	a4,16(s0)
    1c90:	00e7ae23          	sw	a4,28(a5)
    1c94:	00842703          	lw	a4,8(s0)
    1c98:	02e7a023          	sw	a4,32(a5)
    1c9c:	00c42703          	lw	a4,12(s0)
    1ca0:	02e7a223          	sw	a4,36(a5)
    1ca4:	00700713          	li	a4,7
    1ca8:	00ea8463          	beq	s5,a4,1cb0 <gpu_try_submit+0x230>
    1cac:	01445603          	lhu	a2,20(s0)
    1cb0:	01645703          	lhu	a4,22(s0)
    1cb4:	01071713          	slli	a4,a4,0x10
    1cb8:	00c76733          	or	a4,a4,a2
    1cbc:	02e7a423          	sw	a4,40(a5)
    1cc0:	01845703          	lhu	a4,24(s0)
    1cc4:	01d44603          	lbu	a2,29(s0)
    1cc8:	01071713          	slli	a4,a4,0x10
    1ccc:	00c76733          	or	a4,a4,a2
    1cd0:	02e7a623          	sw	a4,44(a5)
    1cd4:	00700713          	li	a4,7
    1cd8:	00ea9c63          	bne	s5,a4,1cf0 <gpu_try_submit+0x270>
    1cdc:	01a45703          	lhu	a4,26(s0)
    1ce0:	01445603          	lhu	a2,20(s0)
    1ce4:	01071713          	slli	a4,a4,0x10
    1ce8:	00c76733          	or	a4,a4,a2
    1cec:	0ae7a423          	sw	a4,168(a5)
    1cf0:	02d7a823          	sw	a3,48(a5)
    1cf4:	0ff0000f          	fence
    1cf8:	0004a783          	lw	a5,0(s1)
    1cfc:	00100713          	li	a4,1
    1d00:	00e7a623          	sw	a4,12(a5)
    1d04:	0ff0000f          	fence
    1d08:	0044a783          	lw	a5,4(s1)
    1d0c:	00e488a3          	sb	a4,17(s1)
    1d10:	0144c703          	lbu	a4,20(s1)
    1d14:	00178793          	addi	a5,a5,1
    1d18:	00f4a223          	sw	a5,4(s1)
    1d1c:	0124c783          	lbu	a5,18(s1)
    1d20:	00d49723          	sh	a3,14(s1)
    1d24:	00178793          	addi	a5,a5,1
    1d28:	0ff7f793          	zext.b	a5,a5
    1d2c:	00f48923          	sb	a5,18(s1)
    1d30:	00f77463          	bgeu	a4,a5,1d38 <gpu_try_submit+0x2b8>
    1d34:	00f48a23          	sb	a5,20(s1)
    1d38:	00da1023          	sh	a3,0(s4)
    1d3c:	00000513          	li	a0,0
    1d40:	d51ff06f          	j	1a90 <gpu_try_submit+0x10>
    1d44:	0185d783          	lhu	a5,24(a1)
    1d48:	d40792e3          	bnez	a5,1a8c <gpu_try_submit+0xc>
    1d4c:	00100793          	li	a5,1
    1d50:	02fa9063          	bne	s5,a5,1d70 <gpu_try_submit+0x2f0>
    1d54:	01245683          	lhu	a3,18(s0)
    1d58:	01045603          	lhu	a2,16(s0)
    1d5c:	00c42583          	lw	a1,12(s0)
    1d60:	00442503          	lw	a0,4(s0)
    1d64:	bedff0ef          	jal	1950 <surface>
    1d68:	e8050ce3          	beqz	a0,1c00 <gpu_try_submit+0x180>
    1d6c:	d25ff06f          	j	1a90 <gpu_try_submit+0x10>
    1d70:	00600793          	li	a5,6
    1d74:	02fa9263          	bne	s5,a5,1d98 <gpu_try_submit+0x318>
    1d78:	0045a783          	lw	a5,4(a1)
    1d7c:	ffe00737          	lui	a4,0xffe00
    1d80:	fff70713          	addi	a4,a4,-1 # ffdfffff <__gpu_framebuffer_a+0xfddfffff>
    1d84:	00e7f7b3          	and	a5,a5,a4
    1d88:	02000737          	lui	a4,0x2000
    1d8c:	00500513          	li	a0,5
    1d90:	d0e790e3          	bne	a5,a4,1a90 <gpu_try_submit+0x10>
    1d94:	e6dff06f          	j	1c00 <gpu_try_submit+0x180>
    1d98:	00500793          	li	a5,5
    1d9c:	02fa9863          	bne	s5,a5,1dcc <gpu_try_submit+0x34c>
    1da0:	0005a783          	lw	a5,0(a1)
    1da4:	00300513          	li	a0,3
    1da8:	0037f713          	andi	a4,a5,3
    1dac:	ce0712e3          	bnez	a4,1a90 <gpu_try_submit+0x10>
    1db0:	fe000737          	lui	a4,0xfe000
    1db4:	00e787b3          	add	a5,a5,a4
    1db8:	0e000737          	lui	a4,0xe000
    1dbc:	ffc70713          	addi	a4,a4,-4 # dfffffc <__gpu_framebuffer_a+0xbfffffc>
    1dc0:	00500513          	li	a0,5
    1dc4:	f8f778e3          	bgeu	a4,a5,1d54 <gpu_try_submit+0x2d4>
    1dc8:	cc9ff06f          	j	1a90 <gpu_try_submit+0x10>
    1dcc:	ffea8793          	addi	a5,s5,-2
    1dd0:	0ff7f793          	zext.b	a5,a5
    1dd4:	00200713          	li	a4,2
    1dd8:	00100513          	li	a0,1
    1ddc:	caf76ae3          	bltu	a4,a5,1a90 <gpu_try_submit+0x10>
    1de0:	0005ac03          	lw	s8,0(a1)
    1de4:	0105d903          	lhu	s2,16(a1)
    1de8:	0125d983          	lhu	s3,18(a1)
    1dec:	0085ab83          	lw	s7,8(a1)
    1df0:	00090613          	mv	a2,s2
    1df4:	00098693          	mv	a3,s3
    1df8:	000b8593          	mv	a1,s7
    1dfc:	000c0513          	mv	a0,s8
    1e00:	b51ff0ef          	jal	1950 <surface>
    1e04:	c80516e3          	bnez	a0,1a90 <gpu_try_submit+0x10>
    1e08:	00442c83          	lw	s9,4(s0)
    1e0c:	00c42b03          	lw	s6,12(s0)
    1e10:	00098693          	mv	a3,s3
    1e14:	00090613          	mv	a2,s2
    1e18:	000b0593          	mv	a1,s6
    1e1c:	000c8513          	mv	a0,s9
    1e20:	b31ff0ef          	jal	1950 <surface>
    1e24:	c60516e3          	bnez	a0,1a90 <gpu_try_submit+0x10>
    1e28:	fff98693          	addi	a3,s3,-1
    1e2c:	036687b3          	mul	a5,a3,s6
    1e30:	00191913          	slli	s2,s2,0x1
    1e34:	01990733          	add	a4,s2,s9
    1e38:	01273633          	sltu	a2,a4,s2
    1e3c:	0366bb33          	mulhu	s6,a3,s6
    1e40:	00e78733          	add	a4,a5,a4
    1e44:	00f737b3          	sltu	a5,a4,a5
    1e48:	00cb0b33          	add	s6,s6,a2
    1e4c:	016787b3          	add	a5,a5,s6
    1e50:	00079463          	bnez	a5,1e58 <gpu_try_submit+0x3d8>
    1e54:	daec76e3          	bgeu	s8,a4,1c00 <gpu_try_submit+0x180>
    1e58:	037687b3          	mul	a5,a3,s7
    1e5c:	012c0933          	add	s2,s8,s2
    1e60:	01893c33          	sltu	s8,s2,s8
    1e64:	0376b6b3          	mulhu	a3,a3,s7
    1e68:	01278933          	add	s2,a5,s2
    1e6c:	00f937b3          	sltu	a5,s2,a5
    1e70:	018686b3          	add	a3,a3,s8
    1e74:	00d787b3          	add	a5,a5,a3
    1e78:	00079463          	bnez	a5,1e80 <gpu_try_submit+0x400>
    1e7c:	d92cf2e3          	bgeu	s9,s2,1c00 <gpu_try_submit+0x180>
    1e80:	00600513          	li	a0,6
    1e84:	c0dff06f          	j	1a90 <gpu_try_submit+0x10>

00001e88 <gpu_submit>:
    1e88:	04051663          	bnez	a0,1ed4 <gpu_submit+0x4c>
    1e8c:	ff800513          	li	a0,-8
    1e90:	00008067          	ret
    1e94:	ff800513          	li	a0,-8
    1e98:	04c12083          	lw	ra,76(sp)
    1e9c:	04812403          	lw	s0,72(sp)
    1ea0:	04412483          	lw	s1,68(sp)
    1ea4:	04012903          	lw	s2,64(sp)
    1ea8:	03c12983          	lw	s3,60(sp)
    1eac:	03812a03          	lw	s4,56(sp)
    1eb0:	03412a83          	lw	s5,52(sp)
    1eb4:	03012b03          	lw	s6,48(sp)
    1eb8:	02c12b83          	lw	s7,44(sp)
    1ebc:	02812c03          	lw	s8,40(sp)
    1ec0:	02412c83          	lw	s9,36(sp)
    1ec4:	02012d03          	lw	s10,32(sp)
    1ec8:	01c12d83          	lw	s11,28(sp)
    1ecc:	05010113          	addi	sp,sp,80
    1ed0:	00008067          	ret
    1ed4:	fb010113          	addi	sp,sp,-80
    1ed8:	04912223          	sw	s1,68(sp)
    1edc:	04112623          	sw	ra,76(sp)
    1ee0:	04812423          	sw	s0,72(sp)
    1ee4:	05212023          	sw	s2,64(sp)
    1ee8:	03312e23          	sw	s3,60(sp)
    1eec:	03412c23          	sw	s4,56(sp)
    1ef0:	03512a23          	sw	s5,52(sp)
    1ef4:	03612823          	sw	s6,48(sp)
    1ef8:	03712623          	sw	s7,44(sp)
    1efc:	03812423          	sw	s8,40(sp)
    1f00:	03912223          	sw	s9,36(sp)
    1f04:	03a12023          	sw	s10,32(sp)
    1f08:	01b12e23          	sw	s11,28(sp)
    1f0c:	01054783          	lbu	a5,16(a0)
    1f10:	00050493          	mv	s1,a0
    1f14:	f80780e3          	beqz	a5,1e94 <gpu_submit+0xc>
    1f18:	00068a13          	mv	s4,a3
    1f1c:	f6068ce3          	beqz	a3,1e94 <gpu_submit+0xc>
    1f20:	00058413          	mv	s0,a1
    1f24:	f60588e3          	beqz	a1,1e94 <gpu_submit+0xc>
    1f28:	01c5c903          	lbu	s2,28(a1)
    1f2c:	00700793          	li	a5,7
    1f30:	00060993          	mv	s3,a2
    1f34:	20f91c63          	bne	s2,a5,214c <gpu_submit+0x2c4>
    1f38:	0105dd03          	lhu	s10,16(a1)
    1f3c:	00200513          	li	a0,2
    1f40:	f40d0ce3          	beqz	s10,1e98 <gpu_submit+0x10>
    1f44:	0125db03          	lhu	s6,18(a1)
    1f48:	f40b08e3          	beqz	s6,1e98 <gpu_submit+0x10>
    1f4c:	0145dc03          	lhu	s8,20(a1)
    1f50:	f40c04e3          	beqz	s8,1e98 <gpu_submit+0x10>
    1f54:	01a5da83          	lhu	s5,26(a1)
    1f58:	f40a80e3          	beqz	s5,1e98 <gpu_submit+0x10>
    1f5c:	0185d783          	lhu	a5,24(a1)
    1f60:	00a00513          	li	a0,10
    1f64:	fcc7f793          	andi	a5,a5,-52
    1f68:	f20798e3          	bnez	a5,1e98 <gpu_submit+0x10>
    1f6c:	0005ab83          	lw	s7,0(a1)
    1f70:	0085ac83          	lw	s9,8(a1)
    1f74:	000a8693          	mv	a3,s5
    1f78:	000c0613          	mv	a2,s8
    1f7c:	000c8593          	mv	a1,s9
    1f80:	000b8513          	mv	a0,s7
    1f84:	9cdff0ef          	jal	1950 <surface>
    1f88:	f00518e3          	bnez	a0,1e98 <gpu_submit+0x10>
    1f8c:	00442d83          	lw	s11,4(s0)
    1f90:	00c42583          	lw	a1,12(s0)
    1f94:	000b0693          	mv	a3,s6
    1f98:	000d0613          	mv	a2,s10
    1f9c:	000d8513          	mv	a0,s11
    1fa0:	00b12623          	sw	a1,12(sp)
    1fa4:	9adff0ef          	jal	1950 <surface>
    1fa8:	ee0518e3          	bnez	a0,1e98 <gpu_submit+0x10>
    1fac:	00c12583          	lw	a1,12(sp)
    1fb0:	fffb0b13          	addi	s6,s6,-1
    1fb4:	001d1d13          	slli	s10,s10,0x1
    1fb8:	02bb07b3          	mul	a5,s6,a1
    1fbc:	01bd0733          	add	a4,s10,s11
    1fc0:	01a73d33          	sltu	s10,a4,s10
    1fc4:	02bb3b33          	mulhu	s6,s6,a1
    1fc8:	00e78733          	add	a4,a5,a4
    1fcc:	00f737b3          	sltu	a5,a4,a5
    1fd0:	01ab0b33          	add	s6,s6,s10
    1fd4:	016787b3          	add	a5,a5,s6
    1fd8:	00079463          	bnez	a5,1fe0 <gpu_submit+0x158>
    1fdc:	02ebfa63          	bgeu	s7,a4,2010 <gpu_submit+0x188>
    1fe0:	fffa8a93          	addi	s5,s5,-1
    1fe4:	039a87b3          	mul	a5,s5,s9
    1fe8:	001c1c13          	slli	s8,s8,0x1
    1fec:	017c0bb3          	add	s7,s8,s7
    1ff0:	018bbc33          	sltu	s8,s7,s8
    1ff4:	039abab3          	mulhu	s5,s5,s9
    1ff8:	01778bb3          	add	s7,a5,s7
    1ffc:	00fbb7b3          	sltu	a5,s7,a5
    2000:	018a8ab3          	add	s5,s5,s8
    2004:	015787b3          	add	a5,a5,s5
    2008:	28079063          	bnez	a5,2288 <gpu_submit+0x400>
    200c:	277dee63          	bltu	s11,s7,2288 <gpu_submit+0x400>
    2010:	00700a93          	li	s5,7
    2014:	00f00b13          	li	s6,15
    2018:	0004a683          	lw	a3,0(s1)
    201c:	0386a783          	lw	a5,56(a3)
    2020:	0ff7f793          	zext.b	a5,a5
    2024:	00f489a3          	sb	a5,19(s1)
    2028:	28079063          	bnez	a5,22a8 <gpu_submit+0x420>
    202c:	0086a783          	lw	a5,8(a3)
    2030:	03591063          	bne	s2,s5,2050 <gpu_submit+0x1c8>
    2034:	00e79713          	slli	a4,a5,0xe
    2038:	e4075ee3          	bgez	a4,1e94 <gpu_submit+0xc>
    203c:	01845703          	lhu	a4,24(s0)
    2040:	02077713          	andi	a4,a4,32
    2044:	00070663          	beqz	a4,2050 <gpu_submit+0x1c8>
    2048:	00d79713          	slli	a4,a5,0xd
    204c:	e40754e3          	bgez	a4,1e94 <gpu_submit+0xc>
    2050:	0144c603          	lbu	a2,20(s1)
    2054:	01f7f713          	andi	a4,a5,31
    2058:	00e67463          	bgeu	a2,a4,2060 <gpu_submit+0x1d8>
    205c:	00e48a23          	sb	a4,20(s1)
    2060:	0407f793          	andi	a5,a5,64
    2064:	22079663          	bnez	a5,2290 <gpu_submit+0x408>
    2068:	0124c783          	lbu	a5,18(s1)
    206c:	22fb6263          	bltu	s6,a5,2290 <gpu_submit+0x408>
    2070:	00a4d603          	lhu	a2,10(s1)
    2074:	00000713          	li	a4,0
    2078:	00160793          	addi	a5,a2,1 # 2a00001 <__gpu_framebuffer_a+0xa00001>
    207c:	00f49523          	sh	a5,10(s1)
    2080:	0126a823          	sw	s2,16(a3)
    2084:	00042783          	lw	a5,0(s0)
    2088:	00f6aa23          	sw	a5,20(a3)
    208c:	00442783          	lw	a5,4(s0)
    2090:	00f6ac23          	sw	a5,24(a3)
    2094:	01042783          	lw	a5,16(s0)
    2098:	00f6ae23          	sw	a5,28(a3)
    209c:	00842783          	lw	a5,8(s0)
    20a0:	02f6a023          	sw	a5,32(a3)
    20a4:	00c42783          	lw	a5,12(s0)
    20a8:	02f6a223          	sw	a5,36(a3)
    20ac:	00700793          	li	a5,7
    20b0:	00f90463          	beq	s2,a5,20b8 <gpu_submit+0x230>
    20b4:	01445703          	lhu	a4,20(s0)
    20b8:	01645783          	lhu	a5,22(s0)
    20bc:	01079793          	slli	a5,a5,0x10
    20c0:	00e7e7b3          	or	a5,a5,a4
    20c4:	02f6a423          	sw	a5,40(a3)
    20c8:	01845783          	lhu	a5,24(s0)
    20cc:	01d44703          	lbu	a4,29(s0)
    20d0:	01079793          	slli	a5,a5,0x10
    20d4:	00e7e7b3          	or	a5,a5,a4
    20d8:	02f6a623          	sw	a5,44(a3)
    20dc:	00700793          	li	a5,7
    20e0:	00f91c63          	bne	s2,a5,20f8 <gpu_submit+0x270>
    20e4:	01a45783          	lhu	a5,26(s0)
    20e8:	01445703          	lhu	a4,20(s0)
    20ec:	01079793          	slli	a5,a5,0x10
    20f0:	00e7e7b3          	or	a5,a5,a4
    20f4:	0af6a423          	sw	a5,168(a3)
    20f8:	02c6a823          	sw	a2,48(a3)
    20fc:	0ff0000f          	fence
    2100:	0004a783          	lw	a5,0(s1)
    2104:	00100713          	li	a4,1
    2108:	00e7a623          	sw	a4,12(a5)
    210c:	0ff0000f          	fence
    2110:	0044a783          	lw	a5,4(s1)
    2114:	00e488a3          	sb	a4,17(s1)
    2118:	0144c703          	lbu	a4,20(s1)
    211c:	00178793          	addi	a5,a5,1
    2120:	00f4a223          	sw	a5,4(s1)
    2124:	0124c783          	lbu	a5,18(s1)
    2128:	00c49723          	sh	a2,14(s1)
    212c:	00178793          	addi	a5,a5,1
    2130:	0ff7f793          	zext.b	a5,a5
    2134:	00f48923          	sb	a5,18(s1)
    2138:	00f77463          	bgeu	a4,a5,2140 <gpu_submit+0x2b8>
    213c:	00f48a23          	sb	a5,20(s1)
    2140:	00ca1023          	sh	a2,0(s4)
    2144:	00000513          	li	a0,0
    2148:	d51ff06f          	j	1e98 <gpu_submit+0x10>
    214c:	0185d783          	lhu	a5,24(a1)
    2150:	d40792e3          	bnez	a5,1e94 <gpu_submit+0xc>
    2154:	00100793          	li	a5,1
    2158:	02f91063          	bne	s2,a5,2178 <gpu_submit+0x2f0>
    215c:	01245683          	lhu	a3,18(s0)
    2160:	01045603          	lhu	a2,16(s0)
    2164:	00c42583          	lw	a1,12(s0)
    2168:	00442503          	lw	a0,4(s0)
    216c:	fe4ff0ef          	jal	1950 <surface>
    2170:	d20514e3          	bnez	a0,1e98 <gpu_submit+0x10>
    2174:	e9dff06f          	j	2010 <gpu_submit+0x188>
    2178:	00600793          	li	a5,6
    217c:	02f91263          	bne	s2,a5,21a0 <gpu_submit+0x318>
    2180:	0045a783          	lw	a5,4(a1)
    2184:	ffe00737          	lui	a4,0xffe00
    2188:	fff70713          	addi	a4,a4,-1 # ffdfffff <__gpu_framebuffer_a+0xfddfffff>
    218c:	00e7f7b3          	and	a5,a5,a4
    2190:	02000737          	lui	a4,0x2000
    2194:	00500513          	li	a0,5
    2198:	d0e790e3          	bne	a5,a4,1e98 <gpu_submit+0x10>
    219c:	e75ff06f          	j	2010 <gpu_submit+0x188>
    21a0:	00500793          	li	a5,5
    21a4:	02f91863          	bne	s2,a5,21d4 <gpu_submit+0x34c>
    21a8:	0005a783          	lw	a5,0(a1)
    21ac:	00300513          	li	a0,3
    21b0:	0037f713          	andi	a4,a5,3
    21b4:	ce0712e3          	bnez	a4,1e98 <gpu_submit+0x10>
    21b8:	fe000737          	lui	a4,0xfe000
    21bc:	00e787b3          	add	a5,a5,a4
    21c0:	0e000737          	lui	a4,0xe000
    21c4:	ffc70713          	addi	a4,a4,-4 # dfffffc <__gpu_framebuffer_a+0xbfffffc>
    21c8:	00500513          	li	a0,5
    21cc:	f8f778e3          	bgeu	a4,a5,215c <gpu_submit+0x2d4>
    21d0:	cc9ff06f          	j	1e98 <gpu_submit+0x10>
    21d4:	ffe90793          	addi	a5,s2,-2
    21d8:	0ff7f793          	zext.b	a5,a5
    21dc:	00200713          	li	a4,2
    21e0:	00100513          	li	a0,1
    21e4:	caf76ae3          	bltu	a4,a5,1e98 <gpu_submit+0x10>
    21e8:	0005ac03          	lw	s8,0(a1)
    21ec:	0105dc83          	lhu	s9,16(a1)
    21f0:	0125dd03          	lhu	s10,18(a1)
    21f4:	0085aa83          	lw	s5,8(a1)
    21f8:	000c8613          	mv	a2,s9
    21fc:	000d0693          	mv	a3,s10
    2200:	000a8593          	mv	a1,s5
    2204:	000c0513          	mv	a0,s8
    2208:	f48ff0ef          	jal	1950 <surface>
    220c:	c80516e3          	bnez	a0,1e98 <gpu_submit+0x10>
    2210:	00442b83          	lw	s7,4(s0)
    2214:	00c42b03          	lw	s6,12(s0)
    2218:	000d0693          	mv	a3,s10
    221c:	000c8613          	mv	a2,s9
    2220:	000b0593          	mv	a1,s6
    2224:	000b8513          	mv	a0,s7
    2228:	f28ff0ef          	jal	1950 <surface>
    222c:	c60516e3          	bnez	a0,1e98 <gpu_submit+0x10>
    2230:	fffd0713          	addi	a4,s10,-1
    2234:	03670633          	mul	a2,a4,s6
    2238:	001c9793          	slli	a5,s9,0x1
    223c:	017786b3          	add	a3,a5,s7
    2240:	00f6b5b3          	sltu	a1,a3,a5
    2244:	03673b33          	mulhu	s6,a4,s6
    2248:	00c68633          	add	a2,a3,a2
    224c:	00d636b3          	sltu	a3,a2,a3
    2250:	016585b3          	add	a1,a1,s6
    2254:	00b686b3          	add	a3,a3,a1
    2258:	00069463          	bnez	a3,2260 <gpu_submit+0x3d8>
    225c:	dacc7ae3          	bgeu	s8,a2,2010 <gpu_submit+0x188>
    2260:	035706b3          	mul	a3,a4,s5
    2264:	00fc07b3          	add	a5,s8,a5
    2268:	0187b533          	sltu	a0,a5,s8
    226c:	03573733          	mulhu	a4,a4,s5
    2270:	00f687b3          	add	a5,a3,a5
    2274:	00d7b6b3          	sltu	a3,a5,a3
    2278:	00a70733          	add	a4,a4,a0
    227c:	00e686b3          	add	a3,a3,a4
    2280:	00069463          	bnez	a3,2288 <gpu_submit+0x400>
    2284:	d8fbf6e3          	bgeu	s7,a5,2010 <gpu_submit+0x188>
    2288:	00600513          	li	a0,6
    228c:	c0dff06f          	j	1e98 <gpu_submit+0x10>
    2290:	02098063          	beqz	s3,22b0 <gpu_submit+0x428>
    2294:	00048513          	mv	a0,s1
    2298:	dc4ff0ef          	jal	185c <refresh>
    229c:	fff98993          	addi	s3,s3,-1
    22a0:	d6050ce3          	beqz	a0,2018 <gpu_submit+0x190>
    22a4:	bf5ff06f          	j	1e98 <gpu_submit+0x10>
    22a8:	ff900513          	li	a0,-7
    22ac:	bedff06f          	j	1e98 <gpu_submit+0x10>
    22b0:	ffb00513          	li	a0,-5
    22b4:	be5ff06f          	j	1e98 <gpu_submit+0x10>

000022b8 <gpu_poll>:
    22b8:	08050863          	beqz	a0,2348 <gpu_poll+0x90>
    22bc:	ff010113          	addi	sp,sp,-16
    22c0:	00812423          	sw	s0,8(sp)
    22c4:	00112623          	sw	ra,12(sp)
    22c8:	00912223          	sw	s1,4(sp)
    22cc:	01054783          	lbu	a5,16(a0)
    22d0:	00050413          	mv	s0,a0
    22d4:	ff800513          	li	a0,-8
    22d8:	04078e63          	beqz	a5,2334 <gpu_poll+0x7c>
    22dc:	00442703          	lw	a4,4(s0)
    22e0:	ffa00513          	li	a0,-6
    22e4:	04070863          	beqz	a4,2334 <gpu_poll+0x7c>
    22e8:	000106b7          	lui	a3,0x10
    22ec:	00845783          	lhu	a5,8(s0)
    22f0:	00058493          	mv	s1,a1
    22f4:	00d77a63          	bgeu	a4,a3,2308 <gpu_poll+0x50>
    22f8:	40f587b3          	sub	a5,a1,a5
    22fc:	01079793          	slli	a5,a5,0x10
    2300:	0107d793          	srli	a5,a5,0x10
    2304:	02e7f863          	bgeu	a5,a4,2334 <gpu_poll+0x7c>
    2308:	00040513          	mv	a0,s0
    230c:	d50ff0ef          	jal	185c <refresh>
    2310:	02051263          	bnez	a0,2334 <gpu_poll+0x7c>
    2314:	01244783          	lbu	a5,18(s0)
    2318:	00078e63          	beqz	a5,2334 <gpu_poll+0x7c>
    231c:	00a45703          	lhu	a4,10(s0)
    2320:	40e78733          	sub	a4,a5,a4
    2324:	00e484b3          	add	s1,s1,a4
    2328:	01049493          	slli	s1,s1,0x10
    232c:	0104d493          	srli	s1,s1,0x10
    2330:	00f4b533          	sltu	a0,s1,a5
    2334:	00c12083          	lw	ra,12(sp)
    2338:	00812403          	lw	s0,8(sp)
    233c:	00412483          	lw	s1,4(sp)
    2340:	01010113          	addi	sp,sp,16
    2344:	00008067          	ret
    2348:	ff800513          	li	a0,-8
    234c:	00008067          	ret

00002350 <gpu_present_async>:
    2350:	fd010113          	addi	sp,sp,-48
    2354:	02812423          	sw	s0,40(sp)
    2358:	02912223          	sw	s1,36(sp)
    235c:	03212023          	sw	s2,32(sp)
    2360:	00050413          	mv	s0,a0
    2364:	00058913          	mv	s2,a1
    2368:	00060493          	mv	s1,a2
    236c:	00000593          	li	a1,0
    2370:	02000613          	li	a2,32
    2374:	00010513          	mv	a0,sp
    2378:	02112623          	sw	ra,44(sp)
    237c:	eadfe0ef          	jal	1228 <memset>
    2380:	00200793          	li	a5,2
    2384:	00f12623          	sw	a5,12(sp)
    2388:	000107b7          	lui	a5,0x10
    238c:	00178793          	addi	a5,a5,1 # 10001 <__global_pointer$+0x1299>
    2390:	00f12823          	sw	a5,16(sp)
    2394:	00048613          	mv	a2,s1
    2398:	00600793          	li	a5,6
    239c:	00010593          	mv	a1,sp
    23a0:	00040513          	mv	a0,s0
    23a4:	01212223          	sw	s2,4(sp)
    23a8:	00f10e23          	sb	a5,28(sp)
    23ac:	ed4ff0ef          	jal	1a80 <gpu_try_submit>
    23b0:	02c12083          	lw	ra,44(sp)
    23b4:	02812403          	lw	s0,40(sp)
    23b8:	02412483          	lw	s1,36(sp)
    23bc:	02012903          	lw	s2,32(sp)
    23c0:	03010113          	addi	sp,sp,48
    23c4:	00008067          	ret

000023c8 <gpu_wait_tag>:
    23c8:	0a050063          	beqz	a0,2468 <gpu_wait_tag+0xa0>
    23cc:	fe010113          	addi	sp,sp,-32
    23d0:	00812c23          	sw	s0,24(sp)
    23d4:	00112e23          	sw	ra,28(sp)
    23d8:	00912a23          	sw	s1,20(sp)
    23dc:	01212823          	sw	s2,16(sp)
    23e0:	01312623          	sw	s3,12(sp)
    23e4:	01054783          	lbu	a5,16(a0)
    23e8:	00050413          	mv	s0,a0
    23ec:	ff800513          	li	a0,-8
    23f0:	02078a63          	beqz	a5,2424 <gpu_wait_tag+0x5c>
    23f4:	00442703          	lw	a4,4(s0)
    23f8:	ffa00513          	li	a0,-6
    23fc:	02070463          	beqz	a4,2424 <gpu_wait_tag+0x5c>
    2400:	000106b7          	lui	a3,0x10
    2404:	00845783          	lhu	a5,8(s0)
    2408:	00058913          	mv	s2,a1
    240c:	00060493          	mv	s1,a2
    2410:	04d77863          	bgeu	a4,a3,2460 <gpu_wait_tag+0x98>
    2414:	40f587b3          	sub	a5,a1,a5
    2418:	01079793          	slli	a5,a5,0x10
    241c:	0107d793          	srli	a5,a5,0x10
    2420:	04e7e063          	bltu	a5,a4,2460 <gpu_wait_tag+0x98>
    2424:	01c12083          	lw	ra,28(sp)
    2428:	01812403          	lw	s0,24(sp)
    242c:	01412483          	lw	s1,20(sp)
    2430:	01012903          	lw	s2,16(sp)
    2434:	00c12983          	lw	s3,12(sp)
    2438:	02010113          	addi	sp,sp,32
    243c:	00008067          	ret
    2440:	00090593          	mv	a1,s2
    2444:	00040513          	mv	a0,s0
    2448:	e71ff0ef          	jal	22b8 <gpu_poll>
    244c:	fff48493          	addi	s1,s1,-1
    2450:	fd351ae3          	bne	a0,s3,2424 <gpu_wait_tag+0x5c>
    2454:	fe0496e3          	bnez	s1,2440 <gpu_wait_tag+0x78>
    2458:	ffb00513          	li	a0,-5
    245c:	fc9ff06f          	j	2424 <gpu_wait_tag+0x5c>
    2460:	00100993          	li	s3,1
    2464:	ff1ff06f          	j	2454 <gpu_wait_tag+0x8c>
    2468:	ff800513          	li	a0,-8
    246c:	00008067          	ret

00002470 <gpu_set_qos>:
    2470:	00050793          	mv	a5,a0
    2474:	04050463          	beqz	a0,24bc <gpu_set_qos+0x4c>
    2478:	01054703          	lbu	a4,16(a0)
    247c:	ff800513          	li	a0,-8
    2480:	04070063          	beqz	a4,24c0 <gpu_set_qos+0x50>
    2484:	02c5fe63          	bgeu	a1,a2,24c0 <gpu_set_qos+0x50>
    2488:	00001737          	lui	a4,0x1
    248c:	02e67a63          	bgeu	a2,a4,24c0 <gpu_set_qos+0x50>
    2490:	00100713          	li	a4,1
    2494:	02d76663          	bltu	a4,a3,24c0 <gpu_set_qos+0x50>
    2498:	0007a783          	lw	a5,0(a5)
    249c:	01061613          	slli	a2,a2,0x10
    24a0:	00b665b3          	or	a1,a2,a1
    24a4:	01f69693          	slli	a3,a3,0x1f
    24a8:	00d5e5b3          	or	a1,a1,a3
    24ac:	04b7a423          	sw	a1,72(a5)
    24b0:	0ff0000f          	fence
    24b4:	00000513          	li	a0,0
    24b8:	00008067          	ret
    24bc:	ff800513          	li	a0,-8
    24c0:	00008067          	ret

000024c4 <gpu_texture_cache_load>:
    24c4:	0e050663          	beqz	a0,25b0 <gpu_texture_cache_load+0xec>
    24c8:	fe010113          	addi	sp,sp,-32
    24cc:	00812c23          	sw	s0,24(sp)
    24d0:	00112e23          	sw	ra,28(sp)
    24d4:	00912a23          	sw	s1,20(sp)
    24d8:	01212823          	sw	s2,16(sp)
    24dc:	01312623          	sw	s3,12(sp)
    24e0:	01054703          	lbu	a4,16(a0)
    24e4:	00050413          	mv	s0,a0
    24e8:	ff800793          	li	a5,-8
    24ec:	06070c63          	beqz	a4,2564 <gpu_texture_cache_load+0xa0>
    24f0:	00001737          	lui	a4,0x1
    24f4:	00068993          	mv	s3,a3
    24f8:	ffc70713          	addi	a4,a4,-4 # ffc <CUSTOM2+0xfa1>
    24fc:	ffc60693          	addi	a3,a2,-4
    2500:	00060913          	mv	s2,a2
    2504:	06d76063          	bltu	a4,a3,2564 <gpu_texture_cache_load+0xa0>
    2508:	00c5e733          	or	a4,a1,a2
    250c:	00377713          	andi	a4,a4,3
    2510:	00058493          	mv	s1,a1
    2514:	04071863          	bnez	a4,2564 <gpu_texture_cache_load+0xa0>
    2518:	02400737          	lui	a4,0x2400
    251c:	04e5e463          	bltu	a1,a4,2564 <gpu_texture_cache_load+0xa0>
    2520:	00c587b3          	add	a5,a1,a2
    2524:	08b7ec63          	bltu	a5,a1,25bc <gpu_texture_cache_load+0xf8>
    2528:	10000737          	lui	a4,0x10000
    252c:	08f76863          	bltu	a4,a5,25bc <gpu_texture_cache_load+0xf8>
    2530:	bd0ff0ef          	jal	1900 <texture_cache_idle>
    2534:	00050793          	mv	a5,a0
    2538:	02051663          	bnez	a0,2564 <gpu_texture_cache_load+0xa0>
    253c:	00042703          	lw	a4,0(s0)
    2540:	08972823          	sw	s1,144(a4) # 10000090 <__gpu_framebuffer_a+0xe000090>
    2544:	09272a23          	sw	s2,148(a4)
    2548:	0ff0000f          	fence
    254c:	00042703          	lw	a4,0(s0)
    2550:	00100693          	li	a3,1
    2554:	08d72c23          	sw	a3,152(a4)
    2558:	0ff0000f          	fence
    255c:	02099463          	bnez	s3,2584 <gpu_texture_cache_load+0xc0>
    2560:	ffb00793          	li	a5,-5
    2564:	01c12083          	lw	ra,28(sp)
    2568:	01812403          	lw	s0,24(sp)
    256c:	01412483          	lw	s1,20(sp)
    2570:	01012903          	lw	s2,16(sp)
    2574:	00c12983          	lw	s3,12(sp)
    2578:	00078513          	mv	a0,a5
    257c:	02010113          	addi	sp,sp,32
    2580:	00008067          	ret
    2584:	00042703          	lw	a4,0(s0)
    2588:	09c72703          	lw	a4,156(a4)
    258c:	00477693          	andi	a3,a4,4
    2590:	00069c63          	bnez	a3,25a8 <gpu_texture_cache_load+0xe4>
    2594:	00277693          	andi	a3,a4,2
    2598:	fff98993          	addi	s3,s3,-1
    259c:	fc0690e3          	bnez	a3,255c <gpu_texture_cache_load+0x98>
    25a0:	00177713          	andi	a4,a4,1
    25a4:	fc0710e3          	bnez	a4,2564 <gpu_texture_cache_load+0xa0>
    25a8:	ff900793          	li	a5,-7
    25ac:	fb9ff06f          	j	2564 <gpu_texture_cache_load+0xa0>
    25b0:	ff800793          	li	a5,-8
    25b4:	00078513          	mv	a0,a5
    25b8:	00008067          	ret
    25bc:	ff800793          	li	a5,-8
    25c0:	fa5ff06f          	j	2564 <gpu_texture_cache_load+0xa0>

000025c4 <gpu_read_perf_snapshot>:
    25c4:	00050793          	mv	a5,a0
    25c8:	0c050063          	beqz	a0,2688 <gpu_read_perf_snapshot+0xc4>
    25cc:	01054703          	lbu	a4,16(a0)
    25d0:	ff800513          	li	a0,-8
    25d4:	0a070c63          	beqz	a4,268c <gpu_read_perf_snapshot+0xc8>
    25d8:	0a058a63          	beqz	a1,268c <gpu_read_perf_snapshot+0xc8>
    25dc:	0007a703          	lw	a4,0(a5)
    25e0:	00100693          	li	a3,1
    25e4:	04d72623          	sw	a3,76(a4)
    25e8:	0ff0000f          	fence
    25ec:	0007a783          	lw	a5,0(a5)
    25f0:	00000513          	li	a0,0
    25f4:	0507a683          	lw	a3,80(a5)
    25f8:	0547a703          	lw	a4,84(a5)
    25fc:	00d5a023          	sw	a3,0(a1)
    2600:	0587a683          	lw	a3,88(a5)
    2604:	00e5a223          	sw	a4,4(a1)
    2608:	05c7a703          	lw	a4,92(a5)
    260c:	00d5a423          	sw	a3,8(a1)
    2610:	0607a683          	lw	a3,96(a5)
    2614:	00e5a623          	sw	a4,12(a1)
    2618:	0647a703          	lw	a4,100(a5)
    261c:	00d5a823          	sw	a3,16(a1)
    2620:	0687a683          	lw	a3,104(a5)
    2624:	00e5aa23          	sw	a4,20(a1)
    2628:	06c7a703          	lw	a4,108(a5)
    262c:	00d5ac23          	sw	a3,24(a1)
    2630:	0707a683          	lw	a3,112(a5)
    2634:	00e5ae23          	sw	a4,28(a1)
    2638:	0747a703          	lw	a4,116(a5)
    263c:	02d5a023          	sw	a3,32(a1)
    2640:	0787a683          	lw	a3,120(a5)
    2644:	02e5a223          	sw	a4,36(a1)
    2648:	07c7a703          	lw	a4,124(a5)
    264c:	02d5a423          	sw	a3,40(a1)
    2650:	0807a683          	lw	a3,128(a5)
    2654:	02e5a623          	sw	a4,44(a1)
    2658:	0847a703          	lw	a4,132(a5)
    265c:	02d5a823          	sw	a3,48(a1)
    2660:	0887a683          	lw	a3,136(a5)
    2664:	02e5aa23          	sw	a4,52(a1)
    2668:	08c7a703          	lw	a4,140(a5)
    266c:	02d5ac23          	sw	a3,56(a1)
    2670:	02e5ae23          	sw	a4,60(a1)
    2674:	0a07a703          	lw	a4,160(a5)
    2678:	0a47a783          	lw	a5,164(a5)
    267c:	04e5a023          	sw	a4,64(a1)
    2680:	04f5a223          	sw	a5,68(a1)
    2684:	00008067          	ret
    2688:	ff800513          	li	a0,-8
    268c:	00008067          	ret

00002690 <blit_pair_validate>:
    2690:	fd010113          	addi	sp,sp,-48
    2694:	00a12623          	sw	a0,12(sp)
    2698:	02812623          	sw	s0,44(sp)
    269c:	02912423          	sw	s1,40(sp)
    26a0:	03212223          	sw	s2,36(sp)
    26a4:	00d12423          	sw	a3,8(sp)
    26a8:	00e11023          	sh	a4,0(sp)
    26ac:	00b11123          	sh	a1,2(sp)
    26b0:	00f11223          	sh	a5,4(sp)
    26b4:	00c11323          	sh	a2,6(sp)
    26b8:	00200513          	li	a0,2
    26bc:	10080263          	beqz	a6,27c0 <blit_pair_validate+0x130>
    26c0:	10088063          	beqz	a7,27c0 <blit_pair_validate+0x130>
    26c4:	00181413          	slli	s0,a6,0x1
    26c8:	00810293          	addi	t0,sp,8
    26cc:	01010f93          	addi	t6,sp,16
    26d0:	01810f13          	addi	t5,sp,24
    26d4:	00000e13          	li	t3,0
    26d8:	fff88493          	addi	s1,a7,-1
    26dc:	00200393          	li	t2,2
    26e0:	0002a303          	lw	t1,0(t0) # 12dc <memset+0xb4>
    26e4:	10030463          	beqz	t1,27ec <blit_pair_validate+0x15c>
    26e8:	00032703          	lw	a4,0(t1)
    26ec:	10070063          	beqz	a4,27ec <blit_pair_validate+0x15c>
    26f0:	00c32783          	lw	a5,12(t1)
    26f4:	00f76533          	or	a0,a4,a5
    26f8:	00157513          	andi	a0,a0,1
    26fc:	0e051063          	bnez	a0,27dc <blit_pair_validate+0x14c>
    2700:	00835583          	lhu	a1,8(t1)
    2704:	00159613          	slli	a2,a1,0x1
    2708:	0cc7ee63          	bltu	a5,a2,27e4 <blit_pair_validate+0x154>
    270c:	00a35683          	lhu	a3,10(t1)
    2710:	0c068e63          	beqz	a3,27ec <blit_pair_validate+0x15c>
    2714:	01c10eb3          	add	t4,sp,t3
    2718:	000ed903          	lhu	s2,0(t4)
    271c:	01090eb3          	add	t4,s2,a6
    2720:	0dd5e663          	bltu	a1,t4,27ec <blit_pair_validate+0x15c>
    2724:	00410593          	addi	a1,sp,4
    2728:	01c585b3          	add	a1,a1,t3
    272c:	0005de83          	lhu	t4,0(a1)
    2730:	01d885b3          	add	a1,a7,t4
    2734:	0ab6ec63          	bltu	a3,a1,27ec <blit_pair_validate+0x15c>
    2738:	fff68693          	addi	a3,a3,-1 # ffff <__global_pointer$+0x1297>
    273c:	02d785b3          	mul	a1,a5,a3
    2740:	02f6a6b3          	mulhsu	a3,a3,a5
    2744:	00c58633          	add	a2,a1,a2
    2748:	00b635b3          	sltu	a1,a2,a1
    274c:	00d585b3          	add	a1,a1,a3
    2750:	00432683          	lw	a3,4(t1)
    2754:	08059c63          	bnez	a1,27ec <blit_pair_validate+0x15c>
    2758:	08c6ea63          	bltu	a3,a2,27ec <blit_pair_validate+0x15c>
    275c:	fff74693          	not	a3,a4
    2760:	08c6e663          	bltu	a3,a2,27ec <blit_pair_validate+0x15c>
    2764:	03d78eb3          	mul	t4,a5,t4
    2768:	00191913          	slli	s2,s2,0x1
    276c:	01270733          	add	a4,a4,s2
    2770:	00428293          	addi	t0,t0,4
    2774:	004f8f93          	addi	t6,t6,4
    2778:	004f0f13          	addi	t5,t5,4
    277c:	02f487b3          	mul	a5,s1,a5
    2780:	01d70733          	add	a4,a4,t4
    2784:	feefae23          	sw	a4,-4(t6)
    2788:	008787b3          	add	a5,a5,s0
    278c:	00e787b3          	add	a5,a5,a4
    2790:	feff2e23          	sw	a5,-4(t5)
    2794:	047e1063          	bne	t3,t2,27d4 <blit_pair_validate+0x144>
    2798:	01012783          	lw	a5,16(sp)
    279c:	01c12683          	lw	a3,28(sp)
    27a0:	01412703          	lw	a4,20(sp)
    27a4:	00d7f663          	bgeu	a5,a3,27b0 <blit_pair_validate+0x120>
    27a8:	01812683          	lw	a3,24(sp)
    27ac:	04d76463          	bltu	a4,a3,27f4 <blit_pair_validate+0x164>
    27b0:	03012683          	lw	a3,48(sp)
    27b4:	00e6a023          	sw	a4,0(a3)
    27b8:	03412703          	lw	a4,52(sp)
    27bc:	00f72023          	sw	a5,0(a4)
    27c0:	02c12403          	lw	s0,44(sp)
    27c4:	02812483          	lw	s1,40(sp)
    27c8:	02412903          	lw	s2,36(sp)
    27cc:	03010113          	addi	sp,sp,48
    27d0:	00008067          	ret
    27d4:	00200e13          	li	t3,2
    27d8:	f09ff06f          	j	26e0 <blit_pair_validate+0x50>
    27dc:	00300513          	li	a0,3
    27e0:	fe1ff06f          	j	27c0 <blit_pair_validate+0x130>
    27e4:	00400513          	li	a0,4
    27e8:	fd9ff06f          	j	27c0 <blit_pair_validate+0x130>
    27ec:	00500513          	li	a0,5
    27f0:	fd1ff06f          	j	27c0 <blit_pair_validate+0x130>
    27f4:	00600513          	li	a0,6
    27f8:	fc9ff06f          	j	27c0 <blit_pair_validate+0x130>

000027fc <golden_fill>:
    27fc:	00050813          	mv	a6,a0
    2800:	0c050a63          	beqz	a0,28d4 <golden_fill+0xd8>
    2804:	00052883          	lw	a7,0(a0)
    2808:	00500513          	li	a0,5
    280c:	0c088663          	beqz	a7,28d8 <golden_fill+0xdc>
    2810:	00200513          	li	a0,2
    2814:	0c068263          	beqz	a3,28d8 <golden_fill+0xdc>
    2818:	0c070063          	beqz	a4,28d8 <golden_fill+0xdc>
    281c:	00885f03          	lhu	t5,8(a6)
    2820:	0a0f0c63          	beqz	t5,28d8 <golden_fill+0xdc>
    2824:	00a85e83          	lhu	t4,10(a6)
    2828:	0a0e8863          	beqz	t4,28d8 <golden_fill+0xdc>
    282c:	0018f893          	andi	a7,a7,1
    2830:	00300513          	li	a0,3
    2834:	0a089263          	bnez	a7,28d8 <golden_fill+0xdc>
    2838:	00c82303          	lw	t1,12(a6)
    283c:	00137513          	andi	a0,t1,1
    2840:	08051263          	bnez	a0,28c4 <golden_fill+0xc8>
    2844:	001f1e13          	slli	t3,t5,0x1
    2848:	09c36263          	bltu	t1,t3,28cc <golden_fill+0xd0>
    284c:	fffe8f93          	addi	t6,t4,-1
    2850:	03f308b3          	mul	a7,t1,t6
    2854:	026fa333          	mulhsu	t1,t6,t1
    2858:	01c88e33          	add	t3,a7,t3
    285c:	011e38b3          	sltu	a7,t3,a7
    2860:	006888b3          	add	a7,a7,t1
    2864:	00482303          	lw	t1,4(a6)
    2868:	06089663          	bnez	a7,28d4 <golden_fill+0xd8>
    286c:	07c36463          	bltu	t1,t3,28d4 <golden_fill+0xd8>
    2870:	00d588b3          	add	a7,a1,a3
    2874:	071f6063          	bltu	t5,a7,28d4 <golden_fill+0xd8>
    2878:	00c70733          	add	a4,a4,a2
    287c:	04eeec63          	bltu	t4,a4,28d4 <golden_fill+0xd8>
    2880:	00159593          	slli	a1,a1,0x1
    2884:	0087de13          	srli	t3,a5,0x8
    2888:	00e66463          	bltu	a2,a4,2890 <golden_fill+0x94>
    288c:	00008067          	ret
    2890:	00c82303          	lw	t1,12(a6)
    2894:	00082883          	lw	a7,0(a6)
    2898:	02660333          	mul	t1,a2,t1
    289c:	00b30333          	add	t1,t1,a1
    28a0:	006888b3          	add	a7,a7,t1
    28a4:	00000313          	li	t1,0
    28a8:	00f88023          	sb	a5,0(a7)
    28ac:	01c880a3          	sb	t3,1(a7)
    28b0:	00130313          	addi	t1,t1,1
    28b4:	00288893          	addi	a7,a7,2
    28b8:	fed368e3          	bltu	t1,a3,28a8 <golden_fill+0xac>
    28bc:	00160613          	addi	a2,a2,1
    28c0:	fc9ff06f          	j	2888 <golden_fill+0x8c>
    28c4:	00300513          	li	a0,3
    28c8:	00008067          	ret
    28cc:	00400513          	li	a0,4
    28d0:	00008067          	ret
    28d4:	00500513          	li	a0,5
    28d8:	00008067          	ret

000028dc <golden_copy>:
    28dc:	fc010113          	addi	sp,sp,-64
    28e0:	02812e23          	sw	s0,60(sp)
    28e4:	02912c23          	sw	s1,56(sp)
    28e8:	03212a23          	sw	s2,52(sp)
    28ec:	03312823          	sw	s3,48(sp)
    28f0:	03412623          	sw	s4,44(sp)
    28f4:	00d12423          	sw	a3,8(sp)
    28f8:	00a12623          	sw	a0,12(sp)
    28fc:	00e11023          	sh	a4,0(sp)
    2900:	00b11123          	sh	a1,2(sp)
    2904:	00f11223          	sh	a5,4(sp)
    2908:	00c11323          	sh	a2,6(sp)
    290c:	16080063          	beqz	a6,2a6c <golden_copy+0x190>
    2910:	00050e13          	mv	t3,a0
    2914:	00200513          	li	a0,2
    2918:	12088863          	beqz	a7,2a48 <golden_copy+0x16c>
    291c:	00181393          	slli	t2,a6,0x1
    2920:	00810293          	addi	t0,sp,8
    2924:	01010f93          	addi	t6,sp,16
    2928:	01810f13          	addi	t5,sp,24
    292c:	00000e93          	li	t4,0
    2930:	fff88493          	addi	s1,a7,-1
    2934:	00200413          	li	s0,2
    2938:	0002a903          	lw	s2,0(t0)
    293c:	14090463          	beqz	s2,2a84 <golden_copy+0x1a8>
    2940:	00092703          	lw	a4,0(s2)
    2944:	14070063          	beqz	a4,2a84 <golden_copy+0x1a8>
    2948:	00c92783          	lw	a5,12(s2)
    294c:	00f76533          	or	a0,a4,a5
    2950:	00157513          	andi	a0,a0,1
    2954:	12051063          	bnez	a0,2a74 <golden_copy+0x198>
    2958:	00895303          	lhu	t1,8(s2)
    295c:	00131593          	slli	a1,t1,0x1
    2960:	10b7ee63          	bltu	a5,a1,2a7c <golden_copy+0x1a0>
    2964:	00a95603          	lhu	a2,10(s2)
    2968:	10060e63          	beqz	a2,2a84 <golden_copy+0x1a8>
    296c:	01d109b3          	add	s3,sp,t4
    2970:	0009da03          	lhu	s4,0(s3)
    2974:	010a09b3          	add	s3,s4,a6
    2978:	11336663          	bltu	t1,s3,2a84 <golden_copy+0x1a8>
    297c:	00410313          	addi	t1,sp,4
    2980:	01d30333          	add	t1,t1,t4
    2984:	00035983          	lhu	s3,0(t1)
    2988:	01198333          	add	t1,s3,a7
    298c:	0e666c63          	bltu	a2,t1,2a84 <golden_copy+0x1a8>
    2990:	fff60613          	addi	a2,a2,-1
    2994:	02c78333          	mul	t1,a5,a2
    2998:	02f62633          	mulhsu	a2,a2,a5
    299c:	00b305b3          	add	a1,t1,a1
    29a0:	0065b333          	sltu	t1,a1,t1
    29a4:	00c30333          	add	t1,t1,a2
    29a8:	00492603          	lw	a2,4(s2)
    29ac:	0c031c63          	bnez	t1,2a84 <golden_copy+0x1a8>
    29b0:	0cb66a63          	bltu	a2,a1,2a84 <golden_copy+0x1a8>
    29b4:	fff74613          	not	a2,a4
    29b8:	0cb66663          	bltu	a2,a1,2a84 <golden_copy+0x1a8>
    29bc:	033789b3          	mul	s3,a5,s3
    29c0:	001a1a13          	slli	s4,s4,0x1
    29c4:	01470733          	add	a4,a4,s4
    29c8:	00428293          	addi	t0,t0,4
    29cc:	004f8f93          	addi	t6,t6,4
    29d0:	004f0f13          	addi	t5,t5,4
    29d4:	02f487b3          	mul	a5,s1,a5
    29d8:	01370733          	add	a4,a4,s3
    29dc:	feefae23          	sw	a4,-4(t6)
    29e0:	007787b3          	add	a5,a5,t2
    29e4:	00e787b3          	add	a5,a5,a4
    29e8:	feff2e23          	sw	a5,-4(t5)
    29ec:	068e9c63          	bne	t4,s0,2a64 <golden_copy+0x188>
    29f0:	01012803          	lw	a6,16(sp)
    29f4:	01c12783          	lw	a5,28(sp)
    29f8:	01412303          	lw	t1,20(sp)
    29fc:	00f87663          	bgeu	a6,a5,2a08 <golden_copy+0x12c>
    2a00:	01812783          	lw	a5,24(sp)
    2a04:	08f36463          	bltu	t1,a5,2a8c <golden_copy+0x1b0>
    2a08:	00000793          	li	a5,0
    2a0c:	00000713          	li	a4,0
    2a10:	00c6a583          	lw	a1,12(a3)
    2a14:	00e80633          	add	a2,a6,a4
    2a18:	02b785b3          	mul	a1,a5,a1
    2a1c:	00b60633          	add	a2,a2,a1
    2a20:	00ce2583          	lw	a1,12(t3)
    2a24:	00064e83          	lbu	t4,0(a2)
    2a28:	00670633          	add	a2,a4,t1
    2a2c:	02b785b3          	mul	a1,a5,a1
    2a30:	00170713          	addi	a4,a4,1
    2a34:	00b60633          	add	a2,a2,a1
    2a38:	01d60023          	sb	t4,0(a2)
    2a3c:	fc776ae3          	bltu	a4,t2,2a10 <golden_copy+0x134>
    2a40:	00178793          	addi	a5,a5,1
    2a44:	fcf894e3          	bne	a7,a5,2a0c <golden_copy+0x130>
    2a48:	03c12403          	lw	s0,60(sp)
    2a4c:	03812483          	lw	s1,56(sp)
    2a50:	03412903          	lw	s2,52(sp)
    2a54:	03012983          	lw	s3,48(sp)
    2a58:	02c12a03          	lw	s4,44(sp)
    2a5c:	04010113          	addi	sp,sp,64
    2a60:	00008067          	ret
    2a64:	00200e93          	li	t4,2
    2a68:	ed1ff06f          	j	2938 <golden_copy+0x5c>
    2a6c:	00200513          	li	a0,2
    2a70:	fd9ff06f          	j	2a48 <golden_copy+0x16c>
    2a74:	00300513          	li	a0,3
    2a78:	fd1ff06f          	j	2a48 <golden_copy+0x16c>
    2a7c:	00400513          	li	a0,4
    2a80:	fc9ff06f          	j	2a48 <golden_copy+0x16c>
    2a84:	00500513          	li	a0,5
    2a88:	fc1ff06f          	j	2a48 <golden_copy+0x16c>
    2a8c:	00600513          	li	a0,6
    2a90:	fb9ff06f          	j	2a48 <golden_copy+0x16c>

00002a94 <golden_color_key>:
    2a94:	fc010113          	addi	sp,sp,-64
    2a98:	01c10313          	addi	t1,sp,28
    2a9c:	00612223          	sw	t1,4(sp)
    2aa0:	01810313          	addi	t1,sp,24
    2aa4:	00612023          	sw	t1,0(sp)
    2aa8:	02812c23          	sw	s0,56(sp)
    2aac:	02912a23          	sw	s1,52(sp)
    2ab0:	03212823          	sw	s2,48(sp)
    2ab4:	03312623          	sw	s3,44(sp)
    2ab8:	03412423          	sw	s4,40(sp)
    2abc:	02112e23          	sw	ra,60(sp)
    2ac0:	04015a03          	lhu	s4,64(sp)
    2ac4:	00050493          	mv	s1,a0
    2ac8:	00068913          	mv	s2,a3
    2acc:	00080993          	mv	s3,a6
    2ad0:	00088413          	mv	s0,a7
    2ad4:	bbdff0ef          	jal	2690 <blit_pair_validate>
    2ad8:	00051a63          	bnez	a0,2aec <golden_color_key+0x58>
    2adc:	01c12803          	lw	a6,28(sp)
    2ae0:	01812883          	lw	a7,24(sp)
    2ae4:	00000713          	li	a4,0
    2ae8:	02876263          	bltu	a4,s0,2b0c <golden_color_key+0x78>
    2aec:	03c12083          	lw	ra,60(sp)
    2af0:	03812403          	lw	s0,56(sp)
    2af4:	03412483          	lw	s1,52(sp)
    2af8:	03012903          	lw	s2,48(sp)
    2afc:	02c12983          	lw	s3,44(sp)
    2b00:	02812a03          	lw	s4,40(sp)
    2b04:	04010113          	addi	sp,sp,64
    2b08:	00008067          	ret
    2b0c:	00c92603          	lw	a2,12(s2)
    2b10:	00c4a583          	lw	a1,12(s1)
    2b14:	00000693          	li	a3,0
    2b18:	02c70633          	mul	a2,a4,a2
    2b1c:	02b705b3          	mul	a1,a4,a1
    2b20:	01060633          	add	a2,a2,a6
    2b24:	011585b3          	add	a1,a1,a7
    2b28:	0136e663          	bltu	a3,s3,2b34 <golden_color_key+0xa0>
    2b2c:	00170713          	addi	a4,a4,1
    2b30:	fb9ff06f          	j	2ae8 <golden_color_key+0x54>
    2b34:	00169313          	slli	t1,a3,0x1
    2b38:	006607b3          	add	a5,a2,t1
    2b3c:	0007ce03          	lbu	t3,0(a5)
    2b40:	0017c783          	lbu	a5,1(a5)
    2b44:	00879793          	slli	a5,a5,0x8
    2b48:	01c7e7b3          	or	a5,a5,t3
    2b4c:	00fa0a63          	beq	s4,a5,2b60 <golden_color_key+0xcc>
    2b50:	00658333          	add	t1,a1,t1
    2b54:	00f30023          	sb	a5,0(t1)
    2b58:	0087d793          	srli	a5,a5,0x8
    2b5c:	00f300a3          	sb	a5,1(t1)
    2b60:	00168693          	addi	a3,a3,1
    2b64:	fc5ff06f          	j	2b28 <golden_color_key+0x94>

00002b68 <golden_alpha_blend>:
    2b68:	fb010113          	addi	sp,sp,-80
    2b6c:	01c10313          	addi	t1,sp,28
    2b70:	00612223          	sw	t1,4(sp)
    2b74:	01810313          	addi	t1,sp,24
    2b78:	00612023          	sw	t1,0(sp)
    2b7c:	04812423          	sw	s0,72(sp)
    2b80:	03312e23          	sw	s3,60(sp)
    2b84:	03412c23          	sw	s4,56(sp)
    2b88:	03512a23          	sw	s5,52(sp)
    2b8c:	03612823          	sw	s6,48(sp)
    2b90:	03712623          	sw	s7,44(sp)
    2b94:	03a12023          	sw	s10,32(sp)
    2b98:	05014b83          	lbu	s7,80(sp)
    2b9c:	04112623          	sw	ra,76(sp)
    2ba0:	04912223          	sw	s1,68(sp)
    2ba4:	05212023          	sw	s2,64(sp)
    2ba8:	03812423          	sw	s8,40(sp)
    2bac:	03912223          	sw	s9,36(sp)
    2bb0:	00050a13          	mv	s4,a0
    2bb4:	00068a93          	mv	s5,a3
    2bb8:	00080b13          	mv	s6,a6
    2bbc:	00088993          	mv	s3,a7
    2bc0:	ad1ff0ef          	jal	2690 <blit_pair_validate>
    2bc4:	00050d13          	mv	s10,a0
    2bc8:	00000413          	li	s0,0
    2bcc:	06050663          	beqz	a0,2c38 <golden_alpha_blend+0xd0>
    2bd0:	04c12083          	lw	ra,76(sp)
    2bd4:	04812403          	lw	s0,72(sp)
    2bd8:	04412483          	lw	s1,68(sp)
    2bdc:	04012903          	lw	s2,64(sp)
    2be0:	03c12983          	lw	s3,60(sp)
    2be4:	03812a03          	lw	s4,56(sp)
    2be8:	03412a83          	lw	s5,52(sp)
    2bec:	03012b03          	lw	s6,48(sp)
    2bf0:	02c12b83          	lw	s7,44(sp)
    2bf4:	02812c03          	lw	s8,40(sp)
    2bf8:	02412c83          	lw	s9,36(sp)
    2bfc:	000d0513          	mv	a0,s10
    2c00:	02012d03          	lw	s10,32(sp)
    2c04:	05010113          	addi	sp,sp,80
    2c08:	00008067          	ret
    2c0c:	00caa483          	lw	s1,12(s5)
    2c10:	00ca2903          	lw	s2,12(s4)
    2c14:	01c12783          	lw	a5,28(sp)
    2c18:	029404b3          	mul	s1,s0,s1
    2c1c:	00000c13          	li	s8,0
    2c20:	03240933          	mul	s2,s0,s2
    2c24:	00f484b3          	add	s1,s1,a5
    2c28:	01812783          	lw	a5,24(sp)
    2c2c:	00f90933          	add	s2,s2,a5
    2c30:	016c6863          	bltu	s8,s6,2c40 <golden_alpha_blend+0xd8>
    2c34:	00140413          	addi	s0,s0,1
    2c38:	fd346ae3          	bltu	s0,s3,2c0c <golden_alpha_blend+0xa4>
    2c3c:	f95ff06f          	j	2bd0 <golden_alpha_blend+0x68>
    2c40:	001c1793          	slli	a5,s8,0x1
    2c44:	00f90cb3          	add	s9,s2,a5
    2c48:	00f487b3          	add	a5,s1,a5
    2c4c:	0007c503          	lbu	a0,0(a5)
    2c50:	001cc703          	lbu	a4,1(s9)
    2c54:	0017c783          	lbu	a5,1(a5)
    2c58:	000cc583          	lbu	a1,0(s9)
    2c5c:	00871713          	slli	a4,a4,0x8
    2c60:	00879793          	slli	a5,a5,0x8
    2c64:	00a7e533          	or	a0,a5,a0
    2c68:	000b8613          	mv	a2,s7
    2c6c:	00b765b3          	or	a1,a4,a1
    2c70:	018000ef          	jal	2c88 <rgb565_global_alpha>
    2c74:	00855793          	srli	a5,a0,0x8
    2c78:	00ac8023          	sb	a0,0(s9)
    2c7c:	00fc80a3          	sb	a5,1(s9)
    2c80:	001c0c13          	addi	s8,s8,1
    2c84:	fadff06f          	j	2c30 <golden_alpha_blend+0xc8>

00002c88 <rgb565_global_alpha>:
    2c88:	0ff00693          	li	a3,255
    2c8c:	40c68833          	sub	a6,a3,a2
    2c90:	00b5d713          	srli	a4,a1,0xb
    2c94:	03070733          	mul	a4,a4,a6
    2c98:	00b55793          	srli	a5,a0,0xb
    2c9c:	01f57893          	andi	a7,a0,31
    2ca0:	00555513          	srli	a0,a0,0x5
    2ca4:	03f57513          	andi	a0,a0,63
    2ca8:	02c787b3          	mul	a5,a5,a2
    2cac:	07f70713          	addi	a4,a4,127
    2cb0:	00f70733          	add	a4,a4,a5
    2cb4:	01f5f793          	andi	a5,a1,31
    2cb8:	030787b3          	mul	a5,a5,a6
    2cbc:	02c888b3          	mul	a7,a7,a2
    2cc0:	07f78793          	addi	a5,a5,127
    2cc4:	02d75733          	divu	a4,a4,a3
    2cc8:	011787b3          	add	a5,a5,a7
    2ccc:	02d7d7b3          	divu	a5,a5,a3
    2cd0:	00b71713          	slli	a4,a4,0xb
    2cd4:	00f76733          	or	a4,a4,a5
    2cd8:	0055d793          	srli	a5,a1,0x5
    2cdc:	03f7f793          	andi	a5,a5,63
    2ce0:	030787b3          	mul	a5,a5,a6
    2ce4:	02c50633          	mul	a2,a0,a2
    2ce8:	07f78793          	addi	a5,a5,127
    2cec:	00c787b3          	add	a5,a5,a2
    2cf0:	02d7d7b3          	divu	a5,a5,a3
    2cf4:	00579793          	slli	a5,a5,0x5
    2cf8:	00f76533          	or	a0,a4,a5
    2cfc:	01051513          	slli	a0,a0,0x10
    2d00:	01055513          	srli	a0,a0,0x10
    2d04:	00008067          	ret

00002d08 <framebuffer_init>:
    2d08:	00050a63          	beqz	a0,2d1c <framebuffer_init+0x14>
    2d0c:	020007b7          	lui	a5,0x2000
    2d10:	00f52023          	sw	a5,0(a0)
    2d14:	022007b7          	lui	a5,0x2200
    2d18:	00f52223          	sw	a5,4(a0)
    2d1c:	00008067          	ret

00002d20 <framebuffer_present>:
    2d20:	06058863          	beqz	a1,2d90 <framebuffer_present+0x70>
    2d24:	fe010113          	addi	sp,sp,-32
    2d28:	00812c23          	sw	s0,24(sp)
    2d2c:	00058413          	mv	s0,a1
    2d30:	0045a583          	lw	a1,4(a1)
    2d34:	01212823          	sw	s2,16(sp)
    2d38:	00060913          	mv	s2,a2
    2d3c:	00e10613          	addi	a2,sp,14
    2d40:	00912a23          	sw	s1,20(sp)
    2d44:	00112e23          	sw	ra,28(sp)
    2d48:	00050493          	mv	s1,a0
    2d4c:	e04ff0ef          	jal	2350 <gpu_present_async>
    2d50:	02051463          	bnez	a0,2d78 <framebuffer_present+0x58>
    2d54:	00e15583          	lhu	a1,14(sp)
    2d58:	00090613          	mv	a2,s2
    2d5c:	00048513          	mv	a0,s1
    2d60:	e68ff0ef          	jal	23c8 <gpu_wait_tag>
    2d64:	00051a63          	bnez	a0,2d78 <framebuffer_present+0x58>
    2d68:	00042783          	lw	a5,0(s0)
    2d6c:	00442703          	lw	a4,4(s0)
    2d70:	00f42223          	sw	a5,4(s0)
    2d74:	00e42023          	sw	a4,0(s0)
    2d78:	01c12083          	lw	ra,28(sp)
    2d7c:	01812403          	lw	s0,24(sp)
    2d80:	01412483          	lw	s1,20(sp)
    2d84:	01012903          	lw	s2,16(sp)
    2d88:	02010113          	addi	sp,sp,32
    2d8c:	00008067          	ret
    2d90:	ff800513          	li	a0,-8
    2d94:	00008067          	ret

00002d98 <append_fill>:
    2d98:	fe010113          	addi	sp,sp,-32
    2d9c:	00812c23          	sw	s0,24(sp)
    2da0:	00068413          	mv	s0,a3
    2da4:	000086b7          	lui	a3,0x8
    2da8:	00d506b3          	add	a3,a0,a3
    2dac:	00912a23          	sw	s1,20(sp)
    2db0:	00070493          	mv	s1,a4
    2db4:	0006d703          	lhu	a4,0(a3) # 8000 <game_update_cached+0xec>
    2db8:	01512223          	sw	s5,4(sp)
    2dbc:	00112e23          	sw	ra,28(sp)
    2dc0:	00078a93          	mv	s5,a5
    2dc4:	01212823          	sw	s2,16(sp)
    2dc8:	01312623          	sw	s3,12(sp)
    2dcc:	01412423          	sw	s4,8(sp)
    2dd0:	01612023          	sw	s6,0(sp)
    2dd4:	3ff00793          	li	a5,1023
    2dd8:	08e7e663          	bltu	a5,a4,2e64 <append_fill+0xcc>
    2ddc:	00060913          	mv	s2,a2
    2de0:	032484b3          	mul	s1,s1,s2
    2de4:	00170793          	addi	a5,a4,1
    2de8:	00571713          	slli	a4,a4,0x5
    2dec:	00e50733          	add	a4,a0,a4
    2df0:	00058b13          	mv	s6,a1
    2df4:	00f69023          	sh	a5,0(a3)
    2df8:	02000613          	li	a2,32
    2dfc:	00000593          	li	a1,0
    2e00:	00070513          	mv	a0,a4
    2e04:	00141413          	slli	s0,s0,0x1
    2e08:	00080a13          	mv	s4,a6
    2e0c:	00088993          	mv	s3,a7
    2e10:	01640433          	add	s0,s0,s6
    2e14:	c14fe0ef          	jal	1228 <memset>
    2e18:	00940433          	add	s0,s0,s1
    2e1c:	00100793          	li	a5,1
    2e20:	00852223          	sw	s0,4(a0)
    2e24:	01252623          	sw	s2,12(a0)
    2e28:	01551823          	sh	s5,16(a0)
    2e2c:	01451923          	sh	s4,18(a0)
    2e30:	01351a23          	sh	s3,20(a0)
    2e34:	00f50e23          	sb	a5,28(a0)
    2e38:	00000513          	li	a0,0
    2e3c:	01c12083          	lw	ra,28(sp)
    2e40:	01812403          	lw	s0,24(sp)
    2e44:	01412483          	lw	s1,20(sp)
    2e48:	01012903          	lw	s2,16(sp)
    2e4c:	00c12983          	lw	s3,12(sp)
    2e50:	00812a03          	lw	s4,8(sp)
    2e54:	00412a83          	lw	s5,4(sp)
    2e58:	00012b03          	lw	s6,0(sp)
    2e5c:	02010113          	addi	sp,sp,32
    2e60:	00008067          	ret
    2e64:	ffc00513          	li	a0,-4
    2e68:	fd5ff06f          	j	2e3c <append_fill+0xa4>

00002e6c <text>:
    2e6c:	0005c783          	lbu	a5,0(a1)
    2e70:	00079663          	bnez	a5,2e7c <text+0x10>
    2e74:	00050023          	sb	zero,0(a0)
    2e78:	00008067          	ret
    2e7c:	00150513          	addi	a0,a0,1
    2e80:	00158593          	addi	a1,a1,1
    2e84:	fef50fa3          	sb	a5,-1(a0)
    2e88:	fe5ff06f          	j	2e6c <text>

00002e8c <number>:
    2e8c:	ff010113          	addi	sp,sp,-16
    2e90:	00410713          	addi	a4,sp,4
    2e94:	00000793          	li	a5,0
    2e98:	00070813          	mv	a6,a4
    2e9c:	00a00613          	li	a2,10
    2ea0:	00900893          	li	a7,9
    2ea4:	02c5f6b3          	remu	a3,a1,a2
    2ea8:	00178793          	addi	a5,a5,1 # 2200001 <__gpu_framebuffer_a+0x200001>
    2eac:	00170713          	addi	a4,a4,1
    2eb0:	03068693          	addi	a3,a3,48
    2eb4:	fed70fa3          	sb	a3,-1(a4)
    2eb8:	00058693          	mv	a3,a1
    2ebc:	02c5d5b3          	divu	a1,a1,a2
    2ec0:	fed8e2e3          	bltu	a7,a3,2ea4 <number+0x18>
    2ec4:	00078713          	mv	a4,a5
    2ec8:	00050693          	mv	a3,a0
    2ecc:	fff70713          	addi	a4,a4,-1
    2ed0:	00e80633          	add	a2,a6,a4
    2ed4:	00064603          	lbu	a2,0(a2)
    2ed8:	00168693          	addi	a3,a3,1
    2edc:	fec68fa3          	sb	a2,-1(a3)
    2ee0:	fe0716e3          	bnez	a4,2ecc <number+0x40>
    2ee4:	00f50533          	add	a0,a0,a5
    2ee8:	00050023          	sb	zero,0(a0)
    2eec:	01010113          	addi	sp,sp,16
    2ef0:	00008067          	ret

00002ef4 <hud_set_logo_enabled>:
    2ef4:	00a03533          	snez	a0,a0
    2ef8:	82a18023          	sb	a0,-2016(gp) # e588 <logo_enabled>
    2efc:	00008067          	ret

00002f00 <hud_logo_fits>:
    2f00:	8201c703          	lbu	a4,-2016(gp) # e588 <logo_enabled>
    2f04:	00050793          	mv	a5,a0
    2f08:	00000513          	li	a0,0
    2f0c:	04070a63          	beqz	a4,2f60 <hud_logo_fits+0x60>
    2f10:	04078663          	beqz	a5,2f5c <hud_logo_fits+0x5c>
    2f14:	00078513          	mv	a0,a5
    2f18:	10078713          	addi	a4,a5,256
    2f1c:	04000693          	li	a3,64
    2f20:	00e00613          	li	a2,14
    2f24:	2f000593          	li	a1,752
    2f28:	00000793          	li	a5,0
    2f2c:	00c0006f          	j	2f38 <hud_logo_fits+0x38>
    2f30:	00178793          	addi	a5,a5,1
    2f34:	02d78863          	beq	a5,a3,2f64 <hud_logo_fits+0x64>
    2f38:	00f50833          	add	a6,a0,a5
    2f3c:	00084803          	lbu	a6,0(a6)
    2f40:	fe0818e3          	bnez	a6,2f30 <hud_logo_fits+0x30>
    2f44:	02c787b3          	mul	a5,a5,a2
    2f48:	00878793          	addi	a5,a5,8
    2f4c:	00f5ec63          	bltu	a1,a5,2f64 <hud_logo_fits+0x64>
    2f50:	04050513          	addi	a0,a0,64
    2f54:	fce51ae3          	bne	a0,a4,2f28 <hud_logo_fits+0x28>
    2f58:	00100513          	li	a0,1
    2f5c:	00008067          	ret
    2f60:	00008067          	ret
    2f64:	00000513          	li	a0,0
    2f68:	00008067          	ret

00002f6c <hud_comparison_text>:
    2f6c:	4e050463          	beqz	a0,3454 <hud_comparison_text+0x4e8>
    2f70:	f7010113          	addi	sp,sp,-144
    2f74:	08812423          	sw	s0,136(sp)
    2f78:	08912223          	sw	s1,132(sp)
    2f7c:	08112623          	sw	ra,140(sp)
    2f80:	09212023          	sw	s2,128(sp)
    2f84:	07312e23          	sw	s3,124(sp)
    2f88:	07412c23          	sw	s4,120(sp)
    2f8c:	07512a23          	sw	s5,116(sp)
    2f90:	07612823          	sw	s6,112(sp)
    2f94:	07712623          	sw	s7,108(sp)
    2f98:	07812423          	sw	s8,104(sp)
    2f9c:	07912223          	sw	s9,100(sp)
    2fa0:	07a12023          	sw	s10,96(sp)
    2fa4:	05b12e23          	sw	s11,92(sp)
    2fa8:	00050413          	mv	s0,a0
    2fac:	00058493          	mv	s1,a1
    2fb0:	ff800513          	li	a0,-8
    2fb4:	20058a63          	beqz	a1,31c8 <hud_comparison_text+0x25c>
    2fb8:	00042783          	lw	a5,0(s0)
    2fbc:	05f5ebb7          	lui	s7,0x5f5e
    2fc0:	000189b7          	lui	s3,0x18
    2fc4:	00f12e23          	sw	a5,28(sp)
    2fc8:	00442783          	lw	a5,4(s0)
    2fcc:	01c10b13          	addi	s6,sp,28
    2fd0:	02410a93          	addi	s5,sp,36
    2fd4:	02f12023          	sw	a5,32(sp)
    2fd8:	00842783          	lw	a5,8(s0)
    2fdc:	02c10a13          	addi	s4,sp,44
    2fe0:	00000913          	li	s2,0
    2fe4:	02f12223          	sw	a5,36(sp)
    2fe8:	00c42783          	lw	a5,12(s0)
    2fec:	0ffb8b93          	addi	s7,s7,255 # 5f5e0ff <__gpu_framebuffer_a+0x3f5e0ff>
    2ff0:	69f98993          	addi	s3,s3,1695 # 1869f <scene+0x4fdf>
    2ff4:	02f12423          	sw	a5,40(sp)
    2ff8:	01244783          	lbu	a5,18(s0)
    2ffc:	0000dc37          	lui	s8,0xd
    3000:	0000ddb7          	lui	s11,0xd
    3004:	02f12623          	sw	a5,44(sp)
    3008:	01344783          	lbu	a5,19(s0)
    300c:	02f12823          	sw	a5,48(sp)
    3010:	0000d7b7          	lui	a5,0xd
    3014:	38c78793          	addi	a5,a5,908 # d38c <_data+0xf8>
    3018:	00f12423          	sw	a5,8(sp)
    301c:	000aad03          	lw	s10,0(s5)
    3020:	01312223          	sw	s3,4(sp)
    3024:	000b2c83          	lw	s9,0(s6)
    3028:	01abe863          	bltu	s7,s10,3038 <hud_comparison_text+0xcc>
    302c:	3e800793          	li	a5,1000
    3030:	02fd57b3          	divu	a5,s10,a5
    3034:	00f12223          	sw	a5,4(sp)
    3038:	00691513          	slli	a0,s2,0x6
    303c:	00a48533          	add	a0,s1,a0
    3040:	1c090663          	beqz	s2,320c <hud_comparison_text+0x2a0>
    3044:	00812583          	lw	a1,8(sp)
    3048:	e25ff0ef          	jal	2e6c <text>
    304c:	000a2683          	lw	a3,0(s4)
    3050:	00050613          	mv	a2,a0
    3054:	1c068263          	beqz	a3,3218 <hud_comparison_text+0x2ac>
    3058:	000c8793          	mv	a5,s9
    305c:	0199f663          	bgeu	s3,s9,3068 <hud_comparison_text+0xfc>
    3060:	000187b7          	lui	a5,0x18
    3064:	69f78793          	addi	a5,a5,1695 # 1869f <scene+0x4fdf>
    3068:	00a00c93          	li	s9,10
    306c:	0397d5b3          	divu	a1,a5,s9
    3070:	00060513          	mv	a0,a2
    3074:	00f12623          	sw	a5,12(sp)
    3078:	e15ff0ef          	jal	2e8c <number>
    307c:	41cc0593          	addi	a1,s8,1052 # d41c <_data+0x188>
    3080:	dedff0ef          	jal	2e6c <text>
    3084:	00c12783          	lw	a5,12(sp)
    3088:	0397f5b3          	remu	a1,a5,s9
    308c:	e01ff0ef          	jal	2e8c <number>
    3090:	420d8593          	addi	a1,s11,1056 # d420 <_data+0x18c>
    3094:	dd9ff0ef          	jal	2e6c <text>
    3098:	00412583          	lw	a1,4(sp)
    309c:	df1ff0ef          	jal	2e8c <number>
    30a0:	41cc0593          	addi	a1,s8,1052
    30a4:	dc9ff0ef          	jal	2e6c <text>
    30a8:	06400793          	li	a5,100
    30ac:	02fd55b3          	divu	a1,s10,a5
    30b0:	0395f5b3          	remu	a1,a1,s9
    30b4:	dd9ff0ef          	jal	2e8c <number>
    30b8:	02091063          	bnez	s2,30d8 <hud_comparison_text+0x16c>
    30bc:	02a44783          	lbu	a5,42(s0)
    30c0:	00078c63          	beqz	a5,30d8 <hud_comparison_text+0x16c>
    30c4:	02b44783          	lbu	a5,43(s0)
    30c8:	00078863          	beqz	a5,30d8 <hud_comparison_text+0x16c>
    30cc:	0000d5b7          	lui	a1,0xd
    30d0:	43058593          	addi	a1,a1,1072 # d430 <_data+0x19c>
    30d4:	d99ff0ef          	jal	2e6c <text>
    30d8:	004b0b13          	addi	s6,s6,4
    30dc:	004a8a93          	addi	s5,s5,4
    30e0:	004a0a13          	addi	s4,s4,4
    30e4:	12090063          	beqz	s2,3204 <hud_comparison_text+0x298>
    30e8:	02a44703          	lbu	a4,42(s0)
    30ec:	00500793          	li	a5,5
    30f0:	08048513          	addi	a0,s1,128
    30f4:	0c048493          	addi	s1,s1,192
    30f8:	12f71663          	bne	a4,a5,3224 <hud_comparison_text+0x2b8>
    30fc:	0000d5b7          	lui	a1,0xd
    3100:	44c58593          	addi	a1,a1,1100 # d44c <_data+0x1b8>
    3104:	d69ff0ef          	jal	2e6c <text>
    3108:	01045583          	lhu	a1,16(s0)
    310c:	d81ff0ef          	jal	2e8c <number>
    3110:	0000d5b7          	lui	a1,0xd
    3114:	46058593          	addi	a1,a1,1120 # d460 <_data+0x1cc>
    3118:	d55ff0ef          	jal	2e6c <text>
    311c:	02445583          	lhu	a1,36(s0)
    3120:	d6dff0ef          	jal	2e8c <number>
    3124:	0000d5b7          	lui	a1,0xd
    3128:	46858593          	addi	a1,a1,1128 # d468 <_data+0x1d4>
    312c:	d41ff0ef          	jal	2e6c <text>
    3130:	01045583          	lhu	a1,16(s0)
    3134:	d59ff0ef          	jal	2e8c <number>
    3138:	0000e5b7          	lui	a1,0xe
    313c:	01c00613          	li	a2,28
    3140:	c3858593          	addi	a1,a1,-968 # dc38 <comparison_letters+0xb8>
    3144:	03410513          	addi	a0,sp,52
    3148:	9bcfe0ef          	jal	1304 <memcpy>
    314c:	03244783          	lbu	a5,50(s0)
    3150:	00600713          	li	a4,6
    3154:	00f77463          	bgeu	a4,a5,315c <hud_comparison_text+0x1f0>
    3158:	00000793          	li	a5,0
    315c:	00279793          	slli	a5,a5,0x2
    3160:	01010713          	addi	a4,sp,16
    3164:	04078793          	addi	a5,a5,64
    3168:	00e787b3          	add	a5,a5,a4
    316c:	fe47a583          	lw	a1,-28(a5)
    3170:	00048513          	mv	a0,s1
    3174:	cf9ff0ef          	jal	2e6c <text>
    3178:	03244683          	lbu	a3,50(s0)
    317c:	00300713          	li	a4,3
    3180:	00050793          	mv	a5,a0
    3184:	00d76e63          	bltu	a4,a3,31a0 <hud_comparison_text+0x234>
    3188:	0000d5b7          	lui	a1,0xd
    318c:	47058593          	addi	a1,a1,1136 # d470 <_data+0x1dc>
    3190:	cddff0ef          	jal	2e6c <text>
    3194:	03045583          	lhu	a1,48(s0)
    3198:	cf5ff0ef          	jal	2e8c <number>
    319c:	00050793          	mv	a5,a0
    31a0:	0000d5b7          	lui	a1,0xd
    31a4:	47458593          	addi	a1,a1,1140 # d474 <_data+0x1e0>
    31a8:	00078513          	mv	a0,a5
    31ac:	cc1ff0ef          	jal	2e6c <text>
    31b0:	02e45583          	lhu	a1,46(s0)
    31b4:	cd9ff0ef          	jal	2e8c <number>
    31b8:	0000d5b7          	lui	a1,0xd
    31bc:	47c58593          	addi	a1,a1,1148 # d47c <_data+0x1e8>
    31c0:	cadff0ef          	jal	2e6c <text>
    31c4:	00000513          	li	a0,0
    31c8:	08c12083          	lw	ra,140(sp)
    31cc:	08812403          	lw	s0,136(sp)
    31d0:	08412483          	lw	s1,132(sp)
    31d4:	08012903          	lw	s2,128(sp)
    31d8:	07c12983          	lw	s3,124(sp)
    31dc:	07812a03          	lw	s4,120(sp)
    31e0:	07412a83          	lw	s5,116(sp)
    31e4:	07012b03          	lw	s6,112(sp)
    31e8:	06c12b83          	lw	s7,108(sp)
    31ec:	06812c03          	lw	s8,104(sp)
    31f0:	06412c83          	lw	s9,100(sp)
    31f4:	06012d03          	lw	s10,96(sp)
    31f8:	05c12d83          	lw	s11,92(sp)
    31fc:	09010113          	addi	sp,sp,144
    3200:	00008067          	ret
    3204:	00100913          	li	s2,1
    3208:	e15ff06f          	j	301c <hud_comparison_text+0xb0>
    320c:	0000d5b7          	lui	a1,0xd
    3210:	39858593          	addi	a1,a1,920 # d398 <_data+0x104>
    3214:	e35ff06f          	j	3048 <hud_comparison_text+0xdc>
    3218:	0000d7b7          	lui	a5,0xd
    321c:	43878593          	addi	a1,a5,1080 # d438 <_data+0x1a4>
    3220:	eb5ff06f          	j	30d4 <hud_comparison_text+0x168>
    3224:	01444783          	lbu	a5,20(s0)
    3228:	0a078e63          	beqz	a5,32e4 <hud_comparison_text+0x378>
    322c:	0000d5b7          	lui	a1,0xd
    3230:	3a458593          	addi	a1,a1,932 # d3a4 <_data+0x110>
    3234:	c39ff0ef          	jal	2e6c <text>
    3238:	02a44783          	lbu	a5,42(s0)
    323c:	02078063          	beqz	a5,325c <hud_comparison_text+0x2f0>
    3240:	00400713          	li	a4,4
    3244:	0ae78663          	beq	a5,a4,32f0 <hud_comparison_text+0x384>
    3248:	00100713          	li	a4,1
    324c:	0ae79863          	bne	a5,a4,32fc <hud_comparison_text+0x390>
    3250:	0000d5b7          	lui	a1,0xd
    3254:	3cc58593          	addi	a1,a1,972 # d3cc <_data+0x138>
    3258:	c15ff0ef          	jal	2e6c <text>
    325c:	01644783          	lbu	a5,22(s0)
    3260:	0a078463          	beqz	a5,3308 <hud_comparison_text+0x39c>
    3264:	0000d5b7          	lui	a1,0xd
    3268:	3d458593          	addi	a1,a1,980 # d3d4 <_data+0x140>
    326c:	c01ff0ef          	jal	2e6c <text>
    3270:	01045583          	lhu	a1,16(s0)
    3274:	c19ff0ef          	jal	2e8c <number>
    3278:	01644703          	lbu	a4,22(s0)
    327c:	00050793          	mv	a5,a0
    3280:	02070263          	beqz	a4,32a4 <hud_comparison_text+0x338>
    3284:	02644703          	lbu	a4,38(s0)
    3288:	00070e63          	beqz	a4,32a4 <hud_comparison_text+0x338>
    328c:	0000d5b7          	lui	a1,0xd
    3290:	46058593          	addi	a1,a1,1120 # d460 <_data+0x1cc>
    3294:	bd9ff0ef          	jal	2e6c <text>
    3298:	02445583          	lhu	a1,36(s0)
    329c:	bf1ff0ef          	jal	2e8c <number>
    32a0:	00050793          	mv	a5,a0
    32a4:	0000d5b7          	lui	a1,0xd
    32a8:	00078513          	mv	a0,a5
    32ac:	49058593          	addi	a1,a1,1168 # d490 <_data+0x1fc>
    32b0:	bbdff0ef          	jal	2e6c <text>
    32b4:	01544783          	lbu	a5,21(s0)
    32b8:	04078e63          	beqz	a5,3314 <hud_comparison_text+0x3a8>
    32bc:	0000e5b7          	lui	a1,0xe
    32c0:	a2058593          	addi	a1,a1,-1504 # da20 <_data+0x78c>
    32c4:	ba9ff0ef          	jal	2e6c <text>
    32c8:	02a44703          	lbu	a4,42(s0)
    32cc:	00400793          	li	a5,4
    32d0:	04f71863          	bne	a4,a5,3320 <hud_comparison_text+0x3b4>
    32d4:	0000d5b7          	lui	a1,0xd
    32d8:	49858593          	addi	a1,a1,1176 # d498 <_data+0x204>
    32dc:	00048513          	mv	a0,s1
    32e0:	ee1ff06f          	j	31c0 <hud_comparison_text+0x254>
    32e4:	0000d5b7          	lui	a1,0xd
    32e8:	3b058593          	addi	a1,a1,944 # d3b0 <_data+0x11c>
    32ec:	f49ff06f          	j	3234 <hud_comparison_text+0x2c8>
    32f0:	0000d5b7          	lui	a1,0xd
    32f4:	3c458593          	addi	a1,a1,964 # d3c4 <_data+0x130>
    32f8:	f61ff06f          	j	3258 <hud_comparison_text+0x2ec>
    32fc:	0000d5b7          	lui	a1,0xd
    3300:	3bc58593          	addi	a1,a1,956 # d3bc <_data+0x128>
    3304:	f55ff06f          	j	3258 <hud_comparison_text+0x2ec>
    3308:	0000d5b7          	lui	a1,0xd
    330c:	3e058593          	addi	a1,a1,992 # d3e0 <_data+0x14c>
    3310:	f5dff06f          	j	326c <hud_comparison_text+0x300>
    3314:	0000d5b7          	lui	a1,0xd
    3318:	3e458593          	addi	a1,a1,996 # d3e4 <_data+0x150>
    331c:	fa9ff06f          	j	32c4 <hud_comparison_text+0x358>
    3320:	01644783          	lbu	a5,22(s0)
    3324:	12078263          	beqz	a5,3448 <hud_comparison_text+0x4dc>
    3328:	02644783          	lbu	a5,38(s0)
    332c:	0000d937          	lui	s2,0xd
    3330:	0e078263          	beqz	a5,3414 <hud_comparison_text+0x4a8>
    3334:	0000d5b7          	lui	a1,0xd
    3338:	4c458593          	addi	a1,a1,1220 # d4c4 <_data+0x230>
    333c:	00048513          	mv	a0,s1
    3340:	b2dff0ef          	jal	2e6c <text>
    3344:	02744583          	lbu	a1,39(s0)
    3348:	b45ff0ef          	jal	2e8c <number>
    334c:	0000d5b7          	lui	a1,0xd
    3350:	4c858593          	addi	a1,a1,1224 # d4c8 <_data+0x234>
    3354:	b19ff0ef          	jal	2e6c <text>
    3358:	01c42583          	lw	a1,28(s0)
    335c:	000f47b7          	lui	a5,0xf4
    3360:	23f78793          	addi	a5,a5,575 # f423f <__freertos_irq_stack_top+0xd67bf>
    3364:	00b7f463          	bgeu	a5,a1,336c <hud_comparison_text+0x400>
    3368:	00078593          	mv	a1,a5
    336c:	b21ff0ef          	jal	2e8c <number>
    3370:	0000d5b7          	lui	a1,0xd
    3374:	4d058593          	addi	a1,a1,1232 # d4d0 <_data+0x23c>
    3378:	af5ff0ef          	jal	2e6c <text>
    337c:	02042583          	lw	a1,32(s0)
    3380:	000027b7          	lui	a5,0x2
    3384:	70f78793          	addi	a5,a5,1807 # 270f <blit_pair_validate+0x7f>
    3388:	00b7f463          	bgeu	a5,a1,3390 <hud_comparison_text+0x424>
    338c:	00078593          	mv	a1,a5
    3390:	afdff0ef          	jal	2e8c <number>
    3394:	0000d5b7          	lui	a1,0xd
    3398:	4d858593          	addi	a1,a1,1240 # d4d8 <_data+0x244>
    339c:	ad1ff0ef          	jal	2e6c <text>
    33a0:	01842583          	lw	a1,24(s0)
    33a4:	ae9ff0ef          	jal	2e8c <number>
    33a8:	4e090593          	addi	a1,s2,1248 # d4e0 <_data+0x24c>
    33ac:	ac1ff0ef          	jal	2e6c <text>
    33b0:	01744583          	lbu	a1,23(s0)
    33b4:	ad9ff0ef          	jal	2e8c <number>
    33b8:	02944783          	lbu	a5,41(s0)
    33bc:	02079463          	bnez	a5,33e4 <hud_comparison_text+0x478>
    33c0:	02844783          	lbu	a5,40(s0)
    33c4:	02079663          	bnez	a5,33f0 <hud_comparison_text+0x484>
    33c8:	02a44783          	lbu	a5,42(s0)
    33cc:	02078863          	beqz	a5,33fc <hud_comparison_text+0x490>
    33d0:	02c44783          	lbu	a5,44(s0)
    33d4:	02078a63          	beqz	a5,3408 <hud_comparison_text+0x49c>
    33d8:	0000d5b7          	lui	a1,0xd
    33dc:	41458593          	addi	a1,a1,1044 # d414 <_data+0x180>
    33e0:	de1ff06f          	j	31c0 <hud_comparison_text+0x254>
    33e4:	0000d5b7          	lui	a1,0xd
    33e8:	3fc58593          	addi	a1,a1,1020 # d3fc <_data+0x168>
    33ec:	dd5ff06f          	j	31c0 <hud_comparison_text+0x254>
    33f0:	0000d5b7          	lui	a1,0xd
    33f4:	3f458593          	addi	a1,a1,1012 # d3f4 <_data+0x160>
    33f8:	dc9ff06f          	j	31c0 <hud_comparison_text+0x254>
    33fc:	0000d5b7          	lui	a1,0xd
    3400:	40458593          	addi	a1,a1,1028 # d404 <_data+0x170>
    3404:	dbdff06f          	j	31c0 <hud_comparison_text+0x254>
    3408:	0000d5b7          	lui	a1,0xd
    340c:	40c58593          	addi	a1,a1,1036 # d40c <_data+0x178>
    3410:	db1ff06f          	j	31c0 <hud_comparison_text+0x254>
    3414:	0000d5b7          	lui	a1,0xd
    3418:	4e858593          	addi	a1,a1,1256 # d4e8 <_data+0x254>
    341c:	00048513          	mv	a0,s1
    3420:	a4dff0ef          	jal	2e6c <text>
    3424:	01842583          	lw	a1,24(s0)
    3428:	a65ff0ef          	jal	2e8c <number>
    342c:	4e090593          	addi	a1,s2,1248
    3430:	a3dff0ef          	jal	2e6c <text>
    3434:	01744583          	lbu	a1,23(s0)
    3438:	a55ff0ef          	jal	2e8c <number>
    343c:	0000d5b7          	lui	a1,0xd
    3440:	4f058593          	addi	a1,a1,1264 # d4f0 <_data+0x25c>
    3444:	d7dff06f          	j	31c0 <hud_comparison_text+0x254>
    3448:	0000d5b7          	lui	a1,0xd
    344c:	50858593          	addi	a1,a1,1288 # d508 <_data+0x274>
    3450:	e8dff06f          	j	32dc <hud_comparison_text+0x370>
    3454:	ff800513          	li	a0,-8
    3458:	00008067          	ret

0000345c <hud_build_comparison>:
    345c:	ea010113          	addi	sp,sp,-352
    3460:	15212823          	sw	s2,336(sp)
    3464:	14112e23          	sw	ra,348(sp)
    3468:	14812c23          	sw	s0,344(sp)
    346c:	14912a23          	sw	s1,340(sp)
    3470:	15312623          	sw	s3,332(sp)
    3474:	15412423          	sw	s4,328(sp)
    3478:	15512223          	sw	s5,324(sp)
    347c:	15612023          	sw	s6,320(sp)
    3480:	13712e23          	sw	s7,316(sp)
    3484:	13812c23          	sw	s8,312(sp)
    3488:	13912a23          	sw	s9,308(sp)
    348c:	13a12823          	sw	s10,304(sp)
    3490:	13b12623          	sw	s11,300(sp)
    3494:	ff800913          	li	s2,-8
    3498:	28060263          	beqz	a2,371c <hud_build_comparison+0x2c0>
    349c:	ffe007b7          	lui	a5,0xffe00
    34a0:	fff78793          	addi	a5,a5,-1 # ffdfffff <__gpu_framebuffer_a+0xfddfffff>
    34a4:	00f577b3          	and	a5,a0,a5
    34a8:	02000737          	lui	a4,0x2000
    34ac:	00050993          	mv	s3,a0
    34b0:	ff800913          	li	s2,-8
    34b4:	26e79463          	bne	a5,a4,371c <hud_build_comparison+0x2c0>
    34b8:	00058513          	mv	a0,a1
    34bc:	02010593          	addi	a1,sp,32
    34c0:	00060413          	mv	s0,a2
    34c4:	aa9ff0ef          	jal	2f6c <hud_comparison_text>
    34c8:	00050913          	mv	s2,a0
    34cc:	24051863          	bnez	a0,371c <hud_build_comparison+0x2c0>
    34d0:	000087b7          	lui	a5,0x8
    34d4:	00f407b3          	add	a5,s0,a5
    34d8:	00100493          	li	s1,1
    34dc:	00979023          	sh	s1,0(a5) # 8000 <game_update_cached+0xec>
    34e0:	02000613          	li	a2,32
    34e4:	00000593          	li	a1,0
    34e8:	00040513          	mv	a0,s0
    34ec:	d3dfd0ef          	jal	1228 <memset>
    34f0:	78000793          	li	a5,1920
    34f4:	00f42623          	sw	a5,12(s0)
    34f8:	004807b7          	lui	a5,0x480
    34fc:	3c078793          	addi	a5,a5,960 # 4803c0 <__freertos_irq_stack_top+0x462940>
    3500:	0000eeb7          	lui	t4,0xe
    3504:	0000ef37          	lui	t5,0xe
    3508:	01342223          	sw	s3,4(s0)
    350c:	00f42823          	sw	a5,16(s0)
    3510:	00940e23          	sb	s1,28(s0)
    3514:	02010e13          	addi	t3,sp,32
    3518:	00000b93          	li	s7,0
    351c:	b38e8e93          	addi	t4,t4,-1224 # db38 <comparison_digits>
    3520:	b80f0f13          	addi	t5,t5,-1152 # db80 <comparison_letters>
    3524:	ffeb8793          	addi	a5,s7,-2
    3528:	fff00c13          	li	s8,-1
    352c:	00079463          	bnez	a5,3534 <hud_build_comparison+0xd8>
    3530:	7e000c13          	li	s8,2016
    3534:	01200a13          	li	s4,18
    3538:	034b8a33          	mul	s4,s7,s4
    353c:	010c1793          	slli	a5,s8,0x10
    3540:	0107d793          	srli	a5,a5,0x10
    3544:	00f12223          	sw	a5,4(sp)
    3548:	000e0c13          	mv	s8,t3
    354c:	00400b13          	li	s6,4
    3550:	003a0a13          	addi	s4,s4,3
    3554:	010a1a13          	slli	s4,s4,0x10
    3558:	010a5a13          	srli	s4,s4,0x10
    355c:	2500006f          	j	37ac <hud_build_comparison+0x350>
    3560:	00700613          	li	a2,7
    3564:	02c70633          	mul	a2,a4,a2
    3568:	fbf70593          	addi	a1,a4,-65 # 1ffffbf <__freertos_irq_stack_top+0x1fe253f>
    356c:	fd070513          	addi	a0,a4,-48
    3570:	00000693          	li	a3,0
    3574:	0ff5f593          	zext.b	a1,a1
    3578:	01900f93          	li	t6,25
    357c:	0ff57513          	zext.b	a0,a0
    3580:	00900293          	li	t0,9
    3584:	02d00393          	li	t2,45
    3588:	02e00493          	li	s1,46
    358c:	00700813          	li	a6,7
    3590:	04bfe463          	bltu	t6,a1,35d8 <hud_build_comparison+0x17c>
    3594:	01e607b3          	add	a5,a2,t5
    3598:	e397c783          	lbu	a5,-455(a5)
    359c:	01810893          	addi	a7,sp,24
    35a0:	00d888b3          	add	a7,a7,a3
    35a4:	00f88023          	sb	a5,0(a7)
    35a8:	00168693          	addi	a3,a3,1
    35ac:	00160613          	addi	a2,a2,1
    35b0:	ff0690e3          	bne	a3,a6,3590 <hud_build_comparison+0x134>
    35b4:	01810c93          	addi	s9,sp,24
    35b8:	000a0713          	mv	a4,s4
    35bc:	00000a93          	li	s5,0
    35c0:	01000d13          	li	s10,16
    35c4:	00500d93          	li	s11,5
    35c8:	00100293          	li	t0,1
    35cc:	00000693          	li	a3,0
    35d0:	00700f93          	li	t6,7
    35d4:	0480006f          	j	361c <hud_build_comparison+0x1c0>
    35d8:	00a2e863          	bltu	t0,a0,35e8 <hud_build_comparison+0x18c>
    35dc:	01d607b3          	add	a5,a2,t4
    35e0:	eb07c783          	lbu	a5,-336(a5)
    35e4:	fb9ff06f          	j	359c <hud_build_comparison+0x140>
    35e8:	00771c63          	bne	a4,t2,3600 <hud_build_comparison+0x1a4>
    35ec:	00300893          	li	a7,3
    35f0:	00e00793          	li	a5,14
    35f4:	fb1684e3          	beq	a3,a7,359c <hud_build_comparison+0x140>
    35f8:	00000793          	li	a5,0
    35fc:	fa1ff06f          	j	359c <hud_build_comparison+0x140>
    3600:	00000793          	li	a5,0
    3604:	f8971ce3          	bne	a4,s1,359c <hud_build_comparison+0x140>
    3608:	ffa68793          	addi	a5,a3,-6
    360c:	0017b793          	seqz	a5,a5
    3610:	00279793          	slli	a5,a5,0x2
    3614:	f89ff06f          	j	359c <hud_build_comparison+0x140>
    3618:	00048693          	mv	a3,s1
    361c:	000cc603          	lbu	a2,0(s9)
    3620:	00dd57b3          	srl	a5,s10,a3
    3624:	00168493          	addi	s1,a3,1
    3628:	00c7f7b3          	and	a5,a5,a2
    362c:	14078863          	beqz	a5,377c <hud_build_comparison+0x320>
    3630:	00068493          	mv	s1,a3
    3634:	00148493          	addi	s1,s1,1
    3638:	01b48863          	beq	s1,s11,3648 <hud_build_comparison+0x1ec>
    363c:	009d57b3          	srl	a5,s10,s1
    3640:	00c7f7b3          	and	a5,a5,a2
    3644:	fe0798e3          	bnez	a5,3634 <hud_build_comparison+0x1d8>
    3648:	40d487b3          	sub	a5,s1,a3
    364c:	00f29633          	sll	a2,t0,a5
    3650:	409d85b3          	sub	a1,s11,s1
    3654:	fff60613          	addi	a2,a2,-1
    3658:	00b61633          	sll	a2,a2,a1
    365c:	001a8813          	addi	a6,s5,1
    3660:	00000593          	li	a1,0
    3664:	00068663          	beqz	a3,3670 <hud_build_comparison+0x214>
    3668:	fff68593          	addi	a1,a3,-1
    366c:	00bd55b3          	srl	a1,s10,a1
    3670:	00000513          	li	a0,0
    3674:	01b48463          	beq	s1,s11,367c <hud_build_comparison+0x220>
    3678:	009d5533          	srl	a0,s10,s1
    367c:	00a5e5b3          	or	a1,a1,a0
    3680:	00b665b3          	or	a1,a2,a1
    3684:	01f80c63          	beq	a6,t6,369c <hud_build_comparison+0x240>
    3688:	01810513          	addi	a0,sp,24
    368c:	01050533          	add	a0,a0,a6
    3690:	00054503          	lbu	a0,0(a0)
    3694:	00b57533          	and	a0,a0,a1
    3698:	0cc50263          	beq	a0,a2,375c <hud_build_comparison+0x300>
    369c:	000c8593          	mv	a1,s9
    36a0:	000a8513          	mv	a0,s5
    36a4:	fff64613          	not	a2,a2
    36a8:	0b056e63          	bltu	a0,a6,3764 <hud_build_comparison+0x308>
    36ac:	41580833          	sub	a6,a6,s5
    36b0:	00db06b3          	add	a3,s6,a3
    36b4:	00412883          	lw	a7,4(sp)
    36b8:	00181813          	slli	a6,a6,0x1
    36bc:	00179793          	slli	a5,a5,0x1
    36c0:	00169693          	slli	a3,a3,0x1
    36c4:	01081813          	slli	a6,a6,0x10
    36c8:	01079793          	slli	a5,a5,0x10
    36cc:	01069693          	slli	a3,a3,0x10
    36d0:	0107d793          	srli	a5,a5,0x10
    36d4:	01085813          	srli	a6,a6,0x10
    36d8:	0106d693          	srli	a3,a3,0x10
    36dc:	78000613          	li	a2,1920
    36e0:	00098593          	mv	a1,s3
    36e4:	00040513          	mv	a0,s0
    36e8:	01c12623          	sw	t3,12(sp)
    36ec:	00e12423          	sw	a4,8(sp)
    36f0:	ea8ff0ef          	jal	2d98 <append_fill>
    36f4:	0000e7b7          	lui	a5,0xe
    36f8:	b3878e93          	addi	t4,a5,-1224 # db38 <comparison_digits>
    36fc:	0000e7b7          	lui	a5,0xe
    3700:	00812703          	lw	a4,8(sp)
    3704:	00c12e03          	lw	t3,12(sp)
    3708:	00100293          	li	t0,1
    370c:	00700f93          	li	t6,7
    3710:	b8078f13          	addi	t5,a5,-1152 # db80 <comparison_letters>
    3714:	06050463          	beqz	a0,377c <hud_build_comparison+0x320>
    3718:	00050913          	mv	s2,a0
    371c:	15c12083          	lw	ra,348(sp)
    3720:	15812403          	lw	s0,344(sp)
    3724:	15412483          	lw	s1,340(sp)
    3728:	14c12983          	lw	s3,332(sp)
    372c:	14812a03          	lw	s4,328(sp)
    3730:	14412a83          	lw	s5,324(sp)
    3734:	14012b03          	lw	s6,320(sp)
    3738:	13c12b83          	lw	s7,316(sp)
    373c:	13812c03          	lw	s8,312(sp)
    3740:	13412c83          	lw	s9,308(sp)
    3744:	13012d03          	lw	s10,304(sp)
    3748:	12c12d83          	lw	s11,300(sp)
    374c:	00090513          	mv	a0,s2
    3750:	15012903          	lw	s2,336(sp)
    3754:	16010113          	addi	sp,sp,352
    3758:	00008067          	ret
    375c:	00180813          	addi	a6,a6,1
    3760:	f25ff06f          	j	3684 <hud_build_comparison+0x228>
    3764:	0005c883          	lbu	a7,0(a1)
    3768:	00150513          	addi	a0,a0,1
    376c:	00158593          	addi	a1,a1,1
    3770:	00c8f8b3          	and	a7,a7,a2
    3774:	ff158fa3          	sb	a7,-1(a1)
    3778:	f31ff06f          	j	36a8 <hud_build_comparison+0x24c>
    377c:	e9b49ee3          	bne	s1,s11,3618 <hud_build_comparison+0x1bc>
    3780:	00270713          	addi	a4,a4,2
    3784:	01071713          	slli	a4,a4,0x10
    3788:	001a8a93          	addi	s5,s5,1
    378c:	00700793          	li	a5,7
    3790:	01075713          	srli	a4,a4,0x10
    3794:	001c8c93          	addi	s9,s9,1
    3798:	e2fa9ae3          	bne	s5,a5,35cc <hud_build_comparison+0x170>
    379c:	007b0b13          	addi	s6,s6,7
    37a0:	010b1b13          	slli	s6,s6,0x10
    37a4:	001c0c13          	addi	s8,s8,1
    37a8:	010b5b13          	srli	s6,s6,0x10
    37ac:	000c4703          	lbu	a4,0(s8)
    37b0:	da0718e3          	bnez	a4,3560 <hud_build_comparison+0x104>
    37b4:	001b8b93          	addi	s7,s7,1
    37b8:	00400793          	li	a5,4
    37bc:	040e0e13          	addi	t3,t3,64
    37c0:	d6fb92e3          	bne	s7,a5,3524 <hud_build_comparison+0xc8>
    37c4:	02010513          	addi	a0,sp,32
    37c8:	f38ff0ef          	jal	2f00 <hud_logo_fits>
    37cc:	f40508e3          	beqz	a0,371c <hud_build_comparison+0x2c0>
    37d0:	00008737          	lui	a4,0x8
    37d4:	00e40733          	add	a4,s0,a4
    37d8:	00075783          	lhu	a5,0(a4) # 8000 <game_update_cached+0xec>
    37dc:	3ff00693          	li	a3,1023
    37e0:	06f6e263          	bltu	a3,a5,3844 <hud_build_comparison+0x3e8>
    37e4:	00178693          	addi	a3,a5,1
    37e8:	00579793          	slli	a5,a5,0x5
    37ec:	00f40433          	add	s0,s0,a5
    37f0:	00d71023          	sh	a3,0(a4)
    37f4:	02000613          	li	a2,32
    37f8:	00000593          	li	a1,0
    37fc:	00040513          	mv	a0,s0
    3800:	a29fd0ef          	jal	1228 <memset>
    3804:	02c507b7          	lui	a5,0x2c50
    3808:	00f42023          	sw	a5,0(s0)
    380c:	000017b7          	lui	a5,0x1
    3810:	d6078793          	addi	a5,a5,-672 # d60 <CUSTOM2+0xd05>
    3814:	00f989b3          	add	s3,s3,a5
    3818:	19000793          	li	a5,400
    381c:	00f42423          	sw	a5,8(s0)
    3820:	78000793          	li	a5,1920
    3824:	00f42623          	sw	a5,12(s0)
    3828:	004607b7          	lui	a5,0x460
    382c:	0c878793          	addi	a5,a5,200 # 4600c8 <__freertos_irq_stack_top+0x442648>
    3830:	00f42823          	sw	a5,16(s0)
    3834:	00200793          	li	a5,2
    3838:	01342223          	sw	s3,4(s0)
    383c:	00f40e23          	sb	a5,28(s0)
    3840:	eddff06f          	j	371c <hud_build_comparison+0x2c0>
    3844:	ffc00913          	li	s2,-4
    3848:	ed5ff06f          	j	371c <hud_build_comparison+0x2c0>

0000384c <hud_init_glyph_atlas>:
    384c:	fe010113          	addi	sp,sp,-32
    3850:	00010337          	lui	t1,0x10
    3854:	00005537          	lui	a0,0x5
    3858:	02c4ae37          	lui	t3,0x2c4a
    385c:	00812e23          	sw	s0,28(sp)
    3860:	00912c23          	sw	s1,24(sp)
    3864:	01212a23          	sw	s2,20(sp)
    3868:	01312823          	sw	s3,16(sp)
    386c:	01412623          	sw	s4,12(sp)
    3870:	01512423          	sw	s5,8(sp)
    3874:	00000893          	li	a7,0
    3878:	02c407b7          	lui	a5,0x2c40
    387c:	0000dfb7          	lui	t6,0xd
    3880:	00d00293          	li	t0,13
    3884:	00900393          	li	t2,9
    3888:	01000913          	li	s2,16
    388c:	fff30313          	addi	t1,t1,-1 # ffff <__global_pointer$+0x1297>
    3890:	00e00413          	li	s0,14
    3894:	00f00493          	li	s1,15
    3898:	cc850513          	addi	a0,a0,-824 # 4cc8 <perf_window_add+0x78>
    389c:	990e0e13          	addi	t3,t3,-1648 # 2c49990 <__gpu_framebuffer_a+0xc49990>
    38a0:	538f8813          	addi	a6,t6,1336 # d538 <_data+0x2a4>
    38a4:	00a78f33          	add	t5,a5,a0
    38a8:	00084583          	lbu	a1,0(a6)
    38ac:	00078e93          	mv	t4,a5
    38b0:	ffd00613          	li	a2,-3
    38b4:	00000693          	li	a3,0
    38b8:	02c2ea63          	bltu	t0,a2,38ec <hud_init_glyph_atlas+0xa0>
    38bc:	fbf58993          	addi	s3,a1,-65
    38c0:	0ff9fa93          	zext.b	s5,s3
    38c4:	01900a13          	li	s4,25
    38c8:	00165713          	srli	a4,a2,0x1
    38cc:	095a6e63          	bltu	s4,s5,3968 <hud_init_glyph_atlas+0x11c>
    38d0:	00700a13          	li	s4,7
    38d4:	034989b3          	mul	s3,s3,s4
    38d8:	0000e6b7          	lui	a3,0xe
    38dc:	b8068693          	addi	a3,a3,-1152 # db80 <comparison_letters>
    38e0:	013686b3          	add	a3,a3,s3
    38e4:	00e68733          	add	a4,a3,a4
    38e8:	00074683          	lbu	a3,0(a4)
    38ec:	00000713          	li	a4,0
    38f0:	00000a13          	li	s4,0
    38f4:	02e3e063          	bltu	t2,a4,3914 <hud_init_glyph_atlas+0xc8>
    38f8:	00175993          	srli	s3,a4,0x1
    38fc:	013959b3          	srl	s3,s2,s3
    3900:	00d9f9b3          	and	s3,s3,a3
    3904:	00098863          	beqz	s3,3914 <hud_init_glyph_atlas+0xc8>
    3908:	00030a13          	mv	s4,t1
    390c:	00088463          	beqz	a7,3914 <hud_init_glyph_atlas+0xc8>
    3910:	7e000a13          	li	s4,2016
    3914:	00171993          	slli	s3,a4,0x1
    3918:	013e89b3          	add	s3,t4,s3
    391c:	01499023          	sh	s4,0(s3)
    3920:	00170713          	addi	a4,a4,1
    3924:	fc8716e3          	bne	a4,s0,38f0 <hud_init_glyph_atlas+0xa4>
    3928:	00160613          	addi	a2,a2,1
    392c:	01ce8e93          	addi	t4,t4,28
    3930:	f89612e3          	bne	a2,s1,38b4 <hud_init_glyph_atlas+0x68>
    3934:	1f878793          	addi	a5,a5,504 # 2c401f8 <__gpu_framebuffer_a+0xc401f8>
    3938:	00180813          	addi	a6,a6,1
    393c:	f7e796e3          	bne	a5,t5,38a8 <hud_init_glyph_atlas+0x5c>
    3940:	00188893          	addi	a7,a7,1
    3944:	f5c79ee3          	bne	a5,t3,38a0 <hud_init_glyph_atlas+0x54>
    3948:	01c12403          	lw	s0,28(sp)
    394c:	01812483          	lw	s1,24(sp)
    3950:	01412903          	lw	s2,20(sp)
    3954:	01012983          	lw	s3,16(sp)
    3958:	00c12a03          	lw	s4,12(sp)
    395c:	00812a83          	lw	s5,8(sp)
    3960:	02010113          	addi	sp,sp,32
    3964:	00008067          	ret
    3968:	fd058993          	addi	s3,a1,-48
    396c:	0ff9fa93          	zext.b	s5,s3
    3970:	00900a13          	li	s4,9
    3974:	015a6c63          	bltu	s4,s5,398c <hud_init_glyph_atlas+0x140>
    3978:	0000e6b7          	lui	a3,0xe
    397c:	00700a13          	li	s4,7
    3980:	034989b3          	mul	s3,s3,s4
    3984:	b3868693          	addi	a3,a3,-1224 # db38 <comparison_digits>
    3988:	f59ff06f          	j	38e0 <hud_init_glyph_atlas+0x94>
    398c:	02d00993          	li	s3,45
    3990:	01359a63          	bne	a1,s3,39a4 <hud_init_glyph_atlas+0x158>
    3994:	00300993          	li	s3,3
    3998:	f5371ae3          	bne	a4,s3,38ec <hud_init_glyph_atlas+0xa0>
    399c:	00e00693          	li	a3,14
    39a0:	f4dff06f          	j	38ec <hud_init_glyph_atlas+0xa0>
    39a4:	02e00993          	li	s3,46
    39a8:	f53592e3          	bne	a1,s3,38ec <hud_init_glyph_atlas+0xa0>
    39ac:	ffa70713          	addi	a4,a4,-6
    39b0:	00173713          	seqz	a4,a4
    39b4:	00271693          	slli	a3,a4,0x2
    39b8:	f35ff06f          	j	38ec <hud_init_glyph_atlas+0xa0>

000039bc <hud_update_cache>:
    39bc:	e9010113          	addi	sp,sp,-368
    39c0:	16112623          	sw	ra,364(sp)
    39c4:	16812423          	sw	s0,360(sp)
    39c8:	16912223          	sw	s1,356(sp)
    39cc:	17212023          	sw	s2,352(sp)
    39d0:	15312e23          	sw	s3,348(sp)
    39d4:	15412c23          	sw	s4,344(sp)
    39d8:	15512a23          	sw	s5,340(sp)
    39dc:	15612823          	sw	s6,336(sp)
    39e0:	15712623          	sw	s7,332(sp)
    39e4:	15812423          	sw	s8,328(sp)
    39e8:	15912223          	sw	s9,324(sp)
    39ec:	15a12023          	sw	s10,320(sp)
    39f0:	13b12e23          	sw	s11,316(sp)
    39f4:	04051463          	bnez	a0,3a3c <hud_update_cache+0x80>
    39f8:	ff800993          	li	s3,-8
    39fc:	16c12083          	lw	ra,364(sp)
    3a00:	16812403          	lw	s0,360(sp)
    3a04:	16412483          	lw	s1,356(sp)
    3a08:	16012903          	lw	s2,352(sp)
    3a0c:	15812a03          	lw	s4,344(sp)
    3a10:	15412a83          	lw	s5,340(sp)
    3a14:	15012b03          	lw	s6,336(sp)
    3a18:	14c12b83          	lw	s7,332(sp)
    3a1c:	14812c03          	lw	s8,328(sp)
    3a20:	14412c83          	lw	s9,324(sp)
    3a24:	14012d03          	lw	s10,320(sp)
    3a28:	13c12d83          	lw	s11,316(sp)
    3a2c:	00098513          	mv	a0,s3
    3a30:	15c12983          	lw	s3,348(sp)
    3a34:	17010113          	addi	sp,sp,368
    3a38:	00008067          	ret
    3a3c:	00058493          	mv	s1,a1
    3a40:	fa058ce3          	beqz	a1,39f8 <hud_update_cache+0x3c>
    3a44:	00060a13          	mv	s4,a2
    3a48:	fa0608e3          	beqz	a2,39f8 <hud_update_cache+0x3c>
    3a4c:	00050413          	mv	s0,a0
    3a50:	10000613          	li	a2,256
    3a54:	00000593          	li	a1,0
    3a58:	03010513          	addi	a0,sp,48
    3a5c:	fccfd0ef          	jal	1228 <memset>
    3a60:	03010593          	addi	a1,sp,48
    3a64:	00040513          	mv	a0,s0
    3a68:	d04ff0ef          	jal	2f6c <hud_comparison_text>
    3a6c:	00050993          	mv	s3,a0
    3a70:	f80516e3          	bnez	a0,39fc <hud_update_cache+0x40>
    3a74:	03010513          	addi	a0,sp,48
    3a78:	c88ff0ef          	jal	2f00 <hud_logo_fits>
    3a7c:	1044c783          	lbu	a5,260(s1)
    3a80:	0ff57b13          	zext.b	s6,a0
    3a84:	02079063          	bnez	a5,3aa4 <hud_update_cache+0xe8>
    3a88:	000a0613          	mv	a2,s4
    3a8c:	00040593          	mv	a1,s0
    3a90:	02000537          	lui	a0,0x2000
    3a94:	9c9ff0ef          	jal	345c <hud_build_comparison>
    3a98:	02050663          	beqz	a0,3ac4 <hud_update_cache+0x108>
    3a9c:	00050993          	mv	s3,a0
    3aa0:	f5dff06f          	j	39fc <hud_update_cache+0x40>
    3aa4:	1054c783          	lbu	a5,261(s1)
    3aa8:	ff6790e3          	bne	a5,s6,3a88 <hud_update_cache+0xcc>
    3aac:	10000613          	li	a2,256
    3ab0:	03010593          	addi	a1,sp,48
    3ab4:	00048513          	mv	a0,s1
    3ab8:	db4fd0ef          	jal	106c <memcmp>
    3abc:	fc0516e3          	bnez	a0,3a88 <hud_update_cache+0xcc>
    3ac0:	f3dff06f          	j	39fc <hud_update_cache+0x40>
    3ac4:	0000eab7          	lui	s5,0xe
    3ac8:	c54a8593          	addi	a1,s5,-940 # dc54 <comparison_letters+0xd4>
    3acc:	10048223          	sb	zero,260(s1)
    3ad0:	01000613          	li	a2,16
    3ad4:	01010513          	addi	a0,sp,16
    3ad8:	82dfd0ef          	jal	1304 <memcpy>
    3adc:	00008bb7          	lui	s7,0x8
    3ae0:	017a07b3          	add	a5,s4,s7
    3ae4:	00022db7          	lui	s11,0x22
    3ae8:	00460bb7          	lui	s7,0x460
    3aec:	c54a8a93          	addi	s5,s5,-940
    3af0:	000a0913          	mv	s2,s4
    3af4:	00000d13          	li	s10,0
    3af8:	00f12623          	sw	a5,12(sp)
    3afc:	78000c93          	li	s9,1920
    3b00:	02000c37          	lui	s8,0x2000
    3b04:	bffd8d93          	addi	s11,s11,-1025 # 21bff <__freertos_irq_stack_top+0x417f>
    3b08:	0c8b8b93          	addi	s7,s7,200 # 4600c8 <__freertos_irq_stack_top+0x442648>
    3b0c:	010a8a93          	addi	s5,s5,16
    3b10:	00c12783          	lw	a5,12(sp)
    3b14:	0007d783          	lhu	a5,0(a5)
    3b18:	02fd6863          	bltu	s10,a5,3b48 <hud_update_cache+0x18c>
    3b1c:	10000613          	li	a2,256
    3b20:	03010593          	addi	a1,sp,48
    3b24:	00048513          	mv	a0,s1
    3b28:	fdcfd0ef          	jal	1304 <memcpy>
    3b2c:	00100793          	li	a5,1
    3b30:	10f48223          	sb	a5,260(s1)
    3b34:	1004a783          	lw	a5,256(s1)
    3b38:	116482a3          	sb	s6,261(s1)
    3b3c:	00178793          	addi	a5,a5,1
    3b40:	10f4a023          	sw	a5,256(s1)
    3b44:	eb9ff06f          	j	39fc <hud_update_cache+0x40>
    3b48:	00c92783          	lw	a5,12(s2)
    3b4c:	eb9796e3          	bne	a5,s9,39f8 <hud_update_cache+0x3c>
    3b50:	00492403          	lw	s0,4(s2)
    3b54:	eb8462e3          	bltu	s0,s8,39f8 <hud_update_cache+0x3c>
    3b58:	41840433          	sub	s0,s0,s8
    3b5c:	e88deee3          	bltu	s11,s0,39f8 <hud_update_cache+0x3c>
    3b60:	00147793          	andi	a5,s0,1
    3b64:	e8079ae3          	bnez	a5,39f8 <hud_update_cache+0x3c>
    3b68:	01c94783          	lbu	a5,28(s2)
    3b6c:	00100713          	li	a4,1
    3b70:	02e79e63          	bne	a5,a4,3bac <hud_update_cache+0x1f0>
    3b74:	03945633          	divu	a2,s0,s9
    3b78:	01495783          	lhu	a5,20(s2)
    3b7c:	01295703          	lhu	a4,18(s2)
    3b80:	01095683          	lhu	a3,16(s2)
    3b84:	01010513          	addi	a0,sp,16
    3b88:	039475b3          	remu	a1,s0,s9
    3b8c:	01061613          	slli	a2,a2,0x10
    3b90:	01065613          	srli	a2,a2,0x10
    3b94:	0015d593          	srli	a1,a1,0x1
    3b98:	c65fe0ef          	jal	27fc <golden_fill>
    3b9c:	02090913          	addi	s2,s2,32
    3ba0:	ee051ee3          	bnez	a0,3a9c <hud_update_cache+0xe0>
    3ba4:	001d0d13          	addi	s10,s10,1
    3ba8:	f69ff06f          	j	3b10 <hud_update_cache+0x154>
    3bac:	00200713          	li	a4,2
    3bb0:	e4e794e3          	bne	a5,a4,39f8 <hud_update_cache+0x3c>
    3bb4:	00092703          	lw	a4,0(s2)
    3bb8:	02c507b7          	lui	a5,0x2c50
    3bbc:	e2f71ee3          	bne	a4,a5,39f8 <hud_update_cache+0x3c>
    3bc0:	00892703          	lw	a4,8(s2)
    3bc4:	19000793          	li	a5,400
    3bc8:	e2f718e3          	bne	a4,a5,39f8 <hud_update_cache+0x3c>
    3bcc:	005d1793          	slli	a5,s10,0x5
    3bd0:	00fa07b3          	add	a5,s4,a5
    3bd4:	0107a783          	lw	a5,16(a5) # 2c50010 <__gpu_framebuffer_a+0xc50010>
    3bd8:	e37790e3          	bne	a5,s7,39f8 <hud_update_cache+0x3c>
    3bdc:	000a8593          	mv	a1,s5
    3be0:	01000613          	li	a2,16
    3be4:	02010513          	addi	a0,sp,32
    3be8:	f1cfd0ef          	jal	1304 <memcpy>
    3bec:	03945633          	divu	a2,s0,s9
    3bf0:	04600893          	li	a7,70
    3bf4:	0c800813          	li	a6,200
    3bf8:	00000793          	li	a5,0
    3bfc:	00000713          	li	a4,0
    3c00:	02010693          	addi	a3,sp,32
    3c04:	01010513          	addi	a0,sp,16
    3c08:	03947433          	remu	s0,s0,s9
    3c0c:	01061613          	slli	a2,a2,0x10
    3c10:	01065613          	srli	a2,a2,0x10
    3c14:	00145593          	srli	a1,s0,0x1
    3c18:	cc5fe0ef          	jal	28dc <golden_copy>
    3c1c:	f81ff06f          	j	3b9c <hud_update_cache+0x1e0>

00003c20 <hud_cached_command>:
    3c20:	08058663          	beqz	a1,3cac <hud_cached_command+0x8c>
    3c24:	ff010113          	addi	sp,sp,-16
    3c28:	00812423          	sw	s0,8(sp)
    3c2c:	00112623          	sw	ra,12(sp)
    3c30:	1045c703          	lbu	a4,260(a1)
    3c34:	00050413          	mv	s0,a0
    3c38:	ff800513          	li	a0,-8
    3c3c:	06070063          	beqz	a4,3c9c <hud_cached_command+0x7c>
    3c40:	00060793          	mv	a5,a2
    3c44:	04060c63          	beqz	a2,3c9c <hud_cached_command+0x7c>
    3c48:	ffe00737          	lui	a4,0xffe00
    3c4c:	fff70713          	addi	a4,a4,-1 # ffdfffff <__gpu_framebuffer_a+0xfddfffff>
    3c50:	00e47733          	and	a4,s0,a4
    3c54:	020006b7          	lui	a3,0x2000
    3c58:	04d71263          	bne	a4,a3,3c9c <hud_cached_command+0x7c>
    3c5c:	02000613          	li	a2,32
    3c60:	00000593          	li	a1,0
    3c64:	00078513          	mv	a0,a5
    3c68:	dc0fd0ef          	jal	1228 <memset>
    3c6c:	02c10737          	lui	a4,0x2c10
    3c70:	00e52023          	sw	a4,0(a0) # 2000000 <__gpu_framebuffer_a>
    3c74:	78000713          	li	a4,1920
    3c78:	00e52423          	sw	a4,8(a0)
    3c7c:	00e52623          	sw	a4,12(a0)
    3c80:	00480737          	lui	a4,0x480
    3c84:	3c070713          	addi	a4,a4,960 # 4803c0 <__freertos_irq_stack_top+0x462940>
    3c88:	00e52823          	sw	a4,16(a0)
    3c8c:	00200713          	li	a4,2
    3c90:	00852223          	sw	s0,4(a0)
    3c94:	00e50e23          	sb	a4,28(a0)
    3c98:	00000513          	li	a0,0
    3c9c:	00c12083          	lw	ra,12(sp)
    3ca0:	00812403          	lw	s0,8(sp)
    3ca4:	01010113          	addi	sp,sp,16
    3ca8:	00008067          	ret
    3cac:	ff800513          	li	a0,-8
    3cb0:	00008067          	ret

00003cb4 <update_gpu_target>:
    3cb4:	eb010113          	addi	sp,sp,-336
    3cb8:	14812423          	sw	s0,328(sp)
    3cbc:	14112623          	sw	ra,332(sp)
    3cc0:	14912223          	sw	s1,324(sp)
    3cc4:	15212023          	sw	s2,320(sp)
    3cc8:	13312e23          	sw	s3,316(sp)
    3ccc:	13412c23          	sw	s4,312(sp)
    3cd0:	13512a23          	sw	s5,308(sp)
    3cd4:	13612823          	sw	s6,304(sp)
    3cd8:	13712623          	sw	s7,300(sp)
    3cdc:	13812423          	sw	s8,296(sp)
    3ce0:	13912223          	sw	s9,292(sp)
    3ce4:	13a12023          	sw	s10,288(sp)
    3ce8:	11b12e23          	sw	s11,284(sp)
    3cec:	ff800413          	li	s0,-8
    3cf0:	1e050a63          	beqz	a0,3ee4 <update_gpu_target+0x230>
    3cf4:	00078993          	mv	s3,a5
    3cf8:	01054783          	lbu	a5,16(a0)
    3cfc:	00050a93          	mv	s5,a0
    3d00:	ff800413          	li	s0,-8
    3d04:	1e078063          	beqz	a5,3ee4 <update_gpu_target+0x230>
    3d08:	00058a13          	mv	s4,a1
    3d0c:	1c058c63          	beqz	a1,3ee4 <update_gpu_target+0x230>
    3d10:	00060493          	mv	s1,a2
    3d14:	1c060863          	beqz	a2,3ee4 <update_gpu_target+0x230>
    3d18:	00068913          	mv	s2,a3
    3d1c:	1c068463          	beqz	a3,3ee4 <update_gpu_target+0x230>
    3d20:	00070b13          	mv	s6,a4
    3d24:	1c070063          	beqz	a4,3ee4 <update_gpu_target+0x230>
    3d28:	10000613          	li	a2,256
    3d2c:	00000593          	li	a1,0
    3d30:	01010513          	addi	a0,sp,16
    3d34:	cf4fd0ef          	jal	1228 <memset>
    3d38:	01010593          	addi	a1,sp,16
    3d3c:	000a0513          	mv	a0,s4
    3d40:	a2cff0ef          	jal	2f6c <hud_comparison_text>
    3d44:	00050413          	mv	s0,a0
    3d48:	18051e63          	bnez	a0,3ee4 <update_gpu_target+0x230>
    3d4c:	01010513          	addi	a0,sp,16
    3d50:	9b0ff0ef          	jal	2f00 <hud_logo_fits>
    3d54:	000087b7          	lui	a5,0x8
    3d58:	00f907b3          	add	a5,s2,a5
    3d5c:	00079023          	sh	zero,0(a5) # 8000 <game_update_cached+0xec>
    3d60:	1044c783          	lbu	a5,260(s1)
    3d64:	0ff57a13          	zext.b	s4,a0
    3d68:	14079e63          	bnez	a5,3ec4 <update_gpu_target+0x210>
    3d6c:	1044cb83          	lbu	s7,260(s1)
    3d70:	1a0b8a63          	beqz	s7,3f24 <update_gpu_target+0x270>
    3d74:	1054c783          	lbu	a5,261(s1)
    3d78:	20079063          	bnez	a5,3f78 <update_gpu_target+0x2c4>
    3d7c:	02c45837          	lui	a6,0x2c45
    3d80:	00008737          	lui	a4,0x8
    3d84:	001206b7          	lui	a3,0x120
    3d88:	71098c13          	addi	s8,s3,1808
    3d8c:	00000c93          	li	s9,0
    3d90:	cc880813          	addi	a6,a6,-824 # 2c44cc8 <__gpu_framebuffer_a+0xc44cc8>
    3d94:	00e90733          	add	a4,s2,a4
    3d98:	01900f93          	li	t6,25
    3d9c:	00e68693          	addi	a3,a3,14 # 12000e <__freertos_irq_stack_top+0x10258e>
    3da0:	ffec8793          	addi	a5,s9,-2
    3da4:	02c408b7          	lui	a7,0x2c40
    3da8:	00079463          	bnez	a5,3db0 <update_gpu_target+0xfc>
    3dac:	00080893          	mv	a7,a6
    3db0:	900c0d13          	addi	s10,s8,-1792 # 1fff900 <__freertos_irq_stack_top+0x1fe1e80>
    3db4:	006c9d93          	slli	s11,s9,0x6
    3db8:	010d8793          	addi	a5,s11,16
    3dbc:	002787b3          	add	a5,a5,sp
    3dc0:	0007c603          	lbu	a2,0(a5)
    3dc4:	200b8663          	beqz	s7,3fd0 <update_gpu_target+0x31c>
    3dc8:	01b487b3          	add	a5,s1,s11
    3dcc:	0007c783          	lbu	a5,0(a5)
    3dd0:	20c79463          	bne	a5,a2,3fd8 <update_gpu_target+0x324>
    3dd4:	01cd0d13          	addi	s10,s10,28
    3dd8:	001d8d93          	addi	s11,s11,1
    3ddc:	fd8d1ee3          	bne	s10,s8,3db8 <update_gpu_target+0x104>
    3de0:	00008c37          	lui	s8,0x8
    3de4:	700c0c13          	addi	s8,s8,1792 # 8700 <replay_seal_step+0xc4>
    3de8:	001c8c93          	addi	s9,s9,1
    3dec:	00400793          	li	a5,4
    3df0:	018d0c33          	add	s8,s10,s8
    3df4:	fafc96e3          	bne	s9,a5,3da0 <update_gpu_target+0xec>
    3df8:	060a0c63          	beqz	s4,3e70 <update_gpu_target+0x1bc>
    3dfc:	000b8663          	beqz	s7,3e08 <update_gpu_target+0x154>
    3e00:	1054c783          	lbu	a5,261(s1)
    3e04:	06079663          	bnez	a5,3e70 <update_gpu_target+0x1bc>
    3e08:	000087b7          	lui	a5,0x8
    3e0c:	00f907b3          	add	a5,s2,a5
    3e10:	0007d803          	lhu	a6,0(a5) # 8000 <game_update_cached+0xec>
    3e14:	02000613          	li	a2,32
    3e18:	00000593          	li	a1,0
    3e1c:	00180713          	addi	a4,a6,1
    3e20:	00581813          	slli	a6,a6,0x5
    3e24:	01090833          	add	a6,s2,a6
    3e28:	00e79023          	sh	a4,0(a5)
    3e2c:	00080513          	mv	a0,a6
    3e30:	bf8fd0ef          	jal	1228 <memset>
    3e34:	02c507b7          	lui	a5,0x2c50
    3e38:	00f52023          	sw	a5,0(a0)
    3e3c:	000017b7          	lui	a5,0x1
    3e40:	d6078793          	addi	a5,a5,-672 # d60 <CUSTOM2+0xd05>
    3e44:	00f989b3          	add	s3,s3,a5
    3e48:	19000793          	li	a5,400
    3e4c:	00f52423          	sw	a5,8(a0)
    3e50:	78000793          	li	a5,1920
    3e54:	00f52623          	sw	a5,12(a0)
    3e58:	004607b7          	lui	a5,0x460
    3e5c:	0c878793          	addi	a5,a5,200 # 4600c8 <__freertos_irq_stack_top+0x442648>
    3e60:	00f52823          	sw	a5,16(a0)
    3e64:	00200793          	li	a5,2
    3e68:	01352223          	sw	s3,4(a0)
    3e6c:	00f50e23          	sb	a5,28(a0)
    3e70:	000087b7          	lui	a5,0x8
    3e74:	10048223          	sb	zero,260(s1)
    3e78:	00f907b3          	add	a5,s2,a5
    3e7c:	0007d603          	lhu	a2,0(a5) # 8000 <game_update_cached+0xec>
    3e80:	000b0693          	mv	a3,s6
    3e84:	00090593          	mv	a1,s2
    3e88:	000a8513          	mv	a0,s5
    3e8c:	52d000ef          	jal	4bb8 <perf_render_gpu>
    3e90:	00050413          	mv	s0,a0
    3e94:	04051863          	bnez	a0,3ee4 <update_gpu_target+0x230>
    3e98:	10000613          	li	a2,256
    3e9c:	01010593          	addi	a1,sp,16
    3ea0:	00048513          	mv	a0,s1
    3ea4:	c60fd0ef          	jal	1304 <memcpy>
    3ea8:	00100793          	li	a5,1
    3eac:	10f48223          	sb	a5,260(s1)
    3eb0:	1004a783          	lw	a5,256(s1)
    3eb4:	114482a3          	sb	s4,261(s1)
    3eb8:	00178793          	addi	a5,a5,1
    3ebc:	10f4a023          	sw	a5,256(s1)
    3ec0:	0240006f          	j	3ee4 <update_gpu_target+0x230>
    3ec4:	1054c783          	lbu	a5,261(s1)
    3ec8:	eb4792e3          	bne	a5,s4,3d6c <update_gpu_target+0xb8>
    3ecc:	10000613          	li	a2,256
    3ed0:	01010593          	addi	a1,sp,16
    3ed4:	00048513          	mv	a0,s1
    3ed8:	994fd0ef          	jal	106c <memcmp>
    3edc:	00050413          	mv	s0,a0
    3ee0:	e80516e3          	bnez	a0,3d6c <update_gpu_target+0xb8>
    3ee4:	14c12083          	lw	ra,332(sp)
    3ee8:	00040513          	mv	a0,s0
    3eec:	14812403          	lw	s0,328(sp)
    3ef0:	14412483          	lw	s1,324(sp)
    3ef4:	14012903          	lw	s2,320(sp)
    3ef8:	13c12983          	lw	s3,316(sp)
    3efc:	13812a03          	lw	s4,312(sp)
    3f00:	13412a83          	lw	s5,308(sp)
    3f04:	13012b03          	lw	s6,304(sp)
    3f08:	12c12b83          	lw	s7,300(sp)
    3f0c:	12812c03          	lw	s8,296(sp)
    3f10:	12412c83          	lw	s9,292(sp)
    3f14:	12012d03          	lw	s10,288(sp)
    3f18:	11c12d83          	lw	s11,284(sp)
    3f1c:	15010113          	addi	sp,sp,336
    3f20:	00008067          	ret
    3f24:	00008737          	lui	a4,0x8
    3f28:	00e90733          	add	a4,s2,a4
    3f2c:	00075783          	lhu	a5,0(a4) # 8000 <game_update_cached+0xec>
    3f30:	02000613          	li	a2,32
    3f34:	00000593          	li	a1,0
    3f38:	00178693          	addi	a3,a5,1
    3f3c:	00579793          	slli	a5,a5,0x5
    3f40:	00f907b3          	add	a5,s2,a5
    3f44:	00d71023          	sh	a3,0(a4)
    3f48:	00078513          	mv	a0,a5
    3f4c:	adcfd0ef          	jal	1228 <memset>
    3f50:	78000713          	li	a4,1920
    3f54:	00e52623          	sw	a4,12(a0)
    3f58:	00480737          	lui	a4,0x480
    3f5c:	00050793          	mv	a5,a0
    3f60:	01352223          	sw	s3,4(a0)
    3f64:	3c070713          	addi	a4,a4,960 # 4803c0 <__freertos_irq_stack_top+0x462940>
    3f68:	00e7a823          	sw	a4,16(a5)
    3f6c:	00100713          	li	a4,1
    3f70:	00e78e23          	sb	a4,28(a5)
    3f74:	e09ff06f          	j	3d7c <update_gpu_target+0xc8>
    3f78:	e00a12e3          	bnez	s4,3d7c <update_gpu_target+0xc8>
    3f7c:	00008737          	lui	a4,0x8
    3f80:	00e90733          	add	a4,s2,a4
    3f84:	00075783          	lhu	a5,0(a4) # 8000 <game_update_cached+0xec>
    3f88:	02000613          	li	a2,32
    3f8c:	00000593          	li	a1,0
    3f90:	00178693          	addi	a3,a5,1
    3f94:	00579793          	slli	a5,a5,0x5
    3f98:	00f907b3          	add	a5,s2,a5
    3f9c:	00d71023          	sh	a3,0(a4)
    3fa0:	00078513          	mv	a0,a5
    3fa4:	a84fd0ef          	jal	1228 <memset>
    3fa8:	00001737          	lui	a4,0x1
    3fac:	d6070713          	addi	a4,a4,-672 # d60 <CUSTOM2+0xd05>
    3fb0:	00e98733          	add	a4,s3,a4
    3fb4:	00e52223          	sw	a4,4(a0)
    3fb8:	78000713          	li	a4,1920
    3fbc:	00e52623          	sw	a4,12(a0)
    3fc0:	00460737          	lui	a4,0x460
    3fc4:	00050793          	mv	a5,a0
    3fc8:	0c870713          	addi	a4,a4,200 # 4600c8 <__freertos_irq_stack_top+0x442648>
    3fcc:	f9dff06f          	j	3f68 <update_gpu_target+0x2b4>
    3fd0:	0df67793          	andi	a5,a2,223
    3fd4:	e00780e3          	beqz	a5,3dd4 <update_gpu_target+0x120>
    3fd8:	00075783          	lhu	a5,0(a4)
    3fdc:	fbf60413          	addi	s0,a2,-65
    3fe0:	00178593          	addi	a1,a5,1
    3fe4:	00b71023          	sh	a1,0(a4)
    3fe8:	0ff47593          	zext.b	a1,s0
    3fec:	02bffa63          	bgeu	t6,a1,4020 <update_gpu_target+0x36c>
    3ff0:	fd060593          	addi	a1,a2,-48
    3ff4:	0ff5f593          	zext.b	a1,a1
    3ff8:	00900513          	li	a0,9
    3ffc:	fea60413          	addi	s0,a2,-22
    4000:	02b57063          	bgeu	a0,a1,4020 <update_gpu_target+0x36c>
    4004:	02d00593          	li	a1,45
    4008:	02400413          	li	s0,36
    400c:	00b60a63          	beq	a2,a1,4020 <update_gpu_target+0x36c>
    4010:	02e00593          	li	a1,46
    4014:	02600413          	li	s0,38
    4018:	00b61463          	bne	a2,a1,4020 <update_gpu_target+0x36c>
    401c:	02500413          	li	s0,37
    4020:	00579793          	slli	a5,a5,0x5
    4024:	00f907b3          	add	a5,s2,a5
    4028:	02000613          	li	a2,32
    402c:	00000593          	li	a1,0
    4030:	00078513          	mv	a0,a5
    4034:	01012623          	sw	a6,12(sp)
    4038:	00d12423          	sw	a3,8(sp)
    403c:	00e12223          	sw	a4,4(sp)
    4040:	01112023          	sw	a7,0(sp)
    4044:	9e4fd0ef          	jal	1228 <memset>
    4048:	1f800f13          	li	t5,504
    404c:	03e40433          	mul	s0,s0,t5
    4050:	00012883          	lw	a7,0(sp)
    4054:	00812683          	lw	a3,8(sp)
    4058:	01c00e93          	li	t4,28
    405c:	78000e13          	li	t3,1920
    4060:	00200313          	li	t1,2
    4064:	00c12803          	lw	a6,12(sp)
    4068:	00412703          	lw	a4,4(sp)
    406c:	01a52223          	sw	s10,4(a0)
    4070:	01d52423          	sw	t4,8(a0)
    4074:	01140433          	add	s0,s0,a7
    4078:	00852023          	sw	s0,0(a0)
    407c:	01c52623          	sw	t3,12(a0)
    4080:	00d52823          	sw	a3,16(a0)
    4084:	00650e23          	sb	t1,28(a0)
    4088:	01900f93          	li	t6,25
    408c:	d49ff06f          	j	3dd4 <update_gpu_target+0x120>

00004090 <hud_update_gpu_cache>:
    4090:	02c107b7          	lui	a5,0x2c10
    4094:	c21ff06f          	j	3cb4 <update_gpu_target>

00004098 <hud_render_gpu_direct>:
    4098:	00070813          	mv	a6,a4
    409c:	00078713          	mv	a4,a5
    40a0:	02060c63          	beqz	a2,40d8 <hud_render_gpu_direct+0x40>
    40a4:	ffe008b7          	lui	a7,0xffe00
    40a8:	fff88893          	addi	a7,a7,-1 # ffdfffff <__gpu_framebuffer_a+0xfddfffff>
    40ac:	011878b3          	and	a7,a6,a7
    40b0:	020007b7          	lui	a5,0x2000
    40b4:	02f89263          	bne	a7,a5,40d8 <hud_render_gpu_direct+0x40>
    40b8:	fde007b7          	lui	a5,0xfde00
    40bc:	00f807b3          	add	a5,a6,a5
    40c0:	00000893          	li	a7,0
    40c4:	00079463          	bnez	a5,40cc <hud_render_gpu_direct+0x34>
    40c8:	10800893          	li	a7,264
    40cc:	00080793          	mv	a5,a6
    40d0:	01160633          	add	a2,a2,a7
    40d4:	be1ff06f          	j	3cb4 <update_gpu_target>
    40d8:	ff800513          	li	a0,-8
    40dc:	00008067          	ret

000040e0 <asst_crc32>:
    40e0:	edb88737          	lui	a4,0xedb88
    40e4:	00b505b3          	add	a1,a0,a1
    40e8:	fff00793          	li	a5,-1
    40ec:	32070713          	addi	a4,a4,800 # edb88320 <__gpu_framebuffer_a+0xebb88320>
    40f0:	00b51663          	bne	a0,a1,40fc <asst_crc32+0x1c>
    40f4:	fff7c513          	not	a0,a5
    40f8:	00008067          	ret
    40fc:	00054683          	lbu	a3,0(a0)
    4100:	00150513          	addi	a0,a0,1
    4104:	00d7c7b3          	xor	a5,a5,a3
    4108:	00800693          	li	a3,8
    410c:	0017d613          	srli	a2,a5,0x1
    4110:	0017f793          	andi	a5,a5,1
    4114:	40f007b3          	neg	a5,a5
    4118:	00e7f7b3          	and	a5,a5,a4
    411c:	fff68693          	addi	a3,a3,-1
    4120:	00f647b3          	xor	a5,a2,a5
    4124:	fe0694e3          	bnez	a3,410c <asst_crc32+0x2c>
    4128:	fc9ff06f          	j	40f0 <asst_crc32+0x10>

0000412c <asst_encode>:
    412c:	00050793          	mv	a5,a0
    4130:	fff00513          	li	a0,-1
    4134:	14078063          	beqz	a5,4274 <asst_encode+0x148>
    4138:	12058e63          	beqz	a1,4274 <asst_encode+0x148>
    413c:	0005a683          	lw	a3,0(a1)
    4140:	41535737          	lui	a4,0x41535
    4144:	35470713          	addi	a4,a4,852 # 41535354 <__gpu_framebuffer_a+0x3f535354>
    4148:	12e69663          	bne	a3,a4,4274 <asst_encode+0x148>
    414c:	0185d683          	lhu	a3,24(a1)
    4150:	00100713          	li	a4,1
    4154:	12e69063          	bne	a3,a4,4274 <asst_encode+0x148>
    4158:	01c5d683          	lhu	a3,28(a1)
    415c:	40000713          	li	a4,1024
    4160:	10d76a63          	bltu	a4,a3,4274 <asst_encode+0x148>
    4164:	01e5d683          	lhu	a3,30(a1)
    4168:	00300713          	li	a4,3
    416c:	10d76463          	bltu	a4,a3,4274 <asst_encode+0x148>
    4170:	04100713          	li	a4,65
    4174:	00e78023          	sb	a4,0(a5) # fde00000 <__gpu_framebuffer_a+0xfbe00000>
    4178:	05300713          	li	a4,83
    417c:	00e780a3          	sb	a4,1(a5)
    4180:	00e78123          	sb	a4,2(a5)
    4184:	05400713          	li	a4,84
    4188:	00e781a3          	sb	a4,3(a5)
    418c:	0185d703          	lhu	a4,24(a1)
    4190:	00000513          	li	a0,0
    4194:	00875693          	srli	a3,a4,0x8
    4198:	00d78223          	sb	a3,4(a5)
    419c:	00e782a3          	sb	a4,5(a5)
    41a0:	01a5d703          	lhu	a4,26(a1)
    41a4:	00875693          	srli	a3,a4,0x8
    41a8:	00d78323          	sb	a3,6(a5)
    41ac:	00e783a3          	sb	a4,7(a5)
    41b0:	0045a703          	lw	a4,4(a1)
    41b4:	01875693          	srli	a3,a4,0x18
    41b8:	00d78423          	sb	a3,8(a5)
    41bc:	01075693          	srli	a3,a4,0x10
    41c0:	00d784a3          	sb	a3,9(a5)
    41c4:	00875693          	srli	a3,a4,0x8
    41c8:	00d78523          	sb	a3,10(a5)
    41cc:	00e785a3          	sb	a4,11(a5)
    41d0:	0085a703          	lw	a4,8(a1)
    41d4:	01875693          	srli	a3,a4,0x18
    41d8:	00d78623          	sb	a3,12(a5)
    41dc:	01075693          	srli	a3,a4,0x10
    41e0:	00d786a3          	sb	a3,13(a5)
    41e4:	00875693          	srli	a3,a4,0x8
    41e8:	00d78723          	sb	a3,14(a5)
    41ec:	00e787a3          	sb	a4,15(a5)
    41f0:	00c5a703          	lw	a4,12(a1)
    41f4:	01875693          	srli	a3,a4,0x18
    41f8:	00d78823          	sb	a3,16(a5)
    41fc:	01075693          	srli	a3,a4,0x10
    4200:	00d788a3          	sb	a3,17(a5)
    4204:	00875693          	srli	a3,a4,0x8
    4208:	00d78923          	sb	a3,18(a5)
    420c:	00e789a3          	sb	a4,19(a5)
    4210:	01c5d703          	lhu	a4,28(a1)
    4214:	00875693          	srli	a3,a4,0x8
    4218:	00d78a23          	sb	a3,20(a5)
    421c:	00e78aa3          	sb	a4,21(a5)
    4220:	01e5d703          	lhu	a4,30(a1)
    4224:	00875693          	srli	a3,a4,0x8
    4228:	00d78b23          	sb	a3,22(a5)
    422c:	00e78ba3          	sb	a4,23(a5)
    4230:	0105a703          	lw	a4,16(a1)
    4234:	01875693          	srli	a3,a4,0x18
    4238:	00d78c23          	sb	a3,24(a5)
    423c:	01075693          	srli	a3,a4,0x10
    4240:	00d78ca3          	sb	a3,25(a5)
    4244:	00875693          	srli	a3,a4,0x8
    4248:	00d78d23          	sb	a3,26(a5)
    424c:	00e78da3          	sb	a4,27(a5)
    4250:	0145a703          	lw	a4,20(a1)
    4254:	01875693          	srli	a3,a4,0x18
    4258:	00d78e23          	sb	a3,28(a5)
    425c:	01075693          	srli	a3,a4,0x10
    4260:	00d78ea3          	sb	a3,29(a5)
    4264:	00875693          	srli	a3,a4,0x8
    4268:	00d78f23          	sb	a3,30(a5)
    426c:	00e78fa3          	sb	a4,31(a5)
    4270:	00008067          	ret
    4274:	00008067          	ret

00004278 <asset_dma_start>:
    4278:	00050793          	mv	a5,a0
    427c:	fff00513          	li	a0,-1
    4280:	0a058063          	beqz	a1,4320 <asset_dma_start+0xa8>
    4284:	0a078263          	beqz	a5,4328 <asset_dma_start+0xb0>
    4288:	0005a603          	lw	a2,0(a1)
    428c:	08060e63          	beqz	a2,4328 <asset_dma_start+0xb0>
    4290:	0145a703          	lw	a4,20(a1)
    4294:	08070a63          	beqz	a4,4328 <asset_dma_start+0xb0>
    4298:	0045a683          	lw	a3,4(a1)
    429c:	0036f813          	andi	a6,a3,3
    42a0:	08081463          	bnez	a6,4328 <asset_dma_start+0xb0>
    42a4:	00c5a803          	lw	a6,12(a1)
    42a8:	00387893          	andi	a7,a6,3
    42ac:	06089e63          	bnez	a7,4328 <asset_dma_start+0xb0>
    42b0:	06e87c63          	bgeu	a6,a4,4328 <asset_dma_start+0xb0>
    42b4:	02400837          	lui	a6,0x2400
    42b8:	0706e863          	bltu	a3,a6,4328 <asset_dma_start+0xb0>
    42bc:	00e68733          	add	a4,a3,a4
    42c0:	06d76263          	bltu	a4,a3,4324 <asset_dma_start+0xac>
    42c4:	100006b7          	lui	a3,0x10000
    42c8:	04e6ee63          	bltu	a3,a4,4324 <asset_dma_start+0xac>
    42cc:	11c7a703          	lw	a4,284(a5)
    42d0:	ffe00513          	li	a0,-2
    42d4:	00177713          	andi	a4,a4,1
    42d8:	04071863          	bnez	a4,4328 <asset_dma_start+0xb0>
    42dc:	10c7a023          	sw	a2,256(a5)
    42e0:	0045a703          	lw	a4,4(a1)
    42e4:	10e7a223          	sw	a4,260(a5)
    42e8:	0085a703          	lw	a4,8(a1)
    42ec:	10e7a423          	sw	a4,264(a5)
    42f0:	00c5a703          	lw	a4,12(a1)
    42f4:	10e7a623          	sw	a4,268(a5)
    42f8:	0105a703          	lw	a4,16(a1)
    42fc:	10e7a823          	sw	a4,272(a5)
    4300:	0145a703          	lw	a4,20(a1)
    4304:	10e7aa23          	sw	a4,276(a5)
    4308:	0ff0000f          	fence
    430c:	00100713          	li	a4,1
    4310:	10e7ac23          	sw	a4,280(a5)
    4314:	0ff0000f          	fence
    4318:	00000513          	li	a0,0
    431c:	00008067          	ret
    4320:	00008067          	ret
    4324:	fff00513          	li	a0,-1
    4328:	00008067          	ret

0000432c <asset_dma_poll>:
    432c:	00050793          	mv	a5,a0
    4330:	fff00513          	li	a0,-1
    4334:	06078263          	beqz	a5,4398 <asset_dma_poll+0x6c>
    4338:	06058063          	beqz	a1,4398 <asset_dma_poll+0x6c>
    433c:	0ff0000f          	fence
    4340:	11c7a703          	lw	a4,284(a5)
    4344:	ffc00513          	li	a0,-4
    4348:	00e5a023          	sw	a4,0(a1)
    434c:	1207a683          	lw	a3,288(a5)
    4350:	00d5a223          	sw	a3,4(a1)
    4354:	1247a683          	lw	a3,292(a5)
    4358:	00d5a423          	sw	a3,8(a1)
    435c:	1287a683          	lw	a3,296(a5)
    4360:	00d5a623          	sw	a3,12(a1)
    4364:	12c7a683          	lw	a3,300(a5)
    4368:	00d5a823          	sw	a3,16(a1)
    436c:	1307a683          	lw	a3,304(a5)
    4370:	00d5aa23          	sw	a3,20(a1)
    4374:	1347a783          	lw	a5,308(a5)
    4378:	00f5ac23          	sw	a5,24(a1)
    437c:	00c77793          	andi	a5,a4,12
    4380:	00079c63          	bnez	a5,4398 <asset_dma_poll+0x6c>
    4384:	00277713          	andi	a4,a4,2
    4388:	00000513          	li	a0,0
    438c:	00071663          	bnez	a4,4398 <asset_dma_poll+0x6c>
    4390:	ffe00513          	li	a0,-2
    4394:	00008067          	ret
    4398:	00008067          	ret

0000439c <asset_dma_abort>:
    439c:	00050863          	beqz	a0,43ac <asset_dma_abort+0x10>
    43a0:	00200793          	li	a5,2
    43a4:	10f52c23          	sw	a5,280(a0)
    43a8:	0ff0000f          	fence
    43ac:	00008067          	ret

000043b0 <stop_dma>:
    43b0:	11c52783          	lw	a5,284(a0)
    43b4:	0017f793          	andi	a5,a5,1
    43b8:	0a078e63          	beqz	a5,4474 <stop_dma+0xc4>
    43bc:	fe010113          	addi	sp,sp,-32
    43c0:	00112e23          	sw	ra,28(sp)
    43c4:	00812c23          	sw	s0,24(sp)
    43c8:	00912a23          	sw	s1,20(sp)
    43cc:	00058413          	mv	s0,a1
    43d0:	01212823          	sw	s2,16(sp)
    43d4:	01312623          	sw	s3,12(sp)
    43d8:	01412423          	sw	s4,8(sp)
    43dc:	11c50993          	addi	s3,a0,284
    43e0:	fbdff0ef          	jal	439c <asset_dma_abort>
    43e4:	c44fd0ef          	jal	1828 <gpu_platform_cycles>
    43e8:	01400793          	li	a5,20
    43ec:	00058913          	mv	s2,a1
    43f0:	02f405b3          	mul	a1,s0,a5
    43f4:	00050493          	mv	s1,a0
    43f8:	3e800613          	li	a2,1000
    43fc:	00000693          	li	a3,0
    4400:	02f43433          	mulhu	s0,s0,a5
    4404:	3e758513          	addi	a0,a1,999
    4408:	00b535b3          	sltu	a1,a0,a1
    440c:	008585b3          	add	a1,a1,s0
    4410:	564080ef          	jal	c974 <__udivdi3>
    4414:	00058413          	mv	s0,a1
    4418:	00050a13          	mv	s4,a0
    441c:	0009a783          	lw	a5,0(s3)
    4420:	0017f793          	andi	a5,a5,1
    4424:	04078463          	beqz	a5,446c <stop_dma+0xbc>
    4428:	c00fd0ef          	jal	1828 <gpu_platform_cycles>
    442c:	409506b3          	sub	a3,a0,s1
    4430:	00d53733          	sltu	a4,a0,a3
    4434:	412587b3          	sub	a5,a1,s2
    4438:	40e787b3          	sub	a5,a5,a4
    443c:	fe87e0e3          	bltu	a5,s0,441c <stop_dma+0x6c>
    4440:	00f41463          	bne	s0,a5,4448 <stop_dma+0x98>
    4444:	fd46ece3          	bltu	a3,s4,441c <stop_dma+0x6c>
    4448:	fea00513          	li	a0,-22
    444c:	01c12083          	lw	ra,28(sp)
    4450:	01812403          	lw	s0,24(sp)
    4454:	01412483          	lw	s1,20(sp)
    4458:	01012903          	lw	s2,16(sp)
    445c:	00c12983          	lw	s3,12(sp)
    4460:	00812a03          	lw	s4,8(sp)
    4464:	02010113          	addi	sp,sp,32
    4468:	00008067          	ret
    446c:	00000513          	li	a0,0
    4470:	fddff06f          	j	444c <stop_dma+0x9c>
    4474:	00000513          	li	a0,0
    4478:	00008067          	ret

0000447c <network_configure>:
    447c:	00050793          	mv	a5,a0
    4480:	fec00513          	li	a0,-20
    4484:	04078c63          	beqz	a5,44dc <network_configure+0x60>
    4488:	04058a63          	beqz	a1,44dc <network_configure+0x60>
    448c:	04060863          	beqz	a2,44dc <network_configure+0x60>
    4490:	04068663          	beqz	a3,44dc <network_configure+0x60>
    4494:	04070463          	beqz	a4,44dc <network_configure+0x60>
    4498:	2007a883          	lw	a7,512(a5)
    449c:	4e455837          	lui	a6,0x4e455
    44a0:	43180813          	addi	a6,a6,1073 # 4e455431 <__gpu_framebuffer_a+0x4c455431>
    44a4:	feb00513          	li	a0,-21
    44a8:	03089a63          	bne	a7,a6,44dc <network_configure+0x60>
    44ac:	2047a803          	lw	a6,516(a5)
    44b0:	fe900513          	li	a0,-23
    44b4:	00187813          	andi	a6,a6,1
    44b8:	02081263          	bnez	a6,44dc <network_configure+0x60>
    44bc:	20b7a623          	sw	a1,524(a5)
    44c0:	01071713          	slli	a4,a4,0x10
    44c4:	20c7a823          	sw	a2,528(a5)
    44c8:	00d766b3          	or	a3,a4,a3
    44cc:	20d7aa23          	sw	a3,532(a5)
    44d0:	0ff0000f          	fence
    44d4:	00000513          	li	a0,0
    44d8:	00008067          	ret
    44dc:	00008067          	ret

000044e0 <network_asset_fetch>:
    44e0:	f2010113          	addi	sp,sp,-224
    44e4:	0c112e23          	sw	ra,220(sp)
    44e8:	0c812c23          	sw	s0,216(sp)
    44ec:	0c912a23          	sw	s1,212(sp)
    44f0:	0d212823          	sw	s2,208(sp)
    44f4:	0d312623          	sw	s3,204(sp)
    44f8:	0d412423          	sw	s4,200(sp)
    44fc:	0d512223          	sw	s5,196(sp)
    4500:	0d612023          	sw	s6,192(sp)
    4504:	0b712e23          	sw	s7,188(sp)
    4508:	0b812c23          	sw	s8,184(sp)
    450c:	0b912a23          	sw	s9,180(sp)
    4510:	0ba12823          	sw	s10,176(sp)
    4514:	0bb12623          	sw	s11,172(sp)
    4518:	00c12a23          	sw	a2,20(sp)
    451c:	00d12e23          	sw	a3,28(sp)
    4520:	03012423          	sw	a6,40(sp)
    4524:	04089463          	bnez	a7,456c <network_asset_fetch+0x8c>
    4528:	fec00493          	li	s1,-20
    452c:	0dc12083          	lw	ra,220(sp)
    4530:	0d812403          	lw	s0,216(sp)
    4534:	0d012903          	lw	s2,208(sp)
    4538:	0cc12983          	lw	s3,204(sp)
    453c:	0c812a03          	lw	s4,200(sp)
    4540:	0c412a83          	lw	s5,196(sp)
    4544:	0c012b03          	lw	s6,192(sp)
    4548:	0bc12b83          	lw	s7,188(sp)
    454c:	0b812c03          	lw	s8,184(sp)
    4550:	0b412c83          	lw	s9,180(sp)
    4554:	0b012d03          	lw	s10,176(sp)
    4558:	0ac12d83          	lw	s11,172(sp)
    455c:	00048513          	mv	a0,s1
    4560:	0d412483          	lw	s1,212(sp)
    4564:	0e010113          	addi	sp,sp,224
    4568:	00008067          	ret
    456c:	00050413          	mv	s0,a0
    4570:	00058993          	mv	s3,a1
    4574:	01800613          	li	a2,24
    4578:	00000593          	li	a1,0
    457c:	00088513          	mv	a0,a7
    4580:	00070a93          	mv	s5,a4
    4584:	00078a13          	mv	s4,a5
    4588:	00088913          	mv	s2,a7
    458c:	c9dfc0ef          	jal	1228 <memset>
    4590:	f8040ce3          	beqz	s0,4528 <network_asset_fetch+0x48>
    4594:	f8098ae3          	beqz	s3,4528 <network_asset_fetch+0x48>
    4598:	01412783          	lw	a5,20(sp)
    459c:	f80786e3          	beqz	a5,4528 <network_asset_fetch+0x48>
    45a0:	f80a04e3          	beqz	s4,4528 <network_asset_fetch+0x48>
    45a4:	003af793          	andi	a5,s5,3
    45a8:	f80790e3          	bnez	a5,4528 <network_asset_fetch+0x48>
    45ac:	024007b7          	lui	a5,0x2400
    45b0:	f6faece3          	bltu	s5,a5,4528 <network_asset_fetch+0x48>
    45b4:	014a87b3          	add	a5,s5,s4
    45b8:	f757e8e3          	bltu	a5,s5,4528 <network_asset_fetch+0x48>
    45bc:	10000737          	lui	a4,0x10000
    45c0:	f6f764e3          	bltu	a4,a5,4528 <network_asset_fetch+0x48>
    45c4:	20042703          	lw	a4,512(s0)
    45c8:	4e4557b7          	lui	a5,0x4e455
    45cc:	43178793          	addi	a5,a5,1073 # 4e455431 <__gpu_framebuffer_a+0x4c455431>
    45d0:	feb00493          	li	s1,-21
    45d4:	f4f71ce3          	bne	a4,a5,452c <network_asset_fetch+0x4c>
    45d8:	a50fd0ef          	jal	1828 <gpu_platform_cycles>
    45dc:	01412783          	lw	a5,20(sp)
    45e0:	02a12623          	sw	a0,44(sp)
    45e4:	02b12823          	sw	a1,48(sp)
    45e8:	04f12423          	sw	a5,72(sp)
    45ec:	01c12783          	lw	a5,28(sp)
    45f0:	04810593          	addi	a1,sp,72
    45f4:	00040513          	mv	a0,s0
    45f8:	04012a23          	sw	zero,84(sp)
    45fc:	04012c23          	sw	zero,88(sp)
    4600:	05512623          	sw	s5,76(sp)
    4604:	04f12823          	sw	a5,80(sp)
    4608:	05412e23          	sw	s4,92(sp)
    460c:	c6dff0ef          	jal	4278 <asset_dma_start>
    4610:	00050493          	mv	s1,a0
    4614:	36051a63          	bnez	a0,4988 <network_asset_fetch+0x4a8>
    4618:	06400793          	li	a5,100
    461c:	02f985b3          	mul	a1,s3,a5
    4620:	3e800613          	li	a2,1000
    4624:	00000693          	li	a3,0
    4628:	00000b13          	li	s6,0
    462c:	02f9b7b3          	mulhu	a5,s3,a5
    4630:	3e758513          	addi	a0,a1,999
    4634:	00b535b3          	sltu	a1,a0,a1
    4638:	00f585b3          	add	a1,a1,a5
    463c:	338080ef          	jal	c974 <__udivdi3>
    4640:	01400793          	li	a5,20
    4644:	00b12623          	sw	a1,12(sp)
    4648:	02f985b3          	mul	a1,s3,a5
    464c:	02a12223          	sw	a0,36(sp)
    4650:	3e800613          	li	a2,1000
    4654:	00000693          	li	a3,0
    4658:	02f9b7b3          	mulhu	a5,s3,a5
    465c:	3e758513          	addi	a0,a1,999
    4660:	00b535b3          	sltu	a1,a0,a1
    4664:	00f585b3          	add	a1,a1,a5
    4668:	30c080ef          	jal	c974 <__udivdi3>
    466c:	415357b7          	lui	a5,0x41535
    4670:	35478793          	addi	a5,a5,852 # 41535354 <__gpu_framebuffer_a+0x3f535354>
    4674:	02f12c23          	sw	a5,56(sp)
    4678:	000107b7          	lui	a5,0x10
    467c:	00178793          	addi	a5,a5,1 # 10001 <__global_pointer$+0x1299>
    4680:	02a12a23          	sw	a0,52(sp)
    4684:	02b12023          	sw	a1,32(sp)
    4688:	00012423          	sw	zero,8(sp)
    468c:	02f12e23          	sw	a5,60(sp)
    4690:	40000713          	li	a4,1024
    4694:	416a07b3          	sub	a5,s4,s6
    4698:	00e12823          	sw	a4,16(sp)
    469c:	00f76863          	bltu	a4,a5,46ac <network_asset_fetch+0x1cc>
    46a0:	01079793          	slli	a5,a5,0x10
    46a4:	0107d793          	srli	a5,a5,0x10
    46a8:	00f12823          	sw	a5,16(sp)
    46ac:	01012783          	lw	a5,16(sp)
    46b0:	00000b93          	li	s7,0
    46b4:	01678c33          	add	s8,a5,s6
    46b8:	00812783          	lw	a5,8(sp)
    46bc:	00178793          	addi	a5,a5,1
    46c0:	00f12c23          	sw	a5,24(sp)
    46c4:	11c42783          	lw	a5,284(s0)
    46c8:	000b9863          	bnez	s7,46d8 <network_asset_fetch+0x1f8>
    46cc:	00d7f793          	andi	a5,a5,13
    46d0:	00100713          	li	a4,1
    46d4:	06e78263          	beq	a5,a4,4738 <network_asset_fetch+0x258>
    46d8:	00098593          	mv	a1,s3
    46dc:	00040513          	mv	a0,s0
    46e0:	cd1ff0ef          	jal	43b0 <stop_dma>
    46e4:	00050c93          	mv	s9,a0
    46e8:	02051263          	bnez	a0,470c <network_asset_fetch+0x22c>
    46ec:	00812783          	lw	a5,8(sp)
    46f0:	04810593          	addi	a1,sp,72
    46f4:	00040513          	mv	a0,s0
    46f8:	05612a23          	sw	s6,84(sp)
    46fc:	04f12c23          	sw	a5,88(sp)
    4700:	b79ff0ef          	jal	4278 <asset_dma_start>
    4704:	02050a63          	beqz	a0,4738 <network_asset_fetch+0x258>
    4708:	fe900c93          	li	s9,-23
    470c:	00098593          	mv	a1,s3
    4710:	00040513          	mv	a0,s0
    4714:	c9dff0ef          	jal	43b0 <stop_dma>
    4718:	00050493          	mv	s1,a0
    471c:	22051e63          	bnez	a0,4958 <network_asset_fetch+0x478>
    4720:	000c8493          	mv	s1,s9
    4724:	2340006f          	j	4958 <network_asset_fetch+0x478>
    4728:	00892783          	lw	a5,8(s2)
    472c:	00178793          	addi	a5,a5,1
    4730:	00f92423          	sw	a5,8(s2)
    4734:	f91ff06f          	j	46c4 <network_asset_fetch+0x1e4>
    4738:	03812783          	lw	a5,56(sp)
    473c:	06010593          	addi	a1,sp,96
    4740:	08010513          	addi	a0,sp,128
    4744:	06f12023          	sw	a5,96(sp)
    4748:	01412783          	lw	a5,20(sp)
    474c:	07612623          	sw	s6,108(sp)
    4750:	06012a23          	sw	zero,116(sp)
    4754:	06f12223          	sw	a5,100(sp)
    4758:	01c12783          	lw	a5,28(sp)
    475c:	06f12423          	sw	a5,104(sp)
    4760:	00812783          	lw	a5,8(sp)
    4764:	06f12823          	sw	a5,112(sp)
    4768:	03c12783          	lw	a5,60(sp)
    476c:	06f12c23          	sw	a5,120(sp)
    4770:	01012783          	lw	a5,16(sp)
    4774:	06f11e23          	sh	a5,124(sp)
    4778:	017037b3          	snez	a5,s7
    477c:	00179793          	slli	a5,a5,0x1
    4780:	06f11f23          	sh	a5,126(sp)
    4784:	00492783          	lw	a5,4(s2)
    4788:	00178793          	addi	a5,a5,1
    478c:	00f92223          	sw	a5,4(s2)
    4790:	99dff0ef          	jal	412c <asst_encode>
    4794:	10051063          	bnez	a0,4894 <network_asset_fetch+0x3b4>
    4798:	890fd0ef          	jal	1828 <gpu_platform_cycles>
    479c:	00050d13          	mv	s10,a0
    47a0:	00058d93          	mv	s11,a1
    47a4:	00800613          	li	a2,8
    47a8:	20442783          	lw	a5,516(s0)
    47ac:	20440c93          	addi	s9,s0,516
    47b0:	0097f793          	andi	a5,a5,9
    47b4:	02c78c63          	beq	a5,a2,47ec <network_asset_fetch+0x30c>
    47b8:	870fd0ef          	jal	1828 <gpu_platform_cycles>
    47bc:	41a506b3          	sub	a3,a0,s10
    47c0:	00d53733          	sltu	a4,a0,a3
    47c4:	41b587b3          	sub	a5,a1,s11
    47c8:	40e787b3          	sub	a5,a5,a4
    47cc:	00c12703          	lw	a4,12(sp)
    47d0:	00800613          	li	a2,8
    47d4:	fce7eae3          	bltu	a5,a4,47a8 <network_asset_fetch+0x2c8>
    47d8:	00f71663          	bne	a4,a5,47e4 <network_asset_fetch+0x304>
    47dc:	02412783          	lw	a5,36(sp)
    47e0:	fcf6e4e3          	bltu	a3,a5,47a8 <network_asset_fetch+0x2c8>
    47e4:	fea00c93          	li	s9,-22
    47e8:	0b00006f          	j	4898 <network_asset_fetch+0x3b8>
    47ec:	08010713          	addi	a4,sp,128
    47f0:	22040693          	addi	a3,s0,544
    47f4:	24040593          	addi	a1,s0,576
    47f8:	00174783          	lbu	a5,1(a4) # 10000001 <__gpu_framebuffer_a+0xe000001>
    47fc:	00274603          	lbu	a2,2(a4)
    4800:	00468693          	addi	a3,a3,4 # 10000004 <__gpu_framebuffer_a+0xe000004>
    4804:	00879793          	slli	a5,a5,0x8
    4808:	01061613          	slli	a2,a2,0x10
    480c:	00c7e7b3          	or	a5,a5,a2
    4810:	00074603          	lbu	a2,0(a4)
    4814:	00470713          	addi	a4,a4,4
    4818:	00c7e7b3          	or	a5,a5,a2
    481c:	fff74603          	lbu	a2,-1(a4)
    4820:	01861613          	slli	a2,a2,0x18
    4824:	00c7e7b3          	or	a5,a5,a2
    4828:	fef6ae23          	sw	a5,-4(a3)
    482c:	fcd596e3          	bne	a1,a3,47f8 <network_asset_fetch+0x318>
    4830:	0ff0000f          	fence
    4834:	00100793          	li	a5,1
    4838:	20f42423          	sw	a5,520(s0)
    483c:	0ff0000f          	fence
    4840:	fe9fc0ef          	jal	1828 <gpu_platform_cycles>
    4844:	00050d13          	mv	s10,a0
    4848:	00058d93          	mv	s11,a1
    484c:	000ca783          	lw	a5,0(s9)
    4850:	0017f713          	andi	a4,a5,1
    4854:	00071a63          	bnez	a4,4868 <network_asset_fetch+0x388>
    4858:	0047f713          	andi	a4,a5,4
    485c:	12071263          	bnez	a4,4980 <network_asset_fetch+0x4a0>
    4860:	0027f793          	andi	a5,a5,2
    4864:	12079663          	bnez	a5,4990 <network_asset_fetch+0x4b0>
    4868:	fc1fc0ef          	jal	1828 <gpu_platform_cycles>
    486c:	41a506b3          	sub	a3,a0,s10
    4870:	00d53733          	sltu	a4,a0,a3
    4874:	41b587b3          	sub	a5,a1,s11
    4878:	40e787b3          	sub	a5,a5,a4
    487c:	00c12703          	lw	a4,12(sp)
    4880:	fce7e6e3          	bltu	a5,a4,484c <network_asset_fetch+0x36c>
    4884:	f6f710e3          	bne	a4,a5,47e4 <network_asset_fetch+0x304>
    4888:	02412783          	lw	a5,36(sp)
    488c:	fcf6e0e3          	bltu	a3,a5,484c <network_asset_fetch+0x36c>
    4890:	f55ff06f          	j	47e4 <network_asset_fetch+0x304>
    4894:	fec00c93          	li	s9,-20
    4898:	001b8b93          	addi	s7,s7,1
    489c:	00600793          	li	a5,6
    48a0:	e8fb94e3          	bne	s7,a5,4728 <network_asset_fetch+0x248>
    48a4:	0a0c8a63          	beqz	s9,4958 <network_asset_fetch+0x478>
    48a8:	e65ff06f          	j	470c <network_asset_fetch+0x22c>
    48ac:	0cfc6a63          	bltu	s8,a5,4980 <network_asset_fetch+0x4a0>
    48b0:	08812783          	lw	a5,136(sp)
    48b4:	01812703          	lw	a4,24(sp)
    48b8:	0cf76463          	bltu	a4,a5,4980 <network_asset_fetch+0x4a0>
    48bc:	f6dfc0ef          	jal	1828 <gpu_platform_cycles>
    48c0:	41a507b3          	sub	a5,a0,s10
    48c4:	02012703          	lw	a4,32(sp)
    48c8:	00f53533          	sltu	a0,a0,a5
    48cc:	419585b3          	sub	a1,a1,s9
    48d0:	40a585b3          	sub	a1,a1,a0
    48d4:	00e5e863          	bltu	a1,a4,48e4 <network_asset_fetch+0x404>
    48d8:	f0b716e3          	bne	a4,a1,47e4 <network_asset_fetch+0x304>
    48dc:	03412703          	lw	a4,52(sp)
    48e0:	f0e7f2e3          	bgeu	a5,a4,47e4 <network_asset_fetch+0x304>
    48e4:	08010593          	addi	a1,sp,128
    48e8:	00040513          	mv	a0,s0
    48ec:	a41ff0ef          	jal	432c <asset_dma_poll>
    48f0:	09b50863          	beq	a0,s11,4980 <network_asset_fetch+0x4a0>
    48f4:	08412783          	lw	a5,132(sp)
    48f8:	fb879ae3          	bne	a5,s8,48ac <network_asset_fetch+0x3cc>
    48fc:	08812783          	lw	a5,136(sp)
    4900:	01812703          	lw	a4,24(sp)
    4904:	fae796e3          	bne	a5,a4,48b0 <network_asset_fetch+0x3d0>
    4908:	11c42783          	lw	a5,284(s0)
    490c:	00c7f713          	andi	a4,a5,12
    4910:	06071863          	bnez	a4,4980 <network_asset_fetch+0x4a0>
    4914:	414c0733          	sub	a4,s8,s4
    4918:	0017d793          	srli	a5,a5,0x1
    491c:	00173713          	seqz	a4,a4
    4920:	0017f793          	andi	a5,a5,1
    4924:	04f71e63          	bne	a4,a5,4980 <network_asset_fetch+0x4a0>
    4928:	01812783          	lw	a5,24(sp)
    492c:	01892023          	sw	s8,0(s2)
    4930:	000c0b13          	mv	s6,s8
    4934:	00f12423          	sw	a5,8(sp)
    4938:	d54c6ce3          	bltu	s8,s4,4690 <network_asset_fetch+0x1b0>
    493c:	f11fc0ef          	jal	184c <gpu_platform_sync>
    4940:	000a0593          	mv	a1,s4
    4944:	000a8513          	mv	a0,s5
    4948:	f98ff0ef          	jal	40e0 <asst_crc32>
    494c:	02812783          	lw	a5,40(sp)
    4950:	fe800c93          	li	s9,-24
    4954:	daa79ce3          	bne	a5,a0,470c <network_asset_fetch+0x22c>
    4958:	ed1fc0ef          	jal	1828 <gpu_platform_cycles>
    495c:	02c12783          	lw	a5,44(sp)
    4960:	03012703          	lw	a4,48(sp)
    4964:	40f507b3          	sub	a5,a0,a5
    4968:	00f53533          	sltu	a0,a0,a5
    496c:	40e585b3          	sub	a1,a1,a4
    4970:	40a585b3          	sub	a1,a1,a0
    4974:	00f92823          	sw	a5,16(s2)
    4978:	00b92a23          	sw	a1,20(s2)
    497c:	bb1ff06f          	j	452c <network_asset_fetch+0x4c>
    4980:	fe900c93          	li	s9,-23
    4984:	f15ff06f          	j	4898 <network_asset_fetch+0x3b8>
    4988:	fe900493          	li	s1,-23
    498c:	ba1ff06f          	j	452c <network_asset_fetch+0x4c>
    4990:	e99fc0ef          	jal	1828 <gpu_platform_cycles>
    4994:	00050d13          	mv	s10,a0
    4998:	00058c93          	mv	s9,a1
    499c:	ffc00d93          	li	s11,-4
    49a0:	f45ff06f          	j	48e4 <network_asset_fetch+0x404>

000049a4 <perf_render_cpu>:
    49a4:	20050663          	beqz	a0,4bb0 <perf_render_cpu+0x20c>
    49a8:	fa010113          	addi	sp,sp,-96
    49ac:	04812c23          	sw	s0,88(sp)
    49b0:	04912a23          	sw	s1,84(sp)
    49b4:	04112e23          	sw	ra,92(sp)
    49b8:	05212823          	sw	s2,80(sp)
    49bc:	05312623          	sw	s3,76(sp)
    49c0:	05412423          	sw	s4,72(sp)
    49c4:	05512223          	sw	s5,68(sp)
    49c8:	05612023          	sw	s6,64(sp)
    49cc:	03712e23          	sw	s7,60(sp)
    49d0:	03812c23          	sw	s8,56(sp)
    49d4:	03912a23          	sw	s9,52(sp)
    49d8:	00050413          	mv	s0,a0
    49dc:	00058493          	mv	s1,a1
    49e0:	ff800513          	li	a0,-8
    49e4:	14058063          	beqz	a1,4b24 <perf_render_cpu+0x180>
    49e8:	000fda37          	lui	s4,0xfd
    49ec:	000fdab7          	lui	s5,0xfd
    49f0:	021c0b37          	lui	s6,0x21c0
    49f4:	00000993          	li	s3,0
    49f8:	02200bb7          	lui	s7,0x2200
    49fc:	02000c37          	lui	s8,0x2000
    4a00:	1ffa0a13          	addi	s4,s4,511 # fd1ff <__freertos_irq_stack_top+0xdf77f>
    4a04:	78000913          	li	s2,1920
    4a08:	200a8a93          	addi	s5,s5,512 # fd200 <__freertos_irq_stack_top+0xdf780>
    4a0c:	3c0b0b13          	addi	s6,s6,960 # 21c03c0 <__gpu_framebuffer_a+0x1c03c0>
    4a10:	00100c93          	li	s9,1
    4a14:	00442783          	lw	a5,4(s0)
    4a18:	0d77fa63          	bgeu	a5,s7,4aec <perf_render_cpu+0x148>
    4a1c:	0d87e463          	bltu	a5,s8,4ae4 <perf_render_cpu+0x140>
    4a20:	02000737          	lui	a4,0x2000
    4a24:	40e78633          	sub	a2,a5,a4
    4a28:	0aca6e63          	bltu	s4,a2,4ae4 <perf_render_cpu+0x140>
    4a2c:	00c42683          	lw	a3,12(s0)
    4a30:	0b269a63          	bne	a3,s2,4ae4 <perf_render_cpu+0x140>
    4a34:	0017f793          	andi	a5,a5,1
    4a38:	0a079663          	bnez	a5,4ae4 <perf_render_cpu+0x140>
    4a3c:	032675b3          	remu	a1,a2,s2
    4a40:	01245883          	lhu	a7,18(s0)
    4a44:	00e12823          	sw	a4,16(sp)
    4a48:	01512a23          	sw	s5,20(sp)
    4a4c:	01612c23          	sw	s6,24(sp)
    4a50:	01212e23          	sw	s2,28(sp)
    4a54:	00842303          	lw	t1,8(s0)
    4a58:	01045803          	lhu	a6,16(s0)
    4a5c:	03265633          	divu	a2,a2,s2
    4a60:	0015d593          	srli	a1,a1,0x1
    4a64:	01061613          	slli	a2,a2,0x10
    4a68:	01065613          	srli	a2,a2,0x10
    4a6c:	08088463          	beqz	a7,4af4 <perf_render_cpu+0x150>
    4a70:	fff88793          	addi	a5,a7,-1
    4a74:	02f30733          	mul	a4,t1,a5
    4a78:	0267a6b3          	mulhsu	a3,a5,t1
    4a7c:	00181793          	slli	a5,a6,0x1
    4a80:	00f707b3          	add	a5,a4,a5
    4a84:	00e7b733          	sltu	a4,a5,a4
    4a88:	00d70733          	add	a4,a4,a3
    4a8c:	00042503          	lw	a0,0(s0)
    4a90:	01c44683          	lbu	a3,28(s0)
    4a94:	02f12223          	sw	a5,36(sp)
    4a98:	02a12023          	sw	a0,32(sp)
    4a9c:	03011423          	sh	a6,40(sp)
    4aa0:	03111523          	sh	a7,42(sp)
    4aa4:	02612623          	sw	t1,44(sp)
    4aa8:	05968c63          	beq	a3,s9,4b00 <perf_render_cpu+0x15c>
    4aac:	02400337          	lui	t1,0x2400
    4ab0:	02656a63          	bltu	a0,t1,4ae4 <perf_render_cpu+0x140>
    4ab4:	00f507b3          	add	a5,a0,a5
    4ab8:	00a7b533          	sltu	a0,a5,a0
    4abc:	00e50533          	add	a0,a0,a4
    4ac0:	02051263          	bnez	a0,4ae4 <perf_render_cpu+0x140>
    4ac4:	10000737          	lui	a4,0x10000
    4ac8:	00f76e63          	bltu	a4,a5,4ae4 <perf_render_cpu+0x140>
    4acc:	00300793          	li	a5,3
    4ad0:	0af68063          	beq	a3,a5,4b70 <perf_render_cpu+0x1cc>
    4ad4:	00400793          	li	a5,4
    4ad8:	0af68c63          	beq	a3,a5,4b90 <perf_render_cpu+0x1ec>
    4adc:	00200793          	li	a5,2
    4ae0:	06f68c63          	beq	a3,a5,4b58 <perf_render_cpu+0x1b4>
    4ae4:	ff800513          	li	a0,-8
    4ae8:	03c0006f          	j	4b24 <perf_render_cpu+0x180>
    4aec:	02200737          	lui	a4,0x2200
    4af0:	f35ff06f          	j	4a24 <perf_render_cpu+0x80>
    4af4:	00000793          	li	a5,0
    4af8:	00000713          	li	a4,0
    4afc:	f91ff06f          	j	4a8c <perf_render_cpu+0xe8>
    4b00:	01445783          	lhu	a5,20(s0)
    4b04:	00088713          	mv	a4,a7
    4b08:	00080693          	mv	a3,a6
    4b0c:	01010513          	addi	a0,sp,16
    4b10:	cedfd0ef          	jal	27fc <golden_fill>
    4b14:	00051863          	bnez	a0,4b24 <perf_render_cpu+0x180>
    4b18:	00198993          	addi	s3,s3,1
    4b1c:	02040413          	addi	s0,s0,32
    4b20:	ef349ae3          	bne	s1,s3,4a14 <perf_render_cpu+0x70>
    4b24:	05c12083          	lw	ra,92(sp)
    4b28:	05812403          	lw	s0,88(sp)
    4b2c:	05412483          	lw	s1,84(sp)
    4b30:	05012903          	lw	s2,80(sp)
    4b34:	04c12983          	lw	s3,76(sp)
    4b38:	04812a03          	lw	s4,72(sp)
    4b3c:	04412a83          	lw	s5,68(sp)
    4b40:	04012b03          	lw	s6,64(sp)
    4b44:	03c12b83          	lw	s7,60(sp)
    4b48:	03812c03          	lw	s8,56(sp)
    4b4c:	03412c83          	lw	s9,52(sp)
    4b50:	06010113          	addi	sp,sp,96
    4b54:	00008067          	ret
    4b58:	00000793          	li	a5,0
    4b5c:	00000713          	li	a4,0
    4b60:	02010693          	addi	a3,sp,32
    4b64:	01010513          	addi	a0,sp,16
    4b68:	d75fd0ef          	jal	28dc <golden_copy>
    4b6c:	fa9ff06f          	j	4b14 <perf_render_cpu+0x170>
    4b70:	01645783          	lhu	a5,22(s0)
    4b74:	00000713          	li	a4,0
    4b78:	02010693          	addi	a3,sp,32
    4b7c:	00f12023          	sw	a5,0(sp)
    4b80:	01010513          	addi	a0,sp,16
    4b84:	00000793          	li	a5,0
    4b88:	f0dfd0ef          	jal	2a94 <golden_color_key>
    4b8c:	f89ff06f          	j	4b14 <perf_render_cpu+0x170>
    4b90:	01d44783          	lbu	a5,29(s0)
    4b94:	00000713          	li	a4,0
    4b98:	02010693          	addi	a3,sp,32
    4b9c:	00f12023          	sw	a5,0(sp)
    4ba0:	01010513          	addi	a0,sp,16
    4ba4:	00000793          	li	a5,0
    4ba8:	fc1fd0ef          	jal	2b68 <golden_alpha_blend>
    4bac:	f69ff06f          	j	4b14 <perf_render_cpu+0x170>
    4bb0:	ff800513          	li	a0,-8
    4bb4:	00008067          	ret

00004bb8 <perf_render_gpu>:
    4bb8:	08050863          	beqz	a0,4c48 <perf_render_gpu+0x90>
    4bbc:	fc010113          	addi	sp,sp,-64
    4bc0:	02812c23          	sw	s0,56(sp)
    4bc4:	03312623          	sw	s3,44(sp)
    4bc8:	02112e23          	sw	ra,60(sp)
    4bcc:	02912a23          	sw	s1,52(sp)
    4bd0:	03212823          	sw	s2,48(sp)
    4bd4:	00050413          	mv	s0,a0
    4bd8:	00058993          	mv	s3,a1
    4bdc:	ff800513          	li	a0,-8
    4be0:	04058663          	beqz	a1,4c2c <perf_render_gpu+0x74>
    4be4:	00060913          	mv	s2,a2
    4be8:	04060263          	beqz	a2,4c2c <perf_render_gpu+0x74>
    4bec:	00068613          	mv	a2,a3
    4bf0:	00011f23          	sh	zero,30(sp)
    4bf4:	00000493          	li	s1,0
    4bf8:	00549593          	slli	a1,s1,0x5
    4bfc:	01e10693          	addi	a3,sp,30
    4c00:	00b985b3          	add	a1,s3,a1
    4c04:	00040513          	mv	a0,s0
    4c08:	00c12623          	sw	a2,12(sp)
    4c0c:	a7cfd0ef          	jal	1e88 <gpu_submit>
    4c10:	00051e63          	bnez	a0,4c2c <perf_render_gpu+0x74>
    4c14:	00148493          	addi	s1,s1,1
    4c18:	00c12603          	lw	a2,12(sp)
    4c1c:	fc991ee3          	bne	s2,s1,4bf8 <perf_render_gpu+0x40>
    4c20:	01e15583          	lhu	a1,30(sp)
    4c24:	00040513          	mv	a0,s0
    4c28:	fa0fd0ef          	jal	23c8 <gpu_wait_tag>
    4c2c:	03c12083          	lw	ra,60(sp)
    4c30:	03812403          	lw	s0,56(sp)
    4c34:	03412483          	lw	s1,52(sp)
    4c38:	03012903          	lw	s2,48(sp)
    4c3c:	02c12983          	lw	s3,44(sp)
    4c40:	04010113          	addi	sp,sp,64
    4c44:	00008067          	ret
    4c48:	ff800513          	li	a0,-8
    4c4c:	00008067          	ret

00004c50 <perf_window_add>:
    4c50:	00050793          	mv	a5,a0
    4c54:	0a050263          	beqz	a0,4cf8 <perf_window_add+0xa8>
    4c58:	00c5e833          	or	a6,a1,a2
    4c5c:	ff800513          	li	a0,-8
    4c60:	08080e63          	beqz	a6,4cfc <perf_window_add+0xac>
    4c64:	08e66a63          	bltu	a2,a4,4cf8 <perf_window_add+0xa8>
    4c68:	00c71463          	bne	a4,a2,4c70 <perf_window_add+0x20>
    4c6c:	08d5e663          	bltu	a1,a3,4cf8 <perf_window_add+0xa8>
    4c70:	0107a883          	lw	a7,16(a5)
    4c74:	01d00813          	li	a6,29
    4c78:	ff800513          	li	a0,-8
    4c7c:	09186063          	bltu	a6,a7,4cfc <perf_window_add+0xac>
    4c80:	0047ae03          	lw	t3,4(a5)
    4c84:	0007a803          	lw	a6,0(a5)
    4c88:	fffe4513          	not	a0,t3
    4c8c:	fff84313          	not	t1,a6
    4c90:	06c56463          	bltu	a0,a2,4cf8 <perf_window_add+0xa8>
    4c94:	00a61463          	bne	a2,a0,4c9c <perf_window_add+0x4c>
    4c98:	06b36063          	bltu	t1,a1,4cf8 <perf_window_add+0xa8>
    4c9c:	00c7a303          	lw	t1,12(a5)
    4ca0:	0087a503          	lw	a0,8(a5)
    4ca4:	fff34e93          	not	t4,t1
    4ca8:	fff54f13          	not	t5,a0
    4cac:	04eee663          	bltu	t4,a4,4cf8 <perf_window_add+0xa8>
    4cb0:	01d71463          	bne	a4,t4,4cb8 <perf_window_add+0x68>
    4cb4:	04df6263          	bltu	t5,a3,4cf8 <perf_window_add+0xa8>
    4cb8:	00b805b3          	add	a1,a6,a1
    4cbc:	00d506b3          	add	a3,a0,a3
    4cc0:	0105b833          	sltu	a6,a1,a6
    4cc4:	00ce0e33          	add	t3,t3,a2
    4cc8:	00a6b533          	sltu	a0,a3,a0
    4ccc:	00e30333          	add	t1,t1,a4
    4cd0:	00650533          	add	a0,a0,t1
    4cd4:	01c80833          	add	a6,a6,t3
    4cd8:	00188893          	addi	a7,a7,1
    4cdc:	00a7a623          	sw	a0,12(a5)
    4ce0:	00b7a023          	sw	a1,0(a5)
    4ce4:	0107a223          	sw	a6,4(a5)
    4ce8:	00d7a423          	sw	a3,8(a5)
    4cec:	0117a823          	sw	a7,16(a5)
    4cf0:	00000513          	li	a0,0
    4cf4:	00008067          	ret
    4cf8:	ff800513          	li	a0,-8
    4cfc:	00008067          	ret

00004d00 <perf_fps_x10>:
    4d00:	00050793          	mv	a5,a0
    4d04:	06050663          	beqz	a0,4d70 <perf_fps_x10+0x70>
    4d08:	00052603          	lw	a2,0(a0)
    4d0c:	00452683          	lw	a3,4(a0)
    4d10:	00d66733          	or	a4,a2,a3
    4d14:	04070e63          	beqz	a4,4d70 <perf_fps_x10+0x70>
    4d18:	00058513          	mv	a0,a1
    4d1c:	0107a583          	lw	a1,16(a5)
    4d20:	01d00793          	li	a5,29
    4d24:	fff58713          	addi	a4,a1,-1
    4d28:	04e7e463          	bltu	a5,a4,4d70 <perf_fps_x10+0x70>
    4d2c:	04050a63          	beqz	a0,4d80 <perf_fps_x10+0x80>
    4d30:	02a58733          	mul	a4,a1,a0
    4d34:	ff010113          	addi	sp,sp,-16
    4d38:	00112623          	sw	ra,12(sp)
    4d3c:	02a5b5b3          	mulhu	a1,a1,a0
    4d40:	00a00513          	li	a0,10
    4d44:	02b505b3          	mul	a1,a0,a1
    4d48:	02e53833          	mulhu	a6,a0,a4
    4d4c:	02e50533          	mul	a0,a0,a4
    4d50:	010585b3          	add	a1,a1,a6
    4d54:	421070ef          	jal	c974 <__udivdi3>
    4d58:	02059063          	bnez	a1,4d78 <perf_fps_x10+0x78>
    4d5c:	ffe00793          	li	a5,-2
    4d60:	00a7ec63          	bltu	a5,a0,4d78 <perf_fps_x10+0x78>
    4d64:	00c12083          	lw	ra,12(sp)
    4d68:	01010113          	addi	sp,sp,16
    4d6c:	00008067          	ret
    4d70:	00000513          	li	a0,0
    4d74:	00008067          	ret
    4d78:	fff00513          	li	a0,-1
    4d7c:	fe9ff06f          	j	4d64 <perf_fps_x10+0x64>
    4d80:	00008067          	ret

00004d84 <perf_render_us>:
    4d84:	00050793          	mv	a5,a0
    4d88:	0e050063          	beqz	a0,4e68 <perf_render_us+0xe4>
    4d8c:	01052703          	lw	a4,16(a0)
    4d90:	01d00693          	li	a3,29
    4d94:	fff70613          	addi	a2,a4,-1 # 21fffff <__gpu_framebuffer_a+0x1fffff>
    4d98:	0cc6e863          	bltu	a3,a2,4e68 <perf_render_us+0xe4>
    4d9c:	00058513          	mv	a0,a1
    4da0:	0c058c63          	beqz	a1,4e78 <perf_render_us+0xf4>
    4da4:	02b70633          	mul	a2,a4,a1
    4da8:	fe010113          	addi	sp,sp,-32
    4dac:	01212a23          	sw	s2,20(sp)
    4db0:	01312823          	sw	s3,16(sp)
    4db4:	0087a903          	lw	s2,8(a5)
    4db8:	00c7a983          	lw	s3,12(a5)
    4dbc:	00812c23          	sw	s0,24(sp)
    4dc0:	00090513          	mv	a0,s2
    4dc4:	00112e23          	sw	ra,28(sp)
    4dc8:	02b736b3          	mulhu	a3,a4,a1
    4dcc:	00098593          	mv	a1,s3
    4dd0:	00c12623          	sw	a2,12(sp)
    4dd4:	00d12423          	sw	a3,8(sp)
    4dd8:	39d070ef          	jal	c974 <__udivdi3>
    4ddc:	00050413          	mv	s0,a0
    4de0:	08059863          	bnez	a1,4e70 <perf_render_us+0xec>
    4de4:	000017b7          	lui	a5,0x1
    4de8:	0c678793          	addi	a5,a5,198 # 10c6 <memcmp+0x5a>
    4dec:	08a7e263          	bltu	a5,a0,4e70 <perf_render_us+0xec>
    4df0:	00c12603          	lw	a2,12(sp)
    4df4:	00812683          	lw	a3,8(sp)
    4df8:	00090513          	mv	a0,s2
    4dfc:	00098593          	mv	a1,s3
    4e00:	000f4937          	lui	s2,0xf4
    4e04:	020080ef          	jal	ce24 <__umoddi3>
    4e08:	24090913          	addi	s2,s2,576 # f4240 <__freertos_irq_stack_top+0xd67c0>
    4e0c:	032537b3          	mulhu	a5,a0,s2
    4e10:	00c12603          	lw	a2,12(sp)
    4e14:	00812683          	lw	a3,8(sp)
    4e18:	032585b3          	mul	a1,a1,s2
    4e1c:	03250533          	mul	a0,a0,s2
    4e20:	00f585b3          	add	a1,a1,a5
    4e24:	351070ef          	jal	c974 <__udivdi3>
    4e28:	028907b3          	mul	a5,s2,s0
    4e2c:	00050713          	mv	a4,a0
    4e30:	03243433          	mulhu	s0,s0,s2
    4e34:	00f50533          	add	a0,a0,a5
    4e38:	00e53733          	sltu	a4,a0,a4
    4e3c:	008585b3          	add	a1,a1,s0
    4e40:	00b70733          	add	a4,a4,a1
    4e44:	02071663          	bnez	a4,4e70 <perf_render_us+0xec>
    4e48:	ffe00793          	li	a5,-2
    4e4c:	02a7e263          	bltu	a5,a0,4e70 <perf_render_us+0xec>
    4e50:	01c12083          	lw	ra,28(sp)
    4e54:	01812403          	lw	s0,24(sp)
    4e58:	01412903          	lw	s2,20(sp)
    4e5c:	01012983          	lw	s3,16(sp)
    4e60:	02010113          	addi	sp,sp,32
    4e64:	00008067          	ret
    4e68:	00000513          	li	a0,0
    4e6c:	00008067          	ret
    4e70:	fff00513          	li	a0,-1
    4e74:	fddff06f          	j	4e50 <perf_render_us+0xcc>
    4e78:	00008067          	ret

00004e7c <append>:
    4e7c:	ff010113          	addi	sp,sp,-16
    4e80:	00812423          	sw	s0,8(sp)
    4e84:	00009437          	lui	s0,0x9
    4e88:	00850433          	add	s0,a0,s0
    4e8c:	12042783          	lw	a5,288(s0) # 9120 <v3_runtime_advance+0xc0>
    4e90:	00112623          	sw	ra,12(sp)
    4e94:	00912223          	sw	s1,4(sp)
    4e98:	06b78e63          	beq	a5,a1,4f14 <append+0x98>
    4e9c:	00060493          	mv	s1,a2
    4ea0:	00178713          	addi	a4,a5,1
    4ea4:	00579793          	slli	a5,a5,0x5
    4ea8:	12e42023          	sw	a4,288(s0)
    4eac:	00f50533          	add	a0,a0,a5
    4eb0:	02000613          	li	a2,32
    4eb4:	00048593          	mv	a1,s1
    4eb8:	c4cfc0ef          	jal	1304 <memcpy>
    4ebc:	0124d703          	lhu	a4,18(s1)
    4ec0:	0104d783          	lhu	a5,16(s1)
    4ec4:	02e787b3          	mul	a5,a5,a4
    4ec8:	12842703          	lw	a4,296(s0)
    4ecc:	00f70733          	add	a4,a4,a5
    4ed0:	12e42423          	sw	a4,296(s0)
    4ed4:	01c4c683          	lbu	a3,28(s1)
    4ed8:	00400713          	li	a4,4
    4edc:	00e68e63          	beq	a3,a4,4ef8 <append+0x7c>
    4ee0:	00000513          	li	a0,0
    4ee4:	00c12083          	lw	ra,12(sp)
    4ee8:	00812403          	lw	s0,8(sp)
    4eec:	00412483          	lw	s1,4(sp)
    4ef0:	01010113          	addi	sp,sp,16
    4ef4:	00008067          	ret
    4ef8:	12c42703          	lw	a4,300(s0)
    4efc:	00170713          	addi	a4,a4,1
    4f00:	12e42623          	sw	a4,300(s0)
    4f04:	13042703          	lw	a4,304(s0)
    4f08:	00f707b3          	add	a5,a4,a5
    4f0c:	12f42823          	sw	a5,304(s0)
    4f10:	fd1ff06f          	j	4ee0 <append+0x64>
    4f14:	ffc00513          	li	a0,-4
    4f18:	fcdff06f          	j	4ee4 <append+0x68>

00004f1c <pixel_coordinate>:
    4f1c:	00050793          	mv	a5,a0
    4f20:	10000513          	li	a0,256
    4f24:	02a7c533          	div	a0,a5,a0
    4f28:	0007d863          	bgez	a5,4f38 <pixel_coordinate+0x1c>
    4f2c:	0ff7f793          	zext.b	a5,a5
    4f30:	00078463          	beqz	a5,4f38 <pixel_coordinate+0x1c>
    4f34:	fff50513          	addi	a0,a0,-1
    4f38:	00008067          	ret

00004f3c <bullet_campaign_valid>:
    4f3c:	06050a63          	beqz	a0,4fb0 <bullet_campaign_valid+0x74>
    4f40:	000057b7          	lui	a5,0x5
    4f44:	00f507b3          	add	a5,a0,a5
    4f48:	0287c803          	lbu	a6,40(a5) # 5028 <bullet_enemy_position+0x70>
    4f4c:	00100713          	li	a4,1
    4f50:	00000513          	li	a0,0
    4f54:	07076063          	bltu	a4,a6,4fb4 <bullet_campaign_valid+0x78>
    4f58:	0297c603          	lbu	a2,41(a5)
    4f5c:	04c76c63          	bltu	a4,a2,4fb4 <bullet_campaign_valid+0x78>
    4f60:	0257c703          	lbu	a4,37(a5)
    4f64:	00600593          	li	a1,6
    4f68:	04e5e663          	bltu	a1,a4,4fb4 <bullet_campaign_valid+0x78>
    4f6c:	0267c683          	lbu	a3,38(a5)
    4f70:	04d5e263          	bltu	a1,a3,4fb4 <bullet_campaign_valid+0x78>
    4f74:	00d766b3          	or	a3,a4,a3
    4f78:	0277c703          	lbu	a4,39(a5)
    4f7c:	02e5ec63          	bltu	a1,a4,4fb4 <bullet_campaign_valid+0x78>
    4f80:	00d76733          	or	a4,a4,a3
    4f84:	00081863          	bnez	a6,4f94 <bullet_campaign_valid+0x58>
    4f88:	02071663          	bnez	a4,4fb4 <bullet_campaign_valid+0x78>
    4f8c:	00164513          	xori	a0,a2,1
    4f90:	00008067          	ret
    4f94:	00e03533          	snez	a0,a4
    4f98:	00060e63          	beqz	a2,4fb4 <bullet_campaign_valid+0x78>
    4f9c:	00000513          	li	a0,0
    4fa0:	00071a63          	bnez	a4,4fb4 <bullet_campaign_valid+0x78>
    4fa4:	0247c503          	lbu	a0,36(a5)
    4fa8:	00a03533          	snez	a0,a0
    4fac:	00008067          	ret
    4fb0:	00000513          	li	a0,0
    4fb4:	00008067          	ret

00004fb8 <bullet_enemy_position>:
    4fb8:	00050793          	mv	a5,a0
    4fbc:	14050a63          	beqz	a0,5110 <bullet_enemy_position+0x158>
    4fc0:	00200713          	li	a4,2
    4fc4:	ff800513          	li	a0,-8
    4fc8:	14b76663          	bltu	a4,a1,5114 <bullet_enemy_position+0x15c>
    4fcc:	14060463          	beqz	a2,5114 <bullet_enemy_position+0x15c>
    4fd0:	14068263          	beqz	a3,5114 <bullet_enemy_position+0x15c>
    4fd4:	0000e737          	lui	a4,0xe
    4fd8:	00359513          	slli	a0,a1,0x3
    4fdc:	cd870713          	addi	a4,a4,-808 # dcd8 <centers>
    4fe0:	00a70733          	add	a4,a4,a0
    4fe4:	00072503          	lw	a0,0(a4)
    4fe8:	00472303          	lw	t1,4(a4)
    4fec:	00005737          	lui	a4,0x5
    4ff0:	00a62023          	sw	a0,0(a2)
    4ff4:	0066a023          	sw	t1,0(a3)
    4ff8:	00e78533          	add	a0,a5,a4
    4ffc:	02854783          	lbu	a5,40(a0)
    5000:	00078663          	beqz	a5,500c <bullet_enemy_position+0x54>
    5004:	01452f83          	lw	t6,20(a0)
    5008:	000f9663          	bnez	t6,5014 <bullet_enemy_position+0x5c>
    500c:	00000513          	li	a0,0
    5010:	00008067          	ret
    5014:	07800813          	li	a6,120
    5018:	030fd733          	divu	a4,t6,a6
    501c:	9e3787b7          	lui	a5,0x9e378
    5020:	00158893          	addi	a7,a1,1
    5024:	9b978793          	addi	a5,a5,-1607 # 9e3779b9 <__gpu_framebuffer_a+0x9c3779b9>
    5028:	85ebdf37          	lui	t5,0x85ebd
    502c:	a6bf0f13          	addi	t5,t5,-1429 # 85ebca6b <__gpu_framebuffer_a+0x83ebca6b>
    5030:	7feb3eb7          	lui	t4,0x7feb3
    5034:	52de8e93          	addi	t4,t4,1325 # 7feb352d <__gpu_framebuffer_a+0x7deb352d>
    5038:	0000ee37          	lui	t3,0xe
    503c:	ccce0e13          	addi	t3,t3,-820 # dccc <minimum_y.2>
    5040:	00259593          	slli	a1,a1,0x2
    5044:	00be05b3          	add	a1,t3,a1
    5048:	07700293          	li	t0,119
    504c:	0005a583          	lw	a1,0(a1)
    5050:	02f888b3          	mul	a7,a7,a5
    5054:	00052783          	lw	a5,0(a0)
    5058:	00f8c8b3          	xor	a7,a7,a5
    505c:	03e707b3          	mul	a5,a4,t5
    5060:	0117c7b3          	xor	a5,a5,a7
    5064:	0107d513          	srli	a0,a5,0x10
    5068:	00a7c7b3          	xor	a5,a5,a0
    506c:	03d787b3          	mul	a5,a5,t4
    5070:	00f7d513          	srli	a0,a5,0xf
    5074:	00a7c7b3          	xor	a5,a5,a0
    5078:	00062503          	lw	a0,0(a2)
    507c:	030ff833          	remu	a6,t6,a6
    5080:	f8850e13          	addi	t3,a0,-120
    5084:	05f2f063          	bgeu	t0,t6,50c4 <bullet_enemy_position+0x10c>
    5088:	fff70713          	addi	a4,a4,-1 # 4fff <bullet_enemy_position+0x47>
    508c:	03e70733          	mul	a4,a4,t5
    5090:	01174733          	xor	a4,a4,a7
    5094:	01075513          	srli	a0,a4,0x10
    5098:	00a74733          	xor	a4,a4,a0
    509c:	03d70733          	mul	a4,a4,t4
    50a0:	06100893          	li	a7,97
    50a4:	00f75513          	srli	a0,a4,0xf
    50a8:	00a74733          	xor	a4,a4,a0
    50ac:	0f100513          	li	a0,241
    50b0:	02a77533          	remu	a0,a4,a0
    50b4:	01075713          	srli	a4,a4,0x10
    50b8:	03177733          	remu	a4,a4,a7
    50bc:	01c50533          	add	a0,a0,t3
    50c0:	00b70333          	add	t1,a4,a1
    50c4:	0f100713          	li	a4,241
    50c8:	02e7f733          	remu	a4,a5,a4
    50cc:	07800893          	li	a7,120
    50d0:	0107d793          	srli	a5,a5,0x10
    50d4:	01c70733          	add	a4,a4,t3
    50d8:	40a70733          	sub	a4,a4,a0
    50dc:	03070733          	mul	a4,a4,a6
    50e0:	03174733          	div	a4,a4,a7
    50e4:	00a70733          	add	a4,a4,a0
    50e8:	00e62023          	sw	a4,0(a2)
    50ec:	06100713          	li	a4,97
    50f0:	02e7f7b3          	remu	a5,a5,a4
    50f4:	00b787b3          	add	a5,a5,a1
    50f8:	406787b3          	sub	a5,a5,t1
    50fc:	030787b3          	mul	a5,a5,a6
    5100:	0317c7b3          	div	a5,a5,a7
    5104:	006787b3          	add	a5,a5,t1
    5108:	00f6a023          	sw	a5,0(a3)
    510c:	f01ff06f          	j	500c <bullet_enemy_position+0x54>
    5110:	ff800513          	li	a0,-8
    5114:	00008067          	ret

00005118 <spawn>:
    5118:	000057b7          	lui	a5,0x5
    511c:	fc010113          	addi	sp,sp,-64
    5120:	00f507b3          	add	a5,a0,a5
    5124:	02812c23          	sw	s0,56(sp)
    5128:	0147a403          	lw	s0,20(a5) # 5014 <bullet_enemy_position+0x5c>
    512c:	03c00713          	li	a4,60
    5130:	03512223          	sw	s5,36(sp)
    5134:	02e45733          	divu	a4,s0,a4
    5138:	00300a93          	li	s5,3
    513c:	01712e23          	sw	s7,28(sp)
    5140:	02912a23          	sw	s1,52(sp)
    5144:	03212823          	sw	s2,48(sp)
    5148:	03412423          	sw	s4,40(sp)
    514c:	03612023          	sw	s6,32(sp)
    5150:	01912a23          	sw	s9,20(sp)
    5154:	02112e23          	sw	ra,60(sp)
    5158:	03312623          	sw	s3,44(sp)
    515c:	01812c23          	sw	s8,24(sp)
    5160:	0007a483          	lw	s1,0(a5)
    5164:	00050a13          	mv	s4,a0
    5168:	00058913          	mv	s2,a1
    516c:	00000c93          	li	s9,0
    5170:	0355fbb3          	remu	s7,a1,s5
    5174:	00377b13          	andi	s6,a4,3
    5178:	00200713          	li	a4,2
    517c:	0355dab3          	divu	s5,a1,s5
    5180:	00eb9663          	bne	s7,a4,518c <spawn+0x74>
    5184:	0047ac83          	lw	s9,4(a5)
    5188:	003cdc93          	srli	s9,s9,0x3
    518c:	00000993          	li	s3,0
    5190:	00060e63          	beqz	a2,51ac <spawn+0x94>
    5194:	03000993          	li	s3,48
    5198:	00a00793          	li	a5,10
    519c:	033959b3          	divu	s3,s2,s3
    51a0:	02f9f9b3          	remu	s3,s3,a5
    51a4:	00198993          	addi	s3,s3,1
    51a8:	00499993          	slli	s3,s3,0x4
    51ac:	00100713          	li	a4,1
    51b0:	0f000793          	li	a5,240
    51b4:	00eb8a63          	beq	s7,a4,51c8 <spawn+0xb0>
    51b8:	00200713          	li	a4,2
    51bc:	1e000793          	li	a5,480
    51c0:	00eb9463          	bne	s7,a4,51c8 <spawn+0xb0>
    51c4:	2d000793          	li	a5,720
    51c8:	00f12423          	sw	a5,8(sp)
    51cc:	00100713          	li	a4,1
    51d0:	06400793          	li	a5,100
    51d4:	00eb8a63          	beq	s7,a4,51e8 <spawn+0xd0>
    51d8:	00200713          	li	a4,2
    51dc:	11800793          	li	a5,280
    51e0:	00eb9463          	bne	s7,a4,51e8 <spawn+0xd0>
    51e4:	0dc00793          	li	a5,220
    51e8:	00f12623          	sw	a5,12(sp)
    51ec:	000057b7          	lui	a5,0x5
    51f0:	00fa07b3          	add	a5,s4,a5
    51f4:	0287cc03          	lbu	s8,40(a5) # 5028 <bullet_enemy_position+0x70>
    51f8:	000c0c63          	beqz	s8,5210 <spawn+0xf8>
    51fc:	00c10693          	addi	a3,sp,12
    5200:	00810613          	addi	a2,sp,8
    5204:	000b8593          	mv	a1,s7
    5208:	000a0513          	mv	a0,s4
    520c:	dadff0ef          	jal	4fb8 <bullet_enemy_position>
    5210:	00100793          	li	a5,1
    5214:	0efb8e63          	beq	s7,a5,5310 <spawn+0x1f8>
    5218:	0074c793          	xori	a5,s1,7
    521c:	015787b3          	add	a5,a5,s5
    5220:	002b1713          	slli	a4,s6,0x2
    5224:	00e787b3          	add	a5,a5,a4
    5228:	019787b3          	add	a5,a5,s9
    522c:	00f7f793          	andi	a5,a5,15
    5230:	0000e6b7          	lui	a3,0xe
    5234:	cf068713          	addi	a4,a3,-784 # dcf0 <directions>
    5238:	00279793          	slli	a5,a5,0x2
    523c:	00f70733          	add	a4,a4,a5
    5240:	00071583          	lh	a1,0(a4)
    5244:	00271703          	lh	a4,2(a4)
    5248:	00c12803          	lw	a6,12(sp)
    524c:	033587b3          	mul	a5,a1,s3
    5250:	00812603          	lw	a2,8(sp)
    5254:	00881813          	slli	a6,a6,0x8
    5258:	cf068693          	addi	a3,a3,-784
    525c:	00861613          	slli	a2,a2,0x8
    5260:	02e98533          	mul	a0,s3,a4
    5264:	00f60633          	add	a2,a2,a5
    5268:	01400793          	li	a5,20
    526c:	00a809b3          	add	s3,a6,a0
    5270:	006b0813          	addi	a6,s6,6
    5274:	03070733          	mul	a4,a4,a6
    5278:	00400513          	li	a0,4
    527c:	02a74733          	div	a4,a4,a0
    5280:	02f907b3          	mul	a5,s2,a5
    5284:	030585b3          	mul	a1,a1,a6
    5288:	00fa07b3          	add	a5,s4,a5
    528c:	00e79523          	sh	a4,10(a5)
    5290:	00600813          	li	a6,6
    5294:	01690733          	add	a4,s2,s6
    5298:	00c7a023          	sw	a2,0(a5)
    529c:	0137a223          	sw	s3,4(a5)
    52a0:	01778723          	sb	s7,14(a5)
    52a4:	00079623          	sh	zero,12(a5)
    52a8:	00079823          	sh	zero,16(a5)
    52ac:	02a5c5b3          	div	a1,a1,a0
    52b0:	03077733          	remu	a4,a4,a6
    52b4:	00b79423          	sh	a1,8(a5)
    52b8:	00e787a3          	sb	a4,15(a5)
    52bc:	020c0063          	beqz	s8,52dc <spawn+0x1c4>
    52c0:	017a05b3          	add	a1,s4,s7
    52c4:	00005737          	lui	a4,0x5
    52c8:	00b70733          	add	a4,a4,a1
    52cc:	02574703          	lbu	a4,37(a4) # 5025 <bullet_enemy_position+0x6d>
    52d0:	04071e63          	bnez	a4,532c <spawn+0x214>
    52d4:	fff00713          	li	a4,-1
    52d8:	00e79623          	sh	a4,12(a5)
    52dc:	03c12083          	lw	ra,60(sp)
    52e0:	03812403          	lw	s0,56(sp)
    52e4:	03412483          	lw	s1,52(sp)
    52e8:	03012903          	lw	s2,48(sp)
    52ec:	02c12983          	lw	s3,44(sp)
    52f0:	02812a03          	lw	s4,40(sp)
    52f4:	02412a83          	lw	s5,36(sp)
    52f8:	02012b03          	lw	s6,32(sp)
    52fc:	01c12b83          	lw	s7,28(sp)
    5300:	01812c03          	lw	s8,24(sp)
    5304:	01412c83          	lw	s9,20(sp)
    5308:	04010113          	addi	sp,sp,64
    530c:	00008067          	ret
    5310:	00500713          	li	a4,5
    5314:	02eaf733          	remu	a4,s5,a4
    5318:	001b1793          	slli	a5,s6,0x1
    531c:	0027f793          	andi	a5,a5,2
    5320:	00170713          	addi	a4,a4,1
    5324:	00e787b3          	add	a5,a5,a4
    5328:	f09ff06f          	j	5230 <spawn+0x118>
    532c:	0b400713          	li	a4,180
    5330:	02e45733          	divu	a4,s0,a4
    5334:	01270733          	add	a4,a4,s2
    5338:	03077733          	remu	a4,a4,a6
    533c:	00e788a3          	sb	a4,17(a5)
    5340:	fff70713          	addi	a4,a4,-1
    5344:	0ff77713          	zext.b	a4,a4
    5348:	f8e56ae3          	bltu	a0,a4,52dc <spawn+0x1c4>
    534c:	0000e5b7          	lui	a1,0xe
    5350:	00271713          	slli	a4,a4,0x2
    5354:	c7458593          	addi	a1,a1,-908 # dc74 <comparison_letters+0xf4>
    5358:	00b70733          	add	a4,a4,a1
    535c:	00072703          	lw	a4,0(a4)
    5360:	00070067          	jr	a4
    5364:	00005737          	lui	a4,0x5
    5368:	00ea0a33          	add	s4,s4,a4
    536c:	00ca2683          	lw	a3,12(s4)
    5370:	010a2703          	lw	a4,16(s4)
    5374:	00869693          	slli	a3,a3,0x8
    5378:	00871713          	slli	a4,a4,0x8
    537c:	40c686b3          	sub	a3,a3,a2
    5380:	41370733          	sub	a4,a4,s3
    5384:	41f6d513          	srai	a0,a3,0x1f
    5388:	41f75813          	srai	a6,a4,0x1f
    538c:	00d54633          	xor	a2,a0,a3
    5390:	00e845b3          	xor	a1,a6,a4
    5394:	410585b3          	sub	a1,a1,a6
    5398:	40a60633          	sub	a2,a2,a0
    539c:	00b65463          	bge	a2,a1,53a4 <spawn+0x28c>
    53a0:	00058613          	mv	a2,a1
    53a4:	00000593          	li	a1,0
    53a8:	00060a63          	beqz	a2,53bc <spawn+0x2a4>
    53ac:	00969693          	slli	a3,a3,0x9
    53b0:	02c6c6b3          	div	a3,a3,a2
    53b4:	01069593          	slli	a1,a3,0x10
    53b8:	4105d593          	srai	a1,a1,0x10
    53bc:	00b79423          	sh	a1,8(a5)
    53c0:	20000693          	li	a3,512
    53c4:	00060a63          	beqz	a2,53d8 <spawn+0x2c0>
    53c8:	00971713          	slli	a4,a4,0x9
    53cc:	02c74733          	div	a4,a4,a2
    53d0:	01071693          	slli	a3,a4,0x10
    53d4:	4106d693          	srai	a3,a3,0x10
    53d8:	00d79523          	sh	a3,10(a5)
    53dc:	f01ff06f          	j	52dc <spawn+0x1c4>
    53e0:	00500713          	li	a4,5
    53e4:	02e97733          	remu	a4,s2,a4
    53e8:	06000693          	li	a3,96
    53ec:	ffe70713          	addi	a4,a4,-2 # 4ffe <bullet_enemy_position+0x46>
    53f0:	02d70733          	mul	a4,a4,a3
    53f4:	08070713          	addi	a4,a4,128
    53f8:	00e79423          	sh	a4,8(a5)
    53fc:	18000713          	li	a4,384
    5400:	0240006f          	j	5424 <spawn+0x30c>
    5404:	00fafa93          	andi	s5,s5,15
    5408:	002a9a93          	slli	s5,s5,0x2
    540c:	015686b3          	add	a3,a3,s5
    5410:	0006d703          	lhu	a4,0(a3)
    5414:	00171713          	slli	a4,a4,0x1
    5418:	00e79423          	sh	a4,8(a5)
    541c:	0026d703          	lhu	a4,2(a3)
    5420:	00171713          	slli	a4,a4,0x1
    5424:	00e79523          	sh	a4,10(a5)
    5428:	eb5ff06f          	j	52dc <spawn+0x1c4>
    542c:	00500713          	li	a4,5
    5430:	02e97733          	remu	a4,s2,a4
    5434:	06000693          	li	a3,96
    5438:	ffe70713          	addi	a4,a4,-2
    543c:	02d70733          	mul	a4,a4,a3
    5440:	00e79423          	sh	a4,8(a5)
    5444:	0c000713          	li	a4,192
    5448:	fddff06f          	j	5424 <spawn+0x30c>
    544c:	00197913          	andi	s2,s2,1
    5450:	e0000713          	li	a4,-512
    5454:	fa0902e3          	beqz	s2,53f8 <spawn+0x2e0>
    5458:	20000713          	li	a4,512
    545c:	f9dff06f          	j	53f8 <spawn+0x2e0>

00005460 <bullet_reset>:
    5460:	0a050463          	beqz	a0,5508 <bullet_reset+0xa8>
    5464:	ff010113          	addi	sp,sp,-16
    5468:	00812423          	sw	s0,8(sp)
    546c:	00112623          	sw	ra,12(sp)
    5470:	00912223          	sw	s1,4(sp)
    5474:	01212023          	sw	s2,0(sp)
    5478:	fff58713          	addi	a4,a1,-1
    547c:	3ff00693          	li	a3,1023
    5480:	00058413          	mv	s0,a1
    5484:	ff800793          	li	a5,-8
    5488:	06e6e263          	bltu	a3,a4,54ec <bullet_reset+0x8c>
    548c:	00060913          	mv	s2,a2
    5490:	00005637          	lui	a2,0x5
    5494:	02c60613          	addi	a2,a2,44 # 502c <bullet_enemy_position+0x74>
    5498:	00000593          	li	a1,0
    549c:	00050493          	mv	s1,a0
    54a0:	d89fb0ef          	jal	1228 <memset>
    54a4:	000057b7          	lui	a5,0x5
    54a8:	00f487b3          	add	a5,s1,a5
    54ac:	1e000713          	li	a4,480
    54b0:	00e7a623          	sw	a4,12(a5) # 500c <bullet_enemy_position+0x54>
    54b4:	00e7a823          	sw	a4,16(a5)
    54b8:	00300713          	li	a4,3
    54bc:	0127a023          	sw	s2,0(a5)
    54c0:	0087a423          	sw	s0,8(a5)
    54c4:	02e78223          	sb	a4,36(a5)
    54c8:	02078423          	sb	zero,40(a5)
    54cc:	00000913          	li	s2,0
    54d0:	00090593          	mv	a1,s2
    54d4:	00100613          	li	a2,1
    54d8:	00048513          	mv	a0,s1
    54dc:	00190913          	addi	s2,s2,1
    54e0:	c39ff0ef          	jal	5118 <spawn>
    54e4:	ff2416e3          	bne	s0,s2,54d0 <bullet_reset+0x70>
    54e8:	00000793          	li	a5,0
    54ec:	00c12083          	lw	ra,12(sp)
    54f0:	00812403          	lw	s0,8(sp)
    54f4:	00412483          	lw	s1,4(sp)
    54f8:	00012903          	lw	s2,0(sp)
    54fc:	00078513          	mv	a0,a5
    5500:	01010113          	addi	sp,sp,16
    5504:	00008067          	ret
    5508:	ff800793          	li	a5,-8
    550c:	00078513          	mv	a0,a5
    5510:	00008067          	ret

00005514 <bullet_reset_player>:
    5514:	0a050863          	beqz	a0,55c4 <bullet_reset_player+0xb0>
    5518:	ff010113          	addi	sp,sp,-16
    551c:	00812423          	sw	s0,8(sp)
    5520:	00112623          	sw	ra,12(sp)
    5524:	00912223          	sw	s1,4(sp)
    5528:	01212023          	sw	s2,0(sp)
    552c:	fff58713          	addi	a4,a1,-1
    5530:	3ff00693          	li	a3,1023
    5534:	00058413          	mv	s0,a1
    5538:	ff800793          	li	a5,-8
    553c:	06e6e663          	bltu	a3,a4,55a8 <bullet_reset_player+0x94>
    5540:	00060913          	mv	s2,a2
    5544:	00005637          	lui	a2,0x5
    5548:	02c60613          	addi	a2,a2,44 # 502c <bullet_enemy_position+0x74>
    554c:	00000593          	li	a1,0
    5550:	00050493          	mv	s1,a0
    5554:	cd5fb0ef          	jal	1228 <memset>
    5558:	000057b7          	lui	a5,0x5
    555c:	00f487b3          	add	a5,s1,a5
    5560:	1e000713          	li	a4,480
    5564:	00e7a623          	sw	a4,12(a5) # 500c <bullet_enemy_position+0x54>
    5568:	00e7a823          	sw	a4,16(a5)
    556c:	06060737          	lui	a4,0x6060
    5570:	60370713          	addi	a4,a4,1539 # 6060603 <__gpu_framebuffer_a+0x4060603>
    5574:	02e7a223          	sw	a4,36(a5)
    5578:	00100713          	li	a4,1
    557c:	0127a023          	sw	s2,0(a5)
    5580:	0087a423          	sw	s0,8(a5)
    5584:	02e78423          	sb	a4,40(a5)
    5588:	00000913          	li	s2,0
    558c:	00090593          	mv	a1,s2
    5590:	00100613          	li	a2,1
    5594:	00048513          	mv	a0,s1
    5598:	00190913          	addi	s2,s2,1
    559c:	b7dff0ef          	jal	5118 <spawn>
    55a0:	ff2416e3          	bne	s0,s2,558c <bullet_reset_player+0x78>
    55a4:	00000793          	li	a5,0
    55a8:	00c12083          	lw	ra,12(sp)
    55ac:	00812403          	lw	s0,8(sp)
    55b0:	00412483          	lw	s1,4(sp)
    55b4:	00012903          	lw	s2,0(sp)
    55b8:	00078513          	mv	a0,a5
    55bc:	01010113          	addi	sp,sp,16
    55c0:	00008067          	ret
    55c4:	ff800793          	li	a5,-8
    55c8:	00078513          	mv	a0,a5
    55cc:	00008067          	ret

000055d0 <step>:
    55d0:	f9010113          	addi	sp,sp,-112
    55d4:	05512a23          	sw	s5,84(sp)
    55d8:	06112623          	sw	ra,108(sp)
    55dc:	06812423          	sw	s0,104(sp)
    55e0:	06912223          	sw	s1,100(sp)
    55e4:	07212023          	sw	s2,96(sp)
    55e8:	05312e23          	sw	s3,92(sp)
    55ec:	05412c23          	sw	s4,88(sp)
    55f0:	05612823          	sw	s6,80(sp)
    55f4:	05712623          	sw	s7,76(sp)
    55f8:	05812423          	sw	s8,72(sp)
    55fc:	05912223          	sw	s9,68(sp)
    5600:	05a12023          	sw	s10,64(sp)
    5604:	03b12e23          	sw	s11,60(sp)
    5608:	00e12423          	sw	a4,8(sp)
    560c:	00058a93          	mv	s5,a1
    5610:	74050263          	beqz	a0,5d54 <step+0x784>
    5614:	00005437          	lui	s0,0x5
    5618:	00850433          	add	s0,a0,s0
    561c:	00842a03          	lw	s4,8(s0) # 5008 <bullet_enemy_position+0x50>
    5620:	00068993          	mv	s3,a3
    5624:	3ff00713          	li	a4,1023
    5628:	fffa0693          	addi	a3,s4,-1
    562c:	00050493          	mv	s1,a0
    5630:	ff800793          	li	a5,-8
    5634:	18d76e63          	bltu	a4,a3,57d0 <step+0x200>
    5638:	02444b83          	lbu	s7,36(s0)
    563c:	00300713          	li	a4,3
    5640:	19776863          	bltu	a4,s7,57d0 <step+0x200>
    5644:	00060913          	mv	s2,a2
    5648:	8f5ff0ef          	jal	4f3c <bullet_campaign_valid>
    564c:	ff800793          	li	a5,-8
    5650:	18050063          	beqz	a0,57d0 <step+0x200>
    5654:	02045703          	lhu	a4,32(s0)
    5658:	03c00693          	li	a3,60
    565c:	16e6ea63          	bltu	a3,a4,57d0 <step+0x200>
    5660:	00812583          	lw	a1,8(sp)
    5664:	000b9e63          	bnez	s7,5680 <step+0xb0>
    5668:	02245683          	lhu	a3,34(s0)
    566c:	07700613          	li	a2,119
    5670:	fff68693          	addi	a3,a3,-1
    5674:	01069693          	slli	a3,a3,0x10
    5678:	0106d693          	srli	a3,a3,0x10
    567c:	14d66a63          	bltu	a2,a3,57d0 <step+0x200>
    5680:	020a8063          	beqz	s5,56a0 <step+0xd0>
    5684:	ff890693          	addi	a3,s2,-8
    5688:	3b000613          	li	a2,944
    568c:	ff800793          	li	a5,-8
    5690:	14d66063          	bltu	a2,a3,57d0 <step+0x200>
    5694:	fb098693          	addi	a3,s3,-80
    5698:	1c400613          	li	a2,452
    569c:	12d66a63          	bltu	a2,a3,57d0 <step+0x200>
    56a0:	01400693          	li	a3,20
    56a4:	02da06b3          	mul	a3,s4,a3
    56a8:	00005637          	lui	a2,0x5
    56ac:	00048413          	mv	s0,s1
    56b0:	00048793          	mv	a5,s1
    56b4:	001ab893          	seqz	a7,s5
    56b8:	00500813          	li	a6,5
    56bc:	00c48633          	add	a2,s1,a2
    56c0:	009686b3          	add	a3,a3,s1
    56c4:	00e7c303          	lbu	t1,14(a5)
    56c8:	0018b513          	seqz	a0,a7
    56cc:	00250513          	addi	a0,a0,2
    56d0:	68654263          	blt	a0,t1,5d54 <step+0x784>
    56d4:	00f7c503          	lbu	a0,15(a5)
    56d8:	66a86e63          	bltu	a6,a0,5d54 <step+0x784>
    56dc:	02864503          	lbu	a0,40(a2) # 5028 <bullet_enemy_position+0x70>
    56e0:	00050663          	beqz	a0,56ec <step+0x11c>
    56e4:	0117c303          	lbu	t1,17(a5)
    56e8:	66686663          	bltu	a6,t1,5d54 <step+0x784>
    56ec:	01478793          	addi	a5,a5,20
    56f0:	fcd79ae3          	bne	a5,a3,56c4 <step+0xf4>
    56f4:	000057b7          	lui	a5,0x5
    56f8:	00f487b3          	add	a5,s1,a5
    56fc:	0047ab03          	lw	s6,4(a5) # 5004 <bullet_enemy_position+0x4c>
    5700:	001b0b13          	addi	s6,s6,1
    5704:	0167a223          	sw	s6,4(a5)
    5708:	000a8663          	beqz	s5,5714 <step+0x144>
    570c:	0297c783          	lbu	a5,41(a5)
    5710:	08079e63          	bnez	a5,57ac <step+0x1dc>
    5714:	100b9663          	bnez	s7,5820 <step+0x250>
    5718:	000057b7          	lui	a5,0x5
    571c:	00f48733          	add	a4,s1,a5
    5720:	02275683          	lhu	a3,34(a4)
    5724:	fff68693          	addi	a3,a3,-1
    5728:	01069693          	slli	a3,a3,0x10
    572c:	0106d693          	srli	a3,a3,0x10
    5730:	02d71123          	sh	a3,34(a4)
    5734:	06069c63          	bnez	a3,57ac <step+0x1dc>
    5738:	00072603          	lw	a2,0(a4)
    573c:	0c0a8a63          	beqz	s5,5810 <step+0x240>
    5740:	0c050863          	beqz	a0,5810 <step+0x240>
    5744:	06058863          	beqz	a1,57b4 <step+0x1e4>
    5748:	06b48663          	beq	s1,a1,57b4 <step+0x1e4>
    574c:	00f587b3          	add	a5,a1,a5
    5750:	0287c703          	lbu	a4,40(a5) # 5028 <bullet_enemy_position+0x70>
    5754:	06070063          	beqz	a4,57b4 <step+0x1e4>
    5758:	0087a703          	lw	a4,8(a5)
    575c:	04ea1c63          	bne	s4,a4,57b4 <step+0x1e4>
    5760:	0007a703          	lw	a4,0(a5)
    5764:	04c71863          	bne	a4,a2,57b4 <step+0x1e4>
    5768:	0047a783          	lw	a5,4(a5)
    576c:	04079463          	bnez	a5,57b4 <step+0x1e4>
    5770:	00005437          	lui	s0,0x5
    5774:	008587b3          	add	a5,a1,s0
    5778:	0147a703          	lw	a4,20(a5)
    577c:	02071c63          	bnez	a4,57b4 <step+0x1e4>
    5780:	0247c683          	lbu	a3,36(a5)
    5784:	00300713          	li	a4,3
    5788:	02e69663          	bne	a3,a4,57b4 <step+0x1e4>
    578c:	0297c783          	lbu	a5,41(a5)
    5790:	02079263          	bnez	a5,57b4 <step+0x1e4>
    5794:	00005637          	lui	a2,0x5
    5798:	02c60613          	addi	a2,a2,44 # 502c <bullet_enemy_position+0x74>
    579c:	00048513          	mv	a0,s1
    57a0:	00848433          	add	s0,s1,s0
    57a4:	b61fb0ef          	jal	1304 <memcpy>
    57a8:	01642223          	sw	s6,4(s0) # 5004 <bullet_enemy_position+0x4c>
    57ac:	00000793          	li	a5,0
    57b0:	0200006f          	j	57d0 <step+0x200>
    57b4:	000a0593          	mv	a1,s4
    57b8:	00048513          	mv	a0,s1
    57bc:	d59ff0ef          	jal	5514 <bullet_reset_player>
    57c0:	00005737          	lui	a4,0x5
    57c4:	00e48733          	add	a4,s1,a4
    57c8:	00050793          	mv	a5,a0
    57cc:	01672223          	sw	s6,4(a4) # 5004 <bullet_enemy_position+0x4c>
    57d0:	06c12083          	lw	ra,108(sp)
    57d4:	06812403          	lw	s0,104(sp)
    57d8:	06412483          	lw	s1,100(sp)
    57dc:	06012903          	lw	s2,96(sp)
    57e0:	05c12983          	lw	s3,92(sp)
    57e4:	05812a03          	lw	s4,88(sp)
    57e8:	05412a83          	lw	s5,84(sp)
    57ec:	05012b03          	lw	s6,80(sp)
    57f0:	04c12b83          	lw	s7,76(sp)
    57f4:	04812c03          	lw	s8,72(sp)
    57f8:	04412c83          	lw	s9,68(sp)
    57fc:	04012d03          	lw	s10,64(sp)
    5800:	03c12d83          	lw	s11,60(sp)
    5804:	00078513          	mv	a0,a5
    5808:	07010113          	addi	sp,sp,112
    580c:	00008067          	ret
    5810:	000a0593          	mv	a1,s4
    5814:	00048513          	mv	a0,s1
    5818:	c49ff0ef          	jal	5460 <bullet_reset>
    581c:	fa5ff06f          	j	57c0 <step+0x1f0>
    5820:	000056b7          	lui	a3,0x5
    5824:	00d486b3          	add	a3,s1,a3
    5828:	0146a783          	lw	a5,20(a3) # 5014 <bullet_enemy_position+0x5c>
    582c:	00178793          	addi	a5,a5,1
    5830:	00f6aa23          	sw	a5,20(a3)
    5834:	020a9863          	bnez	s5,5864 <step+0x294>
    5838:	0f000913          	li	s2,240
    583c:	0327f933          	remu	s2,a5,s2
    5840:	03b00693          	li	a3,59
    5844:	1526f063          	bgeu	a3,s2,5984 <step+0x3b4>
    5848:	0b300693          	li	a3,179
    584c:	1326e463          	bltu	a3,s2,5974 <step+0x3a4>
    5850:	07800693          	li	a3,120
    5854:	412686b3          	sub	a3,a3,s2
    5858:	00300613          	li	a2,3
    585c:	02c686b3          	mul	a3,a3,a2
    5860:	1e068913          	addi	s2,a3,480
    5864:	000056b7          	lui	a3,0x5
    5868:	00d486b3          	add	a3,s1,a3
    586c:	0126a623          	sw	s2,12(a3) # 500c <bullet_enemy_position+0x54>
    5870:	000a9463          	bnez	s5,5878 <step+0x2a8>
    5874:	1e000993          	li	s3,480
    5878:	000056b7          	lui	a3,0x5
    587c:	00d486b3          	add	a3,s1,a3
    5880:	0136a823          	sw	s3,16(a3) # 5010 <bullet_enemy_position+0x58>
    5884:	00e03cb3          	snez	s9,a4
    5888:	00070663          	beqz	a4,5894 <step+0x2c4>
    588c:	fff70713          	addi	a4,a4,-1
    5890:	02e69023          	sh	a4,32(a3)
    5894:	01e00713          	li	a4,30
    5898:	02e7f7b3          	remu	a5,a5,a4
    589c:	02079463          	bnez	a5,58c4 <step+0x2f4>
    58a0:	000057b7          	lui	a5,0x5
    58a4:	00f487b3          	add	a5,s1,a5
    58a8:	0187a783          	lw	a5,24(a5) # 5018 <bullet_enemy_position+0x60>
    58ac:	fff00713          	li	a4,-1
    58b0:	00e78463          	beq	a5,a4,58b8 <step+0x2e8>
    58b4:	00178793          	addi	a5,a5,1
    58b8:	00005737          	lui	a4,0x5
    58bc:	00e48733          	add	a4,s1,a4
    58c0:	00f72c23          	sw	a5,24(a4) # 5018 <bullet_enemy_position+0x60>
    58c4:	fed90793          	addi	a5,s2,-19
    58c8:	00005ab7          	lui	s5,0x5
    58cc:	0003cbb7          	lui	s7,0x3c
    58d0:	0001ec37          	lui	s8,0x1e
    58d4:	00f12423          	sw	a5,8(sp)
    58d8:	00010b37          	lui	s6,0x10
    58dc:	00c90793          	addi	a5,s2,12
    58e0:	0f000d93          	li	s11,240
    58e4:	00000d13          	li	s10,0
    58e8:	01548ab3          	add	s5,s1,s5
    58ec:	7feb8b93          	addi	s7,s7,2046 # 3c7fe <__freertos_irq_stack_top+0x1ed7e>
    58f0:	bffc0c13          	addi	s8,s8,-1025 # 1dbff <__freertos_irq_stack_top+0x17f>
    58f4:	00f12623          	sw	a5,12(sp)
    58f8:	fffb0b13          	addi	s6,s6,-1 # ffff <__global_pointer$+0x1297>
    58fc:	00e44683          	lbu	a3,14(s0)
    5900:	00300793          	li	a5,3
    5904:	1cf69863          	bne	a3,a5,5ad4 <step+0x504>
    5908:	00c45683          	lhu	a3,12(s0)
    590c:	05668663          	beq	a3,s6,5958 <step+0x388>
    5910:	00042783          	lw	a5,0(s0)
    5914:	00841303          	lh	t1,8(s0)
    5918:	00442603          	lw	a2,4(s0)
    591c:	00f30333          	add	t1,t1,a5
    5920:	00a41783          	lh	a5,10(s0)
    5924:	00642023          	sw	t1,0(s0)
    5928:	40835313          	srai	t1,t1,0x8
    592c:	00c787b3          	add	a5,a5,a2
    5930:	00f42223          	sw	a5,4(s0)
    5934:	00430313          	addi	t1,t1,4 # 2400004 <__gpu_framebuffer_a+0x400004>
    5938:	3bf00613          	li	a2,959
    593c:	00666a63          	bltu	a2,t1,5950 <step+0x380>
    5940:	4087d793          	srai	a5,a5,0x8
    5944:	fbc78593          	addi	a1,a5,-68
    5948:	1d300613          	li	a2,467
    594c:	04b67463          	bgeu	a2,a1,5994 <step+0x3c4>
    5950:	fff00793          	li	a5,-1
    5954:	00f41623          	sh	a5,12(s0)
    5958:	16700793          	li	a5,359
    595c:	001d0d13          	addi	s10,s10,1
    5960:	3efd8663          	beq	s11,a5,5d4c <step+0x77c>
    5964:	001d8d93          	addi	s11,s11,1
    5968:	01440413          	addi	s0,s0,20
    596c:	f9aa18e3          	bne	s4,s10,58fc <step+0x32c>
    5970:	e3dff06f          	j	57ac <step+0x1dc>
    5974:	00300693          	li	a3,3
    5978:	02d90933          	mul	s2,s2,a3
    597c:	f1090913          	addi	s2,s2,-240
    5980:	ee5ff06f          	j	5864 <step+0x294>
    5984:	00300693          	li	a3,3
    5988:	02d90933          	mul	s2,s2,a3
    598c:	1e090913          	addi	s2,s2,480
    5990:	ed5ff06f          	j	5864 <step+0x294>
    5994:	00168693          	addi	a3,a3,1
    5998:	00d41623          	sh	a3,12(s0)
    599c:	00478893          	addi	a7,a5,4
    59a0:	00000593          	li	a1,0
    59a4:	00300e93          	li	t4,3
    59a8:	028ace03          	lbu	t3,40(s5) # 5028 <bullet_enemy_position+0x70>
    59ac:	020e0c63          	beqz	t3,59e4 <step+0x414>
    59b0:	000057b7          	lui	a5,0x5
    59b4:	02578793          	addi	a5,a5,37 # 5025 <bullet_enemy_position+0x6d>
    59b8:	00f587b3          	add	a5,a1,a5
    59bc:	00f487b3          	add	a5,s1,a5
    59c0:	0007c783          	lbu	a5,0(a5)
    59c4:	02079063          	bnez	a5,59e4 <step+0x414>
    59c8:	00158593          	addi	a1,a1,1
    59cc:	fdd59ee3          	bne	a1,t4,59a8 <step+0x3d8>
    59d0:	000057b7          	lui	a5,0x5
    59d4:	00f487b3          	add	a5,s1,a5
    59d8:	0297c783          	lbu	a5,41(a5) # 5029 <bullet_enemy_position+0x71>
    59dc:	dc0798e3          	bnez	a5,57ac <step+0x1dc>
    59e0:	f79ff06f          	j	5958 <step+0x388>
    59e4:	02c10693          	addi	a3,sp,44
    59e8:	02810613          	addi	a2,sp,40
    59ec:	00048513          	mv	a0,s1
    59f0:	01112e23          	sw	a7,28(sp)
    59f4:	00612c23          	sw	t1,24(sp)
    59f8:	00b12823          	sw	a1,16(sp)
    59fc:	01c12a23          	sw	t3,20(sp)
    5a00:	db8ff0ef          	jal	4fb8 <bullet_enemy_position>
    5a04:	02812683          	lw	a3,40(sp)
    5a08:	01812303          	lw	t1,24(sp)
    5a0c:	01400613          	li	a2,20
    5a10:	02c12783          	lw	a5,44(sp)
    5a14:	40d306b3          	sub	a3,t1,a3
    5a18:	00a68693          	addi	a3,a3,10
    5a1c:	01012583          	lw	a1,16(sp)
    5a20:	01c12883          	lw	a7,28(sp)
    5a24:	00300e93          	li	t4,3
    5a28:	fad660e3          	bltu	a2,a3,59c8 <step+0x3f8>
    5a2c:	40f887b3          	sub	a5,a7,a5
    5a30:	00a78793          	addi	a5,a5,10
    5a34:	f8f66ae3          	bltu	a2,a5,59c8 <step+0x3f8>
    5a38:	fff00793          	li	a5,-1
    5a3c:	00f41623          	sh	a5,12(s0)
    5a40:	000057b7          	lui	a5,0x5
    5a44:	00f487b3          	add	a5,s1,a5
    5a48:	0187a783          	lw	a5,24(a5) # 5018 <bullet_enemy_position+0x60>
    5a4c:	fe600693          	li	a3,-26
    5a50:	01412e03          	lw	t3,20(sp)
    5a54:	00f6f463          	bgeu	a3,a5,5a5c <step+0x48c>
    5a58:	fe600793          	li	a5,-26
    5a5c:	000056b7          	lui	a3,0x5
    5a60:	01978793          	addi	a5,a5,25
    5a64:	00d48533          	add	a0,s1,a3
    5a68:	00f52c23          	sw	a5,24(a0)
    5a6c:	f60e02e3          	beqz	t3,59d0 <step+0x400>
    5a70:	00b485b3          	add	a1,s1,a1
    5a74:	00b68633          	add	a2,a3,a1
    5a78:	02564683          	lbu	a3,37(a2)
    5a7c:	fff68693          	addi	a3,a3,-1 # 4fff <bullet_enemy_position+0x47>
    5a80:	0ff6f693          	zext.b	a3,a3
    5a84:	02d602a3          	sb	a3,37(a2)
    5a88:	f40694e3          	bnez	a3,59d0 <step+0x400>
    5a8c:	f3700693          	li	a3,-201
    5a90:	00f6f463          	bgeu	a3,a5,5a98 <step+0x4c8>
    5a94:	f3700793          	li	a5,-201
    5a98:	0c878793          	addi	a5,a5,200
    5a9c:	000056b7          	lui	a3,0x5
    5aa0:	00f52c23          	sw	a5,24(a0)
    5aa4:	00d486b3          	add	a3,s1,a3
    5aa8:	0246a603          	lw	a2,36(a3) # 5024 <bullet_enemy_position+0x6c>
    5aac:	00000793          	li	a5,0
    5ab0:	00861593          	slli	a1,a2,0x8
    5ab4:	0105d593          	srli	a1,a1,0x10
    5ab8:	00059663          	bnez	a1,5ac4 <step+0x4f4>
    5abc:	0276c783          	lbu	a5,39(a3)
    5ac0:	0017b793          	seqz	a5,a5
    5ac4:	000056b7          	lui	a3,0x5
    5ac8:	00d486b3          	add	a3,s1,a3
    5acc:	02f684a3          	sb	a5,41(a3) # 5029 <bullet_enemy_position+0x71>
    5ad0:	f01ff06f          	j	59d0 <step+0x400>
    5ad4:	028ac583          	lbu	a1,40(s5)
    5ad8:	00058663          	beqz	a1,5ae4 <step+0x514>
    5adc:	00c45783          	lhu	a5,12(s0)
    5ae0:	e7678ce3          	beq	a5,s6,5958 <step+0x388>
    5ae4:	00042883          	lw	a7,0(s0)
    5ae8:	7ff88793          	addi	a5,a7,2047
    5aec:	00fbee63          	bltu	s7,a5,5b08 <step+0x538>
    5af0:	00442503          	lw	a0,4(s0)
    5af4:	ffffc7b7          	lui	a5,0xffffc
    5af8:	00f507b3          	add	a5,a0,a5
    5afc:	00fc6663          	bltu	s8,a5,5b08 <step+0x538>
    5b00:	00c45603          	lhu	a2,12(s0)
    5b04:	01b66c63          	bltu	a2,s11,5b1c <step+0x54c>
    5b08:	00000613          	li	a2,0
    5b0c:	000d0593          	mv	a1,s10
    5b10:	00048513          	mv	a0,s1
    5b14:	e04ff0ef          	jal	5118 <spawn>
    5b18:	e41ff06f          	j	5958 <step+0x388>
    5b1c:	04058a63          	beqz	a1,5b70 <step+0x5a0>
    5b20:	01144783          	lbu	a5,17(s0)
    5b24:	00300693          	li	a3,3
    5b28:	10d78663          	beq	a5,a3,5c34 <step+0x664>
    5b2c:	00400693          	li	a3,4
    5b30:	14d78263          	beq	a5,a3,5c74 <step+0x6a4>
    5b34:	00200693          	li	a3,2
    5b38:	02d79c63          	bne	a5,a3,5b70 <step+0x5a0>
    5b3c:	0000e6b7          	lui	a3,0xe
    5b40:	03c67313          	andi	t1,a2,60
    5b44:	cf068693          	addi	a3,a3,-784 # dcf0 <directions>
    5b48:	006686b3          	add	a3,a3,t1
    5b4c:	00069683          	lh	a3,0(a3)
    5b50:	06000313          	li	t1,96
    5b54:	02f6c6b3          	div	a3,a3,a5
    5b58:	00500793          	li	a5,5
    5b5c:	02fd77b3          	remu	a5,s10,a5
    5b60:	ffe78793          	addi	a5,a5,-2 # ffffbffe <__gpu_framebuffer_a+0xfdffbffe>
    5b64:	026787b3          	mul	a5,a5,t1
    5b68:	00f687b3          	add	a5,a3,a5
    5b6c:	00f41423          	sh	a5,8(s0)
    5b70:	00841683          	lh	a3,8(s0)
    5b74:	00a41783          	lh	a5,10(s0)
    5b78:	00160613          	addi	a2,a2,1
    5b7c:	011688b3          	add	a7,a3,a7
    5b80:	00a787b3          	add	a5,a5,a0
    5b84:	01142023          	sw	a7,0(s0)
    5b88:	00f42223          	sw	a5,4(s0)
    5b8c:	00c41623          	sh	a2,12(s0)
    5b90:	02058063          	beqz	a1,5bb0 <step+0x5e0>
    5b94:	01144583          	lbu	a1,17(s0)
    5b98:	00500613          	li	a2,5
    5b9c:	00c59a63          	bne	a1,a2,5bb0 <step+0x5e0>
    5ba0:	0e08d863          	bgez	a7,5c90 <step+0x6c0>
    5ba4:	00042023          	sw	zero,0(s0)
    5ba8:	40d006b3          	neg	a3,a3
    5bac:	00d41423          	sh	a3,8(s0)
    5bb0:	00042683          	lw	a3,0(s0)
    5bb4:	00812703          	lw	a4,8(sp)
    5bb8:	4086d693          	srai	a3,a3,0x8
    5bbc:	d8e6cee3          	blt	a3,a4,5958 <step+0x388>
    5bc0:	00c12703          	lw	a4,12(sp)
    5bc4:	d8d74ae3          	blt	a4,a3,5958 <step+0x388>
    5bc8:	4087d793          	srai	a5,a5,0x8
    5bcc:	fed98613          	addi	a2,s3,-19
    5bd0:	d8c7c4e3          	blt	a5,a2,5958 <step+0x388>
    5bd4:	00c98613          	addi	a2,s3,12
    5bd8:	d8f640e3          	blt	a2,a5,5958 <step+0x388>
    5bdc:	412686b3          	sub	a3,a3,s2
    5be0:	01368613          	addi	a2,a3,19
    5be4:	00f44683          	lbu	a3,15(s0)
    5be8:	413787b3          	sub	a5,a5,s3
    5bec:	01378793          	addi	a5,a5,19
    5bf0:	00669693          	slli	a3,a3,0x6
    5bf4:	00f687b3          	add	a5,a3,a5
    5bf8:	02078693          	addi	a3,a5,32
    5bfc:	0000e5b7          	lui	a1,0xe
    5c00:	d3058593          	addi	a1,a1,-720 # dd30 <bullet_contact_masks>
    5c04:	00279793          	slli	a5,a5,0x2
    5c08:	00269693          	slli	a3,a3,0x2
    5c0c:	00d586b3          	add	a3,a1,a3
    5c10:	00f585b3          	add	a1,a1,a5
    5c14:	0005a783          	lw	a5,0(a1)
    5c18:	0006a683          	lw	a3,0(a3)
    5c1c:	00c7d7b3          	srl	a5,a5,a2
    5c20:	0017f793          	andi	a5,a5,1
    5c24:	0c078663          	beqz	a5,5cf0 <step+0x720>
    5c28:	060c8e63          	beqz	s9,5ca4 <step+0x6d4>
    5c2c:	00100c93          	li	s9,1
    5c30:	d29ff06f          	j	5958 <step+0x388>
    5c34:	00c00693          	li	a3,12
    5c38:	02d656b3          	divu	a3,a2,a3
    5c3c:	02fd57b3          	divu	a5,s10,a5
    5c40:	00d787b3          	add	a5,a5,a3
    5c44:	00f7f793          	andi	a5,a5,15
    5c48:	0000e6b7          	lui	a3,0xe
    5c4c:	cf068693          	addi	a3,a3,-784 # dcf0 <directions>
    5c50:	00279793          	slli	a5,a5,0x2
    5c54:	00f687b3          	add	a5,a3,a5
    5c58:	0007d683          	lhu	a3,0(a5)
    5c5c:	0027d783          	lhu	a5,2(a5)
    5c60:	00169693          	slli	a3,a3,0x1
    5c64:	00d41423          	sh	a3,8(s0)
    5c68:	00179793          	slli	a5,a5,0x1
    5c6c:	00f41523          	sh	a5,10(s0)
    5c70:	f01ff06f          	j	5b70 <step+0x5a0>
    5c74:	00767793          	andi	a5,a2,7
    5c78:	ee079ce3          	bnez	a5,5b70 <step+0x5a0>
    5c7c:	00a41783          	lh	a5,10(s0)
    5c80:	37f00693          	li	a3,895
    5c84:	eef6c6e3          	blt	a3,a5,5b70 <step+0x5a0>
    5c88:	02078793          	addi	a5,a5,32
    5c8c:	fe1ff06f          	j	5c6c <step+0x69c>
    5c90:	0003c637          	lui	a2,0x3c
    5c94:	80060613          	addi	a2,a2,-2048 # 3b800 <__freertos_irq_stack_top+0x1dd80>
    5c98:	f1165ce3          	bge	a2,a7,5bb0 <step+0x5e0>
    5c9c:	00c42023          	sw	a2,0(s0)
    5ca0:	f09ff06f          	j	5ba8 <step+0x5d8>
    5ca4:	00005cb7          	lui	s9,0x5
    5ca8:	01948cb3          	add	s9,s1,s9
    5cac:	024cc783          	lbu	a5,36(s9) # 5024 <bullet_enemy_position+0x6c>
    5cb0:	00000613          	li	a2,0
    5cb4:	000d0593          	mv	a1,s10
    5cb8:	fff78793          	addi	a5,a5,-1
    5cbc:	0ff7f793          	zext.b	a5,a5
    5cc0:	02fc8223          	sb	a5,36(s9)
    5cc4:	00048513          	mv	a0,s1
    5cc8:	00f12823          	sw	a5,16(sp)
    5ccc:	c4cff0ef          	jal	5118 <spawn>
    5cd0:	01012783          	lw	a5,16(sp)
    5cd4:	00079863          	bnez	a5,5ce4 <step+0x714>
    5cd8:	007807b7          	lui	a5,0x780
    5cdc:	02fca023          	sw	a5,32(s9)
    5ce0:	acdff06f          	j	57ac <step+0x1dc>
    5ce4:	03c00793          	li	a5,60
    5ce8:	02fc9023          	sh	a5,32(s9)
    5cec:	f41ff06f          	j	5c2c <step+0x65c>
    5cf0:	00c6d7b3          	srl	a5,a3,a2
    5cf4:	0017f793          	andi	a5,a5,1
    5cf8:	c60780e3          	beqz	a5,5958 <step+0x388>
    5cfc:	01044783          	lbu	a5,16(s0)
    5d00:	c4079ce3          	bnez	a5,5958 <step+0x388>
    5d04:	00100793          	li	a5,1
    5d08:	00f40823          	sb	a5,16(s0)
    5d0c:	000057b7          	lui	a5,0x5
    5d10:	00f487b3          	add	a5,s1,a5
    5d14:	01c7a683          	lw	a3,28(a5) # 501c <bullet_enemy_position+0x64>
    5d18:	fff00613          	li	a2,-1
    5d1c:	00c68663          	beq	a3,a2,5d28 <step+0x758>
    5d20:	00168693          	addi	a3,a3,1
    5d24:	00d7ae23          	sw	a3,28(a5)
    5d28:	000056b7          	lui	a3,0x5
    5d2c:	00d486b3          	add	a3,s1,a3
    5d30:	0186a783          	lw	a5,24(a3) # 5018 <bullet_enemy_position+0x60>
    5d34:	ff500613          	li	a2,-11
    5d38:	00f67463          	bgeu	a2,a5,5d40 <step+0x770>
    5d3c:	ff500793          	li	a5,-11
    5d40:	00a78793          	addi	a5,a5,10
    5d44:	00f6ac23          	sw	a5,24(a3)
    5d48:	c11ff06f          	j	5958 <step+0x388>
    5d4c:	0f000d93          	li	s11,240
    5d50:	c19ff06f          	j	5968 <step+0x398>
    5d54:	ff800793          	li	a5,-8
    5d58:	a79ff06f          	j	57d0 <step+0x200>

00005d5c <bullet_step_player>:
    5d5c:	00060693          	mv	a3,a2
    5d60:	00000713          	li	a4,0
    5d64:	00058613          	mv	a2,a1
    5d68:	00100593          	li	a1,1
    5d6c:	865ff06f          	j	55d0 <step>

00005d70 <bullet_step_player_cached>:
    5d70:	00068713          	mv	a4,a3
    5d74:	00060693          	mv	a3,a2
    5d78:	00058613          	mv	a2,a1
    5d7c:	00100593          	li	a1,1
    5d80:	851ff06f          	j	55d0 <step>

00005d84 <bullet_shape_opaque>:
    5d84:	00500793          	li	a5,5
    5d88:	00050713          	mv	a4,a0
    5d8c:	02a7ec63          	bltu	a5,a0,5dc4 <bullet_shape_opaque+0x40>
    5d90:	00c5e7b3          	or	a5,a1,a2
    5d94:	00700693          	li	a3,7
    5d98:	00000513          	li	a0,0
    5d9c:	02f6e663          	bltu	a3,a5,5dc8 <bullet_shape_opaque+0x44>
    5da0:	0000e7b7          	lui	a5,0xe
    5da4:	00371713          	slli	a4,a4,0x3
    5da8:	c9c78793          	addi	a5,a5,-868 # dc9c <masks.1>
    5dac:	00e787b3          	add	a5,a5,a4
    5db0:	00c78633          	add	a2,a5,a2
    5db4:	00064503          	lbu	a0,0(a2)
    5db8:	40b55533          	sra	a0,a0,a1
    5dbc:	00157513          	andi	a0,a0,1
    5dc0:	00008067          	ret
    5dc4:	00000513          	li	a0,0
    5dc8:	00008067          	ret

00005dcc <sprite>:
    5dcc:	f8010113          	addi	sp,sp,-128
    5dd0:	05812c23          	sw	s8,88(sp)
    5dd4:	00060c13          	mv	s8,a2
    5dd8:	08412603          	lw	a2,132(sp)
    5ddc:	07412423          	sw	s4,104(sp)
    5de0:	06112e23          	sw	ra,124(sp)
    5de4:	06812c23          	sw	s0,120(sp)
    5de8:	06912a23          	sw	s1,116(sp)
    5dec:	07212823          	sw	s2,112(sp)
    5df0:	07312623          	sw	s3,108(sp)
    5df4:	07512223          	sw	s5,100(sp)
    5df8:	07612023          	sw	s6,96(sp)
    5dfc:	05712e23          	sw	s7,92(sp)
    5e00:	05912a23          	sw	s9,84(sp)
    5e04:	05a12823          	sw	s10,80(sp)
    5e08:	05b12623          	sw	s11,76(sp)
    5e0c:	00062023          	sw	zero,0(a2)
    5e10:	00a12623          	sw	a0,12(sp)
    5e14:	00b12823          	sw	a1,16(sp)
    5e18:	3bf00613          	li	a2,959
    5e1c:	00000a13          	li	s4,0
    5e20:	10e64c63          	blt	a2,a4,5f38 <sprite+0x16c>
    5e24:	41000633          	neg	a2,a6
    5e28:	00080c93          	mv	s9,a6
    5e2c:	00000a13          	li	s4,0
    5e30:	10e65463          	bge	a2,a4,5f38 <sprite+0x16c>
    5e34:	21b00613          	li	a2,539
    5e38:	10f64063          	blt	a2,a5,5f38 <sprite+0x16c>
    5e3c:	04800593          	li	a1,72
    5e40:	41058633          	sub	a2,a1,a6
    5e44:	0ef65a63          	bge	a2,a5,5f38 <sprite+0x16c>
    5e48:	41f75613          	srai	a2,a4,0x1f
    5e4c:	40e00b33          	neg	s6,a4
    5e50:	00cb7b33          	and	s6,s6,a2
    5e54:	04700613          	li	a2,71
    5e58:	00088d93          	mv	s11,a7
    5e5c:	00000413          	li	s0,0
    5e60:	00f64463          	blt	a2,a5,5e68 <sprite+0x9c>
    5e64:	40f58433          	sub	s0,a1,a5
    5e68:	00070b93          	mv	s7,a4
    5e6c:	00075463          	bgez	a4,5e74 <sprite+0xa8>
    5e70:	00000b93          	li	s7,0
    5e74:	3c000d13          	li	s10,960
    5e78:	416c8733          	sub	a4,s9,s6
    5e7c:	417d0d33          	sub	s10,s10,s7
    5e80:	01a77463          	bgeu	a4,s10,5e88 <sprite+0xbc>
    5e84:	00070d13          	mv	s10,a4
    5e88:	00078a93          	mv	s5,a5
    5e8c:	04800793          	li	a5,72
    5e90:	00fad463          	bge	s5,a5,5e98 <sprite+0xcc>
    5e94:	04800a93          	li	s5,72
    5e98:	21c00713          	li	a4,540
    5e9c:	408c87b3          	sub	a5,s9,s0
    5ea0:	415704b3          	sub	s1,a4,s5
    5ea4:	0097f463          	bgeu	a5,s1,5eac <sprite+0xe0>
    5ea8:	00078493          	mv	s1,a5
    5eac:	08012703          	lw	a4,128(sp)
    5eb0:	fff00793          	li	a5,-1
    5eb4:	0cf71263          	bne	a4,a5,5f78 <sprite+0x1ac>
    5eb8:	3c000793          	li	a5,960
    5ebc:	02fa87b3          	mul	a5,s5,a5
    5ec0:	02012a23          	sw	zero,52(sp)
    5ec4:	01012583          	lw	a1,16(sp)
    5ec8:	00c12503          	lw	a0,12(sp)
    5ecc:	02012e23          	sw	zero,60(sp)
    5ed0:	02012c23          	sw	zero,56(sp)
    5ed4:	03a11823          	sh	s10,48(sp)
    5ed8:	02911923          	sh	s1,50(sp)
    5edc:	03b10ea3          	sb	s11,61(sp)
    5ee0:	03940433          	mul	s0,s0,s9
    5ee4:	017787b3          	add	a5,a5,s7
    5ee8:	00179793          	slli	a5,a5,0x1
    5eec:	01878633          	add	a2,a5,s8
    5ef0:	78000793          	li	a5,1920
    5ef4:	02f12623          	sw	a5,44(sp)
    5ef8:	81f00793          	li	a5,-2017
    5efc:	02f11b23          	sh	a5,54(sp)
    5f00:	01b037b3          	snez	a5,s11
    5f04:	02c12223          	sw	a2,36(sp)
    5f08:	01640433          	add	s0,s0,s6
    5f0c:	00141413          	slli	s0,s0,0x1
    5f10:	00d406b3          	add	a3,s0,a3
    5f14:	00378793          	addi	a5,a5,3
    5f18:	001c9c93          	slli	s9,s9,0x1
    5f1c:	02010613          	addi	a2,sp,32
    5f20:	02d12023          	sw	a3,32(sp)
    5f24:	03912423          	sw	s9,40(sp)
    5f28:	02f10e23          	sb	a5,60(sp)
    5f2c:	f51fe0ef          	jal	4e7c <append>
    5f30:	00050a13          	mv	s4,a0
    5f34:	0a050e63          	beqz	a0,5ff0 <sprite+0x224>
    5f38:	07c12083          	lw	ra,124(sp)
    5f3c:	07812403          	lw	s0,120(sp)
    5f40:	07412483          	lw	s1,116(sp)
    5f44:	07012903          	lw	s2,112(sp)
    5f48:	06c12983          	lw	s3,108(sp)
    5f4c:	06412a83          	lw	s5,100(sp)
    5f50:	06012b03          	lw	s6,96(sp)
    5f54:	05c12b83          	lw	s7,92(sp)
    5f58:	05812c03          	lw	s8,88(sp)
    5f5c:	05412c83          	lw	s9,84(sp)
    5f60:	05012d03          	lw	s10,80(sp)
    5f64:	04c12d83          	lw	s11,76(sp)
    5f68:	000a0513          	mv	a0,s4
    5f6c:	06812a03          	lw	s4,104(sp)
    5f70:	08010113          	addi	sp,sp,128
    5f74:	00008067          	ret
    5f78:	008b6633          	or	a2,s6,s0
    5f7c:	02060263          	beqz	a2,5fa0 <sprite+0x1d4>
    5f80:	00040613          	mv	a2,s0
    5f84:	00000a13          	li	s4,0
    5f88:	00940933          	add	s2,s0,s1
    5f8c:	016d09b3          	add	s3,s10,s6
    5f90:	05267c63          	bgeu	a2,s2,5fe8 <sprite+0x21c>
    5f94:	f20a12e3          	bnez	s4,5eb8 <sprite+0xec>
    5f98:	000b0593          	mv	a1,s6
    5f9c:	0380006f          	j	5fd4 <sprite+0x208>
    5fa0:	ff9d62e3          	bltu	s10,s9,5f84 <sprite+0x1b8>
    5fa4:	ff94e0e3          	bltu	s1,s9,5f84 <sprite+0x1b8>
    5fa8:	f11ff06f          	j	5eb8 <sprite+0xec>
    5fac:	08012503          	lw	a0,128(sp)
    5fb0:	00d12e23          	sw	a3,28(sp)
    5fb4:	00c12c23          	sw	a2,24(sp)
    5fb8:	00b12a23          	sw	a1,20(sp)
    5fbc:	dc9ff0ef          	jal	5d84 <bullet_shape_opaque>
    5fc0:	01812603          	lw	a2,24(sp)
    5fc4:	01c12683          	lw	a3,28(sp)
    5fc8:	00051c63          	bnez	a0,5fe0 <sprite+0x214>
    5fcc:	01412583          	lw	a1,20(sp)
    5fd0:	00158593          	addi	a1,a1,1
    5fd4:	fd35ece3          	bltu	a1,s3,5fac <sprite+0x1e0>
    5fd8:	00160613          	addi	a2,a2,1
    5fdc:	fb5ff06f          	j	5f90 <sprite+0x1c4>
    5fe0:	00100a13          	li	s4,1
    5fe4:	ff5ff06f          	j	5fd8 <sprite+0x20c>
    5fe8:	f40a08e3          	beqz	s4,5f38 <sprite+0x16c>
    5fec:	ecdff06f          	j	5eb8 <sprite+0xec>
    5ff0:	08412703          	lw	a4,132(sp)
    5ff4:	00100793          	li	a5,1
    5ff8:	00f72023          	sw	a5,0(a4)
    5ffc:	f3dff06f          	j	5f38 <sprite+0x16c>

00006000 <build_frame>:
    6000:	f4010113          	addi	sp,sp,-192
    6004:	0a112e23          	sw	ra,188(sp)
    6008:	0a812c23          	sw	s0,184(sp)
    600c:	0a912a23          	sw	s1,180(sp)
    6010:	0b212823          	sw	s2,176(sp)
    6014:	0b312623          	sw	s3,172(sp)
    6018:	0b412423          	sw	s4,168(sp)
    601c:	0b512223          	sw	s5,164(sp)
    6020:	0b612023          	sw	s6,160(sp)
    6024:	09712e23          	sw	s7,156(sp)
    6028:	09812c23          	sw	s8,152(sp)
    602c:	09912a23          	sw	s9,148(sp)
    6030:	09a12823          	sw	s10,144(sp)
    6034:	09b12623          	sw	s11,140(sp)
    6038:	00e12e23          	sw	a4,28(sp)
    603c:	04079463          	bnez	a5,6084 <build_frame+0x84>
    6040:	ff800793          	li	a5,-8
    6044:	0bc12083          	lw	ra,188(sp)
    6048:	0b812403          	lw	s0,184(sp)
    604c:	0b412483          	lw	s1,180(sp)
    6050:	0b012903          	lw	s2,176(sp)
    6054:	0ac12983          	lw	s3,172(sp)
    6058:	0a812a03          	lw	s4,168(sp)
    605c:	0a412a83          	lw	s5,164(sp)
    6060:	0a012b03          	lw	s6,160(sp)
    6064:	09c12b83          	lw	s7,156(sp)
    6068:	09812c03          	lw	s8,152(sp)
    606c:	09412c83          	lw	s9,148(sp)
    6070:	09012d03          	lw	s10,144(sp)
    6074:	08c12d83          	lw	s11,140(sp)
    6078:	00078513          	mv	a0,a5
    607c:	0c010113          	addi	sp,sp,192
    6080:	00008067          	ret
    6084:	00078413          	mv	s0,a5
    6088:	000097b7          	lui	a5,0x9
    608c:	00f407b3          	add	a5,s0,a5
    6090:	1207a823          	sw	zero,304(a5) # 9130 <v3_runtime_advance+0xd0>
    6094:	1207a623          	sw	zero,300(a5)
    6098:	1207a423          	sw	zero,296(a5)
    609c:	1207a223          	sw	zero,292(a5)
    60a0:	1207a023          	sw	zero,288(a5)
    60a4:	00050493          	mv	s1,a0
    60a8:	f8050ce3          	beqz	a0,6040 <build_frame+0x40>
    60ac:	000057b7          	lui	a5,0x5
    60b0:	00f507b3          	add	a5,a0,a5
    60b4:	0087ab03          	lw	s6,8(a5) # 5008 <bullet_enemy_position+0x50>
    60b8:	3ff00793          	li	a5,1023
    60bc:	fffb0713          	addi	a4,s6,-1
    60c0:	f8e7e0e3          	bltu	a5,a4,6040 <build_frame+0x40>
    60c4:	01c12783          	lw	a5,28(sp)
    60c8:	48800713          	li	a4,1160
    60cc:	fff78793          	addi	a5,a5,-1
    60d0:	f6f768e3          	bltu	a4,a5,6040 <build_frame+0x40>
    60d4:	00058913          	mv	s2,a1
    60d8:	00060a93          	mv	s5,a2
    60dc:	00068b93          	mv	s7,a3
    60e0:	00080993          	mv	s3,a6
    60e4:	e59fe0ef          	jal	4f3c <bullet_campaign_valid>
    60e8:	f4050ce3          	beqz	a0,6040 <build_frame+0x40>
    60ec:	00100793          	li	a5,1
    60f0:	f557e8e3          	bltu	a5,s5,6040 <build_frame+0x40>
    60f4:	ffe007b7          	lui	a5,0xffe00
    60f8:	fff78793          	addi	a5,a5,-1 # ffdfffff <__gpu_framebuffer_a+0xfddfffff>
    60fc:	00f977b3          	and	a5,s2,a5
    6100:	02000737          	lui	a4,0x2000
    6104:	f2e79ee3          	bne	a5,a4,6040 <build_frame+0x40>
    6108:	02c00a37          	lui	s4,0x2c00
    610c:	000a8463          	beqz	s5,6114 <build_frame+0x114>
    6110:	02a00a37          	lui	s4,0x2a00
    6114:	04012a23          	sw	zero,84(sp)
    6118:	04012c23          	sw	zero,88(sp)
    611c:	04012e23          	sw	zero,92(sp)
    6120:	02b007b7          	lui	a5,0x2b00
    6124:	000a8463          	beqz	s5,612c <build_frame+0x12c>
    6128:	029007b7          	lui	a5,0x2900
    612c:	04f12023          	sw	a5,64(sp)
    6130:	78000793          	li	a5,1920
    6134:	04f12423          	sw	a5,72(sp)
    6138:	04f12623          	sw	a5,76(sp)
    613c:	01c12583          	lw	a1,28(sp)
    6140:	021c07b7          	lui	a5,0x21c0
    6144:	3c078793          	addi	a5,a5,960 # 21c03c0 <__gpu_framebuffer_a+0x1c03c0>
    6148:	04f12823          	sw	a5,80(sp)
    614c:	04010613          	addi	a2,sp,64
    6150:	00200793          	li	a5,2
    6154:	00040513          	mv	a0,s0
    6158:	04f10e23          	sb	a5,92(sp)
    615c:	05212223          	sw	s2,68(sp)
    6160:	d1dfe0ef          	jal	4e7c <append>
    6164:	00050793          	mv	a5,a0
    6168:	00000a93          	li	s5,0
    616c:	00098a63          	beqz	s3,6180 <build_frame+0x180>
    6170:	00005737          	lui	a4,0x5
    6174:	00e48733          	add	a4,s1,a4
    6178:	02974a83          	lbu	s5,41(a4) # 5029 <bullet_enemy_position+0x71>
    617c:	01503ab3          	snez	s5,s5
    6180:	00005337          	lui	t1,0x5
    6184:	500a0713          	addi	a4,s4,1280 # 2a00500 <__gpu_framebuffer_a+0xa00500>
    6188:	00010eb7          	lui	t4,0x10
    618c:	00048d93          	mv	s11,s1
    6190:	00000c13          	li	s8,0
    6194:	00648cb3          	add	s9,s1,t1
    6198:	02e12023          	sw	a4,32(sp)
    619c:	fff00d13          	li	s10,-1
    61a0:	00300f13          	li	t5,3
    61a4:	fffe8e93          	addi	t4,t4,-1 # ffff <__global_pointer$+0x1297>
    61a8:	00079863          	bnez	a5,61b8 <build_frame+0x1b8>
    61ac:	000a9663          	bnez	s5,61b8 <build_frame+0x1b8>
    61b0:	000b8463          	beqz	s7,61b8 <build_frame+0x1b8>
    61b4:	036c6a63          	bltu	s8,s6,61e8 <build_frame+0x1e8>
    61b8:	01400713          	li	a4,20
    61bc:	02eb0b33          	mul	s6,s6,a4
    61c0:	00009cb7          	lui	s9,0x9
    61c4:	00010d37          	lui	s10,0x10
    61c8:	00005db7          	lui	s11,0x5
    61cc:	00048c13          	mv	s8,s1
    61d0:	0019b313          	seqz	t1,s3
    61d4:	01940cb3          	add	s9,s0,s9
    61d8:	fffd0d13          	addi	s10,s10,-1 # ffff <__global_pointer$+0x1297>
    61dc:	01b48db3          	add	s11,s1,s11
    61e0:	01648b33          	add	s6,s1,s6
    61e4:	14c0006f          	j	6330 <build_frame+0x330>
    61e8:	02098063          	beqz	s3,6208 <build_frame+0x208>
    61ec:	00edc783          	lbu	a5,14(s11) # 500e <bullet_enemy_position+0x56>
    61f0:	01e78663          	beq	a5,t5,61fc <build_frame+0x1fc>
    61f4:	028cc783          	lbu	a5,40(s9) # 9028 <v3_runtime_game_command+0x110>
    61f8:	00078863          	beqz	a5,6208 <build_frame+0x208>
    61fc:	00cdd703          	lhu	a4,12(s11)
    6200:	00000793          	li	a5,0
    6204:	07d70463          	beq	a4,t4,626c <build_frame+0x26c>
    6208:	000da503          	lw	a0,0(s11)
    620c:	d11fe0ef          	jal	4f1c <pixel_coordinate>
    6210:	02a12223          	sw	a0,36(sp)
    6214:	004da503          	lw	a0,4(s11)
    6218:	d05fe0ef          	jal	4f1c <pixel_coordinate>
    621c:	004ca883          	lw	a7,4(s9)
    6220:	02412703          	lw	a4,36(sp)
    6224:	02012683          	lw	a3,32(sp)
    6228:	01c12583          	lw	a1,28(sp)
    622c:	00f8f893          	andi	a7,a7,15
    6230:	03810793          	addi	a5,sp,56
    6234:	01088893          	addi	a7,a7,16
    6238:	00f12223          	sw	a5,4(sp)
    623c:	ffe70713          	addi	a4,a4,-2
    6240:	ffe50793          	addi	a5,a0,-2
    6244:	01a12023          	sw	s10,0(sp)
    6248:	00289893          	slli	a7,a7,0x2
    624c:	00c00813          	li	a6,12
    6250:	00090613          	mv	a2,s2
    6254:	00040513          	mv	a0,s0
    6258:	b75ff0ef          	jal	5dcc <sprite>
    625c:	00010737          	lui	a4,0x10
    6260:	00050793          	mv	a5,a0
    6264:	fff70e93          	addi	t4,a4,-1 # ffff <__global_pointer$+0x1297>
    6268:	00300f13          	li	t5,3
    626c:	008c0c13          	addi	s8,s8,8
    6270:	0a0d8d93          	addi	s11,s11,160
    6274:	f35ff06f          	j	61a8 <build_frame+0x1a8>
    6278:	00ec4703          	lbu	a4,14(s8)
    627c:	00133793          	seqz	a5,t1
    6280:	00278793          	addi	a5,a5,2
    6284:	1ae7c063          	blt	a5,a4,6424 <build_frame+0x424>
    6288:	00fc4603          	lbu	a2,15(s8)
    628c:	00500793          	li	a5,5
    6290:	18c7ea63          	bltu	a5,a2,6424 <build_frame+0x424>
    6294:	00300793          	li	a5,3
    6298:	00f70863          	beq	a4,a5,62a8 <build_frame+0x2a8>
    629c:	00098c63          	beqz	s3,62b4 <build_frame+0x2b4>
    62a0:	028dc783          	lbu	a5,40(s11)
    62a4:	00078863          	beqz	a5,62b4 <build_frame+0x2b4>
    62a8:	00cc5703          	lhu	a4,12(s8)
    62ac:	00000793          	li	a5,0
    62b0:	07a70e63          	beq	a4,s10,632c <build_frame+0x32c>
    62b4:	000c2503          	lw	a0,0(s8)
    62b8:	00761693          	slli	a3,a2,0x7
    62bc:	014686b3          	add	a3,a3,s4
    62c0:	02612623          	sw	t1,44(sp)
    62c4:	02c12423          	sw	a2,40(sp)
    62c8:	02d12223          	sw	a3,36(sp)
    62cc:	c51fe0ef          	jal	4f1c <pixel_coordinate>
    62d0:	02a12023          	sw	a0,32(sp)
    62d4:	004c2503          	lw	a0,4(s8)
    62d8:	c45fe0ef          	jal	4f1c <pixel_coordinate>
    62dc:	02812603          	lw	a2,40(sp)
    62e0:	03810593          	addi	a1,sp,56
    62e4:	00b12223          	sw	a1,4(sp)
    62e8:	02012703          	lw	a4,32(sp)
    62ec:	02412683          	lw	a3,36(sp)
    62f0:	01c12583          	lw	a1,28(sp)
    62f4:	00050793          	mv	a5,a0
    62f8:	00c12023          	sw	a2,0(sp)
    62fc:	00000893          	li	a7,0
    6300:	00800813          	li	a6,8
    6304:	00090613          	mv	a2,s2
    6308:	00040513          	mv	a0,s0
    630c:	ac1ff0ef          	jal	5dcc <sprite>
    6310:	02c12303          	lw	t1,44(sp)
    6314:	00050793          	mv	a5,a0
    6318:	00051a63          	bnez	a0,632c <build_frame+0x32c>
    631c:	124ca703          	lw	a4,292(s9)
    6320:	03812683          	lw	a3,56(sp)
    6324:	00d70733          	add	a4,a4,a3
    6328:	12eca223          	sw	a4,292(s9)
    632c:	014c0c13          	addi	s8,s8,20
    6330:	00079663          	bnez	a5,633c <build_frame+0x33c>
    6334:	000a9463          	bnez	s5,633c <build_frame+0x33c>
    6338:	f56c10e3          	bne	s8,s6,6278 <build_frame+0x278>
    633c:	00005637          	lui	a2,0x5
    6340:	00c48633          	add	a2,s1,a2
    6344:	02464c03          	lbu	s8,36(a2) # 5024 <bullet_enemy_position+0x6c>
    6348:	0a079463          	bnez	a5,63f0 <build_frame+0x3f0>
    634c:	0e0b8063          	beqz	s7,642c <build_frame+0x42c>
    6350:	05000b13          	li	s6,80
    6354:	0e0c0063          	beqz	s8,6434 <build_frame+0x434>
    6358:	00c62703          	lw	a4,12(a2)
    635c:	01062783          	lw	a5,16(a2)
    6360:	02065603          	lhu	a2,32(a2)
    6364:	500a0693          	addi	a3,s4,1280
    6368:	ffa70713          	addi	a4,a4,-6
    636c:	ffa78793          	addi	a5,a5,-6
    6370:	04000893          	li	a7,64
    6374:	00060463          	beqz	a2,637c <build_frame+0x37c>
    6378:	0c000893          	li	a7,192
    637c:	03810613          	addi	a2,sp,56
    6380:	01c12583          	lw	a1,28(sp)
    6384:	00c12223          	sw	a2,4(sp)
    6388:	fff00613          	li	a2,-1
    638c:	00c12023          	sw	a2,0(sp)
    6390:	00c00813          	li	a6,12
    6394:	00090613          	mv	a2,s2
    6398:	00040513          	mv	a0,s0
    639c:	a31ff0ef          	jal	5dcc <sprite>
    63a0:	00050793          	mv	a5,a0
    63a4:	04051a63          	bnez	a0,63f8 <build_frame+0x3f8>
    63a8:	00005737          	lui	a4,0x5
    63ac:	00e48733          	add	a4,s1,a4
    63b0:	01072783          	lw	a5,16(a4) # 5010 <bullet_enemy_position+0x58>
    63b4:	00c72703          	lw	a4,12(a4)
    63b8:	03810693          	addi	a3,sp,56
    63bc:	01c12583          	lw	a1,28(sp)
    63c0:	00d12223          	sw	a3,4(sp)
    63c4:	fff00693          	li	a3,-1
    63c8:	00d12023          	sw	a3,0(sp)
    63cc:	ff878793          	addi	a5,a5,-8
    63d0:	00000893          	li	a7,0
    63d4:	01000813          	li	a6,16
    63d8:	ff870713          	addi	a4,a4,-8
    63dc:	300a0693          	addi	a3,s4,768
    63e0:	00090613          	mv	a2,s2
    63e4:	00040513          	mv	a0,s0
    63e8:	9e5ff0ef          	jal	5dcc <sprite>
    63ec:	00050793          	mv	a5,a0
    63f0:	05000b13          	li	s6,80
    63f4:	040c0063          	beqz	s8,6434 <build_frame+0x434>
    63f8:	00005737          	lui	a4,0x5
    63fc:	00e48733          	add	a4,s1,a4
    6400:	01472703          	lw	a4,20(a4) # 5014 <bullet_enemy_position+0x5c>
    6404:	03c00693          	li	a3,60
    6408:	05000b13          	li	s6,80
    640c:	02d77733          	remu	a4,a4,a3
    6410:	02b00693          	li	a3,43
    6414:	02e6f063          	bgeu	a3,a4,6434 <build_frame+0x434>
    6418:	fdf70713          	addi	a4,a4,-33
    641c:	00371b13          	slli	s6,a4,0x3
    6420:	0140006f          	j	6434 <build_frame+0x434>
    6424:	ff800793          	li	a5,-8
    6428:	f15ff06f          	j	633c <build_frame+0x33c>
    642c:	05000b13          	li	s6,80
    6430:	f60c1ce3          	bnez	s8,63a8 <build_frame+0x3a8>
    6434:	0000e337          	lui	t1,0xe
    6438:	00348713          	addi	a4,s1,3
    643c:	00005cb7          	lui	s9,0x5
    6440:	620a0c13          	addi	s8,s4,1568
    6444:	cd830d93          	addi	s11,t1,-808 # dcd8 <centers>
    6448:	02e12023          	sw	a4,32(sp)
    644c:	00048d13          	mv	s10,s1
    6450:	01948cb3          	add	s9,s1,s9
    6454:	08079a63          	bnez	a5,64e8 <build_frame+0x4e8>
    6458:	02012703          	lw	a4,32(sp)
    645c:	0ba71663          	bne	a4,s10,6508 <build_frame+0x508>
    6460:	be0a82e3          	beqz	s5,6044 <build_frame+0x44>
    6464:	02000613          	li	a2,32
    6468:	00000593          	li	a1,0
    646c:	06010513          	addi	a0,sp,96
    6470:	02f12023          	sw	a5,32(sp)
    6474:	db5fa0ef          	jal	1228 <memset>
    6478:	00053737          	lui	a4,0x53
    647c:	ad070713          	addi	a4,a4,-1328 # 52ad0 <__freertos_irq_stack_top+0x35050>
    6480:	00e90733          	add	a4,s2,a4
    6484:	06e12223          	sw	a4,100(sp)
    6488:	78000713          	li	a4,1920
    648c:	06e12623          	sw	a4,108(sp)
    6490:	009c0737          	lui	a4,0x9c0
    6494:	0f070713          	addi	a4,a4,240 # 9c00f0 <__freertos_irq_stack_top+0x9a2670>
    6498:	01c12583          	lw	a1,28(sp)
    649c:	06e12823          	sw	a4,112(sp)
    64a0:	00b00713          	li	a4,11
    64a4:	06e11a23          	sh	a4,116(sp)
    64a8:	06010613          	addi	a2,sp,96
    64ac:	00100713          	li	a4,1
    64b0:	00040513          	mv	a0,s0
    64b4:	06e10e23          	sb	a4,124(sp)
    64b8:	9c5fe0ef          	jal	4e7c <append>
    64bc:	02012783          	lw	a5,32(sp)
    64c0:	0000eab7          	lui	s5,0xe
    64c4:	00010c37          	lui	s8,0x10
    64c8:	c88a8a93          	addi	s5,s5,-888 # dc88 <columns.0>
    64cc:	00000a13          	li	s4,0
    64d0:	00400693          	li	a3,4
    64d4:	fe0c0c13          	addi	s8,s8,-32 # ffe0 <__global_pointer$+0x1278>
    64d8:	00700c93          	li	s9,7
    64dc:	3c000813          	li	a6,960
    64e0:	1c050a63          	beqz	a0,66b4 <build_frame+0x6b4>
    64e4:	00050793          	mv	a5,a0
    64e8:	00009737          	lui	a4,0x9
    64ec:	00e40433          	add	s0,s0,a4
    64f0:	12042823          	sw	zero,304(s0)
    64f4:	12042623          	sw	zero,300(s0)
    64f8:	12042423          	sw	zero,296(s0)
    64fc:	12042223          	sw	zero,292(s0)
    6500:	12042023          	sw	zero,288(s0)
    6504:	b41ff06f          	j	6044 <build_frame+0x44>
    6508:	02098063          	beqz	s3,6528 <build_frame+0x528>
    650c:	028cc703          	lbu	a4,40(s9) # 5028 <bullet_enemy_position+0x70>
    6510:	00070c63          	beqz	a4,6528 <build_frame+0x528>
    6514:	00005737          	lui	a4,0x5
    6518:	02570713          	addi	a4,a4,37 # 5025 <bullet_enemy_position+0x6d>
    651c:	00ed0733          	add	a4,s10,a4
    6520:	00074703          	lbu	a4,0(a4)
    6524:	06070863          	beqz	a4,6594 <build_frame+0x594>
    6528:	000da783          	lw	a5,0(s11)
    652c:	02f12e23          	sw	a5,60(sp)
    6530:	004da783          	lw	a5,4(s11)
    6534:	06f12023          	sw	a5,96(sp)
    6538:	00098c63          	beqz	s3,6550 <build_frame+0x550>
    653c:	06010693          	addi	a3,sp,96
    6540:	03c10613          	addi	a2,sp,60
    6544:	409d05b3          	sub	a1,s10,s1
    6548:	00048513          	mv	a0,s1
    654c:	a6dfe0ef          	jal	4fb8 <bullet_enemy_position>
    6550:	03c12e83          	lw	t4,60(sp)
    6554:	06012f03          	lw	t5,96(sp)
    6558:	040b9663          	bnez	s7,65a4 <build_frame+0x5a4>
    655c:	03810793          	addi	a5,sp,56
    6560:	01c12583          	lw	a1,28(sp)
    6564:	00f12223          	sw	a5,4(sp)
    6568:	fff00793          	li	a5,-1
    656c:	00f12023          	sw	a5,0(sp)
    6570:	00000893          	li	a7,0
    6574:	ff8f0793          	addi	a5,t5,-8
    6578:	01000813          	li	a6,16
    657c:	ff8e8713          	addi	a4,t4,-8
    6580:	000c0693          	mv	a3,s8
    6584:	00090613          	mv	a2,s2
    6588:	00040513          	mv	a0,s0
    658c:	841ff0ef          	jal	5dcc <sprite>
    6590:	00050793          	mv	a5,a0
    6594:	001d0d13          	addi	s10,s10,1
    6598:	200c0c13          	addi	s8,s8,512
    659c:	008d8d93          	addi	s11,s11,8
    65a0:	eb5ff06f          	j	6454 <build_frame+0x454>
    65a4:	03810793          	addi	a5,sp,56
    65a8:	01c12583          	lw	a1,28(sp)
    65ac:	00f12223          	sw	a5,4(sp)
    65b0:	fff00793          	li	a5,-1
    65b4:	00f12023          	sw	a5,0(sp)
    65b8:	ffae8713          	addi	a4,t4,-6
    65bc:	ffaf0793          	addi	a5,t5,-6
    65c0:	000b0893          	mv	a7,s6
    65c4:	00c00813          	li	a6,12
    65c8:	500a0693          	addi	a3,s4,1280
    65cc:	00090613          	mv	a2,s2
    65d0:	00040513          	mv	a0,s0
    65d4:	03e12423          	sw	t5,40(sp)
    65d8:	03d12223          	sw	t4,36(sp)
    65dc:	ff0ff0ef          	jal	5dcc <sprite>
    65e0:	02412e83          	lw	t4,36(sp)
    65e4:	02812f03          	lw	t5,40(sp)
    65e8:	00050793          	mv	a5,a0
    65ec:	fa0514e3          	bnez	a0,6594 <build_frame+0x594>
    65f0:	f6dff06f          	j	655c <build_frame+0x55c>
    65f4:	00300b93          	li	s7,3
    65f8:	1d800493          	li	s1,472
    65fc:	11a00d93          	li	s11,282
    6600:	000c0713          	mv	a4,s8
    6604:	0d40006f          	j	66d8 <build_frame+0x6d8>
    6608:	00098613          	mv	a2,s3
    660c:	0008c583          	lbu	a1,0(a7)
    6610:	00160993          	addi	s3,a2,1
    6614:	00c5d733          	srl	a4,a1,a2
    6618:	00177713          	andi	a4,a4,1
    661c:	06070a63          	beqz	a4,6690 <build_frame+0x690>
    6620:	00060993          	mv	s3,a2
    6624:	00198993          	addi	s3,s3,1
    6628:	01998863          	beq	s3,s9,6638 <build_frame+0x638>
    662c:	0135d733          	srl	a4,a1,s3
    6630:	00177713          	andi	a4,a4,1
    6634:	fe0718e3          	bnez	a4,6624 <build_frame+0x624>
    6638:	03760733          	mul	a4,a2,s7
    663c:	40c98633          	sub	a2,s3,a2
    6640:	01c12583          	lw	a1,28(sp)
    6644:	00040513          	mv	a0,s0
    6648:	03112223          	sw	a7,36(sp)
    664c:	02f12023          	sw	a5,32(sp)
    6650:	01b70733          	add	a4,a4,s11
    6654:	03070733          	mul	a4,a4,a6
    6658:	02cd0633          	mul	a2,s10,a2
    665c:	00970733          	add	a4,a4,s1
    6660:	00171713          	slli	a4,a4,0x1
    6664:	01270733          	add	a4,a4,s2
    6668:	06e12223          	sw	a4,100(sp)
    666c:	06c11923          	sh	a2,114(sp)
    6670:	06010613          	addi	a2,sp,96
    6674:	809fe0ef          	jal	4e7c <append>
    6678:	02012783          	lw	a5,32(sp)
    667c:	02412883          	lw	a7,36(sp)
    6680:	3c000813          	li	a6,960
    6684:	00500313          	li	t1,5
    6688:	00400693          	li	a3,4
    668c:	00051663          	bnez	a0,6698 <build_frame+0x698>
    6690:	f7999ce3          	bne	s3,s9,6608 <build_frame+0x608>
    6694:	00000513          	li	a0,0
    6698:	001b0b13          	addi	s6,s6,1
    669c:	00051663          	bnez	a0,66a8 <build_frame+0x6a8>
    66a0:	017484b3          	add	s1,s1,s7
    66a4:	046b1663          	bne	s6,t1,66f0 <build_frame+0x6f0>
    66a8:	001a0a13          	addi	s4,s4,1
    66ac:	005a8a93          	addi	s5,s5,5
    66b0:	e31ff06f          	j	64e0 <build_frame+0x4e0>
    66b4:	98da08e3          	beq	s4,a3,6044 <build_frame+0x44>
    66b8:	00300713          	li	a4,3
    66bc:	f2ea0ce3          	beq	s4,a4,65f4 <build_frame+0x5f4>
    66c0:	03800493          	li	s1,56
    66c4:	029a04b3          	mul	s1,s4,s1
    66c8:	00800b93          	li	s7,8
    66cc:	0d000d93          	li	s11,208
    66d0:	7e000713          	li	a4,2016
    66d4:	19448493          	addi	s1,s1,404
    66d8:	010b9d13          	slli	s10,s7,0x10
    66dc:	010d5d13          	srli	s10,s10,0x10
    66e0:	06e11a23          	sh	a4,116(sp)
    66e4:	07a11823          	sh	s10,112(sp)
    66e8:	00000b13          	li	s6,0
    66ec:	00500313          	li	t1,5
    66f0:	00000613          	li	a2,0
    66f4:	016a88b3          	add	a7,s5,s6
    66f8:	f15ff06f          	j	660c <build_frame+0x60c>

000066fc <bullet_build_frame_player>:
    66fc:	00100813          	li	a6,1
    6700:	901ff06f          	j	6000 <build_frame>

00006704 <bullet_clip_background_for_hud>:
    6704:	00050793          	mv	a5,a0
    6708:	0c050c63          	beqz	a0,67e0 <bullet_clip_background_for_hud+0xdc>
    670c:	00009737          	lui	a4,0x9
    6710:	00e50733          	add	a4,a0,a4
    6714:	12072703          	lw	a4,288(a4) # 9120 <v3_runtime_advance+0xc0>
    6718:	ff800513          	li	a0,-8
    671c:	0c070463          	beqz	a4,67e4 <bullet_clip_background_for_hud+0xe0>
    6720:	21b00713          	li	a4,539
    6724:	0cb76063          	bltu	a4,a1,67e4 <bullet_clip_background_for_hud+0xe0>
    6728:	01c7c683          	lbu	a3,28(a5)
    672c:	00200713          	li	a4,2
    6730:	0ae69a63          	bne	a3,a4,67e4 <bullet_clip_background_for_hud+0xe0>
    6734:	0107a683          	lw	a3,16(a5)
    6738:	021c0737          	lui	a4,0x21c0
    673c:	3c070713          	addi	a4,a4,960 # 21c03c0 <__gpu_framebuffer_a+0x1c03c0>
    6740:	0ae69263          	bne	a3,a4,67e4 <bullet_clip_background_for_hud+0xe0>
    6744:	0087a703          	lw	a4,8(a5)
    6748:	78000693          	li	a3,1920
    674c:	08d71c63          	bne	a4,a3,67e4 <bullet_clip_background_for_hud+0xe0>
    6750:	00c7a683          	lw	a3,12(a5)
    6754:	08e69863          	bne	a3,a4,67e4 <bullet_clip_background_for_hud+0xe0>
    6758:	0047a803          	lw	a6,4(a5)
    675c:	ffe00737          	lui	a4,0xffe00
    6760:	fff70713          	addi	a4,a4,-1 # ffdfffff <__gpu_framebuffer_a+0xfddfffff>
    6764:	00e87733          	and	a4,a6,a4
    6768:	020006b7          	lui	a3,0x2000
    676c:	06d71c63          	bne	a4,a3,67e4 <bullet_clip_background_for_hud+0xe0>
    6770:	0007a683          	lw	a3,0(a5)
    6774:	000fd737          	lui	a4,0xfd
    6778:	20070713          	addi	a4,a4,512 # fd200 <__freertos_irq_stack_top+0xdf780>
    677c:	00e68733          	add	a4,a3,a4
    6780:	06d76063          	bltu	a4,a3,67e0 <bullet_clip_background_for_hud+0xdc>
    6784:	10000637          	lui	a2,0x10000
    6788:	04e66c63          	bltu	a2,a4,67e0 <bullet_clip_background_for_hud+0xdc>
    678c:	00009737          	lui	a4,0x9
    6790:	00e78733          	add	a4,a5,a4
    6794:	12872603          	lw	a2,296(a4) # 9128 <v3_runtime_advance+0xc8>
    6798:	0007f8b7          	lui	a7,0x7f
    679c:	8ff88893          	addi	a7,a7,-1793 # 7e8ff <__freertos_irq_stack_top+0x60e7f>
    67a0:	04c8f263          	bgeu	a7,a2,67e4 <bullet_clip_background_for_hud+0xe0>
    67a4:	78000513          	li	a0,1920
    67a8:	02a58533          	mul	a0,a1,a0
    67ac:	00a686b3          	add	a3,a3,a0
    67b0:	00d7a023          	sw	a3,0(a5)
    67b4:	21c00693          	li	a3,540
    67b8:	00a80833          	add	a6,a6,a0
    67bc:	40b686b3          	sub	a3,a3,a1
    67c0:	0107a223          	sw	a6,4(a5)
    67c4:	00d79923          	sh	a3,18(a5)
    67c8:	3c000793          	li	a5,960
    67cc:	02f585b3          	mul	a1,a1,a5
    67d0:	00000513          	li	a0,0
    67d4:	40b60633          	sub	a2,a2,a1
    67d8:	12c72423          	sw	a2,296(a4)
    67dc:	00008067          	ret
    67e0:	ff800513          	li	a0,-8
    67e4:	00008067          	ret

000067e8 <_putchar>:
    67e8:	f80107b7          	lui	a5,0xf8010
    67ec:	00478793          	addi	a5,a5,4 # f8010004 <__gpu_framebuffer_a+0xf6010004>
    67f0:	0007a703          	lw	a4,0(a5)
    67f4:	01075693          	srli	a3,a4,0x10
    67f8:	0ff6f693          	zext.b	a3,a3
    67fc:	fe068ae3          	beqz	a3,67f0 <_putchar+0x8>
    6800:	f80107b7          	lui	a5,0xf8010
    6804:	00a7a023          	sw	a0,0(a5) # f8010000 <__gpu_framebuffer_a+0xf6010000>
    6808:	00008067          	ret

0000680c <bsp_printf.constprop.0>:
    680c:	f8010113          	addi	sp,sp,-128
    6810:	05312623          	sw	s3,76(sp)
    6814:	06f12a23          	sw	a5,116(sp)
    6818:	0000d9b7          	lui	s3,0xd
    681c:	06410793          	addi	a5,sp,100
    6820:	05212823          	sw	s2,80(sp)
    6824:	05412423          	sw	s4,72(sp)
    6828:	05512223          	sw	s5,68(sp)
    682c:	05612023          	sw	s6,64(sp)
    6830:	03712e23          	sw	s7,60(sp)
    6834:	04112e23          	sw	ra,92(sp)
    6838:	04812c23          	sw	s0,88(sp)
    683c:	04912a23          	sw	s1,84(sp)
    6840:	03812c23          	sw	s8,56(sp)
    6844:	03912a23          	sw	s9,52(sp)
    6848:	06b12223          	sw	a1,100(sp)
    684c:	06c12423          	sw	a2,104(sp)
    6850:	06d12623          	sw	a3,108(sp)
    6854:	06e12823          	sw	a4,112(sp)
    6858:	07012c23          	sw	a6,120(sp)
    685c:	07112e23          	sw	a7,124(sp)
    6860:	00f12623          	sw	a5,12(sp)
    6864:	00000913          	li	s2,0
    6868:	5a898993          	addi	s3,s3,1448 # d5a8 <_data+0x314>
    686c:	02500a13          	li	s4,37
    6870:	06600a93          	li	s5,102
    6874:	06600b13          	li	s6,102
    6878:	06300b93          	li	s7,99
    687c:	013907b3          	add	a5,s2,s3
    6880:	0007c503          	lbu	a0,0(a5)
    6884:	02051c63          	bnez	a0,68bc <bsp_printf.constprop.0+0xb0>
    6888:	05c12083          	lw	ra,92(sp)
    688c:	05812403          	lw	s0,88(sp)
    6890:	05412483          	lw	s1,84(sp)
    6894:	05012903          	lw	s2,80(sp)
    6898:	04c12983          	lw	s3,76(sp)
    689c:	04812a03          	lw	s4,72(sp)
    68a0:	04412a83          	lw	s5,68(sp)
    68a4:	04012b03          	lw	s6,64(sp)
    68a8:	03c12b83          	lw	s7,60(sp)
    68ac:	03812c03          	lw	s8,56(sp)
    68b0:	03412c83          	lw	s9,52(sp)
    68b4:	08010113          	addi	sp,sp,128
    68b8:	00008067          	ret
    68bc:	0d451863          	bne	a0,s4,698c <bsp_printf.constprop.0+0x180>
    68c0:	00190913          	addi	s2,s2,1
    68c4:	012987b3          	add	a5,s3,s2
    68c8:	0007c783          	lbu	a5,0(a5)
    68cc:	0e078063          	beqz	a5,69ac <bsp_printf.constprop.0+0x1a0>
    68d0:	17578263          	beq	a5,s5,6a34 <bsp_printf.constprop.0+0x228>
    68d4:	04fb6c63          	bltu	s6,a5,692c <bsp_printf.constprop.0+0x120>
    68d8:	0b778263          	beq	a5,s7,697c <bsp_printf.constprop.0+0x170>
    68dc:	06400713          	li	a4,100
    68e0:	0ee78063          	beq	a5,a4,69c0 <bsp_printf.constprop.0+0x1b4>
    68e4:	05800713          	li	a4,88
    68e8:	fce79ce3          	bne	a5,a4,68c0 <bsp_printf.constprop.0+0xb4>
    68ec:	00c12783          	lw	a5,12(sp)
    68f0:	0000d4b7          	lui	s1,0xd
    68f4:	01c00413          	li	s0,28
    68f8:	0007ac83          	lw	s9,0(a5)
    68fc:	00478713          	addi	a4,a5,4
    6900:	00e12623          	sw	a4,12(sp)
    6904:	2e048493          	addi	s1,s1,736 # d2e0 <_data+0x4c>
    6908:	ffc00c13          	li	s8,-4
    690c:	008cd7b3          	srl	a5,s9,s0
    6910:	00f7f793          	andi	a5,a5,15
    6914:	00f487b3          	add	a5,s1,a5
    6918:	0007c503          	lbu	a0,0(a5)
    691c:	ffc40413          	addi	s0,s0,-4
    6920:	ec9ff0ef          	jal	67e8 <_putchar>
    6924:	ff8414e3          	bne	s0,s8,690c <bsp_printf.constprop.0+0x100>
    6928:	0840006f          	j	69ac <bsp_printf.constprop.0+0x1a0>
    692c:	07300713          	li	a4,115
    6930:	06e78263          	beq	a5,a4,6994 <bsp_printf.constprop.0+0x188>
    6934:	07800713          	li	a4,120
    6938:	f8e794e3          	bne	a5,a4,68c0 <bsp_printf.constprop.0+0xb4>
    693c:	00c12783          	lw	a5,12(sp)
    6940:	0000d4b7          	lui	s1,0xd
    6944:	01c00413          	li	s0,28
    6948:	0007ac83          	lw	s9,0(a5)
    694c:	00478713          	addi	a4,a5,4
    6950:	00e12623          	sw	a4,12(sp)
    6954:	2f448493          	addi	s1,s1,756 # d2f4 <_data+0x60>
    6958:	ffc00c13          	li	s8,-4
    695c:	008cd7b3          	srl	a5,s9,s0
    6960:	00f7f793          	andi	a5,a5,15
    6964:	00f487b3          	add	a5,s1,a5
    6968:	0007c503          	lbu	a0,0(a5)
    696c:	ffc40413          	addi	s0,s0,-4
    6970:	e79ff0ef          	jal	67e8 <_putchar>
    6974:	ff8414e3          	bne	s0,s8,695c <bsp_printf.constprop.0+0x150>
    6978:	0340006f          	j	69ac <bsp_printf.constprop.0+0x1a0>
    697c:	00c12783          	lw	a5,12(sp)
    6980:	0007c503          	lbu	a0,0(a5)
    6984:	00478713          	addi	a4,a5,4
    6988:	00e12623          	sw	a4,12(sp)
    698c:	e5dff0ef          	jal	67e8 <_putchar>
    6990:	01c0006f          	j	69ac <bsp_printf.constprop.0+0x1a0>
    6994:	00c12783          	lw	a5,12(sp)
    6998:	0007a403          	lw	s0,0(a5)
    699c:	00478713          	addi	a4,a5,4
    69a0:	00e12623          	sw	a4,12(sp)
    69a4:	00044503          	lbu	a0,0(s0)
    69a8:	00051663          	bnez	a0,69b4 <bsp_printf.constprop.0+0x1a8>
    69ac:	00190913          	addi	s2,s2,1
    69b0:	ecdff06f          	j	687c <bsp_printf.constprop.0+0x70>
    69b4:	00140413          	addi	s0,s0,1
    69b8:	e31ff0ef          	jal	67e8 <_putchar>
    69bc:	fe9ff06f          	j	69a4 <bsp_printf.constprop.0+0x198>
    69c0:	00c12783          	lw	a5,12(sp)
    69c4:	0007a483          	lw	s1,0(a5)
    69c8:	00478713          	addi	a4,a5,4
    69cc:	00e12623          	sw	a4,12(sp)
    69d0:	0004d863          	bgez	s1,69e0 <bsp_printf.constprop.0+0x1d4>
    69d4:	02d00513          	li	a0,45
    69d8:	e11ff0ef          	jal	67e8 <_putchar>
    69dc:	409004b3          	neg	s1,s1
    69e0:	01010413          	addi	s0,sp,16
    69e4:	00040c13          	mv	s8,s0
    69e8:	00a00713          	li	a4,10
    69ec:	00049e63          	bnez	s1,6a08 <bsp_printf.constprop.0+0x1fc>
    69f0:	01840c63          	beq	s0,s8,6a08 <bsp_printf.constprop.0+0x1fc>
    69f4:	fff44503          	lbu	a0,-1(s0)
    69f8:	fff40413          	addi	s0,s0,-1
    69fc:	dedff0ef          	jal	67e8 <_putchar>
    6a00:	ff841ae3          	bne	s0,s8,69f4 <bsp_printf.constprop.0+0x1e8>
    6a04:	fa9ff06f          	j	69ac <bsp_printf.constprop.0+0x1a0>
    6a08:	02e4e7b3          	rem	a5,s1,a4
    6a0c:	00140413          	addi	s0,s0,1
    6a10:	03078793          	addi	a5,a5,48
    6a14:	02e4c4b3          	div	s1,s1,a4
    6a18:	fef40fa3          	sb	a5,-1(s0)
    6a1c:	fd1ff06f          	j	69ec <bsp_printf.constprop.0+0x1e0>
    6a20:	00140413          	addi	s0,s0,1
    6a24:	dc5ff0ef          	jal	67e8 <_putchar>
    6a28:	00044503          	lbu	a0,0(s0)
    6a2c:	fe051ae3          	bnez	a0,6a20 <bsp_printf.constprop.0+0x214>
    6a30:	f7dff06f          	j	69ac <bsp_printf.constprop.0+0x1a0>
    6a34:	0000d437          	lui	s0,0xd
    6a38:	29440413          	addi	s0,s0,660 # d294 <_data>
    6a3c:	fedff06f          	j	6a28 <bsp_printf.constprop.0+0x21c>

00006a40 <bullet_init_local_assets>:
    6a40:	fb010113          	addi	sp,sp,-80
    6a44:	04812423          	sw	s0,72(sp)
    6a48:	00001e37          	lui	t3,0x1
    6a4c:	00001eb7          	lui	t4,0x1
    6a50:	00001f37          	lui	t5,0x1
    6a54:	00002fb7          	lui	t6,0x2
    6a58:	000022b7          	lui	t0,0x2
    6a5c:	000053b7          	lui	t2,0x5
    6a60:	00003437          	lui	s0,0x3
    6a64:	03412c23          	sw	s4,56(sp)
    6a68:	03512a23          	sw	s5,52(sp)
    6a6c:	03612823          	sw	s6,48(sp)
    6a70:	03712623          	sw	s7,44(sp)
    6a74:	01b12e23          	sw	s11,28(sp)
    6a78:	04112623          	sw	ra,76(sp)
    6a7c:	04912223          	sw	s1,68(sp)
    6a80:	05212023          	sw	s2,64(sp)
    6a84:	03312e23          	sw	s3,60(sp)
    6a88:	03812423          	sw	s8,40(sp)
    6a8c:	03912223          	sw	s9,36(sp)
    6a90:	03a12023          	sw	s10,32(sp)
    6a94:	00000713          	li	a4,0
    6a98:	05a00d93          	li	s11,90
    6a9c:	800e0e13          	addi	t3,t3,-2048 # 800 <CUSTOM2+0x7a5>
    6aa0:	03c00b93          	li	s7,60
    6aa4:	07800b13          	li	s6,120
    6aa8:	01800a93          	li	s5,24
    6aac:	00300a13          	li	s4,3
    6ab0:	107e8e93          	addi	t4,t4,263 # 1107 <strchr+0x1f>
    6ab4:	ffdf0f13          	addi	t5,t5,-3 # ffd <CUSTOM2+0xfa2>
    6ab8:	a2cf8f93          	addi	t6,t6,-1492 # 1a2c <gpu_init+0x60>
    6abc:	1af28293          	addi	t0,t0,431 # 21af <gpu_submit+0x327>
    6ac0:	a7138393          	addi	t2,t2,-1423 # 4a71 <perf_render_cpu+0xcd>
    6ac4:	9ad40413          	addi	s0,s0,-1619 # 29ad <golden_copy+0xd1>
    6ac8:	03b756b3          	divu	a3,a4,s11
    6acc:	08700793          	li	a5,135
    6ad0:	fb870893          	addi	a7,a4,-72
    6ad4:	78000593          	li	a1,1920
    6ad8:	09700813          	li	a6,151
    6adc:	00000313          	li	t1,0
    6ae0:	00000613          	li	a2,0
    6ae4:	00200913          	li	s2,2
    6ae8:	3c000c13          	li	s8,960
    6aec:	02f757b3          	divu	a5,a4,a5
    6af0:	00368693          	addi	a3,a3,3 # 2000003 <__gpu_framebuffer_a+0x3>
    6af4:	00569693          	slli	a3,a3,0x5
    6af8:	00778793          	addi	a5,a5,7
    6afc:	00f6e6b3          	or	a3,a3,a5
    6b00:	035757b3          	divu	a5,a4,s5
    6b04:	01c6e6b3          	or	a3,a3,t3
    6b08:	01069693          	slli	a3,a3,0x10
    6b0c:	0106d693          	srli	a3,a3,0x10
    6b10:	0378fd33          	remu	s10,a7,s7
    6b14:	00f12423          	sw	a5,8(sp)
    6b18:	02b007b7          	lui	a5,0x2b00
    6b1c:	0368fcb3          	remu	s9,a7,s6
    6b20:	02b705b3          	mul	a1,a4,a1
    6b24:	00f585b3          	add	a1,a1,a5
    6b28:	034707b3          	mul	a5,a4,s4
    6b2c:	03070833          	mul	a6,a4,a6
    6b30:	00f12623          	sw	a5,12(sp)
    6b34:	21b00793          	li	a5,539
    6b38:	40e789b3          	sub	s3,a5,a4
    6b3c:	04700793          	li	a5,71
    6b40:	00000513          	li	a0,0
    6b44:	08e7f263          	bgeu	a5,a4,6bc8 <bullet_init_local_assets+0x188>
    6b48:	00098793          	mv	a5,s3
    6b4c:	0138f463          	bgeu	a7,s3,6b54 <bullet_init_local_assets+0x114>
    6b50:	00088793          	mv	a5,a7
    6b54:	00f67463          	bgeu	a2,a5,6b5c <bullet_init_local_assets+0x11c>
    6b58:	00060793          	mv	a5,a2
    6b5c:	3bf00513          	li	a0,959
    6b60:	40c50533          	sub	a0,a0,a2
    6b64:	00f57463          	bgeu	a0,a5,6b6c <bullet_init_local_assets+0x12c>
    6b68:	00050793          	mv	a5,a0
    6b6c:	037674b3          	remu	s1,a2,s7
    6b70:	000e8513          	mv	a0,t4
    6b74:	00048663          	beqz	s1,6b80 <bullet_init_local_assets+0x140>
    6b78:	000d0463          	beqz	s10,6b80 <bullet_init_local_assets+0x140>
    6b7c:	00068513          	mv	a0,a3
    6b80:	036674b3          	remu	s1,a2,s6
    6b84:	0194e4b3          	or	s1,s1,s9
    6b88:	00049463          	bnez	s1,6b90 <bullet_init_local_assets+0x150>
    6b8c:	00040513          	mv	a0,s0
    6b90:	006844b3          	xor	s1,a6,t1
    6b94:	03e4f4b3          	remu	s1,s1,t5
    6b98:	00996463          	bltu	s2,s1,6ba0 <bullet_init_local_assets+0x160>
    6b9c:	00038513          	mv	a0,t2
    6ba0:	ff878493          	addi	s1,a5,-8 # 2affff8 <__gpu_framebuffer_a+0xaffff8>
    6ba4:	00100093          	li	ra,1
    6ba8:	0890f063          	bgeu	ra,s1,6c28 <bullet_init_local_assets+0x1e8>
    6bac:	ff478793          	addi	a5,a5,-12
    6bb0:	00f96c63          	bltu	s2,a5,6bc8 <bullet_init_local_assets+0x188>
    6bb4:	035657b3          	divu	a5,a2,s5
    6bb8:	00812083          	lw	ra,8(sp)
    6bbc:	001787b3          	add	a5,a5,ra
    6bc0:	0347f7b3          	remu	a5,a5,s4
    6bc4:	06078663          	beqz	a5,6c30 <bullet_init_local_assets+0x1f0>
    6bc8:	00c12783          	lw	a5,12(sp)
    6bcc:	00a59023          	sh	a0,0(a1)
    6bd0:	00160613          	addi	a2,a2,1 # 10000001 <__gpu_framebuffer_a+0xe000001>
    6bd4:	00258593          	addi	a1,a1,2
    6bd8:	04980813          	addi	a6,a6,73
    6bdc:	00f30333          	add	t1,t1,a5
    6be0:	f5861ee3          	bne	a2,s8,6b3c <bullet_init_local_assets+0xfc>
    6be4:	00170713          	addi	a4,a4,1
    6be8:	21c00793          	li	a5,540
    6bec:	ecf71ee3          	bne	a4,a5,6ac8 <bullet_init_local_assets+0x88>
    6bf0:	0000ea37          	lui	s4,0xe
    6bf4:	00010bb7          	lui	s7,0x10
    6bf8:	00010c37          	lui	s8,0x10
    6bfc:	00004cb7          	lui	s9,0x4
    6c00:	330a0a13          	addi	s4,s4,816 # e330 <colors.2>
    6c04:	00000993          	li	s3,0
    6c08:	81fb8b93          	addi	s7,s7,-2017 # f81f <__global_pointer$+0xab7>
    6c0c:	00900d13          	li	s10,9
    6c10:	fffc0c13          	addi	s8,s8,-1 # ffff <__global_pointer$+0x1297>
    6c14:	02100d93          	li	s11,33
    6c18:	208c8c93          	addi	s9,s9,520 # 4208 <asst_encode+0xdc>
    6c1c:	00699b13          	slli	s6,s3,0x6
    6c20:	00000913          	li	s2,0
    6c24:	0700006f          	j	6c94 <bullet_init_local_assets+0x254>
    6c28:	000f8513          	mv	a0,t6
    6c2c:	f9dff06f          	j	6bc8 <bullet_init_local_assets+0x188>
    6c30:	00028513          	mv	a0,t0
    6c34:	f95ff06f          	j	6bc8 <bullet_init_local_assets+0x188>
    6c38:	00090613          	mv	a2,s2
    6c3c:	00040593          	mv	a1,s0
    6c40:	00098513          	mv	a0,s3
    6c44:	940ff0ef          	jal	5d84 <bullet_shape_opaque>
    6c48:	000b8713          	mv	a4,s7
    6c4c:	00800693          	li	a3,8
    6c50:	02050463          	beqz	a0,6c78 <bullet_init_local_assets+0x238>
    6c54:	00141793          	slli	a5,s0,0x1
    6c58:	ff978793          	addi	a5,a5,-7
    6c5c:	02f787b3          	mul	a5,a5,a5
    6c60:	000c0713          	mv	a4,s8
    6c64:	009787b3          	add	a5,a5,s1
    6c68:	00fd5863          	bge	s10,a5,6c78 <bullet_init_local_assets+0x238>
    6c6c:	000c8713          	mv	a4,s9
    6c70:	00fdc463          	blt	s11,a5,6c78 <bullet_init_local_assets+0x238>
    6c74:	000a5703          	lhu	a4,0(s4)
    6c78:	00ea9023          	sh	a4,0(s5)
    6c7c:	00140413          	addi	s0,s0,1
    6c80:	002a8a93          	addi	s5,s5,2
    6c84:	fad41ae3          	bne	s0,a3,6c38 <bullet_init_local_assets+0x1f8>
    6c88:	00190913          	addi	s2,s2,1
    6c8c:	008b0b13          	addi	s6,s6,8
    6c90:	02890263          	beq	s2,s0,6cb4 <bullet_init_local_assets+0x274>
    6c94:	00191793          	slli	a5,s2,0x1
    6c98:	ff978793          	addi	a5,a5,-7
    6c9c:	02f784b3          	mul	s1,a5,a5
    6ca0:	001b1a93          	slli	s5,s6,0x1
    6ca4:	02c007b7          	lui	a5,0x2c00
    6ca8:	00fa8ab3          	add	s5,s5,a5
    6cac:	00000413          	li	s0,0
    6cb0:	f89ff06f          	j	6c38 <bullet_init_local_assets+0x1f8>
    6cb4:	00198993          	addi	s3,s3,1
    6cb8:	00600793          	li	a5,6
    6cbc:	002a0a13          	addi	s4,s4,2
    6cc0:	f4f99ee3          	bne	s3,a5,6c1c <bullet_init_local_assets+0x1dc>
    6cc4:	00010337          	lui	t1,0x10
    6cc8:	000103b7          	lui	t2,0x10
    6ccc:	02c00837          	lui	a6,0x2c00
    6cd0:	00000713          	li	a4,0
    6cd4:	00300413          	li	s0,3
    6cd8:	00700493          	li	s1,7
    6cdc:	fff30313          	addi	t1,t1,-1 # ffff <__global_pointer$+0x1297>
    6ce0:	81f38393          	addi	t2,t2,-2017 # f81f <__global_pointer$+0xab7>
    6ce4:	00a00913          	li	s2,10
    6ce8:	00200993          	li	s3,2
    6cec:	30f80813          	addi	a6,a6,783 # 2c0030f <__gpu_framebuffer_a+0xc0030f>
    6cf0:	01100f93          	li	t6,17
    6cf4:	01000293          	li	t0,16
    6cf8:	00571513          	slli	a0,a4,0x5
    6cfc:	ffe70893          	addi	a7,a4,-2
    6d00:	ff100613          	li	a2,-15
    6d04:	00b8b893          	sltiu	a7,a7,11
    6d08:	ffb70f13          	addi	t5,a4,-5
    6d0c:	ff370e93          	addi	t4,a4,-13
    6d10:	01050533          	add	a0,a0,a6
    6d14:	41f65793          	srai	a5,a2,0x1f
    6d18:	00c7c5b3          	xor	a1,a5,a2
    6d1c:	40f585b3          	sub	a1,a1,a5
    6d20:	00000e13          	li	t3,0
    6d24:	00b44463          	blt	s0,a1,6d2c <bullet_init_local_assets+0x2ec>
    6d28:	00088e13          	mv	t3,a7
    6d2c:	03e4ea63          	bltu	s1,t5,6d60 <bullet_init_local_assets+0x320>
    6d30:	00171693          	slli	a3,a4,0x1
    6d34:	ff868693          	addi	a3,a3,-8
    6d38:	00b6a6b3          	slt	a3,a3,a1
    6d3c:	0016b693          	seqz	a3,a3
    6d40:	00030793          	mv	a5,t1
    6d44:	020e1863          	bnez	t3,6d74 <bullet_init_local_assets+0x334>
    6d48:	00038793          	mv	a5,t2
    6d4c:	02068463          	beqz	a3,6d74 <bullet_init_local_assets+0x334>
    6d50:	43000793          	li	a5,1072
    6d54:	02e94063          	blt	s2,a4,6d74 <bullet_init_local_assets+0x334>
    6d58:	7ff00793          	li	a5,2047
    6d5c:	0180006f          	j	6d74 <bullet_init_local_assets+0x334>
    6d60:	00000693          	li	a3,0
    6d64:	fdd9eee3          	bltu	s3,t4,6d40 <bullet_init_local_assets+0x300>
    6d68:	120e0c63          	beqz	t3,6ea0 <bullet_init_local_assets+0x460>
    6d6c:	000107b7          	lui	a5,0x10
    6d70:	fff78793          	addi	a5,a5,-1 # ffff <__global_pointer$+0x1297>
    6d74:	00c506b3          	add	a3,a0,a2
    6d78:	00f69023          	sh	a5,0(a3)
    6d7c:	00260613          	addi	a2,a2,2
    6d80:	f9f61ae3          	bne	a2,t6,6d14 <bullet_init_local_assets+0x2d4>
    6d84:	00170713          	addi	a4,a4,1
    6d88:	f65718e3          	bne	a4,t0,6cf8 <bullet_init_local_assets+0x2b8>
    6d8c:	02c005b7          	lui	a1,0x2c00
    6d90:	ff500693          	li	a3,-11
    6d94:	00c00893          	li	a7,12
    6d98:	58f58593          	addi	a1,a1,1423 # 2c0058f <__gpu_framebuffer_a+0xc0058f>
    6d9c:	01600313          	li	t1,22
    6da0:	00d00e13          	li	t3,13
    6da4:	03168633          	mul	a2,a3,a7
    6da8:	41f6d793          	srai	a5,a3,0x1f
    6dac:	00d7c533          	xor	a0,a5,a3
    6db0:	40f50533          	sub	a0,a0,a5
    6db4:	ff500713          	li	a4,-11
    6db8:	00b60633          	add	a2,a2,a1
    6dbc:	41f75813          	srai	a6,a4,0x1f
    6dc0:	00e847b3          	xor	a5,a6,a4
    6dc4:	410787b3          	sub	a5,a5,a6
    6dc8:	00a787b3          	add	a5,a5,a0
    6dcc:	40f307b3          	sub	a5,t1,a5
    6dd0:	00679793          	slli	a5,a5,0x6
    6dd4:	01079793          	slli	a5,a5,0x10
    6dd8:	00e60eb3          	add	t4,a2,a4
    6ddc:	0107d793          	srli	a5,a5,0x10
    6de0:	00fe9023          	sh	a5,0(t4)
    6de4:	00270713          	addi	a4,a4,2
    6de8:	fdc71ae3          	bne	a4,t3,6dbc <bullet_init_local_assets+0x37c>
    6dec:	00268693          	addi	a3,a3,2
    6df0:	fae69ae3          	bne	a3,a4,6da4 <bullet_init_local_assets+0x364>
    6df4:	000107b7          	lui	a5,0x10
    6df8:	00010f37          	lui	t5,0x10
    6dfc:	00008837          	lui	a6,0x8
    6e00:	fff78793          	addi	a5,a5,-1 # ffff <__global_pointer$+0x1297>
    6e04:	02c00eb7          	lui	t4,0x2c00
    6e08:	000102b7          	lui	t0,0x10
    6e0c:	81018513          	addi	a0,gp,-2032 # e578 <enemies.1>
    6e10:	00000893          	li	a7,0
    6e14:	00200413          	li	s0,2
    6e18:	00100493          	li	s1,1
    6e1c:	81ff0f13          	addi	t5,t5,-2017 # f81f <__global_pointer$+0xab7>
    6e20:	00800913          	li	s2,8
    6e24:	41080813          	addi	a6,a6,1040 # 8410 <initial_valid+0x94>
    6e28:	00900993          	li	s3,9
    6e2c:	00f12623          	sw	a5,12(sp)
    6e30:	00700a13          	li	s4,7
    6e34:	62fe8e93          	addi	t4,t4,1583 # 2c0062f <__gpu_framebuffer_a+0xc0062f>
    6e38:	c8028293          	addi	t0,t0,-896 # fc80 <__global_pointer$+0xf18>
    6e3c:	00055383          	lhu	t2,0(a0)
    6e40:	00589e13          	slli	t3,a7,0x5
    6e44:	00000793          	li	a5,0
    6e48:	00d00b13          	li	s6,13
    6e4c:	00600b93          	li	s7,6
    6e50:	ffb78f93          	addi	t6,a5,-5
    6e54:	01de0733          	add	a4,t3,t4
    6e58:	ff100693          	li	a3,-15
    6e5c:	ff378a93          	addi	s5,a5,-13
    6e60:	ffbfff93          	andi	t6,t6,-5
    6e64:	00b00c13          	li	s8,11
    6e68:	00300c93          	li	s9,3
    6e6c:	ffd78d13          	addi	s10,a5,-3
    6e70:	00c7ad93          	slti	s11,a5,12
    6e74:	00e12423          	sw	a4,8(sp)
    6e78:	41f6d613          	srai	a2,a3,0x1f
    6e7c:	00d64733          	xor	a4,a2,a3
    6e80:	40c70733          	sub	a4,a4,a2
    6e84:	ff970613          	addi	a2,a4,-7
    6e88:	02c46a63          	bltu	s0,a2,6ebc <bullet_init_local_assets+0x47c>
    6e8c:	000d8613          	mv	a2,s11
    6e90:	0c079e63          	bnez	a5,6f6c <bullet_init_local_assets+0x52c>
    6e94:	00000593          	li	a1,0
    6e98:	00000613          	li	a2,0
    6e9c:	0dc0006f          	j	6f78 <bullet_init_local_assets+0x538>
    6ea0:	000107b7          	lui	a5,0x10
    6ea4:	00300693          	li	a3,3
    6ea8:	c8078793          	addi	a5,a5,-896 # fc80 <__global_pointer$+0xf18>
    6eac:	ecb6d4e3          	bge	a3,a1,6d74 <bullet_init_local_assets+0x334>
    6eb0:	000107b7          	lui	a5,0x10
    6eb4:	81f78793          	addi	a5,a5,-2017 # f81f <__global_pointer$+0xab7>
    6eb8:	ebdff06f          	j	6d74 <bullet_init_local_assets+0x334>
    6ebc:	0aecc663          	blt	s9,a4,6f68 <bullet_init_local_assets+0x528>
    6ec0:	fda9eae3          	bltu	s3,s10,6e94 <bullet_init_local_assets+0x454>
    6ec4:	00000613          	li	a2,0
    6ec8:	00100593          	li	a1,1
    6ecc:	0a0f9463          	bnez	t6,6f74 <bullet_init_local_assets+0x534>
    6ed0:	0eec5a63          	bge	s8,a4,6fc4 <bullet_init_local_assets+0x584>
    6ed4:	00000313          	li	t1,0
    6ed8:	00058663          	beqz	a1,6ee4 <bullet_init_local_assets+0x4a4>
    6edc:	00c12703          	lw	a4,12(sp)
    6ee0:	00f9ca63          	blt	s3,a5,6ef4 <bullet_init_local_assets+0x4b4>
    6ee4:	0c060663          	beqz	a2,6fb0 <bullet_init_local_assets+0x570>
    6ee8:	00080713          	mv	a4,a6
    6eec:	00f44463          	blt	s0,a5,6ef4 <bullet_init_local_assets+0x4b4>
    6ef0:	00028713          	mv	a4,t0
    6ef4:	00812603          	lw	a2,8(sp)
    6ef8:	00d60633          	add	a2,a2,a3
    6efc:	00e61023          	sh	a4,0(a2)
    6f00:	00268693          	addi	a3,a3,2
    6f04:	01100713          	li	a4,17
    6f08:	f6e698e3          	bne	a3,a4,6e78 <bullet_init_local_assets+0x438>
    6f0c:	00178793          	addi	a5,a5,1
    6f10:	01000713          	li	a4,16
    6f14:	020e0e13          	addi	t3,t3,32
    6f18:	f2e79ce3          	bne	a5,a4,6e50 <bullet_init_local_assets+0x410>
    6f1c:	01088893          	addi	a7,a7,16
    6f20:	03000793          	li	a5,48
    6f24:	00250513          	addi	a0,a0,2
    6f28:	f0f89ae3          	bne	a7,a5,6e3c <bullet_init_local_assets+0x3fc>
    6f2c:	04c12083          	lw	ra,76(sp)
    6f30:	04812403          	lw	s0,72(sp)
    6f34:	04412483          	lw	s1,68(sp)
    6f38:	04012903          	lw	s2,64(sp)
    6f3c:	03c12983          	lw	s3,60(sp)
    6f40:	03812a03          	lw	s4,56(sp)
    6f44:	03412a83          	lw	s5,52(sp)
    6f48:	03012b03          	lw	s6,48(sp)
    6f4c:	02c12b83          	lw	s7,44(sp)
    6f50:	02812c03          	lw	s8,40(sp)
    6f54:	02412c83          	lw	s9,36(sp)
    6f58:	02012d03          	lw	s10,32(sp)
    6f5c:	01c12d83          	lw	s11,28(sp)
    6f60:	05010113          	addi	sp,sp,80
    6f64:	00008067          	ret
    6f68:	00000613          	li	a2,0
    6f6c:	00000593          	li	a1,0
    6f70:	f5dff06f          	j	6ecc <bullet_init_local_assets+0x48c>
    6f74:	05778863          	beq	a5,s7,6fc4 <bullet_init_local_assets+0x584>
    6f78:	05478663          	beq	a5,s4,6fc4 <bullet_init_local_assets+0x584>
    6f7c:	03279063          	bne	a5,s2,6f9c <bullet_init_local_assets+0x55c>
    6f80:	04eb5263          	bge	s6,a4,6fc4 <bullet_init_local_assets+0x584>
    6f84:	00080713          	mv	a4,a6
    6f88:	f60616e3          	bnez	a2,6ef4 <bullet_init_local_assets+0x4b4>
    6f8c:	00038713          	mv	a4,t2
    6f90:	f60592e3          	bnez	a1,6ef4 <bullet_init_local_assets+0x4b4>
    6f94:	000f0713          	mv	a4,t5
    6f98:	f5dff06f          	j	6ef4 <bullet_init_local_assets+0x4b4>
    6f9c:	f2e4cce3          	blt	s1,a4,6ed4 <bullet_init_local_assets+0x494>
    6fa0:	f354eae3          	bltu	s1,s5,6ed4 <bullet_init_local_assets+0x494>
    6fa4:	00010737          	lui	a4,0x10
    6fa8:	fff70713          	addi	a4,a4,-1 # ffff <__global_pointer$+0x1297>
    6fac:	f49ff06f          	j	6ef4 <bullet_init_local_assets+0x4b4>
    6fb0:	fc030ee3          	beqz	t1,6f8c <bullet_init_local_assets+0x54c>
    6fb4:	00038713          	mv	a4,t2
    6fb8:	f3279ee3          	bne	a5,s2,6ef4 <bullet_init_local_assets+0x4b4>
    6fbc:	43000713          	li	a4,1072
    6fc0:	f35ff06f          	j	6ef4 <bullet_init_local_assets+0x4b4>
    6fc4:	00100313          	li	t1,1
    6fc8:	f11ff06f          	j	6ed8 <bullet_init_local_assets+0x498>

00006fcc <bullet_load_network_assets>:
    6fcc:	fc010113          	addi	sp,sp,-64
    6fd0:	00002737          	lui	a4,0x2
    6fd4:	03212823          	sw	s2,48(sp)
    6fd8:	f9070713          	addi	a4,a4,-112 # 1f90 <gpu_submit+0x108>
    6fdc:	00058913          	mv	s2,a1
    6fe0:	c0a80637          	lui	a2,0xc0a80
    6fe4:	c0a805b7          	lui	a1,0xc0a80
    6fe8:	00070693          	mv	a3,a4
    6fec:	10260613          	addi	a2,a2,258 # c0a80102 <__gpu_framebuffer_a+0xbea80102>
    6ff0:	10358593          	addi	a1,a1,259 # c0a80103 <__gpu_framebuffer_a+0xbea80103>
    6ff4:	02812c23          	sw	s0,56(sp)
    6ff8:	02912a23          	sw	s1,52(sp)
    6ffc:	02112e23          	sw	ra,60(sp)
    7000:	03312623          	sw	s3,44(sp)
    7004:	00050493          	mv	s1,a0
    7008:	c74fd0ef          	jal	447c <network_configure>
    700c:	00050413          	mv	s0,a0
    7010:	0a051263          	bnez	a0,70b4 <bullet_load_network_assets+0xe8>
    7014:	4a955837          	lui	a6,0x4a955
    7018:	000fd7b7          	lui	a5,0xfd
    701c:	05f5e5b7          	lui	a1,0x5f5e
    7020:	02900737          	lui	a4,0x2900
    7024:	06500693          	li	a3,101
    7028:	00090613          	mv	a2,s2
    702c:	10058593          	addi	a1,a1,256 # 5f5e100 <__gpu_framebuffer_a+0x3f5e100>
    7030:	00810893          	addi	a7,sp,8
    7034:	6cc80813          	addi	a6,a6,1740 # 4a9556cc <__gpu_framebuffer_a+0x489556cc>
    7038:	20078793          	addi	a5,a5,512 # fd200 <__freertos_irq_stack_top+0xdf780>
    703c:	00048513          	mv	a0,s1
    7040:	ca0fd0ef          	jal	44e0 <network_asset_fetch>
    7044:	01012683          	lw	a3,16(sp)
    7048:	00812603          	lw	a2,8(sp)
    704c:	0000d9b7          	lui	s3,0xd
    7050:	00050413          	mv	s0,a0
    7054:	00050713          	mv	a4,a0
    7058:	06500593          	li	a1,101
    705c:	5a898513          	addi	a0,s3,1448 # d5a8 <_data+0x314>
    7060:	facff0ef          	jal	680c <bsp_printf.constprop.0>
    7064:	04041863          	bnez	s0,70b4 <bullet_load_network_assets+0xe8>
    7068:	9d6b3837          	lui	a6,0x9d6b3
    706c:	000017b7          	lui	a5,0x1
    7070:	05f5e5b7          	lui	a1,0x5f5e
    7074:	02a00737          	lui	a4,0x2a00
    7078:	06600693          	li	a3,102
    707c:	00090613          	mv	a2,s2
    7080:	10058593          	addi	a1,a1,256 # 5f5e100 <__gpu_framebuffer_a+0x3f5e100>
    7084:	00810893          	addi	a7,sp,8
    7088:	1f280813          	addi	a6,a6,498 # 9d6b31f2 <__gpu_framebuffer_a+0x9b6b31f2>
    708c:	c2078793          	addi	a5,a5,-992 # c20 <CUSTOM2+0xbc5>
    7090:	00048513          	mv	a0,s1
    7094:	c4cfd0ef          	jal	44e0 <network_asset_fetch>
    7098:	01012683          	lw	a3,16(sp)
    709c:	00812603          	lw	a2,8(sp)
    70a0:	00050413          	mv	s0,a0
    70a4:	00050713          	mv	a4,a0
    70a8:	06600593          	li	a1,102
    70ac:	5a898513          	addi	a0,s3,1448
    70b0:	f5cff0ef          	jal	680c <bsp_printf.constprop.0>
    70b4:	03c12083          	lw	ra,60(sp)
    70b8:	00040513          	mv	a0,s0
    70bc:	03812403          	lw	s0,56(sp)
    70c0:	03412483          	lw	s1,52(sp)
    70c4:	03012903          	lw	s2,48(sp)
    70c8:	02c12983          	lw	s3,44(sp)
    70cc:	04010113          	addi	sp,sp,64
    70d0:	00008067          	ret

000070d4 <bullet_prepare_assets>:
    70d4:	fe010113          	addi	sp,sp,-32
    70d8:	00112e23          	sw	ra,28(sp)
    70dc:	ef1ff0ef          	jal	6fcc <bullet_load_network_assets>
    70e0:	00050863          	beqz	a0,70f0 <bullet_prepare_assets+0x1c>
    70e4:	00a12623          	sw	a0,12(sp)
    70e8:	959ff0ef          	jal	6a40 <bullet_init_local_assets>
    70ec:	00c12503          	lw	a0,12(sp)
    70f0:	01c12083          	lw	ra,28(sp)
    70f4:	02010113          	addi	sp,sp,32
    70f8:	00008067          	ret

000070fc <bullet_prepare_texture_cache>:
    70fc:	00060693          	mv	a3,a2
    7100:	00059a63          	bnez	a1,7114 <bullet_prepare_texture_cache+0x18>
    7104:	02a005b7          	lui	a1,0x2a00
    7108:	00001637          	lui	a2,0x1
    710c:	c2060613          	addi	a2,a2,-992 # c20 <CUSTOM2+0xbc5>
    7110:	bb4fb06f          	j	24c4 <gpu_texture_cache_load>
    7114:	02c005b7          	lui	a1,0x2c00
    7118:	ff1ff06f          	j	7108 <bullet_prepare_texture_cache+0xc>

0000711c <be32>:
    711c:	00054783          	lbu	a5,0(a0)
    7120:	00154703          	lbu	a4,1(a0)
    7124:	01879793          	slli	a5,a5,0x18
    7128:	01071713          	slli	a4,a4,0x10
    712c:	00e7e7b3          	or	a5,a5,a4
    7130:	00354703          	lbu	a4,3(a0)
    7134:	00254503          	lbu	a0,2(a0)
    7138:	00e7e7b3          	or	a5,a5,a4
    713c:	00851513          	slli	a0,a0,0x8
    7140:	00a7e533          	or	a0,a5,a0
    7144:	00008067          	ret

00007148 <put32>:
    7148:	0185d793          	srli	a5,a1,0x18
    714c:	00f50023          	sb	a5,0(a0)
    7150:	0105d793          	srli	a5,a1,0x10
    7154:	00f500a3          	sb	a5,1(a0)
    7158:	0085d793          	srli	a5,a1,0x8
    715c:	00f50123          	sb	a5,2(a0)
    7160:	00b501a3          	sb	a1,3(a0)
    7164:	00008067          	ret

00007168 <expire>:
    7168:	01654783          	lbu	a5,22(a0)
    716c:	00079663          	bnez	a5,7178 <expire+0x10>
    7170:	00000513          	li	a0,0
    7174:	00008067          	ret
    7178:	08452783          	lw	a5,132(a0)
    717c:	40f585b3          	sub	a1,a1,a5
    7180:	00b52823          	sw	a1,16(a0)
    7184:	0fa00793          	li	a5,250
    7188:	feb7f4e3          	bgeu	a5,a1,7170 <expire+0x8>
    718c:	00452783          	lw	a5,4(a0)
    7190:	00052423          	sw	zero,8(a0)
    7194:	00052223          	sw	zero,4(a0)
    7198:	08f52623          	sw	a5,140(a0)
    719c:	fff00793          	li	a5,-1
    71a0:	00052623          	sw	zero,12(a0)
    71a4:	00052a23          	sw	zero,20(a0)
    71a8:	00f52823          	sw	a5,16(a0)
    71ac:	0a0504a3          	sb	zero,169(a0)
    71b0:	0c051423          	sh	zero,200(a0)
    71b4:	0c050523          	sb	zero,202(a0)
    71b8:	0c050ea3          	sb	zero,221(a0)
    71bc:	00100513          	li	a0,1
    71c0:	00008067          	ret

000071c4 <take>:
    71c4:	00052683          	lw	a3,0(a0)
    71c8:	00050793          	mv	a5,a0
    71cc:	3046a703          	lw	a4,772(a3)
    71d0:	00377513          	andi	a0,a4,3
    71d4:	08050a63          	beqz	a0,7268 <take+0xa4>
    71d8:	00277713          	andi	a4,a4,2
    71dc:	06070463          	beqz	a4,7244 <take+0x80>
    71e0:	0007a703          	lw	a4,0(a5)
    71e4:	00000693          	li	a3,0
    71e8:	02000513          	li	a0,32
    71ec:	31072703          	lw	a4,784(a4) # 2a00310 <__gpu_framebuffer_a+0xa00310>
    71f0:	00e62023          	sw	a4,0(a2)
    71f4:	0007a703          	lw	a4,0(a5)
    71f8:	00d58633          	add	a2,a1,a3
    71fc:	32070713          	addi	a4,a4,800
    7200:	00d70733          	add	a4,a4,a3
    7204:	00072883          	lw	a7,0(a4)
    7208:	00000713          	li	a4,0
    720c:	00e8d833          	srl	a6,a7,a4
    7210:	01060023          	sb	a6,0(a2)
    7214:	00870713          	addi	a4,a4,8
    7218:	00160613          	addi	a2,a2,1
    721c:	fea718e3          	bne	a4,a0,720c <take+0x48>
    7220:	00468693          	addi	a3,a3,4
    7224:	fce698e3          	bne	a3,a4,71f4 <take+0x30>
    7228:	0ff0000f          	fence
    722c:	0007a783          	lw	a5,0(a5)
    7230:	00100713          	li	a4,1
    7234:	30e7a623          	sw	a4,780(a5)
    7238:	0ff0000f          	fence
    723c:	00100513          	li	a0,1
    7240:	00008067          	ret
    7244:	00100713          	li	a4,1
    7248:	30e6a423          	sw	a4,776(a3)
    724c:	0ff0000f          	fence
    7250:	0007a703          	lw	a4,0(a5)
    7254:	ffd00513          	li	a0,-3
    7258:	30472703          	lw	a4,772(a4)
    725c:	00277713          	andi	a4,a4,2
    7260:	f80710e3          	bnez	a4,71e0 <take+0x1c>
    7264:	00008067          	ret
    7268:	00000513          	li	a0,0
    726c:	00008067          	ret

00007270 <nc_init>:
    7270:	0a050e63          	beqz	a0,732c <nc_init+0xbc>
    7274:	fc010113          	addi	sp,sp,-64
    7278:	02812c23          	sw	s0,56(sp)
    727c:	02912a23          	sw	s1,52(sp)
    7280:	02112e23          	sw	ra,60(sp)
    7284:	0035f793          	andi	a5,a1,3
    7288:	00050413          	mv	s0,a0
    728c:	00058493          	mv	s1,a1
    7290:	fff00513          	li	a0,-1
    7294:	08079263          	bnez	a5,7318 <nc_init+0xa8>
    7298:	00059463          	bnez	a1,72a0 <nc_init+0x30>
    729c:	f81004b7          	lui	s1,0xf8100
    72a0:	0e000613          	li	a2,224
    72a4:	00000593          	li	a1,0
    72a8:	00040513          	mv	a0,s0
    72ac:	f7df90ef          	jal	1228 <memset>
    72b0:	fff00793          	li	a5,-1
    72b4:	00f42823          	sw	a5,16(s0)
    72b8:	0c800793          	li	a5,200
    72bc:	0af42023          	sw	a5,160(s0)
    72c0:	3004a703          	lw	a4,768(s1) # f8100300 <__gpu_framebuffer_a+0xf6100300>
    72c4:	4d4757b7          	lui	a5,0x4d475
    72c8:	00942023          	sw	s1,0(s0)
    72cc:	43178793          	addi	a5,a5,1073 # 4d475431 <__gpu_framebuffer_a+0x4b475431>
    72d0:	ffe00513          	li	a0,-2
    72d4:	04f71263          	bne	a4,a5,7318 <nc_init+0xa8>
    72d8:	3044a783          	lw	a5,772(s1)
    72dc:	00400493          	li	s1,4
    72e0:	0057d793          	srli	a5,a5,0x5
    72e4:	0017f793          	andi	a5,a5,1
    72e8:	0cf40e23          	sb	a5,220(s0)
    72ec:	00c10613          	addi	a2,sp,12
    72f0:	01010593          	addi	a1,sp,16
    72f4:	00040513          	mv	a0,s0
    72f8:	ecdff0ef          	jal	71c4 <take>
    72fc:	00054e63          	bltz	a0,7318 <nc_init+0xa8>
    7300:	00050663          	beqz	a0,730c <nc_init+0x9c>
    7304:	fff48493          	addi	s1,s1,-1
    7308:	fe0492e3          	bnez	s1,72ec <nc_init+0x7c>
    730c:	00100793          	li	a5,1
    7310:	0af40423          	sb	a5,168(s0)
    7314:	00000513          	li	a0,0
    7318:	03c12083          	lw	ra,60(sp)
    731c:	03812403          	lw	s0,56(sp)
    7320:	03412483          	lw	s1,52(sp)
    7324:	04010113          	addi	sp,sp,64
    7328:	00008067          	ret
    732c:	fff00513          	li	a0,-1
    7330:	00008067          	ret

00007334 <nc_poll>:
    7334:	f8010113          	addi	sp,sp,-128
    7338:	06112e23          	sw	ra,124(sp)
    733c:	06812c23          	sw	s0,120(sp)
    7340:	06912a23          	sw	s1,116(sp)
    7344:	07212823          	sw	s2,112(sp)
    7348:	07312623          	sw	s3,108(sp)
    734c:	07412423          	sw	s4,104(sp)
    7350:	07512223          	sw	s5,100(sp)
    7354:	07612023          	sw	s6,96(sp)
    7358:	05712e23          	sw	s7,92(sp)
    735c:	05812c23          	sw	s8,88(sp)
    7360:	05912a23          	sw	s9,84(sp)
    7364:	05a12823          	sw	s10,80(sp)
    7368:	05b12623          	sw	s11,76(sp)
    736c:	04061463          	bnez	a2,73b4 <nc_poll+0x80>
    7370:	fff00913          	li	s2,-1
    7374:	07c12083          	lw	ra,124(sp)
    7378:	07812403          	lw	s0,120(sp)
    737c:	07412483          	lw	s1,116(sp)
    7380:	06c12983          	lw	s3,108(sp)
    7384:	06812a03          	lw	s4,104(sp)
    7388:	06412a83          	lw	s5,100(sp)
    738c:	06012b03          	lw	s6,96(sp)
    7390:	05c12b83          	lw	s7,92(sp)
    7394:	05812c03          	lw	s8,88(sp)
    7398:	05412c83          	lw	s9,84(sp)
    739c:	05012d03          	lw	s10,80(sp)
    73a0:	04c12d83          	lw	s11,76(sp)
    73a4:	00090513          	mv	a0,s2
    73a8:	07012903          	lw	s2,112(sp)
    73ac:	08010113          	addi	sp,sp,128
    73b0:	00008067          	ret
    73b4:	fff00793          	li	a5,-1
    73b8:	00062023          	sw	zero,0(a2)
    73bc:	00062223          	sw	zero,4(a2)
    73c0:	00062423          	sw	zero,8(a2)
    73c4:	00062823          	sw	zero,16(a2)
    73c8:	00f62623          	sw	a5,12(a2)
    73cc:	00050413          	mv	s0,a0
    73d0:	00060493          	mv	s1,a2
    73d4:	f8050ee3          	beqz	a0,7370 <nc_poll+0x3c>
    73d8:	0a854783          	lbu	a5,168(a0)
    73dc:	ffe00913          	li	s2,-2
    73e0:	f8078ae3          	beqz	a5,7374 <nc_poll+0x40>
    73e4:	00058a93          	mv	s5,a1
    73e8:	41474bb7          	lui	s7,0x41474
    73ec:	d7dff0ef          	jal	7168 <expire>
    73f0:	00050993          	mv	s3,a0
    73f4:	00400b13          	li	s6,4
    73f8:	331b8b93          	addi	s7,s7,817 # 41474331 <__gpu_framebuffer_a+0x3f474331>
    73fc:	01c10613          	addi	a2,sp,28
    7400:	02010593          	addi	a1,sp,32
    7404:	00040513          	mv	a0,s0
    7408:	dbdff0ef          	jal	71c4 <take>
    740c:	00050913          	mv	s2,a0
    7410:	00055c63          	bgez	a0,7428 <nc_poll+0xf4>
    7414:	01400613          	li	a2,20
    7418:	00440593          	addi	a1,s0,4
    741c:	00048513          	mv	a0,s1
    7420:	ee5f90ef          	jal	1304 <memcpy>
    7424:	f51ff06f          	j	7374 <nc_poll+0x40>
    7428:	2c050263          	beqz	a0,76ec <nc_poll+0x3b8>
    742c:	01c12983          	lw	s3,28(sp)
    7430:	0fa00793          	li	a5,250
    7434:	0b37e863          	bltu	a5,s3,74e4 <nc_poll+0x1b0>
    7438:	02010513          	addi	a0,sp,32
    743c:	ce1ff0ef          	jal	711c <be32>
    7440:	0b751263          	bne	a0,s7,74e4 <nc_poll+0x1b0>
    7444:	02414d03          	lbu	s10,36(sp)
    7448:	00100793          	li	a5,1
    744c:	08fd1c63          	bne	s10,a5,74e4 <nc_poll+0x1b0>
    7450:	02614c03          	lbu	s8,38(sp)
    7454:	080c1863          	bnez	s8,74e4 <nc_poll+0x1b0>
    7458:	02714703          	lbu	a4,39(sp)
    745c:	02000793          	li	a5,32
    7460:	08f71263          	bne	a4,a5,74e4 <nc_poll+0x1b0>
    7464:	02810513          	addi	a0,sp,40
    7468:	cb5ff0ef          	jal	711c <be32>
    746c:	06050c63          	beqz	a0,74e4 <nc_poll+0x1b0>
    7470:	03c10513          	addi	a0,sp,60
    7474:	ca9ff0ef          	jal	711c <be32>
    7478:	00050913          	mv	s2,a0
    747c:	01c00593          	li	a1,28
    7480:	02010513          	addi	a0,sp,32
    7484:	c5dfc0ef          	jal	40e0 <asst_crc32>
    7488:	04a91e63          	bne	s2,a0,74e4 <nc_poll+0x1b0>
    748c:	02514a03          	lbu	s4,37(sp)
    7490:	03aa1863          	bne	s4,s10,74c0 <nc_poll+0x18c>
    7494:	03010513          	addi	a0,sp,48
    7498:	c85ff0ef          	jal	711c <be32>
    749c:	00050913          	mv	s2,a0
    74a0:	03410513          	addi	a0,sp,52
    74a4:	c79ff0ef          	jal	711c <be32>
    74a8:	00a96933          	or	s2,s2,a0
    74ac:	03810513          	addi	a0,sp,56
    74b0:	c6dff0ef          	jal	711c <be32>
    74b4:	00a96933          	or	s2,s2,a0
    74b8:	06090e63          	beqz	s2,7534 <nc_poll+0x200>
    74bc:	0280006f          	j	74e4 <nc_poll+0x1b0>
    74c0:	00200793          	li	a5,2
    74c4:	02fa1863          	bne	s4,a5,74f4 <nc_poll+0x1c0>
    74c8:	03010513          	addi	a0,sp,48
    74cc:	c51ff0ef          	jal	711c <be32>
    74d0:	0ff00793          	li	a5,255
    74d4:	00a7e863          	bltu	a5,a0,74e4 <nc_poll+0x1b0>
    74d8:	03810513          	addi	a0,sp,56
    74dc:	c41ff0ef          	jal	711c <be32>
    74e0:	04050a63          	beqz	a0,7534 <nc_poll+0x200>
    74e4:	0a442783          	lw	a5,164(s0)
    74e8:	00178793          	addi	a5,a5,1
    74ec:	0af42223          	sw	a5,164(s0)
    74f0:	08c0006f          	j	757c <nc_poll+0x248>
    74f4:	00400793          	li	a5,4
    74f8:	fefa16e3          	bne	s4,a5,74e4 <nc_poll+0x1b0>
    74fc:	03010513          	addi	a0,sp,48
    7500:	c1dff0ef          	jal	711c <be32>
    7504:	00050d93          	mv	s11,a0
    7508:	03410513          	addi	a0,sp,52
    750c:	c11ff0ef          	jal	711c <be32>
    7510:	00050913          	mv	s2,a0
    7514:	03810513          	addi	a0,sp,56
    7518:	c05ff0ef          	jal	711c <be32>
    751c:	fc0504e3          	beqz	a0,74e4 <nc_poll+0x1b0>
    7520:	00100793          	li	a5,1
    7524:	06fd9c63          	bne	s11,a5,759c <nc_poll+0x268>
    7528:	fff90913          	addi	s2,s2,-1
    752c:	00500793          	li	a5,5
    7530:	fb27eae3          	bltu	a5,s2,74e4 <nc_poll+0x1b0>
    7534:	02810513          	addi	a0,sp,40
    7538:	be5ff0ef          	jal	711c <be32>
    753c:	00050c93          	mv	s9,a0
    7540:	02c10513          	addi	a0,sp,44
    7544:	bd9ff0ef          	jal	711c <be32>
    7548:	00100693          	li	a3,1
    754c:	01644703          	lbu	a4,22(s0)
    7550:	00050913          	mv	s2,a0
    7554:	08da1c63          	bne	s4,a3,75ec <nc_poll+0x2b8>
    7558:	04070863          	beqz	a4,75a8 <nc_poll+0x274>
    755c:	00442703          	lw	a4,4(s0)
    7560:	f8ec92e3          	bne	s9,a4,74e4 <nc_poll+0x1b0>
    7564:	08842703          	lw	a4,136(s0)
    7568:	f6e51ee3          	bne	a0,a4,74e4 <nc_poll+0x1b0>
    756c:	00100793          	li	a5,1
    7570:	09942823          	sw	s9,144(s0)
    7574:	09242a23          	sw	s2,148(s0)
    7578:	0af404a3          	sb	a5,169(s0)
    757c:	fffb0b13          	addi	s6,s6,-1
    7580:	00100993          	li	s3,1
    7584:	e60b1ce3          	bnez	s6,73fc <nc_poll+0xc8>
    7588:	00100913          	li	s2,1
    758c:	000a8593          	mv	a1,s5
    7590:	00040513          	mv	a0,s0
    7594:	bd5ff0ef          	jal	7168 <expire>
    7598:	e7dff06f          	j	7414 <nc_poll+0xe0>
    759c:	ffed8d93          	addi	s11,s11,-2
    75a0:	f1b7fce3          	bgeu	a5,s11,74b8 <nc_poll+0x184>
    75a4:	f41ff06f          	j	74e4 <nc_poll+0x1b0>
    75a8:	08c42703          	lw	a4,140(s0)
    75ac:	f2ec8ce3          	beq	s9,a4,74e4 <nc_poll+0x1b0>
    75b0:	00042a23          	sw	zero,20(s0)
    75b4:	01342823          	sw	s3,16(s0)
    75b8:	413a89b3          	sub	s3,s5,s3
    75bc:	00042623          	sw	zero,12(s0)
    75c0:	01942223          	sw	s9,4(s0)
    75c4:	00a42423          	sw	a0,8(s0)
    75c8:	01440b23          	sb	s4,22(s0)
    75cc:	09342223          	sw	s3,132(s0)
    75d0:	08a42423          	sw	a0,136(s0)
    75d4:	0c041423          	sh	zero,200(s0)
    75d8:	0c040523          	sb	zero,202(s0)
    75dc:	0a040523          	sb	zero,170(s0)
    75e0:	0c040f23          	sb	zero,222(s0)
    75e4:	0c040ea3          	sb	zero,221(s0)
    75e8:	f85ff06f          	j	756c <nc_poll+0x238>
    75ec:	ee070ce3          	beqz	a4,74e4 <nc_poll+0x1b0>
    75f0:	00442703          	lw	a4,4(s0)
    75f4:	eeec98e3          	bne	s9,a4,74e4 <nc_poll+0x1b0>
    75f8:	00842703          	lw	a4,8(s0)
    75fc:	40e50733          	sub	a4,a0,a4
    7600:	eee052e3          	blez	a4,74e4 <nc_poll+0x1b0>
    7604:	08442703          	lw	a4,132(s0)
    7608:	413a8db3          	sub	s11,s5,s3
    760c:	40ed8733          	sub	a4,s11,a4
    7610:	ec074ae3          	bltz	a4,74e4 <nc_poll+0x1b0>
    7614:	03410513          	addi	a0,sp,52
    7618:	b05ff0ef          	jal	711c <be32>
    761c:	00400693          	li	a3,4
    7620:	0ada1863          	bne	s4,a3,76d0 <nc_poll+0x39c>
    7624:	00a12623          	sw	a0,12(sp)
    7628:	03010513          	addi	a0,sp,48
    762c:	af1ff0ef          	jal	711c <be32>
    7630:	00050a13          	mv	s4,a0
    7634:	03810513          	addi	a0,sp,56
    7638:	ae5ff0ef          	jal	711c <be32>
    763c:	0c845683          	lhu	a3,200(s0)
    7640:	00c12703          	lw	a4,12(sp)
    7644:	04068663          	beqz	a3,7690 <nc_poll+0x35c>
    7648:	0bc42683          	lw	a3,188(s0)
    764c:	04d51263          	bne	a0,a3,7690 <nc_poll+0x35c>
    7650:	0b442783          	lw	a5,180(s0)
    7654:	e8fa18e3          	bne	s4,a5,74e4 <nc_poll+0x1b0>
    7658:	0b842783          	lw	a5,184(s0)
    765c:	e8e794e3          	bne	a5,a4,74e4 <nc_poll+0x1b0>
    7660:	0c944783          	lbu	a5,201(s0)
    7664:	0b242823          	sw	s2,176(s0)
    7668:	00078663          	beqz	a5,7674 <nc_poll+0x340>
    766c:	00100793          	li	a5,1
    7670:	0cf40523          	sb	a5,202(s0)
    7674:	00000513          	li	a0,0
    7678:	00a41a23          	sh	a0,20(s0)
    767c:	01840ba3          	sb	s8,23(s0)
    7680:	01242423          	sw	s2,8(s0)
    7684:	01342823          	sw	s3,16(s0)
    7688:	09b42223          	sw	s11,132(s0)
    768c:	ef1ff06f          	j	757c <nc_poll+0x248>
    7690:	0c844683          	lbu	a3,200(s0)
    7694:	e40698e3          	bnez	a3,74e4 <nc_poll+0x1b0>
    7698:	0c944683          	lbu	a3,201(s0)
    769c:	00068863          	beqz	a3,76ac <nc_poll+0x378>
    76a0:	0bc42683          	lw	a3,188(s0)
    76a4:	40d506b3          	sub	a3,a0,a3
    76a8:	e2d05ee3          	blez	a3,74e4 <nc_poll+0x1b0>
    76ac:	00100793          	li	a5,1
    76b0:	0b942623          	sw	s9,172(s0)
    76b4:	0b242823          	sw	s2,176(s0)
    76b8:	0b442a23          	sw	s4,180(s0)
    76bc:	0ae42c23          	sw	a4,184(s0)
    76c0:	0aa42e23          	sw	a0,188(s0)
    76c4:	0cf41423          	sh	a5,200(s0)
    76c8:	0c040523          	sb	zero,202(s0)
    76cc:	fa9ff06f          	j	7674 <nc_poll+0x340>
    76d0:	00a42623          	sw	a0,12(s0)
    76d4:	03010513          	addi	a0,sp,48
    76d8:	a45ff0ef          	jal	711c <be32>
    76dc:	01051513          	slli	a0,a0,0x10
    76e0:	01055513          	srli	a0,a0,0x10
    76e4:	000d0c13          	mv	s8,s10
    76e8:	f91ff06f          	j	7678 <nc_poll+0x344>
    76ec:	00098913          	mv	s2,s3
    76f0:	e9dff06f          	j	758c <nc_poll+0x258>

000076f4 <nc_take_game>:
    76f4:	00050793          	mv	a5,a0
    76f8:	04050863          	beqz	a0,7748 <nc_take_game+0x54>
    76fc:	00058513          	mv	a0,a1
    7700:	fff00713          	li	a4,-1
    7704:	04058463          	beqz	a1,774c <nc_take_game+0x58>
    7708:	0a87c683          	lbu	a3,168(a5)
    770c:	ffe00713          	li	a4,-2
    7710:	02068e63          	beqz	a3,774c <nc_take_game+0x58>
    7714:	0c87c683          	lbu	a3,200(a5)
    7718:	00000713          	li	a4,0
    771c:	02068863          	beqz	a3,774c <nc_take_game+0x58>
    7720:	ff010113          	addi	sp,sp,-16
    7724:	01400613          	li	a2,20
    7728:	0ac78593          	addi	a1,a5,172
    772c:	00112623          	sw	ra,12(sp)
    7730:	bd5f90ef          	jal	1304 <memcpy>
    7734:	00c12083          	lw	ra,12(sp)
    7738:	00100713          	li	a4,1
    773c:	00070513          	mv	a0,a4
    7740:	01010113          	addi	sp,sp,16
    7744:	00008067          	ret
    7748:	fff00713          	li	a4,-1
    774c:	00070513          	mv	a0,a4
    7750:	00008067          	ret

00007754 <nc_discard_pending_telemetry>:
    7754:	00050663          	beqz	a0,7760 <nc_discard_pending_telemetry+0xc>
    7758:	0c050ea3          	sb	zero,221(a0)
    775c:	0a050523          	sb	zero,170(a0)
    7760:	00008067          	ret

00007764 <nc_complete_game>:
    7764:	0a050c63          	beqz	a0,781c <nc_complete_game+0xb8>
    7768:	ff010113          	addi	sp,sp,-16
    776c:	00812423          	sw	s0,8(sp)
    7770:	00112623          	sw	ra,12(sp)
    7774:	00912223          	sw	s1,4(sp)
    7778:	00050413          	mv	s0,a0
    777c:	fff00513          	li	a0,-1
    7780:	08058463          	beqz	a1,7808 <nc_complete_game+0xa4>
    7784:	00200793          	li	a5,2
    7788:	00060493          	mv	s1,a2
    778c:	06c7ee63          	bltu	a5,a2,7808 <nc_complete_game+0xa4>
    7790:	0a844783          	lbu	a5,168(s0)
    7794:	06078a63          	beqz	a5,7808 <nc_complete_game+0xa4>
    7798:	01644783          	lbu	a5,22(s0)
    779c:	06078663          	beqz	a5,7808 <nc_complete_game+0xa4>
    77a0:	0c844783          	lbu	a5,200(s0)
    77a4:	06078263          	beqz	a5,7808 <nc_complete_game+0xa4>
    77a8:	0005a783          	lw	a5,0(a1) # 2c00000 <__gpu_framebuffer_a+0xc00000>
    77ac:	00442703          	lw	a4,4(s0)
    77b0:	04e79c63          	bne	a5,a4,7808 <nc_complete_game+0xa4>
    77b4:	0ac42703          	lw	a4,172(s0)
    77b8:	04e79863          	bne	a5,a4,7808 <nc_complete_game+0xa4>
    77bc:	0105a703          	lw	a4,16(a1)
    77c0:	0bc42783          	lw	a5,188(s0)
    77c4:	04f71263          	bne	a4,a5,7808 <nc_complete_game+0xa4>
    77c8:	0085a703          	lw	a4,8(a1)
    77cc:	0b442783          	lw	a5,180(s0)
    77d0:	02f71c63          	bne	a4,a5,7808 <nc_complete_game+0xa4>
    77d4:	00c5a703          	lw	a4,12(a1)
    77d8:	0b842783          	lw	a5,184(s0)
    77dc:	02f71663          	bne	a4,a5,7808 <nc_complete_game+0xa4>
    77e0:	00040513          	mv	a0,s0
    77e4:	f71ff0ef          	jal	7754 <nc_discard_pending_telemetry>
    77e8:	09842783          	lw	a5,152(s0)
    77ec:	0c942023          	sw	s1,192(s0)
    77f0:	00000513          	li	a0,0
    77f4:	0cf42223          	sw	a5,196(s0)
    77f8:	10000793          	li	a5,256
    77fc:	0cf41423          	sh	a5,200(s0)
    7800:	00100793          	li	a5,1
    7804:	0cf40523          	sb	a5,202(s0)
    7808:	00c12083          	lw	ra,12(sp)
    780c:	00812403          	lw	s0,8(sp)
    7810:	00412483          	lw	s1,4(sp)
    7814:	01010113          	addi	sp,sp,16
    7818:	00008067          	ret
    781c:	fff00513          	li	a0,-1
    7820:	00008067          	ret

00007824 <nc_try_publish>:
    7824:	38050063          	beqz	a0,7ba4 <nc_try_publish+0x380>
    7828:	ef010113          	addi	sp,sp,-272
    782c:	10812423          	sw	s0,264(sp)
    7830:	10112623          	sw	ra,268(sp)
    7834:	10912223          	sw	s1,260(sp)
    7838:	11212023          	sw	s2,256(sp)
    783c:	0f312e23          	sw	s3,252(sp)
    7840:	0f412c23          	sw	s4,248(sp)
    7844:	0f512a23          	sw	s5,244(sp)
    7848:	0f612823          	sw	s6,240(sp)
    784c:	0a854703          	lbu	a4,168(a0)
    7850:	00050413          	mv	s0,a0
    7854:	ffe00513          	li	a0,-2
    7858:	2e070463          	beqz	a4,7b40 <nc_try_publish+0x31c>
    785c:	00060993          	mv	s3,a2
    7860:	00058c63          	beqz	a1,7878 <nc_try_publish+0x54>
    7864:	06c00613          	li	a2,108
    7868:	01840513          	addi	a0,s0,24
    786c:	a99f90ef          	jal	1304 <memcpy>
    7870:	00100793          	li	a5,1
    7874:	0af40523          	sb	a5,170(s0)
    7878:	00098593          	mv	a1,s3
    787c:	00040513          	mv	a0,s0
    7880:	8e9ff0ef          	jal	7168 <expire>
    7884:	0aa44703          	lbu	a4,170(s0)
    7888:	0a042783          	lw	a5,160(s0)
    788c:	00000493          	li	s1,0
    7890:	02070663          	beqz	a4,78bc <nc_try_publish+0x98>
    7894:	0ab44703          	lbu	a4,171(s0)
    7898:	00100493          	li	s1,1
    789c:	02070063          	beqz	a4,78bc <nc_try_publish+0x98>
    78a0:	09c42483          	lw	s1,156(s0)
    78a4:	06400713          	li	a4,100
    78a8:	409984b3          	sub	s1,s3,s1
    78ac:	00e7f463          	bgeu	a5,a4,78b4 <nc_try_publish+0x90>
    78b0:	06400793          	li	a5,100
    78b4:	00f4b4b3          	sltu	s1,s1,a5
    78b8:	0014b493          	seqz	s1,s1
    78bc:	0dd44783          	lbu	a5,221(s0)
    78c0:	00000913          	li	s2,0
    78c4:	02078463          	beqz	a5,78ec <nc_try_publish+0xc8>
    78c8:	01644783          	lbu	a5,22(s0)
    78cc:	02078063          	beqz	a5,78ec <nc_try_publish+0xc8>
    78d0:	0de44783          	lbu	a5,222(s0)
    78d4:	00100913          	li	s2,1
    78d8:	00078a63          	beqz	a5,78ec <nc_try_publish+0xc8>
    78dc:	0d842903          	lw	s2,216(s0)
    78e0:	41298933          	sub	s2,s3,s2
    78e4:	0c893913          	sltiu	s2,s2,200
    78e8:	00193913          	seqz	s2,s2
    78ec:	0a944a03          	lbu	s4,169(s0)
    78f0:	000a1a63          	bnez	s4,7904 <nc_try_publish+0xe0>
    78f4:	0ca44783          	lbu	a5,202(s0)
    78f8:	00079663          	bnez	a5,7904 <nc_try_publish+0xe0>
    78fc:	0124e533          	or	a0,s1,s2
    7900:	24050063          	beqz	a0,7b40 <nc_try_publish+0x31c>
    7904:	00042783          	lw	a5,0(s0)
    7908:	00000513          	li	a0,0
    790c:	3047a783          	lw	a5,772(a5)
    7910:	0047f793          	andi	a5,a5,4
    7914:	22078663          	beqz	a5,7b40 <nc_try_publish+0x31c>
    7918:	08000613          	li	a2,128
    791c:	00000593          	li	a1,0
    7920:	07010513          	addi	a0,sp,112
    7924:	905f90ef          	jal	1228 <memset>
    7928:	280a1263          	bnez	s4,7bac <nc_try_publish+0x388>
    792c:	0ca44783          	lbu	a5,202(s0)
    7930:	2e079463          	bnez	a5,7c18 <nc_try_publish+0x3f4>
    7934:	09842a83          	lw	s5,152(s0)
    7938:	001a8a93          	addi	s5,s5,1
    793c:	36048263          	beqz	s1,7ca0 <nc_try_publish+0x47c>
    7940:	01644783          	lbu	a5,22(s0)
    7944:	00000493          	li	s1,0
    7948:	00078463          	beqz	a5,7950 <nc_try_publish+0x12c>
    794c:	00442483          	lw	s1,4(s0)
    7950:	01842783          	lw	a5,24(s0)
    7954:	007f8737          	lui	a4,0x7f8
    7958:	fff70713          	addi	a4,a4,-1 # 7f7fff <__freertos_irq_stack_top+0x7da57f>
    795c:	00f12223          	sw	a5,4(sp)
    7960:	01c42783          	lw	a5,28(s0)
    7964:	414755b7          	lui	a1,0x41475
    7968:	43158593          	addi	a1,a1,1073 # 41475431 <__gpu_framebuffer_a+0x3f475431>
    796c:	00f12423          	sw	a5,8(sp)
    7970:	02042783          	lw	a5,32(s0)
    7974:	07010513          	addi	a0,sp,112
    7978:	06c00913          	li	s2,108
    797c:	00f12623          	sw	a5,12(sp)
    7980:	02442783          	lw	a5,36(s0)
    7984:	00f12823          	sw	a5,16(sp)
    7988:	02842783          	lw	a5,40(s0)
    798c:	00f12a23          	sw	a5,20(sp)
    7990:	02c42783          	lw	a5,44(s0)
    7994:	00f12c23          	sw	a5,24(sp)
    7998:	03042783          	lw	a5,48(s0)
    799c:	00f12e23          	sw	a5,28(sp)
    79a0:	03442783          	lw	a5,52(s0)
    79a4:	02f12023          	sw	a5,32(sp)
    79a8:	03842783          	lw	a5,56(s0)
    79ac:	02f12223          	sw	a5,36(sp)
    79b0:	03c42783          	lw	a5,60(s0)
    79b4:	02f12423          	sw	a5,40(sp)
    79b8:	04042783          	lw	a5,64(s0)
    79bc:	02f12623          	sw	a5,44(sp)
    79c0:	04442783          	lw	a5,68(s0)
    79c4:	02f12823          	sw	a5,48(sp)
    79c8:	04842783          	lw	a5,72(s0)
    79cc:	02f12a23          	sw	a5,52(sp)
    79d0:	04c42783          	lw	a5,76(s0)
    79d4:	02f12c23          	sw	a5,56(sp)
    79d8:	05042783          	lw	a5,80(s0)
    79dc:	02f12e23          	sw	a5,60(sp)
    79e0:	05442783          	lw	a5,84(s0)
    79e4:	04f12023          	sw	a5,64(sp)
    79e8:	05842783          	lw	a5,88(s0)
    79ec:	04f12223          	sw	a5,68(sp)
    79f0:	05c42783          	lw	a5,92(s0)
    79f4:	04f12423          	sw	a5,72(sp)
    79f8:	06042783          	lw	a5,96(s0)
    79fc:	04f12623          	sw	a5,76(sp)
    7a00:	06442783          	lw	a5,100(s0)
    7a04:	04f12823          	sw	a5,80(sp)
    7a08:	06842783          	lw	a5,104(s0)
    7a0c:	04f12a23          	sw	a5,84(sp)
    7a10:	06c42783          	lw	a5,108(s0)
    7a14:	00e7f7b3          	and	a5,a5,a4
    7a18:	04f12c23          	sw	a5,88(sp)
    7a1c:	07042783          	lw	a5,112(s0)
    7a20:	04f12e23          	sw	a5,92(sp)
    7a24:	07442783          	lw	a5,116(s0)
    7a28:	06f12023          	sw	a5,96(sp)
    7a2c:	07842783          	lw	a5,120(s0)
    7a30:	06f12223          	sw	a5,100(sp)
    7a34:	07c42783          	lw	a5,124(s0)
    7a38:	06f12423          	sw	a5,104(sp)
    7a3c:	08042783          	lw	a5,128(s0)
    7a40:	06f12623          	sw	a5,108(sp)
    7a44:	f04ff0ef          	jal	7148 <put32>
    7a48:	ffff87b7          	lui	a5,0xffff8
    7a4c:	00178793          	addi	a5,a5,1 # ffff8001 <__gpu_framebuffer_a+0xfdff8001>
    7a50:	00048593          	mv	a1,s1
    7a54:	06f11a23          	sh	a5,116(sp)
    7a58:	07810513          	addi	a0,sp,120
    7a5c:	f8000793          	li	a5,-128
    7a60:	06f10ba3          	sb	a5,119(sp)
    7a64:	ee4ff0ef          	jal	7148 <put32>
    7a68:	000a8593          	mv	a1,s5
    7a6c:	07c10513          	addi	a0,sp,124
    7a70:	ed8ff0ef          	jal	7148 <put32>
    7a74:	00000493          	li	s1,0
    7a78:	00410793          	addi	a5,sp,4
    7a7c:	009787b3          	add	a5,a5,s1
    7a80:	0007a583          	lw	a1,0(a5)
    7a84:	08010793          	addi	a5,sp,128
    7a88:	00978533          	add	a0,a5,s1
    7a8c:	00448493          	addi	s1,s1,4
    7a90:	eb8ff0ef          	jal	7148 <put32>
    7a94:	ff2492e3          	bne	s1,s2,7a78 <nc_try_publish+0x254>
    7a98:	07c00593          	li	a1,124
    7a9c:	07010513          	addi	a0,sp,112
    7aa0:	e40fc0ef          	jal	40e0 <asst_crc32>
    7aa4:	00050593          	mv	a1,a0
    7aa8:	0ec10513          	addi	a0,sp,236
    7aac:	e9cff0ef          	jal	7148 <put32>
    7ab0:	00000913          	li	s2,0
    7ab4:	00000493          	li	s1,0
    7ab8:	08000693          	li	a3,128
    7abc:	00042783          	lw	a5,0(s0)
    7ac0:	07010713          	addi	a4,sp,112
    7ac4:	00000613          	li	a2,0
    7ac8:	3cd7a023          	sw	a3,960(a5)
    7acc:	34078593          	addi	a1,a5,832
    7ad0:	00174783          	lbu	a5,1(a4)
    7ad4:	00274503          	lbu	a0,2(a4)
    7ad8:	00470713          	addi	a4,a4,4
    7adc:	00879793          	slli	a5,a5,0x8
    7ae0:	01051513          	slli	a0,a0,0x10
    7ae4:	00a7e7b3          	or	a5,a5,a0
    7ae8:	ffc74503          	lbu	a0,-4(a4)
    7aec:	00a7e7b3          	or	a5,a5,a0
    7af0:	fff74503          	lbu	a0,-1(a4)
    7af4:	01851513          	slli	a0,a0,0x18
    7af8:	00a7e7b3          	or	a5,a5,a0
    7afc:	00c58533          	add	a0,a1,a2
    7b00:	00f52023          	sw	a5,0(a0)
    7b04:	00460613          	addi	a2,a2,4
    7b08:	fcd664e3          	bltu	a2,a3,7ad0 <nc_try_publish+0x2ac>
    7b0c:	0ff0000f          	fence
    7b10:	00042783          	lw	a5,0(s0)
    7b14:	00100713          	li	a4,1
    7b18:	30e7ac23          	sw	a4,792(a5)
    7b1c:	0ff0000f          	fence
    7b20:	00042783          	lw	a5,0(s0)
    7b24:	ffd00513          	li	a0,-3
    7b28:	3047a783          	lw	a5,772(a5)
    7b2c:	0087f793          	andi	a5,a5,8
    7b30:	00079863          	bnez	a5,7b40 <nc_try_publish+0x31c>
    7b34:	020a0a63          	beqz	s4,7b68 <nc_try_publish+0x344>
    7b38:	0a0404a3          	sb	zero,169(s0)
    7b3c:	00100513          	li	a0,1
    7b40:	10c12083          	lw	ra,268(sp)
    7b44:	10812403          	lw	s0,264(sp)
    7b48:	10412483          	lw	s1,260(sp)
    7b4c:	10012903          	lw	s2,256(sp)
    7b50:	0fc12983          	lw	s3,252(sp)
    7b54:	0f812a03          	lw	s4,248(sp)
    7b58:	0f412a83          	lw	s5,244(sp)
    7b5c:	0f012b03          	lw	s6,240(sp)
    7b60:	11010113          	addi	sp,sp,272
    7b64:	00008067          	ret
    7b68:	00048663          	beqz	s1,7b74 <nc_try_publish+0x350>
    7b6c:	0c040523          	sb	zero,202(s0)
    7b70:	fcdff06f          	j	7b3c <nc_try_publish+0x318>
    7b74:	09842783          	lw	a5,152(s0)
    7b78:	00178793          	addi	a5,a5,1
    7b7c:	00090c63          	beqz	s2,7b94 <nc_try_publish+0x370>
    7b80:	0c040ea3          	sb	zero,221(s0)
    7b84:	0ce40f23          	sb	a4,222(s0)
    7b88:	0d342c23          	sw	s3,216(s0)
    7b8c:	08f42c23          	sw	a5,152(s0)
    7b90:	fadff06f          	j	7b3c <nc_try_publish+0x318>
    7b94:	10000713          	li	a4,256
    7b98:	0ae41523          	sh	a4,170(s0)
    7b9c:	09342e23          	sw	s3,156(s0)
    7ba0:	fedff06f          	j	7b8c <nc_try_publish+0x368>
    7ba4:	fff00513          	li	a0,-1
    7ba8:	00008067          	ret
    7bac:	414745b7          	lui	a1,0x41474
    7bb0:	09042903          	lw	s2,144(s0)
    7bb4:	33158593          	addi	a1,a1,817 # 41474331 <__gpu_framebuffer_a+0x3f474331>
    7bb8:	07010513          	addi	a0,sp,112
    7bbc:	09442483          	lw	s1,148(s0)
    7bc0:	d88ff0ef          	jal	7148 <put32>
    7bc4:	30100793          	li	a5,769
    7bc8:	00090593          	mv	a1,s2
    7bcc:	06f11a23          	sh	a5,116(sp)
    7bd0:	07810513          	addi	a0,sp,120
    7bd4:	02000793          	li	a5,32
    7bd8:	06f10ba3          	sb	a5,119(sp)
    7bdc:	d6cff0ef          	jal	7148 <put32>
    7be0:	00048593          	mv	a1,s1
    7be4:	07c10513          	addi	a0,sp,124
    7be8:	d60ff0ef          	jal	7148 <put32>
    7bec:	00100793          	li	a5,1
    7bf0:	01c00593          	li	a1,28
    7bf4:	07010513          	addi	a0,sp,112
    7bf8:	08f101a3          	sb	a5,131(sp)
    7bfc:	ce4fc0ef          	jal	40e0 <asst_crc32>
    7c00:	00050593          	mv	a1,a0
    7c04:	08c10513          	addi	a0,sp,140
    7c08:	d40ff0ef          	jal	7148 <put32>
    7c0c:	00000913          	li	s2,0
    7c10:	00000493          	li	s1,0
    7c14:	1080006f          	j	7d1c <nc_try_publish+0x4f8>
    7c18:	414745b7          	lui	a1,0x41474
    7c1c:	0ac42903          	lw	s2,172(s0)
    7c20:	33158593          	addi	a1,a1,817 # 41474331 <__gpu_framebuffer_a+0x3f474331>
    7c24:	07010513          	addi	a0,sp,112
    7c28:	0b042483          	lw	s1,176(s0)
    7c2c:	d1cff0ef          	jal	7148 <put32>
    7c30:	50100793          	li	a5,1281
    7c34:	00090593          	mv	a1,s2
    7c38:	06f11a23          	sh	a5,116(sp)
    7c3c:	07810513          	addi	a0,sp,120
    7c40:	02000793          	li	a5,32
    7c44:	06f10ba3          	sb	a5,119(sp)
    7c48:	d00ff0ef          	jal	7148 <put32>
    7c4c:	00048593          	mv	a1,s1
    7c50:	07c10513          	addi	a0,sp,124
    7c54:	cf4ff0ef          	jal	7148 <put32>
    7c58:	0bc42583          	lw	a1,188(s0)
    7c5c:	08010513          	addi	a0,sp,128
    7c60:	00000913          	li	s2,0
    7c64:	ce4ff0ef          	jal	7148 <put32>
    7c68:	0c042583          	lw	a1,192(s0)
    7c6c:	08410513          	addi	a0,sp,132
    7c70:	00100493          	li	s1,1
    7c74:	cd4ff0ef          	jal	7148 <put32>
    7c78:	0c442583          	lw	a1,196(s0)
    7c7c:	08810513          	addi	a0,sp,136
    7c80:	cc8ff0ef          	jal	7148 <put32>
    7c84:	01c00593          	li	a1,28
    7c88:	07010513          	addi	a0,sp,112
    7c8c:	c54fc0ef          	jal	40e0 <asst_crc32>
    7c90:	00050593          	mv	a1,a0
    7c94:	08c10513          	addi	a0,sp,140
    7c98:	cb0ff0ef          	jal	7148 <put32>
    7c9c:	0800006f          	j	7d1c <nc_try_publish+0x4f8>
    7ca0:	ca0900e3          	beqz	s2,7940 <nc_try_publish+0x11c>
    7ca4:	414745b7          	lui	a1,0x41474
    7ca8:	00442b03          	lw	s6,4(s0)
    7cac:	33158593          	addi	a1,a1,817 # 41474331 <__gpu_framebuffer_a+0x3f474331>
    7cb0:	07010513          	addi	a0,sp,112
    7cb4:	c94ff0ef          	jal	7148 <put32>
    7cb8:	60100793          	li	a5,1537
    7cbc:	06f11a23          	sh	a5,116(sp)
    7cc0:	000b0593          	mv	a1,s6
    7cc4:	02000793          	li	a5,32
    7cc8:	07810513          	addi	a0,sp,120
    7ccc:	06f10ba3          	sb	a5,119(sp)
    7cd0:	c78ff0ef          	jal	7148 <put32>
    7cd4:	000a8593          	mv	a1,s5
    7cd8:	07c10513          	addi	a0,sp,124
    7cdc:	c6cff0ef          	jal	7148 <put32>
    7ce0:	0cc42583          	lw	a1,204(s0)
    7ce4:	08010513          	addi	a0,sp,128
    7ce8:	c60ff0ef          	jal	7148 <put32>
    7cec:	0d042583          	lw	a1,208(s0)
    7cf0:	08410513          	addi	a0,sp,132
    7cf4:	c54ff0ef          	jal	7148 <put32>
    7cf8:	0d442583          	lw	a1,212(s0)
    7cfc:	08810513          	addi	a0,sp,136
    7d00:	c48ff0ef          	jal	7148 <put32>
    7d04:	01c00593          	li	a1,28
    7d08:	07010513          	addi	a0,sp,112
    7d0c:	bd4fc0ef          	jal	40e0 <asst_crc32>
    7d10:	00050593          	mv	a1,a0
    7d14:	08c10513          	addi	a0,sp,140
    7d18:	c30ff0ef          	jal	7148 <put32>
    7d1c:	02000693          	li	a3,32
    7d20:	d9dff06f          	j	7abc <nc_try_publish+0x298>

00007d24 <input_update>:
    7d24:	12050263          	beqz	a0,7e48 <input_update+0x124>
    7d28:	00051123          	sh	zero,2(a0)
    7d2c:	00051223          	sh	zero,4(a0)
    7d30:	02058063          	beqz	a1,7d50 <input_update+0x2c>
    7d34:	0125c783          	lbu	a5,18(a1)
    7d38:	00078c63          	beqz	a5,7d50 <input_update+0x2c>
    7d3c:	0005a883          	lw	a7,0(a1)
    7d40:	00088863          	beqz	a7,7d50 <input_update+0x2c>
    7d44:	00c5a703          	lw	a4,12(a1)
    7d48:	0fa00793          	li	a5,250
    7d4c:	00e7fe63          	bgeu	a5,a4,7d68 <input_update+0x44>
    7d50:	00055783          	lhu	a5,0(a0)
    7d54:	00051a23          	sh	zero,20(a0)
    7d58:	00051023          	sh	zero,0(a0)
    7d5c:	00f51223          	sh	a5,4(a0)
    7d60:	00050b23          	sb	zero,22(a0)
    7d64:	00008067          	ret
    7d68:	01454783          	lbu	a5,20(a0)
    7d6c:	0045a303          	lw	t1,4(a1)
    7d70:	00078e63          	beqz	a5,7d8c <input_update+0x68>
    7d74:	00852783          	lw	a5,8(a0)
    7d78:	00f89a63          	bne	a7,a5,7d8c <input_update+0x68>
    7d7c:	00c52783          	lw	a5,12(a0)
    7d80:	40f307b3          	sub	a5,t1,a5
    7d84:	00f04663          	bgtz	a5,7d90 <input_update+0x6c>
    7d88:	00008067          	ret
    7d8c:	00050aa3          	sb	zero,21(a0)
    7d90:	0105d603          	lhu	a2,16(a1)
    7d94:	00300713          	li	a4,3
    7d98:	00367693          	andi	a3,a2,3
    7d9c:	0fc67793          	andi	a5,a2,252
    7da0:	00e68463          	beq	a3,a4,7da8 <input_update+0x84>
    7da4:	0ff67793          	zext.b	a5,a2
    7da8:	00c7f713          	andi	a4,a5,12
    7dac:	00c00693          	li	a3,12
    7db0:	00d71863          	bne	a4,a3,7dc0 <input_update+0x9c>
    7db4:	ff37f793          	andi	a5,a5,-13
    7db8:	01079793          	slli	a5,a5,0x10
    7dbc:	0107d793          	srli	a5,a5,0x10
    7dc0:	00055803          	lhu	a6,0(a0)
    7dc4:	fff7ce13          	not	t3,a5
    7dc8:	fff84713          	not	a4,a6
    7dcc:	00e7f733          	and	a4,a5,a4
    7dd0:	01c87833          	and	a6,a6,t3
    7dd4:	f3f77693          	andi	a3,a4,-193
    7dd8:	01069693          	slli	a3,a3,0x10
    7ddc:	01051223          	sh	a6,4(a0)
    7de0:	01554803          	lbu	a6,21(a0)
    7de4:	0106d693          	srli	a3,a3,0x10
    7de8:	00d51123          	sh	a3,2(a0)
    7dec:	0085ae03          	lw	t3,8(a1)
    7df0:	00080863          	beqz	a6,7e00 <input_update+0xdc>
    7df4:	01052803          	lw	a6,16(a0)
    7df8:	410e0833          	sub	a6,t3,a6
    7dfc:	03005263          	blez	a6,7e20 <input_update+0xfc>
    7e00:	0c077713          	andi	a4,a4,192
    7e04:	04071463          	bnez	a4,7e4c <input_update+0x128>
    7e08:	0c07f713          	andi	a4,a5,192
    7e0c:	00e6e6b3          	or	a3,a3,a4
    7e10:	00100713          	li	a4,1
    7e14:	00d51123          	sh	a3,2(a0)
    7e18:	01c52823          	sw	t3,16(a0)
    7e1c:	00e50aa3          	sb	a4,21(a0)
    7e20:	00f51023          	sh	a5,0(a0)
    7e24:	00100793          	li	a5,1
    7e28:	00f50a23          	sb	a5,20(a0)
    7e2c:	01152423          	sw	a7,8(a0)
    7e30:	00652623          	sw	t1,12(a0)
    7e34:	0135c703          	lbu	a4,19(a1)
    7e38:	00000793          	li	a5,0
    7e3c:	00070463          	beqz	a4,7e44 <input_update+0x120>
    7e40:	00163793          	seqz	a5,a2
    7e44:	00f50b23          	sb	a5,22(a0)
    7e48:	00008067          	ret
    7e4c:	01071713          	slli	a4,a4,0x10
    7e50:	41075713          	srai	a4,a4,0x10
    7e54:	fb9ff06f          	j	7e0c <input_update+0xe8>

00007e58 <reserve_shots>:
    7e58:	000057b7          	lui	a5,0x5
    7e5c:	00f507b3          	add	a5,a0,a5
    7e60:	0087a603          	lw	a2,8(a5) # 5008 <bullet_enemy_position+0x50>
    7e64:	00800713          	li	a4,8
    7e68:	00c76463          	bltu	a4,a2,7e70 <reserve_shots+0x18>
    7e6c:	00165713          	srli	a4,a2,0x1
    7e70:	40e60733          	sub	a4,a2,a4
    7e74:	01400793          	li	a5,20
    7e78:	02f707b3          	mul	a5,a4,a5
    7e7c:	00300593          	li	a1,3
    7e80:	01400813          	li	a6,20
    7e84:	fff00893          	li	a7,-1
    7e88:	00200313          	li	t1,2
    7e8c:	00f507b3          	add	a5,a0,a5
    7e90:	00c76463          	bltu	a4,a2,7e98 <reserve_shots+0x40>
    7e94:	00008067          	ret
    7e98:	00e7c683          	lbu	a3,14(a5)
    7e9c:	02b68663          	beq	a3,a1,7ec8 <reserve_shots+0x70>
    7ea0:	030706b3          	mul	a3,a4,a6
    7ea4:	00d506b3          	add	a3,a0,a3
    7ea8:	0006a023          	sw	zero,0(a3)
    7eac:	0006a223          	sw	zero,4(a3)
    7eb0:	0006a423          	sw	zero,8(a3)
    7eb4:	0006a623          	sw	zero,12(a3)
    7eb8:	0006a823          	sw	zero,16(a3)
    7ebc:	01179623          	sh	a7,12(a5)
    7ec0:	00b78723          	sb	a1,14(a5)
    7ec4:	006787a3          	sb	t1,15(a5)
    7ec8:	00170713          	addi	a4,a4,1
    7ecc:	01478793          	addi	a5,a5,20
    7ed0:	fc1ff06f          	j	7e90 <reserve_shots+0x38>

00007ed4 <game_reset>:
    7ed4:	ff010113          	addi	sp,sp,-16
    7ed8:	00812423          	sw	s0,8(sp)
    7edc:	00912223          	sw	s1,4(sp)
    7ee0:	00112623          	sw	ra,12(sp)
    7ee4:	00050493          	mv	s1,a0
    7ee8:	e2cfd0ef          	jal	5514 <bullet_reset_player>
    7eec:	00050413          	mv	s0,a0
    7ef0:	00051663          	bnez	a0,7efc <game_reset+0x28>
    7ef4:	00048513          	mv	a0,s1
    7ef8:	f61ff0ef          	jal	7e58 <reserve_shots>
    7efc:	00c12083          	lw	ra,12(sp)
    7f00:	00040513          	mv	a0,s0
    7f04:	00812403          	lw	s0,8(sp)
    7f08:	00412483          	lw	s1,4(sp)
    7f0c:	01010113          	addi	sp,sp,16
    7f10:	00008067          	ret

00007f14 <game_update_cached>:
    7f14:	20050863          	beqz	a0,8124 <game_update_cached+0x210>
    7f18:	ff010113          	addi	sp,sp,-16
    7f1c:	00912223          	sw	s1,4(sp)
    7f20:	00112623          	sw	ra,12(sp)
    7f24:	00812423          	sw	s0,8(sp)
    7f28:	00058493          	mv	s1,a1
    7f2c:	20058063          	beqz	a1,812c <game_update_cached+0x218>
    7f30:	000057b7          	lui	a5,0x5
    7f34:	00f507b3          	add	a5,a0,a5
    7f38:	0087a583          	lw	a1,8(a5) # 5008 <bullet_enemy_position+0x50>
    7f3c:	00060693          	mv	a3,a2
    7f40:	3ff00713          	li	a4,1023
    7f44:	fff58613          	addi	a2,a1,-1
    7f48:	00050413          	mv	s0,a0
    7f4c:	1ec76063          	bltu	a4,a2,812c <game_update_cached+0x218>
    7f50:	00c7a303          	lw	t1,12(a5)
    7f54:	3b000713          	li	a4,944
    7f58:	ff830613          	addi	a2,t1,-8
    7f5c:	1cc76863          	bltu	a4,a2,812c <game_update_cached+0x218>
    7f60:	0107a883          	lw	a7,16(a5)
    7f64:	1c400713          	li	a4,452
    7f68:	fb088613          	addi	a2,a7,-80
    7f6c:	1cc76063          	bltu	a4,a2,812c <game_update_cached+0x218>
    7f70:	0004d703          	lhu	a4,0(s1)
    7f74:	0024d603          	lhu	a2,2(s1)
    7f78:	0044de03          	lhu	t3,4(s1)
    7f7c:	00c76833          	or	a6,a4,a2
    7f80:	01c86833          	or	a6,a6,t3
    7f84:	0ff00e13          	li	t3,255
    7f88:	1b0e6263          	bltu	t3,a6,812c <game_update_cached+0x218>
    7f8c:	04067613          	andi	a2,a2,64
    7f90:	00060e63          	beqz	a2,7fac <game_update_cached+0x98>
    7f94:	00812403          	lw	s0,8(sp)
    7f98:	00c12083          	lw	ra,12(sp)
    7f9c:	00412483          	lw	s1,4(sp)
    7fa0:	0007a603          	lw	a2,0(a5)
    7fa4:	01010113          	addi	sp,sp,16
    7fa8:	f2dff06f          	j	7ed4 <game_reset>
    7fac:	00175793          	srli	a5,a4,0x1
    7fb0:	00177613          	andi	a2,a4,1
    7fb4:	0017f793          	andi	a5,a5,1
    7fb8:	00375513          	srli	a0,a4,0x3
    7fbc:	40c787b3          	sub	a5,a5,a2
    7fc0:	00275613          	srli	a2,a4,0x2
    7fc4:	00157513          	andi	a0,a0,1
    7fc8:	00167613          	andi	a2,a2,1
    7fcc:	02077593          	andi	a1,a4,32
    7fd0:	40c50533          	sub	a0,a0,a2
    7fd4:	00100713          	li	a4,1
    7fd8:	00059a63          	bnez	a1,7fec <game_update_cached+0xd8>
    7fdc:	00400713          	li	a4,4
    7fe0:	00078663          	beqz	a5,7fec <game_update_cached+0xd8>
    7fe4:	00153713          	seqz	a4,a0
    7fe8:	00370713          	addi	a4,a4,3
    7fec:	02f707b3          	mul	a5,a4,a5
    7ff0:	006785b3          	add	a1,a5,t1
    7ff4:	3b800793          	li	a5,952
    7ff8:	00b7d463          	bge	a5,a1,8000 <game_update_cached+0xec>
    7ffc:	3b800593          	li	a1,952
    8000:	00800793          	li	a5,8
    8004:	00f5d463          	bge	a1,a5,800c <game_update_cached+0xf8>
    8008:	00800593          	li	a1,8
    800c:	02a70733          	mul	a4,a4,a0
    8010:	21400793          	li	a5,532
    8014:	01170633          	add	a2,a4,a7
    8018:	00c7d463          	bge	a5,a2,8020 <game_update_cached+0x10c>
    801c:	21400613          	li	a2,532
    8020:	05000793          	li	a5,80
    8024:	00f65463          	bge	a2,a5,802c <game_update_cached+0x118>
    8028:	05000613          	li	a2,80
    802c:	00040513          	mv	a0,s0
    8030:	0e068263          	beqz	a3,8114 <game_update_cached+0x200>
    8034:	d3dfd0ef          	jal	5d70 <bullet_step_player_cached>
    8038:	0c051463          	bnez	a0,8100 <game_update_cached+0x1ec>
    803c:	00040513          	mv	a0,s0
    8040:	e19ff0ef          	jal	7e58 <reserve_shots>
    8044:	000057b7          	lui	a5,0x5
    8048:	00f407b3          	add	a5,s0,a5
    804c:	0247c703          	lbu	a4,36(a5) # 5024 <bullet_enemy_position+0x6c>
    8050:	0a070263          	beqz	a4,80f4 <game_update_cached+0x1e0>
    8054:	0297c703          	lbu	a4,41(a5)
    8058:	08071e63          	bnez	a4,80f4 <game_update_cached+0x1e0>
    805c:	0004d703          	lhu	a4,0(s1)
    8060:	01077713          	andi	a4,a4,16
    8064:	08070863          	beqz	a4,80f4 <game_update_cached+0x1e0>
    8068:	0147a703          	lw	a4,20(a5)
    806c:	00600693          	li	a3,6
    8070:	02d77733          	remu	a4,a4,a3
    8074:	00100693          	li	a3,1
    8078:	06d71e63          	bne	a4,a3,80f4 <game_update_cached+0x1e0>
    807c:	0087a683          	lw	a3,8(a5)
    8080:	00800713          	li	a4,8
    8084:	00d76463          	bltu	a4,a3,808c <game_update_cached+0x178>
    8088:	0016d713          	srli	a4,a3,0x1
    808c:	00010637          	lui	a2,0x10
    8090:	40e68733          	sub	a4,a3,a4
    8094:	01400593          	li	a1,20
    8098:	fff60613          	addi	a2,a2,-1 # ffff <__global_pointer$+0x1297>
    809c:	04d77c63          	bgeu	a4,a3,80f4 <game_update_cached+0x1e0>
    80a0:	02b707b3          	mul	a5,a4,a1
    80a4:	00f407b3          	add	a5,s0,a5
    80a8:	00c7d503          	lhu	a0,12(a5)
    80ac:	06c51863          	bne	a0,a2,811c <game_update_cached+0x208>
    80b0:	00005737          	lui	a4,0x5
    80b4:	00e40733          	add	a4,s0,a4
    80b8:	00c72683          	lw	a3,12(a4) # 500c <bullet_enemy_position+0x54>
    80bc:	01072703          	lw	a4,16(a4)
    80c0:	0007a423          	sw	zero,8(a5)
    80c4:	ffc68693          	addi	a3,a3,-4
    80c8:	ff070713          	addi	a4,a4,-16
    80cc:	00871713          	slli	a4,a4,0x8
    80d0:	00e7a223          	sw	a4,4(a5)
    80d4:	80000713          	li	a4,-2048
    80d8:	00869693          	slli	a3,a3,0x8
    80dc:	0007a623          	sw	zero,12(a5)
    80e0:	00e79523          	sh	a4,10(a5)
    80e4:	20300713          	li	a4,515
    80e8:	0007a823          	sw	zero,16(a5)
    80ec:	00d7a023          	sw	a3,0(a5)
    80f0:	00e79723          	sh	a4,14(a5)
    80f4:	0024d503          	lhu	a0,2(s1)
    80f8:	00755513          	srli	a0,a0,0x7
    80fc:	00157513          	andi	a0,a0,1
    8100:	00c12083          	lw	ra,12(sp)
    8104:	00812403          	lw	s0,8(sp)
    8108:	00412483          	lw	s1,4(sp)
    810c:	01010113          	addi	sp,sp,16
    8110:	00008067          	ret
    8114:	c49fd0ef          	jal	5d5c <bullet_step_player>
    8118:	f21ff06f          	j	8038 <game_update_cached+0x124>
    811c:	00170713          	addi	a4,a4,1
    8120:	f7dff06f          	j	809c <game_update_cached+0x188>
    8124:	ff800513          	li	a0,-8
    8128:	00008067          	ret
    812c:	ff800513          	li	a0,-8
    8130:	fd1ff06f          	j	8100 <game_update_cached+0x1ec>

00008134 <game_update>:
    8134:	00000613          	li	a2,0
    8138:	dddff06f          	j	7f14 <game_update_cached>

0000813c <game_build>:
    813c:	dc0fe06f          	j	66fc <bullet_build_frame_player>

00008140 <crc_word>:
    8140:	00052783          	lw	a5,0(a0)
    8144:	0000e6b7          	lui	a3,0xe
    8148:	00800713          	li	a4,8
    814c:	00f5c5b3          	xor	a1,a1,a5
    8150:	3ac68693          	addi	a3,a3,940 # e3ac <lut.0>
    8154:	00f5f793          	andi	a5,a1,15
    8158:	00279793          	slli	a5,a5,0x2
    815c:	00f687b3          	add	a5,a3,a5
    8160:	0007a783          	lw	a5,0(a5)
    8164:	0045d593          	srli	a1,a1,0x4
    8168:	fff70713          	addi	a4,a4,-1
    816c:	00f5c5b3          	xor	a1,a1,a5
    8170:	fe0712e3          	bnez	a4,8154 <crc_word+0x14>
    8174:	00b52023          	sw	a1,0(a0)
    8178:	00008067          	ret

0000817c <checksum>:
    817c:	fd010113          	addi	sp,sp,-48
    8180:	fff00793          	li	a5,-1
    8184:	02812423          	sw	s0,40(sp)
    8188:	02912223          	sw	s1,36(sp)
    818c:	00200593          	li	a1,2
    8190:	00050493          	mv	s1,a0
    8194:	00005437          	lui	s0,0x5
    8198:	00c10513          	addi	a0,sp,12
    819c:	02112623          	sw	ra,44(sp)
    81a0:	00f12623          	sw	a5,12(sp)
    81a4:	00848433          	add	s0,s1,s0
    81a8:	03212023          	sw	s2,32(sp)
    81ac:	01312e23          	sw	s3,28(sp)
    81b0:	01412c23          	sw	s4,24(sp)
    81b4:	f8dff0ef          	jal	8140 <crc_word>
    81b8:	4dc42583          	lw	a1,1244(s0) # 54dc <bullet_reset+0x7c>
    81bc:	00c10513          	addi	a0,sp,12
    81c0:	00000913          	li	s2,0
    81c4:	f7dff0ef          	jal	8140 <crc_word>
    81c8:	4e042583          	lw	a1,1248(s0)
    81cc:	00c10513          	addi	a0,sp,12
    81d0:	f71ff0ef          	jal	8140 <crc_word>
    81d4:	4e845983          	lhu	s3,1256(s0)
    81d8:	00c10513          	addi	a0,sp,12
    81dc:	00098593          	mv	a1,s3
    81e0:	f61ff0ef          	jal	8140 <crc_word>
    81e4:	00842a03          	lw	s4,8(s0)
    81e8:	00c10513          	addi	a0,sp,12
    81ec:	000a0593          	mv	a1,s4
    81f0:	f51ff0ef          	jal	8140 <crc_word>
    81f4:	00042583          	lw	a1,0(s0)
    81f8:	00c10513          	addi	a0,sp,12
    81fc:	f45ff0ef          	jal	8140 <crc_word>
    8200:	00442583          	lw	a1,4(s0)
    8204:	00c10513          	addi	a0,sp,12
    8208:	f39ff0ef          	jal	8140 <crc_word>
    820c:	01442583          	lw	a1,20(s0)
    8210:	00c10513          	addi	a0,sp,12
    8214:	f2dff0ef          	jal	8140 <crc_word>
    8218:	01842583          	lw	a1,24(s0)
    821c:	00c10513          	addi	a0,sp,12
    8220:	f21ff0ef          	jal	8140 <crc_word>
    8224:	01c42583          	lw	a1,28(s0)
    8228:	00c10513          	addi	a0,sp,12
    822c:	f15ff0ef          	jal	8140 <crc_word>
    8230:	00c42583          	lw	a1,12(s0)
    8234:	00c10513          	addi	a0,sp,12
    8238:	f09ff0ef          	jal	8140 <crc_word>
    823c:	01042583          	lw	a1,16(s0)
    8240:	00c10513          	addi	a0,sp,12
    8244:	efdff0ef          	jal	8140 <crc_word>
    8248:	02045583          	lhu	a1,32(s0)
    824c:	00c10513          	addi	a0,sp,12
    8250:	ef1ff0ef          	jal	8140 <crc_word>
    8254:	02245583          	lhu	a1,34(s0)
    8258:	00c10513          	addi	a0,sp,12
    825c:	ee5ff0ef          	jal	8140 <crc_word>
    8260:	02444583          	lbu	a1,36(s0)
    8264:	00c10513          	addi	a0,sp,12
    8268:	ed9ff0ef          	jal	8140 <crc_word>
    826c:	02844583          	lbu	a1,40(s0)
    8270:	00c10513          	addi	a0,sp,12
    8274:	ecdff0ef          	jal	8140 <crc_word>
    8278:	02944583          	lbu	a1,41(s0)
    827c:	00c10513          	addi	a0,sp,12
    8280:	ec1ff0ef          	jal	8140 <crc_word>
    8284:	02544583          	lbu	a1,37(s0)
    8288:	00c10513          	addi	a0,sp,12
    828c:	eb5ff0ef          	jal	8140 <crc_word>
    8290:	02644583          	lbu	a1,38(s0)
    8294:	00c10513          	addi	a0,sp,12
    8298:	ea9ff0ef          	jal	8140 <crc_word>
    829c:	02744583          	lbu	a1,39(s0)
    82a0:	00c10513          	addi	a0,sp,12
    82a4:	00048413          	mv	s0,s1
    82a8:	e99ff0ef          	jal	8140 <crc_word>
    82ac:	052a1063          	bne	s4,s2,82ec <checksum+0x170>
    82b0:	000057b7          	lui	a5,0x5
    82b4:	02c78793          	addi	a5,a5,44 # 502c <bullet_enemy_position+0x74>
    82b8:	00f484b3          	add	s1,s1,a5
    82bc:	00000413          	li	s0,0
    82c0:	0b346263          	bltu	s0,s3,8364 <checksum+0x1e8>
    82c4:	00c12503          	lw	a0,12(sp)
    82c8:	02c12083          	lw	ra,44(sp)
    82cc:	02812403          	lw	s0,40(sp)
    82d0:	02412483          	lw	s1,36(sp)
    82d4:	02012903          	lw	s2,32(sp)
    82d8:	01c12983          	lw	s3,28(sp)
    82dc:	01812a03          	lw	s4,24(sp)
    82e0:	fff54513          	not	a0,a0
    82e4:	03010113          	addi	sp,sp,48
    82e8:	00008067          	ret
    82ec:	00042583          	lw	a1,0(s0)
    82f0:	00c10513          	addi	a0,sp,12
    82f4:	00190913          	addi	s2,s2,1
    82f8:	e49ff0ef          	jal	8140 <crc_word>
    82fc:	00442583          	lw	a1,4(s0)
    8300:	00c10513          	addi	a0,sp,12
    8304:	01440413          	addi	s0,s0,20
    8308:	e39ff0ef          	jal	8140 <crc_word>
    830c:	ff441583          	lh	a1,-12(s0)
    8310:	00c10513          	addi	a0,sp,12
    8314:	e2dff0ef          	jal	8140 <crc_word>
    8318:	ff641583          	lh	a1,-10(s0)
    831c:	00c10513          	addi	a0,sp,12
    8320:	e21ff0ef          	jal	8140 <crc_word>
    8324:	ff845583          	lhu	a1,-8(s0)
    8328:	00c10513          	addi	a0,sp,12
    832c:	e15ff0ef          	jal	8140 <crc_word>
    8330:	ffa44583          	lbu	a1,-6(s0)
    8334:	00c10513          	addi	a0,sp,12
    8338:	e09ff0ef          	jal	8140 <crc_word>
    833c:	ffb44583          	lbu	a1,-5(s0)
    8340:	00c10513          	addi	a0,sp,12
    8344:	dfdff0ef          	jal	8140 <crc_word>
    8348:	ffc44583          	lbu	a1,-4(s0)
    834c:	00c10513          	addi	a0,sp,12
    8350:	df1ff0ef          	jal	8140 <crc_word>
    8354:	ffd44583          	lbu	a1,-3(s0)
    8358:	00c10513          	addi	a0,sp,12
    835c:	de5ff0ef          	jal	8140 <crc_word>
    8360:	f4dff06f          	j	82ac <checksum+0x130>
    8364:	0004d583          	lhu	a1,0(s1)
    8368:	00c10513          	addi	a0,sp,12
    836c:	00140413          	addi	s0,s0,1
    8370:	dd1ff0ef          	jal	8140 <crc_word>
    8374:	00248493          	addi	s1,s1,2
    8378:	f49ff06f          	j	82c0 <checksum+0x144>

0000837c <initial_valid>:
    837c:	02051263          	bnez	a0,83a0 <initial_valid+0x24>
    8380:	00000513          	li	a0,0
    8384:	00008067          	ret
    8388:	00000513          	li	a0,0
    838c:	00c12083          	lw	ra,12(sp)
    8390:	00812403          	lw	s0,8(sp)
    8394:	00412483          	lw	s1,4(sp)
    8398:	01010113          	addi	sp,sp,16
    839c:	00008067          	ret
    83a0:	ff010113          	addi	sp,sp,-16
    83a4:	00912223          	sw	s1,4(sp)
    83a8:	000054b7          	lui	s1,0x5
    83ac:	009504b3          	add	s1,a0,s1
    83b0:	0084a783          	lw	a5,8(s1) # 5008 <bullet_enemy_position+0x50>
    83b4:	00812423          	sw	s0,8(sp)
    83b8:	00112623          	sw	ra,12(sp)
    83bc:	fff78793          	addi	a5,a5,-1
    83c0:	3ff00713          	li	a4,1023
    83c4:	00050413          	mv	s0,a0
    83c8:	fcf760e3          	bltu	a4,a5,8388 <initial_valid+0xc>
    83cc:	0244c703          	lbu	a4,36(s1)
    83d0:	00300793          	li	a5,3
    83d4:	fae7eae3          	bltu	a5,a4,8388 <initial_valid+0xc>
    83d8:	b65fc0ef          	jal	4f3c <bullet_campaign_valid>
    83dc:	fa0506e3          	beqz	a0,8388 <initial_valid+0xc>
    83e0:	00c4a783          	lw	a5,12(s1)
    83e4:	3b000713          	li	a4,944
    83e8:	ff878793          	addi	a5,a5,-8
    83ec:	f8f76ee3          	bltu	a4,a5,8388 <initial_valid+0xc>
    83f0:	0104a783          	lw	a5,16(s1)
    83f4:	1c400713          	li	a4,452
    83f8:	fb078793          	addi	a5,a5,-80
    83fc:	f8f766e3          	bltu	a4,a5,8388 <initial_valid+0xc>
    8400:	0204d703          	lhu	a4,32(s1)
    8404:	03c00793          	li	a5,60
    8408:	f8e7e0e3          	bltu	a5,a4,8388 <initial_valid+0xc>
    840c:	0244c783          	lbu	a5,36(s1)
    8410:	00079e63          	bnez	a5,842c <initial_valid+0xb0>
    8414:	0224d783          	lhu	a5,34(s1)
    8418:	07700713          	li	a4,119
    841c:	fff78793          	addi	a5,a5,-1
    8420:	01079793          	slli	a5,a5,0x10
    8424:	0107d793          	srli	a5,a5,0x10
    8428:	f6f760e3          	bltu	a4,a5,8388 <initial_valid+0xc>
    842c:	000057b7          	lui	a5,0x5
    8430:	00f407b3          	add	a5,s0,a5
    8434:	0087a603          	lw	a2,8(a5) # 5008 <bullet_enemy_position+0x50>
    8438:	00e40513          	addi	a0,s0,14
    843c:	00000713          	li	a4,0
    8440:	00300593          	li	a1,3
    8444:	00500693          	li	a3,5
    8448:	00e61663          	bne	a2,a4,8454 <initial_valid+0xd8>
    844c:	00100513          	li	a0,1
    8450:	f3dff06f          	j	838c <initial_valid+0x10>
    8454:	00054803          	lbu	a6,0(a0)
    8458:	f305e8e3          	bltu	a1,a6,8388 <initial_valid+0xc>
    845c:	00154803          	lbu	a6,1(a0)
    8460:	f306e4e3          	bltu	a3,a6,8388 <initial_valid+0xc>
    8464:	0287c803          	lbu	a6,40(a5)
    8468:	00080663          	beqz	a6,8474 <initial_valid+0xf8>
    846c:	00354803          	lbu	a6,3(a0)
    8470:	f106ece3          	bltu	a3,a6,8388 <initial_valid+0xc>
    8474:	00170713          	addi	a4,a4,1
    8478:	01450513          	addi	a0,a0,20
    847c:	fcdff06f          	j	8448 <initial_valid+0xcc>

00008480 <replay_init>:
    8480:	02051663          	bnez	a0,84ac <replay_init+0x2c>
    8484:	ff800513          	li	a0,-8
    8488:	00008067          	ret
    848c:	ff800513          	li	a0,-8
    8490:	01c12083          	lw	ra,28(sp)
    8494:	01812403          	lw	s0,24(sp)
    8498:	01412483          	lw	s1,20(sp)
    849c:	01012903          	lw	s2,16(sp)
    84a0:	00c12983          	lw	s3,12(sp)
    84a4:	02010113          	addi	sp,sp,32
    84a8:	00008067          	ret
    84ac:	fe010113          	addi	sp,sp,-32
    84b0:	00812c23          	sw	s0,24(sp)
    84b4:	00050413          	mv	s0,a0
    84b8:	00058513          	mv	a0,a1
    84bc:	00912a23          	sw	s1,20(sp)
    84c0:	01212823          	sw	s2,16(sp)
    84c4:	00112e23          	sw	ra,28(sp)
    84c8:	01312623          	sw	s3,12(sp)
    84cc:	00058493          	mv	s1,a1
    84d0:	00060913          	mv	s2,a2
    84d4:	ea9ff0ef          	jal	837c <initial_valid>
    84d8:	fa050ae3          	beqz	a0,848c <replay_init+0xc>
    84dc:	fa0908e3          	beqz	s2,848c <replay_init+0xc>
    84e0:	fa9406e3          	beq	s0,s1,848c <replay_init+0xc>
    84e4:	00005637          	lui	a2,0x5
    84e8:	4ec60613          	addi	a2,a2,1260 # 54ec <bullet_reset+0x8c>
    84ec:	00000593          	li	a1,0
    84f0:	00040513          	mv	a0,s0
    84f4:	d35f80ef          	jal	1228 <memset>
    84f8:	00005637          	lui	a2,0x5
    84fc:	000059b7          	lui	s3,0x5
    8500:	00048593          	mv	a1,s1
    8504:	00040513          	mv	a0,s0
    8508:	02c60613          	addi	a2,a2,44 # 502c <bullet_enemy_position+0x74>
    850c:	df9f80ef          	jal	1304 <memcpy>
    8510:	013484b3          	add	s1,s1,s3
    8514:	0004a783          	lw	a5,0(s1)
    8518:	01340433          	add	s0,s0,s3
    851c:	4f242023          	sw	s2,1248(s0)
    8520:	4cf42e23          	sw	a5,1244(s0)
    8524:	00000513          	li	a0,0
    8528:	f69ff06f          	j	8490 <replay_init+0x10>

0000852c <replay_record>:
    852c:	00050793          	mv	a5,a0
    8530:	ff800513          	li	a0,-8
    8534:	06078c63          	beqz	a5,85ac <replay_record+0x80>
    8538:	06058a63          	beqz	a1,85ac <replay_record+0x80>
    853c:	00005637          	lui	a2,0x5
    8540:	00c78633          	add	a2,a5,a2
    8544:	4ea64703          	lbu	a4,1258(a2) # 54ea <bullet_reset+0x8a>
    8548:	06071263          	bnez	a4,85ac <replay_record+0x80>
    854c:	0005d683          	lhu	a3,0(a1)
    8550:	0025d803          	lhu	a6,2(a1)
    8554:	0045d583          	lhu	a1,4(a1)
    8558:	0106e733          	or	a4,a3,a6
    855c:	00b76733          	or	a4,a4,a1
    8560:	0ff00593          	li	a1,255
    8564:	04e5e463          	bltu	a1,a4,85ac <replay_record+0x80>
    8568:	4e865703          	lhu	a4,1256(a2)
    856c:	25700593          	li	a1,599
    8570:	ffc00513          	li	a0,-4
    8574:	02e5ec63          	bltu	a1,a4,85ac <replay_record+0x80>
    8578:	00170593          	addi	a1,a4,1
    857c:	4eb61423          	sh	a1,1256(a2)
    8580:	00003637          	lui	a2,0x3
    8584:	81060613          	addi	a2,a2,-2032 # 2810 <golden_fill+0x14>
    8588:	00c70733          	add	a4,a4,a2
    858c:	00171713          	slli	a4,a4,0x1
    8590:	0c087813          	andi	a6,a6,192
    8594:	f3f6f693          	andi	a3,a3,-193
    8598:	00e787b3          	add	a5,a5,a4
    859c:	0106e6b3          	or	a3,a3,a6
    85a0:	00d79623          	sh	a3,12(a5)
    85a4:	00000513          	li	a0,0
    85a8:	00008067          	ret
    85ac:	00008067          	ret

000085b0 <replay_seal>:
    85b0:	02051263          	bnez	a0,85d4 <replay_seal+0x24>
    85b4:	ff800513          	li	a0,-8
    85b8:	00008067          	ret
    85bc:	ff800513          	li	a0,-8
    85c0:	00c12083          	lw	ra,12(sp)
    85c4:	00812403          	lw	s0,8(sp)
    85c8:	00412483          	lw	s1,4(sp)
    85cc:	01010113          	addi	sp,sp,16
    85d0:	00008067          	ret
    85d4:	ff010113          	addi	sp,sp,-16
    85d8:	00812423          	sw	s0,8(sp)
    85dc:	00005437          	lui	s0,0x5
    85e0:	00912223          	sw	s1,4(sp)
    85e4:	00112623          	sw	ra,12(sp)
    85e8:	00850433          	add	s0,a0,s0
    85ec:	4e842783          	lw	a5,1256(s0) # 54e8 <bullet_reset+0x88>
    85f0:	25800713          	li	a4,600
    85f4:	00050493          	mv	s1,a0
    85f8:	00879793          	slli	a5,a5,0x8
    85fc:	0087d793          	srli	a5,a5,0x8
    8600:	fae79ee3          	bne	a5,a4,85bc <replay_seal+0xc>
    8604:	d79ff0ef          	jal	837c <initial_valid>
    8608:	fa050ae3          	beqz	a0,85bc <replay_seal+0xc>
    860c:	4e042783          	lw	a5,1248(s0)
    8610:	fa0786e3          	beqz	a5,85bc <replay_seal+0xc>
    8614:	4dc42703          	lw	a4,1244(s0)
    8618:	00042783          	lw	a5,0(s0)
    861c:	faf710e3          	bne	a4,a5,85bc <replay_seal+0xc>
    8620:	00048513          	mv	a0,s1
    8624:	b59ff0ef          	jal	817c <checksum>
    8628:	00100793          	li	a5,1
    862c:	4ea42223          	sw	a0,1252(s0)
    8630:	4ef40523          	sb	a5,1258(s0)
    8634:	00000513          	li	a0,0
    8638:	f89ff06f          	j	85c0 <replay_seal+0x10>

0000863c <replay_seal_step>:
    863c:	02051a63          	bnez	a0,8670 <replay_seal_step+0x34>
    8640:	ff800513          	li	a0,-8
    8644:	00008067          	ret
    8648:	ff800513          	li	a0,-8
    864c:	01c12083          	lw	ra,28(sp)
    8650:	01812403          	lw	s0,24(sp)
    8654:	01412483          	lw	s1,20(sp)
    8658:	01012903          	lw	s2,16(sp)
    865c:	00c12983          	lw	s3,12(sp)
    8660:	00812a03          	lw	s4,8(sp)
    8664:	00412a83          	lw	s5,4(sp)
    8668:	02010113          	addi	sp,sp,32
    866c:	00008067          	ret
    8670:	fe010113          	addi	sp,sp,-32
    8674:	01212823          	sw	s2,16(sp)
    8678:	00112e23          	sw	ra,28(sp)
    867c:	00812c23          	sw	s0,24(sp)
    8680:	00912a23          	sw	s1,20(sp)
    8684:	01312623          	sw	s3,12(sp)
    8688:	01412423          	sw	s4,8(sp)
    868c:	01512223          	sw	s5,4(sp)
    8690:	00058913          	mv	s2,a1
    8694:	fa058ae3          	beqz	a1,8648 <replay_seal_step+0xc>
    8698:	fff60793          	addi	a5,a2,-1
    869c:	0ff00713          	li	a4,255
    86a0:	00060993          	mv	s3,a2
    86a4:	faf762e3          	bltu	a4,a5,8648 <replay_seal_step+0xc>
    86a8:	000057b7          	lui	a5,0x5
    86ac:	00f507b3          	add	a5,a0,a5
    86b0:	4e87a703          	lw	a4,1256(a5) # 54e8 <bullet_reset+0x88>
    86b4:	25800693          	li	a3,600
    86b8:	00050413          	mv	s0,a0
    86bc:	00871713          	slli	a4,a4,0x8
    86c0:	00875713          	srli	a4,a4,0x8
    86c4:	f8d712e3          	bne	a4,a3,8648 <replay_seal_step+0xc>
    86c8:	0087a483          	lw	s1,8(a5)
    86cc:	3ff00713          	li	a4,1023
    86d0:	fff48693          	addi	a3,s1,-1
    86d4:	f6d76ae3          	bltu	a4,a3,8648 <replay_seal_step+0xc>
    86d8:	4e07a703          	lw	a4,1248(a5)
    86dc:	f60706e3          	beqz	a4,8648 <replay_seal_step+0xc>
    86e0:	4dc7a683          	lw	a3,1244(a5)
    86e4:	0007a703          	lw	a4,0(a5)
    86e8:	f6e690e3          	bne	a3,a4,8648 <replay_seal_step+0xc>
    86ec:	00900713          	li	a4,9
    86f0:	02e484b3          	mul	s1,s1,a4
    86f4:	4e87d783          	lhu	a5,1256(a5)
    86f8:	00f484b3          	add	s1,s1,a5
    86fc:	0045a783          	lw	a5,4(a1)
    8700:	01448493          	addi	s1,s1,20
    8704:	f497f2e3          	bgeu	a5,s1,8648 <replay_seal_step+0xc>
    8708:	00079a63          	bnez	a5,871c <replay_seal_step+0xe0>
    870c:	c71ff0ef          	jal	837c <initial_valid>
    8710:	f2050ce3          	beqz	a0,8648 <replay_seal_step+0xc>
    8714:	fff00793          	li	a5,-1
    8718:	00f92023          	sw	a5,0(s2)
    871c:	00492783          	lw	a5,4(s2)
    8720:	00048a13          	mv	s4,s1
    8724:	40f48733          	sub	a4,s1,a5
    8728:	01376463          	bltu	a4,s3,8730 <replay_seal_step+0xf4>
    872c:	01378a33          	add	s4,a5,s3
    8730:	0000e9b7          	lui	s3,0xe
    8734:	01300a93          	li	s5,19
    8738:	33c98993          	addi	s3,s3,828 # e33c <colors.2+0xc>
    873c:	00492783          	lw	a5,4(s2)
    8740:	0347ee63          	bltu	a5,s4,877c <replay_seal_step+0x140>
    8744:	00000513          	li	a0,0
    8748:	f097e2e3          	bltu	a5,s1,864c <replay_seal_step+0x10>
    874c:	00040513          	mv	a0,s0
    8750:	c2dff0ef          	jal	837c <initial_valid>
    8754:	ee050ae3          	beqz	a0,8648 <replay_seal_step+0xc>
    8758:	000057b7          	lui	a5,0x5
    875c:	00f40433          	add	s0,s0,a5
    8760:	00092783          	lw	a5,0(s2)
    8764:	00100513          	li	a0,1
    8768:	fff7c793          	not	a5,a5
    876c:	4ef42223          	sw	a5,1252(s0)
    8770:	00100793          	li	a5,1
    8774:	4ef40523          	sb	a5,1258(s0)
    8778:	ed5ff06f          	j	864c <replay_seal_step+0x10>
    877c:	00178713          	addi	a4,a5,1 # 5001 <bullet_enemy_position+0x49>
    8780:	00e92223          	sw	a4,4(s2)
    8784:	14fae663          	bltu	s5,a5,88d0 <replay_seal_step+0x294>
    8788:	00279793          	slli	a5,a5,0x2
    878c:	013787b3          	add	a5,a5,s3
    8790:	0007a783          	lw	a5,0(a5)
    8794:	00078067          	jr	a5
    8798:	000057b7          	lui	a5,0x5
    879c:	00f407b3          	add	a5,s0,a5
    87a0:	4dc7a583          	lw	a1,1244(a5) # 54dc <bullet_reset+0x7c>
    87a4:	00090513          	mv	a0,s2
    87a8:	999ff0ef          	jal	8140 <crc_word>
    87ac:	f91ff06f          	j	873c <replay_seal_step+0x100>
    87b0:	000057b7          	lui	a5,0x5
    87b4:	00f407b3          	add	a5,s0,a5
    87b8:	4e07a583          	lw	a1,1248(a5) # 54e0 <bullet_reset+0x80>
    87bc:	fe9ff06f          	j	87a4 <replay_seal_step+0x168>
    87c0:	000057b7          	lui	a5,0x5
    87c4:	00f407b3          	add	a5,s0,a5
    87c8:	4e87d583          	lhu	a1,1256(a5) # 54e8 <bullet_reset+0x88>
    87cc:	fd9ff06f          	j	87a4 <replay_seal_step+0x168>
    87d0:	000057b7          	lui	a5,0x5
    87d4:	00f407b3          	add	a5,s0,a5
    87d8:	0087a583          	lw	a1,8(a5) # 5008 <bullet_enemy_position+0x50>
    87dc:	fc9ff06f          	j	87a4 <replay_seal_step+0x168>
    87e0:	000057b7          	lui	a5,0x5
    87e4:	00f407b3          	add	a5,s0,a5
    87e8:	0007a583          	lw	a1,0(a5) # 5000 <bullet_enemy_position+0x48>
    87ec:	fb9ff06f          	j	87a4 <replay_seal_step+0x168>
    87f0:	000057b7          	lui	a5,0x5
    87f4:	00f407b3          	add	a5,s0,a5
    87f8:	0047a583          	lw	a1,4(a5) # 5004 <bullet_enemy_position+0x4c>
    87fc:	fa9ff06f          	j	87a4 <replay_seal_step+0x168>
    8800:	000057b7          	lui	a5,0x5
    8804:	00f407b3          	add	a5,s0,a5
    8808:	0147a583          	lw	a1,20(a5) # 5014 <bullet_enemy_position+0x5c>
    880c:	f99ff06f          	j	87a4 <replay_seal_step+0x168>
    8810:	000057b7          	lui	a5,0x5
    8814:	00f407b3          	add	a5,s0,a5
    8818:	0187a583          	lw	a1,24(a5) # 5018 <bullet_enemy_position+0x60>
    881c:	f89ff06f          	j	87a4 <replay_seal_step+0x168>
    8820:	000057b7          	lui	a5,0x5
    8824:	00f407b3          	add	a5,s0,a5
    8828:	01c7a583          	lw	a1,28(a5) # 501c <bullet_enemy_position+0x64>
    882c:	f79ff06f          	j	87a4 <replay_seal_step+0x168>
    8830:	000057b7          	lui	a5,0x5
    8834:	00f407b3          	add	a5,s0,a5
    8838:	00c7a583          	lw	a1,12(a5) # 500c <bullet_enemy_position+0x54>
    883c:	f69ff06f          	j	87a4 <replay_seal_step+0x168>
    8840:	000057b7          	lui	a5,0x5
    8844:	00f407b3          	add	a5,s0,a5
    8848:	0107a583          	lw	a1,16(a5) # 5010 <bullet_enemy_position+0x58>
    884c:	f59ff06f          	j	87a4 <replay_seal_step+0x168>
    8850:	000057b7          	lui	a5,0x5
    8854:	00f407b3          	add	a5,s0,a5
    8858:	0207d583          	lhu	a1,32(a5) # 5020 <bullet_enemy_position+0x68>
    885c:	f49ff06f          	j	87a4 <replay_seal_step+0x168>
    8860:	000057b7          	lui	a5,0x5
    8864:	00f407b3          	add	a5,s0,a5
    8868:	0227d583          	lhu	a1,34(a5) # 5022 <bullet_enemy_position+0x6a>
    886c:	f39ff06f          	j	87a4 <replay_seal_step+0x168>
    8870:	000057b7          	lui	a5,0x5
    8874:	00f407b3          	add	a5,s0,a5
    8878:	0247c583          	lbu	a1,36(a5) # 5024 <bullet_enemy_position+0x6c>
    887c:	f29ff06f          	j	87a4 <replay_seal_step+0x168>
    8880:	000057b7          	lui	a5,0x5
    8884:	00f407b3          	add	a5,s0,a5
    8888:	0287c583          	lbu	a1,40(a5) # 5028 <bullet_enemy_position+0x70>
    888c:	f19ff06f          	j	87a4 <replay_seal_step+0x168>
    8890:	000057b7          	lui	a5,0x5
    8894:	00f407b3          	add	a5,s0,a5
    8898:	0297c583          	lbu	a1,41(a5) # 5029 <bullet_enemy_position+0x71>
    889c:	f09ff06f          	j	87a4 <replay_seal_step+0x168>
    88a0:	000057b7          	lui	a5,0x5
    88a4:	00f407b3          	add	a5,s0,a5
    88a8:	0257c583          	lbu	a1,37(a5) # 5025 <bullet_enemy_position+0x6d>
    88ac:	ef9ff06f          	j	87a4 <replay_seal_step+0x168>
    88b0:	000057b7          	lui	a5,0x5
    88b4:	00f407b3          	add	a5,s0,a5
    88b8:	0267c583          	lbu	a1,38(a5) # 5026 <bullet_enemy_position+0x6e>
    88bc:	ee9ff06f          	j	87a4 <replay_seal_step+0x168>
    88c0:	000057b7          	lui	a5,0x5
    88c4:	00f407b3          	add	a5,s0,a5
    88c8:	0277c583          	lbu	a1,39(a5) # 5027 <bullet_enemy_position+0x6f>
    88cc:	ed9ff06f          	j	87a4 <replay_seal_step+0x168>
    88d0:	00005737          	lui	a4,0x5
    88d4:	00e40733          	add	a4,s0,a4
    88d8:	00872703          	lw	a4,8(a4) # 5008 <bullet_enemy_position+0x50>
    88dc:	00900693          	li	a3,9
    88e0:	fec78793          	addi	a5,a5,-20
    88e4:	02e68733          	mul	a4,a3,a4
    88e8:	02e7e263          	bltu	a5,a4,890c <replay_seal_step+0x2d0>
    88ec:	40e787b3          	sub	a5,a5,a4
    88f0:	00003737          	lui	a4,0x3
    88f4:	81070713          	addi	a4,a4,-2032 # 2810 <golden_fill+0x14>
    88f8:	00e787b3          	add	a5,a5,a4
    88fc:	00179793          	slli	a5,a5,0x1
    8900:	00f407b3          	add	a5,s0,a5
    8904:	00c7d583          	lhu	a1,12(a5)
    8908:	e9dff06f          	j	87a4 <replay_seal_step+0x168>
    890c:	02d7d733          	divu	a4,a5,a3
    8910:	01400613          	li	a2,20
    8914:	02d7f7b3          	remu	a5,a5,a3
    8918:	00700693          	li	a3,7
    891c:	02c70733          	mul	a4,a4,a2
    8920:	00e40733          	add	a4,s0,a4
    8924:	04f6ee63          	bltu	a3,a5,8980 <replay_seal_step+0x344>
    8928:	0000e6b7          	lui	a3,0xe
    892c:	00279793          	slli	a5,a5,0x2
    8930:	38c68693          	addi	a3,a3,908 # e38c <colors.2+0x5c>
    8934:	00d787b3          	add	a5,a5,a3
    8938:	0007a783          	lw	a5,0(a5)
    893c:	00078067          	jr	a5
    8940:	00072583          	lw	a1,0(a4)
    8944:	e61ff06f          	j	87a4 <replay_seal_step+0x168>
    8948:	00472583          	lw	a1,4(a4)
    894c:	e59ff06f          	j	87a4 <replay_seal_step+0x168>
    8950:	00871583          	lh	a1,8(a4)
    8954:	e51ff06f          	j	87a4 <replay_seal_step+0x168>
    8958:	00a71583          	lh	a1,10(a4)
    895c:	e49ff06f          	j	87a4 <replay_seal_step+0x168>
    8960:	00c75583          	lhu	a1,12(a4)
    8964:	e41ff06f          	j	87a4 <replay_seal_step+0x168>
    8968:	00e74583          	lbu	a1,14(a4)
    896c:	e39ff06f          	j	87a4 <replay_seal_step+0x168>
    8970:	00f74583          	lbu	a1,15(a4)
    8974:	e31ff06f          	j	87a4 <replay_seal_step+0x168>
    8978:	01074583          	lbu	a1,16(a4)
    897c:	e29ff06f          	j	87a4 <replay_seal_step+0x168>
    8980:	01174583          	lbu	a1,17(a4)
    8984:	e21ff06f          	j	87a4 <replay_seal_step+0x168>
    8988:	00200593          	li	a1,2
    898c:	e19ff06f          	j	87a4 <replay_seal_step+0x168>

00008990 <replay_begin>:
    8990:	02051663          	bnez	a0,89bc <replay_begin+0x2c>
    8994:	ff800513          	li	a0,-8
    8998:	00008067          	ret
    899c:	ff800513          	li	a0,-8
    89a0:	01c12083          	lw	ra,28(sp)
    89a4:	01812403          	lw	s0,24(sp)
    89a8:	01412483          	lw	s1,20(sp)
    89ac:	01012903          	lw	s2,16(sp)
    89b0:	00c12983          	lw	s3,12(sp)
    89b4:	02010113          	addi	sp,sp,32
    89b8:	00008067          	ret
    89bc:	fe010113          	addi	sp,sp,-32
    89c0:	01312623          	sw	s3,12(sp)
    89c4:	00112e23          	sw	ra,28(sp)
    89c8:	00812c23          	sw	s0,24(sp)
    89cc:	00912a23          	sw	s1,20(sp)
    89d0:	01212823          	sw	s2,16(sp)
    89d4:	00060993          	mv	s3,a2
    89d8:	fc0602e3          	beqz	a2,899c <replay_begin+0xc>
    89dc:	00068493          	mv	s1,a3
    89e0:	fa068ee3          	beqz	a3,899c <replay_begin+0xc>
    89e4:	00005437          	lui	s0,0x5
    89e8:	00850433          	add	s0,a0,s0
    89ec:	4ea44783          	lbu	a5,1258(s0) # 54ea <bullet_reset+0x8a>
    89f0:	00050913          	mv	s2,a0
    89f4:	fa0784e3          	beqz	a5,899c <replay_begin+0xc>
    89f8:	4e845703          	lhu	a4,1256(s0)
    89fc:	25800793          	li	a5,600
    8a00:	f8f71ee3          	bne	a4,a5,899c <replay_begin+0xc>
    8a04:	4e042783          	lw	a5,1248(s0)
    8a08:	f8b79ae3          	bne	a5,a1,899c <replay_begin+0xc>
    8a0c:	f80788e3          	beqz	a5,899c <replay_begin+0xc>
    8a10:	96dff0ef          	jal	837c <initial_valid>
    8a14:	f80504e3          	beqz	a0,899c <replay_begin+0xc>
    8a18:	4dc42703          	lw	a4,1244(s0)
    8a1c:	00042783          	lw	a5,0(s0)
    8a20:	f6f71ee3          	bne	a4,a5,899c <replay_begin+0xc>
    8a24:	4e442403          	lw	s0,1252(s0)
    8a28:	00090513          	mv	a0,s2
    8a2c:	f50ff0ef          	jal	817c <checksum>
    8a30:	f6a416e3          	bne	s0,a0,899c <replay_begin+0xc>
    8a34:	00005637          	lui	a2,0x5
    8a38:	02c60613          	addi	a2,a2,44 # 502c <bullet_enemy_position+0x74>
    8a3c:	00090593          	mv	a1,s2
    8a40:	00098513          	mv	a0,s3
    8a44:	8c1f80ef          	jal	1304 <memcpy>
    8a48:	00100793          	li	a5,1
    8a4c:	00049223          	sh	zero,4(s1)
    8a50:	00049023          	sh	zero,0(s1)
    8a54:	00049123          	sh	zero,2(s1)
    8a58:	00f48223          	sb	a5,4(s1)
    8a5c:	00000513          	li	a0,0
    8a60:	f41ff06f          	j	89a0 <replay_begin+0x10>

00008a64 <replay_next>:
    8a64:	10050c63          	beqz	a0,8b7c <replay_next+0x118>
    8a68:	fe010113          	addi	sp,sp,-32
    8a6c:	00812c23          	sw	s0,24(sp)
    8a70:	00112e23          	sw	ra,28(sp)
    8a74:	00912a23          	sw	s1,20(sp)
    8a78:	01212823          	sw	s2,16(sp)
    8a7c:	01312623          	sw	s3,12(sp)
    8a80:	01412423          	sw	s4,8(sp)
    8a84:	00050713          	mv	a4,a0
    8a88:	00058413          	mv	s0,a1
    8a8c:	ff800513          	li	a0,-8
    8a90:	04058863          	beqz	a1,8ae0 <replay_next+0x7c>
    8a94:	00060793          	mv	a5,a2
    8a98:	04060463          	beqz	a2,8ae0 <replay_next+0x7c>
    8a9c:	000056b7          	lui	a3,0x5
    8aa0:	00d706b3          	add	a3,a4,a3
    8aa4:	4ea6c603          	lbu	a2,1258(a3) # 54ea <bullet_reset+0x8a>
    8aa8:	02060c63          	beqz	a2,8ae0 <replay_next+0x7c>
    8aac:	4e86d683          	lhu	a3,1256(a3)
    8ab0:	25800613          	li	a2,600
    8ab4:	02c69663          	bne	a3,a2,8ae0 <replay_next+0x7c>
    8ab8:	0045c603          	lbu	a2,4(a1)
    8abc:	02060263          	beqz	a2,8ae0 <replay_next+0x7c>
    8ac0:	0005d483          	lhu	s1,0(a1)
    8ac4:	0096ee63          	bltu	a3,s1,8ae0 <replay_next+0x7c>
    8ac8:	02d49c63          	bne	s1,a3,8b00 <replay_next+0x9c>
    8acc:	01800613          	li	a2,24
    8ad0:	00000593          	li	a1,0
    8ad4:	00078513          	mv	a0,a5
    8ad8:	f50f80ef          	jal	1228 <memset>
    8adc:	00000513          	li	a0,0
    8ae0:	01c12083          	lw	ra,28(sp)
    8ae4:	01812403          	lw	s0,24(sp)
    8ae8:	01412483          	lw	s1,20(sp)
    8aec:	01012903          	lw	s2,16(sp)
    8af0:	00c12983          	lw	s3,12(sp)
    8af4:	00812a03          	lw	s4,8(sp)
    8af8:	02010113          	addi	sp,sp,32
    8afc:	00008067          	ret
    8b00:	000036b7          	lui	a3,0x3
    8b04:	81068693          	addi	a3,a3,-2032 # 2810 <golden_fill+0x14>
    8b08:	00d486b3          	add	a3,s1,a3
    8b0c:	00169693          	slli	a3,a3,0x1
    8b10:	00d70733          	add	a4,a4,a3
    8b14:	00c75903          	lhu	s2,12(a4)
    8b18:	0ff00713          	li	a4,255
    8b1c:	ff800513          	li	a0,-8
    8b20:	fd2760e3          	bltu	a4,s2,8ae0 <replay_next+0x7c>
    8b24:	0025d983          	lhu	s3,2(a1)
    8b28:	01800613          	li	a2,24
    8b2c:	00000593          	li	a1,0
    8b30:	00078513          	mv	a0,a5
    8b34:	ef4f80ef          	jal	1228 <memset>
    8b38:	01091a13          	slli	s4,s2,0x10
    8b3c:	410a5a13          	srai	s4,s4,0x10
    8b40:	fff9c713          	not	a4,s3
    8b44:	00ea7733          	and	a4,s4,a4
    8b48:	f3f77713          	andi	a4,a4,-193
    8b4c:	0c097693          	andi	a3,s2,192
    8b50:	fffa4a13          	not	s4,s4
    8b54:	00d76733          	or	a4,a4,a3
    8b58:	0149f9b3          	and	s3,s3,s4
    8b5c:	01251023          	sh	s2,0(a0)
    8b60:	00e51123          	sh	a4,2(a0)
    8b64:	01351223          	sh	s3,4(a0)
    8b68:	00148493          	addi	s1,s1,1
    8b6c:	01241123          	sh	s2,2(s0)
    8b70:	00941023          	sh	s1,0(s0)
    8b74:	00100513          	li	a0,1
    8b78:	f69ff06f          	j	8ae0 <replay_next+0x7c>
    8b7c:	ff800513          	li	a0,-8
    8b80:	00008067          	ret

00008b84 <enter_menu>:
    8b84:	0000f7b7          	lui	a5,0xf
    8b88:	00f50533          	add	a0,a0,a5
    8b8c:	00100793          	li	a5,1
    8b90:	56f50c23          	sb	a5,1400(a0)
    8b94:	57c52783          	lw	a5,1404(a0)
    8b98:	56b50b23          	sb	a1,1398(a0)
    8b9c:	56052823          	sw	zero,1392(a0)
    8ba0:	00178793          	addi	a5,a5,1 # f001 <__global_pointer$+0x299>
    8ba4:	56050a23          	sb	zero,1396(a0)
    8ba8:	54052223          	sw	zero,1348(a0)
    8bac:	54051423          	sh	zero,1352(a0)
    8bb0:	54052c23          	sw	zero,1368(a0)
    8bb4:	54052e23          	sw	zero,1372(a0)
    8bb8:	56052023          	sw	zero,1376(a0)
    8bbc:	56052223          	sw	zero,1380(a0)
    8bc0:	56052423          	sw	zero,1384(a0)
    8bc4:	56f52e23          	sw	a5,1404(a0)
    8bc8:	54052623          	sw	zero,1356(a0)
    8bcc:	54052823          	sw	zero,1360(a0)
    8bd0:	00008067          	ret

00008bd4 <begin_compare>:
    8bd4:	ff010113          	addi	sp,sp,-16
    8bd8:	00912223          	sw	s1,4(sp)
    8bdc:	00050493          	mv	s1,a0
    8be0:	00005537          	lui	a0,0x5
    8be4:	02c50513          	addi	a0,a0,44 # 502c <bullet_enemy_position+0x74>
    8be8:	00812423          	sw	s0,8(sp)
    8bec:	00050613          	mv	a2,a0
    8bf0:	00048593          	mv	a1,s1
    8bf4:	00a48533          	add	a0,s1,a0
    8bf8:	0000f437          	lui	s0,0xf
    8bfc:	00112623          	sw	ra,12(sp)
    8c00:	00848433          	add	s0,s1,s0
    8c04:	f00f80ef          	jal	1304 <memcpy>
    8c08:	0000f6b7          	lui	a3,0xf
    8c0c:	0000a537          	lui	a0,0xa
    8c10:	56c42583          	lw	a1,1388(s0) # f56c <__global_pointer$+0x804>
    8c14:	54468693          	addi	a3,a3,1348 # f544 <__global_pointer$+0x7dc>
    8c18:	05850513          	addi	a0,a0,88 # a058 <v3_demo_run+0x5b0>
    8c1c:	00d486b3          	add	a3,s1,a3
    8c20:	00048613          	mv	a2,s1
    8c24:	00a48533          	add	a0,s1,a0
    8c28:	d69ff0ef          	jal	8990 <replay_begin>
    8c2c:	02051263          	bnez	a0,8c50 <begin_compare+0x7c>
    8c30:	00100793          	li	a5,1
    8c34:	56f40923          	sb	a5,1394(s0)
    8c38:	56041823          	sh	zero,1392(s0)
    8c3c:	54042c23          	sw	zero,1368(s0)
    8c40:	54042e23          	sw	zero,1372(s0)
    8c44:	56042023          	sw	zero,1376(s0)
    8c48:	56042223          	sw	zero,1380(s0)
    8c4c:	56042423          	sw	zero,1384(s0)
    8c50:	00c12083          	lw	ra,12(sp)
    8c54:	00812403          	lw	s0,8(sp)
    8c58:	00412483          	lw	s1,4(sp)
    8c5c:	01010113          	addi	sp,sp,16
    8c60:	00008067          	ret

00008c64 <v3_runtime_status>:
    8c64:	0000f837          	lui	a6,0xf
    8c68:	01050833          	add	a6,a0,a6
    8c6c:	57784303          	lbu	t1,1399(a6) # f577 <__global_pointer$+0x80f>
    8c70:	57484883          	lbu	a7,1396(a6)
    8c74:	00000e93          	li	t4,0
    8c78:	00030463          	beqz	t1,8c80 <v3_runtime_status+0x1c>
    8c7c:	0018be93          	seqz	t4,a7
    8c80:	0000f837          	lui	a6,0xf
    8c84:	01050533          	add	a0,a0,a6
    8c88:	57254803          	lbu	a6,1394(a0)
    8c8c:	57954503          	lbu	a0,1401(a0)
    8c90:	ffe88893          	addi	a7,a7,-2
    8c94:	00603333          	snez	t1,t1
    8c98:	01003e33          	snez	t3,a6
    8c9c:	00a03533          	snez	a0,a0
    8ca0:	0018b893          	seqz	a7,a7
    8ca4:	00b31f93          	slli	t6,t1,0xb
    8ca8:	001e0e13          	addi	t3,t3,1
    8cac:	00e31313          	slli	t1,t1,0xe
    8cb0:	00c51513          	slli	a0,a0,0xc
    8cb4:	00d89893          	slli	a7,a7,0xd
    8cb8:	00000f13          	li	t5,0
    8cbc:	000e8463          	beqz	t4,8cc4 <v3_runtime_status+0x60>
    8cc0:	50000f13          	li	t5,1280
    8cc4:	0015b593          	seqz	a1,a1
    8cc8:	00c03633          	snez	a2,a2
    8ccc:	00100393          	li	t2,1
    8cd0:	00359593          	slli	a1,a1,0x3
    8cd4:	00461613          	slli	a2,a2,0x4
    8cd8:	02000293          	li	t0,32
    8cdc:	00781663          	bne	a6,t2,8ce8 <v3_runtime_status+0x84>
    8ce0:	0017b793          	seqz	a5,a5
    8ce4:	00579293          	slli	t0,a5,0x5
    8ce8:	00000393          	li	t2,0
    8cec:	00068a63          	beqz	a3,8d00 <v3_runtime_status+0x9c>
    8cf0:	000e9863          	bnez	t4,8d00 <v3_runtime_status+0x9c>
    8cf4:	fff80813          	addi	a6,a6,-1 # efff <__global_pointer$+0x297>
    8cf8:	01003833          	snez	a6,a6
    8cfc:	01081393          	slli	t2,a6,0x10
    8d00:	00e037b3          	snez	a5,a4
    8d04:	01179793          	slli	a5,a5,0x11
    8d08:	0077e7b3          	or	a5,a5,t2
    8d0c:	00c7e7b3          	or	a5,a5,a2
    8d10:	00b7e7b3          	or	a5,a5,a1
    8d14:	01f7e7b3          	or	a5,a5,t6
    8d18:	0067e7b3          	or	a5,a5,t1
    8d1c:	00a7e7b3          	or	a5,a5,a0
    8d20:	0117e7b3          	or	a5,a5,a7
    8d24:	01c7e7b3          	or	a5,a5,t3
    8d28:	01e7e7b3          	or	a5,a5,t5
    8d2c:	00700537          	lui	a0,0x700
    8d30:	0057e7b3          	or	a5,a5,t0
    8d34:	08050513          	addi	a0,a0,128 # 700080 <__freertos_irq_stack_top+0x6e2600>
    8d38:	00a7e533          	or	a0,a5,a0
    8d3c:	00008067          	ret

00008d40 <v3_runtime_init>:
    8d40:	0a050663          	beqz	a0,8dec <v3_runtime_init+0xac>
    8d44:	fe010113          	addi	sp,sp,-32
    8d48:	00912a23          	sw	s1,20(sp)
    8d4c:	00112e23          	sw	ra,28(sp)
    8d50:	00812c23          	sw	s0,24(sp)
    8d54:	01212823          	sw	s2,16(sp)
    8d58:	01312623          	sw	s3,12(sp)
    8d5c:	01412423          	sw	s4,8(sp)
    8d60:	01512223          	sw	s5,4(sp)
    8d64:	00068493          	mv	s1,a3
    8d68:	08068663          	beqz	a3,8df4 <v3_runtime_init+0xb4>
    8d6c:	00060a13          	mv	s4,a2
    8d70:	0000f637          	lui	a2,0xf
    8d74:	00050413          	mv	s0,a0
    8d78:	00058993          	mv	s3,a1
    8d7c:	58860613          	addi	a2,a2,1416 # f588 <__global_pointer$+0x820>
    8d80:	00000593          	li	a1,0
    8d84:	0000f937          	lui	s2,0xf
    8d88:	ca0f80ef          	jal	1228 <memset>
    8d8c:	01240933          	add	s2,s0,s2
    8d90:	00100a93          	li	s5,1
    8d94:	56992623          	sw	s1,1388(s2) # f56c <__global_pointer$+0x804>
    8d98:	57590a23          	sb	s5,1396(s2)
    8d9c:	000a0613          	mv	a2,s4
    8da0:	00098593          	mv	a1,s3
    8da4:	00040513          	mv	a0,s0
    8da8:	92cff0ef          	jal	7ed4 <game_reset>
    8dac:	04051663          	bnez	a0,8df8 <v3_runtime_init+0xb8>
    8db0:	0000a537          	lui	a0,0xa
    8db4:	57590d23          	sb	s5,1402(s2)
    8db8:	05850513          	addi	a0,a0,88 # a058 <v3_demo_run+0x5b0>
    8dbc:	00040593          	mv	a1,s0
    8dc0:	00a40533          	add	a0,s0,a0
    8dc4:	01812403          	lw	s0,24(sp)
    8dc8:	01c12083          	lw	ra,28(sp)
    8dcc:	01012903          	lw	s2,16(sp)
    8dd0:	00c12983          	lw	s3,12(sp)
    8dd4:	00812a03          	lw	s4,8(sp)
    8dd8:	00412a83          	lw	s5,4(sp)
    8ddc:	00048613          	mv	a2,s1
    8de0:	01412483          	lw	s1,20(sp)
    8de4:	02010113          	addi	sp,sp,32
    8de8:	e98ff06f          	j	8480 <replay_init>
    8dec:	ff800513          	li	a0,-8
    8df0:	00008067          	ret
    8df4:	ff800513          	li	a0,-8
    8df8:	01c12083          	lw	ra,28(sp)
    8dfc:	01812403          	lw	s0,24(sp)
    8e00:	01412483          	lw	s1,20(sp)
    8e04:	01012903          	lw	s2,16(sp)
    8e08:	00c12983          	lw	s3,12(sp)
    8e0c:	00812a03          	lw	s4,8(sp)
    8e10:	00412a83          	lw	s5,4(sp)
    8e14:	02010113          	addi	sp,sp,32
    8e18:	00008067          	ret

00008e1c <v3_level_count>:
    8e1c:	fff50513          	addi	a0,a0,-1
    8e20:	00500793          	li	a5,5
    8e24:	02a7e063          	bltu	a5,a0,8e44 <v3_level_count+0x28>
    8e28:	0000e7b7          	lui	a5,0xe
    8e2c:	00251513          	slli	a0,a0,0x2
    8e30:	3ec78793          	addi	a5,a5,1004 # e3ec <counts.0>
    8e34:	00a787b3          	add	a5,a5,a0
    8e38:	0007a503          	lw	a0,0(a5)
    8e3c:	40000793          	li	a5,1024
    8e40:	00a7f463          	bgeu	a5,a0,8e48 <v3_level_count+0x2c>
    8e44:	00000513          	li	a0,0
    8e48:	00008067          	ret

00008e4c <restart_game>:
    8e4c:	fe010113          	addi	sp,sp,-32
    8e50:	00812c23          	sw	s0,24(sp)
    8e54:	0000f437          	lui	s0,0xf
    8e58:	00912a23          	sw	s1,20(sp)
    8e5c:	01212823          	sw	s2,16(sp)
    8e60:	01312623          	sw	s3,12(sp)
    8e64:	00112e23          	sw	ra,28(sp)
    8e68:	00850433          	add	s0,a0,s0
    8e6c:	00050493          	mv	s1,a0
    8e70:	57544503          	lbu	a0,1397(s0) # f575 <__global_pointer$+0x80d>
    8e74:	00058993          	mv	s3,a1
    8e78:	00060913          	mv	s2,a2
    8e7c:	fa1ff0ef          	jal	8e1c <v3_level_count>
    8e80:	00050593          	mv	a1,a0
    8e84:	00700613          	li	a2,7
    8e88:	00048513          	mv	a0,s1
    8e8c:	848ff0ef          	jal	7ed4 <game_reset>
    8e90:	06051663          	bnez	a0,8efc <restart_game+0xb0>
    8e94:	0000a537          	lui	a0,0xa
    8e98:	56c42603          	lw	a2,1388(s0)
    8e9c:	05850513          	addi	a0,a0,88 # a058 <v3_demo_run+0x5b0>
    8ea0:	00048593          	mv	a1,s1
    8ea4:	00a48533          	add	a0,s1,a0
    8ea8:	dd8ff0ef          	jal	8480 <replay_init>
    8eac:	04051863          	bnez	a0,8efc <restart_game+0xb0>
    8eb0:	00100793          	li	a5,1
    8eb4:	56f40d23          	sb	a5,1402(s0)
    8eb8:	56f40a23          	sb	a5,1396(s0)
    8ebc:	56f40c23          	sb	a5,1400(s0)
    8ec0:	57c42783          	lw	a5,1404(s0)
    8ec4:	54042623          	sw	zero,1356(s0)
    8ec8:	54042823          	sw	zero,1360(s0)
    8ecc:	00178793          	addi	a5,a5,1
    8ed0:	54042c23          	sw	zero,1368(s0)
    8ed4:	54042e23          	sw	zero,1372(s0)
    8ed8:	56042023          	sw	zero,1376(s0)
    8edc:	56042223          	sw	zero,1380(s0)
    8ee0:	56042423          	sw	zero,1384(s0)
    8ee4:	54042223          	sw	zero,1348(s0)
    8ee8:	54041423          	sh	zero,1352(s0)
    8eec:	56042823          	sw	zero,1392(s0)
    8ef0:	59342023          	sw	s3,1408(s0)
    8ef4:	59242223          	sw	s2,1412(s0)
    8ef8:	56f42e23          	sw	a5,1404(s0)
    8efc:	01c12083          	lw	ra,28(sp)
    8f00:	01812403          	lw	s0,24(sp)
    8f04:	01412483          	lw	s1,20(sp)
    8f08:	01012903          	lw	s2,16(sp)
    8f0c:	00c12983          	lw	s3,12(sp)
    8f10:	02010113          	addi	sp,sp,32
    8f14:	00008067          	ret

00008f18 <v3_runtime_game_command>:
    8f18:	12050e63          	beqz	a0,9054 <v3_runtime_game_command+0x13c>
    8f1c:	fd010113          	addi	sp,sp,-48
    8f20:	0000f7b7          	lui	a5,0xf
    8f24:	02812423          	sw	s0,40(sp)
    8f28:	02912223          	sw	s1,36(sp)
    8f2c:	02112623          	sw	ra,44(sp)
    8f30:	03212023          	sw	s2,32(sp)
    8f34:	01312e23          	sw	s3,28(sp)
    8f38:	00f507b3          	add	a5,a0,a5
    8f3c:	00060413          	mv	s0,a2
    8f40:	00070613          	mv	a2,a4
    8f44:	5777c703          	lbu	a4,1399(a5) # f577 <__global_pointer$+0x80f>
    8f48:	00050493          	mv	s1,a0
    8f4c:	08070263          	beqz	a4,8fd0 <v3_runtime_game_command+0xb8>
    8f50:	00068993          	mv	s3,a3
    8f54:	06068e63          	beqz	a3,8fd0 <v3_runtime_game_command+0xb8>
    8f58:	00100713          	li	a4,1
    8f5c:	00058913          	mv	s2,a1
    8f60:	02e59663          	bne	a1,a4,8f8c <v3_runtime_game_command+0x74>
    8f64:	fff40793          	addi	a5,s0,-1
    8f68:	00500713          	li	a4,5
    8f6c:	06f76263          	bltu	a4,a5,8fd0 <v3_runtime_game_command+0xb8>
    8f70:	00040513          	mv	a0,s0
    8f74:	00c12623          	sw	a2,12(sp)
    8f78:	ea5ff0ef          	jal	8e1c <v3_level_count>
    8f7c:	00c12603          	lw	a2,12(sp)
    8f80:	06051063          	bnez	a0,8fe0 <v3_runtime_game_command+0xc8>
    8f84:	00100793          	li	a5,1
    8f88:	01c0006f          	j	8fa4 <v3_runtime_game_command+0x8c>
    8f8c:	00200713          	li	a4,2
    8f90:	02e59a63          	bne	a1,a4,8fc4 <v3_runtime_game_command+0xac>
    8f94:	ff800793          	li	a5,-8
    8f98:	00041663          	bnez	s0,8fa4 <v3_runtime_game_command+0x8c>
    8f9c:	be9ff0ef          	jal	8b84 <enter_menu>
    8fa0:	00000793          	li	a5,0
    8fa4:	02c12083          	lw	ra,44(sp)
    8fa8:	02812403          	lw	s0,40(sp)
    8fac:	02412483          	lw	s1,36(sp)
    8fb0:	02012903          	lw	s2,32(sp)
    8fb4:	01c12983          	lw	s3,28(sp)
    8fb8:	00078513          	mv	a0,a5
    8fbc:	03010113          	addi	sp,sp,48
    8fc0:	00008067          	ret
    8fc4:	00300713          	li	a4,3
    8fc8:	00e59463          	bne	a1,a4,8fd0 <v3_runtime_game_command+0xb8>
    8fcc:	00040663          	beqz	s0,8fd8 <v3_runtime_game_command+0xc0>
    8fd0:	ff800793          	li	a5,-8
    8fd4:	fd1ff06f          	j	8fa4 <v3_runtime_game_command+0x8c>
    8fd8:	5797c783          	lbu	a5,1401(a5)
    8fdc:	fa0784e3          	beqz	a5,8f84 <v3_runtime_game_command+0x6c>
    8fe0:	0000f7b7          	lui	a5,0xf
    8fe4:	00f487b3          	add	a5,s1,a5
    8fe8:	5747c703          	lbu	a4,1396(a5) # f574 <__global_pointer$+0x80c>
    8fec:	f8071ce3          	bnez	a4,8f84 <v3_runtime_game_command+0x6c>
    8ff0:	00300713          	li	a4,3
    8ff4:	02e91c63          	bne	s2,a4,902c <v3_runtime_game_command+0x114>
    8ff8:	00200713          	li	a4,2
    8ffc:	56e78a23          	sb	a4,1396(a5)
    9000:	57c7a703          	lw	a4,1404(a5)
    9004:	56079923          	sh	zero,1394(a5)
    9008:	5937a023          	sw	s3,1408(a5)
    900c:	00170713          	addi	a4,a4,1
    9010:	5407ac23          	sw	zero,1368(a5)
    9014:	5407ae23          	sw	zero,1372(a5)
    9018:	5607a023          	sw	zero,1376(a5)
    901c:	5607a223          	sw	zero,1380(a5)
    9020:	5607a423          	sw	zero,1384(a5)
    9024:	56e7ae23          	sw	a4,1404(a5)
    9028:	f79ff06f          	j	8fa0 <v3_runtime_game_command+0x88>
    902c:	56878aa3          	sb	s0,1397(a5)
    9030:	02812403          	lw	s0,40(sp)
    9034:	02c12083          	lw	ra,44(sp)
    9038:	02012903          	lw	s2,32(sp)
    903c:	00098593          	mv	a1,s3
    9040:	00048513          	mv	a0,s1
    9044:	01c12983          	lw	s3,28(sp)
    9048:	02412483          	lw	s1,36(sp)
    904c:	03010113          	addi	sp,sp,48
    9050:	dfdff06f          	j	8e4c <restart_game>
    9054:	ff800793          	li	a5,-8
    9058:	00078513          	mv	a0,a5
    905c:	00008067          	ret

00009060 <v3_runtime_advance>:
    9060:	f9010113          	addi	sp,sp,-112
    9064:	06112623          	sw	ra,108(sp)
    9068:	06812423          	sw	s0,104(sp)
    906c:	06912223          	sw	s1,100(sp)
    9070:	07212023          	sw	s2,96(sp)
    9074:	05312e23          	sw	s3,92(sp)
    9078:	05412c23          	sw	s4,88(sp)
    907c:	05512a23          	sw	s5,84(sp)
    9080:	05612823          	sw	s6,80(sp)
    9084:	05712623          	sw	s7,76(sp)
    9088:	48050c63          	beqz	a0,9520 <v3_runtime_advance+0x4c0>
    908c:	48058a63          	beqz	a1,9520 <v3_runtime_advance+0x4c0>
    9090:	0000f7b7          	lui	a5,0xf
    9094:	00f507b3          	add	a5,a0,a5
    9098:	5547d683          	lhu	a3,1364(a5) # f554 <__global_pointer$+0x7ec>
    909c:	10000713          	li	a4,256
    90a0:	00050493          	mv	s1,a0
    90a4:	46d76e63          	bltu	a4,a3,9520 <v3_runtime_advance+0x4c0>
    90a8:	5777c903          	lbu	s2,1399(a5)
    90ac:	00060413          	mv	s0,a2
    90b0:	5747c783          	lbu	a5,1396(a5)
    90b4:	00090463          	beqz	s2,90bc <v3_runtime_advance+0x5c>
    90b8:	02078663          	beqz	a5,90e4 <v3_runtime_advance+0x84>
    90bc:	00200713          	li	a4,2
    90c0:	02e79663          	bne	a5,a4,90ec <v3_runtime_advance+0x8c>
    90c4:	0025d783          	lhu	a5,2(a1)
    90c8:	0407f793          	andi	a5,a5,64
    90cc:	00078c63          	beqz	a5,90e4 <v3_runtime_advance+0x84>
    90d0:	0000f7b7          	lui	a5,0xf
    90d4:	00f487b3          	add	a5,s1,a5
    90d8:	57c7a703          	lw	a4,1404(a5) # f57c <__global_pointer$+0x814>
    90dc:	00170713          	addi	a4,a4,1
    90e0:	56e7ae23          	sw	a4,1404(a5)
    90e4:	00000413          	li	s0,0
    90e8:	0540006f          	j	913c <v3_runtime_advance+0xdc>
    90ec:	0000f7b7          	lui	a5,0xf
    90f0:	00f487b3          	add	a5,s1,a5
    90f4:	5727c983          	lbu	s3,1394(a5) # f572 <__global_pointer$+0x80a>
    90f8:	06098a63          	beqz	s3,916c <v3_runtime_advance+0x10c>
    90fc:	0000f5b7          	lui	a1,0xf
    9100:	0000a537          	lui	a0,0xa
    9104:	54458593          	addi	a1,a1,1348 # f544 <__global_pointer$+0x7dc>
    9108:	05850513          	addi	a0,a0,88 # a058 <v3_demo_run+0x5b0>
    910c:	02810613          	addi	a2,sp,40
    9110:	00b485b3          	add	a1,s1,a1
    9114:	00a48533          	add	a0,s1,a0
    9118:	94dff0ef          	jal	8a64 <replay_next>
    911c:	00100793          	li	a5,1
    9120:	00050413          	mv	s0,a0
    9124:	3ef51e63          	bne	a0,a5,9520 <v3_runtime_advance+0x4c0>
    9128:	02810593          	addi	a1,sp,40
    912c:	00048513          	mv	a0,s1
    9130:	804ff0ef          	jal	8134 <game_update>
    9134:	00055463          	bgez	a0,913c <v3_runtime_advance+0xdc>
    9138:	00050413          	mv	s0,a0
    913c:	06c12083          	lw	ra,108(sp)
    9140:	00040513          	mv	a0,s0
    9144:	06812403          	lw	s0,104(sp)
    9148:	06412483          	lw	s1,100(sp)
    914c:	06012903          	lw	s2,96(sp)
    9150:	05c12983          	lw	s3,92(sp)
    9154:	05812a03          	lw	s4,88(sp)
    9158:	05412a83          	lw	s5,84(sp)
    915c:	05012b03          	lw	s6,80(sp)
    9160:	04c12b83          	lw	s7,76(sp)
    9164:	07010113          	addi	sp,sp,112
    9168:	00008067          	ret
    916c:	02090263          	beqz	s2,9190 <v3_runtime_advance+0x130>
    9170:	000057b7          	lui	a5,0x5
    9174:	00f487b3          	add	a5,s1,a5
    9178:	0247c783          	lbu	a5,36(a5) # 5024 <bullet_enemy_position+0x6c>
    917c:	00079a63          	bnez	a5,9190 <v3_runtime_advance+0x130>
    9180:	00100593          	li	a1,1
    9184:	00048513          	mv	a0,s1
    9188:	9fdff0ef          	jal	8b84 <enter_menu>
    918c:	f59ff06f          	j	90e4 <v3_runtime_advance+0x84>
    9190:	01800613          	li	a2,24
    9194:	01010513          	addi	a0,sp,16
    9198:	00b12623          	sw	a1,12(sp)
    919c:	968f80ef          	jal	1304 <memcpy>
    91a0:	00c12583          	lw	a1,12(sp)
    91a4:	04090c63          	beqz	s2,91fc <v3_runtime_advance+0x19c>
    91a8:	0000f7b7          	lui	a5,0xf
    91ac:	00f487b3          	add	a5,s1,a5
    91b0:	5787c703          	lbu	a4,1400(a5) # f578 <__global_pointer$+0x810>
    91b4:	0a070263          	beqz	a4,9258 <v3_runtime_advance+0x1f8>
    91b8:	0145c703          	lbu	a4,20(a1)
    91bc:	02070a63          	beqz	a4,91f0 <v3_runtime_advance+0x190>
    91c0:	0165c703          	lbu	a4,22(a1)
    91c4:	02070663          	beqz	a4,91f0 <v3_runtime_advance+0x190>
    91c8:	5847a683          	lw	a3,1412(a5)
    91cc:	0085a603          	lw	a2,8(a1)
    91d0:	5807a783          	lw	a5,1408(a5)
    91d4:	00c5a703          	lw	a4,12(a1)
    91d8:	00f61663          	bne	a2,a5,91e4 <v3_runtime_advance+0x184>
    91dc:	40d70733          	sub	a4,a4,a3
    91e0:	00e05863          	blez	a4,91f0 <v3_runtime_advance+0x190>
    91e4:	0000f7b7          	lui	a5,0xf
    91e8:	00f487b3          	add	a5,s1,a5
    91ec:	56078c23          	sb	zero,1400(a5) # f578 <__global_pointer$+0x810>
    91f0:	00012823          	sw	zero,16(sp)
    91f4:	00011a23          	sh	zero,20(sp)
    91f8:	01010593          	addi	a1,sp,16
    91fc:	0025d783          	lhu	a5,2(a1)
    9200:	0807f713          	andi	a4,a5,128
    9204:	08070c63          	beqz	a4,929c <v3_runtime_advance+0x23c>
    9208:	0000f737          	lui	a4,0xf
    920c:	00e48733          	add	a4,s1,a4
    9210:	00100693          	li	a3,1
    9214:	56d709a3          	sb	a3,1395(a4) # f573 <__global_pointer$+0x80b>
    9218:	0000f737          	lui	a4,0xf
    921c:	00e48733          	add	a4,s1,a4
    9220:	54274703          	lbu	a4,1346(a4) # f542 <__global_pointer$+0x7da>
    9224:	08070463          	beqz	a4,92ac <v3_runtime_advance+0x24c>
    9228:	06812403          	lw	s0,104(sp)
    922c:	06c12083          	lw	ra,108(sp)
    9230:	06012903          	lw	s2,96(sp)
    9234:	05c12983          	lw	s3,92(sp)
    9238:	05812a03          	lw	s4,88(sp)
    923c:	05412a83          	lw	s5,84(sp)
    9240:	05012b03          	lw	s6,80(sp)
    9244:	04c12b83          	lw	s7,76(sp)
    9248:	00048513          	mv	a0,s1
    924c:	06412483          	lw	s1,100(sp)
    9250:	07010113          	addi	sp,sp,112
    9254:	981ff06f          	j	8bd4 <begin_compare>
    9258:	0025d783          	lhu	a5,2(a1)
    925c:	0407f793          	andi	a5,a5,64
    9260:	f8078ee3          	beqz	a5,91fc <v3_runtime_advance+0x19c>
    9264:	06812403          	lw	s0,104(sp)
    9268:	00c5a603          	lw	a2,12(a1)
    926c:	06c12083          	lw	ra,108(sp)
    9270:	06012903          	lw	s2,96(sp)
    9274:	05c12983          	lw	s3,92(sp)
    9278:	05812a03          	lw	s4,88(sp)
    927c:	05412a83          	lw	s5,84(sp)
    9280:	05012b03          	lw	s6,80(sp)
    9284:	04c12b83          	lw	s7,76(sp)
    9288:	0085a583          	lw	a1,8(a1)
    928c:	00048513          	mv	a0,s1
    9290:	06412483          	lw	s1,100(sp)
    9294:	07010113          	addi	sp,sp,112
    9298:	bb5ff06f          	j	8e4c <restart_game>
    929c:	0000f737          	lui	a4,0xf
    92a0:	00e48733          	add	a4,s1,a4
    92a4:	57374703          	lbu	a4,1395(a4) # f573 <__global_pointer$+0x80b>
    92a8:	f60718e3          	bnez	a4,9218 <v3_runtime_advance+0x1b8>
    92ac:	0003d737          	lui	a4,0x3d
    92b0:	09070713          	addi	a4,a4,144 # 3d090 <__freertos_irq_stack_top+0x1f610>
    92b4:	00877663          	bgeu	a4,s0,92c0 <v3_runtime_advance+0x260>
    92b8:	00100993          	li	s3,1
    92bc:	00070413          	mv	s0,a4
    92c0:	03c00713          	li	a4,60
    92c4:	02e40433          	mul	s0,s0,a4
    92c8:	0000f937          	lui	s2,0xf
    92cc:	01248933          	add	s2,s1,s2
    92d0:	55892703          	lw	a4,1368(s2) # f558 <__global_pointer$+0x7f0>
    92d4:	57390423          	sb	s3,1384(s2)
    92d8:	56695983          	lhu	s3,1382(s2)
    92dc:	0000aa37          	lui	s4,0xa
    92e0:	0000aab7          	lui	s5,0xa
    92e4:	01800613          	li	a2,24
    92e8:	02810513          	addi	a0,sp,40
    92ec:	00870733          	add	a4,a4,s0
    92f0:	54e92c23          	sw	a4,1368(s2)
    92f4:	56495703          	lhu	a4,1380(s2)
    92f8:	000f4b37          	lui	s6,0xf4
    92fc:	058a0a13          	addi	s4,s4,88 # a058 <v3_demo_run+0x5b0>
    9300:	00e7e433          	or	s0,a5,a4
    9304:	0045d783          	lhu	a5,4(a1)
    9308:	56891223          	sh	s0,1380(s2)
    930c:	00005bb7          	lui	s7,0x5
    9310:	00f9e9b3          	or	s3,s3,a5
    9314:	57391323          	sh	s3,1382(s2)
    9318:	01548ab3          	add	s5,s1,s5
    931c:	fe9f70ef          	jal	1304 <memcpy>
    9320:	23fb0b13          	addi	s6,s6,575 # f423f <__freertos_irq_stack_top+0xd67bf>
    9324:	03311623          	sh	s3,44(sp)
    9328:	02811523          	sh	s0,42(sp)
    932c:	00000993          	li	s3,0
    9330:	01448a33          	add	s4,s1,s4
    9334:	017a8ab3          	add	s5,s5,s7
    9338:	55892783          	lw	a5,1368(s2)
    933c:	0efb7263          	bgeu	s6,a5,9420 <v3_runtime_advance+0x3c0>
    9340:	00400793          	li	a5,4
    9344:	0cf98e63          	beq	s3,a5,9420 <v3_runtime_advance+0x3c0>
    9348:	54294783          	lbu	a5,1346(s2)
    934c:	08078063          	beqz	a5,93cc <v3_runtime_advance+0x36c>
    9350:	57a94783          	lbu	a5,1402(s2)
    9354:	000a0613          	mv	a2,s4
    9358:	00079463          	bnez	a5,9360 <v3_runtime_advance+0x300>
    935c:	00000613          	li	a2,0
    9360:	02810593          	addi	a1,sp,40
    9364:	00048513          	mv	a0,s1
    9368:	badfe0ef          	jal	7f14 <game_update_cached>
    936c:	00050413          	mv	s0,a0
    9370:	dc0546e3          	bltz	a0,913c <v3_runtime_advance+0xdc>
    9374:	55892783          	lw	a5,1368(s2)
    9378:	fff0c737          	lui	a4,0xfff0c
    937c:	dc070713          	addi	a4,a4,-576 # fff0bdc0 <__gpu_framebuffer_a+0xfdf0bdc0>
    9380:	00e787b3          	add	a5,a5,a4
    9384:	54f92c23          	sw	a5,1368(s2)
    9388:	55c92783          	lw	a5,1372(s2)
    938c:	56092223          	sw	zero,1380(s2)
    9390:	02011623          	sh	zero,44(sp)
    9394:	00178793          	addi	a5,a5,1
    9398:	54f92e23          	sw	a5,1372(s2)
    939c:	57794783          	lbu	a5,1399(s2)
    93a0:	02011523          	sh	zero,42(sp)
    93a4:	00198993          	addi	s3,s3,1
    93a8:	04078863          	beqz	a5,93f8 <v3_runtime_advance+0x398>
    93ac:	017487b3          	add	a5,s1,s7
    93b0:	0247c783          	lbu	a5,36(a5)
    93b4:	04079263          	bnez	a5,93f8 <v3_runtime_advance+0x398>
    93b8:	00100593          	li	a1,1
    93bc:	00048513          	mv	a0,s1
    93c0:	fc4ff0ef          	jal	8b84 <enter_menu>
    93c4:	00098413          	mv	s0,s3
    93c8:	d75ff06f          	j	913c <v3_runtime_advance+0xdc>
    93cc:	54095703          	lhu	a4,1344(s2)
    93d0:	25700793          	li	a5,599
    93d4:	f6e7eee3          	bltu	a5,a4,9350 <v3_runtime_advance+0x2f0>
    93d8:	0000a537          	lui	a0,0xa
    93dc:	05850513          	addi	a0,a0,88 # a058 <v3_demo_run+0x5b0>
    93e0:	02810593          	addi	a1,sp,40
    93e4:	00a48533          	add	a0,s1,a0
    93e8:	944ff0ef          	jal	852c <replay_record>
    93ec:	00050413          	mv	s0,a0
    93f0:	f60500e3          	beqz	a0,9350 <v3_runtime_advance+0x2f0>
    93f4:	d49ff06f          	j	913c <v3_runtime_advance+0xdc>
    93f8:	55495783          	lhu	a5,1364(s2)
    93fc:	08078e63          	beqz	a5,9498 <v3_runtime_advance+0x438>
    9400:	57394783          	lbu	a5,1395(s2)
    9404:	f2078ae3          	beqz	a5,9338 <v3_runtime_advance+0x2d8>
    9408:	54294783          	lbu	a5,1346(s2)
    940c:	f20786e3          	beqz	a5,9338 <v3_runtime_advance+0x2d8>
    9410:	00048513          	mv	a0,s1
    9414:	fc0ff0ef          	jal	8bd4 <begin_compare>
    9418:	00050413          	mv	s0,a0
    941c:	d20510e3          	bnez	a0,913c <v3_runtime_advance+0xdc>
    9420:	0000f937          	lui	s2,0xf
    9424:	01248933          	add	s2,s1,s2
    9428:	55495603          	lhu	a2,1364(s2) # f554 <__global_pointer$+0x7ec>
    942c:	08061e63          	bnez	a2,94c8 <v3_runtime_advance+0x468>
    9430:	0000f737          	lui	a4,0xf
    9434:	00e48733          	add	a4,s1,a4
    9438:	55872783          	lw	a5,1368(a4) # f558 <__global_pointer$+0x7f0>
    943c:	000f46b7          	lui	a3,0xf4
    9440:	23f68693          	addi	a3,a3,575 # f423f <__freertos_irq_stack_top+0xd67bf>
    9444:	f8f6f0e3          	bgeu	a3,a5,93c4 <v3_runtime_advance+0x364>
    9448:	00100693          	li	a3,1
    944c:	56d70423          	sb	a3,1384(a4)
    9450:	003d16b7          	lui	a3,0x3d1
    9454:	90068693          	addi	a3,a3,-1792 # 3d0900 <__freertos_irq_stack_top+0x3b2e80>
    9458:	f6f6f6e3          	bgeu	a3,a5,93c4 <v3_runtime_advance+0x364>
    945c:	40d787b3          	sub	a5,a5,a3
    9460:	03c00693          	li	a3,60
    9464:	02d7d7b3          	divu	a5,a5,a3
    9468:	56072683          	lw	a3,1376(a4)
    946c:	fff00713          	li	a4,-1
    9470:	00f687b3          	add	a5,a3,a5
    9474:	00d7e463          	bltu	a5,a3,947c <v3_runtime_advance+0x41c>
    9478:	00078713          	mv	a4,a5
    947c:	0000f7b7          	lui	a5,0xf
    9480:	00f484b3          	add	s1,s1,a5
    9484:	003d17b7          	lui	a5,0x3d1
    9488:	90078793          	addi	a5,a5,-1792 # 3d0900 <__freertos_irq_stack_top+0x3b2e80>
    948c:	56e4a023          	sw	a4,1376(s1)
    9490:	54f4ac23          	sw	a5,1368(s1)
    9494:	f31ff06f          	j	93c4 <v3_runtime_advance+0x364>
    9498:	540aa783          	lw	a5,1344(s5) # a540 <v3_demo_run+0xa98>
    949c:	25800713          	li	a4,600
    94a0:	00879793          	slli	a5,a5,0x8
    94a4:	0087d793          	srli	a5,a5,0x8
    94a8:	f4e79ce3          	bne	a5,a4,9400 <v3_runtime_advance+0x3a0>
    94ac:	0000a537          	lui	a0,0xa
    94b0:	05850513          	addi	a0,a0,88 # a058 <v3_demo_run+0x5b0>
    94b4:	00a48533          	add	a0,s1,a0
    94b8:	8f8ff0ef          	jal	85b0 <replay_seal>
    94bc:	00050413          	mv	s0,a0
    94c0:	f40500e3          	beqz	a0,9400 <v3_runtime_advance+0x3a0>
    94c4:	c79ff06f          	j	913c <v3_runtime_advance+0xdc>
    94c8:	54092783          	lw	a5,1344(s2)
    94cc:	25800713          	li	a4,600
    94d0:	00879793          	slli	a5,a5,0x8
    94d4:	0087d793          	srli	a5,a5,0x8
    94d8:	f4e79ce3          	bne	a5,a4,9430 <v3_runtime_advance+0x3d0>
    94dc:	0000f5b7          	lui	a1,0xf
    94e0:	0000a537          	lui	a0,0xa
    94e4:	54c58593          	addi	a1,a1,1356 # f54c <__global_pointer$+0x7e4>
    94e8:	05850513          	addi	a0,a0,88 # a058 <v3_demo_run+0x5b0>
    94ec:	00b485b3          	add	a1,s1,a1
    94f0:	00a48533          	add	a0,s1,a0
    94f4:	948ff0ef          	jal	863c <replay_seal_step>
    94f8:	00050413          	mv	s0,a0
    94fc:	c40540e3          	bltz	a0,913c <v3_runtime_advance+0xdc>
    9500:	f20508e3          	beqz	a0,9430 <v3_runtime_advance+0x3d0>
    9504:	57394783          	lbu	a5,1395(s2)
    9508:	f20784e3          	beqz	a5,9430 <v3_runtime_advance+0x3d0>
    950c:	00048513          	mv	a0,s1
    9510:	ec4ff0ef          	jal	8bd4 <begin_compare>
    9514:	00050413          	mv	s0,a0
    9518:	f0050ce3          	beqz	a0,9430 <v3_runtime_advance+0x3d0>
    951c:	c21ff06f          	j	913c <v3_runtime_advance+0xdc>
    9520:	ff800413          	li	s0,-8
    9524:	c19ff06f          	j	913c <v3_runtime_advance+0xdc>

00009528 <v3_runtime_frame_done>:
    9528:	10050663          	beqz	a0,9634 <v3_runtime_frame_done+0x10c>
    952c:	ff010113          	addi	sp,sp,-16
    9530:	00812423          	sw	s0,8(sp)
    9534:	0000f437          	lui	s0,0xf
    9538:	00912223          	sw	s1,4(sp)
    953c:	00112623          	sw	ra,12(sp)
    9540:	01212023          	sw	s2,0(sp)
    9544:	00850433          	add	s0,a0,s0
    9548:	57244703          	lbu	a4,1394(s0) # f572 <__global_pointer$+0x80a>
    954c:	00050493          	mv	s1,a0
    9550:	02071063          	bnez	a4,9570 <v3_runtime_frame_done+0x48>
    9554:	00000513          	li	a0,0
    9558:	00c12083          	lw	ra,12(sp)
    955c:	00812403          	lw	s0,8(sp)
    9560:	00412483          	lw	s1,4(sp)
    9564:	00012903          	lw	s2,0(sp)
    9568:	01010113          	addi	sp,sp,16
    956c:	00008067          	ret
    9570:	57045783          	lhu	a5,1392(s0)
    9574:	25700693          	li	a3,599
    9578:	00178793          	addi	a5,a5,1
    957c:	01079793          	slli	a5,a5,0x10
    9580:	0107d793          	srli	a5,a5,0x10
    9584:	56f41823          	sh	a5,1392(s0)
    9588:	fcf6f6e3          	bgeu	a3,a5,9554 <v3_runtime_frame_done+0x2c>
    958c:	00100793          	li	a5,1
    9590:	56c42903          	lw	s2,1388(s0)
    9594:	02f71e63          	bne	a4,a5,95d0 <v3_runtime_frame_done+0xa8>
    9598:	0000f6b7          	lui	a3,0xf
    959c:	0000a537          	lui	a0,0xa
    95a0:	54468693          	addi	a3,a3,1348 # f544 <__global_pointer$+0x7dc>
    95a4:	05850513          	addi	a0,a0,88 # a058 <v3_demo_run+0x5b0>
    95a8:	00d486b3          	add	a3,s1,a3
    95ac:	00048613          	mv	a2,s1
    95b0:	00090593          	mv	a1,s2
    95b4:	00a48533          	add	a0,s1,a0
    95b8:	bd8ff0ef          	jal	8990 <replay_begin>
    95bc:	f8051ee3          	bnez	a0,9558 <v3_runtime_frame_done+0x30>
    95c0:	00200793          	li	a5,2
    95c4:	56f40923          	sb	a5,1394(s0)
    95c8:	56041823          	sh	zero,1392(s0)
    95cc:	f8dff06f          	j	9558 <v3_runtime_frame_done+0x30>
    95d0:	000055b7          	lui	a1,0x5
    95d4:	02c58593          	addi	a1,a1,44 # 502c <bullet_enemy_position+0x74>
    95d8:	00058613          	mv	a2,a1
    95dc:	00b505b3          	add	a1,a0,a1
    95e0:	d25f70ef          	jal	1304 <memcpy>
    95e4:	0000a537          	lui	a0,0xa
    95e8:	56042823          	sw	zero,1392(s0)
    95ec:	56040d23          	sb	zero,1402(s0)
    95f0:	54042c23          	sw	zero,1368(s0)
    95f4:	54042e23          	sw	zero,1372(s0)
    95f8:	56042023          	sw	zero,1376(s0)
    95fc:	56042223          	sw	zero,1380(s0)
    9600:	56042423          	sw	zero,1384(s0)
    9604:	54042623          	sw	zero,1356(s0)
    9608:	54042823          	sw	zero,1360(s0)
    960c:	05850513          	addi	a0,a0,88 # a058 <v3_demo_run+0x5b0>
    9610:	00812403          	lw	s0,8(sp)
    9614:	00c12083          	lw	ra,12(sp)
    9618:	00090613          	mv	a2,s2
    961c:	00048593          	mv	a1,s1
    9620:	00012903          	lw	s2,0(sp)
    9624:	00a48533          	add	a0,s1,a0
    9628:	00412483          	lw	s1,4(sp)
    962c:	01010113          	addi	sp,sp,16
    9630:	e51fe06f          	j	8480 <replay_init>
    9634:	ff800513          	li	a0,-8
    9638:	00008067          	ret

0000963c <now_ms>:
    963c:	ff010113          	addi	sp,sp,-16
    9640:	00112623          	sw	ra,12(sp)
    9644:	9e4f80ef          	jal	1828 <gpu_platform_cycles>
    9648:	00018637          	lui	a2,0x18
    964c:	6a060613          	addi	a2,a2,1696 # 186a0 <scene+0x4fe0>
    9650:	00000693          	li	a3,0
    9654:	320030ef          	jal	c974 <__udivdi3>
    9658:	00c12083          	lw	ra,12(sp)
    965c:	01010113          	addi	sp,sp,16
    9660:	00008067          	ret

00009664 <_putchar>:
    9664:	f80107b7          	lui	a5,0xf8010
    9668:	00478793          	addi	a5,a5,4 # f8010004 <__gpu_framebuffer_a+0xf6010004>
    966c:	0007a703          	lw	a4,0(a5)
    9670:	01075693          	srli	a3,a4,0x10
    9674:	0ff6f693          	zext.b	a3,a3
    9678:	fe068ae3          	beqz	a3,966c <_putchar+0x8>
    967c:	f80107b7          	lui	a5,0xf8010
    9680:	00a7a023          	sw	a0,0(a5) # f8010000 <__gpu_framebuffer_a+0xf6010000>
    9684:	00008067          	ret

00009688 <bsp_printf>:
    9688:	f8010113          	addi	sp,sp,-128
    968c:	06f12a23          	sw	a5,116(sp)
    9690:	06410793          	addi	a5,sp,100
    9694:	05212823          	sw	s2,80(sp)
    9698:	05312623          	sw	s3,76(sp)
    969c:	05412423          	sw	s4,72(sp)
    96a0:	05512223          	sw	s5,68(sp)
    96a4:	05612023          	sw	s6,64(sp)
    96a8:	03712e23          	sw	s7,60(sp)
    96ac:	04112e23          	sw	ra,92(sp)
    96b0:	04812c23          	sw	s0,88(sp)
    96b4:	04912a23          	sw	s1,84(sp)
    96b8:	03812c23          	sw	s8,56(sp)
    96bc:	03912a23          	sw	s9,52(sp)
    96c0:	00050993          	mv	s3,a0
    96c4:	06b12223          	sw	a1,100(sp)
    96c8:	06c12423          	sw	a2,104(sp)
    96cc:	06d12623          	sw	a3,108(sp)
    96d0:	06e12823          	sw	a4,112(sp)
    96d4:	07012c23          	sw	a6,120(sp)
    96d8:	07112e23          	sw	a7,124(sp)
    96dc:	00f12623          	sw	a5,12(sp)
    96e0:	00000913          	li	s2,0
    96e4:	02500a13          	li	s4,37
    96e8:	06600a93          	li	s5,102
    96ec:	06600b13          	li	s6,102
    96f0:	06300b93          	li	s7,99
    96f4:	012987b3          	add	a5,s3,s2
    96f8:	0007c503          	lbu	a0,0(a5)
    96fc:	02051c63          	bnez	a0,9734 <bsp_printf+0xac>
    9700:	05c12083          	lw	ra,92(sp)
    9704:	05812403          	lw	s0,88(sp)
    9708:	05412483          	lw	s1,84(sp)
    970c:	05012903          	lw	s2,80(sp)
    9710:	04c12983          	lw	s3,76(sp)
    9714:	04812a03          	lw	s4,72(sp)
    9718:	04412a83          	lw	s5,68(sp)
    971c:	04012b03          	lw	s6,64(sp)
    9720:	03c12b83          	lw	s7,60(sp)
    9724:	03812c03          	lw	s8,56(sp)
    9728:	03412c83          	lw	s9,52(sp)
    972c:	08010113          	addi	sp,sp,128
    9730:	00008067          	ret
    9734:	0d451863          	bne	a0,s4,9804 <bsp_printf+0x17c>
    9738:	00190913          	addi	s2,s2,1
    973c:	012987b3          	add	a5,s3,s2
    9740:	0007c783          	lbu	a5,0(a5)
    9744:	0e078063          	beqz	a5,9824 <bsp_printf+0x19c>
    9748:	17578263          	beq	a5,s5,98ac <bsp_printf+0x224>
    974c:	04fb6c63          	bltu	s6,a5,97a4 <bsp_printf+0x11c>
    9750:	0b778263          	beq	a5,s7,97f4 <bsp_printf+0x16c>
    9754:	06400713          	li	a4,100
    9758:	0ee78063          	beq	a5,a4,9838 <bsp_printf+0x1b0>
    975c:	05800713          	li	a4,88
    9760:	fce79ce3          	bne	a5,a4,9738 <bsp_printf+0xb0>
    9764:	00c12783          	lw	a5,12(sp)
    9768:	0000d4b7          	lui	s1,0xd
    976c:	01c00413          	li	s0,28
    9770:	0007ac83          	lw	s9,0(a5)
    9774:	00478713          	addi	a4,a5,4
    9778:	00e12623          	sw	a4,12(sp)
    977c:	2e048493          	addi	s1,s1,736 # d2e0 <_data+0x4c>
    9780:	ffc00c13          	li	s8,-4
    9784:	008cd7b3          	srl	a5,s9,s0
    9788:	00f7f793          	andi	a5,a5,15
    978c:	00f487b3          	add	a5,s1,a5
    9790:	0007c503          	lbu	a0,0(a5)
    9794:	ffc40413          	addi	s0,s0,-4
    9798:	ecdff0ef          	jal	9664 <_putchar>
    979c:	ff8414e3          	bne	s0,s8,9784 <bsp_printf+0xfc>
    97a0:	0840006f          	j	9824 <bsp_printf+0x19c>
    97a4:	07300713          	li	a4,115
    97a8:	06e78263          	beq	a5,a4,980c <bsp_printf+0x184>
    97ac:	07800713          	li	a4,120
    97b0:	f8e794e3          	bne	a5,a4,9738 <bsp_printf+0xb0>
    97b4:	00c12783          	lw	a5,12(sp)
    97b8:	0000d4b7          	lui	s1,0xd
    97bc:	01c00413          	li	s0,28
    97c0:	0007ac83          	lw	s9,0(a5)
    97c4:	00478713          	addi	a4,a5,4
    97c8:	00e12623          	sw	a4,12(sp)
    97cc:	2f448493          	addi	s1,s1,756 # d2f4 <_data+0x60>
    97d0:	ffc00c13          	li	s8,-4
    97d4:	008cd7b3          	srl	a5,s9,s0
    97d8:	00f7f793          	andi	a5,a5,15
    97dc:	00f487b3          	add	a5,s1,a5
    97e0:	0007c503          	lbu	a0,0(a5)
    97e4:	ffc40413          	addi	s0,s0,-4
    97e8:	e7dff0ef          	jal	9664 <_putchar>
    97ec:	ff8414e3          	bne	s0,s8,97d4 <bsp_printf+0x14c>
    97f0:	0340006f          	j	9824 <bsp_printf+0x19c>
    97f4:	00c12783          	lw	a5,12(sp)
    97f8:	0007c503          	lbu	a0,0(a5)
    97fc:	00478713          	addi	a4,a5,4
    9800:	00e12623          	sw	a4,12(sp)
    9804:	e61ff0ef          	jal	9664 <_putchar>
    9808:	01c0006f          	j	9824 <bsp_printf+0x19c>
    980c:	00c12783          	lw	a5,12(sp)
    9810:	0007a403          	lw	s0,0(a5)
    9814:	00478713          	addi	a4,a5,4
    9818:	00e12623          	sw	a4,12(sp)
    981c:	00044503          	lbu	a0,0(s0)
    9820:	00051663          	bnez	a0,982c <bsp_printf+0x1a4>
    9824:	00190913          	addi	s2,s2,1
    9828:	ecdff06f          	j	96f4 <bsp_printf+0x6c>
    982c:	00140413          	addi	s0,s0,1
    9830:	e35ff0ef          	jal	9664 <_putchar>
    9834:	fe9ff06f          	j	981c <bsp_printf+0x194>
    9838:	00c12783          	lw	a5,12(sp)
    983c:	0007a483          	lw	s1,0(a5)
    9840:	00478713          	addi	a4,a5,4
    9844:	00e12623          	sw	a4,12(sp)
    9848:	0004d863          	bgez	s1,9858 <bsp_printf+0x1d0>
    984c:	02d00513          	li	a0,45
    9850:	e15ff0ef          	jal	9664 <_putchar>
    9854:	409004b3          	neg	s1,s1
    9858:	01010413          	addi	s0,sp,16
    985c:	00040c13          	mv	s8,s0
    9860:	00a00713          	li	a4,10
    9864:	00049e63          	bnez	s1,9880 <bsp_printf+0x1f8>
    9868:	01840c63          	beq	s0,s8,9880 <bsp_printf+0x1f8>
    986c:	fff44503          	lbu	a0,-1(s0)
    9870:	fff40413          	addi	s0,s0,-1
    9874:	df1ff0ef          	jal	9664 <_putchar>
    9878:	ff841ae3          	bne	s0,s8,986c <bsp_printf+0x1e4>
    987c:	fa9ff06f          	j	9824 <bsp_printf+0x19c>
    9880:	02e4e7b3          	rem	a5,s1,a4
    9884:	00140413          	addi	s0,s0,1
    9888:	03078793          	addi	a5,a5,48
    988c:	02e4c4b3          	div	s1,s1,a4
    9890:	fef40fa3          	sb	a5,-1(s0)
    9894:	fd1ff06f          	j	9864 <bsp_printf+0x1dc>
    9898:	00140413          	addi	s0,s0,1
    989c:	dc9ff0ef          	jal	9664 <_putchar>
    98a0:	00044503          	lbu	a0,0(s0)
    98a4:	fe051ae3          	bnez	a0,9898 <bsp_printf+0x210>
    98a8:	f7dff06f          	j	9824 <bsp_printf+0x19c>
    98ac:	0000d437          	lui	s0,0xd
    98b0:	29440413          	addi	s0,s0,660 # d294 <_data>
    98b4:	fedff06f          	j	98a0 <bsp_printf+0x218>

000098b8 <v3_build_gpu_scene>:
    98b8:	10050263          	beqz	a0,99bc <v3_build_gpu_scene+0x104>
    98bc:	fc010113          	addi	sp,sp,-64
    98c0:	02812c23          	sw	s0,56(sp)
    98c4:	02112e23          	sw	ra,60(sp)
    98c8:	02912a23          	sw	s1,52(sp)
    98cc:	03212823          	sw	s2,48(sp)
    98d0:	00078413          	mv	s0,a5
    98d4:	0e078863          	beqz	a5,99c4 <v3_build_gpu_scene+0x10c>
    98d8:	00080493          	mv	s1,a6
    98dc:	0e080463          	beqz	a6,99c4 <v3_build_gpu_scene+0x10c>
    98e0:	00100913          	li	s2,1
    98e4:	0ed96063          	bltu	s2,a3,99c4 <v3_build_gpu_scene+0x10c>
    98e8:	00082023          	sw	zero,0(a6)
    98ec:	00050313          	mv	t1,a0
    98f0:	00058e13          	mv	t3,a1
    98f4:	00060e93          	mv	t4,a2
    98f8:	08068263          	beqz	a3,997c <v3_build_gpu_scene+0xc4>
    98fc:	000057b7          	lui	a5,0x5
    9900:	00f507b3          	add	a5,a0,a5
    9904:	0297c783          	lbu	a5,41(a5) # 5029 <bullet_enemy_position+0x71>
    9908:	06079a63          	bnez	a5,997c <v3_build_gpu_scene+0xc4>
    990c:	01c10793          	addi	a5,sp,28
    9910:	00070893          	mv	a7,a4
    9914:	00f12023          	sw	a5,0(sp)
    9918:	00100713          	li	a4,1
    991c:	04800793          	li	a5,72
    9920:	48900813          	li	a6,1161
    9924:	00100693          	li	a3,1
    9928:	6bc020ef          	jal	bfe4 <gpu_instances_build_into>
    992c:	00009737          	lui	a4,0x9
    9930:	00e407b3          	add	a5,s0,a4
    9934:	01c12703          	lw	a4,28(sp)
    9938:	12e7a023          	sw	a4,288(a5)
    993c:	02012703          	lw	a4,32(sp)
    9940:	12e7a223          	sw	a4,292(a5)
    9944:	02812703          	lw	a4,40(sp)
    9948:	12e7a423          	sw	a4,296(a5)
    994c:	02412703          	lw	a4,36(sp)
    9950:	12e7a623          	sw	a4,300(a5)
    9954:	02c12703          	lw	a4,44(sp)
    9958:	12e7a823          	sw	a4,304(a5)
    995c:	00051463          	bnez	a0,9964 <v3_build_gpu_scene+0xac>
    9960:	0124a023          	sw	s2,0(s1)
    9964:	03c12083          	lw	ra,60(sp)
    9968:	03812403          	lw	s0,56(sp)
    996c:	03412483          	lw	s1,52(sp)
    9970:	03012903          	lw	s2,48(sp)
    9974:	04010113          	addi	sp,sp,64
    9978:	00008067          	ret
    997c:	00040793          	mv	a5,s0
    9980:	48900713          	li	a4,1161
    9984:	00100693          	li	a3,1
    9988:	000e8613          	mv	a2,t4
    998c:	000e0593          	mv	a1,t3
    9990:	00030513          	mv	a0,t1
    9994:	fa8fe0ef          	jal	813c <game_build>
    9998:	fc0516e3          	bnez	a0,9964 <v3_build_gpu_scene+0xac>
    999c:	00040513          	mv	a0,s0
    99a0:	03812403          	lw	s0,56(sp)
    99a4:	03c12083          	lw	ra,60(sp)
    99a8:	03412483          	lw	s1,52(sp)
    99ac:	03012903          	lw	s2,48(sp)
    99b0:	04800593          	li	a1,72
    99b4:	04010113          	addi	sp,sp,64
    99b8:	d4dfc06f          	j	6704 <bullet_clip_background_for_hud>
    99bc:	ff800513          	li	a0,-8
    99c0:	00008067          	ret
    99c4:	ff800513          	li	a0,-8
    99c8:	f9dff06f          	j	9964 <v3_build_gpu_scene+0xac>

000099cc <v3_apply_game_command>:
    99cc:	02051463          	bnez	a0,99f4 <v3_apply_game_command+0x28>
    99d0:	ff800513          	li	a0,-8
    99d4:	00008067          	ret
    99d8:	ff800513          	li	a0,-8
    99dc:	02c12083          	lw	ra,44(sp)
    99e0:	02812403          	lw	s0,40(sp)
    99e4:	02412483          	lw	s1,36(sp)
    99e8:	02012903          	lw	s2,32(sp)
    99ec:	03010113          	addi	sp,sp,48
    99f0:	00008067          	ret
    99f4:	fd010113          	addi	sp,sp,-48
    99f8:	02812423          	sw	s0,40(sp)
    99fc:	02112623          	sw	ra,44(sp)
    9a00:	02912223          	sw	s1,36(sp)
    9a04:	03212023          	sw	s2,32(sp)
    9a08:	00060413          	mv	s0,a2
    9a0c:	fc0606e3          	beqz	a2,99d8 <v3_apply_game_command+0xc>
    9a10:	00058493          	mv	s1,a1
    9a14:	00050913          	mv	s2,a0
    9a18:	00c10593          	addi	a1,sp,12
    9a1c:	00048513          	mv	a0,s1
    9a20:	cd5fd0ef          	jal	76f4 <nc_take_game>
    9a24:	00100793          	li	a5,1
    9a28:	faf518e3          	bne	a0,a5,99d8 <v3_apply_game_command+0xc>
    9a2c:	0164c783          	lbu	a5,22(s1)
    9a30:	fa0784e3          	beqz	a5,99d8 <v3_apply_game_command+0xc>
    9a34:	00042683          	lw	a3,0(s0)
    9a38:	0044a783          	lw	a5,4(s1)
    9a3c:	f8f69ee3          	bne	a3,a5,99d8 <v3_apply_game_command+0xc>
    9a40:	00c12783          	lw	a5,12(sp)
    9a44:	f8f69ae3          	bne	a3,a5,99d8 <v3_apply_game_command+0xc>
    9a48:	01042703          	lw	a4,16(s0)
    9a4c:	01c12783          	lw	a5,28(sp)
    9a50:	f8f714e3          	bne	a4,a5,99d8 <v3_apply_game_command+0xc>
    9a54:	00842583          	lw	a1,8(s0)
    9a58:	01412783          	lw	a5,20(sp)
    9a5c:	f6f59ee3          	bne	a1,a5,99d8 <v3_apply_game_command+0xc>
    9a60:	00c42603          	lw	a2,12(s0)
    9a64:	01812783          	lw	a5,24(sp)
    9a68:	f6f618e3          	bne	a2,a5,99d8 <v3_apply_game_command+0xc>
    9a6c:	00442703          	lw	a4,4(s0)
    9a70:	00090513          	mv	a0,s2
    9a74:	ca4ff0ef          	jal	8f18 <v3_runtime_game_command>
    9a78:	00050913          	mv	s2,a0
    9a7c:	00200613          	li	a2,2
    9a80:	00054463          	bltz	a0,9a88 <v3_apply_game_command+0xbc>
    9a84:	00a03633          	snez	a2,a0
    9a88:	00040593          	mv	a1,s0
    9a8c:	00048513          	mv	a0,s1
    9a90:	cd5fd0ef          	jal	7764 <nc_complete_game>
    9a94:	f40544e3          	bltz	a0,99dc <v3_apply_game_command+0x10>
    9a98:	00090513          	mv	a0,s2
    9a9c:	f52050e3          	blez	s2,99dc <v3_apply_game_command+0x10>
    9aa0:	00000513          	li	a0,0
    9aa4:	f39ff06f          	j	99dc <v3_apply_game_command+0x10>

00009aa8 <v3_demo_run>:
    9aa8:	a8010113          	addi	sp,sp,-1408
    9aac:	55a12823          	sw	s10,1360(sp)
    9ab0:	02a12a23          	sw	a0,52(sp)
    9ab4:	02c12e23          	sw	a2,60(sp)
    9ab8:	00058d13          	mv	s10,a1
    9abc:	01800613          	li	a2,24
    9ac0:	00000593          	li	a1,0
    9ac4:	18c10513          	addi	a0,sp,396
    9ac8:	56812c23          	sw	s0,1400(sp)
    9acc:	56112e23          	sw	ra,1404(sp)
    9ad0:	56912a23          	sw	s1,1396(sp)
    9ad4:	57212823          	sw	s2,1392(sp)
    9ad8:	57312623          	sw	s3,1388(sp)
    9adc:	57412423          	sw	s4,1384(sp)
    9ae0:	57512223          	sw	s5,1380(sp)
    9ae4:	57612023          	sw	s6,1376(sp)
    9ae8:	55712e23          	sw	s7,1372(sp)
    9aec:	55812c23          	sw	s8,1368(sp)
    9af0:	55912a23          	sw	s9,1364(sp)
    9af4:	55b12623          	sw	s11,1356(sp)
    9af8:	00068413          	mv	s0,a3
    9afc:	02e12c23          	sw	a4,56(sp)
    9b00:	04f12623          	sw	a5,76(sp)
    9b04:	12012823          	sw	zero,304(sp)
    9b08:	12012a23          	sw	zero,308(sp)
    9b0c:	12012c23          	sw	zero,312(sp)
    9b10:	12012e23          	sw	zero,316(sp)
    9b14:	14012023          	sw	zero,320(sp)
    9b18:	f10f70ef          	jal	1228 <memset>
    9b1c:	f81005b7          	lui	a1,0xf8100
    9b20:	46010513          	addi	a0,sp,1120
    9b24:	f4cfd0ef          	jal	7270 <nc_init>
    9b28:	04050c63          	beqz	a0,9b80 <v3_demo_run+0xd8>
    9b2c:	00050593          	mv	a1,a0
    9b30:	0000d537          	lui	a0,0xd
    9b34:	5f450513          	addi	a0,a0,1524 # d5f4 <_data+0x360>
    9b38:	b51ff0ef          	jal	9688 <bsp_printf>
    9b3c:	00100d93          	li	s11,1
    9b40:	57c12083          	lw	ra,1404(sp)
    9b44:	57812403          	lw	s0,1400(sp)
    9b48:	57412483          	lw	s1,1396(sp)
    9b4c:	57012903          	lw	s2,1392(sp)
    9b50:	56c12983          	lw	s3,1388(sp)
    9b54:	56812a03          	lw	s4,1384(sp)
    9b58:	56412a83          	lw	s5,1380(sp)
    9b5c:	56012b03          	lw	s6,1376(sp)
    9b60:	55c12b83          	lw	s7,1372(sp)
    9b64:	55812c03          	lw	s8,1368(sp)
    9b68:	55412c83          	lw	s9,1364(sp)
    9b6c:	55012d03          	lw	s10,1360(sp)
    9b70:	000d8513          	mv	a0,s11
    9b74:	54c12d83          	lw	s11,1356(sp)
    9b78:	58010113          	addi	sp,sp,1408
    9b7c:	00008067          	ret
    9b80:	0001d737          	lui	a4,0x1d
    9b84:	86c70793          	addi	a5,a4,-1940 # 1c86c <physical_hud>
    9b88:	20078623          	sb	zero,524(a5)
    9b8c:	10078223          	sb	zero,260(a5)
    9b90:	02d107b7          	lui	a5,0x2d10
    9b94:	01478793          	addi	a5,a5,20 # 2d10014 <__gpu_framebuffer_a+0xd10014>
    9b98:	0007a783          	lw	a5,0(a5)
    9b9c:	86c70713          	addi	a4,a4,-1940
    9ba0:	08e12623          	sw	a4,140(sp)
    9ba4:	06f12c23          	sw	a5,120(sp)
    9ba8:	07812703          	lw	a4,120(sp)
    9bac:	00100793          	li	a5,1
    9bb0:	f8e7e6e3          	bltu	a5,a4,9b3c <v3_demo_run+0x94>
    9bb4:	07812583          	lw	a1,120(sp)
    9bb8:	0000d537          	lui	a0,0xd
    9bbc:	62850513          	addi	a0,a0,1576 # d628 <_data+0x394>
    9bc0:	ac9ff0ef          	jal	9688 <bsp_printf>
    9bc4:	03c12603          	lw	a2,60(sp)
    9bc8:	03412583          	lw	a1,52(sp)
    9bcc:	12810513          	addi	a0,sp,296
    9bd0:	0c9020ef          	jal	c498 <gpu_frame_list_init>
    9bd4:	06a12a23          	sw	a0,116(sp)
    9bd8:	f60512e3          	bnez	a0,9b3c <v3_demo_run+0x94>
    9bdc:	12e14583          	lbu	a1,302(sp)
    9be0:	00058e63          	beqz	a1,9bfc <v3_demo_run+0x154>
    9be4:	02d107b7          	lui	a5,0x2d10
    9be8:	00478793          	addi	a5,a5,4 # 2d10004 <__gpu_framebuffer_a+0xd10004>
    9bec:	0007a783          	lw	a5,0(a5)
    9bf0:	fff78793          	addi	a5,a5,-1
    9bf4:	0017b793          	seqz	a5,a5
    9bf8:	06f12a23          	sw	a5,116(sp)
    9bfc:	07412603          	lw	a2,116(sp)
    9c00:	0000d537          	lui	a0,0xd
    9c04:	64450513          	addi	a0,a0,1604 # d644 <_data+0x3b0>
    9c08:	a81ff0ef          	jal	9688 <bsp_printf>
    9c0c:	000306b7          	lui	a3,0x30
    9c10:	00268693          	addi	a3,a3,2 # 30002 <__freertos_irq_stack_top+0x12582>
    9c14:	00700613          	li	a2,7
    9c18:	40000593          	li	a1,1024
    9c1c:	02d00537          	lui	a0,0x2d00
    9c20:	920ff0ef          	jal	8d40 <v3_runtime_init>
    9c24:	04a12023          	sw	a0,64(sp)
    9c28:	f0051ae3          	bnez	a0,9b3c <v3_demo_run+0x94>
    9c2c:	02d107b7          	lui	a5,0x2d10
    9c30:	00c7a583          	lw	a1,12(a5) # 2d1000c <__gpu_framebuffer_a+0xd1000c>
    9c34:	eff5f793          	andi	a5,a1,-257
    9c38:	f00792e3          	bnez	a5,9b3c <v3_demo_run+0x94>
    9c3c:	02d0f7b7          	lui	a5,0x2d0f
    9c40:	0000d537          	lui	a0,0xd
    9c44:	54b79a23          	sh	a1,1364(a5) # 2d0f554 <__gpu_framebuffer_a+0xd0f554>
    9c48:	66c50513          	addi	a0,a0,1644 # d66c <_data+0x3d8>
    9c4c:	a3dff0ef          	jal	9688 <bsp_printf>
    9c50:	02d107b7          	lui	a5,0x2d10
    9c54:	0007a783          	lw	a5,0(a5) # 2d10000 <__gpu_framebuffer_a+0xd10000>
    9c58:	0000d537          	lui	a0,0xd
    9c5c:	68850513          	addi	a0,a0,1672 # d688 <_data+0x3f4>
    9c60:	fff78593          	addi	a1,a5,-1
    9c64:	0015b593          	seqz	a1,a1
    9c68:	04f12823          	sw	a5,80(sp)
    9c6c:	a1dff0ef          	jal	9688 <bsp_printf>
    9c70:	05012703          	lw	a4,80(sp)
    9c74:	00100793          	li	a5,1
    9c78:	00f71e63          	bne	a4,a5,9c94 <v3_demo_run+0x1ec>
    9c7c:	02d107b7          	lui	a5,0x2d10
    9c80:	00878793          	addi	a5,a5,8 # 2d10008 <__gpu_framebuffer_a+0xd10008>
    9c84:	0007a783          	lw	a5,0(a5)
    9c88:	fff78793          	addi	a5,a5,-1
    9c8c:	0017b793          	seqz	a5,a5
    9c90:	04f12023          	sw	a5,64(sp)
    9c94:	04012583          	lw	a1,64(sp)
    9c98:	0000d537          	lui	a0,0xd
    9c9c:	6a450513          	addi	a0,a0,1700 # d6a4 <_data+0x410>
    9ca0:	9e9ff0ef          	jal	9688 <bsp_printf>
    9ca4:	03412503          	lw	a0,52(sp)
    9ca8:	00100693          	li	a3,1
    9cac:	60000613          	li	a2,1536
    9cb0:	10000593          	li	a1,256
    9cb4:	fbcf80ef          	jal	2470 <gpu_set_qos>
    9cb8:	e80512e3          	bnez	a0,9b3c <v3_demo_run+0x94>
    9cbc:	03812503          	lw	a0,56(sp)
    9cc0:	02000613          	li	a2,32
    9cc4:	00000593          	li	a1,0
    9cc8:	004d2483          	lw	s1,4(s10)
    9ccc:	d5cf70ef          	jal	1228 <memset>
    9cd0:	03812783          	lw	a5,56(sp)
    9cd4:	03812703          	lw	a4,56(sp)
    9cd8:	03412503          	lw	a0,52(sp)
    9cdc:	0097a223          	sw	s1,4(a5)
    9ce0:	78000793          	li	a5,1920
    9ce4:	00f72623          	sw	a5,12(a4)
    9ce8:	021c07b7          	lui	a5,0x21c0
    9cec:	3c078793          	addi	a5,a5,960 # 21c03c0 <__gpu_framebuffer_a+0x1c03c0>
    9cf0:	00f72823          	sw	a5,16(a4)
    9cf4:	009896b7          	lui	a3,0x989
    9cf8:	00100793          	li	a5,1
    9cfc:	00f70e23          	sb	a5,28(a4)
    9d00:	68068693          	addi	a3,a3,1664 # 989680 <__freertos_irq_stack_top+0x96bc00>
    9d04:	00100613          	li	a2,1
    9d08:	00070593          	mv	a1,a4
    9d0c:	eadfa0ef          	jal	4bb8 <perf_render_gpu>
    9d10:	e20516e3          	bnez	a0,9b3c <v3_demo_run+0x94>
    9d14:	03412503          	lw	a0,52(sp)
    9d18:	00989637          	lui	a2,0x989
    9d1c:	68060613          	addi	a2,a2,1664 # 989680 <__freertos_irq_stack_top+0x96bc00>
    9d20:	000d0593          	mv	a1,s10
    9d24:	ffdf80ef          	jal	2d20 <framebuffer_present>
    9d28:	e0051ae3          	bnez	a0,9b3c <v3_demo_run+0x94>
    9d2c:	9c8f90ef          	jal	2ef4 <hud_set_logo_enabled>
    9d30:	01800613          	li	a2,24
    9d34:	00000593          	li	a1,0
    9d38:	15810513          	addi	a0,sp,344
    9d3c:	cecf70ef          	jal	1228 <memset>
    9d40:	ae9f70ef          	jal	1828 <gpu_platform_cycles>
    9d44:	03c12783          	lw	a5,60(sp)
    9d48:	00050613          	mv	a2,a0
    9d4c:	feb00713          	li	a4,-21
    9d50:	02078e63          	beqz	a5,9d8c <v3_demo_run+0x2e4>
    9d54:	00051463          	bnez	a0,9d5c <v3_demo_run+0x2b4>
    9d58:	00100613          	li	a2,1
    9d5c:	b4cc7837          	lui	a6,0xb4cc7
    9d60:	000077b7          	lui	a5,0x7
    9d64:	05f5e5b7          	lui	a1,0x5f5e
    9d68:	02c50737          	lui	a4,0x2c50
    9d6c:	15810893          	addi	a7,sp,344
    9d70:	85380813          	addi	a6,a6,-1965 # b4cc6853 <__gpu_framebuffer_a+0xb2cc6853>
    9d74:	d6078793          	addi	a5,a5,-672 # 6d60 <bullet_init_local_assets+0x320>
    9d78:	06700693          	li	a3,103
    9d7c:	10058593          	addi	a1,a1,256 # 5f5e100 <__gpu_framebuffer_a+0x3f5e100>
    9d80:	f8100537          	lui	a0,0xf8100
    9d84:	f5cfa0ef          	jal	44e0 <network_asset_fetch>
    9d88:	00050713          	mv	a4,a0
    9d8c:	00173793          	seqz	a5,a4
    9d90:	00078513          	mv	a0,a5
    9d94:	04e12423          	sw	a4,72(sp)
    9d98:	04f12223          	sw	a5,68(sp)
    9d9c:	958f90ef          	jal	2ef4 <hud_set_logo_enabled>
    9da0:	04c12783          	lw	a5,76(sp)
    9da4:	04812703          	lw	a4,72(sp)
    9da8:	16012683          	lw	a3,352(sp)
    9dac:	15812603          	lw	a2,344(sp)
    9db0:	10078223          	sb	zero,260(a5)
    9db4:	04412783          	lw	a5,68(sp)
    9db8:	0000d537          	lui	a0,0xd
    9dbc:	06700593          	li	a1,103
    9dc0:	6c050513          	addi	a0,a0,1728 # d6c0 <_data+0x42c>
    9dc4:	8c5ff0ef          	jal	9688 <bsp_printf>
    9dc8:	03400613          	li	a2,52
    9dcc:	00000593          	li	a1,0
    9dd0:	1dc10513          	addi	a0,sp,476
    9dd4:	c54f70ef          	jal	1228 <memset>
    9dd8:	03c14783          	lbu	a5,60(sp)
    9ddc:	06400613          	li	a2,100
    9de0:	00000593          	li	a1,0
    9de4:	0cf12223          	sw	a5,196(sp)
    9de8:	1ef108a3          	sb	a5,497(sp)
    9dec:	38410513          	addi	a0,sp,900
    9df0:	00100793          	li	a5,1
    9df4:	1ef10923          	sb	a5,498(sp)
    9df8:	20f10123          	sb	a5,514(sp)
    9dfc:	c2cf70ef          	jal	1228 <memset>
    9e00:	202617b7          	lui	a5,0x20261
    9e04:	01578793          	addi	a5,a5,21 # 20261015 <__gpu_framebuffer_a+0x1e261015>
    9e08:	36f12e23          	sw	a5,892(sp)
    9e0c:	000307b7          	lui	a5,0x30
    9e10:	00278793          	addi	a5,a5,2 # 30002 <__freertos_irq_stack_top+0x12582>
    9e14:	01800613          	li	a2,24
    9e18:	00000593          	li	a1,0
    9e1c:	17010513          	addi	a0,sp,368
    9e20:	38f12023          	sw	a5,896(sp)
    9e24:	c04f70ef          	jal	1228 <memset>
    9e28:	01800613          	li	a2,24
    9e2c:	00000593          	li	a1,0
    9e30:	1a410513          	addi	a0,sp,420
    9e34:	bf4f70ef          	jal	1228 <memset>
    9e38:	02d0f4b7          	lui	s1,0x2d0f
    9e3c:	5794c783          	lbu	a5,1401(s1) # 2d0f579 <__gpu_framebuffer_a+0xd0f579>
    9e40:	1af10ba3          	sb	a5,439(sp)
    9e44:	00600793          	li	a5,6
    9e48:	1af10c23          	sb	a5,440(sp)
    9e4c:	9ddf70ef          	jal	1828 <gpu_platform_cycles>
    9e50:	00050913          	mv	s2,a0
    9e54:	03412503          	lw	a0,52(sp)
    9e58:	00058993          	mv	s3,a1
    9e5c:	21010593          	addi	a1,sp,528
    9e60:	f64f80ef          	jal	25c4 <gpu_read_perf_snapshot>
    9e64:	cc051ce3          	bnez	a0,9b3c <v3_demo_run+0x94>
    9e68:	23812783          	lw	a5,568(sp)
    9e6c:	23c12603          	lw	a2,572(sp)
    9e70:	0000d537          	lui	a0,0xd
    9e74:	00078593          	mv	a1,a5
    9e78:	6fc50513          	addi	a0,a0,1788 # d6fc <_data+0x468>
    9e7c:	0af12a23          	sw	a5,180(sp)
    9e80:	809ff0ef          	jal	9688 <bsp_printf>
    9e84:	03412503          	lw	a0,52(sp)
    9e88:	25810593          	addi	a1,sp,600
    9e8c:	f38f80ef          	jal	25c4 <gpu_read_perf_snapshot>
    9e90:	04a12223          	sw	a0,68(sp)
    9e94:	ca0514e3          	bnez	a0,9b3c <v3_demo_run+0x94>
    9e98:	28012783          	lw	a5,640(sp)
    9e9c:	000015b7          	lui	a1,0x1
    9ea0:	0000d537          	lui	a0,0xd
    9ea4:	0cf12e23          	sw	a5,220(sp)
    9ea8:	28412783          	lw	a5,644(sp)
    9eac:	e1058593          	addi	a1,a1,-496 # e10 <CUSTOM2+0xdb5>
    9eb0:	72c50513          	addi	a0,a0,1836 # d72c <_data+0x498>
    9eb4:	0ef12623          	sw	a5,236(sp)
    9eb8:	fd0ff0ef          	jal	9688 <bsp_printf>
    9ebc:	5774c783          	lbu	a5,1399(s1)
    9ec0:	14078463          	beqz	a5,a008 <v3_demo_run+0x560>
    9ec4:	04412803          	lw	a6,68(sp)
    9ec8:	0000d7b7          	lui	a5,0xd
    9ecc:	5dc78793          	addi	a5,a5,1500 # d5dc <_data+0x348>
    9ed0:	03c12683          	lw	a3,60(sp)
    9ed4:	00030637          	lui	a2,0x30
    9ed8:	202615b7          	lui	a1,0x20261
    9edc:	0000d537          	lui	a0,0xd
    9ee0:	02d00737          	lui	a4,0x2d00
    9ee4:	00260613          	addi	a2,a2,2 # 30002 <__freertos_irq_stack_top+0x12582>
    9ee8:	01558593          	addi	a1,a1,21 # 20261015 <__gpu_framebuffer_a+0x1e261015>
    9eec:	76050513          	addi	a0,a0,1888 # d760 <_data+0x4cc>
    9ef0:	f98ff0ef          	jal	9688 <bsp_printf>
    9ef4:	00000b93          	li	s7,0
    9ef8:	06012223          	sw	zero,100(sp)
    9efc:	0a012823          	sw	zero,176(sp)
    9f00:	06012823          	sw	zero,112(sp)
    9f04:	08012c23          	sw	zero,152(sp)
    9f08:	06012423          	sw	zero,104(sp)
    9f0c:	08012e23          	sw	zero,156(sp)
    9f10:	08012a23          	sw	zero,148(sp)
    9f14:	0a012623          	sw	zero,172(sp)
    9f18:	0a012423          	sw	zero,168(sp)
    9f1c:	08012823          	sw	zero,144(sp)
    9f20:	04012a23          	sw	zero,84(sp)
    9f24:	06012623          	sw	zero,108(sp)
    9f28:	04012223          	sw	zero,68(sp)
    9f2c:	04012423          	sw	zero,72(sp)
    9f30:	06012023          	sw	zero,96(sp)
    9f34:	00090493          	mv	s1,s2
    9f38:	00098a13          	mv	s4,s3
    9f3c:	0c012a23          	sw	zero,212(sp)
    9f40:	0c012823          	sw	zero,208(sp)
    9f44:	04012e23          	sw	zero,92(sp)
    9f48:	04012c23          	sw	zero,88(sp)
    9f4c:	0a012023          	sw	zero,160(sp)
    9f50:	08012423          	sw	zero,136(sp)
    9f54:	0c012023          	sw	zero,192(sp)
    9f58:	08012223          	sw	zero,132(sp)
    9f5c:	0a012e23          	sw	zero,188(sp)
    9f60:	08012023          	sw	zero,128(sp)
    9f64:	0a012c23          	sw	zero,184(sp)
    9f68:	03412503          	lw	a0,52(sp)
    9f6c:	2a010593          	addi	a1,sp,672
    9f70:	e54f80ef          	jal	25c4 <gpu_read_perf_snapshot>
    9f74:	00050b13          	mv	s6,a0
    9f78:	00050463          	beqz	a0,9f80 <v3_demo_run+0x4d8>
    9f7c:	0b40106f          	j	b030 <v3_demo_run+0x1588>
    9f80:	ebcff0ef          	jal	963c <now_ms>
    9f84:	00050593          	mv	a1,a0
    9f88:	13010613          	addi	a2,sp,304
    9f8c:	46010513          	addi	a0,sp,1120
    9f90:	ba4fd0ef          	jal	7334 <nc_poll>
    9f94:	00050d93          	mv	s11,a0
    9f98:	04054a63          	bltz	a0,9fec <v3_demo_run+0x544>
    9f9c:	13010593          	addi	a1,sp,304
    9fa0:	18c10513          	addi	a0,sp,396
    9fa4:	d81fd0ef          	jal	7d24 <input_update>
    9fa8:	14410593          	addi	a1,sp,324
    9fac:	46010513          	addi	a0,sp,1120
    9fb0:	f44fd0ef          	jal	76f4 <nc_take_game>
    9fb4:	00050d93          	mv	s11,a0
    9fb8:	02054a63          	bltz	a0,9fec <v3_demo_run+0x544>
    9fbc:	04050e63          	beqz	a0,a018 <v3_demo_run+0x570>
    9fc0:	14410613          	addi	a2,sp,324
    9fc4:	46010593          	addi	a1,sp,1120
    9fc8:	02d00537          	lui	a0,0x2d00
    9fcc:	a01ff0ef          	jal	99cc <v3_apply_game_command>
    9fd0:	00050d93          	mv	s11,a0
    9fd4:	04055263          	bgez	a0,a018 <v3_demo_run+0x570>
    9fd8:	e64ff0ef          	jal	963c <now_ms>
    9fdc:	00050613          	mv	a2,a0
    9fe0:	00000593          	li	a1,0
    9fe4:	46010513          	addi	a0,sp,1120
    9fe8:	83dfd0ef          	jal	7824 <nc_try_publish>
    9fec:	03412783          	lw	a5,52(sp)
    9ff0:	0000e537          	lui	a0,0xe
    9ff4:	000d8593          	mv	a1,s11
    9ff8:	0137c603          	lbu	a2,19(a5)
    9ffc:	9f450513          	addi	a0,a0,-1548 # d9f4 <_data+0x760>
    a000:	e88ff0ef          	jal	9688 <bsp_printf>
    a004:	b39ff06f          	j	9b3c <v3_demo_run+0x94>
    a008:	0000d7b7          	lui	a5,0xd
    a00c:	5e478793          	addi	a5,a5,1508 # d5e4 <_data+0x350>
    a010:	40000813          	li	a6,1024
    a014:	ebdff06f          	j	9ed0 <v3_demo_run+0x428>
    a018:	e24ff0ef          	jal	963c <now_ms>
    a01c:	00050613          	mv	a2,a0
    a020:	00000593          	li	a1,0
    a024:	46010513          	addi	a0,sp,1120
    a028:	ffcfd0ef          	jal	7824 <nc_try_publish>
    a02c:	ffcf70ef          	jal	1828 <gpu_platform_cycles>
    a030:	04012783          	lw	a5,64(sp)
    a034:	06a12e23          	sw	a0,124(sp)
    a038:	0eb12023          	sw	a1,224(sp)
    a03c:	12011123          	sh	zero,290(sp)
    a040:	40950533          	sub	a0,a0,s1
    a044:	41458a33          	sub	s4,a1,s4
    a048:	66078863          	beqz	a5,a6b8 <v3_demo_run+0xc10>
    a04c:	07c12783          	lw	a5,124(sp)
    a050:	06400613          	li	a2,100
    a054:	00000693          	li	a3,0
    a058:	00a7b5b3          	sltu	a1,a5,a0
    a05c:	40ba05b3          	sub	a1,s4,a1
    a060:	115020ef          	jal	c974 <__udivdi3>
    a064:	02d0f7b7          	lui	a5,0x2d0f
    a068:	5727c603          	lbu	a2,1394(a5) # 2d0f572 <__gpu_framebuffer_a+0xd0f572>
    a06c:	00100693          	li	a3,1
    a070:	004d2703          	lw	a4,4(s10)
    a074:	00050493          	mv	s1,a0
    a078:	5ed60463          	beq	a2,a3,a660 <v3_demo_run+0xbb8>
    a07c:	5777c683          	lbu	a3,1399(a5)
    a080:	00068663          	beqz	a3,a08c <v3_demo_run+0x5e4>
    a084:	5747c783          	lbu	a5,1396(a5)
    a088:	5c078c63          	beqz	a5,a660 <v3_demo_run+0xbb8>
    a08c:	03c12683          	lw	a3,60(sp)
    a090:	00100793          	li	a5,1
    a094:	00d7f663          	bgeu	a5,a3,a0a0 <v3_demo_run+0x5f8>
    a098:	ff800d93          	li	s11,-8
    a09c:	f51ff06f          	j	9fec <v3_demo_run+0x544>
    a0a0:	ffe007b7          	lui	a5,0xffe00
    a0a4:	fff78793          	addi	a5,a5,-1 # ffdfffff <__gpu_framebuffer_a+0xfddfffff>
    a0a8:	00f777b3          	and	a5,a4,a5
    a0ac:	020006b7          	lui	a3,0x2000
    a0b0:	fed794e3          	bne	a5,a3,a098 <v3_demo_run+0x5f0>
    a0b4:	03c12683          	lw	a3,60(sp)
    a0b8:	02b227b7          	lui	a5,0x2b22
    a0bc:	c0078793          	addi	a5,a5,-1024 # 2b21c00 <__gpu_framebuffer_a+0xb21c00>
    a0c0:	00068663          	beqz	a3,a0cc <v3_demo_run+0x624>
    a0c4:	029227b7          	lui	a5,0x2922
    a0c8:	c0078793          	addi	a5,a5,-1024 # 2921c00 <__gpu_framebuffer_a+0x921c00>
    a0cc:	1af12e23          	sw	a5,444(sp)
    a0d0:	000227b7          	lui	a5,0x22
    a0d4:	c0078793          	addi	a5,a5,-1024 # 21c00 <__freertos_irq_stack_top+0x4180>
    a0d8:	00f70733          	add	a4,a4,a5
    a0dc:	78000793          	li	a5,1920
    a0e0:	1cf12223          	sw	a5,452(sp)
    a0e4:	1cf12423          	sw	a5,456(sp)
    a0e8:	03412503          	lw	a0,52(sp)
    a0ec:	3c000793          	li	a5,960
    a0f0:	1cf11623          	sh	a5,460(sp)
    a0f4:	00989637          	lui	a2,0x989
    a0f8:	1d400793          	li	a5,468
    a0fc:	1c012c23          	sw	zero,472(sp)
    a100:	1cf11723          	sh	a5,462(sp)
    a104:	12210693          	addi	a3,sp,290
    a108:	00200793          	li	a5,2
    a10c:	68060613          	addi	a2,a2,1664 # 989680 <__freertos_irq_stack_top+0x96bc00>
    a110:	1bc10593          	addi	a1,sp,444
    a114:	1c012823          	sw	zero,464(sp)
    a118:	1c012a23          	sw	zero,468(sp)
    a11c:	1ce12023          	sw	a4,448(sp)
    a120:	1cf10c23          	sb	a5,472(sp)
    a124:	d65f70ef          	jal	1e88 <gpu_submit>
    a128:	00050d93          	mv	s11,a0
    a12c:	5e051463          	bnez	a0,a714 <v3_demo_run+0xc6c>
    a130:	04012a03          	lw	s4,64(sp)
    a134:	02d0fc37          	lui	s8,0x2d0f
    a138:	00048613          	mv	a2,s1
    a13c:	18c10593          	addi	a1,sp,396
    a140:	02d00537          	lui	a0,0x2d00
    a144:	572c4c83          	lbu	s9,1394(s8) # 2d0f572 <__gpu_framebuffer_a+0xd0f572>
    a148:	f19fe0ef          	jal	9060 <v3_runtime_advance>
    a14c:	00050d93          	mv	s11,a0
    a150:	e8054ee3          	bltz	a0,9fec <v3_demo_run+0x544>
    a154:	572c4703          	lbu	a4,1394(s8)
    a158:	500c8863          	beqz	s9,a668 <v3_demo_run+0xbc0>
    a15c:	02d0f7b7          	lui	a5,0x2d0f
    a160:	5727c703          	lbu	a4,1394(a5) # 2d0f572 <__gpu_framebuffer_a+0xd0f572>
    a164:	520a1463          	bnez	s4,a68c <v3_demo_run+0xbe4>
    a168:	00000a93          	li	s5,0
    a16c:	02d0f737          	lui	a4,0x2d0f
    a170:	57774783          	lbu	a5,1399(a4) # 2d0f577 <__gpu_framebuffer_a+0xd0f577>
    a174:	57274a03          	lbu	s4,1394(a4)
    a178:	00000493          	li	s1,0
    a17c:	00078663          	beqz	a5,a188 <v3_demo_run+0x6e0>
    a180:	57474483          	lbu	s1,1396(a4)
    a184:	0014b493          	seqz	s1,s1
    a188:	02d0f7b7          	lui	a5,0x2d0f
    a18c:	57c7a783          	lw	a5,1404(a5) # 2d0f57c <__gpu_framebuffer_a+0xd0f57c>
    a190:	0cf12423          	sw	a5,200(sp)
    a194:	09778c63          	beq	a5,s7,a22c <v3_demo_run+0x784>
    a198:	01800613          	li	a2,24
    a19c:	00000593          	li	a1,0
    a1a0:	17010513          	addi	a0,sp,368
    a1a4:	884f70ef          	jal	1228 <memset>
    a1a8:	04c12783          	lw	a5,76(sp)
    a1ac:	1a410513          	addi	a0,sp,420
    a1b0:	10078223          	sb	zero,260(a5)
    a1b4:	090010ef          	jal	b244 <game_menu_invalidate>
    a1b8:	08c12783          	lw	a5,140(sp)
    a1bc:	46010513          	addi	a0,sp,1120
    a1c0:	20078623          	sb	zero,524(a5)
    a1c4:	10078223          	sb	zero,260(a5)
    a1c8:	d8cfd0ef          	jal	7754 <nc_discard_pending_telemetry>
    a1cc:	c70ff0ef          	jal	963c <now_ms>
    a1d0:	f3850793          	addi	a5,a0,-200 # 2cfff38 <__gpu_framebuffer_a+0xcfff38>
    a1d4:	0af12023          	sw	a5,160(sp)
    a1d8:	e50f70ef          	jal	1828 <gpu_platform_cycles>
    a1dc:	00050913          	mv	s2,a0
    a1e0:	00058993          	mv	s3,a1
    a1e4:	52048e63          	beqz	s1,a720 <v3_demo_run+0xc78>
    a1e8:	0000d5b7          	lui	a1,0xd
    a1ec:	5dc58593          	addi	a1,a1,1500 # d5dc <_data+0x348>
    a1f0:	02d0f7b7          	lui	a5,0x2d0f
    a1f4:	5757c603          	lbu	a2,1397(a5) # 2d0f575 <__gpu_framebuffer_a+0xd0f575>
    a1f8:	00000693          	li	a3,0
    a1fc:	00049663          	bnez	s1,a208 <v3_demo_run+0x760>
    a200:	02d057b7          	lui	a5,0x2d05
    a204:	0087a683          	lw	a3,8(a5) # 2d05008 <__gpu_framebuffer_a+0xd05008>
    a208:	02d0f737          	lui	a4,0x2d0f
    a20c:	57674783          	lbu	a5,1398(a4) # 2d0f576 <__gpu_framebuffer_a+0xd0f576>
    a210:	57c72703          	lw	a4,1404(a4)
    a214:	0000d537          	lui	a0,0xd
    a218:	7a450513          	addi	a0,a0,1956 # d7a4 <_data+0x510>
    a21c:	c6cff0ef          	jal	9688 <bsp_printf>
    a220:	06012623          	sw	zero,108(sp)
    a224:	04012223          	sw	zero,68(sp)
    a228:	06012023          	sw	zero,96(sp)
    a22c:	020a0663          	beqz	s4,a258 <v3_demo_run+0x7b0>
    a230:	01800613          	li	a2,24
    a234:	00000593          	li	a1,0
    a238:	17010513          	addi	a0,sp,368
    a23c:	fedf60ef          	jal	1228 <memset>
    a240:	04c12783          	lw	a5,76(sp)
    a244:	06012023          	sw	zero,96(sp)
    a248:	10078223          	sb	zero,260(a5)
    a24c:	08c12783          	lw	a5,140(sp)
    a250:	20078623          	sb	zero,524(a5)
    a254:	10078223          	sb	zero,260(a5)
    a258:	05012783          	lw	a5,80(sp)
    a25c:	00100713          	li	a4,1
    a260:	00e79a63          	bne	a5,a4,a274 <v3_demo_run+0x7cc>
    a264:	00049863          	bnez	s1,a274 <v3_demo_run+0x7cc>
    a268:	56fa0463          	beq	s4,a5,a7d0 <v3_demo_run+0xd28>
    a26c:	4c0a8063          	beqz	s5,a72c <v3_demo_run+0xc84>
    a270:	00100b13          	li	s6,1
    a274:	db4f70ef          	jal	1828 <gpu_platform_cycles>
    a278:	0eb12a23          	sw	a1,244(sp)
    a27c:	0ea12823          	sw	a0,240(sp)
    a280:	12012223          	sw	zero,292(sp)
    a284:	004d2583          	lw	a1,4(s10)
    a288:	54048863          	beqz	s1,a7d8 <v3_demo_run+0xd30>
    a28c:	000097b7          	lui	a5,0x9
    a290:	00f407b3          	add	a5,s0,a5
    a294:	1207a823          	sw	zero,304(a5) # 9130 <v3_runtime_advance+0xd0>
    a298:	1207a623          	sw	zero,300(a5)
    a29c:	1207a223          	sw	zero,292(a5)
    a2a0:	1207a023          	sw	zero,288(a5)
    a2a4:	d84f70ef          	jal	1828 <gpu_platform_cycles>
    a2a8:	0ca12c23          	sw	a0,216(sp)
    a2ac:	0eb12223          	sw	a1,228(sp)
    a2b0:	d9cf70ef          	jal	184c <gpu_platform_sync>
    a2b4:	d74f70ef          	jal	1828 <gpu_platform_cycles>
    a2b8:	12412783          	lw	a5,292(sp)
    a2bc:	0ea12c23          	sw	a0,248(sp)
    a2c0:	0eb12e23          	sw	a1,252(sp)
    a2c4:	0cf12623          	sw	a5,204(sp)
    a2c8:	58078463          	beqz	a5,a850 <v3_demo_run+0xda8>
    a2cc:	560b0e63          	beqz	s6,a848 <v3_demo_run+0xda0>
    a2d0:	12215583          	lhu	a1,290(sp)
    a2d4:	03412503          	lw	a0,52(sp)
    a2d8:	00989637          	lui	a2,0x989
    a2dc:	68060613          	addi	a2,a2,1664 # 989680 <__freertos_irq_stack_top+0x96bc00>
    a2e0:	8e8f80ef          	jal	23c8 <gpu_wait_tag>
    a2e4:	00050d93          	mv	s11,a0
    a2e8:	d00512e3          	bnez	a0,9fec <v3_demo_run+0x544>
    a2ec:	00100793          	li	a5,1
    a2f0:	00009737          	lui	a4,0x9
    a2f4:	00e40733          	add	a4,s0,a4
    a2f8:	12072603          	lw	a2,288(a4) # 9120 <v3_runtime_advance+0xc0>
    a2fc:	02d0f6b7          	lui	a3,0x2d0f
    a300:	57c6a683          	lw	a3,1404(a3) # 2d0f57c <__gpu_framebuffer_a+0xd0f57c>
    a304:	00479593          	slli	a1,a5,0x4
    a308:	00989737          	lui	a4,0x989
    a30c:	40f60633          	sub	a2,a2,a5
    a310:	02d207b7          	lui	a5,0x2d20
    a314:	68070713          	addi	a4,a4,1664 # 989680 <__freertos_irq_stack_top+0x96bc00>
    a318:	00f585b3          	add	a1,a1,a5
    a31c:	12810513          	addi	a0,sp,296
    a320:	528020ef          	jal	c848 <gpu_frame_list_render_span>
    a324:	00050d93          	mv	s11,a0
    a328:	d24f70ef          	jal	184c <gpu_platform_sync>
    a32c:	cfcf70ef          	jal	1828 <gpu_platform_cycles>
    a330:	0eb12423          	sw	a1,232(sp)
    a334:	00050c13          	mv	s8,a0
    a338:	ca0d9ae3          	bnez	s11,9fec <v3_demo_run+0x544>
    a33c:	000097b7          	lui	a5,0x9
    a340:	00f407b3          	add	a5,s0,a5
    a344:	1247df83          	lhu	t6,292(a5) # 9124 <v3_runtime_advance+0xc4>
    a348:	04412783          	lw	a5,68(sp)
    a34c:	00f036b3          	snez	a3,a5
    a350:	00049463          	bnez	s1,a358 <v3_demo_run+0x8b0>
    a354:	00068d93          	mv	s11,a3
    a358:	02d057b7          	lui	a5,0x2d05
    a35c:	0247c803          	lbu	a6,36(a5) # 2d05024 <__gpu_framebuffer_a+0xd05024>
    a360:	0207db83          	lhu	s7,32(a5)
    a364:	00009737          	lui	a4,0x9
    a368:	fffa0c93          	addi	s9,s4,-1
    a36c:	00e40733          	add	a4,s0,a4
    a370:	2c812f03          	lw	t5,712(sp)
    a374:	0187ae83          	lw	t4,24(a5)
    a378:	01c7ae03          	lw	t3,28(a5)
    a37c:	12c75303          	lhu	t1,300(a4) # 912c <v3_runtime_advance+0xcc>
    a380:	0ffdfa93          	zext.b	s5,s11
    a384:	01903cb3          	snez	s9,s9
    a388:	0014c893          	xori	a7,s1,1
    a38c:	01703bb3          	snez	s7,s7
    a390:	00183293          	seqz	t0,a6
    a394:	00400b13          	li	s6,4
    a398:	00049e63          	bnez	s1,a3b4 <v3_demo_run+0x90c>
    a39c:	00100b13          	li	s6,1
    a3a0:	000a0a63          	beqz	s4,a3b4 <v3_demo_run+0x90c>
    a3a4:	00100793          	li	a5,1
    a3a8:	00300b13          	li	s6,3
    a3ac:	00fa1463          	bne	s4,a5,a3b4 <v3_demo_run+0x90c>
    a3b0:	00200b13          	li	s6,2
    a3b4:	14214603          	lbu	a2,322(sp)
    a3b8:	03c12583          	lw	a1,60(sp)
    a3bc:	00000793          	li	a5,0
    a3c0:	00000713          	li	a4,0
    a3c4:	02d00537          	lui	a0,0x2d00
    a3c8:	10512e23          	sw	t0,284(sp)
    a3cc:	11012c23          	sw	a6,280(sp)
    a3d0:	11112a23          	sw	a7,276(sp)
    a3d4:	10612823          	sw	t1,272(sp)
    a3d8:	11c12623          	sw	t3,268(sp)
    a3dc:	11d12423          	sw	t4,264(sp)
    a3e0:	11e12223          	sw	t5,260(sp)
    a3e4:	11f12023          	sw	t6,256(sp)
    a3e8:	87dfe0ef          	jal	8c64 <v3_runtime_status>
    a3ec:	0aa12223          	sw	a0,164(sp)
    a3f0:	02d0f737          	lui	a4,0x2d0f
    a3f4:	01d00613          	li	a2,29
    a3f8:	00000593          	li	a1,0
    a3fc:	1f310513          	addi	a0,sp,499
    a400:	56874d83          	lbu	s11,1384(a4) # 2d0f568 <__gpu_framebuffer_a+0xd0f568>
    a404:	e25f60ef          	jal	1228 <memset>
    a408:	04412783          	lw	a5,68(sp)
    a40c:	10012f83          	lw	t6,256(sp)
    a410:	10412f03          	lw	t5,260(sp)
    a414:	1ef12023          	sw	a5,480(sp)
    a418:	06c12783          	lw	a5,108(sp)
    a41c:	10812e83          	lw	t4,264(sp)
    a420:	10c12e03          	lw	t3,268(sp)
    a424:	1ef12423          	sw	a5,488(sp)
    a428:	0c412783          	lw	a5,196(sp)
    a42c:	11012303          	lw	t1,272(sp)
    a430:	11412883          	lw	a7,276(sp)
    a434:	1ef108a3          	sb	a5,497(sp)
    a438:	0a412783          	lw	a5,164(sp)
    a43c:	11812803          	lw	a6,280(sp)
    a440:	11c12283          	lw	t0,284(sp)
    a444:	0057d793          	srli	a5,a5,0x5
    a448:	0017f793          	andi	a5,a5,1
    a44c:	00100693          	li	a3,1
    a450:	20f103a3          	sb	a5,519(sp)
    a454:	1c012e23          	sw	zero,476(sp)
    a458:	1e012223          	sw	zero,484(sp)
    a45c:	1ff11623          	sh	t6,492(sp)
    a460:	1e010723          	sb	zero,494(sp)
    a464:	1f5107a3          	sb	s5,495(sp)
    a468:	1f910823          	sb	s9,496(sp)
    a46c:	1ed10923          	sb	a3,498(sp)
    a470:	1fe12a23          	sw	t5,500(sp)
    a474:	1fd12c23          	sw	t4,504(sp)
    a478:	1fc12e23          	sw	t3,508(sp)
    a47c:	20611023          	sh	t1,512(sp)
    a480:	21110123          	sb	a7,514(sp)
    a484:	210101a3          	sb	a6,515(sp)
    a488:	21710223          	sb	s7,516(sp)
    a48c:	205102a3          	sb	t0,517(sp)
    a490:	21610323          	sb	s6,518(sp)
    a494:	21b10423          	sb	s11,520(sp)
    a498:	07812783          	lw	a5,120(sp)
    a49c:	4cd79c63          	bne	a5,a3,a974 <v3_demo_run+0xecc>
    a4a0:	4cfa0c63          	beq	s4,a5,a978 <v3_demo_run+0xed0>
    a4a4:	004d2703          	lw	a4,4(s10)
    a4a8:	03812683          	lw	a3,56(sp)
    a4ac:	03412503          	lw	a0,52(sp)
    a4b0:	009897b7          	lui	a5,0x989
    a4b4:	0001d637          	lui	a2,0x1d
    a4b8:	68078793          	addi	a5,a5,1664 # 989680 <__freertos_irq_stack_top+0x96bc00>
    a4bc:	86c60613          	addi	a2,a2,-1940 # 1c86c <physical_hud>
    a4c0:	1dc10593          	addi	a1,sp,476
    a4c4:	bd5f90ef          	jal	4098 <hud_render_gpu_direct>
    a4c8:	00050d93          	mv	s11,a0
    a4cc:	b20510e3          	bnez	a0,9fec <v3_demo_run+0x544>
    a4d0:	b7cf70ef          	jal	184c <gpu_platform_sync>
    a4d4:	b54f70ef          	jal	1828 <gpu_platform_cycles>
    a4d8:	10a12023          	sw	a0,256(sp)
    a4dc:	03412503          	lw	a0,52(sp)
    a4e0:	10b12223          	sw	a1,260(sp)
    a4e4:	2e810593          	addi	a1,sp,744
    a4e8:	8dcf80ef          	jal	25c4 <gpu_read_perf_snapshot>
    a4ec:	00050d93          	mv	s11,a0
    a4f0:	ae051ee3          	bnez	a0,9fec <v3_demo_run+0x544>
    a4f4:	b34f70ef          	jal	1828 <gpu_platform_cycles>
    a4f8:	41250bb3          	sub	s7,a0,s2
    a4fc:	017537b3          	sltu	a5,a0,s7
    a500:	413585b3          	sub	a1,a1,s3
    a504:	06400613          	li	a2,100
    a508:	00000693          	li	a3,0
    a50c:	40f585b3          	sub	a1,a1,a5
    a510:	000b8513          	mv	a0,s7
    a514:	460020ef          	jal	c974 <__udivdi3>
    a518:	0aa12223          	sw	a0,164(sp)
    a51c:	03412503          	lw	a0,52(sp)
    a520:	00989637          	lui	a2,0x989
    a524:	68060613          	addi	a2,a2,1664 # 989680 <__freertos_irq_stack_top+0x96bc00>
    a528:	000d0593          	mv	a1,s10
    a52c:	ff4f80ef          	jal	2d20 <framebuffer_present>
    a530:	00050d93          	mv	s11,a0
    a534:	aa051ce3          	bnez	a0,9fec <v3_demo_run+0x544>
    a538:	af0f70ef          	jal	1828 <gpu_platform_cycles>
    a53c:	41250933          	sub	s2,a0,s2
    a540:	012537b3          	sltu	a5,a0,s2
    a544:	413589b3          	sub	s3,a1,s3
    a548:	06012a83          	lw	s5,96(sp)
    a54c:	00050b13          	mv	s6,a0
    a550:	00058c93          	mv	s9,a1
    a554:	40f989b3          	sub	s3,s3,a5
    a558:	0a049263          	bnez	s1,a5fc <v3_demo_run+0xb54>
    a55c:	0f812783          	lw	a5,248(sp)
    a560:	0fc12703          	lw	a4,252(sp)
    a564:	06400613          	li	a2,100
    a568:	40fc0533          	sub	a0,s8,a5
    a56c:	0e812783          	lw	a5,232(sp)
    a570:	00ac3c33          	sltu	s8,s8,a0
    a574:	00000693          	li	a3,0
    a578:	40e785b3          	sub	a1,a5,a4
    a57c:	418585b3          	sub	a1,a1,s8
    a580:	3f4020ef          	jal	c974 <__udivdi3>
    a584:	06400693          	li	a3,100
    a588:	02a6b733          	mulhu	a4,a3,a0
    a58c:	00090593          	mv	a1,s2
    a590:	00098613          	mv	a2,s3
    a594:	02a686b3          	mul	a3,a3,a0
    a598:	17010513          	addi	a0,sp,368
    a59c:	eb4fa0ef          	jal	4c50 <perf_window_add>
    a5a0:	00050d93          	mv	s11,a0
    a5a4:	a40514e3          	bnez	a0,9fec <v3_demo_run+0x544>
    a5a8:	06012703          	lw	a4,96(sp)
    a5ac:	0001c7b7          	lui	a5,0x1c
    a5b0:	7f478793          	addi	a5,a5,2036 # 1c7f4 <work_samples>
    a5b4:	00271713          	slli	a4,a4,0x2
    a5b8:	00e787b3          	add	a5,a5,a4
    a5bc:	0a412703          	lw	a4,164(sp)
    a5c0:	001a8a93          	addi	s5,s5,1
    a5c4:	00e7a023          	sw	a4,0(a5)
    a5c8:	00100793          	li	a5,1
    a5cc:	02fa0863          	beq	s4,a5,a5fc <v3_demo_run+0xb54>
    a5d0:	06400613          	li	a2,100
    a5d4:	00000693          	li	a3,0
    a5d8:	00090513          	mv	a0,s2
    a5dc:	00098593          	mv	a1,s3
    a5e0:	394020ef          	jal	c974 <__udivdi3>
    a5e4:	000057b7          	lui	a5,0x5
    a5e8:	e2078793          	addi	a5,a5,-480 # 4e20 <perf_render_us+0x9c>
    a5ec:	00a7f863          	bgeu	a5,a0,a5fc <v3_demo_run+0xb54>
    a5f0:	05c12783          	lw	a5,92(sp)
    a5f4:	00178793          	addi	a5,a5,1
    a5f8:	04f12e23          	sw	a5,92(sp)
    a5fc:	31012983          	lw	s3,784(sp)
    a600:	a80a1ce3          	bnez	s4,a098 <v3_demo_run+0x5f0>
    a604:	03412503          	lw	a0,52(sp)
    a608:	33010593          	addi	a1,sp,816
    a60c:	fb9f70ef          	jal	25c4 <gpu_read_perf_snapshot>
    a610:	00050d93          	mv	s11,a0
    a614:	9c051ce3          	bnez	a0,9fec <v3_demo_run+0x544>
    a618:	03412783          	lw	a5,52(sp)
    a61c:	35812703          	lw	a4,856(sp)
    a620:	0dc12603          	lw	a2,220(sp)
    a624:	35c12683          	lw	a3,860(sp)
    a628:	0137c783          	lbu	a5,19(a5)
    a62c:	00c71863          	bne	a4,a2,a63c <v3_demo_run+0xb94>
    a630:	0ec12603          	lw	a2,236(sp)
    a634:	00c69463          	bne	a3,a2,a63c <v3_demo_run+0xb94>
    a638:	3c078463          	beqz	a5,aa00 <v3_demo_run+0xf58>
    a63c:	06412603          	lw	a2,100(sp)
    a640:	0dc12683          	lw	a3,220(sp)
    a644:	06412583          	lw	a1,100(sp)
    a648:	0000d537          	lui	a0,0xd
    a64c:	01e63613          	sltiu	a2,a2,30
    a650:	7e450513          	addi	a0,a0,2020 # d7e4 <_data+0x550>
    a654:	834ff0ef          	jal	9688 <bsp_printf>
    a658:	ff900d93          	li	s11,-7
    a65c:	991ff06f          	j	9fec <v3_demo_run+0x544>
    a660:	00000a13          	li	s4,0
    a664:	ad1ff06f          	j	a134 <v3_demo_run+0x68c>
    a668:	00100793          	li	a5,1
    a66c:	1cf716e3          	bne	a4,a5,b038 <v3_demo_run+0x1590>
    a670:	00000613          	li	a2,0
    a674:	18c10593          	addi	a1,sp,396
    a678:	02d00537          	lui	a0,0x2d00
    a67c:	9e5fe0ef          	jal	9060 <v3_runtime_advance>
    a680:	00050d93          	mv	s11,a0
    a684:	ac055ce3          	bgez	a0,a15c <v3_demo_run+0x6b4>
    a688:	965ff06f          	j	9fec <v3_demo_run+0x544>
    a68c:	00100793          	li	a5,1
    a690:	1af716e3          	bne	a4,a5,b03c <v3_demo_run+0x1594>
    a694:	12215583          	lhu	a1,290(sp)
    a698:	03412503          	lw	a0,52(sp)
    a69c:	00989637          	lui	a2,0x989
    a6a0:	68060613          	addi	a2,a2,1664 # 989680 <__freertos_irq_stack_top+0x96bc00>
    a6a4:	d25f70ef          	jal	23c8 <gpu_wait_tag>
    a6a8:	00050d93          	mv	s11,a0
    a6ac:	aa050ee3          	beqz	a0,a168 <v3_demo_run+0x6c0>
    a6b0:	04012a83          	lw	s5,64(sp)
    a6b4:	0640006f          	j	a718 <v3_demo_run+0xc70>
    a6b8:	07c12783          	lw	a5,124(sp)
    a6bc:	06400613          	li	a2,100
    a6c0:	00000693          	li	a3,0
    a6c4:	00a7b5b3          	sltu	a1,a5,a0
    a6c8:	40ba05b3          	sub	a1,s4,a1
    a6cc:	2a8020ef          	jal	c974 <__udivdi3>
    a6d0:	00050613          	mv	a2,a0
    a6d4:	02d0f4b7          	lui	s1,0x2d0f
    a6d8:	18c10593          	addi	a1,sp,396
    a6dc:	02d00537          	lui	a0,0x2d00
    a6e0:	5724cc03          	lbu	s8,1394(s1) # 2d0f572 <__gpu_framebuffer_a+0xd0f572>
    a6e4:	97dfe0ef          	jal	9060 <v3_runtime_advance>
    a6e8:	00050d93          	mv	s11,a0
    a6ec:	900540e3          	bltz	a0,9fec <v3_demo_run+0x544>
    a6f0:	5724c703          	lbu	a4,1394(s1)
    a6f4:	a60c1ae3          	bnez	s8,a168 <v3_demo_run+0x6c0>
    a6f8:	00100793          	li	a5,1
    a6fc:	a6f716e3          	bne	a4,a5,a168 <v3_demo_run+0x6c0>
    a700:	00000613          	li	a2,0
    a704:	18c10593          	addi	a1,sp,396
    a708:	02d00537          	lui	a0,0x2d00
    a70c:	955fe0ef          	jal	9060 <v3_runtime_advance>
    a710:	00050d93          	mv	s11,a0
    a714:	00000a93          	li	s5,0
    a718:	a40ddae3          	bgez	s11,a16c <v3_demo_run+0x6c4>
    a71c:	8d1ff06f          	j	9fec <v3_demo_run+0x544>
    a720:	0000d5b7          	lui	a1,0xd
    a724:	5ec58593          	addi	a1,a1,1516 # d5ec <_data+0x358>
    a728:	ac9ff06f          	j	a1f0 <v3_demo_run+0x748>
    a72c:	03c12783          	lw	a5,60(sp)
    a730:	05012683          	lw	a3,80(sp)
    a734:	004d2703          	lw	a4,4(s10)
    a738:	96f6e0e3          	bltu	a3,a5,a098 <v3_demo_run+0x5f0>
    a73c:	ffe007b7          	lui	a5,0xffe00
    a740:	fff78793          	addi	a5,a5,-1 # ffdfffff <__gpu_framebuffer_a+0xfddfffff>
    a744:	00f777b3          	and	a5,a4,a5
    a748:	020006b7          	lui	a3,0x2000
    a74c:	94d796e3          	bne	a5,a3,a098 <v3_demo_run+0x5f0>
    a750:	03c12683          	lw	a3,60(sp)
    a754:	02b227b7          	lui	a5,0x2b22
    a758:	c0078793          	addi	a5,a5,-1024 # 2b21c00 <__gpu_framebuffer_a+0xb21c00>
    a75c:	00068663          	beqz	a3,a768 <v3_demo_run+0xcc0>
    a760:	029227b7          	lui	a5,0x2922
    a764:	c0078793          	addi	a5,a5,-1024 # 2921c00 <__gpu_framebuffer_a+0x921c00>
    a768:	1af12e23          	sw	a5,444(sp)
    a76c:	000227b7          	lui	a5,0x22
    a770:	c0078793          	addi	a5,a5,-1024 # 21c00 <__freertos_irq_stack_top+0x4180>
    a774:	00f70733          	add	a4,a4,a5
    a778:	78000793          	li	a5,1920
    a77c:	1cf12223          	sw	a5,452(sp)
    a780:	1cf12423          	sw	a5,456(sp)
    a784:	03412503          	lw	a0,52(sp)
    a788:	3c000793          	li	a5,960
    a78c:	1cf11623          	sh	a5,460(sp)
    a790:	00989637          	lui	a2,0x989
    a794:	1d400793          	li	a5,468
    a798:	1c012c23          	sw	zero,472(sp)
    a79c:	1cf11723          	sh	a5,462(sp)
    a7a0:	12210693          	addi	a3,sp,290
    a7a4:	00200793          	li	a5,2
    a7a8:	68060613          	addi	a2,a2,1664 # 989680 <__freertos_irq_stack_top+0x96bc00>
    a7ac:	1bc10593          	addi	a1,sp,444
    a7b0:	1c012823          	sw	zero,464(sp)
    a7b4:	1c012a23          	sw	zero,468(sp)
    a7b8:	1ce12023          	sw	a4,448(sp)
    a7bc:	1cf10c23          	sb	a5,472(sp)
    a7c0:	ec8f70ef          	jal	1e88 <gpu_submit>
    a7c4:	00050d93          	mv	s11,a0
    a7c8:	aa0504e3          	beqz	a0,a270 <v3_demo_run+0x7c8>
    a7cc:	821ff06f          	j	9fec <v3_demo_run+0x544>
    a7d0:	00000b13          	li	s6,0
    a7d4:	aa1ff06f          	j	a274 <v3_demo_run+0x7cc>
    a7d8:	07412783          	lw	a5,116(sp)
    a7dc:	02078a63          	beqz	a5,a810 <v3_demo_run+0xd68>
    a7e0:	00100793          	li	a5,1
    a7e4:	02fa0663          	beq	s4,a5,a810 <v3_demo_run+0xd68>
    a7e8:	03c12603          	lw	a2,60(sp)
    a7ec:	12410813          	addi	a6,sp,292
    a7f0:	00040793          	mv	a5,s0
    a7f4:	02d20737          	lui	a4,0x2d20
    a7f8:	00100693          	li	a3,1
    a7fc:	02d00537          	lui	a0,0x2d00
    a800:	8b8ff0ef          	jal	98b8 <v3_build_gpu_scene>
    a804:	00050d93          	mv	s11,a0
    a808:	a8050ee3          	beqz	a0,a2a4 <v3_demo_run+0x7fc>
    a80c:	fe0ff06f          	j	9fec <v3_demo_run+0x544>
    a810:	03c12603          	lw	a2,60(sp)
    a814:	00040793          	mv	a5,s0
    a818:	48900713          	li	a4,1161
    a81c:	00100693          	li	a3,1
    a820:	02d00537          	lui	a0,0x2d00
    a824:	919fd0ef          	jal	813c <game_build>
    a828:	00050d93          	mv	s11,a0
    a82c:	fc051063          	bnez	a0,9fec <v3_demo_run+0x544>
    a830:	00100793          	li	a5,1
    a834:	a6fa08e3          	beq	s4,a5,a2a4 <v3_demo_run+0x7fc>
    a838:	04800593          	li	a1,72
    a83c:	00040513          	mv	a0,s0
    a840:	ec5fb0ef          	jal	6704 <bullet_clip_background_for_hud>
    a844:	fc1ff06f          	j	a804 <v3_demo_run+0xd5c>
    a848:	00000793          	li	a5,0
    a84c:	aa5ff06f          	j	a2f0 <v3_demo_run+0x848>
    a850:	02048e63          	beqz	s1,a88c <v3_demo_run+0xde4>
    a854:	004d2683          	lw	a3,4(s10)
    a858:	02d0f737          	lui	a4,0x2d0f
    a85c:	03812803          	lw	a6,56(sp)
    a860:	14214783          	lbu	a5,322(sp)
    a864:	57c72703          	lw	a4,1404(a4) # 2d0f57c <__gpu_framebuffer_a+0xd0f57c>
    a868:	03412503          	lw	a0,52(sp)
    a86c:	fe000637          	lui	a2,0xfe000
    a870:	00c68633          	add	a2,a3,a2
    a874:	009898b7          	lui	a7,0x989
    a878:	68088893          	addi	a7,a7,1664 # 989680 <__freertos_irq_stack_top+0x96bc00>
    a87c:	00c03633          	snez	a2,a2
    a880:	1a410593          	addi	a1,sp,420
    a884:	1cd000ef          	jal	b250 <game_menu_draw>
    a888:	a9dff06f          	j	a324 <v3_demo_run+0x87c>
    a88c:	00100793          	li	a5,1
    a890:	00fa1e63          	bne	s4,a5,a8ac <v3_demo_run+0xe04>
    a894:	000097b7          	lui	a5,0x9
    a898:	00f407b3          	add	a5,s0,a5
    a89c:	1207a583          	lw	a1,288(a5) # 9120 <v3_runtime_advance+0xc0>
    a8a0:	00040513          	mv	a0,s0
    a8a4:	900fa0ef          	jal	49a4 <perf_render_cpu>
    a8a8:	a7dff06f          	j	a324 <v3_demo_run+0x87c>
    a8ac:	0a0b0663          	beqz	s6,a958 <v3_demo_run+0xeb0>
    a8b0:	12215583          	lhu	a1,290(sp)
    a8b4:	ff800d93          	li	s11,-8
    a8b8:	a60408e3          	beqz	s0,a328 <v3_demo_run+0x880>
    a8bc:	000097b7          	lui	a5,0x9
    a8c0:	00f407b3          	add	a5,s0,a5
    a8c4:	1207a783          	lw	a5,288(a5) # 9120 <v3_runtime_advance+0xc0>
    a8c8:	48800713          	li	a4,1160
    a8cc:	fff78613          	addi	a2,a5,-1
    a8d0:	a4c76ce3          	bltu	a4,a2,a328 <v3_demo_run+0x880>
    a8d4:	01c44683          	lbu	a3,28(s0)
    a8d8:	00200713          	li	a4,2
    a8dc:	a4e696e3          	bne	a3,a4,a328 <v3_demo_run+0x880>
    a8e0:	01845703          	lhu	a4,24(s0)
    a8e4:	a40712e3          	bnez	a4,a328 <v3_demo_run+0x880>
    a8e8:	00042683          	lw	a3,0(s0)
    a8ec:	1bc12703          	lw	a4,444(sp)
    a8f0:	a2e69ce3          	bne	a3,a4,a328 <v3_demo_run+0x880>
    a8f4:	00442683          	lw	a3,4(s0)
    a8f8:	1c012703          	lw	a4,448(sp)
    a8fc:	a2e696e3          	bne	a3,a4,a328 <v3_demo_run+0x880>
    a900:	00842683          	lw	a3,8(s0)
    a904:	1c412703          	lw	a4,452(sp)
    a908:	a2e690e3          	bne	a3,a4,a328 <v3_demo_run+0x880>
    a90c:	00c42683          	lw	a3,12(s0)
    a910:	1c812703          	lw	a4,456(sp)
    a914:	a0e69ae3          	bne	a3,a4,a328 <v3_demo_run+0x880>
    a918:	01042683          	lw	a3,16(s0)
    a91c:	1cc12703          	lw	a4,460(sp)
    a920:	a0e694e3          	bne	a3,a4,a328 <v3_demo_run+0x880>
    a924:	00100713          	li	a4,1
    a928:	00e78e63          	beq	a5,a4,a944 <v3_demo_run+0xe9c>
    a92c:	009896b7          	lui	a3,0x989
    a930:	68068693          	addi	a3,a3,1664 # 989680 <__freertos_irq_stack_top+0x96bc00>
    a934:	02040593          	addi	a1,s0,32
    a938:	03412503          	lw	a0,52(sp)
    a93c:	a7cfa0ef          	jal	4bb8 <perf_render_gpu>
    a940:	9e5ff06f          	j	a324 <v3_demo_run+0x87c>
    a944:	03412503          	lw	a0,52(sp)
    a948:	00989637          	lui	a2,0x989
    a94c:	68060613          	addi	a2,a2,1664 # 989680 <__freertos_irq_stack_top+0x96bc00>
    a950:	a79f70ef          	jal	23c8 <gpu_wait_tag>
    a954:	9d1ff06f          	j	a324 <v3_demo_run+0x87c>
    a958:	000097b7          	lui	a5,0x9
    a95c:	00f407b3          	add	a5,s0,a5
    a960:	009896b7          	lui	a3,0x989
    a964:	1207a603          	lw	a2,288(a5) # 9120 <v3_runtime_advance+0xc0>
    a968:	68068693          	addi	a3,a3,1664 # 989680 <__freertos_irq_stack_top+0x96bc00>
    a96c:	00040593          	mv	a1,s0
    a970:	fc9ff06f          	j	a938 <v3_demo_run+0xe90>
    a974:	04da1863          	bne	s4,a3,a9c4 <v3_demo_run+0xf1c>
    a978:	03812603          	lw	a2,56(sp)
    a97c:	04c12583          	lw	a1,76(sp)
    a980:	1dc10513          	addi	a0,sp,476
    a984:	838f90ef          	jal	39bc <hud_update_cache>
    a988:	00050d93          	mv	s11,a0
    a98c:	e6051063          	bnez	a0,9fec <v3_demo_run+0x544>
    a990:	ebdf60ef          	jal	184c <gpu_platform_sync>
    a994:	03812603          	lw	a2,56(sp)
    a998:	04c12583          	lw	a1,76(sp)
    a99c:	004d2503          	lw	a0,4(s10)
    a9a0:	a80f90ef          	jal	3c20 <hud_cached_command>
    a9a4:	00050d93          	mv	s11,a0
    a9a8:	e4051263          	bnez	a0,9fec <v3_demo_run+0x544>
    a9ac:	00100793          	li	a5,1
    a9b0:	02fa1a63          	bne	s4,a5,a9e4 <v3_demo_run+0xf3c>
    a9b4:	03812503          	lw	a0,56(sp)
    a9b8:	00100593          	li	a1,1
    a9bc:	fe9f90ef          	jal	49a4 <perf_render_cpu>
    a9c0:	b09ff06f          	j	a4c8 <v3_demo_run+0xa20>
    a9c4:	03812683          	lw	a3,56(sp)
    a9c8:	04c12603          	lw	a2,76(sp)
    a9cc:	03412503          	lw	a0,52(sp)
    a9d0:	00989737          	lui	a4,0x989
    a9d4:	68070713          	addi	a4,a4,1664 # 989680 <__freertos_irq_stack_top+0x96bc00>
    a9d8:	1dc10593          	addi	a1,sp,476
    a9dc:	eb4f90ef          	jal	4090 <hud_update_gpu_cache>
    a9e0:	fa9ff06f          	j	a988 <v3_demo_run+0xee0>
    a9e4:	03812583          	lw	a1,56(sp)
    a9e8:	03412503          	lw	a0,52(sp)
    a9ec:	009896b7          	lui	a3,0x989
    a9f0:	68068693          	addi	a3,a3,1664 # 989680 <__freertos_irq_stack_top+0x96bc00>
    a9f4:	00100613          	li	a2,1
    a9f8:	9c0fa0ef          	jal	4bb8 <perf_render_gpu>
    a9fc:	acdff06f          	j	a4c8 <v3_demo_run+0xa20>
    aa00:	06412703          	lw	a4,100(sp)
    aa04:	01d00793          	li	a5,29
    aa08:	10e7fe63          	bgeu	a5,a4,ab24 <v3_demo_run+0x107c>
    aa0c:	05412683          	lw	a3,84(sp)
    aa10:	000097b7          	lui	a5,0x9
    aa14:	00f407b3          	add	a5,s0,a5
    aa18:	1247a703          	lw	a4,292(a5) # 9124 <v3_runtime_advance+0xc4>
    aa1c:	12c7a783          	lw	a5,300(a5)
    aa20:	00069663          	bnez	a3,aa2c <v3_demo_run+0xf84>
    aa24:	06f12823          	sw	a5,112(sp)
    aa28:	06e12423          	sw	a4,104(sp)
    aa2c:	05412683          	lw	a3,84(sp)
    aa30:	09012603          	lw	a2,144(sp)
    aa34:	00168693          	addi	a3,a3,1
    aa38:	04d12a23          	sw	a3,84(sp)
    aa3c:	001976b7          	lui	a3,0x197
    aa40:	e6a68693          	addi	a3,a3,-406 # 196e6a <__freertos_irq_stack_top+0x1793ea>
    aa44:	0176b6b3          	sltu	a3,a3,s7
    aa48:	00d606b3          	add	a3,a2,a3
    aa4c:	08d12823          	sw	a3,144(sp)
    aa50:	0a812603          	lw	a2,168(sp)
    aa54:	002626b7          	lui	a3,0x262
    aa58:	5a068693          	addi	a3,a3,1440 # 2625a0 <__freertos_irq_stack_top+0x244b20>
    aa5c:	0126b6b3          	sltu	a3,a3,s2
    aa60:	00d606b3          	add	a3,a2,a3
    aa64:	0ad12423          	sw	a3,168(sp)
    aa68:	08012683          	lw	a3,128(sp)
    aa6c:	08012603          	lw	a2,128(sp)
    aa70:	017686b3          	add	a3,a3,s7
    aa74:	00c6b633          	sltu	a2,a3,a2
    aa78:	08d12023          	sw	a3,128(sp)
    aa7c:	0b812683          	lw	a3,184(sp)
    aa80:	00d606b3          	add	a3,a2,a3
    aa84:	0ad12c23          	sw	a3,184(sp)
    aa88:	08412683          	lw	a3,132(sp)
    aa8c:	08412603          	lw	a2,132(sp)
    aa90:	012686b3          	add	a3,a3,s2
    aa94:	00c6b633          	sltu	a2,a3,a2
    aa98:	08d12223          	sw	a3,132(sp)
    aa9c:	0bc12683          	lw	a3,188(sp)
    aaa0:	00d606b3          	add	a3,a2,a3
    aaa4:	0ad12e23          	sw	a3,188(sp)
    aaa8:	04812603          	lw	a2,72(sp)
    aaac:	08812683          	lw	a3,136(sp)
    aab0:	00c686b3          	add	a3,a3,a2
    aab4:	08812603          	lw	a2,136(sp)
    aab8:	08d12423          	sw	a3,136(sp)
    aabc:	00c6b633          	sltu	a2,a3,a2
    aac0:	0c012683          	lw	a3,192(sp)
    aac4:	00d606b3          	add	a3,a2,a3
    aac8:	0cd12023          	sw	a3,192(sp)
    aacc:	0ac12683          	lw	a3,172(sp)
    aad0:	0176f463          	bgeu	a3,s7,aad8 <v3_demo_run+0x1030>
    aad4:	0b712623          	sw	s7,172(sp)
    aad8:	09412683          	lw	a3,148(sp)
    aadc:	0126f463          	bgeu	a3,s2,aae4 <v3_demo_run+0x103c>
    aae0:	09212a23          	sw	s2,148(sp)
    aae4:	09c12683          	lw	a3,156(sp)
    aae8:	04812603          	lw	a2,72(sp)
    aaec:	00c6f463          	bgeu	a3,a2,aaf4 <v3_demo_run+0x104c>
    aaf0:	08c12e23          	sw	a2,156(sp)
    aaf4:	06812683          	lw	a3,104(sp)
    aaf8:	00d77463          	bgeu	a4,a3,ab00 <v3_demo_run+0x1058>
    aafc:	06e12423          	sw	a4,104(sp)
    ab00:	09812683          	lw	a3,152(sp)
    ab04:	00e6f463          	bgeu	a3,a4,ab0c <v3_demo_run+0x1064>
    ab08:	08e12c23          	sw	a4,152(sp)
    ab0c:	07012703          	lw	a4,112(sp)
    ab10:	00e7f463          	bgeu	a5,a4,ab18 <v3_demo_run+0x1070>
    ab14:	06f12823          	sw	a5,112(sp)
    ab18:	0b012703          	lw	a4,176(sp)
    ab1c:	00f77463          	bgeu	a4,a5,ab24 <v3_demo_run+0x107c>
    ab20:	0af12823          	sw	a5,176(sp)
    ab24:	0001c737          	lui	a4,0x1c
    ab28:	7f470713          	addi	a4,a4,2036 # 1c7f4 <work_samples>
    ab2c:	3e810593          	addi	a1,sp,1000
    ab30:	00000693          	li	a3,0
    ab34:	0480006f          	j	ab7c <v3_demo_run+0x10d4>
    ab38:	00a62023          	sw	a0,0(a2)
    ab3c:	00088793          	mv	a5,a7
    ab40:	ffc60613          	addi	a2,a2,-4
    ab44:	00078a63          	beqz	a5,ab58 <v3_demo_run+0x10b0>
    ab48:	ffc62503          	lw	a0,-4(a2)
    ab4c:	00072803          	lw	a6,0(a4)
    ab50:	fff78893          	addi	a7,a5,-1
    ab54:	fea862e3          	bltu	a6,a0,ab38 <v3_demo_run+0x1090>
    ab58:	00279793          	slli	a5,a5,0x2
    ab5c:	0f010613          	addi	a2,sp,240
    ab60:	45078793          	addi	a5,a5,1104
    ab64:	00c787b3          	add	a5,a5,a2
    ab68:	00072603          	lw	a2,0(a4)
    ab6c:	00168693          	addi	a3,a3,1
    ab70:	00470713          	addi	a4,a4,4
    ab74:	eac7a423          	sw	a2,-344(a5)
    ab78:	00458593          	addi	a1,a1,4
    ab7c:	08da9263          	bne	s5,a3,ac00 <v3_demo_run+0x1158>
    ab80:	05812783          	lw	a5,88(sp)
    ab84:	0b412703          	lw	a4,180(sp)
    ab88:	013787b3          	add	a5,a5,s3
    ab8c:	40e787b3          	sub	a5,a5,a4
    ab90:	04f12c23          	sw	a5,88(sp)
    ab94:	060a9c63          	bnez	s5,ac0c <v3_demo_run+0x1164>
    ab98:	00000b93          	li	s7,0
    ab9c:	04012423          	sw	zero,72(sp)
    aba0:	a9dfe0ef          	jal	963c <now_ms>
    aba4:	0a012783          	lw	a5,160(sp)
    aba8:	00050a13          	mv	s4,a0
    abac:	40f50733          	sub	a4,a0,a5
    abb0:	0c700793          	li	a5,199
    abb4:	2ee7fe63          	bgeu	a5,a4,aeb0 <v3_demo_run+0x1408>
    abb8:	f81007b7          	lui	a5,0xf8100
    abbc:	0cc12683          	lw	a3,204(sp)
    abc0:	3147ac03          	lw	s8,788(a5) # f8100314 <__gpu_framebuffer_a+0xf6100314>
    abc4:	00009737          	lui	a4,0x9
    abc8:	00e40733          	add	a4,s0,a4
    abcc:	12072783          	lw	a5,288(a4) # 9120 <v3_runtime_advance+0xc0>
    abd0:	12069463          	bnez	a3,acf8 <v3_demo_run+0x1250>
    abd4:	00579793          	slli	a5,a5,0x5
    abd8:	00040713          	mv	a4,s0
    abdc:	008787b3          	add	a5,a5,s0
    abe0:	00000913          	li	s2,0
    abe4:	00300693          	li	a3,3
    abe8:	10e78e63          	beq	a5,a4,ad04 <v3_demo_run+0x125c>
    abec:	01c74603          	lbu	a2,28(a4)
    abf0:	00d61463          	bne	a2,a3,abf8 <v3_demo_run+0x1150>
    abf4:	00190913          	addi	s2,s2,1
    abf8:	02070713          	addi	a4,a4,32
    abfc:	fedff06f          	j	abe8 <v3_demo_run+0x1140>
    ac00:	00058613          	mv	a2,a1
    ac04:	00068793          	mv	a5,a3
    ac08:	f3dff06f          	j	ab44 <v3_demo_run+0x109c>
    ac0c:	05f00793          	li	a5,95
    ac10:	02fa87b3          	mul	a5,s5,a5
    ac14:	06400713          	li	a4,100
    ac18:	04012423          	sw	zero,72(sp)
    ac1c:	06378793          	addi	a5,a5,99
    ac20:	02e7d7b3          	divu	a5,a5,a4
    ac24:	0f010713          	addi	a4,sp,240
    ac28:	fff78793          	addi	a5,a5,-1
    ac2c:	00279793          	slli	a5,a5,0x2
    ac30:	45078793          	addi	a5,a5,1104
    ac34:	00e787b3          	add	a5,a5,a4
    ac38:	ea87ab83          	lw	s7,-344(a5)
    ac3c:	01e00793          	li	a5,30
    ac40:	f6fa90e3          	bne	s5,a5,aba0 <v3_demo_run+0x10f8>
    ac44:	05f5e5b7          	lui	a1,0x5f5e
    ac48:	10058593          	addi	a1,a1,256 # 5f5e100 <__gpu_framebuffer_a+0x3f5e100>
    ac4c:	17010513          	addi	a0,sp,368
    ac50:	8b0fa0ef          	jal	4d00 <perf_fps_x10>
    ac54:	05f5e5b7          	lui	a1,0x5f5e
    ac58:	04a12223          	sw	a0,68(sp)
    ac5c:	10058593          	addi	a1,a1,256 # 5f5e100 <__gpu_framebuffer_a+0x3f5e100>
    ac60:	17010513          	addi	a0,sp,368
    ac64:	920fa0ef          	jal	4d84 <perf_render_us>
    ac68:	06a12623          	sw	a0,108(sp)
    ac6c:	bbdf60ef          	jal	1828 <gpu_platform_cycles>
    ac70:	13c12583          	lw	a1,316(sp)
    ac74:	02d05637          	lui	a2,0x2d05
    ac78:	01062783          	lw	a5,16(a2) # 2d05010 <__gpu_framebuffer_a+0xd05010>
    ac7c:	00c62703          	lw	a4,12(a2)
    ac80:	00462603          	lw	a2,4(a2)
    ac84:	00b12a23          	sw	a1,20(sp)
    ac88:	18c15583          	lhu	a1,396(sp)
    ac8c:	000096b7          	lui	a3,0x9
    ac90:	00d406b3          	add	a3,s0,a3
    ac94:	00b12823          	sw	a1,16(sp)
    ac98:	05c12583          	lw	a1,92(sp)
    ac9c:	01712223          	sw	s7,4(sp)
    aca0:	04412883          	lw	a7,68(sp)
    aca4:	00b12623          	sw	a1,12(sp)
    aca8:	05812583          	lw	a1,88(sp)
    acac:	00050913          	mv	s2,a0
    acb0:	0000e537          	lui	a0,0xe
    acb4:	00b12423          	sw	a1,8(sp)
    acb8:	06c12583          	lw	a1,108(sp)
    acbc:	83c50513          	addi	a0,a0,-1988 # d83c <_data+0x5a8>
    acc0:	00000a93          	li	s5,0
    acc4:	00b12023          	sw	a1,0(sp)
    acc8:	1246a803          	lw	a6,292(a3) # 9124 <v3_runtime_advance+0xc4>
    accc:	13412683          	lw	a3,308(sp)
    acd0:	00000593          	li	a1,0
    acd4:	9b5fe0ef          	jal	9688 <bsp_printf>
    acd8:	b51f60ef          	jal	1828 <gpu_platform_cycles>
    acdc:	412507b3          	sub	a5,a0,s2
    ace0:	01800613          	li	a2,24
    ace4:	00000593          	li	a1,0
    ace8:	17010513          	addi	a0,sp,368
    acec:	04f12423          	sw	a5,72(sp)
    acf0:	d38f60ef          	jal	1228 <memset>
    acf4:	eadff06f          	j	aba0 <v3_demo_run+0x10f8>
    acf8:	12c72903          	lw	s2,300(a4)
    acfc:	fff78793          	addi	a5,a5,-1
    ad00:	41278933          	sub	s2,a5,s2
    ad04:	02d05737          	lui	a4,0x2d05
    ad08:	00472783          	lw	a5,4(a4) # 2d05004 <__gpu_framebuffer_a+0xd05004>
    ad0c:	38f12223          	sw	a5,900(sp)
    ad10:	00000793          	li	a5,0
    ad14:	00049463          	bnez	s1,ad1c <v3_demo_run+0x1274>
    ad18:	00872783          	lw	a5,8(a4)
    ad1c:	38f12423          	sw	a5,904(sp)
    ad20:	000097b7          	lui	a5,0x9
    ad24:	00f407b3          	add	a5,s0,a5
    ad28:	1247a783          	lw	a5,292(a5) # 9124 <v3_runtime_advance+0xc4>
    ad2c:	04412703          	lw	a4,68(sp)
    ad30:	38012a23          	sw	zero,916(sp)
    ad34:	38f12623          	sw	a5,908(sp)
    ad38:	00a00793          	li	a5,10
    ad3c:	02f707b3          	mul	a5,a4,a5
    ad40:	38f12823          	sw	a5,912(sp)
    ad44:	00048463          	beqz	s1,ad4c <v3_demo_run+0x12a4>
    ad48:	0a012223          	sw	zero,164(sp)
    ad4c:	0a412783          	lw	a5,164(sp)
    ad50:	00000513          	li	a0,0
    ad54:	38f12c23          	sw	a5,920(sp)
    ad58:	02049863          	bnez	s1,ad88 <v3_demo_run+0x12e0>
    ad5c:	2e812583          	lw	a1,744(sp)
    ad60:	2a012503          	lw	a0,672(sp)
    ad64:	2ec12783          	lw	a5,748(sp)
    ad68:	2a412703          	lw	a4,676(sp)
    ad6c:	40a58533          	sub	a0,a1,a0
    ad70:	00a5b5b3          	sltu	a1,a1,a0
    ad74:	40e787b3          	sub	a5,a5,a4
    ad78:	06400613          	li	a2,100
    ad7c:	00000693          	li	a3,0
    ad80:	40b785b3          	sub	a1,a5,a1
    ad84:	3f1010ef          	jal	c974 <__udivdi3>
    ad88:	38a12e23          	sw	a0,924(sp)
    ad8c:	00000513          	li	a0,0
    ad90:	02049863          	bnez	s1,adc0 <v3_demo_run+0x1318>
    ad94:	0d812783          	lw	a5,216(sp)
    ad98:	0f012703          	lw	a4,240(sp)
    ad9c:	0f412683          	lw	a3,244(sp)
    ada0:	06400613          	li	a2,100
    ada4:	40e78533          	sub	a0,a5,a4
    ada8:	0e412703          	lw	a4,228(sp)
    adac:	00a7b7b3          	sltu	a5,a5,a0
    adb0:	40d705b3          	sub	a1,a4,a3
    adb4:	40f585b3          	sub	a1,a1,a5
    adb8:	00000693          	li	a3,0
    adbc:	3b9010ef          	jal	c974 <__udivdi3>
    adc0:	3aa12023          	sw	a0,928(sp)
    adc4:	00048463          	beqz	s1,adcc <v3_demo_run+0x1324>
    adc8:	00000b93          	li	s7,0
    adcc:	3d712a23          	sw	s7,980(sp)
    add0:	00000513          	li	a0,0
    add4:	02049463          	bnez	s1,adfc <v3_demo_run+0x1354>
    add8:	10012783          	lw	a5,256(sp)
    addc:	10412703          	lw	a4,260(sp)
    ade0:	06400613          	li	a2,100
    ade4:	40fb0533          	sub	a0,s6,a5
    ade8:	00ab37b3          	sltu	a5,s6,a0
    adec:	40ec85b3          	sub	a1,s9,a4
    adf0:	00000693          	li	a3,0
    adf4:	40f585b3          	sub	a1,a1,a5
    adf8:	37d010ef          	jal	c974 <__udivdi3>
    adfc:	05812783          	lw	a5,88(sp)
    ae00:	0d012703          	lw	a4,208(sp)
    ae04:	04412683          	lw	a3,68(sp)
    ae08:	3af12c23          	sw	a5,952(sp)
    ae0c:	03412783          	lw	a5,52(sp)
    ae10:	14214603          	lbu	a2,322(sp)
    ae14:	03c12583          	lw	a1,60(sp)
    ae18:	0137c783          	lbu	a5,19(a5)
    ae1c:	3ca12c23          	sw	a0,984(sp)
    ae20:	00d036b3          	snez	a3,a3
    ae24:	3af12e23          	sw	a5,956(sp)
    ae28:	05c12783          	lw	a5,92(sp)
    ae2c:	02d00537          	lui	a0,0x2d00
    ae30:	3f212223          	sw	s2,996(sp)
    ae34:	3cf12023          	sw	a5,960(sp)
    ae38:	50412783          	lw	a5,1284(sp)
    ae3c:	00fc07b3          	add	a5,s8,a5
    ae40:	40e787b3          	sub	a5,a5,a4
    ae44:	0d412703          	lw	a4,212(sp)
    ae48:	40e787b3          	sub	a5,a5,a4
    ae4c:	3cf12423          	sw	a5,968(sp)
    ae50:	13c12783          	lw	a5,316(sp)
    ae54:	3cf12623          	sw	a5,972(sp)
    ae58:	000097b7          	lui	a5,0x9
    ae5c:	00f407b3          	add	a5,s0,a5
    ae60:	12c7a703          	lw	a4,300(a5) # 912c <v3_runtime_advance+0xcc>
    ae64:	1307a783          	lw	a5,304(a5)
    ae68:	3ce12e23          	sw	a4,988(sp)
    ae6c:	3ef12023          	sw	a5,992(sp)
    ae70:	00000713          	li	a4,0
    ae74:	00000793          	li	a5,0
    ae78:	dedfd0ef          	jal	8c64 <v3_runtime_status>
    ae7c:	3ca12823          	sw	a0,976(sp)
    ae80:	000a0613          	mv	a2,s4
    ae84:	37c10593          	addi	a1,sp,892
    ae88:	46010513          	addi	a0,sp,1120
    ae8c:	999fc0ef          	jal	7824 <nc_try_publish>
    ae90:	00050d93          	mv	s11,a0
    ae94:	94054c63          	bltz	a0,9fec <v3_demo_run+0x544>
    ae98:	50412783          	lw	a5,1284(sp)
    ae9c:	0d812823          	sw	s8,208(sp)
    aea0:	04012e23          	sw	zero,92(sp)
    aea4:	0cf12a23          	sw	a5,212(sp)
    aea8:	04012c23          	sw	zero,88(sp)
    aeac:	0b412023          	sw	s4,160(sp)
    aeb0:	02d00537          	lui	a0,0x2d00
    aeb4:	e74fe0ef          	jal	9528 <v3_runtime_frame_done>
    aeb8:	00050d93          	mv	s11,a0
    aebc:	92051863          	bnez	a0,9fec <v3_demo_run+0x544>
    aec0:	06412783          	lw	a5,100(sp)
    aec4:	05412703          	lw	a4,84(sp)
    aec8:	00178793          	addi	a5,a5,1
    aecc:	06f12223          	sw	a5,100(sp)
    aed0:	000017b7          	lui	a5,0x1
    aed4:	e1078793          	addi	a5,a5,-496 # e10 <CUSTOM2+0xdb5>
    aed8:	12f71c63          	bne	a4,a5,b010 <v3_demo_run+0x1568>
    aedc:	02d0f6b7          	lui	a3,0x2d0f
    aee0:	5426c603          	lbu	a2,1346(a3) # 2d0f542 <__gpu_framebuffer_a+0xd0f542>
    aee4:	9a060a63          	beqz	a2,a098 <v3_demo_run+0x5f0>
    aee8:	5406d703          	lhu	a4,1344(a3)
    aeec:	25800793          	li	a5,600
    aef0:	9af71463          	bne	a4,a5,a098 <v3_demo_run+0x5f0>
    aef4:	53c6a783          	lw	a5,1340(a3)
    aef8:	5506a703          	lw	a4,1360(a3)
    aefc:	5546d683          	lhu	a3,1364(a3)
    af00:	0000e537          	lui	a0,0xe
    af04:	25800593          	li	a1,600
    af08:	8b850513          	addi	a0,a0,-1864 # d8b8 <_data+0x624>
    af0c:	f7cfe0ef          	jal	9688 <bsp_printf>
    af10:	09412503          	lw	a0,148(sp)
    af14:	06400613          	li	a2,100
    af18:	00000693          	li	a3,0
    af1c:	00000593          	li	a1,0
    af20:	255010ef          	jal	c974 <__udivdi3>
    af24:	02a12e23          	sw	a0,60(sp)
    af28:	0ac12503          	lw	a0,172(sp)
    af2c:	06400613          	li	a2,100
    af30:	00000693          	li	a3,0
    af34:	00000593          	li	a1,0
    af38:	23d010ef          	jal	c974 <__udivdi3>
    af3c:	0b812583          	lw	a1,184(sp)
    af40:	02a12c23          	sw	a0,56(sp)
    af44:	08012503          	lw	a0,128(sp)
    af48:	00058637          	lui	a2,0x58
    af4c:	e4060613          	addi	a2,a2,-448 # 57e40 <__freertos_irq_stack_top+0x3a3c0>
    af50:	00000693          	li	a3,0
    af54:	221010ef          	jal	c974 <__udivdi3>
    af58:	08412603          	lw	a2,132(sp)
    af5c:	0bc12683          	lw	a3,188(sp)
    af60:	02a12a23          	sw	a0,52(sp)
    af64:	34600593          	li	a1,838
    af68:	30b8a537          	lui	a0,0x30b8a
    af6c:	209010ef          	jal	c974 <__udivdi3>
    af70:	00050413          	mv	s0,a0
    af74:	09c12503          	lw	a0,156(sp)
    af78:	06400613          	li	a2,100
    af7c:	00000693          	li	a3,0
    af80:	00000593          	li	a1,0
    af84:	1f1010ef          	jal	c974 <__udivdi3>
    af88:	0c012583          	lw	a1,192(sp)
    af8c:	02a12023          	sw	a0,32(sp)
    af90:	08812503          	lw	a0,136(sp)
    af94:	00058637          	lui	a2,0x58
    af98:	e4060613          	addi	a2,a2,-448 # 57e40 <__freertos_irq_stack_top+0x3a3c0>
    af9c:	00000693          	li	a3,0
    afa0:	1d5010ef          	jal	c974 <__udivdi3>
    afa4:	0b012783          	lw	a5,176(sp)
    afa8:	09012883          	lw	a7,144(sp)
    afac:	03c12803          	lw	a6,60(sp)
    afb0:	00f12c23          	sw	a5,24(sp)
    afb4:	07012783          	lw	a5,112(sp)
    afb8:	03412703          	lw	a4,52(sp)
    afbc:	00a12e23          	sw	a0,28(sp)
    afc0:	00f12a23          	sw	a5,20(sp)
    afc4:	09812783          	lw	a5,152(sp)
    afc8:	00012423          	sw	zero,8(sp)
    afcc:	00012223          	sw	zero,4(sp)
    afd0:	00f12823          	sw	a5,16(sp)
    afd4:	06812783          	lw	a5,104(sp)
    afd8:	0000e537          	lui	a0,0xe
    afdc:	00040693          	mv	a3,s0
    afe0:	00f12623          	sw	a5,12(sp)
    afe4:	0a812783          	lw	a5,168(sp)
    afe8:	40000593          	li	a1,1024
    afec:	8f850513          	addi	a0,a0,-1800 # d8f8 <_data+0x664>
    aff0:	00f12023          	sw	a5,0(sp)
    aff4:	03812783          	lw	a5,56(sp)
    aff8:	05412603          	lw	a2,84(sp)
    affc:	e8cfe0ef          	jal	9688 <bsp_printf>
    b000:	0000e537          	lui	a0,0xe
    b004:	9d850513          	addi	a0,a0,-1576 # d9d8 <_data+0x744>
    b008:	e80fe0ef          	jal	9688 <bsp_printf>
    b00c:	b35fe06f          	j	9b40 <v3_demo_run+0x98>
    b010:	0b312a23          	sw	s3,180(sp)
    b014:	0c812b83          	lw	s7,200(sp)
    b018:	07c12483          	lw	s1,124(sp)
    b01c:	0e012a03          	lw	s4,224(sp)
    b020:	07512023          	sw	s5,96(sp)
    b024:	000b0913          	mv	s2,s6
    b028:	000c8993          	mv	s3,s9
    b02c:	f3dfe06f          	j	9f68 <v3_demo_run+0x4c0>
    b030:	00050d93          	mv	s11,a0
    b034:	fb9fe06f          	j	9fec <v3_demo_run+0x544>
    b038:	920a0863          	beqz	s4,a168 <v3_demo_run+0x6c0>
    b03c:	02d0f7b7          	lui	a5,0x2d0f
    b040:	5777c703          	lbu	a4,1399(a5) # 2d0f577 <__gpu_framebuffer_a+0xd0f577>
    b044:	00070663          	beqz	a4,b050 <v3_demo_run+0x15a8>
    b048:	5747c783          	lbu	a5,1396(a5)
    b04c:	e4078463          	beqz	a5,a694 <v3_demo_run+0xbec>
    b050:	04012a83          	lw	s5,64(sp)
    b054:	918ff06f          	j	a16c <v3_demo_run+0x6c4>

0000b058 <fill>:
    b058:	000088b7          	lui	a7,0x8
    b05c:	fe010113          	addi	sp,sp,-32
    b060:	011508b3          	add	a7,a0,a7
    b064:	00812c23          	sw	s0,24(sp)
    b068:	00068413          	mv	s0,a3
    b06c:	0008d683          	lhu	a3,0(a7) # 8000 <game_update_cached+0xec>
    b070:	01212823          	sw	s2,16(sp)
    b074:	00078913          	mv	s2,a5
    b078:	00168793          	addi	a5,a3,1
    b07c:	00569693          	slli	a3,a3,0x5
    b080:	00912a23          	sw	s1,20(sp)
    b084:	01312623          	sw	s3,12(sp)
    b088:	01412423          	sw	s4,8(sp)
    b08c:	01512223          	sw	s5,4(sp)
    b090:	00112e23          	sw	ra,28(sp)
    b094:	00d506b3          	add	a3,a0,a3
    b098:	00058a13          	mv	s4,a1
    b09c:	00060a93          	mv	s5,a2
    b0a0:	00f89023          	sh	a5,0(a7)
    b0a4:	00000593          	li	a1,0
    b0a8:	02000613          	li	a2,32
    b0ac:	00068513          	mv	a0,a3
    b0b0:	00070993          	mv	s3,a4
    b0b4:	00080493          	mv	s1,a6
    b0b8:	970f60ef          	jal	1228 <memset>
    b0bc:	3c000793          	li	a5,960
    b0c0:	02f40433          	mul	s0,s0,a5
    b0c4:	78000793          	li	a5,1920
    b0c8:	00f52623          	sw	a5,12(a0)
    b0cc:	00100793          	li	a5,1
    b0d0:	00f50e23          	sb	a5,28(a0)
    b0d4:	01c12083          	lw	ra,28(sp)
    b0d8:	01351823          	sh	s3,16(a0)
    b0dc:	01251923          	sh	s2,18(a0)
    b0e0:	00951a23          	sh	s1,20(a0)
    b0e4:	01012903          	lw	s2,16(sp)
    b0e8:	01540433          	add	s0,s0,s5
    b0ec:	00141413          	slli	s0,s0,0x1
    b0f0:	014405b3          	add	a1,s0,s4
    b0f4:	01812403          	lw	s0,24(sp)
    b0f8:	00b52223          	sw	a1,4(a0)
    b0fc:	01412483          	lw	s1,20(sp)
    b100:	00c12983          	lw	s3,12(sp)
    b104:	00812a03          	lw	s4,8(sp)
    b108:	00412a83          	lw	s5,4(sp)
    b10c:	02010113          	addi	sp,sp,32
    b110:	00008067          	ret

0000b114 <text>:
    b114:	fd010113          	addi	sp,sp,-48
    b118:	03212023          	sw	s2,32(sp)
    b11c:	01812423          	sw	s8,8(sp)
    b120:	01912223          	sw	s9,4(sp)
    b124:	02112623          	sw	ra,44(sp)
    b128:	02812423          	sw	s0,40(sp)
    b12c:	02912223          	sw	s1,36(sp)
    b130:	01312e23          	sw	s3,28(sp)
    b134:	01412c23          	sw	s4,24(sp)
    b138:	01512a23          	sw	s5,20(sp)
    b13c:	01612823          	sw	s6,16(sp)
    b140:	01712623          	sw	s7,12(sp)
    b144:	01a12023          	sw	s10,0(sp)
    b148:	0017f793          	andi	a5,a5,1
    b14c:	00050913          	mv	s2,a0
    b150:	00070c13          	mv	s8,a4
    b154:	02c40cb7          	lui	s9,0x2c40
    b158:	00078663          	beqz	a5,b164 <text+0x50>
    b15c:	02c45cb7          	lui	s9,0x2c45
    b160:	cc8c8c93          	addi	s9,s9,-824 # 2c44cc8 <__gpu_framebuffer_a+0xc44cc8>
    b164:	3c000793          	li	a5,960
    b168:	02f68433          	mul	s0,a3,a5
    b16c:	000089b7          	lui	s3,0x8
    b170:	00120d37          	lui	s10,0x120
    b174:	0000da37          	lui	s4,0xd
    b178:	013909b3          	add	s3,s2,s3
    b17c:	1f800a93          	li	s5,504
    b180:	01c00b13          	li	s6,28
    b184:	78000b93          	li	s7,1920
    b188:	00ed0d13          	addi	s10,s10,14 # 12000e <__freertos_irq_stack_top+0x10258e>
    b18c:	00c40433          	add	s0,s0,a2
    b190:	00141413          	slli	s0,s0,0x1
    b194:	00b40433          	add	s0,s0,a1
    b198:	000c4583          	lbu	a1,0(s8)
    b19c:	02059e63          	bnez	a1,b1d8 <text+0xc4>
    b1a0:	02c12083          	lw	ra,44(sp)
    b1a4:	02812403          	lw	s0,40(sp)
    b1a8:	02412483          	lw	s1,36(sp)
    b1ac:	02012903          	lw	s2,32(sp)
    b1b0:	01c12983          	lw	s3,28(sp)
    b1b4:	01812a03          	lw	s4,24(sp)
    b1b8:	01412a83          	lw	s5,20(sp)
    b1bc:	01012b03          	lw	s6,16(sp)
    b1c0:	00c12b83          	lw	s7,12(sp)
    b1c4:	00812c03          	lw	s8,8(sp)
    b1c8:	00412c83          	lw	s9,4(sp)
    b1cc:	00012d03          	lw	s10,0(sp)
    b1d0:	03010113          	addi	sp,sp,48
    b1d4:	00008067          	ret
    b1d8:	538a0513          	addi	a0,s4,1336 # d538 <_data+0x2a4>
    b1dc:	f0df50ef          	jal	10e8 <strchr>
    b1e0:	02600493          	li	s1,38
    b1e4:	00050663          	beqz	a0,b1f0 <text+0xdc>
    b1e8:	538a0493          	addi	s1,s4,1336
    b1ec:	409504b3          	sub	s1,a0,s1
    b1f0:	035484b3          	mul	s1,s1,s5
    b1f4:	0009d783          	lhu	a5,0(s3) # 8000 <game_update_cached+0xec>
    b1f8:	02000613          	li	a2,32
    b1fc:	00000593          	li	a1,0
    b200:	00178713          	addi	a4,a5,1
    b204:	00579793          	slli	a5,a5,0x5
    b208:	00f907b3          	add	a5,s2,a5
    b20c:	00e99023          	sh	a4,0(s3)
    b210:	00078513          	mv	a0,a5
    b214:	814f60ef          	jal	1228 <memset>
    b218:	019484b3          	add	s1,s1,s9
    b21c:	00200713          	li	a4,2
    b220:	00852223          	sw	s0,4(a0)
    b224:	00952023          	sw	s1,0(a0)
    b228:	01652423          	sw	s6,8(a0)
    b22c:	01752623          	sw	s7,12(a0)
    b230:	01a52823          	sw	s10,16(a0)
    b234:	00e50e23          	sb	a4,28(a0)
    b238:	001c0c13          	addi	s8,s8,1
    b23c:	01c40413          	addi	s0,s0,28
    b240:	f59ff06f          	j	b198 <text+0x84>

0000b244 <game_menu_invalidate>:
    b244:	00050463          	beqz	a0,b24c <game_menu_invalidate+0x8>
    b248:	00050823          	sb	zero,16(a0)
    b24c:	00008067          	ret

0000b250 <game_menu_draw>:
    b250:	f4010113          	addi	sp,sp,-192
    b254:	0a112e23          	sw	ra,188(sp)
    b258:	0a812c23          	sw	s0,184(sp)
    b25c:	0a912a23          	sw	s1,180(sp)
    b260:	0b212823          	sw	s2,176(sp)
    b264:	0b312623          	sw	s3,172(sp)
    b268:	0b412423          	sw	s4,168(sp)
    b26c:	0b512223          	sw	s5,164(sp)
    b270:	0b612023          	sw	s6,160(sp)
    b274:	09712e23          	sw	s7,156(sp)
    b278:	09812c23          	sw	s8,152(sp)
    b27c:	09912a23          	sw	s9,148(sp)
    b280:	09a12823          	sw	s10,144(sp)
    b284:	09b12623          	sw	s11,140(sp)
    b288:	00a12023          	sw	a0,0(sp)
    b28c:	00e12423          	sw	a4,8(sp)
    b290:	00f12623          	sw	a5,12(sp)
    b294:	01112223          	sw	a7,4(sp)
    b298:	40050663          	beqz	a0,b6a4 <game_menu_draw+0x454>
    b29c:	01054783          	lbu	a5,16(a0)
    b2a0:	ff800513          	li	a0,-8
    b2a4:	32078463          	beqz	a5,b5cc <game_menu_draw+0x37c>
    b2a8:	00058913          	mv	s2,a1
    b2ac:	32058063          	beqz	a1,b5cc <game_menu_draw+0x37c>
    b2b0:	00080413          	mv	s0,a6
    b2b4:	30080c63          	beqz	a6,b5cc <game_menu_draw+0x37c>
    b2b8:	00100793          	li	a5,1
    b2bc:	00060993          	mv	s3,a2
    b2c0:	30c7e663          	bltu	a5,a2,b5cc <game_menu_draw+0x37c>
    b2c4:	30088463          	beqz	a7,b5cc <game_menu_draw+0x37c>
    b2c8:	00068493          	mv	s1,a3
    b2cc:	020007b7          	lui	a5,0x2000
    b2d0:	00060463          	beqz	a2,b2d8 <game_menu_draw+0x88>
    b2d4:	022007b7          	lui	a5,0x2200
    b2d8:	ff800513          	li	a0,-8
    b2dc:	2e979863          	bne	a5,s1,b5cc <game_menu_draw+0x37c>
    b2e0:	01494783          	lbu	a5,20(s2)
    b2e4:	0fb7f713          	andi	a4,a5,251
    b2e8:	00070663          	beqz	a4,b2f4 <game_menu_draw+0xa4>
    b2ec:	00600713          	li	a4,6
    b2f0:	2ce79e63          	bne	a5,a4,b5cc <game_menu_draw+0x37c>
    b2f4:	00c12703          	lw	a4,12(sp)
    b2f8:	00100a13          	li	s4,1
    b2fc:	013a1a33          	sll	s4,s4,s3
    b300:	00e03c33          	snez	s8,a4
    b304:	00600713          	li	a4,6
    b308:	0ffa7a13          	zext.b	s4,s4
    b30c:	00400a93          	li	s5,4
    b310:	00e79463          	bne	a5,a4,b318 <game_menu_draw+0xc8>
    b314:	00600a93          	li	s5,6
    b318:	01094783          	lbu	a5,16(s2)
    b31c:	0147f733          	and	a4,a5,s4
    b320:	2e071463          	bnez	a4,b608 <game_menu_draw+0x3b8>
    b324:	00008737          	lui	a4,0x8
    b328:	00e40733          	add	a4,s0,a4
    b32c:	00071023          	sh	zero,0(a4) # 8000 <game_update_cached+0xec>
    b330:	00100713          	li	a4,1
    b334:	fffa4693          	not	a3,s4
    b338:	00d7f7b3          	and	a5,a5,a3
    b33c:	00f90823          	sb	a5,16(s2)
    b340:	1e070663          	beqz	a4,b52c <game_menu_draw+0x2dc>
    b344:	00000813          	li	a6,0
    b348:	1d400793          	li	a5,468
    b34c:	3c000713          	li	a4,960
    b350:	04800693          	li	a3,72
    b354:	00000613          	li	a2,0
    b358:	00048593          	mv	a1,s1
    b35c:	00040513          	mv	a0,s0
    b360:	cf9ff0ef          	jal	b058 <fill>
    b364:	0000e737          	lui	a4,0xe
    b368:	00100793          	li	a5,1
    b36c:	a4070713          	addi	a4,a4,-1472 # da40 <_data+0x7ac>
    b370:	06000693          	li	a3,96
    b374:	10e00613          	li	a2,270
    b378:	00048593          	mv	a1,s1
    b37c:	00040513          	mv	a0,s0
    b380:	d95ff0ef          	jal	b114 <text>
    b384:	0000e5b7          	lui	a1,0xe
    b388:	40458b93          	addi	s7,a1,1028 # e404 <counts.0+0x18>
    b38c:	01800613          	li	a2,24
    b390:	40458593          	addi	a1,a1,1028
    b394:	03810513          	addi	a0,sp,56
    b398:	f6df50ef          	jal	1304 <memcpy>
    b39c:	01800613          	li	a2,24
    b3a0:	018b8593          	addi	a1,s7,24 # 5018 <bullet_enemy_position+0x60>
    b3a4:	05010513          	addi	a0,sp,80
    b3a8:	f5df50ef          	jal	1304 <memcpy>
    b3ac:	01000613          	li	a2,16
    b3b0:	030b8593          	addi	a1,s7,48
    b3b4:	02810513          	addi	a0,sp,40
    b3b8:	f4df50ef          	jal	1304 <memcpy>
    b3bc:	01800613          	li	a2,24
    b3c0:	040b8593          	addi	a1,s7,64
    b3c4:	06810513          	addi	a0,sp,104
    b3c8:	f3df50ef          	jal	1304 <memcpy>
    b3cc:	ffaa8793          	addi	a5,s5,-6
    b3d0:	0017b713          	seqz	a4,a5
    b3d4:	06800313          	li	t1,104
    b3d8:	00079463          	bnez	a5,b3e0 <game_menu_draw+0x190>
    b3dc:	05000313          	li	t1,80
    b3e0:	ffc30793          	addi	a5,t1,-4
    b3e4:	00f12823          	sw	a5,16(sp)
    b3e8:	26070463          	beqz	a4,b650 <game_menu_draw+0x400>
    b3ec:	00e00d93          	li	s11,14
    b3f0:	02e00d13          	li	s10,46
    b3f4:	002a9e13          	slli	t3,s5,0x2
    b3f8:	00000b13          	li	s6,0
    b3fc:	00600e93          	li	t4,6
    b400:	05010793          	addi	a5,sp,80
    b404:	01da8463          	beq	s5,t4,b40c <game_menu_draw+0x1bc>
    b408:	02810793          	addi	a5,sp,40
    b40c:	016787b3          	add	a5,a5,s6
    b410:	0007ac83          	lw	s9,0(a5) # 2200000 <__gpu_framebuffer_a+0x200000>
    b414:	03810793          	addi	a5,sp,56
    b418:	016787b3          	add	a5,a5,s6
    b41c:	0007ab83          	lw	s7,0(a5)
    b420:	7e000813          	li	a6,2016
    b424:	00030793          	mv	a5,t1
    b428:	17000713          	li	a4,368
    b42c:	000c8693          	mv	a3,s9
    b430:	000b8613          	mv	a2,s7
    b434:	00048593          	mv	a1,s1
    b438:	00040513          	mv	a0,s0
    b43c:	01c12e23          	sw	t3,28(sp)
    b440:	00612c23          	sw	t1,24(sp)
    b444:	c15ff0ef          	jal	b058 <fill>
    b448:	01012783          	lw	a5,16(sp)
    b44c:	00000813          	li	a6,0
    b450:	16c00713          	li	a4,364
    b454:	002c8693          	addi	a3,s9,2
    b458:	002b8613          	addi	a2,s7,2
    b45c:	00048593          	mv	a1,s1
    b460:	00040513          	mv	a0,s0
    b464:	bf5ff0ef          	jal	b058 <fill>
    b468:	06810793          	addi	a5,sp,104
    b46c:	01678733          	add	a4,a5,s6
    b470:	00072703          	lw	a4,0(a4)
    b474:	010b8613          	addi	a2,s7,16
    b478:	00000793          	li	a5,0
    b47c:	019d86b3          	add	a3,s11,s9
    b480:	00048593          	mv	a1,s1
    b484:	00040513          	mv	a0,s0
    b488:	00c12a23          	sw	a2,20(sp)
    b48c:	c89ff0ef          	jal	b114 <text>
    b490:	01412603          	lw	a2,20(sp)
    b494:	0000e737          	lui	a4,0xe
    b498:	00100793          	li	a5,1
    b49c:	a5470713          	addi	a4,a4,-1452 # da54 <_data+0x7c0>
    b4a0:	019d06b3          	add	a3,s10,s9
    b4a4:	00048593          	mv	a1,s1
    b4a8:	00040513          	mv	a0,s0
    b4ac:	c69ff0ef          	jal	b114 <text>
    b4b0:	01c12e03          	lw	t3,28(sp)
    b4b4:	004b0b13          	addi	s6,s6,4
    b4b8:	01812303          	lw	t1,24(sp)
    b4bc:	00600e93          	li	t4,6
    b4c0:	f5cb10e3          	bne	s6,t3,b400 <game_menu_draw+0x1b0>
    b4c4:	01394783          	lbu	a5,19(s2)
    b4c8:	18078a63          	beqz	a5,b65c <game_menu_draw+0x40c>
    b4cc:	7e000813          	li	a6,2016
    b4d0:	03000793          	li	a5,48
    b4d4:	30000713          	li	a4,768
    b4d8:	19c00693          	li	a3,412
    b4dc:	06000613          	li	a2,96
    b4e0:	00048593          	mv	a1,s1
    b4e4:	00040513          	mv	a0,s0
    b4e8:	b71ff0ef          	jal	b058 <fill>
    b4ec:	02c00793          	li	a5,44
    b4f0:	2fc00713          	li	a4,764
    b4f4:	19e00693          	li	a3,414
    b4f8:	06200613          	li	a2,98
    b4fc:	00000813          	li	a6,0
    b500:	00048593          	mv	a1,s1
    b504:	00040513          	mv	a0,s0
    b508:	b51ff0ef          	jal	b058 <fill>
    b50c:	0000e737          	lui	a4,0xe
    b510:	00100793          	li	a5,1
    b514:	a6470713          	addi	a4,a4,-1436 # da64 <_data+0x7d0>
    b518:	1aa00693          	li	a3,426
    b51c:	06c00613          	li	a2,108
    b520:	00048593          	mv	a1,s1
    b524:	00040513          	mv	a0,s0
    b528:	bedff0ef          	jal	b114 <text>
    b52c:	01200793          	li	a5,18
    b530:	00000813          	li	a6,0
    b534:	25800713          	li	a4,600
    b538:	1e000693          	li	a3,480
    b53c:	06000613          	li	a2,96
    b540:	00048593          	mv	a1,s1
    b544:	00040513          	mv	a0,s0
    b548:	b11ff0ef          	jal	b058 <fill>
    b54c:	00c12783          	lw	a5,12(sp)
    b550:	12078263          	beqz	a5,b674 <game_menu_draw+0x424>
    b554:	0000e737          	lui	a4,0xe
    b558:	a1470713          	addi	a4,a4,-1516 # da14 <_data+0x780>
    b55c:	000c0793          	mv	a5,s8
    b560:	1e000693          	li	a3,480
    b564:	06000613          	li	a2,96
    b568:	00048593          	mv	a1,s1
    b56c:	00040513          	mv	a0,s0
    b570:	00008cb7          	lui	s9,0x8
    b574:	ba1ff0ef          	jal	b114 <text>
    b578:	00000b93          	li	s7,0
    b57c:	06011423          	sh	zero,104(sp)
    b580:	01940cb3          	add	s9,s0,s9
    b584:	000cd783          	lhu	a5,0(s9) # 8000 <game_update_cached+0xec>
    b588:	0efbec63          	bltu	s7,a5,b680 <game_menu_draw+0x430>
    b58c:	00412603          	lw	a2,4(sp)
    b590:	06815583          	lhu	a1,104(sp)
    b594:	00012503          	lw	a0,0(sp)
    b598:	e31f60ef          	jal	23c8 <gpu_wait_tag>
    b59c:	02051863          	bnez	a0,b5cc <game_menu_draw+0x37c>
    b5a0:	00812703          	lw	a4,8(sp)
    b5a4:	00299793          	slli	a5,s3,0x2
    b5a8:	00f907b3          	add	a5,s2,a5
    b5ac:	0097a023          	sw	s1,0(a5)
    b5b0:	00e7a423          	sw	a4,8(a5)
    b5b4:	013909b3          	add	s3,s2,s3
    b5b8:	018988a3          	sb	s8,17(s3)
    b5bc:	01598aa3          	sb	s5,21(s3)
    b5c0:	01094783          	lbu	a5,16(s2)
    b5c4:	00fa6a33          	or	s4,s4,a5
    b5c8:	01490823          	sb	s4,16(s2)
    b5cc:	0bc12083          	lw	ra,188(sp)
    b5d0:	0b812403          	lw	s0,184(sp)
    b5d4:	0b412483          	lw	s1,180(sp)
    b5d8:	0b012903          	lw	s2,176(sp)
    b5dc:	0ac12983          	lw	s3,172(sp)
    b5e0:	0a812a03          	lw	s4,168(sp)
    b5e4:	0a412a83          	lw	s5,164(sp)
    b5e8:	0a012b03          	lw	s6,160(sp)
    b5ec:	09c12b83          	lw	s7,156(sp)
    b5f0:	09812c03          	lw	s8,152(sp)
    b5f4:	09412c83          	lw	s9,148(sp)
    b5f8:	09012d03          	lw	s10,144(sp)
    b5fc:	08c12d83          	lw	s11,140(sp)
    b600:	0c010113          	addi	sp,sp,192
    b604:	00008067          	ret
    b608:	00299713          	slli	a4,s3,0x2
    b60c:	00e90733          	add	a4,s2,a4
    b610:	00872683          	lw	a3,8(a4)
    b614:	00812603          	lw	a2,8(sp)
    b618:	d0c696e3          	bne	a3,a2,b324 <game_menu_draw+0xd4>
    b61c:	00072703          	lw	a4,0(a4)
    b620:	d09712e3          	bne	a4,s1,b324 <game_menu_draw+0xd4>
    b624:	013906b3          	add	a3,s2,s3
    b628:	0156c703          	lbu	a4,21(a3)
    b62c:	cf571ce3          	bne	a4,s5,b324 <game_menu_draw+0xd4>
    b630:	00008737          	lui	a4,0x8
    b634:	00e40733          	add	a4,s0,a4
    b638:	00071023          	sh	zero,0(a4) # 8000 <game_update_cached+0xec>
    b63c:	0116c703          	lbu	a4,17(a3)
    b640:	00000513          	li	a0,0
    b644:	f98704e3          	beq	a4,s8,b5cc <game_menu_draw+0x37c>
    b648:	00000713          	li	a4,0
    b64c:	ce9ff06f          	j	b334 <game_menu_draw+0xe4>
    b650:	01400d93          	li	s11,20
    b654:	03800d13          	li	s10,56
    b658:	d9dff06f          	j	b3f4 <game_menu_draw+0x1a4>
    b65c:	0000e737          	lui	a4,0xe
    b660:	00000793          	li	a5,0
    b664:	a8870713          	addi	a4,a4,-1400 # da88 <_data+0x7f4>
    b668:	1b400693          	li	a3,436
    b66c:	06000613          	li	a2,96
    b670:	eb1ff06f          	j	b520 <game_menu_draw+0x2d0>
    b674:	0000e737          	lui	a4,0xe
    b678:	a2870713          	addi	a4,a4,-1496 # da28 <_data+0x794>
    b67c:	ee1ff06f          	j	b55c <game_menu_draw+0x30c>
    b680:	00412603          	lw	a2,4(sp)
    b684:	00012503          	lw	a0,0(sp)
    b688:	005b9593          	slli	a1,s7,0x5
    b68c:	06810693          	addi	a3,sp,104
    b690:	00b405b3          	add	a1,s0,a1
    b694:	ff4f60ef          	jal	1e88 <gpu_submit>
    b698:	f2051ae3          	bnez	a0,b5cc <game_menu_draw+0x37c>
    b69c:	001b8b93          	addi	s7,s7,1
    b6a0:	ee5ff06f          	j	b584 <game_menu_draw+0x334>
    b6a4:	ff800513          	li	a0,-8
    b6a8:	f25ff06f          	j	b5cc <game_menu_draw+0x37c>

0000b6ac <append>:
    b6ac:	00452303          	lw	t1,4(a0)
    b6b0:	00032e03          	lw	t3,0(t1)
    b6b4:	08be0263          	beq	t3,a1,b738 <append+0x8c>
    b6b8:	00052503          	lw	a0,0(a0)
    b6bc:	001e0593          	addi	a1,t3,1
    b6c0:	004e1e13          	slli	t3,t3,0x4
    b6c4:	00b32023          	sw	a1,0(t1)
    b6c8:	01c50533          	add	a0,a0,t3
    b6cc:	00e52423          	sw	a4,8(a0)
    b6d0:	01081713          	slli	a4,a6,0x10
    b6d4:	00f76733          	or	a4,a4,a5
    b6d8:	030787b3          	mul	a5,a5,a6
    b6dc:	fff60593          	addi	a1,a2,-1
    b6e0:	00e52623          	sw	a4,12(a0)
    b6e4:	0015b593          	seqz	a1,a1
    b6e8:	00c32703          	lw	a4,12(t1)
    b6ec:	01089893          	slli	a7,a7,0x10
    b6f0:	00859593          	slli	a1,a1,0x8
    b6f4:	00c8e8b3          	or	a7,a7,a2
    b6f8:	0115e5b3          	or	a1,a1,a7
    b6fc:	00b52023          	sw	a1,0(a0)
    b700:	00f70733          	add	a4,a4,a5
    b704:	00d52223          	sw	a3,4(a0)
    b708:	00e32623          	sw	a4,12(t1)
    b70c:	00100713          	li	a4,1
    b710:	00e60663          	beq	a2,a4,b71c <append+0x70>
    b714:	00000513          	li	a0,0
    b718:	00008067          	ret
    b71c:	00832703          	lw	a4,8(t1)
    b720:	00170713          	addi	a4,a4,1
    b724:	00e32423          	sw	a4,8(t1)
    b728:	01032703          	lw	a4,16(t1)
    b72c:	00f707b3          	add	a5,a4,a5
    b730:	00f32823          	sw	a5,16(t1)
    b734:	fe1ff06f          	j	b714 <append+0x68>
    b738:	ffc00513          	li	a0,-4
    b73c:	00008067          	ret

0000b740 <clipped_sprite>:
    b740:	fa010113          	addi	sp,sp,-96
    b744:	05512223          	sw	s5,68(sp)
    b748:	06412a83          	lw	s5,100(sp)
    b74c:	04112e23          	sw	ra,92(sp)
    b750:	04812c23          	sw	s0,88(sp)
    b754:	04912a23          	sw	s1,84(sp)
    b758:	05212823          	sw	s2,80(sp)
    b75c:	05312623          	sw	s3,76(sp)
    b760:	05412423          	sw	s4,72(sp)
    b764:	05612023          	sw	s6,64(sp)
    b768:	03712e23          	sw	s7,60(sp)
    b76c:	03812c23          	sw	s8,56(sp)
    b770:	03912a23          	sw	s9,52(sp)
    b774:	03a12823          	sw	s10,48(sp)
    b778:	03b12623          	sw	s11,44(sp)
    b77c:	00d12823          	sw	a3,16(sp)
    b780:	00a12423          	sw	a0,8(sp)
    b784:	00b12623          	sw	a1,12(sp)
    b788:	000aa023          	sw	zero,0(s5)
    b78c:	3bf00693          	li	a3,959
    b790:	04e6d263          	bge	a3,a4,b7d4 <clipped_sprite+0x94>
    b794:	00000513          	li	a0,0
    b798:	05c12083          	lw	ra,92(sp)
    b79c:	05812403          	lw	s0,88(sp)
    b7a0:	05412483          	lw	s1,84(sp)
    b7a4:	05012903          	lw	s2,80(sp)
    b7a8:	04c12983          	lw	s3,76(sp)
    b7ac:	04812a03          	lw	s4,72(sp)
    b7b0:	04412a83          	lw	s5,68(sp)
    b7b4:	04012b03          	lw	s6,64(sp)
    b7b8:	03c12b83          	lw	s7,60(sp)
    b7bc:	03812c03          	lw	s8,56(sp)
    b7c0:	03412c83          	lw	s9,52(sp)
    b7c4:	03012d03          	lw	s10,48(sp)
    b7c8:	02c12d83          	lw	s11,44(sp)
    b7cc:	06010113          	addi	sp,sp,96
    b7d0:	00008067          	ret
    b7d4:	410006b3          	neg	a3,a6
    b7d8:	00080d93          	mv	s11,a6
    b7dc:	fae6dce3          	bge	a3,a4,b794 <clipped_sprite+0x54>
    b7e0:	21b00693          	li	a3,539
    b7e4:	faf6c8e3          	blt	a3,a5,b794 <clipped_sprite+0x54>
    b7e8:	04800593          	li	a1,72
    b7ec:	410586b3          	sub	a3,a1,a6
    b7f0:	faf6d2e3          	bge	a3,a5,b794 <clipped_sprite+0x54>
    b7f4:	00060c13          	mv	s8,a2
    b7f8:	40e006b3          	neg	a3,a4
    b7fc:	41f75613          	srai	a2,a4,0x1f
    b800:	00c6f933          	and	s2,a3,a2
    b804:	04700613          	li	a2,71
    b808:	00000493          	li	s1,0
    b80c:	00f64463          	blt	a2,a5,b814 <clipped_sprite+0xd4>
    b810:	40f584b3          	sub	s1,a1,a5
    b814:	00070b13          	mv	s6,a4
    b818:	00075463          	bgez	a4,b820 <clipped_sprite+0xe0>
    b81c:	00000b13          	li	s6,0
    b820:	00078413          	mv	s0,a5
    b824:	04800793          	li	a5,72
    b828:	00f45463          	bge	s0,a5,b830 <clipped_sprite+0xf0>
    b82c:	04800413          	li	s0,72
    b830:	3c000793          	li	a5,960
    b834:	412d8733          	sub	a4,s11,s2
    b838:	416787b3          	sub	a5,a5,s6
    b83c:	00f77463          	bgeu	a4,a5,b844 <clipped_sprite+0x104>
    b840:	00070793          	mv	a5,a4
    b844:	21c00813          	li	a6,540
    b848:	409d8733          	sub	a4,s11,s1
    b84c:	40880833          	sub	a6,a6,s0
    b850:	01077463          	bgeu	a4,a6,b858 <clipped_sprite+0x118>
    b854:	00070813          	mv	a6,a4
    b858:	06012683          	lw	a3,96(sp)
    b85c:	fff00713          	li	a4,-1
    b860:	04e69263          	bne	a3,a4,b8a4 <clipped_sprite+0x164>
    b864:	3c000313          	li	t1,960
    b868:	02640333          	mul	t1,s0,t1
    b86c:	01012603          	lw	a2,16(sp)
    b870:	00c12583          	lw	a1,12(sp)
    b874:	00812503          	lw	a0,8(sp)
    b878:	03b48733          	mul	a4,s1,s11
    b87c:	01630333          	add	t1,t1,s6
    b880:	00131313          	slli	t1,t1,0x1
    b884:	018306b3          	add	a3,t1,s8
    b888:	01270733          	add	a4,a4,s2
    b88c:	00171713          	slli	a4,a4,0x1
    b890:	e1dff0ef          	jal	b6ac <append>
    b894:	f00512e3          	bnez	a0,b798 <clipped_sprite+0x58>
    b898:	00100793          	li	a5,1
    b89c:	00faa023          	sw	a5,0(s5)
    b8a0:	ef9ff06f          	j	b798 <clipped_sprite+0x58>
    b8a4:	00996bb3          	or	s7,s2,s1
    b8a8:	020b8263          	beqz	s7,b8cc <clipped_sprite+0x18c>
    b8ac:	00048b93          	mv	s7,s1
    b8b0:	00000d13          	li	s10,0
    b8b4:	010489b3          	add	s3,s1,a6
    b8b8:	00f90a33          	add	s4,s2,a5
    b8bc:	073bf063          	bgeu	s7,s3,b91c <clipped_sprite+0x1dc>
    b8c0:	fa0d12e3          	bnez	s10,b864 <clipped_sprite+0x124>
    b8c4:	00090c93          	mv	s9,s2
    b8c8:	0400006f          	j	b908 <clipped_sprite+0x1c8>
    b8cc:	ffb7e2e3          	bltu	a5,s11,b8b0 <clipped_sprite+0x170>
    b8d0:	ffb860e3          	bltu	a6,s11,b8b0 <clipped_sprite+0x170>
    b8d4:	f91ff06f          	j	b864 <clipped_sprite+0x124>
    b8d8:	06012503          	lw	a0,96(sp)
    b8dc:	000b8613          	mv	a2,s7
    b8e0:	000c8593          	mv	a1,s9
    b8e4:	01112e23          	sw	a7,28(sp)
    b8e8:	01012c23          	sw	a6,24(sp)
    b8ec:	00f12a23          	sw	a5,20(sp)
    b8f0:	c94fa0ef          	jal	5d84 <bullet_shape_opaque>
    b8f4:	01412783          	lw	a5,20(sp)
    b8f8:	01812803          	lw	a6,24(sp)
    b8fc:	01c12883          	lw	a7,28(sp)
    b900:	00051a63          	bnez	a0,b914 <clipped_sprite+0x1d4>
    b904:	001c8c93          	addi	s9,s9,1
    b908:	fd4ce8e3          	bltu	s9,s4,b8d8 <clipped_sprite+0x198>
    b90c:	001b8b93          	addi	s7,s7,1
    b910:	fadff06f          	j	b8bc <clipped_sprite+0x17c>
    b914:	00100d13          	li	s10,1
    b918:	ff5ff06f          	j	b90c <clipped_sprite+0x1cc>
    b91c:	e60d0ce3          	beqz	s10,b794 <clipped_sprite+0x54>
    b920:	f45ff06f          	j	b864 <clipped_sprite+0x124>

0000b924 <sprite>:
    b924:	ff010113          	addi	sp,sp,-16
    b928:	3c000393          	li	t2,960
    b92c:	00812423          	sw	s0,8(sp)
    b930:	00912223          	sw	s1,4(sp)
    b934:	00112623          	sw	ra,12(sp)
    b938:	41038fb3          	sub	t6,t2,a6
    b93c:	00068e93          	mv	t4,a3
    b940:	01012483          	lw	s1,16(sp)
    b944:	01412403          	lw	s0,20(sp)
    b948:	00050313          	mv	t1,a0
    b94c:	00058f13          	mv	t5,a1
    b950:	00080e13          	mv	t3,a6
    b954:	00088693          	mv	a3,a7
    b958:	00efea63          	bltu	t6,a4,b96c <sprite+0x48>
    b95c:	1d400f93          	li	t6,468
    b960:	fb878293          	addi	t0,a5,-72
    b964:	410f8fb3          	sub	t6,t6,a6
    b968:	025ffa63          	bgeu	t6,t0,b99c <sprite+0x78>
    b96c:	00812a23          	sw	s0,20(sp)
    b970:	00812403          	lw	s0,8(sp)
    b974:	00912823          	sw	s1,16(sp)
    b978:	00c12083          	lw	ra,12(sp)
    b97c:	00412483          	lw	s1,4(sp)
    b980:	00068893          	mv	a7,a3
    b984:	000e0813          	mv	a6,t3
    b988:	000e8693          	mv	a3,t4
    b98c:	000f0593          	mv	a1,t5
    b990:	00030513          	mv	a0,t1
    b994:	01010113          	addi	sp,sp,16
    b998:	da9ff06f          	j	b740 <clipped_sprite>
    b99c:	02778333          	mul	t1,a5,t2
    b9a0:	00080793          	mv	a5,a6
    b9a4:	00e30333          	add	t1,t1,a4
    b9a8:	00131313          	slli	t1,t1,0x1
    b9ac:	00c306b3          	add	a3,t1,a2
    b9b0:	00000713          	li	a4,0
    b9b4:	000e8613          	mv	a2,t4
    b9b8:	cf5ff0ef          	jal	b6ac <append>
    b9bc:	00153793          	seqz	a5,a0
    b9c0:	00c12083          	lw	ra,12(sp)
    b9c4:	00f42023          	sw	a5,0(s0)
    b9c8:	00812403          	lw	s0,8(sp)
    b9cc:	00412483          	lw	s1,4(sp)
    b9d0:	01010113          	addi	sp,sp,16
    b9d4:	00008067          	ret

0000b9d8 <gpu_instances_init>:
    b9d8:	00050793          	mv	a5,a0
    b9dc:	ff800513          	li	a0,-8
    b9e0:	04078863          	beqz	a5,ba30 <gpu_instances_init+0x58>
    b9e4:	04058663          	beqz	a1,ba30 <gpu_instances_init+0x58>
    b9e8:	0105c703          	lbu	a4,16(a1)
    b9ec:	04070263          	beqz	a4,ba30 <gpu_instances_init+0x58>
    b9f0:	0005a703          	lw	a4,0(a1)
    b9f4:	0007a223          	sw	zero,4(a5)
    b9f8:	00b7a023          	sw	a1,0(a5)
    b9fc:	00872683          	lw	a3,8(a4)
    ba00:	01169613          	slli	a2,a3,0x11
    ba04:	00064663          	bltz	a2,ba10 <gpu_instances_init+0x38>
    ba08:	00000513          	li	a0,0
    ba0c:	00008067          	ret
    ba10:	40072683          	lw	a3,1024(a4)
    ba14:	494e5737          	lui	a4,0x494e5
    ba18:	33170713          	addi	a4,a4,817 # 494e5331 <__gpu_framebuffer_a+0x474e5331>
    ba1c:	fff00513          	li	a0,-1
    ba20:	00e69863          	bne	a3,a4,ba30 <gpu_instances_init+0x58>
    ba24:	00100713          	li	a4,1
    ba28:	00e78223          	sb	a4,4(a5)
    ba2c:	fddff06f          	j	ba08 <gpu_instances_init+0x30>
    ba30:	00008067          	ret

0000ba34 <gpu_instances_templates>:
    ba34:	12058063          	beqz	a1,bb54 <gpu_instances_templates+0x120>
    ba38:	ff010113          	addi	sp,sp,-16
    ba3c:	00912223          	sw	s1,4(sp)
    ba40:	00112623          	sw	ra,12(sp)
    ba44:	00050493          	mv	s1,a0
    ba48:	00812423          	sw	s0,8(sp)
    ba4c:	00100793          	li	a5,1
    ba50:	00000513          	li	a0,0
    ba54:	1097e463          	bltu	a5,s1,bb5c <gpu_instances_templates+0x128>
    ba58:	00058413          	mv	s0,a1
    ba5c:	1c000613          	li	a2,448
    ba60:	00000593          	li	a1,0
    ba64:	00040513          	mv	a0,s0
    ba68:	fc0f50ef          	jal	1228 <memset>
    ba6c:	0c048063          	beqz	s1,bb2c <gpu_instances_templates+0xf8>
    ba70:	02a005b7          	lui	a1,0x2a00
    ba74:	029007b7          	lui	a5,0x2900
    ba78:	00f42223          	sw	a5,4(s0)
    ba7c:	78000793          	li	a5,1920
    ba80:	00f42423          	sw	a5,8(s0)
    ba84:	00f42623          	sw	a5,12(s0)
    ba88:	3c000793          	li	a5,960
    ba8c:	00200713          	li	a4,2
    ba90:	00f42823          	sw	a5,16(s0)
    ba94:	000106b7          	lui	a3,0x10
    ba98:	21c00793          	li	a5,540
    ba9c:	fffff637          	lui	a2,0xfffff
    baa0:	00e42023          	sw	a4,0(s0)
    baa4:	00f42a23          	sw	a5,20(s0)
    baa8:	00042c23          	sw	zero,24(s0)
    baac:	00100513          	li	a0,1
    bab0:	01c40413          	addi	s0,s0,28
    bab4:	00c00713          	li	a4,12
    bab8:	50000793          	li	a5,1280
    babc:	00100893          	li	a7,1
    bac0:	78000313          	li	t1,1920
    bac4:	81f68693          	addi	a3,a3,-2017 # f81f <__global_pointer$+0xab7>
    bac8:	00c00e13          	li	t3,12
    bacc:	00700e93          	li	t4,7
    bad0:	00800f13          	li	t5,8
    bad4:	42060613          	addi	a2,a2,1056 # fffff420 <__gpu_framebuffer_a+0xfdfff420>
    bad8:	00300813          	li	a6,3
    badc:	01151463          	bne	a0,a7,bae4 <gpu_instances_templates+0xb0>
    bae0:	00400813          	li	a6,4
    bae4:	00b787b3          	add	a5,a5,a1
    bae8:	00f42223          	sw	a5,4(s0)
    baec:	00171793          	slli	a5,a4,0x1
    baf0:	01042023          	sw	a6,0(s0)
    baf4:	00f42423          	sw	a5,8(s0)
    baf8:	00642623          	sw	t1,12(s0)
    bafc:	00e42823          	sw	a4,16(s0)
    bb00:	00e42a23          	sw	a4,20(s0)
    bb04:	00d42c23          	sw	a3,24(s0)
    bb08:	00150513          	addi	a0,a0,1
    bb0c:	01c40413          	addi	s0,s0,28
    bb10:	05c50663          	beq	a0,t3,bb5c <gpu_instances_templates+0x128>
    bb14:	02aef263          	bgeu	t4,a0,bb38 <gpu_instances_templates+0x104>
    bb18:	03e50863          	beq	a0,t5,bb48 <gpu_instances_templates+0x114>
    bb1c:	00951793          	slli	a5,a0,0x9
    bb20:	00c787b3          	add	a5,a5,a2
    bb24:	01000713          	li	a4,16
    bb28:	fb1ff06f          	j	bad8 <gpu_instances_templates+0xa4>
    bb2c:	02c005b7          	lui	a1,0x2c00
    bb30:	02b007b7          	lui	a5,0x2b00
    bb34:	f45ff06f          	j	ba78 <gpu_instances_templates+0x44>
    bb38:	00751793          	slli	a5,a0,0x7
    bb3c:	f0078793          	addi	a5,a5,-256 # 2afff00 <__gpu_framebuffer_a+0xafff00>
    bb40:	00800713          	li	a4,8
    bb44:	f95ff06f          	j	bad8 <gpu_instances_templates+0xa4>
    bb48:	01000713          	li	a4,16
    bb4c:	30000793          	li	a5,768
    bb50:	f89ff06f          	j	bad8 <gpu_instances_templates+0xa4>
    bb54:	00000513          	li	a0,0
    bb58:	00008067          	ret
    bb5c:	00c12083          	lw	ra,12(sp)
    bb60:	00812403          	lw	s0,8(sp)
    bb64:	00412483          	lw	s1,4(sp)
    bb68:	01010113          	addi	sp,sp,16
    bb6c:	00008067          	ret

0000bb70 <gpu_instance_expand>:
    bb70:	28050863          	beqz	a0,be00 <gpu_instance_expand+0x290>
    bb74:	00050713          	mv	a4,a0
    bb78:	ff800513          	li	a0,-8
    bb7c:	28058a63          	beqz	a1,be10 <gpu_instance_expand+0x2a0>
    bb80:	28068863          	beqz	a3,be10 <gpu_instance_expand+0x2a0>
    bb84:	0005a783          	lw	a5,0(a1) # 2c00000 <__gpu_framebuffer_a+0xc00000>
    bb88:	fd010113          	addi	sp,sp,-48
    bb8c:	01312e23          	sw	s3,28(sp)
    bb90:	0187d513          	srli	a0,a5,0x18
    bb94:	0087d813          	srli	a6,a5,0x8
    bb98:	01512a23          	sw	s5,20(sp)
    bb9c:	00060993          	mv	s3,a2
    bba0:	0107da93          	srli	s5,a5,0x10
    bba4:	0ff7f613          	zext.b	a2,a5
    bba8:	0f07f793          	andi	a5,a5,240
    bbac:	00f567b3          	or	a5,a0,a5
    bbb0:	02112623          	sw	ra,44(sp)
    bbb4:	02812423          	sw	s0,40(sp)
    bbb8:	02912223          	sw	s1,36(sp)
    bbbc:	03212023          	sw	s2,32(sp)
    bbc0:	01412c23          	sw	s4,24(sp)
    bbc4:	01612823          	sw	s6,16(sp)
    bbc8:	01712623          	sw	s7,12(sp)
    bbcc:	01812423          	sw	s8,8(sp)
    bbd0:	01912223          	sw	s9,4(sp)
    bbd4:	0ff87813          	zext.b	a6,a6
    bbd8:	ff800513          	li	a0,-8
    bbdc:	1e079863          	bnez	a5,bdcc <gpu_instance_expand+0x25c>
    bbe0:	01c00793          	li	a5,28
    bbe4:	02f60633          	mul	a2,a2,a5
    bbe8:	00c5aa03          	lw	s4,12(a1)
    bbec:	00200893          	li	a7,2
    bbf0:	010a1793          	slli	a5,s4,0x10
    bbf4:	0107d793          	srli	a5,a5,0x10
    bbf8:	010a5313          	srli	t1,s4,0x10
    bbfc:	00c70733          	add	a4,a4,a2
    bc00:	00072903          	lw	s2,0(a4)
    bc04:	ffe90613          	addi	a2,s2,-2
    bc08:	1cc8e263          	bltu	a7,a2,bdcc <gpu_instance_expand+0x25c>
    bc0c:	ffc90893          	addi	a7,s2,-4
    bc10:	0018b893          	seqz	a7,a7
    bc14:	1b089c63          	bne	a7,a6,bdcc <gpu_instance_expand+0x25c>
    bc18:	00400513          	li	a0,4
    bc1c:	00a90663          	beq	s2,a0,bc28 <gpu_instance_expand+0xb8>
    bc20:	ff800513          	li	a0,-8
    bc24:	1a0a9463          	bnez	s5,bdcc <gpu_instance_expand+0x25c>
    bc28:	ff800513          	li	a0,-8
    bc2c:	1a078063          	beqz	a5,bdcc <gpu_instance_expand+0x25c>
    bc30:	18030e63          	beqz	t1,bdcc <gpu_instance_expand+0x25c>
    bc34:	01072803          	lw	a6,16(a4)
    bc38:	00010e37          	lui	t3,0x10
    bc3c:	ffee0e13          	addi	t3,t3,-2 # fffe <__global_pointer$+0x1296>
    bc40:	fff80893          	addi	a7,a6,-1
    bc44:	00010f37          	lui	t5,0x10
    bc48:	191e6263          	bltu	t3,a7,bdcc <gpu_instance_expand+0x25c>
    bc4c:	01472e83          	lw	t4,20(a4)
    bc50:	fffe8893          	addi	a7,t4,-1
    bc54:	171e6c63          	bltu	t3,a7,bdcc <gpu_instance_expand+0x25c>
    bc58:	16f86a63          	bltu	a6,a5,bdcc <gpu_instance_expand+0x25c>
    bc5c:	166ee863          	bltu	t4,t1,bdcc <gpu_instance_expand+0x25c>
    bc60:	01872b03          	lw	s6,24(a4)
    bc64:	17eb7463          	bgeu	s6,t5,bdcc <gpu_instance_expand+0x25c>
    bc68:	0045ab83          	lw	s7,4(a1)
    bc6c:	0085a583          	lw	a1,8(a1)
    bc70:	00872403          	lw	s0,8(a4)
    bc74:	00c72483          	lw	s1,12(a4)
    bc78:	00472e03          	lw	t3,4(a4)
    bc7c:	00bbe733          	or	a4,s7,a1
    bc80:	00876733          	or	a4,a4,s0
    bc84:	00976733          	or	a4,a4,s1
    bc88:	01c76733          	or	a4,a4,t3
    bc8c:	00177713          	andi	a4,a4,1
    bc90:	12071e63          	bnez	a4,bdcc <gpu_instance_expand+0x25c>
    bc94:	00179793          	slli	a5,a5,0x1
    bc98:	12f46a63          	bltu	s0,a5,bdcc <gpu_instance_expand+0x25c>
    bc9c:	12f4e863          	bltu	s1,a5,bdcc <gpu_instance_expand+0x25c>
    bca0:	fff30313          	addi	t1,t1,-1
    bca4:	02830fb3          	mul	t6,t1,s0
    bca8:	00be0c33          	add	s8,t3,a1
    bcac:	01cc3733          	sltu	a4,s8,t3
    bcb0:	00181813          	slli	a6,a6,0x1
    bcb4:	00000f13          	li	t5,0
    bcb8:	028332b3          	mulhu	t0,t1,s0
    bcbc:	018f8533          	add	a0,t6,s8
    bcc0:	01f53e33          	sltu	t3,a0,t6
    bcc4:	00e28eb3          	add	t4,t0,a4
    bcc8:	01de0e33          	add	t3,t3,t4
    bccc:	00f50eb3          	add	t4,a0,a5
    bcd0:	00aeb533          	sltu	a0,t4,a0
    bcd4:	029333b3          	mulhu	t2,t1,s1
    bcd8:	01c50533          	add	a0,a0,t3
    bcdc:	02930e33          	mul	t3,t1,s1
    bce0:	01778333          	add	t1,a5,s7
    bce4:	00f33cb3          	sltu	s9,t1,a5
    bce8:	00f587b3          	add	a5,a1,a5
    bcec:	00b7b5b3          	sltu	a1,a5,a1
    bcf0:	01f78fb3          	add	t6,a5,t6
    bcf4:	005585b3          	add	a1,a1,t0
    bcf8:	00ffb7b3          	sltu	a5,t6,a5
    bcfc:	00b787b3          	add	a5,a5,a1
    bd00:	019383b3          	add	t2,t2,s9
    bd04:	031405b3          	mul	a1,s0,a7
    bd08:	006e0333          	add	t1,t3,t1
    bd0c:	01c33e33          	sltu	t3,t1,t3
    bd10:	007e0e33          	add	t3,t3,t2
    bd14:	031438b3          	mulhu	a7,s0,a7
    bd18:	01058833          	add	a6,a1,a6
    bd1c:	00b835b3          	sltu	a1,a6,a1
    bd20:	011588b3          	add	a7,a1,a7
    bd24:	0ef8e263          	bltu	a7,a5,be08 <gpu_instance_expand+0x298>
    bd28:	01179463          	bne	a5,a7,bd30 <gpu_instance_expand+0x1c0>
    bd2c:	0df86e63          	bltu	a6,t6,be08 <gpu_instance_expand+0x298>
    bd30:	fe0005b7          	lui	a1,0xfe000
    bd34:	00bc0833          	add	a6,s8,a1
    bd38:	018837b3          	sltu	a5,a6,s8
    bd3c:	fff70893          	addi	a7,a4,-1
    bd40:	011787b3          	add	a5,a5,a7
    bd44:	0c079263          	bnez	a5,be08 <gpu_instance_expand+0x298>
    bd48:	0cb87063          	bgeu	a6,a1,be08 <gpu_instance_expand+0x298>
    bd4c:	0a051e63          	bnez	a0,be08 <gpu_instance_expand+0x298>
    bd50:	100007b7          	lui	a5,0x10000
    bd54:	0bd7ea63          	bltu	a5,t4,be08 <gpu_instance_expand+0x298>
    bd58:	020005b7          	lui	a1,0x2000
    bd5c:	ff800513          	li	a0,-8
    bd60:	06bbe663          	bltu	s7,a1,bdcc <gpu_instance_expand+0x25c>
    bd64:	0a0e1263          	bnez	t3,be08 <gpu_instance_expand+0x298>
    bd68:	0a67e063          	bltu	a5,t1,be08 <gpu_instance_expand+0x298>
    bd6c:	ffd67613          	andi	a2,a2,-3
    bd70:	02061263          	bnez	a2,bd94 <gpu_instance_expand+0x224>
    bd74:	02071063          	bnez	a4,bd94 <gpu_instance_expand+0x224>
    bd78:	006c7e63          	bgeu	s8,t1,bd94 <gpu_instance_expand+0x224>
    bd7c:	01dbfc63          	bgeu	s7,t4,bd94 <gpu_instance_expand+0x224>
    bd80:	00400793          	li	a5,4
    bd84:	04f91463          	bne	s2,a5,bdcc <gpu_instance_expand+0x25c>
    bd88:	098b9063          	bne	s7,s8,be08 <gpu_instance_expand+0x298>
    bd8c:	06ef1e63          	bne	t5,a4,be08 <gpu_instance_expand+0x298>
    bd90:	02941e63          	bne	s0,s1,bdcc <gpu_instance_expand+0x25c>
    bd94:	02000613          	li	a2,32
    bd98:	00000593          	li	a1,0
    bd9c:	00068513          	mv	a0,a3
    bda0:	c88f50ef          	jal	1228 <memset>
    bda4:	01852023          	sw	s8,0(a0)
    bda8:	01752223          	sw	s7,4(a0)
    bdac:	00852423          	sw	s0,8(a0)
    bdb0:	00952623          	sw	s1,12(a0)
    bdb4:	01452823          	sw	s4,16(a0)
    bdb8:	01651b23          	sh	s6,22(a0)
    bdbc:	01351d23          	sh	s3,26(a0)
    bdc0:	01250e23          	sb	s2,28(a0)
    bdc4:	01550ea3          	sb	s5,29(a0)
    bdc8:	00000513          	li	a0,0
    bdcc:	02c12083          	lw	ra,44(sp)
    bdd0:	02812403          	lw	s0,40(sp)
    bdd4:	02412483          	lw	s1,36(sp)
    bdd8:	02012903          	lw	s2,32(sp)
    bddc:	01c12983          	lw	s3,28(sp)
    bde0:	01812a03          	lw	s4,24(sp)
    bde4:	01412a83          	lw	s5,20(sp)
    bde8:	01012b03          	lw	s6,16(sp)
    bdec:	00c12b83          	lw	s7,12(sp)
    bdf0:	00812c03          	lw	s8,8(sp)
    bdf4:	00412c83          	lw	s9,4(sp)
    bdf8:	03010113          	addi	sp,sp,48
    bdfc:	00008067          	ret
    be00:	ff800513          	li	a0,-8
    be04:	00008067          	ret
    be08:	ff800513          	li	a0,-8
    be0c:	fc1ff06f          	j	bdcc <gpu_instance_expand+0x25c>
    be10:	00008067          	ret

0000be14 <gpu_instances_program>:
    be14:	1c050463          	beqz	a0,bfdc <gpu_instances_program+0x1c8>
    be18:	00052783          	lw	a5,0(a0)
    be1c:	fa010113          	addi	sp,sp,-96
    be20:	04912a23          	sw	s1,84(sp)
    be24:	04112e23          	sw	ra,92(sp)
    be28:	04812c23          	sw	s0,88(sp)
    be2c:	05212823          	sw	s2,80(sp)
    be30:	05312623          	sw	s3,76(sp)
    be34:	05412423          	sw	s4,72(sp)
    be38:	05512223          	sw	s5,68(sp)
    be3c:	05612023          	sw	s6,64(sp)
    be40:	03712e23          	sw	s7,60(sp)
    be44:	03812c23          	sw	s8,56(sp)
    be48:	03912a23          	sw	s9,52(sp)
    be4c:	00050493          	mv	s1,a0
    be50:	16078a63          	beqz	a5,bfc4 <gpu_instances_program+0x1b0>
    be54:	00058993          	mv	s3,a1
    be58:	16058663          	beqz	a1,bfc4 <gpu_instances_program+0x1b0>
    be5c:	fff60713          	addi	a4,a2,-1
    be60:	00f00693          	li	a3,15
    be64:	00060b93          	mv	s7,a2
    be68:	14e6ee63          	bltu	a3,a4,bfc4 <gpu_instances_program+0x1b0>
    be6c:	00454703          	lbu	a4,4(a0)
    be70:	02071e63          	bnez	a4,beac <gpu_instances_program+0x98>
    be74:	00000513          	li	a0,0
    be78:	05c12083          	lw	ra,92(sp)
    be7c:	05812403          	lw	s0,88(sp)
    be80:	05412483          	lw	s1,84(sp)
    be84:	05012903          	lw	s2,80(sp)
    be88:	04c12983          	lw	s3,76(sp)
    be8c:	04812a03          	lw	s4,72(sp)
    be90:	04412a83          	lw	s5,68(sp)
    be94:	04012b03          	lw	s6,64(sp)
    be98:	03c12b83          	lw	s7,60(sp)
    be9c:	03812c03          	lw	s8,56(sp)
    bea0:	03412c83          	lw	s9,52(sp)
    bea4:	06010113          	addi	sp,sp,96
    bea8:	00008067          	ret
    beac:	00554703          	lbu	a4,5(a0)
    beb0:	ffd00513          	li	a0,-3
    beb4:	fc0712e3          	bnez	a4,be78 <gpu_instances_program+0x64>
    beb8:	0127c703          	lbu	a4,18(a5) # 10000012 <__gpu_framebuffer_a+0xe000012>
    bebc:	fa071ee3          	bnez	a4,be78 <gpu_instances_program+0x64>
    bec0:	0007ab03          	lw	s6,0(a5)
    bec4:	008b2903          	lw	s2,8(s6)
    bec8:	08097913          	andi	s2,s2,128
    becc:	fa0916e3          	bnez	s2,be78 <gpu_instances_program+0x64>
    bed0:	00010c37          	lui	s8,0x10
    bed4:	00058413          	mv	s0,a1
    bed8:	00058a13          	mv	s4,a1
    bedc:	00000a93          	li	s5,0
    bee0:	02000cb7          	lui	s9,0x2000
    bee4:	fffc0c13          	addi	s8,s8,-1 # ffff <__global_pointer$+0x1297>
    bee8:	000a2783          	lw	a5,0(s4)
    beec:	010a2703          	lw	a4,16(s4)
    bef0:	01010693          	addi	a3,sp,16
    bef4:	ffc78793          	addi	a5,a5,-4
    bef8:	0017b793          	seqz	a5,a5
    befc:	00879793          	slli	a5,a5,0x8
    bf00:	0157e7b3          	or	a5,a5,s5
    bf04:	00f12023          	sw	a5,0(sp)
    bf08:	014a2783          	lw	a5,20(s4)
    bf0c:	01877733          	and	a4,a4,s8
    bf10:	00000613          	li	a2,0
    bf14:	01079793          	slli	a5,a5,0x10
    bf18:	00e7e7b3          	or	a5,a5,a4
    bf1c:	00010593          	mv	a1,sp
    bf20:	00098513          	mv	a0,s3
    bf24:	01912223          	sw	s9,4(sp)
    bf28:	00012423          	sw	zero,8(sp)
    bf2c:	00f12623          	sw	a5,12(sp)
    bf30:	c41ff0ef          	jal	bb70 <gpu_instance_expand>
    bf34:	08051863          	bnez	a0,bfc4 <gpu_instances_program+0x1b0>
    bf38:	001a8793          	addi	a5,s5,1
    bf3c:	01ca0a13          	addi	s4,s4,28
    bf40:	08fb9663          	bne	s7,a5,bfcc <gpu_instances_program+0x1b8>
    bf44:	42cb0693          	addi	a3,s6,1068
    bf48:	00042783          	lw	a5,0(s0)
    bf4c:	01010713          	addi	a4,sp,16
    bf50:	00f12823          	sw	a5,16(sp)
    bf54:	00442783          	lw	a5,4(s0)
    bf58:	00f12a23          	sw	a5,20(sp)
    bf5c:	00842783          	lw	a5,8(s0)
    bf60:	00f12c23          	sw	a5,24(sp)
    bf64:	00c42783          	lw	a5,12(s0)
    bf68:	00f12e23          	sw	a5,28(sp)
    bf6c:	01042783          	lw	a5,16(s0)
    bf70:	02f12023          	sw	a5,32(sp)
    bf74:	01442783          	lw	a5,20(s0)
    bf78:	02f12223          	sw	a5,36(sp)
    bf7c:	01842783          	lw	a5,24(s0)
    bf80:	412b2623          	sw	s2,1036(s6)
    bf84:	02f12423          	sw	a5,40(sp)
    bf88:	410b0793          	addi	a5,s6,1040
    bf8c:	00072603          	lw	a2,0(a4)
    bf90:	00478793          	addi	a5,a5,4
    bf94:	00470713          	addi	a4,a4,4
    bf98:	fec7ae23          	sw	a2,-4(a5)
    bf9c:	fef698e3          	bne	a3,a5,bf8c <gpu_instances_program+0x178>
    bfa0:	00190793          	addi	a5,s2,1
    bfa4:	01c40413          	addi	s0,s0,28
    bfa8:	032a9663          	bne	s5,s2,bfd4 <gpu_instances_program+0x1c0>
    bfac:	0ff0000f          	fence
    bfb0:	0004a783          	lw	a5,0(s1)
    bfb4:	0007a783          	lw	a5,0(a5)
    bfb8:	4047a783          	lw	a5,1028(a5)
    bfbc:	0087f793          	andi	a5,a5,8
    bfc0:	ea078ae3          	beqz	a5,be74 <gpu_instances_program+0x60>
    bfc4:	ff800513          	li	a0,-8
    bfc8:	eb1ff06f          	j	be78 <gpu_instances_program+0x64>
    bfcc:	00078a93          	mv	s5,a5
    bfd0:	f19ff06f          	j	bee8 <gpu_instances_program+0xd4>
    bfd4:	00078913          	mv	s2,a5
    bfd8:	f71ff06f          	j	bf48 <gpu_instances_program+0x134>
    bfdc:	ff800513          	li	a0,-8
    bfe0:	00008067          	ret

0000bfe4 <gpu_instances_build_into>:
    bfe4:	f9010113          	addi	sp,sp,-112
    bfe8:	06812423          	sw	s0,104(sp)
    bfec:	07012403          	lw	s0,112(sp)
    bff0:	06112623          	sw	ra,108(sp)
    bff4:	06912223          	sw	s1,100(sp)
    bff8:	07212023          	sw	s2,96(sp)
    bffc:	05312e23          	sw	s3,92(sp)
    c000:	05412c23          	sw	s4,88(sp)
    c004:	05512a23          	sw	s5,84(sp)
    c008:	05612823          	sw	s6,80(sp)
    c00c:	05712623          	sw	s7,76(sp)
    c010:	05812423          	sw	s8,72(sp)
    c014:	05912223          	sw	s9,68(sp)
    c018:	05a12023          	sw	s10,64(sp)
    c01c:	03b12e23          	sw	s11,60(sp)
    c020:	04041263          	bnez	s0,c064 <gpu_instances_build_into+0x80>
    c024:	ff800513          	li	a0,-8
    c028:	06c12083          	lw	ra,108(sp)
    c02c:	06812403          	lw	s0,104(sp)
    c030:	06412483          	lw	s1,100(sp)
    c034:	06012903          	lw	s2,96(sp)
    c038:	05c12983          	lw	s3,92(sp)
    c03c:	05812a03          	lw	s4,88(sp)
    c040:	05412a83          	lw	s5,84(sp)
    c044:	05012b03          	lw	s6,80(sp)
    c048:	04c12b83          	lw	s7,76(sp)
    c04c:	04812c03          	lw	s8,72(sp)
    c050:	04412c83          	lw	s9,68(sp)
    c054:	04012d03          	lw	s10,64(sp)
    c058:	03c12d83          	lw	s11,60(sp)
    c05c:	07010113          	addi	sp,sp,112
    c060:	00008067          	ret
    c064:	00042823          	sw	zero,16(s0)
    c068:	00042423          	sw	zero,8(s0)
    c06c:	00042623          	sw	zero,12(s0)
    c070:	00042223          	sw	zero,4(s0)
    c074:	00042023          	sw	zero,0(s0)
    c078:	00050493          	mv	s1,a0
    c07c:	fa0504e3          	beqz	a0,c024 <gpu_instances_build_into+0x40>
    c080:	00088c13          	mv	s8,a7
    c084:	fa0880e3          	beqz	a7,c024 <gpu_instances_build_into+0x40>
    c088:	00005cb7          	lui	s9,0x5
    c08c:	01950cb3          	add	s9,a0,s9
    c090:	00078b93          	mv	s7,a5
    c094:	008ca783          	lw	a5,8(s9) # 5008 <bullet_enemy_position+0x50>
    c098:	00070a13          	mv	s4,a4
    c09c:	3ff00713          	li	a4,1023
    c0a0:	fff78793          	addi	a5,a5,-1
    c0a4:	f8f760e3          	bltu	a4,a5,c024 <gpu_instances_build_into+0x40>
    c0a8:	fff80793          	addi	a5,a6,-1
    c0ac:	48800713          	li	a4,1160
    c0b0:	00080993          	mv	s3,a6
    c0b4:	f6f768e3          	bltu	a4,a5,c024 <gpu_instances_build_into+0x40>
    c0b8:	00058913          	mv	s2,a1
    c0bc:	00060a93          	mv	s5,a2
    c0c0:	00068b13          	mv	s6,a3
    c0c4:	e79f80ef          	jal	4f3c <bullet_campaign_valid>
    c0c8:	f4050ee3          	beqz	a0,c024 <gpu_instances_build_into+0x40>
    c0cc:	000a0663          	beqz	s4,c0d8 <gpu_instances_build_into+0xf4>
    c0d0:	029cc783          	lbu	a5,41(s9)
    c0d4:	f40798e3          	bnez	a5,c024 <gpu_instances_build_into+0x40>
    c0d8:	016aeab3          	or	s5,s5,s6
    c0dc:	014aeab3          	or	s5,s5,s4
    c0e0:	00100793          	li	a5,1
    c0e4:	f557e0e3          	bltu	a5,s5,c024 <gpu_instances_build_into+0x40>
    c0e8:	21b00793          	li	a5,539
    c0ec:	f377ece3          	bltu	a5,s7,c024 <gpu_instances_build_into+0x40>
    c0f0:	ffe00737          	lui	a4,0xffe00
    c0f4:	fff70713          	addi	a4,a4,-1 # ffdfffff <__gpu_framebuffer_a+0xfddfffff>
    c0f8:	00e97733          	and	a4,s2,a4
    c0fc:	020007b7          	lui	a5,0x2000
    c100:	f2f712e3          	bne	a4,a5,c024 <gpu_instances_build_into+0x40>
    c104:	78000713          	li	a4,1920
    c108:	02eb8733          	mul	a4,s7,a4
    c10c:	21c00813          	li	a6,540
    c110:	41780833          	sub	a6,a6,s7
    c114:	00000893          	li	a7,0
    c118:	3c000793          	li	a5,960
    c11c:	00000613          	li	a2,0
    c120:	00098593          	mv	a1,s3
    c124:	02810513          	addi	a0,sp,40
    c128:	03812423          	sw	s8,40(sp)
    c12c:	02812623          	sw	s0,44(sp)
    c130:	012706b3          	add	a3,a4,s2
    c134:	d78ff0ef          	jal	b6ac <append>
    c138:	00005c37          	lui	s8,0x5
    c13c:	00010d37          	lui	s10,0x10
    c140:	00048b93          	mv	s7,s1
    c144:	00048a93          	mv	s5,s1
    c148:	00000c93          	li	s9,0
    c14c:	01848c33          	add	s8,s1,s8
    c150:	01c10d93          	addi	s11,sp,28
    c154:	fff00313          	li	t1,-1
    c158:	00300e13          	li	t3,3
    c15c:	fffd0d13          	addi	s10,s10,-1 # ffff <__global_pointer$+0x1297>
    c160:	00051863          	bnez	a0,c170 <gpu_instances_build_into+0x18c>
    c164:	000b0663          	beqz	s6,c170 <gpu_instances_build_into+0x18c>
    c168:	008c2783          	lw	a5,8(s8) # 5008 <bullet_enemy_position+0x50>
    c16c:	18fcea63          	bltu	s9,a5,c300 <gpu_instances_build_into+0x31c>
    c170:	01403cb3          	snez	s9,s4
    c174:	00005ab7          	lui	s5,0x5
    c178:	00010d37          	lui	s10,0x10
    c17c:	002c8c93          	addi	s9,s9,2
    c180:	00000c13          	li	s8,0
    c184:	01548ab3          	add	s5,s1,s5
    c188:	00500d93          	li	s11,5
    c18c:	00300313          	li	t1,3
    c190:	01c10e13          	addi	t3,sp,28
    c194:	fffd0d13          	addi	s10,s10,-1 # ffff <__global_pointer$+0x1297>
    c198:	06051c63          	bnez	a0,c210 <gpu_instances_build_into+0x22c>
    c19c:	008aa783          	lw	a5,8(s5) # 5008 <bullet_enemy_position+0x50>
    c1a0:	1cfc6c63          	bltu	s8,a5,c378 <gpu_instances_build_into+0x394>
    c1a4:	024ac783          	lbu	a5,36(s5)
    c1a8:	040b0a63          	beqz	s6,c1fc <gpu_instances_build_into+0x218>
    c1ac:	06078063          	beqz	a5,c20c <gpu_instances_build_into+0x228>
    c1b0:	00caa703          	lw	a4,12(s5)
    c1b4:	010aa783          	lw	a5,16(s5)
    c1b8:	020ad683          	lhu	a3,32(s5)
    c1bc:	ffa70713          	addi	a4,a4,-6
    c1c0:	ffa78793          	addi	a5,a5,-6 # 1fffffa <__freertos_irq_stack_top+0x1fe257a>
    c1c4:	04000893          	li	a7,64
    c1c8:	00068463          	beqz	a3,c1d0 <gpu_instances_build_into+0x1ec>
    c1cc:	0c000893          	li	a7,192
    c1d0:	01c10693          	addi	a3,sp,28
    c1d4:	00d12223          	sw	a3,4(sp)
    c1d8:	fff00693          	li	a3,-1
    c1dc:	00d12023          	sw	a3,0(sp)
    c1e0:	00c00813          	li	a6,12
    c1e4:	00100693          	li	a3,1
    c1e8:	00090613          	mv	a2,s2
    c1ec:	00098593          	mv	a1,s3
    c1f0:	02810513          	addi	a0,sp,40
    c1f4:	f30ff0ef          	jal	b924 <sprite>
    c1f8:	00051c63          	bnez	a0,c210 <gpu_instances_build_into+0x22c>
    c1fc:	00005737          	lui	a4,0x5
    c200:	00e48733          	add	a4,s1,a4
    c204:	02474783          	lbu	a5,36(a4) # 5024 <bullet_enemy_position+0x6c>
    c208:	1e079a63          	bnez	a5,c3fc <gpu_instances_build_into+0x418>
    c20c:	00000513          	li	a0,0
    c210:	000057b7          	lui	a5,0x5
    c214:	00f487b3          	add	a5,s1,a5
    c218:	0247c703          	lbu	a4,36(a5) # 5024 <bullet_enemy_position+0x6c>
    c21c:	05000b93          	li	s7,80
    c220:	02070063          	beqz	a4,c240 <gpu_instances_build_into+0x25c>
    c224:	0147a783          	lw	a5,20(a5)
    c228:	03c00713          	li	a4,60
    c22c:	02e7f7b3          	remu	a5,a5,a4
    c230:	02b00713          	li	a4,43
    c234:	00f77663          	bgeu	a4,a5,c240 <gpu_instances_build_into+0x25c>
    c238:	00379793          	slli	a5,a5,0x3
    c23c:	ef878b93          	addi	s7,a5,-264
    c240:	0000edb7          	lui	s11,0xe
    c244:	00005ab7          	lui	s5,0x5
    c248:	45cd8d93          	addi	s11,s11,1116 # e45c <centers.0>
    c24c:	00000d13          	li	s10,0
    c250:	00300c13          	li	s8,3
    c254:	fff00c93          	li	s9,-1
    c258:	01548ab3          	add	s5,s1,s5
    c25c:	20051e63          	bnez	a0,c478 <gpu_instances_build_into+0x494>
    c260:	dd8d04e3          	beq	s10,s8,c028 <gpu_instances_build_into+0x44>
    c264:	020a0263          	beqz	s4,c288 <gpu_instances_build_into+0x2a4>
    c268:	028ac783          	lbu	a5,40(s5) # 5028 <bullet_enemy_position+0x70>
    c26c:	00078e63          	beqz	a5,c288 <gpu_instances_build_into+0x2a4>
    c270:	000057b7          	lui	a5,0x5
    c274:	02578793          	addi	a5,a5,37 # 5025 <bullet_enemy_position+0x6d>
    c278:	00fd07b3          	add	a5,s10,a5
    c27c:	00f487b3          	add	a5,s1,a5
    c280:	0007c783          	lbu	a5,0(a5)
    c284:	06078863          	beqz	a5,c2f4 <gpu_instances_build_into+0x310>
    c288:	000da783          	lw	a5,0(s11)
    c28c:	02f12023          	sw	a5,32(sp)
    c290:	004da783          	lw	a5,4(s11)
    c294:	02f12223          	sw	a5,36(sp)
    c298:	000a0c63          	beqz	s4,c2b0 <gpu_instances_build_into+0x2cc>
    c29c:	02410693          	addi	a3,sp,36
    c2a0:	02010613          	addi	a2,sp,32
    c2a4:	000d0593          	mv	a1,s10
    c2a8:	00048513          	mv	a0,s1
    c2ac:	d0df80ef          	jal	4fb8 <bullet_enemy_position>
    c2b0:	02012703          	lw	a4,32(sp)
    c2b4:	02412783          	lw	a5,36(sp)
    c2b8:	180b1263          	bnez	s6,c43c <gpu_instances_build_into+0x458>
    c2bc:	01c10793          	addi	a5,sp,28
    c2c0:	02012703          	lw	a4,32(sp)
    c2c4:	00f12223          	sw	a5,4(sp)
    c2c8:	02412783          	lw	a5,36(sp)
    c2cc:	01912023          	sw	s9,0(sp)
    c2d0:	00000893          	li	a7,0
    c2d4:	01000813          	li	a6,16
    c2d8:	ff878793          	addi	a5,a5,-8
    c2dc:	ff870713          	addi	a4,a4,-8
    c2e0:	009d0693          	addi	a3,s10,9
    c2e4:	00090613          	mv	a2,s2
    c2e8:	00098593          	mv	a1,s3
    c2ec:	02810513          	addi	a0,sp,40
    c2f0:	e34ff0ef          	jal	b924 <sprite>
    c2f4:	001d0d13          	addi	s10,s10,1
    c2f8:	008d8d93          	addi	s11,s11,8
    c2fc:	f61ff06f          	j	c25c <gpu_instances_build_into+0x278>
    c300:	000a0e63          	beqz	s4,c31c <gpu_instances_build_into+0x338>
    c304:	00eac783          	lbu	a5,14(s5)
    c308:	01c78663          	beq	a5,t3,c314 <gpu_instances_build_into+0x330>
    c30c:	028c4783          	lbu	a5,40(s8)
    c310:	00078663          	beqz	a5,c31c <gpu_instances_build_into+0x338>
    c314:	00cad783          	lhu	a5,12(s5)
    c318:	05a78a63          	beq	a5,s10,c36c <gpu_instances_build_into+0x388>
    c31c:	004c2883          	lw	a7,4(s8)
    c320:	004aa783          	lw	a5,4(s5)
    c324:	000aa703          	lw	a4,0(s5)
    c328:	00f8f893          	andi	a7,a7,15
    c32c:	01088893          	addi	a7,a7,16
    c330:	4087d793          	srai	a5,a5,0x8
    c334:	40875713          	srai	a4,a4,0x8
    c338:	00612023          	sw	t1,0(sp)
    c33c:	01b12223          	sw	s11,4(sp)
    c340:	00289893          	slli	a7,a7,0x2
    c344:	00c00813          	li	a6,12
    c348:	ffe78793          	addi	a5,a5,-2
    c34c:	ffe70713          	addi	a4,a4,-2
    c350:	00100693          	li	a3,1
    c354:	00090613          	mv	a2,s2
    c358:	00098593          	mv	a1,s3
    c35c:	02810513          	addi	a0,sp,40
    c360:	dc4ff0ef          	jal	b924 <sprite>
    c364:	00300e13          	li	t3,3
    c368:	fff00313          	li	t1,-1
    c36c:	008c8c93          	addi	s9,s9,8
    c370:	0a0a8a93          	addi	s5,s5,160
    c374:	dedff06f          	j	c160 <gpu_instances_build_into+0x17c>
    c378:	00ebc783          	lbu	a5,14(s7)
    c37c:	10fcca63          	blt	s9,a5,c490 <gpu_instances_build_into+0x4ac>
    c380:	00fbc683          	lbu	a3,15(s7)
    c384:	10dde663          	bltu	s11,a3,c490 <gpu_instances_build_into+0x4ac>
    c388:	00678863          	beq	a5,t1,c398 <gpu_instances_build_into+0x3b4>
    c38c:	000a0a63          	beqz	s4,c3a0 <gpu_instances_build_into+0x3bc>
    c390:	028ac783          	lbu	a5,40(s5)
    c394:	00078663          	beqz	a5,c3a0 <gpu_instances_build_into+0x3bc>
    c398:	00cbd783          	lhu	a5,12(s7)
    c39c:	05a78a63          	beq	a5,s10,c3f0 <gpu_instances_build_into+0x40c>
    c3a0:	004ba783          	lw	a5,4(s7)
    c3a4:	000ba703          	lw	a4,0(s7)
    c3a8:	00000893          	li	a7,0
    c3ac:	01c12223          	sw	t3,4(sp)
    c3b0:	00d12023          	sw	a3,0(sp)
    c3b4:	00800813          	li	a6,8
    c3b8:	4087d793          	srai	a5,a5,0x8
    c3bc:	40875713          	srai	a4,a4,0x8
    c3c0:	00268693          	addi	a3,a3,2
    c3c4:	00090613          	mv	a2,s2
    c3c8:	00098593          	mv	a1,s3
    c3cc:	02810513          	addi	a0,sp,40
    c3d0:	d54ff0ef          	jal	b924 <sprite>
    c3d4:	01c10e13          	addi	t3,sp,28
    c3d8:	00300313          	li	t1,3
    c3dc:	00051a63          	bnez	a0,c3f0 <gpu_instances_build_into+0x40c>
    c3e0:	00442783          	lw	a5,4(s0)
    c3e4:	01c12703          	lw	a4,28(sp)
    c3e8:	00e787b3          	add	a5,a5,a4
    c3ec:	00f42223          	sw	a5,4(s0)
    c3f0:	001c0c13          	addi	s8,s8,1
    c3f4:	014b8b93          	addi	s7,s7,20
    c3f8:	da1ff06f          	j	c198 <gpu_instances_build_into+0x1b4>
    c3fc:	01072783          	lw	a5,16(a4)
    c400:	00c72703          	lw	a4,12(a4)
    c404:	01c10693          	addi	a3,sp,28
    c408:	00d12223          	sw	a3,4(sp)
    c40c:	fff00693          	li	a3,-1
    c410:	00d12023          	sw	a3,0(sp)
    c414:	00000893          	li	a7,0
    c418:	01000813          	li	a6,16
    c41c:	ff878793          	addi	a5,a5,-8
    c420:	ff870713          	addi	a4,a4,-8
    c424:	00800693          	li	a3,8
    c428:	00090613          	mv	a2,s2
    c42c:	00098593          	mv	a1,s3
    c430:	02810513          	addi	a0,sp,40
    c434:	cf0ff0ef          	jal	b924 <sprite>
    c438:	dd9ff06f          	j	c210 <gpu_instances_build_into+0x22c>
    c43c:	01c10693          	addi	a3,sp,28
    c440:	00d12223          	sw	a3,4(sp)
    c444:	fff00693          	li	a3,-1
    c448:	00d12023          	sw	a3,0(sp)
    c44c:	000b8893          	mv	a7,s7
    c450:	00c00813          	li	a6,12
    c454:	ffa78793          	addi	a5,a5,-6
    c458:	ffa70713          	addi	a4,a4,-6
    c45c:	00100693          	li	a3,1
    c460:	00090613          	mv	a2,s2
    c464:	00098593          	mv	a1,s3
    c468:	02810513          	addi	a0,sp,40
    c46c:	cb8ff0ef          	jal	b924 <sprite>
    c470:	e80512e3          	bnez	a0,c2f4 <gpu_instances_build_into+0x310>
    c474:	e49ff06f          	j	c2bc <gpu_instances_build_into+0x2d8>
    c478:	00042823          	sw	zero,16(s0)
    c47c:	00042423          	sw	zero,8(s0)
    c480:	00042623          	sw	zero,12(s0)
    c484:	00042223          	sw	zero,4(s0)
    c488:	00042023          	sw	zero,0(s0)
    c48c:	b9dff06f          	j	c028 <gpu_instances_build_into+0x44>
    c490:	ff800513          	li	a0,-8
    c494:	d7dff06f          	j	c210 <gpu_instances_build_into+0x22c>

0000c498 <gpu_frame_list_init>:
    c498:	10050463          	beqz	a0,c5a0 <gpu_frame_list_init+0x108>
    c49c:	e2010113          	addi	sp,sp,-480
    c4a0:	1c812c23          	sw	s0,472(sp)
    c4a4:	1c112e23          	sw	ra,476(sp)
    c4a8:	1c912a23          	sw	s1,468(sp)
    c4ac:	1d212823          	sw	s2,464(sp)
    c4b0:	00050413          	mv	s0,a0
    c4b4:	ff800513          	li	a0,-8
    c4b8:	06058863          	beqz	a1,c528 <gpu_frame_list_init+0x90>
    c4bc:	00100793          	li	a5,1
    c4c0:	00060493          	mv	s1,a2
    c4c4:	06c7e263          	bltu	a5,a2,c528 <gpu_frame_list_init+0x90>
    c4c8:	0135c783          	lbu	a5,19(a1) # 2000013 <__gpu_framebuffer_a+0x13>
    c4cc:	04079c63          	bnez	a5,c524 <gpu_frame_list_init+0x8c>
    c4d0:	0105c783          	lbu	a5,16(a1)
    c4d4:	04078a63          	beqz	a5,c528 <gpu_frame_list_init+0x90>
    c4d8:	0005a783          	lw	a5,0(a1)
    c4dc:	00042223          	sw	zero,4(s0)
    c4e0:	00b42023          	sw	a1,0(s0)
    c4e4:	0087a903          	lw	s2,8(a5)
    c4e8:	01091713          	slli	a4,s2,0x10
    c4ec:	0a075663          	bgez	a4,c598 <gpu_frame_list_init+0x100>
    c4f0:	01191713          	slli	a4,s2,0x11
    c4f4:	fff00513          	li	a0,-1
    c4f8:	02075863          	bgez	a4,c528 <gpu_frame_list_init+0x90>
    c4fc:	5007a683          	lw	a3,1280(a5)
    c500:	464c5737          	lui	a4,0x464c5
    c504:	43170713          	addi	a4,a4,1073 # 464c5431 <__gpu_framebuffer_a+0x444c5431>
    c508:	02e69063          	bne	a3,a4,c528 <gpu_frame_list_init+0x90>
    c50c:	5047a783          	lw	a5,1284(a5)
    c510:	0047f713          	andi	a4,a5,4
    c514:	02070663          	beqz	a4,c540 <gpu_frame_list_init+0xa8>
    c518:	0087d793          	srli	a5,a5,0x8
    c51c:	00f589a3          	sb	a5,19(a1)
    c520:	00058823          	sb	zero,16(a1)
    c524:	ff900513          	li	a0,-7
    c528:	1dc12083          	lw	ra,476(sp)
    c52c:	1d812403          	lw	s0,472(sp)
    c530:	1d412483          	lw	s1,468(sp)
    c534:	1d012903          	lw	s2,464(sp)
    c538:	1e010113          	addi	sp,sp,480
    c53c:	00008067          	ret
    c540:	0017f793          	andi	a5,a5,1
    c544:	ffd00513          	li	a0,-3
    c548:	fe0790e3          	bnez	a5,c528 <gpu_frame_list_init+0x90>
    c54c:	00810513          	addi	a0,sp,8
    c550:	c88ff0ef          	jal	b9d8 <gpu_instances_init>
    c554:	fc051ae3          	bnez	a0,c528 <gpu_frame_list_init+0x90>
    c558:	01010593          	addi	a1,sp,16
    c55c:	00048513          	mv	a0,s1
    c560:	cd4ff0ef          	jal	ba34 <gpu_instances_templates>
    c564:	00050613          	mv	a2,a0
    c568:	01010593          	addi	a1,sp,16
    c56c:	00810513          	addi	a0,sp,8
    c570:	8a5ff0ef          	jal	be14 <gpu_instances_program>
    c574:	fa051ae3          	bnez	a0,c528 <gpu_frame_list_init+0x90>
    c578:	000017b7          	lui	a5,0x1
    c57c:	00b91713          	slli	a4,s2,0xb
    c580:	80078793          	addi	a5,a5,-2048 # 800 <CUSTOM2+0x7a5>
    c584:	00075463          	bgez	a4,c58c <gpu_frame_list_init+0xf4>
    c588:	000017b7          	lui	a5,0x1
    c58c:	00f41223          	sh	a5,4(s0)
    c590:	00100793          	li	a5,1
    c594:	00f40323          	sb	a5,6(s0)
    c598:	00000513          	li	a0,0
    c59c:	f8dff06f          	j	c528 <gpu_frame_list_init+0x90>
    c5a0:	ff800513          	li	a0,-8
    c5a4:	00008067          	ret

0000c5a8 <gpu_frame_list_render>:
    c5a8:	fd010113          	addi	sp,sp,-48
    c5ac:	02912223          	sw	s1,36(sp)
    c5b0:	03212023          	sw	s2,32(sp)
    c5b4:	01312e23          	sw	s3,28(sp)
    c5b8:	01412c23          	sw	s4,24(sp)
    c5bc:	01512a23          	sw	s5,20(sp)
    c5c0:	02112623          	sw	ra,44(sp)
    c5c4:	02812423          	sw	s0,40(sp)
    c5c8:	01612823          	sw	s6,16(sp)
    c5cc:	01712623          	sw	s7,12(sp)
    c5d0:	01812423          	sw	s8,8(sp)
    c5d4:	01912223          	sw	s9,4(sp)
    c5d8:	00050493          	mv	s1,a0
    c5dc:	00058a93          	mv	s5,a1
    c5e0:	00060913          	mv	s2,a2
    c5e4:	00068993          	mv	s3,a3
    c5e8:	00070a13          	mv	s4,a4
    c5ec:	00050663          	beqz	a0,c5f8 <gpu_frame_list_render+0x50>
    c5f0:	00754783          	lbu	a5,7(a0)
    c5f4:	0a079263          	bnez	a5,c698 <gpu_frame_list_render+0xf0>
    c5f8:	00491713          	slli	a4,s2,0x4
    c5fc:	015707b3          	add	a5,a4,s5
    c600:	01c95693          	srli	a3,s2,0x1c
    c604:	00e7b733          	sltu	a4,a5,a4
    c608:	00d70733          	add	a4,a4,a3
    c60c:	ff800513          	li	a0,-8
    c610:	08048663          	beqz	s1,c69c <gpu_frame_list_render+0xf4>
    c614:	0004a403          	lw	s0,0(s1)
    c618:	08040263          	beqz	s0,c69c <gpu_frame_list_render+0xf4>
    c61c:	01044683          	lbu	a3,16(s0)
    c620:	06068e63          	beqz	a3,c69c <gpu_frame_list_render+0xf4>
    c624:	0064c683          	lbu	a3,6(s1)
    c628:	06068a63          	beqz	a3,c69c <gpu_frame_list_render+0xf4>
    c62c:	060a0863          	beqz	s4,c69c <gpu_frame_list_render+0xf4>
    c630:	fff90693          	addi	a3,s2,-1
    c634:	3ff00613          	li	a2,1023
    c638:	06d66263          	bltu	a2,a3,c69c <gpu_frame_list_render+0xf4>
    c63c:	00faf693          	andi	a3,s5,15
    c640:	04069e63          	bnez	a3,c69c <gpu_frame_list_render+0xf4>
    c644:	02d20637          	lui	a2,0x2d20
    c648:	04caea63          	bltu	s5,a2,c69c <gpu_frame_list_render+0xf4>
    c64c:	0044d683          	lhu	a3,4(s1)
    c650:	00469693          	slli	a3,a3,0x4
    c654:	00c686b3          	add	a3,a3,a2
    c658:	1e071463          	bnez	a4,c840 <gpu_frame_list_render+0x298>
    c65c:	1ef6e263          	bltu	a3,a5,c840 <gpu_frame_list_render+0x298>
    c660:	fff78713          	addi	a4,a5,-1 # fff <CUSTOM2+0xfa4>
    c664:	00f037b3          	snez	a5,a5
    c668:	fff78793          	addi	a5,a5,-1
    c66c:	01279613          	slli	a2,a5,0x12
    c670:	00e75713          	srli	a4,a4,0xe
    c674:	00ead693          	srli	a3,s5,0xe
    c678:	00e66733          	or	a4,a2,a4
    c67c:	00e7d793          	srli	a5,a5,0xe
    c680:	1ce69063          	bne	a3,a4,c840 <gpu_frame_list_render+0x298>
    c684:	1a079e63          	bnez	a5,c840 <gpu_frame_list_render+0x298>
    c688:	00042783          	lw	a5,0(s0)
    c68c:	5047a783          	lw	a5,1284(a5)
    c690:	0017f793          	andi	a5,a5,1
    c694:	02078e63          	beqz	a5,c6d0 <gpu_frame_list_render+0x128>
    c698:	ffd00513          	li	a0,-3
    c69c:	02c12083          	lw	ra,44(sp)
    c6a0:	02812403          	lw	s0,40(sp)
    c6a4:	02412483          	lw	s1,36(sp)
    c6a8:	02012903          	lw	s2,32(sp)
    c6ac:	01c12983          	lw	s3,28(sp)
    c6b0:	01812a03          	lw	s4,24(sp)
    c6b4:	01412a83          	lw	s5,20(sp)
    c6b8:	01012b03          	lw	s6,16(sp)
    c6bc:	00c12b83          	lw	s7,12(sp)
    c6c0:	00812c03          	lw	s8,8(sp)
    c6c4:	00412c83          	lw	s9,4(sp)
    c6c8:	03010113          	addi	sp,sp,48
    c6cc:	00008067          	ret
    c6d0:	01244783          	lbu	a5,18(s0)
    c6d4:	0a079463          	bnez	a5,c77c <gpu_frame_list_render+0x1d4>
    c6d8:	0004a783          	lw	a5,0(s1)
    c6dc:	0007a783          	lw	a5,0(a5)
    c6e0:	0087ab83          	lw	s7,8(a5)
    c6e4:	080bfb93          	andi	s7,s7,128
    c6e8:	fa0b98e3          	bnez	s7,c698 <gpu_frame_list_render+0xf0>
    c6ec:	0387a783          	lw	a5,56(a5)
    c6f0:	0ff7f793          	zext.b	a5,a5
    c6f4:	00f409a3          	sb	a5,19(s0)
    c6f8:	06079e63          	bnez	a5,c774 <gpu_frame_list_render+0x1cc>
    c6fc:	00a45c83          	lhu	s9,10(s0)
    c700:	94cf50ef          	jal	184c <gpu_platform_sync>
    c704:	0004a783          	lw	a5,0(s1)
    c708:	012c8c33          	add	s8,s9,s2
    c70c:	010c1c13          	slli	s8,s8,0x10
    c710:	0007a783          	lw	a5,0(a5)
    c714:	010c5c13          	srli	s8,s8,0x10
    c718:	fffc0b13          	addi	s6,s8,-1
    c71c:	5157a623          	sw	s5,1292(a5)
    c720:	5127a823          	sw	s2,1296(a5)
    c724:	5197aa23          	sw	s9,1300(a5)
    c728:	010b1b13          	slli	s6,s6,0x10
    c72c:	010b5b13          	srli	s6,s6,0x10
    c730:	5137ac23          	sw	s3,1304(a5)
    c734:	0ff0000f          	fence
    c738:	0004a703          	lw	a4,0(s1)
    c73c:	00100793          	li	a5,1
    c740:	00f483a3          	sb	a5,7(s1)
    c744:	00072703          	lw	a4,0(a4)
    c748:	50f72423          	sw	a5,1288(a4)
    c74c:	0ff0000f          	fence
    c750:	0004a783          	lw	a5,0(s1)
    c754:	0007a683          	lw	a3,0(a5)
    c758:	50468713          	addi	a4,a3,1284
    c75c:	00072783          	lw	a5,0(a4)
    c760:	0047f613          	andi	a2,a5,4
    c764:	02060863          	beqz	a2,c794 <gpu_frame_list_render+0x1ec>
    c768:	0087d793          	srli	a5,a5,0x8
    c76c:	00f409a3          	sb	a5,19(s0)
    c770:	00040823          	sb	zero,16(s0)
    c774:	ff900513          	li	a0,-7
    c778:	f25ff06f          	j	c69c <gpu_frame_list_render+0xf4>
    c77c:	00e45583          	lhu	a1,14(s0)
    c780:	000a0613          	mv	a2,s4
    c784:	00040513          	mv	a0,s0
    c788:	c41f50ef          	jal	23c8 <gpu_wait_tag>
    c78c:	f40506e3          	beqz	a0,c6d8 <gpu_frame_list_render+0x130>
    c790:	f0dff06f          	j	c69c <gpu_frame_list_render+0xf4>
    c794:	0027f613          	andi	a2,a5,2
    c798:	00061c63          	bnez	a2,c7b0 <gpu_frame_list_render+0x208>
    c79c:	001b8b93          	addi	s7,s7,1
    c7a0:	fb4beee3          	bltu	s7,s4,c75c <gpu_frame_list_render+0x1b4>
    c7a4:	00040823          	sb	zero,16(s0)
    c7a8:	ffb00513          	li	a0,-5
    c7ac:	ef1ff06f          	j	c69c <gpu_frame_list_render+0xf4>
    c7b0:	0017f793          	andi	a5,a5,1
    c7b4:	02079663          	bnez	a5,c7e0 <gpu_frame_list_render+0x238>
    c7b8:	51c6a783          	lw	a5,1308(a3)
    c7bc:	02f99263          	bne	s3,a5,c7e0 <gpu_frame_list_render+0x238>
    c7c0:	5246a783          	lw	a5,1316(a3)
    c7c4:	00f91e63          	bne	s2,a5,c7e0 <gpu_frame_list_render+0x238>
    c7c8:	5206a783          	lw	a5,1312(a3)
    c7cc:	00fb1a63          	bne	s6,a5,c7e0 <gpu_frame_list_render+0x238>
    c7d0:	0346a783          	lw	a5,52(a3)
    c7d4:	01079793          	slli	a5,a5,0x10
    c7d8:	0107d793          	srli	a5,a5,0x10
    c7dc:	01678863          	beq	a5,s6,c7ec <gpu_frame_list_render+0x244>
    c7e0:	00040823          	sb	zero,16(s0)
    c7e4:	ffa00513          	li	a0,-6
    c7e8:	eb5ff06f          	j	c69c <gpu_frame_list_render+0xf4>
    c7ec:	0386a783          	lw	a5,56(a3)
    c7f0:	0ff7f793          	zext.b	a5,a5
    c7f4:	00f409a3          	sb	a5,19(s0)
    c7f8:	f6079ce3          	bnez	a5,c770 <gpu_frame_list_render+0x1c8>
    c7fc:	00442783          	lw	a5,4(s0)
    c800:	000408a3          	sb	zero,17(s0)
    c804:	00040923          	sb	zero,18(s0)
    c808:	012787b3          	add	a5,a5,s2
    c80c:	00f42223          	sw	a5,4(s0)
    c810:	0086a783          	lw	a5,8(a3)
    c814:	01444703          	lbu	a4,20(s0)
    c818:	01841523          	sh	s8,10(s0)
    c81c:	0087d793          	srli	a5,a5,0x8
    c820:	01641623          	sh	s6,12(s0)
    c824:	01641723          	sh	s6,14(s0)
    c828:	01f7f793          	andi	a5,a5,31
    c82c:	00f77463          	bgeu	a4,a5,c834 <gpu_frame_list_render+0x28c>
    c830:	00f40a23          	sb	a5,20(s0)
    c834:	000483a3          	sb	zero,7(s1)
    c838:	00000513          	li	a0,0
    c83c:	e61ff06f          	j	c69c <gpu_frame_list_render+0xf4>
    c840:	ff800513          	li	a0,-8
    c844:	e59ff06f          	j	c69c <gpu_frame_list_render+0xf4>

0000c848 <gpu_frame_list_render_span>:
    c848:	fd010113          	addi	sp,sp,-48
    c84c:	02812423          	sw	s0,40(sp)
    c850:	03212023          	sw	s2,32(sp)
    c854:	01312e23          	sw	s3,28(sp)
    c858:	01412c23          	sw	s4,24(sp)
    c85c:	01512a23          	sw	s5,20(sp)
    c860:	02112623          	sw	ra,44(sp)
    c864:	02912223          	sw	s1,36(sp)
    c868:	01612823          	sw	s6,16(sp)
    c86c:	01712623          	sw	s7,12(sp)
    c870:	00050993          	mv	s3,a0
    c874:	00058913          	mv	s2,a1
    c878:	00060413          	mv	s0,a2
    c87c:	00068a13          	mv	s4,a3
    c880:	00070a93          	mv	s5,a4
    c884:	00050863          	beqz	a0,c894 <gpu_frame_list_render_span+0x4c>
    c888:	00754783          	lbu	a5,7(a0)
    c88c:	ffd00513          	li	a0,-3
    c890:	0a079863          	bnez	a5,c940 <gpu_frame_list_render_span+0xf8>
    c894:	00441793          	slli	a5,s0,0x4
    c898:	01278633          	add	a2,a5,s2
    c89c:	01c45713          	srli	a4,s0,0x1c
    c8a0:	00f637b3          	sltu	a5,a2,a5
    c8a4:	00e786b3          	add	a3,a5,a4
    c8a8:	ff800513          	li	a0,-8
    c8ac:	08098a63          	beqz	s3,c940 <gpu_frame_list_render_span+0xf8>
    c8b0:	0009a783          	lw	a5,0(s3)
    c8b4:	08078663          	beqz	a5,c940 <gpu_frame_list_render_span+0xf8>
    c8b8:	0107c783          	lbu	a5,16(a5)
    c8bc:	08078263          	beqz	a5,c940 <gpu_frame_list_render_span+0xf8>
    c8c0:	0069c783          	lbu	a5,6(s3)
    c8c4:	06078e63          	beqz	a5,c940 <gpu_frame_list_render_span+0xf8>
    c8c8:	060a8c63          	beqz	s5,c940 <gpu_frame_list_render_span+0xf8>
    c8cc:	06040a63          	beqz	s0,c940 <gpu_frame_list_render_span+0xf8>
    c8d0:	0049d783          	lhu	a5,4(s3)
    c8d4:	0687e663          	bltu	a5,s0,c940 <gpu_frame_list_render_span+0xf8>
    c8d8:	00f97713          	andi	a4,s2,15
    c8dc:	06071263          	bnez	a4,c940 <gpu_frame_list_render_span+0xf8>
    c8e0:	02d20737          	lui	a4,0x2d20
    c8e4:	04e96e63          	bltu	s2,a4,c940 <gpu_frame_list_render_span+0xf8>
    c8e8:	00479793          	slli	a5,a5,0x4
    c8ec:	00e787b3          	add	a5,a5,a4
    c8f0:	06069e63          	bnez	a3,c96c <gpu_frame_list_render_span+0x124>
    c8f4:	06c7ec63          	bltu	a5,a2,c96c <gpu_frame_list_render_span+0x124>
    c8f8:	00004b37          	lui	s6,0x4
    c8fc:	fffb0b93          	addi	s7,s6,-1 # 3fff <update_gpu_target+0x34b>
    c900:	017974b3          	and	s1,s2,s7
    c904:	409b04b3          	sub	s1,s6,s1
    c908:	0044d493          	srli	s1,s1,0x4
    c90c:	00947463          	bgeu	s0,s1,c914 <gpu_frame_list_render_span+0xcc>
    c910:	00040493          	mv	s1,s0
    c914:	000a8713          	mv	a4,s5
    c918:	000a0693          	mv	a3,s4
    c91c:	00048613          	mv	a2,s1
    c920:	00090593          	mv	a1,s2
    c924:	00098513          	mv	a0,s3
    c928:	c81ff0ef          	jal	c5a8 <gpu_frame_list_render>
    c92c:	00051a63          	bnez	a0,c940 <gpu_frame_list_render_span+0xf8>
    c930:	00449793          	slli	a5,s1,0x4
    c934:	40940433          	sub	s0,s0,s1
    c938:	00f90933          	add	s2,s2,a5
    c93c:	fc0412e3          	bnez	s0,c900 <gpu_frame_list_render_span+0xb8>
    c940:	02c12083          	lw	ra,44(sp)
    c944:	02812403          	lw	s0,40(sp)
    c948:	02412483          	lw	s1,36(sp)
    c94c:	02012903          	lw	s2,32(sp)
    c950:	01c12983          	lw	s3,28(sp)
    c954:	01812a03          	lw	s4,24(sp)
    c958:	01412a83          	lw	s5,20(sp)
    c95c:	01012b03          	lw	s6,16(sp)
    c960:	00c12b83          	lw	s7,12(sp)
    c964:	03010113          	addi	sp,sp,48
    c968:	00008067          	ret
    c96c:	ff800513          	li	a0,-8
    c970:	fd1ff06f          	j	c940 <gpu_frame_list_render_span+0xf8>

0000c974 <__udivdi3>:
    c974:	00060813          	mv	a6,a2
    c978:	00050893          	mv	a7,a0
    c97c:	00058713          	mv	a4,a1
    c980:	0e069063          	bnez	a3,ca60 <__udivdi3+0xec>
    c984:	12c5fe63          	bgeu	a1,a2,cac0 <__udivdi3+0x14c>
    c988:	000107b7          	lui	a5,0x10
    c98c:	1ef66e63          	bltu	a2,a5,cb88 <__udivdi3+0x214>
    c990:	010007b7          	lui	a5,0x1000
    c994:	01800693          	li	a3,24
    c998:	00f67463          	bgeu	a2,a5,c9a0 <__udivdi3+0x2c>
    c99c:	01000693          	li	a3,16
    c9a0:	00d65333          	srl	t1,a2,a3
    c9a4:	00002797          	auipc	a5,0x2
    c9a8:	ad078793          	addi	a5,a5,-1328 # e474 <__clz_tab>
    c9ac:	006787b3          	add	a5,a5,t1
    c9b0:	0007c783          	lbu	a5,0(a5)
    c9b4:	02000313          	li	t1,32
    c9b8:	00d787b3          	add	a5,a5,a3
    c9bc:	40f306b3          	sub	a3,t1,a5
    c9c0:	00f30c63          	beq	t1,a5,c9d8 <__udivdi3+0x64>
    c9c4:	00d59733          	sll	a4,a1,a3
    c9c8:	00f557b3          	srl	a5,a0,a5
    c9cc:	00d61833          	sll	a6,a2,a3
    c9d0:	00e7e733          	or	a4,a5,a4
    c9d4:	00d518b3          	sll	a7,a0,a3
    c9d8:	01085613          	srli	a2,a6,0x10
    c9dc:	02c75533          	divu	a0,a4,a2
    c9e0:	01081693          	slli	a3,a6,0x10
    c9e4:	0106d693          	srli	a3,a3,0x10
    c9e8:	0108d793          	srli	a5,a7,0x10
    c9ec:	02c77733          	remu	a4,a4,a2
    c9f0:	02a685b3          	mul	a1,a3,a0
    c9f4:	01071713          	slli	a4,a4,0x10
    c9f8:	00e7e7b3          	or	a5,a5,a4
    c9fc:	00b7fc63          	bgeu	a5,a1,ca14 <__udivdi3+0xa0>
    ca00:	00f807b3          	add	a5,a6,a5
    ca04:	fff50713          	addi	a4,a0,-1
    ca08:	0107e463          	bltu	a5,a6,ca10 <__udivdi3+0x9c>
    ca0c:	40b7e063          	bltu	a5,a1,ce0c <__udivdi3+0x498>
    ca10:	00070513          	mv	a0,a4
    ca14:	40b787b3          	sub	a5,a5,a1
    ca18:	02c7d733          	divu	a4,a5,a2
    ca1c:	01089893          	slli	a7,a7,0x10
    ca20:	0108d893          	srli	a7,a7,0x10
    ca24:	02c7f7b3          	remu	a5,a5,a2
    ca28:	02e686b3          	mul	a3,a3,a4
    ca2c:	01079793          	slli	a5,a5,0x10
    ca30:	00f8e8b3          	or	a7,a7,a5
    ca34:	00d8fe63          	bgeu	a7,a3,ca50 <__udivdi3+0xdc>
    ca38:	011808b3          	add	a7,a6,a7
    ca3c:	fff70793          	addi	a5,a4,-1 # 2d1ffff <__gpu_framebuffer_a+0xd1ffff>
    ca40:	0108e663          	bltu	a7,a6,ca4c <__udivdi3+0xd8>
    ca44:	ffe70713          	addi	a4,a4,-2
    ca48:	00d8e463          	bltu	a7,a3,ca50 <__udivdi3+0xdc>
    ca4c:	00078713          	mv	a4,a5
    ca50:	01051513          	slli	a0,a0,0x10
    ca54:	00e56533          	or	a0,a0,a4
    ca58:	00000593          	li	a1,0
    ca5c:	00008067          	ret
    ca60:	00d5f863          	bgeu	a1,a3,ca70 <__udivdi3+0xfc>
    ca64:	00000593          	li	a1,0
    ca68:	00000513          	li	a0,0
    ca6c:	00008067          	ret
    ca70:	000107b7          	lui	a5,0x10
    ca74:	1ef6e863          	bltu	a3,a5,cc64 <__udivdi3+0x2f0>
    ca78:	01000737          	lui	a4,0x1000
    ca7c:	01800793          	li	a5,24
    ca80:	00e6f463          	bgeu	a3,a4,ca88 <__udivdi3+0x114>
    ca84:	01000793          	li	a5,16
    ca88:	00f6d833          	srl	a6,a3,a5
    ca8c:	00002717          	auipc	a4,0x2
    ca90:	9e870713          	addi	a4,a4,-1560 # e474 <__clz_tab>
    ca94:	01070733          	add	a4,a4,a6
    ca98:	00074703          	lbu	a4,0(a4)
    ca9c:	02000893          	li	a7,32
    caa0:	00f70733          	add	a4,a4,a5
    caa4:	40e88833          	sub	a6,a7,a4
    caa8:	1ee89663          	bne	a7,a4,cc94 <__udivdi3+0x320>
    caac:	32b6e463          	bltu	a3,a1,cdd4 <__udivdi3+0x460>
    cab0:	00c53533          	sltu	a0,a0,a2
    cab4:	00153513          	seqz	a0,a0
    cab8:	00000593          	li	a1,0
    cabc:	00008067          	ret
    cac0:	0c060c63          	beqz	a2,cb98 <__udivdi3+0x224>
    cac4:	000107b7          	lui	a5,0x10
    cac8:	2ef67c63          	bgeu	a2,a5,cdc0 <__udivdi3+0x44c>
    cacc:	10063713          	sltiu	a4,a2,256
    cad0:	00173713          	seqz	a4,a4
    cad4:	00371713          	slli	a4,a4,0x3
    cad8:	00e656b3          	srl	a3,a2,a4
    cadc:	00002797          	auipc	a5,0x2
    cae0:	99878793          	addi	a5,a5,-1640 # e474 <__clz_tab>
    cae4:	00d787b3          	add	a5,a5,a3
    cae8:	0007c783          	lbu	a5,0(a5)
    caec:	02000693          	li	a3,32
    caf0:	00e787b3          	add	a5,a5,a4
    caf4:	40f68eb3          	sub	t4,a3,a5
    caf8:	0cf69463          	bne	a3,a5,cbc0 <__udivdi3+0x24c>
    cafc:	40c587b3          	sub	a5,a1,a2
    cb00:	01065693          	srli	a3,a2,0x10
    cb04:	01061613          	slli	a2,a2,0x10
    cb08:	01065613          	srli	a2,a2,0x10
    cb0c:	00100593          	li	a1,1
    cb10:	02d7d533          	divu	a0,a5,a3
    cb14:	0108d713          	srli	a4,a7,0x10
    cb18:	02d7f7b3          	remu	a5,a5,a3
    cb1c:	02c50333          	mul	t1,a0,a2
    cb20:	01079793          	slli	a5,a5,0x10
    cb24:	00f767b3          	or	a5,a4,a5
    cb28:	0067fc63          	bgeu	a5,t1,cb40 <__udivdi3+0x1cc>
    cb2c:	00f807b3          	add	a5,a6,a5
    cb30:	fff50713          	addi	a4,a0,-1
    cb34:	0107e463          	bltu	a5,a6,cb3c <__udivdi3+0x1c8>
    cb38:	2c67e463          	bltu	a5,t1,ce00 <__udivdi3+0x48c>
    cb3c:	00070513          	mv	a0,a4
    cb40:	406787b3          	sub	a5,a5,t1
    cb44:	02d7d733          	divu	a4,a5,a3
    cb48:	01089893          	slli	a7,a7,0x10
    cb4c:	0108d893          	srli	a7,a7,0x10
    cb50:	02d7f7b3          	remu	a5,a5,a3
    cb54:	02c70633          	mul	a2,a4,a2
    cb58:	01079793          	slli	a5,a5,0x10
    cb5c:	00f8e8b3          	or	a7,a7,a5
    cb60:	00c8fe63          	bgeu	a7,a2,cb7c <__udivdi3+0x208>
    cb64:	011808b3          	add	a7,a6,a7
    cb68:	fff70793          	addi	a5,a4,-1
    cb6c:	0108e663          	bltu	a7,a6,cb78 <__udivdi3+0x204>
    cb70:	ffe70713          	addi	a4,a4,-2
    cb74:	00c8e463          	bltu	a7,a2,cb7c <__udivdi3+0x208>
    cb78:	00078713          	mv	a4,a5
    cb7c:	01051513          	slli	a0,a0,0x10
    cb80:	00e56533          	or	a0,a0,a4
    cb84:	00008067          	ret
    cb88:	10063693          	sltiu	a3,a2,256
    cb8c:	0016b693          	seqz	a3,a3
    cb90:	00369693          	slli	a3,a3,0x3
    cb94:	e0dff06f          	j	c9a0 <__udivdi3+0x2c>
    cb98:	00000693          	li	a3,0
    cb9c:	00002797          	auipc	a5,0x2
    cba0:	8d878793          	addi	a5,a5,-1832 # e474 <__clz_tab>
    cba4:	00d787b3          	add	a5,a5,a3
    cba8:	0007c783          	lbu	a5,0(a5)
    cbac:	00000713          	li	a4,0
    cbb0:	02000693          	li	a3,32
    cbb4:	00e787b3          	add	a5,a5,a4
    cbb8:	40f68eb3          	sub	t4,a3,a5
    cbbc:	f4f680e3          	beq	a3,a5,cafc <__udivdi3+0x188>
    cbc0:	01d61833          	sll	a6,a2,t4
    cbc4:	00f5d333          	srl	t1,a1,a5
    cbc8:	01085693          	srli	a3,a6,0x10
    cbcc:	02d35e33          	divu	t3,t1,a3
    cbd0:	01081613          	slli	a2,a6,0x10
    cbd4:	01d595b3          	sll	a1,a1,t4
    cbd8:	01065613          	srli	a2,a2,0x10
    cbdc:	00f557b3          	srl	a5,a0,a5
    cbe0:	00b7e7b3          	or	a5,a5,a1
    cbe4:	0107d713          	srli	a4,a5,0x10
    cbe8:	01d518b3          	sll	a7,a0,t4
    cbec:	02d37333          	remu	t1,t1,a3
    cbf0:	03c605b3          	mul	a1,a2,t3
    cbf4:	01031313          	slli	t1,t1,0x10
    cbf8:	00676733          	or	a4,a4,t1
    cbfc:	00b77e63          	bgeu	a4,a1,cc18 <__udivdi3+0x2a4>
    cc00:	00e80733          	add	a4,a6,a4
    cc04:	fffe0513          	addi	a0,t3,-1
    cc08:	1f076463          	bltu	a4,a6,cdf0 <__udivdi3+0x47c>
    cc0c:	1eb77263          	bgeu	a4,a1,cdf0 <__udivdi3+0x47c>
    cc10:	ffee0e13          	addi	t3,t3,-2
    cc14:	01070733          	add	a4,a4,a6
    cc18:	40b70733          	sub	a4,a4,a1
    cc1c:	02d75533          	divu	a0,a4,a3
    cc20:	01079793          	slli	a5,a5,0x10
    cc24:	0107d793          	srli	a5,a5,0x10
    cc28:	02d77733          	remu	a4,a4,a3
    cc2c:	02a60333          	mul	t1,a2,a0
    cc30:	01071713          	slli	a4,a4,0x10
    cc34:	00e7e7b3          	or	a5,a5,a4
    cc38:	0067fe63          	bgeu	a5,t1,cc54 <__udivdi3+0x2e0>
    cc3c:	00f807b3          	add	a5,a6,a5
    cc40:	fff50713          	addi	a4,a0,-1
    cc44:	1907ee63          	bltu	a5,a6,cde0 <__udivdi3+0x46c>
    cc48:	1867fc63          	bgeu	a5,t1,cde0 <__udivdi3+0x46c>
    cc4c:	ffe50513          	addi	a0,a0,-2
    cc50:	010787b3          	add	a5,a5,a6
    cc54:	010e1593          	slli	a1,t3,0x10
    cc58:	406787b3          	sub	a5,a5,t1
    cc5c:	00a5e5b3          	or	a1,a1,a0
    cc60:	eb1ff06f          	j	cb10 <__udivdi3+0x19c>
    cc64:	1006b793          	sltiu	a5,a3,256
    cc68:	0017b793          	seqz	a5,a5
    cc6c:	00379793          	slli	a5,a5,0x3
    cc70:	00f6d833          	srl	a6,a3,a5
    cc74:	00002717          	auipc	a4,0x2
    cc78:	80070713          	addi	a4,a4,-2048 # e474 <__clz_tab>
    cc7c:	01070733          	add	a4,a4,a6
    cc80:	00074703          	lbu	a4,0(a4)
    cc84:	02000893          	li	a7,32
    cc88:	00f70733          	add	a4,a4,a5
    cc8c:	40e88833          	sub	a6,a7,a4
    cc90:	e0e88ee3          	beq	a7,a4,caac <__udivdi3+0x138>
    cc94:	00e65e33          	srl	t3,a2,a4
    cc98:	010696b3          	sll	a3,a3,a6
    cc9c:	00de6e33          	or	t3,t3,a3
    cca0:	00e5d8b3          	srl	a7,a1,a4
    cca4:	010e5e93          	srli	t4,t3,0x10
    cca8:	03d8d7b3          	divu	a5,a7,t4
    ccac:	010e1313          	slli	t1,t3,0x10
    ccb0:	010595b3          	sll	a1,a1,a6
    ccb4:	01035313          	srli	t1,t1,0x10
    ccb8:	00e55733          	srl	a4,a0,a4
    ccbc:	00b76733          	or	a4,a4,a1
    ccc0:	01075693          	srli	a3,a4,0x10
    ccc4:	01061633          	sll	a2,a2,a6
    ccc8:	03d8f8b3          	remu	a7,a7,t4
    cccc:	02f305b3          	mul	a1,t1,a5
    ccd0:	01089893          	slli	a7,a7,0x10
    ccd4:	0116e6b3          	or	a3,a3,a7
    ccd8:	00b6fe63          	bgeu	a3,a1,ccf4 <__udivdi3+0x380>
    ccdc:	00de06b3          	add	a3,t3,a3
    cce0:	fff78893          	addi	a7,a5,-1
    cce4:	11c6ea63          	bltu	a3,t3,cdf8 <__udivdi3+0x484>
    cce8:	10b6f863          	bgeu	a3,a1,cdf8 <__udivdi3+0x484>
    ccec:	ffe78793          	addi	a5,a5,-2
    ccf0:	01c686b3          	add	a3,a3,t3
    ccf4:	40b686b3          	sub	a3,a3,a1
    ccf8:	03d6d5b3          	divu	a1,a3,t4
    ccfc:	01071713          	slli	a4,a4,0x10
    cd00:	01075713          	srli	a4,a4,0x10
    cd04:	03d6f6b3          	remu	a3,a3,t4
    cd08:	02b308b3          	mul	a7,t1,a1
    cd0c:	01069693          	slli	a3,a3,0x10
    cd10:	00d76733          	or	a4,a4,a3
    cd14:	01177e63          	bgeu	a4,a7,cd30 <__udivdi3+0x3bc>
    cd18:	00ee0733          	add	a4,t3,a4
    cd1c:	fff58693          	addi	a3,a1,-1
    cd20:	0dc76463          	bltu	a4,t3,cde8 <__udivdi3+0x474>
    cd24:	0d177263          	bgeu	a4,a7,cde8 <__udivdi3+0x474>
    cd28:	ffe58593          	addi	a1,a1,-2
    cd2c:	01c70733          	add	a4,a4,t3
    cd30:	01079793          	slli	a5,a5,0x10
    cd34:	00010eb7          	lui	t4,0x10
    cd38:	00b7e7b3          	or	a5,a5,a1
    cd3c:	fffe8693          	addi	a3,t4,-1 # ffff <__global_pointer$+0x1297>
    cd40:	00d7f5b3          	and	a1,a5,a3
    cd44:	0107d313          	srli	t1,a5,0x10
    cd48:	00d676b3          	and	a3,a2,a3
    cd4c:	01065613          	srli	a2,a2,0x10
    cd50:	02d58e33          	mul	t3,a1,a3
    cd54:	41170733          	sub	a4,a4,a7
    cd58:	02d306b3          	mul	a3,t1,a3
    cd5c:	010e5893          	srli	a7,t3,0x10
    cd60:	02c585b3          	mul	a1,a1,a2
    cd64:	00d585b3          	add	a1,a1,a3
    cd68:	00b885b3          	add	a1,a7,a1
    cd6c:	02c30333          	mul	t1,t1,a2
    cd70:	00d5f463          	bgeu	a1,a3,cd78 <__udivdi3+0x404>
    cd74:	01d30333          	add	t1,t1,t4
    cd78:	0105d693          	srli	a3,a1,0x10
    cd7c:	006686b3          	add	a3,a3,t1
    cd80:	02d76a63          	bltu	a4,a3,cdb4 <__udivdi3+0x440>
    cd84:	00d70863          	beq	a4,a3,cd94 <__udivdi3+0x420>
    cd88:	00078513          	mv	a0,a5
    cd8c:	00000593          	li	a1,0
    cd90:	00008067          	ret
    cd94:	000106b7          	lui	a3,0x10
    cd98:	fff68693          	addi	a3,a3,-1 # ffff <__global_pointer$+0x1297>
    cd9c:	00d5f733          	and	a4,a1,a3
    cda0:	01071713          	slli	a4,a4,0x10
    cda4:	00de7e33          	and	t3,t3,a3
    cda8:	01051533          	sll	a0,a0,a6
    cdac:	01c70733          	add	a4,a4,t3
    cdb0:	fce57ce3          	bgeu	a0,a4,cd88 <__udivdi3+0x414>
    cdb4:	fff78513          	addi	a0,a5,-1
    cdb8:	00000593          	li	a1,0
    cdbc:	00008067          	ret
    cdc0:	010007b7          	lui	a5,0x1000
    cdc4:	04f67a63          	bgeu	a2,a5,ce18 <__udivdi3+0x4a4>
    cdc8:	01065693          	srli	a3,a2,0x10
    cdcc:	01000713          	li	a4,16
    cdd0:	d0dff06f          	j	cadc <__udivdi3+0x168>
    cdd4:	00000593          	li	a1,0
    cdd8:	00100513          	li	a0,1
    cddc:	00008067          	ret
    cde0:	00070513          	mv	a0,a4
    cde4:	e71ff06f          	j	cc54 <__udivdi3+0x2e0>
    cde8:	00068593          	mv	a1,a3
    cdec:	f45ff06f          	j	cd30 <__udivdi3+0x3bc>
    cdf0:	00050e13          	mv	t3,a0
    cdf4:	e25ff06f          	j	cc18 <__udivdi3+0x2a4>
    cdf8:	00088793          	mv	a5,a7
    cdfc:	ef9ff06f          	j	ccf4 <__udivdi3+0x380>
    ce00:	ffe50513          	addi	a0,a0,-2
    ce04:	010787b3          	add	a5,a5,a6
    ce08:	d39ff06f          	j	cb40 <__udivdi3+0x1cc>
    ce0c:	ffe50513          	addi	a0,a0,-2
    ce10:	010787b3          	add	a5,a5,a6
    ce14:	c01ff06f          	j	ca14 <__udivdi3+0xa0>
    ce18:	01865693          	srli	a3,a2,0x18
    ce1c:	01800713          	li	a4,24
    ce20:	cbdff06f          	j	cadc <__udivdi3+0x168>

0000ce24 <__umoddi3>:
    ce24:	00060813          	mv	a6,a2
    ce28:	00050893          	mv	a7,a0
    ce2c:	00058793          	mv	a5,a1
    ce30:	00058713          	mv	a4,a1
    ce34:	0c069863          	bnez	a3,cf04 <__umoddi3+0xe0>
    ce38:	12c5fa63          	bgeu	a1,a2,cf6c <__umoddi3+0x148>
    ce3c:	000107b7          	lui	a5,0x10
    ce40:	1cf66c63          	bltu	a2,a5,d018 <__umoddi3+0x1f4>
    ce44:	010007b7          	lui	a5,0x1000
    ce48:	01800693          	li	a3,24
    ce4c:	00f67463          	bgeu	a2,a5,ce54 <__umoddi3+0x30>
    ce50:	01000693          	li	a3,16
    ce54:	00d65333          	srl	t1,a2,a3
    ce58:	00001797          	auipc	a5,0x1
    ce5c:	61c78793          	addi	a5,a5,1564 # e474 <__clz_tab>
    ce60:	006787b3          	add	a5,a5,t1
    ce64:	0007c783          	lbu	a5,0(a5)
    ce68:	02000313          	li	t1,32
    ce6c:	00d787b3          	add	a5,a5,a3
    ce70:	40f306b3          	sub	a3,t1,a5
    ce74:	00f30c63          	beq	t1,a5,ce8c <__umoddi3+0x68>
    ce78:	00d59733          	sll	a4,a1,a3
    ce7c:	00f557b3          	srl	a5,a0,a5
    ce80:	00d61833          	sll	a6,a2,a3
    ce84:	00e7e733          	or	a4,a5,a4
    ce88:	00d518b3          	sll	a7,a0,a3
    ce8c:	01085593          	srli	a1,a6,0x10
    ce90:	02b75633          	divu	a2,a4,a1
    ce94:	01081313          	slli	t1,a6,0x10
    ce98:	01035313          	srli	t1,t1,0x10
    ce9c:	0108d793          	srli	a5,a7,0x10
    cea0:	02b77733          	remu	a4,a4,a1
    cea4:	02660633          	mul	a2,a2,t1
    cea8:	01071713          	slli	a4,a4,0x10
    ceac:	00e7e7b3          	or	a5,a5,a4
    ceb0:	00c7f863          	bgeu	a5,a2,cec0 <__umoddi3+0x9c>
    ceb4:	00f807b3          	add	a5,a6,a5
    ceb8:	0107e463          	bltu	a5,a6,cec0 <__umoddi3+0x9c>
    cebc:	3cc7e263          	bltu	a5,a2,d280 <__umoddi3+0x45c>
    cec0:	40c787b3          	sub	a5,a5,a2
    cec4:	02b7d733          	divu	a4,a5,a1
    cec8:	01089513          	slli	a0,a7,0x10
    cecc:	01055513          	srli	a0,a0,0x10
    ced0:	02b7f7b3          	remu	a5,a5,a1
    ced4:	02670733          	mul	a4,a4,t1
    ced8:	01079793          	slli	a5,a5,0x10
    cedc:	00f56533          	or	a0,a0,a5
    cee0:	00e57a63          	bgeu	a0,a4,cef4 <__umoddi3+0xd0>
    cee4:	00a80533          	add	a0,a6,a0
    cee8:	01056663          	bltu	a0,a6,cef4 <__umoddi3+0xd0>
    ceec:	00e57463          	bgeu	a0,a4,cef4 <__umoddi3+0xd0>
    cef0:	01050533          	add	a0,a0,a6
    cef4:	40e50533          	sub	a0,a0,a4
    cef8:	00d55533          	srl	a0,a0,a3
    cefc:	00000593          	li	a1,0
    cf00:	00008067          	ret
    cf04:	00d5f463          	bgeu	a1,a3,cf0c <__umoddi3+0xe8>
    cf08:	00008067          	ret
    cf0c:	00010737          	lui	a4,0x10
    cf10:	1ce6e663          	bltu	a3,a4,d0dc <__umoddi3+0x2b8>
    cf14:	01000737          	lui	a4,0x1000
    cf18:	01800813          	li	a6,24
    cf1c:	00e6f463          	bgeu	a3,a4,cf24 <__umoddi3+0x100>
    cf20:	01000813          	li	a6,16
    cf24:	0106d333          	srl	t1,a3,a6
    cf28:	00001717          	auipc	a4,0x1
    cf2c:	54c70713          	addi	a4,a4,1356 # e474 <__clz_tab>
    cf30:	00670733          	add	a4,a4,t1
    cf34:	00074703          	lbu	a4,0(a4)
    cf38:	02000313          	li	t1,32
    cf3c:	01070733          	add	a4,a4,a6
    cf40:	40e30833          	sub	a6,t1,a4
    cf44:	1ce31463          	bne	t1,a4,d10c <__umoddi3+0x2e8>
    cf48:	00b6e463          	bltu	a3,a1,cf50 <__umoddi3+0x12c>
    cf4c:	00c56a63          	bltu	a0,a2,cf60 <__umoddi3+0x13c>
    cf50:	40c508b3          	sub	a7,a0,a2
    cf54:	40d586b3          	sub	a3,a1,a3
    cf58:	011537b3          	sltu	a5,a0,a7
    cf5c:	40f687b3          	sub	a5,a3,a5
    cf60:	00088513          	mv	a0,a7
    cf64:	00078593          	mv	a1,a5
    cf68:	00008067          	ret
    cf6c:	0a060e63          	beqz	a2,d028 <__umoddi3+0x204>
    cf70:	000107b7          	lui	a5,0x10
    cf74:	2ef67463          	bgeu	a2,a5,d25c <__umoddi3+0x438>
    cf78:	10063713          	sltiu	a4,a2,256
    cf7c:	00173713          	seqz	a4,a4
    cf80:	00371713          	slli	a4,a4,0x3
    cf84:	00e656b3          	srl	a3,a2,a4
    cf88:	00001797          	auipc	a5,0x1
    cf8c:	4ec78793          	addi	a5,a5,1260 # e474 <__clz_tab>
    cf90:	00d787b3          	add	a5,a5,a3
    cf94:	0007c783          	lbu	a5,0(a5)
    cf98:	02000313          	li	t1,32
    cf9c:	00e787b3          	add	a5,a5,a4
    cfa0:	40f306b3          	sub	a3,t1,a5
    cfa4:	0af31663          	bne	t1,a5,d050 <__umoddi3+0x22c>
    cfa8:	40c58733          	sub	a4,a1,a2
    cfac:	01065313          	srli	t1,a2,0x10
    cfb0:	01061613          	slli	a2,a2,0x10
    cfb4:	01065613          	srli	a2,a2,0x10
    cfb8:	026755b3          	divu	a1,a4,t1
    cfbc:	0108d793          	srli	a5,a7,0x10
    cfc0:	02677733          	remu	a4,a4,t1
    cfc4:	02c585b3          	mul	a1,a1,a2
    cfc8:	01071713          	slli	a4,a4,0x10
    cfcc:	00e7e7b3          	or	a5,a5,a4
    cfd0:	00b7fa63          	bgeu	a5,a1,cfe4 <__umoddi3+0x1c0>
    cfd4:	00f807b3          	add	a5,a6,a5
    cfd8:	0107e663          	bltu	a5,a6,cfe4 <__umoddi3+0x1c0>
    cfdc:	00b7f463          	bgeu	a5,a1,cfe4 <__umoddi3+0x1c0>
    cfe0:	010787b3          	add	a5,a5,a6
    cfe4:	40b787b3          	sub	a5,a5,a1
    cfe8:	0267d733          	divu	a4,a5,t1
    cfec:	01089893          	slli	a7,a7,0x10
    cff0:	0108d893          	srli	a7,a7,0x10
    cff4:	0267f7b3          	remu	a5,a5,t1
    cff8:	02c70733          	mul	a4,a4,a2
    cffc:	01079513          	slli	a0,a5,0x10
    d000:	00a8e533          	or	a0,a7,a0
    d004:	eee560e3          	bltu	a0,a4,cee4 <__umoddi3+0xc0>
    d008:	40e50533          	sub	a0,a0,a4
    d00c:	00d55533          	srl	a0,a0,a3
    d010:	00000593          	li	a1,0
    d014:	00008067          	ret
    d018:	10063693          	sltiu	a3,a2,256
    d01c:	0016b693          	seqz	a3,a3
    d020:	00369693          	slli	a3,a3,0x3
    d024:	e31ff06f          	j	ce54 <__umoddi3+0x30>
    d028:	00000693          	li	a3,0
    d02c:	00001797          	auipc	a5,0x1
    d030:	44878793          	addi	a5,a5,1096 # e474 <__clz_tab>
    d034:	00d787b3          	add	a5,a5,a3
    d038:	0007c783          	lbu	a5,0(a5)
    d03c:	00000713          	li	a4,0
    d040:	02000313          	li	t1,32
    d044:	00e787b3          	add	a5,a5,a4
    d048:	40f306b3          	sub	a3,t1,a5
    d04c:	f4f30ee3          	beq	t1,a5,cfa8 <__umoddi3+0x184>
    d050:	00d61833          	sll	a6,a2,a3
    d054:	00f5de33          	srl	t3,a1,a5
    d058:	01085313          	srli	t1,a6,0x10
    d05c:	026e5eb3          	divu	t4,t3,t1
    d060:	01081613          	slli	a2,a6,0x10
    d064:	00d595b3          	sll	a1,a1,a3
    d068:	00f55733          	srl	a4,a0,a5
    d06c:	01065613          	srli	a2,a2,0x10
    d070:	00b76733          	or	a4,a4,a1
    d074:	01075793          	srli	a5,a4,0x10
    d078:	00d518b3          	sll	a7,a0,a3
    d07c:	026e7e33          	remu	t3,t3,t1
    d080:	02ce85b3          	mul	a1,t4,a2
    d084:	010e1e13          	slli	t3,t3,0x10
    d088:	01c7e7b3          	or	a5,a5,t3
    d08c:	00b7fa63          	bgeu	a5,a1,d0a0 <__umoddi3+0x27c>
    d090:	00f807b3          	add	a5,a6,a5
    d094:	0107e663          	bltu	a5,a6,d0a0 <__umoddi3+0x27c>
    d098:	00b7f463          	bgeu	a5,a1,d0a0 <__umoddi3+0x27c>
    d09c:	010787b3          	add	a5,a5,a6
    d0a0:	40b787b3          	sub	a5,a5,a1
    d0a4:	0267d5b3          	divu	a1,a5,t1
    d0a8:	01071713          	slli	a4,a4,0x10
    d0ac:	01075713          	srli	a4,a4,0x10
    d0b0:	0267f7b3          	remu	a5,a5,t1
    d0b4:	02c585b3          	mul	a1,a1,a2
    d0b8:	01079793          	slli	a5,a5,0x10
    d0bc:	00f76733          	or	a4,a4,a5
    d0c0:	00b77a63          	bgeu	a4,a1,d0d4 <__umoddi3+0x2b0>
    d0c4:	00e80733          	add	a4,a6,a4
    d0c8:	01076663          	bltu	a4,a6,d0d4 <__umoddi3+0x2b0>
    d0cc:	00b77463          	bgeu	a4,a1,d0d4 <__umoddi3+0x2b0>
    d0d0:	01070733          	add	a4,a4,a6
    d0d4:	40b70733          	sub	a4,a4,a1
    d0d8:	ee1ff06f          	j	cfb8 <__umoddi3+0x194>
    d0dc:	1006b813          	sltiu	a6,a3,256
    d0e0:	00183813          	seqz	a6,a6
    d0e4:	00381813          	slli	a6,a6,0x3
    d0e8:	0106d333          	srl	t1,a3,a6
    d0ec:	00001717          	auipc	a4,0x1
    d0f0:	38870713          	addi	a4,a4,904 # e474 <__clz_tab>
    d0f4:	00670733          	add	a4,a4,t1
    d0f8:	00074703          	lbu	a4,0(a4)
    d0fc:	02000313          	li	t1,32
    d100:	01070733          	add	a4,a4,a6
    d104:	40e30833          	sub	a6,t1,a4
    d108:	e4e300e3          	beq	t1,a4,cf48 <__umoddi3+0x124>
    d10c:	010696b3          	sll	a3,a3,a6
    d110:	00e658b3          	srl	a7,a2,a4
    d114:	00d8e8b3          	or	a7,a7,a3
    d118:	00e5de33          	srl	t3,a1,a4
    d11c:	0108df13          	srli	t5,a7,0x10
    d120:	03ee57b3          	divu	a5,t3,t5
    d124:	01089e93          	slli	t4,a7,0x10
    d128:	010ede93          	srli	t4,t4,0x10
    d12c:	00e556b3          	srl	a3,a0,a4
    d130:	01051333          	sll	t1,a0,a6
    d134:	010595b3          	sll	a1,a1,a6
    d138:	00b6e5b3          	or	a1,a3,a1
    d13c:	0105d693          	srli	a3,a1,0x10
    d140:	01061633          	sll	a2,a2,a6
    d144:	03ee7e33          	remu	t3,t3,t5
    d148:	02fe8533          	mul	a0,t4,a5
    d14c:	010e1e13          	slli	t3,t3,0x10
    d150:	01c6e6b3          	or	a3,a3,t3
    d154:	00a6fe63          	bgeu	a3,a0,d170 <__umoddi3+0x34c>
    d158:	00d886b3          	add	a3,a7,a3
    d15c:	fff78e13          	addi	t3,a5,-1
    d160:	1116ec63          	bltu	a3,a7,d278 <__umoddi3+0x454>
    d164:	10a6fa63          	bgeu	a3,a0,d278 <__umoddi3+0x454>
    d168:	ffe78793          	addi	a5,a5,-2
    d16c:	011686b3          	add	a3,a3,a7
    d170:	40a686b3          	sub	a3,a3,a0
    d174:	03e6d533          	divu	a0,a3,t5
    d178:	01059593          	slli	a1,a1,0x10
    d17c:	0105d593          	srli	a1,a1,0x10
    d180:	03e6f6b3          	remu	a3,a3,t5
    d184:	02ae8eb3          	mul	t4,t4,a0
    d188:	01069693          	slli	a3,a3,0x10
    d18c:	00d5e5b3          	or	a1,a1,a3
    d190:	01d5fe63          	bgeu	a1,t4,d1ac <__umoddi3+0x388>
    d194:	00b885b3          	add	a1,a7,a1
    d198:	fff50693          	addi	a3,a0,-1
    d19c:	0d15ea63          	bltu	a1,a7,d270 <__umoddi3+0x44c>
    d1a0:	0dd5f863          	bgeu	a1,t4,d270 <__umoddi3+0x44c>
    d1a4:	ffe50513          	addi	a0,a0,-2
    d1a8:	011585b3          	add	a1,a1,a7
    d1ac:	01079693          	slli	a3,a5,0x10
    d1b0:	000102b7          	lui	t0,0x10
    d1b4:	00a6e6b3          	or	a3,a3,a0
    d1b8:	fff28513          	addi	a0,t0,-1 # ffff <__global_pointer$+0x1297>
    d1bc:	00a6fe33          	and	t3,a3,a0
    d1c0:	01065f93          	srli	t6,a2,0x10
    d1c4:	0106d693          	srli	a3,a3,0x10
    d1c8:	00a67533          	and	a0,a2,a0
    d1cc:	02ae0f33          	mul	t5,t3,a0
    d1d0:	41d585b3          	sub	a1,a1,t4
    d1d4:	02a68533          	mul	a0,a3,a0
    d1d8:	010f5793          	srli	a5,t5,0x10
    d1dc:	03fe0e33          	mul	t3,t3,t6
    d1e0:	00ae0e33          	add	t3,t3,a0
    d1e4:	01c787b3          	add	a5,a5,t3
    d1e8:	03f686b3          	mul	a3,a3,t6
    d1ec:	00a7f463          	bgeu	a5,a0,d1f4 <__umoddi3+0x3d0>
    d1f0:	005686b3          	add	a3,a3,t0
    d1f4:	00010eb7          	lui	t4,0x10
    d1f8:	fffe8e93          	addi	t4,t4,-1 # ffff <__global_pointer$+0x1297>
    d1fc:	01d7f533          	and	a0,a5,t4
    d200:	0107de13          	srli	t3,a5,0x10
    d204:	01051513          	slli	a0,a0,0x10
    d208:	01df7f33          	and	t5,t5,t4
    d20c:	00de07b3          	add	a5,t3,a3
    d210:	01e50533          	add	a0,a0,t5
    d214:	02f5e863          	bltu	a1,a5,d244 <__umoddi3+0x420>
    d218:	02f58463          	beq	a1,a5,d240 <__umoddi3+0x41c>
    d21c:	40a30533          	sub	a0,t1,a0
    d220:	00a33333          	sltu	t1,t1,a0
    d224:	40f585b3          	sub	a1,a1,a5
    d228:	406585b3          	sub	a1,a1,t1
    d22c:	00e59733          	sll	a4,a1,a4
    d230:	01055533          	srl	a0,a0,a6
    d234:	00a76533          	or	a0,a4,a0
    d238:	0105d5b3          	srl	a1,a1,a6
    d23c:	00008067          	ret
    d240:	fca37ee3          	bgeu	t1,a0,d21c <__umoddi3+0x3f8>
    d244:	40c50633          	sub	a2,a0,a2
    d248:	00c53533          	sltu	a0,a0,a2
    d24c:	011508b3          	add	a7,a0,a7
    d250:	411787b3          	sub	a5,a5,a7
    d254:	00060513          	mv	a0,a2
    d258:	fc5ff06f          	j	d21c <__umoddi3+0x3f8>
    d25c:	010007b7          	lui	a5,0x1000
    d260:	02f67463          	bgeu	a2,a5,d288 <__umoddi3+0x464>
    d264:	01065693          	srli	a3,a2,0x10
    d268:	01000713          	li	a4,16
    d26c:	d1dff06f          	j	cf88 <__umoddi3+0x164>
    d270:	00068513          	mv	a0,a3
    d274:	f39ff06f          	j	d1ac <__umoddi3+0x388>
    d278:	000e0793          	mv	a5,t3
    d27c:	ef5ff06f          	j	d170 <__umoddi3+0x34c>
    d280:	010787b3          	add	a5,a5,a6
    d284:	c3dff06f          	j	cec0 <__umoddi3+0x9c>
    d288:	01865693          	srli	a3,a2,0x18
    d28c:	01800713          	li	a4,24
    d290:	cf9ff06f          	j	cf88 <__umoddi3+0x164>
