import hashlib
import json
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

root = Path.cwd()
cpu = root / 'generated/verification/v3/cpu-builder-20261025'
dest = root / 'docs/efinix_2d_gpu/evidence/logic_q8_shift_20261025'
archive = dest / 'evidence.zip'
assert not archive.exists(), 'Never overwrite sealed evidence'
files = {}
def add(path, name):
    assert path.is_file() and name not in files, path
    files[name] = path
def tree(path, prefix):
    assert path.is_dir(), path
    for child in sorted(path.rglob('*')):
        if child.is_file() and '__pycache__' not in child.parts:
            add(child, prefix + '/' + child.relative_to(path).as_posix())
for name in ('probe-logic-control-r1', 'probe-logic-shift-r1', 'normal-logic-control-r1',
             'normal-logic-shift-r1', 'logic-final-menu-r1', 'logic-normal-menu-r1'):
    tree(cpu / name, name)
for name in ('logic-coordinate-red.log', 'logic-coordinate-green.log', 'logic-q8-green.log',
             'logic-q8-baseline.log', 'logic-cpu-drawing-unchanged.log', 'software-logic-q8-r1.log',
             'logic-baseline-bullet_demo.c', 'build-logic-control.ps1',
             'build-logic-control-r1.log', 'build-logic-shift-r1.log',
             'build-normal-logic-control-r1.log', 'build-normal-logic-shift-r1.log',
             'logic-shift-linked.asm', 'run-logic-aba-r1.ps1', 'logic-bit-load-r1.log',
             'logic-board-cohort-r1.log', 'logic-cohort-summary-r1.json', 'logic-analysis-r1.json',
             'logic-final-state-r1.json', 'logic-final-menu-r1.log', 'logic-normal-menu-r1.log',
             'logic-normal-state-r1.json'):
    add(cpu / name, 'verification/' + name)
add(cpu / 'sprite-fast-linked.asm', 'codegen/control-linked.asm')
for name in ('logic-control-a1', 'logic-fast-b1', 'logic-control-a2', 'logic-fast-b2'):
    for kind in ('uart', 'capture'):
        add(cpu / (name + '-' + kind + '.log'), 'board/' + name + '-' + kind + '.log')
for name in ('src', 'include', 'tests'):
    tree(root / 'sw/efinix_gpu' / name, 'source/sw/efinix_gpu/' + name)
for name in ('scripts/test-logic-coordinate-codegen.ps1', 'scripts/test-gpu-sprite-codegen.ps1',
             'scripts/test-gpu-coordinate-codegen.ps1', 'scripts/test-v3-instances.sh',
             'scripts/test-v3-integration.ps1', 'scripts/test-efinix-software.ps1',
             'scripts/capture-game-probe.ps1', 'scripts/test-game-menu-board.ps1',
             'scripts/control-keepalive.py', 'sw/efinix_gpu/Makefile', 'sw/efinix_gpu/linker.ld'):
    add(root / name, 'source/' + name)
for name in ('logic-coordinate-codegen-9eba84bcef8d488f8cf92fad4c7f68cf',
             'logic-coordinate-codegen-b38f0981e51c426b9cfba0f0db686213'):
    path = root / 'generated/verification/v3' / name
    add(path / 'step.asm', 'codegen/' + name + '/step.asm')
    add(path / 'bullet.o', 'codegen/' + name + '/bullet.o')
add(dest / 'README.md', 'README.md')
add(Path(__file__), 'verification/seal-logic.py')
rows = 0
manifest = []
with ZipFile(archive, 'x', ZIP_DEFLATED, compresslevel=9) as zipped:
    for name, path in sorted(files.items()):
        data = path.read_bytes()
        if path.suffix == '.jsonl':
            for line in data.decode('utf-8-sig').splitlines():
                json.loads(line)
                assert not any('"' + key + '"' in line for key in ('token', 'authorization', 'password', 'secret'))
                rows += 1
        elif path.suffix == '.json':
            json.loads(data.decode('utf-8-sig'))
        manifest.append(dict(path=name, size=len(data), sha256=hashlib.sha256(data).hexdigest()))
        zipped.writestr(name, data)
    body = json.dumps(dict(payloads=manifest, parsed_status_rows=rows,
                           implementation_commit='29a0241', continuous_long_run_proven=False), indent=2).encode()
    zipped.writestr('manifest.json', body)
with ZipFile(archive) as zipped:
    assert len(zipped.namelist()) == len(manifest)+1 == len(set(zipped.namelist()))
    for item in manifest:
        data = zipped.read(item['path'])
        assert len(data) == item['size'] and hashlib.sha256(data).hexdigest() == item['sha256']
digest = hashlib.sha256(archive.read_bytes()).hexdigest()
(dest / 'SHA256SUMS').write_text(digest + '  evidence.zip\n')
(dest / 'manifest.json').write_bytes(body)
result = dict(sha256=digest, bytes=archive.stat().st_size, entries=len(manifest)+1, status_rows=rows)
(cpu / 'logic-seal-summary.json').write_text(json.dumps(result, indent=2))
print(json.dumps(result))
