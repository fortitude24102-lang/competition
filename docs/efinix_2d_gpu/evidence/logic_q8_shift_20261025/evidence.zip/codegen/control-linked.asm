
generated/verification/v3/cpu-builder-20261025/probe-sprite-fast-r1/gpu_demo.elf:     file format elf32-littleriscv


Disassembly of section .init:

00001000 <_start>:
    1000:	0000e197          	auipc	gp,0xe
    1004:	d8018193          	addi	gp,gp,-640 # ed80 <__global_pointer$>

00001008 <init>:
    1008:	0001d117          	auipc	sp,0x1d
    100c:	a9810113          	addi	sp,sp,-1384 # 1daa0 <__freertos_irq_stack_top>
    1010:	0000c517          	auipc	a0,0xc
    1014:	29c50513          	addi	a0,a0,668 # d2ac <_data>
    1018:	0000c597          	auipc	a1,0xc
    101c:	29458593          	addi	a1,a1,660 # d2ac <_data>
    1020:	0000d617          	auipc	a2,0xd
    1024:	58060613          	addi	a2,a2,1408 # e5a0 <logo_enabled>
    1028:	00c5fc63          	bgeu	a1,a2,1040 <init+0x38>
    102c:	00052283          	lw	t0,0(a0)
    1030:	0055a023          	sw	t0,0(a1)
    1034:	00450513          	addi	a0,a0,4
    1038:	00458593          	addi	a1,a1,4
    103c:	fec5e8e3          	bltu	a1,a2,102c <init+0x24>
    1040:	0000d517          	auipc	a0,0xd
    1044:	56050513          	addi	a0,a0,1376 # e5a0 <logo_enabled>
    1048:	0001c597          	auipc	a1,0x1c
    104c:	a5058593          	addi	a1,a1,-1456 # 1ca98 <_end>
    1050:	00b57863          	bgeu	a0,a1,1060 <init+0x58>
    1054:	00052023          	sw	zero,0(a0)
    1058:	00450513          	addi	a0,a0,4
    105c:	feb56ce3          	bltu	a0,a1,1054 <init+0x4c>
    1060:	448000ef          	jal	14a8 <main>

00001064 <mainDone>:
    1064:	0000006f          	j	1064 <mainDone>

00001068 <_init>:
    1068:	00008067          	ret

Disassembly of section .text:

0000106c <memcmp>:
    106c:	00300793          	li	a5,3
    1070:	02c7fe63          	bgeu	a5,a2,10ac <memcmp+0x40>
    1074:	00a5e7b3          	or	a5,a1,a0
    1078:	0037f793          	andi	a5,a5,3
    107c:	02079463          	bnez	a5,10a4 <memcmp+0x38>
    1080:	00300693          	li	a3,3
    1084:	0140006f          	j	1098 <memcmp+0x2c>
    1088:	ffc60613          	addi	a2,a2,-4
    108c:	00450513          	addi	a0,a0,4
    1090:	00458593          	addi	a1,a1,4
    1094:	00c6fc63          	bgeu	a3,a2,10ac <memcmp+0x40>
    1098:	00052703          	lw	a4,0(a0)
    109c:	0005a783          	lw	a5,0(a1)
    10a0:	fef704e3          	beq	a4,a5,1088 <memcmp+0x1c>
    10a4:	fff60693          	addi	a3,a2,-1
    10a8:	00c0006f          	j	10b4 <memcmp+0x48>
    10ac:	fff60693          	addi	a3,a2,-1
    10b0:	02060863          	beqz	a2,10e0 <memcmp+0x74>
    10b4:	00168693          	addi	a3,a3,1
    10b8:	00d506b3          	add	a3,a0,a3
    10bc:	0080006f          	j	10c4 <memcmp+0x58>
    10c0:	02a68063          	beq	a3,a0,10e0 <memcmp+0x74>
    10c4:	00054783          	lbu	a5,0(a0)
    10c8:	0005c703          	lbu	a4,0(a1)
    10cc:	00150513          	addi	a0,a0,1
    10d0:	00158593          	addi	a1,a1,1
    10d4:	fee786e3          	beq	a5,a4,10c0 <memcmp+0x54>
    10d8:	40e78533          	sub	a0,a5,a4
    10dc:	00008067          	ret
    10e0:	00000513          	li	a0,0
    10e4:	00008067          	ret

000010e8 <strchr>:
    10e8:	0ff5f693          	zext.b	a3,a1
    10ec:	00357793          	andi	a5,a0,3
    10f0:	0c068063          	beqz	a3,11b0 <strchr+0xc8>
    10f4:	00078e63          	beqz	a5,1110 <strchr+0x28>
    10f8:	00054783          	lbu	a5,0(a0)
    10fc:	0a078663          	beqz	a5,11a8 <strchr+0xc0>
    1100:	0ad78663          	beq	a5,a3,11ac <strchr+0xc4>
    1104:	00150513          	addi	a0,a0,1
    1108:	00357793          	andi	a5,a0,3
    110c:	fe0796e3          	bnez	a5,10f8 <strchr+0x10>
    1110:	0ff5f593          	zext.b	a1,a1
    1114:	00859893          	slli	a7,a1,0x8
    1118:	00052703          	lw	a4,0(a0)
    111c:	00b888b3          	add	a7,a7,a1
    1120:	01089793          	slli	a5,a7,0x10
    1124:	00f888b3          	add	a7,a7,a5
    1128:	feff0837          	lui	a6,0xfeff0
    112c:	00e8c633          	xor	a2,a7,a4
    1130:	eff80813          	addi	a6,a6,-257 # fefefeff <__gpu_framebuffer_a+0xfcfefeff>
    1134:	010707b3          	add	a5,a4,a6
    1138:	010605b3          	add	a1,a2,a6
    113c:	fff74713          	not	a4,a4
    1140:	fff64613          	not	a2,a2
    1144:	00e7f7b3          	and	a5,a5,a4
    1148:	80808337          	lui	t1,0x80808
    114c:	00c5f733          	and	a4,a1,a2
    1150:	00e7e7b3          	or	a5,a5,a4
    1154:	08030313          	addi	t1,t1,128 # 80808080 <__gpu_framebuffer_a+0x7e808080>
    1158:	0067f7b3          	and	a5,a5,t1
    115c:	02079a63          	bnez	a5,1190 <strchr+0xa8>
    1160:	00452703          	lw	a4,4(a0)
    1164:	00450513          	addi	a0,a0,4
    1168:	01174633          	xor	a2,a4,a7
    116c:	010707b3          	add	a5,a4,a6
    1170:	010605b3          	add	a1,a2,a6
    1174:	fff74713          	not	a4,a4
    1178:	fff64613          	not	a2,a2
    117c:	00e7f7b3          	and	a5,a5,a4
    1180:	00c5f733          	and	a4,a1,a2
    1184:	00e7e7b3          	or	a5,a5,a4
    1188:	0067f7b3          	and	a5,a5,t1
    118c:	fc078ae3          	beqz	a5,1160 <strchr+0x78>
    1190:	00054783          	lbu	a5,0(a0)
    1194:	00078a63          	beqz	a5,11a8 <strchr+0xc0>
    1198:	08f68663          	beq	a3,a5,1224 <strchr+0x13c>
    119c:	00154783          	lbu	a5,1(a0)
    11a0:	00150513          	addi	a0,a0,1
    11a4:	fe079ae3          	bnez	a5,1198 <strchr+0xb0>
    11a8:	00000513          	li	a0,0
    11ac:	00008067          	ret
    11b0:	00078c63          	beqz	a5,11c8 <strchr+0xe0>
    11b4:	00054783          	lbu	a5,0(a0)
    11b8:	fe078ae3          	beqz	a5,11ac <strchr+0xc4>
    11bc:	00150513          	addi	a0,a0,1
    11c0:	00357793          	andi	a5,a0,3
    11c4:	fe0798e3          	bnez	a5,11b4 <strchr+0xcc>
    11c8:	00052703          	lw	a4,0(a0)
    11cc:	feff0637          	lui	a2,0xfeff0
    11d0:	eff60613          	addi	a2,a2,-257 # fefefeff <__gpu_framebuffer_a+0xfcfefeff>
    11d4:	00c707b3          	add	a5,a4,a2
    11d8:	808086b7          	lui	a3,0x80808
    11dc:	fff74713          	not	a4,a4
    11e0:	00e7f7b3          	and	a5,a5,a4
    11e4:	08068693          	addi	a3,a3,128 # 80808080 <__gpu_framebuffer_a+0x7e808080>
    11e8:	00d7f7b3          	and	a5,a5,a3
    11ec:	02079063          	bnez	a5,120c <strchr+0x124>
    11f0:	00452703          	lw	a4,4(a0)
    11f4:	00450513          	addi	a0,a0,4
    11f8:	00c707b3          	add	a5,a4,a2
    11fc:	fff74713          	not	a4,a4
    1200:	00e7f7b3          	and	a5,a5,a4
    1204:	00d7f7b3          	and	a5,a5,a3
    1208:	fe0784e3          	beqz	a5,11f0 <strchr+0x108>
    120c:	00054783          	lbu	a5,0(a0)
    1210:	f8078ee3          	beqz	a5,11ac <strchr+0xc4>
    1214:	00154783          	lbu	a5,1(a0)
    1218:	00150513          	addi	a0,a0,1
    121c:	fe079ce3          	bnez	a5,1214 <strchr+0x12c>
    1220:	00008067          	ret
    1224:	00008067          	ret

00001228 <memset>:
    1228:	00f00313          	li	t1,15
    122c:	00050713          	mv	a4,a0
    1230:	02c37e63          	bgeu	t1,a2,126c <memset+0x44>
    1234:	00f77793          	andi	a5,a4,15
    1238:	0a079063          	bnez	a5,12d8 <memset+0xb0>
    123c:	08059263          	bnez	a1,12c0 <memset+0x98>
    1240:	ff067693          	andi	a3,a2,-16
    1244:	00f67613          	andi	a2,a2,15
    1248:	00e686b3          	add	a3,a3,a4
    124c:	00b72023          	sw	a1,0(a4)
    1250:	00b72223          	sw	a1,4(a4)
    1254:	00b72423          	sw	a1,8(a4)
    1258:	00b72623          	sw	a1,12(a4)
    125c:	01070713          	addi	a4,a4,16
    1260:	fed766e3          	bltu	a4,a3,124c <memset+0x24>
    1264:	00061463          	bnez	a2,126c <memset+0x44>
    1268:	00008067          	ret
    126c:	40c306b3          	sub	a3,t1,a2
    1270:	00269693          	slli	a3,a3,0x2
    1274:	00000297          	auipc	t0,0x0
    1278:	005686b3          	add	a3,a3,t0
    127c:	00c68067          	jr	12(a3)
    1280:	00b70723          	sb	a1,14(a4)
    1284:	00b706a3          	sb	a1,13(a4)
    1288:	00b70623          	sb	a1,12(a4)
    128c:	00b705a3          	sb	a1,11(a4)
    1290:	00b70523          	sb	a1,10(a4)
    1294:	00b704a3          	sb	a1,9(a4)
    1298:	00b70423          	sb	a1,8(a4)
    129c:	00b703a3          	sb	a1,7(a4)
    12a0:	00b70323          	sb	a1,6(a4)
    12a4:	00b702a3          	sb	a1,5(a4)
    12a8:	00b70223          	sb	a1,4(a4)
    12ac:	00b701a3          	sb	a1,3(a4)
    12b0:	00b70123          	sb	a1,2(a4)
    12b4:	00b700a3          	sb	a1,1(a4)
    12b8:	00b70023          	sb	a1,0(a4)
    12bc:	00008067          	ret
    12c0:	0ff5f593          	zext.b	a1,a1
    12c4:	00859693          	slli	a3,a1,0x8
    12c8:	00d5e5b3          	or	a1,a1,a3
    12cc:	01059693          	slli	a3,a1,0x10
    12d0:	00d5e5b3          	or	a1,a1,a3
    12d4:	f6dff06f          	j	1240 <memset+0x18>
    12d8:	00279693          	slli	a3,a5,0x2
    12dc:	00000297          	auipc	t0,0x0
    12e0:	005686b3          	add	a3,a3,t0
    12e4:	00008293          	mv	t0,ra
    12e8:	fa0680e7          	jalr	-96(a3)
    12ec:	00028093          	mv	ra,t0
    12f0:	ff078793          	addi	a5,a5,-16
    12f4:	40f70733          	sub	a4,a4,a5
    12f8:	00f60633          	add	a2,a2,a5
    12fc:	f6c378e3          	bgeu	t1,a2,126c <memset+0x44>
    1300:	f3dff06f          	j	123c <memset+0x14>

00001304 <memcpy>:
    1304:	00a5c7b3          	xor	a5,a1,a0
    1308:	0037f793          	andi	a5,a5,3
    130c:	00c508b3          	add	a7,a0,a2
    1310:	06079463          	bnez	a5,1378 <memcpy+0x74>
    1314:	00300793          	li	a5,3
    1318:	06c7f063          	bgeu	a5,a2,1378 <memcpy+0x74>
    131c:	00357793          	andi	a5,a0,3
    1320:	00050713          	mv	a4,a0
    1324:	06079a63          	bnez	a5,1398 <memcpy+0x94>
    1328:	ffc8f613          	andi	a2,a7,-4
    132c:	40e606b3          	sub	a3,a2,a4
    1330:	02000793          	li	a5,32
    1334:	08d7ce63          	blt	a5,a3,13d0 <memcpy+0xcc>
    1338:	00058693          	mv	a3,a1
    133c:	00070793          	mv	a5,a4
    1340:	02c77863          	bgeu	a4,a2,1370 <memcpy+0x6c>
    1344:	0006a803          	lw	a6,0(a3)
    1348:	00478793          	addi	a5,a5,4
    134c:	00468693          	addi	a3,a3,4
    1350:	ff07ae23          	sw	a6,-4(a5)
    1354:	fec7e8e3          	bltu	a5,a2,1344 <memcpy+0x40>
    1358:	fff60793          	addi	a5,a2,-1
    135c:	40e787b3          	sub	a5,a5,a4
    1360:	ffc7f793          	andi	a5,a5,-4
    1364:	00478793          	addi	a5,a5,4
    1368:	00f70733          	add	a4,a4,a5
    136c:	00f585b3          	add	a1,a1,a5
    1370:	01176863          	bltu	a4,a7,1380 <memcpy+0x7c>
    1374:	00008067          	ret
    1378:	00050713          	mv	a4,a0
    137c:	05157863          	bgeu	a0,a7,13cc <memcpy+0xc8>
    1380:	0005c783          	lbu	a5,0(a1)
    1384:	00170713          	addi	a4,a4,1
    1388:	00158593          	addi	a1,a1,1
    138c:	fef70fa3          	sb	a5,-1(a4)
    1390:	fee898e3          	bne	a7,a4,1380 <memcpy+0x7c>
    1394:	00008067          	ret
    1398:	0005c683          	lbu	a3,0(a1)
    139c:	00170713          	addi	a4,a4,1
    13a0:	00377793          	andi	a5,a4,3
    13a4:	fed70fa3          	sb	a3,-1(a4)
    13a8:	00158593          	addi	a1,a1,1
    13ac:	f6078ee3          	beqz	a5,1328 <memcpy+0x24>
    13b0:	0005c683          	lbu	a3,0(a1)
    13b4:	00170713          	addi	a4,a4,1
    13b8:	00377793          	andi	a5,a4,3
    13bc:	fed70fa3          	sb	a3,-1(a4)
    13c0:	00158593          	addi	a1,a1,1
    13c4:	fc079ae3          	bnez	a5,1398 <memcpy+0x94>
    13c8:	f61ff06f          	j	1328 <memcpy+0x24>
    13cc:	00008067          	ret
    13d0:	ff010113          	addi	sp,sp,-16
    13d4:	00812623          	sw	s0,12(sp)
    13d8:	02000413          	li	s0,32
    13dc:	0005a383          	lw	t2,0(a1)
    13e0:	0045a283          	lw	t0,4(a1)
    13e4:	0085af83          	lw	t6,8(a1)
    13e8:	00c5af03          	lw	t5,12(a1)
    13ec:	0105ae83          	lw	t4,16(a1)
    13f0:	0145ae03          	lw	t3,20(a1)
    13f4:	0185a303          	lw	t1,24(a1)
    13f8:	01c5a803          	lw	a6,28(a1)
    13fc:	0205a683          	lw	a3,32(a1)
    1400:	02470713          	addi	a4,a4,36
    1404:	40e607b3          	sub	a5,a2,a4
    1408:	fc772e23          	sw	t2,-36(a4)
    140c:	fe572023          	sw	t0,-32(a4)
    1410:	fff72223          	sw	t6,-28(a4)
    1414:	ffe72423          	sw	t5,-24(a4)
    1418:	ffd72623          	sw	t4,-20(a4)
    141c:	ffc72823          	sw	t3,-16(a4)
    1420:	fe672a23          	sw	t1,-12(a4)
    1424:	ff072c23          	sw	a6,-8(a4)
    1428:	fed72e23          	sw	a3,-4(a4)
    142c:	02458593          	addi	a1,a1,36
    1430:	faf446e3          	blt	s0,a5,13dc <memcpy+0xd8>
    1434:	00058693          	mv	a3,a1
    1438:	00070793          	mv	a5,a4
    143c:	02c77863          	bgeu	a4,a2,146c <memcpy+0x168>
    1440:	0006a803          	lw	a6,0(a3)
    1444:	00478793          	addi	a5,a5,4
    1448:	00468693          	addi	a3,a3,4
    144c:	ff07ae23          	sw	a6,-4(a5)
    1450:	fec7e8e3          	bltu	a5,a2,1440 <memcpy+0x13c>
    1454:	fff60793          	addi	a5,a2,-1
    1458:	40e787b3          	sub	a5,a5,a4
    145c:	ffc7f793          	andi	a5,a5,-4
    1460:	00478793          	addi	a5,a5,4
    1464:	00f70733          	add	a4,a4,a5
    1468:	00f585b3          	add	a1,a1,a5
    146c:	01176863          	bltu	a4,a7,147c <memcpy+0x178>
    1470:	00c12403          	lw	s0,12(sp)
    1474:	01010113          	addi	sp,sp,16
    1478:	00008067          	ret
    147c:	0005c783          	lbu	a5,0(a1)
    1480:	00170713          	addi	a4,a4,1
    1484:	00158593          	addi	a1,a1,1
    1488:	fef70fa3          	sb	a5,-1(a4)
    148c:	fee882e3          	beq	a7,a4,1470 <memcpy+0x16c>
    1490:	0005c783          	lbu	a5,0(a1)
    1494:	00170713          	addi	a4,a4,1
    1498:	00158593          	addi	a1,a1,1
    149c:	fef70fa3          	sb	a5,-1(a4)
    14a0:	fce89ee3          	bne	a7,a4,147c <memcpy+0x178>
    14a4:	fcdff06f          	j	1470 <memcpy+0x16c>

000014a8 <main>:
    14a8:	fd010113          	addi	sp,sp,-48
    14ac:	02112623          	sw	ra,44(sp)
    14b0:	02812423          	sw	s0,40(sp)
    14b4:	f80107b7          	lui	a5,0xf8010
    14b8:	06b00713          	li	a4,107
    14bc:	00e7a423          	sw	a4,8(a5) # f8010008 <__gpu_framebuffer_a+0xf6010008>
    14c0:	f80107b7          	lui	a5,0xf8010
    14c4:	00700713          	li	a4,7
    14c8:	00e7a623          	sw	a4,12(a5) # f801000c <__gpu_framebuffer_a+0xf601000c>
    14cc:	f81005b7          	lui	a1,0xf8100
    14d0:	00810513          	addi	a0,sp,8
    14d4:	4f8000ef          	jal	19cc <gpu_init>
    14d8:	02050463          	beqz	a0,1500 <main+0x58>
    14dc:	00050593          	mv	a1,a0
    14e0:	0000d537          	lui	a0,0xd
    14e4:	32050513          	addi	a0,a0,800 # d320 <_data+0x74>
    14e8:	110000ef          	jal	15f8 <bsp_printf>
    14ec:	00100513          	li	a0,1
    14f0:	02c12083          	lw	ra,44(sp)
    14f4:	02812403          	lw	s0,40(sp)
    14f8:	03010113          	addi	sp,sp,48
    14fc:	00008067          	ret
    1500:	328000ef          	jal	1828 <gpu_platform_cycles>
    1504:	00050593          	mv	a1,a0
    1508:	00051463          	bnez	a0,1510 <main+0x68>
    150c:	00100593          	li	a1,1
    1510:	f8100537          	lui	a0,0xf8100
    1514:	3d9050ef          	jal	70ec <bullet_prepare_assets>
    1518:	00050413          	mv	s0,a0
    151c:	0000e537          	lui	a0,0xe
    1520:	00700613          	li	a2,7
    1524:	02000593          	li	a1,32
    1528:	6ac50513          	addi	a0,a0,1708 # e6ac <bullets>
    152c:	735030ef          	jal	5460 <bullet_reset>
    1530:	fa051ee3          	bnez	a0,14ec <main+0x44>
    1534:	318000ef          	jal	184c <gpu_platform_sync>
    1538:	00989637          	lui	a2,0x989
    153c:	68060613          	addi	a2,a2,1664 # 989680 <__freertos_irq_stack_top+0x96bbe0>
    1540:	00040593          	mv	a1,s0
    1544:	00810513          	addi	a0,sp,8
    1548:	3cd050ef          	jal	7114 <bullet_prepare_texture_cache>
    154c:	00050593          	mv	a1,a0
    1550:	02c00637          	lui	a2,0x2c00
    1554:	00041463          	bnez	s0,155c <main+0xb4>
    1558:	02a00637          	lui	a2,0x2a00
    155c:	00143413          	seqz	s0,s0
    1560:	000016b7          	lui	a3,0x1
    1564:	0000d537          	lui	a0,0xd
    1568:	00040713          	mv	a4,s0
    156c:	c2068693          	addi	a3,a3,-992 # c20 <CUSTOM2+0xbc5>
    1570:	33850513          	addi	a0,a0,824 # d338 <_data+0x8c>
    1574:	084000ef          	jal	15f8 <bsp_printf>
    1578:	00010513          	mv	a0,sp
    157c:	78c010ef          	jal	2d08 <framebuffer_init>
    1580:	2cc020ef          	jal	384c <hud_init_glyph_atlas>
    1584:	2c8000ef          	jal	184c <gpu_platform_sync>
    1588:	f81007b7          	lui	a5,0xf8100
    158c:	3007a703          	lw	a4,768(a5) # f8100300 <__gpu_framebuffer_a+0xf6100300>
    1590:	4d4757b7          	lui	a5,0x4d475
    1594:	43178793          	addi	a5,a5,1073 # 4d475431 <__gpu_framebuffer_a+0x4b475431>
    1598:	02f71663          	bne	a4,a5,15c4 <main+0x11c>
    159c:	0000e7b7          	lui	a5,0xe
    15a0:	000136b7          	lui	a3,0x13
    15a4:	5a478793          	addi	a5,a5,1444 # e5a4 <hud_cache>
    15a8:	02d80737          	lui	a4,0x2d80
    15ac:	6d868693          	addi	a3,a3,1752 # 136d8 <scene>
    15b0:	00040613          	mv	a2,s0
    15b4:	00010593          	mv	a1,sp
    15b8:	00810513          	addi	a0,sp,8
    15bc:	504080ef          	jal	9ac0 <v3_demo_run>
    15c0:	f31ff06f          	j	14f0 <main+0x48>
    15c4:	0000d537          	lui	a0,0xd
    15c8:	37050513          	addi	a0,a0,880 # d370 <_data+0xc4>
    15cc:	02c000ef          	jal	15f8 <bsp_printf>
    15d0:	f1dff06f          	j	14ec <main+0x44>

000015d4 <_putchar>:
    15d4:	f80107b7          	lui	a5,0xf8010
    15d8:	00478793          	addi	a5,a5,4 # f8010004 <__gpu_framebuffer_a+0xf6010004>
    15dc:	0007a703          	lw	a4,0(a5)
    15e0:	01075693          	srli	a3,a4,0x10
    15e4:	0ff6f693          	zext.b	a3,a3
    15e8:	fe068ae3          	beqz	a3,15dc <_putchar+0x8>
    15ec:	f80107b7          	lui	a5,0xf8010
    15f0:	00a7a023          	sw	a0,0(a5) # f8010000 <__gpu_framebuffer_a+0xf6010000>
    15f4:	00008067          	ret

000015f8 <bsp_printf>:
    15f8:	f8010113          	addi	sp,sp,-128
    15fc:	06f12a23          	sw	a5,116(sp)
    1600:	06410793          	addi	a5,sp,100
    1604:	05212823          	sw	s2,80(sp)
    1608:	05312623          	sw	s3,76(sp)
    160c:	05412423          	sw	s4,72(sp)
    1610:	05512223          	sw	s5,68(sp)
    1614:	05612023          	sw	s6,64(sp)
    1618:	03712e23          	sw	s7,60(sp)
    161c:	04112e23          	sw	ra,92(sp)
    1620:	04812c23          	sw	s0,88(sp)
    1624:	04912a23          	sw	s1,84(sp)
    1628:	03812c23          	sw	s8,56(sp)
    162c:	03912a23          	sw	s9,52(sp)
    1630:	00050993          	mv	s3,a0
    1634:	06b12223          	sw	a1,100(sp)
    1638:	06c12423          	sw	a2,104(sp)
    163c:	06d12623          	sw	a3,108(sp)
    1640:	06e12823          	sw	a4,112(sp)
    1644:	07012c23          	sw	a6,120(sp)
    1648:	07112e23          	sw	a7,124(sp)
    164c:	00f12623          	sw	a5,12(sp)
    1650:	00000913          	li	s2,0
    1654:	02500a13          	li	s4,37
    1658:	06600a93          	li	s5,102
    165c:	06600b13          	li	s6,102
    1660:	06300b93          	li	s7,99
    1664:	012987b3          	add	a5,s3,s2
    1668:	0007c503          	lbu	a0,0(a5)
    166c:	02051c63          	bnez	a0,16a4 <bsp_printf+0xac>
    1670:	05c12083          	lw	ra,92(sp)
    1674:	05812403          	lw	s0,88(sp)
    1678:	05412483          	lw	s1,84(sp)
    167c:	05012903          	lw	s2,80(sp)
    1680:	04c12983          	lw	s3,76(sp)
    1684:	04812a03          	lw	s4,72(sp)
    1688:	04412a83          	lw	s5,68(sp)
    168c:	04012b03          	lw	s6,64(sp)
    1690:	03c12b83          	lw	s7,60(sp)
    1694:	03812c03          	lw	s8,56(sp)
    1698:	03412c83          	lw	s9,52(sp)
    169c:	08010113          	addi	sp,sp,128
    16a0:	00008067          	ret
    16a4:	0d451863          	bne	a0,s4,1774 <bsp_printf+0x17c>
    16a8:	00190913          	addi	s2,s2,1
    16ac:	012987b3          	add	a5,s3,s2
    16b0:	0007c783          	lbu	a5,0(a5)
    16b4:	0e078063          	beqz	a5,1794 <bsp_printf+0x19c>
    16b8:	17578263          	beq	a5,s5,181c <bsp_printf+0x224>
    16bc:	04fb6c63          	bltu	s6,a5,1714 <bsp_printf+0x11c>
    16c0:	0b778263          	beq	a5,s7,1764 <bsp_printf+0x16c>
    16c4:	06400713          	li	a4,100
    16c8:	0ee78063          	beq	a5,a4,17a8 <bsp_printf+0x1b0>
    16cc:	05800713          	li	a4,88
    16d0:	fce79ce3          	bne	a5,a4,16a8 <bsp_printf+0xb0>
    16d4:	00c12783          	lw	a5,12(sp)
    16d8:	0000d4b7          	lui	s1,0xd
    16dc:	01c00413          	li	s0,28
    16e0:	0007ac83          	lw	s9,0(a5)
    16e4:	00478713          	addi	a4,a5,4
    16e8:	00e12623          	sw	a4,12(sp)
    16ec:	2f848493          	addi	s1,s1,760 # d2f8 <_data+0x4c>
    16f0:	ffc00c13          	li	s8,-4
    16f4:	008cd7b3          	srl	a5,s9,s0
    16f8:	00f7f793          	andi	a5,a5,15
    16fc:	00f487b3          	add	a5,s1,a5
    1700:	0007c503          	lbu	a0,0(a5)
    1704:	ffc40413          	addi	s0,s0,-4
    1708:	ecdff0ef          	jal	15d4 <_putchar>
    170c:	ff8414e3          	bne	s0,s8,16f4 <bsp_printf+0xfc>
    1710:	0840006f          	j	1794 <bsp_printf+0x19c>
    1714:	07300713          	li	a4,115
    1718:	06e78263          	beq	a5,a4,177c <bsp_printf+0x184>
    171c:	07800713          	li	a4,120
    1720:	f8e794e3          	bne	a5,a4,16a8 <bsp_printf+0xb0>
    1724:	00c12783          	lw	a5,12(sp)
    1728:	0000d4b7          	lui	s1,0xd
    172c:	01c00413          	li	s0,28
    1730:	0007ac83          	lw	s9,0(a5)
    1734:	00478713          	addi	a4,a5,4
    1738:	00e12623          	sw	a4,12(sp)
    173c:	30c48493          	addi	s1,s1,780 # d30c <_data+0x60>
    1740:	ffc00c13          	li	s8,-4
    1744:	008cd7b3          	srl	a5,s9,s0
    1748:	00f7f793          	andi	a5,a5,15
    174c:	00f487b3          	add	a5,s1,a5
    1750:	0007c503          	lbu	a0,0(a5)
    1754:	ffc40413          	addi	s0,s0,-4
    1758:	e7dff0ef          	jal	15d4 <_putchar>
    175c:	ff8414e3          	bne	s0,s8,1744 <bsp_printf+0x14c>
    1760:	0340006f          	j	1794 <bsp_printf+0x19c>
    1764:	00c12783          	lw	a5,12(sp)
    1768:	0007c503          	lbu	a0,0(a5)
    176c:	00478713          	addi	a4,a5,4
    1770:	00e12623          	sw	a4,12(sp)
    1774:	e61ff0ef          	jal	15d4 <_putchar>
    1778:	01c0006f          	j	1794 <bsp_printf+0x19c>
    177c:	00c12783          	lw	a5,12(sp)
    1780:	0007a403          	lw	s0,0(a5)
    1784:	00478713          	addi	a4,a5,4
    1788:	00e12623          	sw	a4,12(sp)
    178c:	00044503          	lbu	a0,0(s0)
    1790:	00051663          	bnez	a0,179c <bsp_printf+0x1a4>
    1794:	00190913          	addi	s2,s2,1
    1798:	ecdff06f          	j	1664 <bsp_printf+0x6c>
    179c:	00140413          	addi	s0,s0,1
    17a0:	e35ff0ef          	jal	15d4 <_putchar>
    17a4:	fe9ff06f          	j	178c <bsp_printf+0x194>
    17a8:	00c12783          	lw	a5,12(sp)
    17ac:	0007a483          	lw	s1,0(a5)
    17b0:	00478713          	addi	a4,a5,4
    17b4:	00e12623          	sw	a4,12(sp)
    17b8:	0004d863          	bgez	s1,17c8 <bsp_printf+0x1d0>
    17bc:	02d00513          	li	a0,45
    17c0:	e15ff0ef          	jal	15d4 <_putchar>
    17c4:	409004b3          	neg	s1,s1
    17c8:	01010413          	addi	s0,sp,16
    17cc:	00040c13          	mv	s8,s0
    17d0:	00a00713          	li	a4,10
    17d4:	00049e63          	bnez	s1,17f0 <bsp_printf+0x1f8>
    17d8:	01840c63          	beq	s0,s8,17f0 <bsp_printf+0x1f8>
    17dc:	fff44503          	lbu	a0,-1(s0)
    17e0:	fff40413          	addi	s0,s0,-1
    17e4:	df1ff0ef          	jal	15d4 <_putchar>
    17e8:	ff841ae3          	bne	s0,s8,17dc <bsp_printf+0x1e4>
    17ec:	fa9ff06f          	j	1794 <bsp_printf+0x19c>
    17f0:	02e4e7b3          	rem	a5,s1,a4
    17f4:	00140413          	addi	s0,s0,1
    17f8:	03078793          	addi	a5,a5,48
    17fc:	02e4c4b3          	div	s1,s1,a4
    1800:	fef40fa3          	sb	a5,-1(s0)
    1804:	fd1ff06f          	j	17d4 <bsp_printf+0x1dc>
    1808:	00140413          	addi	s0,s0,1
    180c:	dc9ff0ef          	jal	15d4 <_putchar>
    1810:	00044503          	lbu	a0,0(s0)
    1814:	fe051ae3          	bnez	a0,1808 <bsp_printf+0x210>
    1818:	f7dff06f          	j	1794 <bsp_printf+0x19c>
    181c:	0000d437          	lui	s0,0xd
    1820:	2ac40413          	addi	s0,s0,684 # d2ac <_data>
    1824:	fedff06f          	j	1810 <bsp_printf+0x218>

00001828 <gpu_platform_cycles>:
    1828:	f8b0c7b7          	lui	a5,0xf8b0c
    182c:	f8b0c737          	lui	a4,0xf8b0c
    1830:	ffc78793          	addi	a5,a5,-4 # f8b0bffc <__gpu_framebuffer_a+0xf6b0bffc>
    1834:	ff870713          	addi	a4,a4,-8 # f8b0bff8 <__gpu_framebuffer_a+0xf6b0bff8>
    1838:	0007a583          	lw	a1,0(a5)
    183c:	00072503          	lw	a0,0(a4)
    1840:	0007a683          	lw	a3,0(a5)
    1844:	fed59ae3          	bne	a1,a3,1838 <gpu_platform_cycles+0x10>
    1848:	00008067          	ret

0000184c <gpu_platform_sync>:
    184c:	0ff0000f          	fence
    1850:	0000500f          	.word	0x0000500f
    1854:	0ff0000f          	fence
    1858:	00008067          	ret

0000185c <refresh>:
    185c:	00052703          	lw	a4,0(a0)
    1860:	00050793          	mv	a5,a0
    1864:	00300513          	li	a0,3
    1868:	03470813          	addi	a6,a4,52
    186c:	03870713          	addi	a4,a4,56
    1870:	00082583          	lw	a1,0(a6)
    1874:	00072603          	lw	a2,0(a4)
    1878:	00082683          	lw	a3,0(a6)
    187c:	01059593          	slli	a1,a1,0x10
    1880:	0105d593          	srli	a1,a1,0x10
    1884:	01069693          	slli	a3,a3,0x10
    1888:	0106d693          	srli	a3,a3,0x10
    188c:	02d59c63          	bne	a1,a3,18c4 <refresh+0x68>
    1890:	00c7d683          	lhu	a3,12(a5)
    1894:	0ff67613          	zext.b	a2,a2
    1898:	40d586b3          	sub	a3,a1,a3
    189c:	01069693          	slli	a3,a3,0x10
    18a0:	0106d693          	srli	a3,a3,0x10
    18a4:	04068863          	beqz	a3,18f4 <refresh+0x98>
    18a8:	0127c703          	lbu	a4,18(a5)
    18ac:	ffa00513          	li	a0,-6
    18b0:	02d76063          	bltu	a4,a3,18d0 <refresh+0x74>
    18b4:	00c789a3          	sb	a2,19(a5)
    18b8:	00060e63          	beqz	a2,18d4 <refresh+0x78>
    18bc:	ff900513          	li	a0,-7
    18c0:	00008067          	ret
    18c4:	fff50513          	addi	a0,a0,-1
    18c8:	fa0514e3          	bnez	a0,1870 <refresh+0x14>
    18cc:	ffa00513          	li	a0,-6
    18d0:	00008067          	ret
    18d4:	40d70733          	sub	a4,a4,a3
    18d8:	0ff77713          	zext.b	a4,a4
    18dc:	00e78923          	sb	a4,18(a5)
    18e0:	00e03733          	snez	a4,a4
    18e4:	00b79623          	sh	a1,12(a5)
    18e8:	00e788a3          	sb	a4,17(a5)
    18ec:	00000513          	li	a0,0
    18f0:	00008067          	ret
    18f4:	00c789a3          	sb	a2,19(a5)
    18f8:	fe060ae3          	beqz	a2,18ec <refresh+0x90>
    18fc:	fc1ff06f          	j	18bc <refresh+0x60>

00001900 <texture_cache_idle>:
    1900:	00050793          	mv	a5,a0
    1904:	04050263          	beqz	a0,1948 <texture_cache_idle+0x48>
    1908:	01054703          	lbu	a4,16(a0)
    190c:	ff800513          	li	a0,-8
    1910:	02070e63          	beqz	a4,194c <texture_cache_idle+0x4c>
    1914:	0127c703          	lbu	a4,18(a5)
    1918:	ffd00513          	li	a0,-3
    191c:	02071863          	bnez	a4,194c <texture_cache_idle+0x4c>
    1920:	0007a703          	lw	a4,0(a5)
    1924:	02000693          	li	a3,32
    1928:	00872783          	lw	a5,8(a4)
    192c:	0a07f793          	andi	a5,a5,160
    1930:	00d79e63          	bne	a5,a3,194c <texture_cache_idle+0x4c>
    1934:	09c72783          	lw	a5,156(a4)
    1938:	0027f793          	andi	a5,a5,2
    193c:	00079863          	bnez	a5,194c <texture_cache_idle+0x4c>
    1940:	00000513          	li	a0,0
    1944:	00008067          	ret
    1948:	ff800513          	li	a0,-8
    194c:	00008067          	ret

00001950 <surface>:
    1950:	00050713          	mv	a4,a0
    1954:	00200513          	li	a0,2
    1958:	06060463          	beqz	a2,19c0 <surface+0x70>
    195c:	06068663          	beqz	a3,19c8 <surface+0x78>
    1960:	00b767b3          	or	a5,a4,a1
    1964:	0017f793          	andi	a5,a5,1
    1968:	00300513          	li	a0,3
    196c:	04079e63          	bnez	a5,19c8 <surface+0x78>
    1970:	00161613          	slli	a2,a2,0x1
    1974:	00400513          	li	a0,4
    1978:	04c5e863          	bltu	a1,a2,19c8 <surface+0x78>
    197c:	fff68693          	addi	a3,a3,-1
    1980:	02b687b3          	mul	a5,a3,a1
    1984:	00500513          	li	a0,5
    1988:	02b6b6b3          	mulhu	a3,a3,a1
    198c:	00c78633          	add	a2,a5,a2
    1990:	00f637b3          	sltu	a5,a2,a5
    1994:	00d787b3          	add	a5,a5,a3
    1998:	00e606b3          	add	a3,a2,a4
    199c:	00c6b633          	sltu	a2,a3,a2
    19a0:	00f60633          	add	a2,a2,a5
    19a4:	020007b7          	lui	a5,0x2000
    19a8:	02f76063          	bltu	a4,a5,19c8 <surface+0x78>
    19ac:	00061c63          	bnez	a2,19c4 <surface+0x74>
    19b0:	100007b7          	lui	a5,0x10000
    19b4:	00d7e863          	bltu	a5,a3,19c4 <surface+0x74>
    19b8:	00000513          	li	a0,0
    19bc:	00008067          	ret
    19c0:	00008067          	ret
    19c4:	00500513          	li	a0,5
    19c8:	00008067          	ret

000019cc <gpu_init>:
    19cc:	0a050463          	beqz	a0,1a74 <gpu_init+0xa8>
    19d0:	ff010113          	addi	sp,sp,-16
    19d4:	00912223          	sw	s1,4(sp)
    19d8:	00112623          	sw	ra,12(sp)
    19dc:	00812423          	sw	s0,8(sp)
    19e0:	0035f713          	andi	a4,a1,3
    19e4:	00058493          	mv	s1,a1
    19e8:	ff800793          	li	a5,-8
    19ec:	06071863          	bnez	a4,1a5c <gpu_init+0x90>
    19f0:	01800613          	li	a2,24
    19f4:	00000593          	li	a1,0
    19f8:	00050413          	mv	s0,a0
    19fc:	82dff0ef          	jal	1228 <memset>
    1a00:	0004a683          	lw	a3,0(s1)
    1a04:	32444737          	lui	a4,0x32444
    1a08:	00942023          	sw	s1,0(s0)
    1a0c:	75070713          	addi	a4,a4,1872 # 32444750 <__gpu_framebuffer_a+0x30444750>
    1a10:	fff00793          	li	a5,-1
    1a14:	04e69463          	bne	a3,a4,1a5c <gpu_init+0x90>
    1a18:	0044a683          	lw	a3,4(s1)
    1a1c:	00010737          	lui	a4,0x10
    1a20:	10070713          	addi	a4,a4,256 # 10100 <__global_pointer$+0x1380>
    1a24:	ffe00793          	li	a5,-2
    1a28:	02e69a63          	bne	a3,a4,1a5c <gpu_init+0x90>
    1a2c:	0344a783          	lw	a5,52(s1)
    1a30:	01079793          	slli	a5,a5,0x10
    1a34:	0107d793          	srli	a5,a5,0x10
    1a38:	00f41623          	sh	a5,12(s0)
    1a3c:	00178793          	addi	a5,a5,1 # 10000001 <__gpu_framebuffer_a+0xe000001>
    1a40:	01079793          	slli	a5,a5,0x10
    1a44:	0107d793          	srli	a5,a5,0x10
    1a48:	00f41523          	sh	a5,10(s0)
    1a4c:	00f41423          	sh	a5,8(s0)
    1a50:	00100793          	li	a5,1
    1a54:	00f40823          	sb	a5,16(s0)
    1a58:	00000793          	li	a5,0
    1a5c:	00c12083          	lw	ra,12(sp)
    1a60:	00812403          	lw	s0,8(sp)
    1a64:	00412483          	lw	s1,4(sp)
    1a68:	00078513          	mv	a0,a5
    1a6c:	01010113          	addi	sp,sp,16
    1a70:	00008067          	ret
    1a74:	ff800793          	li	a5,-8
    1a78:	00078513          	mv	a0,a5
    1a7c:	00008067          	ret

00001a80 <gpu_try_submit>:
    1a80:	04051663          	bnez	a0,1acc <gpu_try_submit+0x4c>
    1a84:	ff800513          	li	a0,-8
    1a88:	00008067          	ret
    1a8c:	ff800513          	li	a0,-8
    1a90:	03c12083          	lw	ra,60(sp)
    1a94:	03812403          	lw	s0,56(sp)
    1a98:	03412483          	lw	s1,52(sp)
    1a9c:	03012903          	lw	s2,48(sp)
    1aa0:	02c12983          	lw	s3,44(sp)
    1aa4:	02812a03          	lw	s4,40(sp)
    1aa8:	02412a83          	lw	s5,36(sp)
    1aac:	02012b03          	lw	s6,32(sp)
    1ab0:	01c12b83          	lw	s7,28(sp)
    1ab4:	01812c03          	lw	s8,24(sp)
    1ab8:	01412c83          	lw	s9,20(sp)
    1abc:	01012d03          	lw	s10,16(sp)
    1ac0:	00c12d83          	lw	s11,12(sp)
    1ac4:	04010113          	addi	sp,sp,64
    1ac8:	00008067          	ret
    1acc:	fc010113          	addi	sp,sp,-64
    1ad0:	02912a23          	sw	s1,52(sp)
    1ad4:	02112e23          	sw	ra,60(sp)
    1ad8:	02812c23          	sw	s0,56(sp)
    1adc:	03212823          	sw	s2,48(sp)
    1ae0:	03312623          	sw	s3,44(sp)
    1ae4:	03412423          	sw	s4,40(sp)
    1ae8:	03512223          	sw	s5,36(sp)
    1aec:	03612023          	sw	s6,32(sp)
    1af0:	01712e23          	sw	s7,28(sp)
    1af4:	01812c23          	sw	s8,24(sp)
    1af8:	01912a23          	sw	s9,20(sp)
    1afc:	01a12823          	sw	s10,16(sp)
    1b00:	01b12623          	sw	s11,12(sp)
    1b04:	01054783          	lbu	a5,16(a0)
    1b08:	00050493          	mv	s1,a0
    1b0c:	f80780e3          	beqz	a5,1a8c <gpu_try_submit+0xc>
    1b10:	00060a13          	mv	s4,a2
    1b14:	f6060ce3          	beqz	a2,1a8c <gpu_try_submit+0xc>
    1b18:	00058413          	mv	s0,a1
    1b1c:	f60588e3          	beqz	a1,1a8c <gpu_try_submit+0xc>
    1b20:	01c5ca83          	lbu	s5,28(a1) # f810001c <__gpu_framebuffer_a+0xf610001c>
    1b24:	00700793          	li	a5,7
    1b28:	20fa9e63          	bne	s5,a5,1d44 <gpu_try_submit+0x2c4>
    1b2c:	0105dc83          	lhu	s9,16(a1)
    1b30:	00200513          	li	a0,2
    1b34:	f40c8ee3          	beqz	s9,1a90 <gpu_try_submit+0x10>
    1b38:	0125d983          	lhu	s3,18(a1)
    1b3c:	f4098ae3          	beqz	s3,1a90 <gpu_try_submit+0x10>
    1b40:	0145db83          	lhu	s7,20(a1)
    1b44:	f40b86e3          	beqz	s7,1a90 <gpu_try_submit+0x10>
    1b48:	01a5d903          	lhu	s2,26(a1)
    1b4c:	f40902e3          	beqz	s2,1a90 <gpu_try_submit+0x10>
    1b50:	0185d783          	lhu	a5,24(a1)
    1b54:	00a00513          	li	a0,10
    1b58:	fcc7f793          	andi	a5,a5,-52
    1b5c:	f2079ae3          	bnez	a5,1a90 <gpu_try_submit+0x10>
    1b60:	0005ab03          	lw	s6,0(a1)
    1b64:	0085ac03          	lw	s8,8(a1)
    1b68:	00090693          	mv	a3,s2
    1b6c:	000b8613          	mv	a2,s7
    1b70:	000c0593          	mv	a1,s8
    1b74:	000b0513          	mv	a0,s6
    1b78:	dd9ff0ef          	jal	1950 <surface>
    1b7c:	f0051ae3          	bnez	a0,1a90 <gpu_try_submit+0x10>
    1b80:	00442d03          	lw	s10,4(s0)
    1b84:	00c42d83          	lw	s11,12(s0)
    1b88:	00098693          	mv	a3,s3
    1b8c:	000c8613          	mv	a2,s9
    1b90:	000d8593          	mv	a1,s11
    1b94:	000d0513          	mv	a0,s10
    1b98:	db9ff0ef          	jal	1950 <surface>
    1b9c:	ee051ae3          	bnez	a0,1a90 <gpu_try_submit+0x10>
    1ba0:	fff98993          	addi	s3,s3,-1
    1ba4:	03b987b3          	mul	a5,s3,s11
    1ba8:	001c9c93          	slli	s9,s9,0x1
    1bac:	01ac8733          	add	a4,s9,s10
    1bb0:	01973cb3          	sltu	s9,a4,s9
    1bb4:	03b9b9b3          	mulhu	s3,s3,s11
    1bb8:	00e78733          	add	a4,a5,a4
    1bbc:	00f737b3          	sltu	a5,a4,a5
    1bc0:	019989b3          	add	s3,s3,s9
    1bc4:	013787b3          	add	a5,a5,s3
    1bc8:	00079463          	bnez	a5,1bd0 <gpu_try_submit+0x150>
    1bcc:	02eb7a63          	bgeu	s6,a4,1c00 <gpu_try_submit+0x180>
    1bd0:	fff90913          	addi	s2,s2,-1
    1bd4:	038907b3          	mul	a5,s2,s8
    1bd8:	001b9b93          	slli	s7,s7,0x1
    1bdc:	016b8b33          	add	s6,s7,s6
    1be0:	017b3bb3          	sltu	s7,s6,s7
    1be4:	03893933          	mulhu	s2,s2,s8
    1be8:	01678b33          	add	s6,a5,s6
    1bec:	00fb37b3          	sltu	a5,s6,a5
    1bf0:	01790933          	add	s2,s2,s7
    1bf4:	012787b3          	add	a5,a5,s2
    1bf8:	28079463          	bnez	a5,1e80 <gpu_try_submit+0x400>
    1bfc:	296d6263          	bltu	s10,s6,1e80 <gpu_try_submit+0x400>
    1c00:	0004a783          	lw	a5,0(s1)
    1c04:	ff900513          	li	a0,-7
    1c08:	0387a703          	lw	a4,56(a5)
    1c0c:	0ff77713          	zext.b	a4,a4
    1c10:	00e489a3          	sb	a4,19(s1)
    1c14:	e6071ee3          	bnez	a4,1a90 <gpu_try_submit+0x10>
    1c18:	0087a703          	lw	a4,8(a5)
    1c1c:	00700693          	li	a3,7
    1c20:	02da9063          	bne	s5,a3,1c40 <gpu_try_submit+0x1c0>
    1c24:	00e71693          	slli	a3,a4,0xe
    1c28:	e606d2e3          	bgez	a3,1a8c <gpu_try_submit+0xc>
    1c2c:	01845683          	lhu	a3,24(s0)
    1c30:	0206f693          	andi	a3,a3,32
    1c34:	00068663          	beqz	a3,1c40 <gpu_try_submit+0x1c0>
    1c38:	00d71693          	slli	a3,a4,0xd
    1c3c:	e406d8e3          	bgez	a3,1a8c <gpu_try_submit+0xc>
    1c40:	0144c603          	lbu	a2,20(s1)
    1c44:	01f77693          	andi	a3,a4,31
    1c48:	00d67463          	bgeu	a2,a3,1c50 <gpu_try_submit+0x1d0>
    1c4c:	00d48a23          	sb	a3,20(s1)
    1c50:	04077713          	andi	a4,a4,64
    1c54:	ffc00513          	li	a0,-4
    1c58:	e2071ce3          	bnez	a4,1a90 <gpu_try_submit+0x10>
    1c5c:	0124c683          	lbu	a3,18(s1)
    1c60:	00f00713          	li	a4,15
    1c64:	e2d766e3          	bltu	a4,a3,1a90 <gpu_try_submit+0x10>
    1c68:	00a4d683          	lhu	a3,10(s1)
    1c6c:	00000613          	li	a2,0
    1c70:	00168713          	addi	a4,a3,1
    1c74:	00e49523          	sh	a4,10(s1)
    1c78:	0157a823          	sw	s5,16(a5)
    1c7c:	00042703          	lw	a4,0(s0)
    1c80:	00e7aa23          	sw	a4,20(a5)
    1c84:	00442703          	lw	a4,4(s0)
    1c88:	00e7ac23          	sw	a4,24(a5)
    1c8c:	01042703          	lw	a4,16(s0)
    1c90:	00e7ae23          	sw	a4,28(a5)
    1c94:	00842703          	lw	a4,8(s0)
    1c98:	02e7a023          	sw	a4,32(a5)
    1c9c:	00c42703          	lw	a4,12(s0)
    1ca0:	02e7a223          	sw	a4,36(a5)
    1ca4:	00700713          	li	a4,7
    1ca8:	00ea8463          	beq	s5,a4,1cb0 <gpu_try_submit+0x230>
    1cac:	01445603          	lhu	a2,20(s0)
    1cb0:	01645703          	lhu	a4,22(s0)
    1cb4:	01071713          	slli	a4,a4,0x10
    1cb8:	00c76733          	or	a4,a4,a2
    1cbc:	02e7a423          	sw	a4,40(a5)
    1cc0:	01845703          	lhu	a4,24(s0)
    1cc4:	01d44603          	lbu	a2,29(s0)
    1cc8:	01071713          	slli	a4,a4,0x10
    1ccc:	00c76733          	or	a4,a4,a2
    1cd0:	02e7a623          	sw	a4,44(a5)
    1cd4:	00700713          	li	a4,7
    1cd8:	00ea9c63          	bne	s5,a4,1cf0 <gpu_try_submit+0x270>
    1cdc:	01a45703          	lhu	a4,26(s0)
    1ce0:	01445603          	lhu	a2,20(s0)
    1ce4:	01071713          	slli	a4,a4,0x10
    1ce8:	00c76733          	or	a4,a4,a2
    1cec:	0ae7a423          	sw	a4,168(a5)
    1cf0:	02d7a823          	sw	a3,48(a5)
    1cf4:	0ff0000f          	fence
    1cf8:	0004a783          	lw	a5,0(s1)
    1cfc:	00100713          	li	a4,1
    1d00:	00e7a623          	sw	a4,12(a5)
    1d04:	0ff0000f          	fence
    1d08:	0044a783          	lw	a5,4(s1)
    1d0c:	00e488a3          	sb	a4,17(s1)
    1d10:	0144c703          	lbu	a4,20(s1)
    1d14:	00178793          	addi	a5,a5,1
    1d18:	00f4a223          	sw	a5,4(s1)
    1d1c:	0124c783          	lbu	a5,18(s1)
    1d20:	00d49723          	sh	a3,14(s1)
    1d24:	00178793          	addi	a5,a5,1
    1d28:	0ff7f793          	zext.b	a5,a5
    1d2c:	00f48923          	sb	a5,18(s1)
    1d30:	00f77463          	bgeu	a4,a5,1d38 <gpu_try_submit+0x2b8>
    1d34:	00f48a23          	sb	a5,20(s1)
    1d38:	00da1023          	sh	a3,0(s4)
    1d3c:	00000513          	li	a0,0
    1d40:	d51ff06f          	j	1a90 <gpu_try_submit+0x10>
    1d44:	0185d783          	lhu	a5,24(a1)
    1d48:	d40792e3          	bnez	a5,1a8c <gpu_try_submit+0xc>
    1d4c:	00100793          	li	a5,1
    1d50:	02fa9063          	bne	s5,a5,1d70 <gpu_try_submit+0x2f0>
    1d54:	01245683          	lhu	a3,18(s0)
    1d58:	01045603          	lhu	a2,16(s0)
    1d5c:	00c42583          	lw	a1,12(s0)
    1d60:	00442503          	lw	a0,4(s0)
    1d64:	bedff0ef          	jal	1950 <surface>
    1d68:	e8050ce3          	beqz	a0,1c00 <gpu_try_submit+0x180>
    1d6c:	d25ff06f          	j	1a90 <gpu_try_submit+0x10>
    1d70:	00600793          	li	a5,6
    1d74:	02fa9263          	bne	s5,a5,1d98 <gpu_try_submit+0x318>
    1d78:	0045a783          	lw	a5,4(a1)
    1d7c:	ffe00737          	lui	a4,0xffe00
    1d80:	fff70713          	addi	a4,a4,-1 # ffdfffff <__gpu_framebuffer_a+0xfddfffff>
    1d84:	00e7f7b3          	and	a5,a5,a4
    1d88:	02000737          	lui	a4,0x2000
    1d8c:	00500513          	li	a0,5
    1d90:	d0e790e3          	bne	a5,a4,1a90 <gpu_try_submit+0x10>
    1d94:	e6dff06f          	j	1c00 <gpu_try_submit+0x180>
    1d98:	00500793          	li	a5,5
    1d9c:	02fa9863          	bne	s5,a5,1dcc <gpu_try_submit+0x34c>
    1da0:	0005a783          	lw	a5,0(a1)
    1da4:	00300513          	li	a0,3
    1da8:	0037f713          	andi	a4,a5,3
    1dac:	ce0712e3          	bnez	a4,1a90 <gpu_try_submit+0x10>
    1db0:	fe000737          	lui	a4,0xfe000
    1db4:	00e787b3          	add	a5,a5,a4
    1db8:	0e000737          	lui	a4,0xe000
    1dbc:	ffc70713          	addi	a4,a4,-4 # dfffffc <__gpu_framebuffer_a+0xbfffffc>
    1dc0:	00500513          	li	a0,5
    1dc4:	f8f778e3          	bgeu	a4,a5,1d54 <gpu_try_submit+0x2d4>
    1dc8:	cc9ff06f          	j	1a90 <gpu_try_submit+0x10>
    1dcc:	ffea8793          	addi	a5,s5,-2
    1dd0:	0ff7f793          	zext.b	a5,a5
    1dd4:	00200713          	li	a4,2
    1dd8:	00100513          	li	a0,1
    1ddc:	caf76ae3          	bltu	a4,a5,1a90 <gpu_try_submit+0x10>
    1de0:	0005ac03          	lw	s8,0(a1)
    1de4:	0105d903          	lhu	s2,16(a1)
    1de8:	0125d983          	lhu	s3,18(a1)
    1dec:	0085ab83          	lw	s7,8(a1)
    1df0:	00090613          	mv	a2,s2
    1df4:	00098693          	mv	a3,s3
    1df8:	000b8593          	mv	a1,s7
    1dfc:	000c0513          	mv	a0,s8
    1e00:	b51ff0ef          	jal	1950 <surface>
    1e04:	c80516e3          	bnez	a0,1a90 <gpu_try_submit+0x10>
    1e08:	00442c83          	lw	s9,4(s0)
    1e0c:	00c42b03          	lw	s6,12(s0)
    1e10:	00098693          	mv	a3,s3
    1e14:	00090613          	mv	a2,s2
    1e18:	000b0593          	mv	a1,s6
    1e1c:	000c8513          	mv	a0,s9
    1e20:	b31ff0ef          	jal	1950 <surface>
    1e24:	c60516e3          	bnez	a0,1a90 <gpu_try_submit+0x10>
    1e28:	fff98693          	addi	a3,s3,-1
    1e2c:	036687b3          	mul	a5,a3,s6
    1e30:	00191913          	slli	s2,s2,0x1
    1e34:	01990733          	add	a4,s2,s9
    1e38:	01273633          	sltu	a2,a4,s2
    1e3c:	0366bb33          	mulhu	s6,a3,s6
    1e40:	00e78733          	add	a4,a5,a4
    1e44:	00f737b3          	sltu	a5,a4,a5
    1e48:	00cb0b33          	add	s6,s6,a2
    1e4c:	016787b3          	add	a5,a5,s6
    1e50:	00079463          	bnez	a5,1e58 <gpu_try_submit+0x3d8>
    1e54:	daec76e3          	bgeu	s8,a4,1c00 <gpu_try_submit+0x180>
    1e58:	037687b3          	mul	a5,a3,s7
    1e5c:	012c0933          	add	s2,s8,s2
    1e60:	01893c33          	sltu	s8,s2,s8
    1e64:	0376b6b3          	mulhu	a3,a3,s7
    1e68:	01278933          	add	s2,a5,s2
    1e6c:	00f937b3          	sltu	a5,s2,a5
    1e70:	018686b3          	add	a3,a3,s8
    1e74:	00d787b3          	add	a5,a5,a3
    1e78:	00079463          	bnez	a5,1e80 <gpu_try_submit+0x400>
    1e7c:	d92cf2e3          	bgeu	s9,s2,1c00 <gpu_try_submit+0x180>
    1e80:	00600513          	li	a0,6
    1e84:	c0dff06f          	j	1a90 <gpu_try_submit+0x10>

00001e88 <gpu_submit>:
    1e88:	04051663          	bnez	a0,1ed4 <gpu_submit+0x4c>
    1e8c:	ff800513          	li	a0,-8
    1e90:	00008067          	ret
    1e94:	ff800513          	li	a0,-8
    1e98:	04c12083          	lw	ra,76(sp)
    1e9c:	04812403          	lw	s0,72(sp)
    1ea0:	04412483          	lw	s1,68(sp)
    1ea4:	04012903          	lw	s2,64(sp)
    1ea8:	03c12983          	lw	s3,60(sp)
    1eac:	03812a03          	lw	s4,56(sp)
    1eb0:	03412a83          	lw	s5,52(sp)
    1eb4:	03012b03          	lw	s6,48(sp)
    1eb8:	02c12b83          	lw	s7,44(sp)
    1ebc:	02812c03          	lw	s8,40(sp)
    1ec0:	02412c83          	lw	s9,36(sp)
    1ec4:	02012d03          	lw	s10,32(sp)
    1ec8:	01c12d83          	lw	s11,28(sp)
    1ecc:	05010113          	addi	sp,sp,80
    1ed0:	00008067          	ret
    1ed4:	fb010113          	addi	sp,sp,-80
    1ed8:	04912223          	sw	s1,68(sp)
    1edc:	04112623          	sw	ra,76(sp)
    1ee0:	04812423          	sw	s0,72(sp)
    1ee4:	05212023          	sw	s2,64(sp)
    1ee8:	03312e23          	sw	s3,60(sp)
    1eec:	03412c23          	sw	s4,56(sp)
    1ef0:	03512a23          	sw	s5,52(sp)
    1ef4:	03612823          	sw	s6,48(sp)
    1ef8:	03712623          	sw	s7,44(sp)
    1efc:	03812423          	sw	s8,40(sp)
    1f00:	03912223          	sw	s9,36(sp)
    1f04:	03a12023          	sw	s10,32(sp)
    1f08:	01b12e23          	sw	s11,28(sp)
    1f0c:	01054783          	lbu	a5,16(a0)
    1f10:	00050493          	mv	s1,a0
    1f14:	f80780e3          	beqz	a5,1e94 <gpu_submit+0xc>
    1f18:	00068a13          	mv	s4,a3
    1f1c:	f6068ce3          	beqz	a3,1e94 <gpu_submit+0xc>
    1f20:	00058413          	mv	s0,a1
    1f24:	f60588e3          	beqz	a1,1e94 <gpu_submit+0xc>
    1f28:	01c5c903          	lbu	s2,28(a1)
    1f2c:	00700793          	li	a5,7
    1f30:	00060993          	mv	s3,a2
    1f34:	20f91c63          	bne	s2,a5,214c <gpu_submit+0x2c4>
    1f38:	0105dd03          	lhu	s10,16(a1)
    1f3c:	00200513          	li	a0,2
    1f40:	f40d0ce3          	beqz	s10,1e98 <gpu_submit+0x10>
    1f44:	0125db03          	lhu	s6,18(a1)
    1f48:	f40b08e3          	beqz	s6,1e98 <gpu_submit+0x10>
    1f4c:	0145dc03          	lhu	s8,20(a1)
    1f50:	f40c04e3          	beqz	s8,1e98 <gpu_submit+0x10>
    1f54:	01a5da83          	lhu	s5,26(a1)
    1f58:	f40a80e3          	beqz	s5,1e98 <gpu_submit+0x10>
    1f5c:	0185d783          	lhu	a5,24(a1)
    1f60:	00a00513          	li	a0,10
    1f64:	fcc7f793          	andi	a5,a5,-52
    1f68:	f20798e3          	bnez	a5,1e98 <gpu_submit+0x10>
    1f6c:	0005ab83          	lw	s7,0(a1)
    1f70:	0085ac83          	lw	s9,8(a1)
    1f74:	000a8693          	mv	a3,s5
    1f78:	000c0613          	mv	a2,s8
    1f7c:	000c8593          	mv	a1,s9
    1f80:	000b8513          	mv	a0,s7
    1f84:	9cdff0ef          	jal	1950 <surface>
    1f88:	f00518e3          	bnez	a0,1e98 <gpu_submit+0x10>
    1f8c:	00442d83          	lw	s11,4(s0)
    1f90:	00c42583          	lw	a1,12(s0)
    1f94:	000b0693          	mv	a3,s6
    1f98:	000d0613          	mv	a2,s10
    1f9c:	000d8513          	mv	a0,s11
    1fa0:	00b12623          	sw	a1,12(sp)
    1fa4:	9adff0ef          	jal	1950 <surface>
    1fa8:	ee0518e3          	bnez	a0,1e98 <gpu_submit+0x10>
    1fac:	00c12583          	lw	a1,12(sp)
    1fb0:	fffb0b13          	addi	s6,s6,-1
    1fb4:	001d1d13          	slli	s10,s10,0x1
    1fb8:	02bb07b3          	mul	a5,s6,a1
    1fbc:	01bd0733          	add	a4,s10,s11
    1fc0:	01a73d33          	sltu	s10,a4,s10
    1fc4:	02bb3b33          	mulhu	s6,s6,a1
    1fc8:	00e78733          	add	a4,a5,a4
    1fcc:	00f737b3          	sltu	a5,a4,a5
    1fd0:	01ab0b33          	add	s6,s6,s10
    1fd4:	016787b3          	add	a5,a5,s6
    1fd8:	00079463          	bnez	a5,1fe0 <gpu_submit+0x158>
    1fdc:	02ebfa63          	bgeu	s7,a4,2010 <gpu_submit+0x188>
    1fe0:	fffa8a93          	addi	s5,s5,-1
    1fe4:	039a87b3          	mul	a5,s5,s9
    1fe8:	001c1c13          	slli	s8,s8,0x1
    1fec:	017c0bb3          	add	s7,s8,s7
    1ff0:	018bbc33          	sltu	s8,s7,s8
    1ff4:	039abab3          	mulhu	s5,s5,s9
    1ff8:	01778bb3          	add	s7,a5,s7
    1ffc:	00fbb7b3          	sltu	a5,s7,a5
    2000:	018a8ab3          	add	s5,s5,s8
    2004:	015787b3          	add	a5,a5,s5
    2008:	28079063          	bnez	a5,2288 <gpu_submit+0x400>
    200c:	277dee63          	bltu	s11,s7,2288 <gpu_submit+0x400>
    2010:	00700a93          	li	s5,7
    2014:	00f00b13          	li	s6,15
    2018:	0004a683          	lw	a3,0(s1)
    201c:	0386a783          	lw	a5,56(a3)
    2020:	0ff7f793          	zext.b	a5,a5
    2024:	00f489a3          	sb	a5,19(s1)
    2028:	28079063          	bnez	a5,22a8 <gpu_submit+0x420>
    202c:	0086a783          	lw	a5,8(a3)
    2030:	03591063          	bne	s2,s5,2050 <gpu_submit+0x1c8>
    2034:	00e79713          	slli	a4,a5,0xe
    2038:	e4075ee3          	bgez	a4,1e94 <gpu_submit+0xc>
    203c:	01845703          	lhu	a4,24(s0)
    2040:	02077713          	andi	a4,a4,32
    2044:	00070663          	beqz	a4,2050 <gpu_submit+0x1c8>
    2048:	00d79713          	slli	a4,a5,0xd
    204c:	e40754e3          	bgez	a4,1e94 <gpu_submit+0xc>
    2050:	0144c603          	lbu	a2,20(s1)
    2054:	01f7f713          	andi	a4,a5,31
    2058:	00e67463          	bgeu	a2,a4,2060 <gpu_submit+0x1d8>
    205c:	00e48a23          	sb	a4,20(s1)
    2060:	0407f793          	andi	a5,a5,64
    2064:	22079663          	bnez	a5,2290 <gpu_submit+0x408>
    2068:	0124c783          	lbu	a5,18(s1)
    206c:	22fb6263          	bltu	s6,a5,2290 <gpu_submit+0x408>
    2070:	00a4d603          	lhu	a2,10(s1)
    2074:	00000713          	li	a4,0
    2078:	00160793          	addi	a5,a2,1 # 2a00001 <__gpu_framebuffer_a+0xa00001>
    207c:	00f49523          	sh	a5,10(s1)
    2080:	0126a823          	sw	s2,16(a3)
    2084:	00042783          	lw	a5,0(s0)
    2088:	00f6aa23          	sw	a5,20(a3)
    208c:	00442783          	lw	a5,4(s0)
    2090:	00f6ac23          	sw	a5,24(a3)
    2094:	01042783          	lw	a5,16(s0)
    2098:	00f6ae23          	sw	a5,28(a3)
    209c:	00842783          	lw	a5,8(s0)
    20a0:	02f6a023          	sw	a5,32(a3)
    20a4:	00c42783          	lw	a5,12(s0)
    20a8:	02f6a223          	sw	a5,36(a3)
    20ac:	00700793          	li	a5,7
    20b0:	00f90463          	beq	s2,a5,20b8 <gpu_submit+0x230>
    20b4:	01445703          	lhu	a4,20(s0)
    20b8:	01645783          	lhu	a5,22(s0)
    20bc:	01079793          	slli	a5,a5,0x10
    20c0:	00e7e7b3          	or	a5,a5,a4
    20c4:	02f6a423          	sw	a5,40(a3)
    20c8:	01845783          	lhu	a5,24(s0)
    20cc:	01d44703          	lbu	a4,29(s0)
    20d0:	01079793          	slli	a5,a5,0x10
    20d4:	00e7e7b3          	or	a5,a5,a4
    20d8:	02f6a623          	sw	a5,44(a3)
    20dc:	00700793          	li	a5,7
    20e0:	00f91c63          	bne	s2,a5,20f8 <gpu_submit+0x270>
    20e4:	01a45783          	lhu	a5,26(s0)
    20e8:	01445703          	lhu	a4,20(s0)
    20ec:	01079793          	slli	a5,a5,0x10
    20f0:	00e7e7b3          	or	a5,a5,a4
    20f4:	0af6a423          	sw	a5,168(a3)
    20f8:	02c6a823          	sw	a2,48(a3)
    20fc:	0ff0000f          	fence
    2100:	0004a783          	lw	a5,0(s1)
    2104:	00100713          	li	a4,1
    2108:	00e7a623          	sw	a4,12(a5)
    210c:	0ff0000f          	fence
    2110:	0044a783          	lw	a5,4(s1)
    2114:	00e488a3          	sb	a4,17(s1)
    2118:	0144c703          	lbu	a4,20(s1)
    211c:	00178793          	addi	a5,a5,1
    2120:	00f4a223          	sw	a5,4(s1)
    2124:	0124c783          	lbu	a5,18(s1)
    2128:	00c49723          	sh	a2,14(s1)
    212c:	00178793          	addi	a5,a5,1
    2130:	0ff7f793          	zext.b	a5,a5
    2134:	00f48923          	sb	a5,18(s1)
    2138:	00f77463          	bgeu	a4,a5,2140 <gpu_submit+0x2b8>
    213c:	00f48a23          	sb	a5,20(s1)
    2140:	00ca1023          	sh	a2,0(s4)
    2144:	00000513          	li	a0,0
    2148:	d51ff06f          	j	1e98 <gpu_submit+0x10>
    214c:	0185d783          	lhu	a5,24(a1)
    2150:	d40792e3          	bnez	a5,1e94 <gpu_submit+0xc>
    2154:	00100793          	li	a5,1
    2158:	02f91063          	bne	s2,a5,2178 <gpu_submit+0x2f0>
    215c:	01245683          	lhu	a3,18(s0)
    2160:	01045603          	lhu	a2,16(s0)
    2164:	00c42583          	lw	a1,12(s0)
    2168:	00442503          	lw	a0,4(s0)
    216c:	fe4ff0ef          	jal	1950 <surface>
    2170:	d20514e3          	bnez	a0,1e98 <gpu_submit+0x10>
    2174:	e9dff06f          	j	2010 <gpu_submit+0x188>
    2178:	00600793          	li	a5,6
    217c:	02f91263          	bne	s2,a5,21a0 <gpu_submit+0x318>
    2180:	0045a783          	lw	a5,4(a1)
    2184:	ffe00737          	lui	a4,0xffe00
    2188:	fff70713          	addi	a4,a4,-1 # ffdfffff <__gpu_framebuffer_a+0xfddfffff>
    218c:	00e7f7b3          	and	a5,a5,a4
    2190:	02000737          	lui	a4,0x2000
    2194:	00500513          	li	a0,5
    2198:	d0e790e3          	bne	a5,a4,1e98 <gpu_submit+0x10>
    219c:	e75ff06f          	j	2010 <gpu_submit+0x188>
    21a0:	00500793          	li	a5,5
    21a4:	02f91863          	bne	s2,a5,21d4 <gpu_submit+0x34c>
    21a8:	0005a783          	lw	a5,0(a1)
    21ac:	00300513          	li	a0,3
    21b0:	0037f713          	andi	a4,a5,3
    21b4:	ce0712e3          	bnez	a4,1e98 <gpu_submit+0x10>
    21b8:	fe000737          	lui	a4,0xfe000
    21bc:	00e787b3          	add	a5,a5,a4
    21c0:	0e000737          	lui	a4,0xe000
    21c4:	ffc70713          	addi	a4,a4,-4 # dfffffc <__gpu_framebuffer_a+0xbfffffc>
    21c8:	00500513          	li	a0,5
    21cc:	f8f778e3          	bgeu	a4,a5,215c <gpu_submit+0x2d4>
    21d0:	cc9ff06f          	j	1e98 <gpu_submit+0x10>
    21d4:	ffe90793          	addi	a5,s2,-2
    21d8:	0ff7f793          	zext.b	a5,a5
    21dc:	00200713          	li	a4,2
    21e0:	00100513          	li	a0,1
    21e4:	caf76ae3          	bltu	a4,a5,1e98 <gpu_submit+0x10>
    21e8:	0005ac03          	lw	s8,0(a1)
    21ec:	0105dc83          	lhu	s9,16(a1)
    21f0:	0125dd03          	lhu	s10,18(a1)
    21f4:	0085aa83          	lw	s5,8(a1)
    21f8:	000c8613          	mv	a2,s9
    21fc:	000d0693          	mv	a3,s10
    2200:	000a8593          	mv	a1,s5
    2204:	000c0513          	mv	a0,s8
    2208:	f48ff0ef          	jal	1950 <surface>
    220c:	c80516e3          	bnez	a0,1e98 <gpu_submit+0x10>
    2210:	00442b83          	lw	s7,4(s0)
    2214:	00c42b03          	lw	s6,12(s0)
    2218:	000d0693          	mv	a3,s10
    221c:	000c8613          	mv	a2,s9
    2220:	000b0593          	mv	a1,s6
    2224:	000b8513          	mv	a0,s7
    2228:	f28ff0ef          	jal	1950 <surface>
    222c:	c60516e3          	bnez	a0,1e98 <gpu_submit+0x10>
    2230:	fffd0713          	addi	a4,s10,-1
    2234:	03670633          	mul	a2,a4,s6
    2238:	001c9793          	slli	a5,s9,0x1
    223c:	017786b3          	add	a3,a5,s7
    2240:	00f6b5b3          	sltu	a1,a3,a5
    2244:	03673b33          	mulhu	s6,a4,s6
    2248:	00c68633          	add	a2,a3,a2
    224c:	00d636b3          	sltu	a3,a2,a3
    2250:	016585b3          	add	a1,a1,s6
    2254:	00b686b3          	add	a3,a3,a1
    2258:	00069463          	bnez	a3,2260 <gpu_submit+0x3d8>
    225c:	dacc7ae3          	bgeu	s8,a2,2010 <gpu_submit+0x188>
    2260:	035706b3          	mul	a3,a4,s5
    2264:	00fc07b3          	add	a5,s8,a5
    2268:	0187b533          	sltu	a0,a5,s8
    226c:	03573733          	mulhu	a4,a4,s5
    2270:	00f687b3          	add	a5,a3,a5
    2274:	00d7b6b3          	sltu	a3,a5,a3
    2278:	00a70733          	add	a4,a4,a0
    227c:	00e686b3          	add	a3,a3,a4
    2280:	00069463          	bnez	a3,2288 <gpu_submit+0x400>
    2284:	d8fbf6e3          	bgeu	s7,a5,2010 <gpu_submit+0x188>
    2288:	00600513          	li	a0,6
    228c:	c0dff06f          	j	1e98 <gpu_submit+0x10>
    2290:	02098063          	beqz	s3,22b0 <gpu_submit+0x428>
    2294:	00048513          	mv	a0,s1
    2298:	dc4ff0ef          	jal	185c <refresh>
    229c:	fff98993          	addi	s3,s3,-1
    22a0:	d6050ce3          	beqz	a0,2018 <gpu_submit+0x190>
    22a4:	bf5ff06f          	j	1e98 <gpu_submit+0x10>
    22a8:	ff900513          	li	a0,-7
    22ac:	bedff06f          	j	1e98 <gpu_submit+0x10>
    22b0:	ffb00513          	li	a0,-5
    22b4:	be5ff06f          	j	1e98 <gpu_submit+0x10>

000022b8 <gpu_poll>:
    22b8:	08050863          	beqz	a0,2348 <gpu_poll+0x90>
    22bc:	ff010113          	addi	sp,sp,-16
    22c0:	00812423          	sw	s0,8(sp)
    22c4:	00112623          	sw	ra,12(sp)
    22c8:	00912223          	sw	s1,4(sp)
    22cc:	01054783          	lbu	a5,16(a0)
    22d0:	00050413          	mv	s0,a0
    22d4:	ff800513          	li	a0,-8
    22d8:	04078e63          	beqz	a5,2334 <gpu_poll+0x7c>
    22dc:	00442703          	lw	a4,4(s0)
    22e0:	ffa00513          	li	a0,-6
    22e4:	04070863          	beqz	a4,2334 <gpu_poll+0x7c>
    22e8:	000106b7          	lui	a3,0x10
    22ec:	00845783          	lhu	a5,8(s0)
    22f0:	00058493          	mv	s1,a1
    22f4:	00d77a63          	bgeu	a4,a3,2308 <gpu_poll+0x50>
    22f8:	40f587b3          	sub	a5,a1,a5
    22fc:	01079793          	slli	a5,a5,0x10
    2300:	0107d793          	srli	a5,a5,0x10
    2304:	02e7f863          	bgeu	a5,a4,2334 <gpu_poll+0x7c>
    2308:	00040513          	mv	a0,s0
    230c:	d50ff0ef          	jal	185c <refresh>
    2310:	02051263          	bnez	a0,2334 <gpu_poll+0x7c>
    2314:	01244783          	lbu	a5,18(s0)
    2318:	00078e63          	beqz	a5,2334 <gpu_poll+0x7c>
    231c:	00a45703          	lhu	a4,10(s0)
    2320:	40e78733          	sub	a4,a5,a4
    2324:	00e484b3          	add	s1,s1,a4
    2328:	01049493          	slli	s1,s1,0x10
    232c:	0104d493          	srli	s1,s1,0x10
    2330:	00f4b533          	sltu	a0,s1,a5
    2334:	00c12083          	lw	ra,12(sp)
    2338:	00812403          	lw	s0,8(sp)
    233c:	00412483          	lw	s1,4(sp)
    2340:	01010113          	addi	sp,sp,16
    2344:	00008067          	ret
    2348:	ff800513          	li	a0,-8
    234c:	00008067          	ret

00002350 <gpu_present_async>:
    2350:	fd010113          	addi	sp,sp,-48
    2354:	02812423          	sw	s0,40(sp)
    2358:	02912223          	sw	s1,36(sp)
    235c:	03212023          	sw	s2,32(sp)
    2360:	00050413          	mv	s0,a0
    2364:	00058913          	mv	s2,a1
    2368:	00060493          	mv	s1,a2
    236c:	00000593          	li	a1,0
    2370:	02000613          	li	a2,32
    2374:	00010513          	mv	a0,sp
    2378:	02112623          	sw	ra,44(sp)
    237c:	eadfe0ef          	jal	1228 <memset>
    2380:	00200793          	li	a5,2
    2384:	00f12623          	sw	a5,12(sp)
    2388:	000107b7          	lui	a5,0x10
    238c:	00178793          	addi	a5,a5,1 # 10001 <__global_pointer$+0x1281>
    2390:	00f12823          	sw	a5,16(sp)
    2394:	00048613          	mv	a2,s1
    2398:	00600793          	li	a5,6
    239c:	00010593          	mv	a1,sp
    23a0:	00040513          	mv	a0,s0
    23a4:	01212223          	sw	s2,4(sp)
    23a8:	00f10e23          	sb	a5,28(sp)
    23ac:	ed4ff0ef          	jal	1a80 <gpu_try_submit>
    23b0:	02c12083          	lw	ra,44(sp)
    23b4:	02812403          	lw	s0,40(sp)
    23b8:	02412483          	lw	s1,36(sp)
    23bc:	02012903          	lw	s2,32(sp)
    23c0:	03010113          	addi	sp,sp,48
    23c4:	00008067          	ret

000023c8 <gpu_wait_tag>:
    23c8:	0a050063          	beqz	a0,2468 <gpu_wait_tag+0xa0>
    23cc:	fe010113          	addi	sp,sp,-32
    23d0:	00812c23          	sw	s0,24(sp)
    23d4:	00112e23          	sw	ra,28(sp)
    23d8:	00912a23          	sw	s1,20(sp)
    23dc:	01212823          	sw	s2,16(sp)
    23e0:	01312623          	sw	s3,12(sp)
    23e4:	01054783          	lbu	a5,16(a0)
    23e8:	00050413          	mv	s0,a0
    23ec:	ff800513          	li	a0,-8
    23f0:	02078a63          	beqz	a5,2424 <gpu_wait_tag+0x5c>
    23f4:	00442703          	lw	a4,4(s0)
    23f8:	ffa00513          	li	a0,-6
    23fc:	02070463          	beqz	a4,2424 <gpu_wait_tag+0x5c>
    2400:	000106b7          	lui	a3,0x10
    2404:	00845783          	lhu	a5,8(s0)
    2408:	00058913          	mv	s2,a1
    240c:	00060493          	mv	s1,a2
    2410:	04d77863          	bgeu	a4,a3,2460 <gpu_wait_tag+0x98>
    2414:	40f587b3          	sub	a5,a1,a5
    2418:	01079793          	slli	a5,a5,0x10
    241c:	0107d793          	srli	a5,a5,0x10
    2420:	04e7e063          	bltu	a5,a4,2460 <gpu_wait_tag+0x98>
    2424:	01c12083          	lw	ra,28(sp)
    2428:	01812403          	lw	s0,24(sp)
    242c:	01412483          	lw	s1,20(sp)
    2430:	01012903          	lw	s2,16(sp)
    2434:	00c12983          	lw	s3,12(sp)
    2438:	02010113          	addi	sp,sp,32
    243c:	00008067          	ret
    2440:	00090593          	mv	a1,s2
    2444:	00040513          	mv	a0,s0
    2448:	e71ff0ef          	jal	22b8 <gpu_poll>
    244c:	fff48493          	addi	s1,s1,-1
    2450:	fd351ae3          	bne	a0,s3,2424 <gpu_wait_tag+0x5c>
    2454:	fe0496e3          	bnez	s1,2440 <gpu_wait_tag+0x78>
    2458:	ffb00513          	li	a0,-5
    245c:	fc9ff06f          	j	2424 <gpu_wait_tag+0x5c>
    2460:	00100993          	li	s3,1
    2464:	ff1ff06f          	j	2454 <gpu_wait_tag+0x8c>
    2468:	ff800513          	li	a0,-8
    246c:	00008067          	ret

00002470 <gpu_set_qos>:
    2470:	00050793          	mv	a5,a0
    2474:	04050463          	beqz	a0,24bc <gpu_set_qos+0x4c>
    2478:	01054703          	lbu	a4,16(a0)
    247c:	ff800513          	li	a0,-8
    2480:	04070063          	beqz	a4,24c0 <gpu_set_qos+0x50>
    2484:	02c5fe63          	bgeu	a1,a2,24c0 <gpu_set_qos+0x50>
    2488:	00001737          	lui	a4,0x1
    248c:	02e67a63          	bgeu	a2,a4,24c0 <gpu_set_qos+0x50>
    2490:	00100713          	li	a4,1
    2494:	02d76663          	bltu	a4,a3,24c0 <gpu_set_qos+0x50>
    2498:	0007a783          	lw	a5,0(a5)
    249c:	01061613          	slli	a2,a2,0x10
    24a0:	00b665b3          	or	a1,a2,a1
    24a4:	01f69693          	slli	a3,a3,0x1f
    24a8:	00d5e5b3          	or	a1,a1,a3
    24ac:	04b7a423          	sw	a1,72(a5)
    24b0:	0ff0000f          	fence
    24b4:	00000513          	li	a0,0
    24b8:	00008067          	ret
    24bc:	ff800513          	li	a0,-8
    24c0:	00008067          	ret

000024c4 <gpu_texture_cache_load>:
    24c4:	0e050663          	beqz	a0,25b0 <gpu_texture_cache_load+0xec>
    24c8:	fe010113          	addi	sp,sp,-32
    24cc:	00812c23          	sw	s0,24(sp)
    24d0:	00112e23          	sw	ra,28(sp)
    24d4:	00912a23          	sw	s1,20(sp)
    24d8:	01212823          	sw	s2,16(sp)
    24dc:	01312623          	sw	s3,12(sp)
    24e0:	01054703          	lbu	a4,16(a0)
    24e4:	00050413          	mv	s0,a0
    24e8:	ff800793          	li	a5,-8
    24ec:	06070c63          	beqz	a4,2564 <gpu_texture_cache_load+0xa0>
    24f0:	00001737          	lui	a4,0x1
    24f4:	00068993          	mv	s3,a3
    24f8:	ffc70713          	addi	a4,a4,-4 # ffc <CUSTOM2+0xfa1>
    24fc:	ffc60693          	addi	a3,a2,-4
    2500:	00060913          	mv	s2,a2
    2504:	06d76063          	bltu	a4,a3,2564 <gpu_texture_cache_load+0xa0>
    2508:	00c5e733          	or	a4,a1,a2
    250c:	00377713          	andi	a4,a4,3
    2510:	00058493          	mv	s1,a1
    2514:	04071863          	bnez	a4,2564 <gpu_texture_cache_load+0xa0>
    2518:	02400737          	lui	a4,0x2400
    251c:	04e5e463          	bltu	a1,a4,2564 <gpu_texture_cache_load+0xa0>
    2520:	00c587b3          	add	a5,a1,a2
    2524:	08b7ec63          	bltu	a5,a1,25bc <gpu_texture_cache_load+0xf8>
    2528:	10000737          	lui	a4,0x10000
    252c:	08f76863          	bltu	a4,a5,25bc <gpu_texture_cache_load+0xf8>
    2530:	bd0ff0ef          	jal	1900 <texture_cache_idle>
    2534:	00050793          	mv	a5,a0
    2538:	02051663          	bnez	a0,2564 <gpu_texture_cache_load+0xa0>
    253c:	00042703          	lw	a4,0(s0)
    2540:	08972823          	sw	s1,144(a4) # 10000090 <__gpu_framebuffer_a+0xe000090>
    2544:	09272a23          	sw	s2,148(a4)
    2548:	0ff0000f          	fence
    254c:	00042703          	lw	a4,0(s0)
    2550:	00100693          	li	a3,1
    2554:	08d72c23          	sw	a3,152(a4)
    2558:	0ff0000f          	fence
    255c:	02099463          	bnez	s3,2584 <gpu_texture_cache_load+0xc0>
    2560:	ffb00793          	li	a5,-5
    2564:	01c12083          	lw	ra,28(sp)
    2568:	01812403          	lw	s0,24(sp)
    256c:	01412483          	lw	s1,20(sp)
    2570:	01012903          	lw	s2,16(sp)
    2574:	00c12983          	lw	s3,12(sp)
    2578:	00078513          	mv	a0,a5
    257c:	02010113          	addi	sp,sp,32
    2580:	00008067          	ret
    2584:	00042703          	lw	a4,0(s0)
    2588:	09c72703          	lw	a4,156(a4)
    258c:	00477693          	andi	a3,a4,4
    2590:	00069c63          	bnez	a3,25a8 <gpu_texture_cache_load+0xe4>
    2594:	00277693          	andi	a3,a4,2
    2598:	fff98993          	addi	s3,s3,-1
    259c:	fc0690e3          	bnez	a3,255c <gpu_texture_cache_load+0x98>
    25a0:	00177713          	andi	a4,a4,1
    25a4:	fc0710e3          	bnez	a4,2564 <gpu_texture_cache_load+0xa0>
    25a8:	ff900793          	li	a5,-7
    25ac:	fb9ff06f          	j	2564 <gpu_texture_cache_load+0xa0>
    25b0:	ff800793          	li	a5,-8
    25b4:	00078513          	mv	a0,a5
    25b8:	00008067          	ret
    25bc:	ff800793          	li	a5,-8
    25c0:	fa5ff06f          	j	2564 <gpu_texture_cache_load+0xa0>

000025c4 <gpu_read_perf_snapshot>:
    25c4:	00050793          	mv	a5,a0
    25c8:	0c050063          	beqz	a0,2688 <gpu_read_perf_snapshot+0xc4>
    25cc:	01054703          	lbu	a4,16(a0)
    25d0:	ff800513          	li	a0,-8
    25d4:	0a070c63          	beqz	a4,268c <gpu_read_perf_snapshot+0xc8>
    25d8:	0a058a63          	beqz	a1,268c <gpu_read_perf_snapshot+0xc8>
    25dc:	0007a703          	lw	a4,0(a5)
    25e0:	00100693          	li	a3,1
    25e4:	04d72623          	sw	a3,76(a4)
    25e8:	0ff0000f          	fence
    25ec:	0007a783          	lw	a5,0(a5)
    25f0:	00000513          	li	a0,0
    25f4:	0507a683          	lw	a3,80(a5)
    25f8:	0547a703          	lw	a4,84(a5)
    25fc:	00d5a023          	sw	a3,0(a1)
    2600:	0587a683          	lw	a3,88(a5)
    2604:	00e5a223          	sw	a4,4(a1)
    2608:	05c7a703          	lw	a4,92(a5)
    260c:	00d5a423          	sw	a3,8(a1)
    2610:	0607a683          	lw	a3,96(a5)
    2614:	00e5a623          	sw	a4,12(a1)
    2618:	0647a703          	lw	a4,100(a5)
    261c:	00d5a823          	sw	a3,16(a1)
    2620:	0687a683          	lw	a3,104(a5)
    2624:	00e5aa23          	sw	a4,20(a1)
    2628:	06c7a703          	lw	a4,108(a5)
    262c:	00d5ac23          	sw	a3,24(a1)
    2630:	0707a683          	lw	a3,112(a5)
    2634:	00e5ae23          	sw	a4,28(a1)
    2638:	0747a703          	lw	a4,116(a5)
    263c:	02d5a023          	sw	a3,32(a1)
    2640:	0787a683          	lw	a3,120(a5)
    2644:	02e5a223          	sw	a4,36(a1)
    2648:	07c7a703          	lw	a4,124(a5)
    264c:	02d5a423          	sw	a3,40(a1)
    2650:	0807a683          	lw	a3,128(a5)
    2654:	02e5a623          	sw	a4,44(a1)
    2658:	0847a703          	lw	a4,132(a5)
    265c:	02d5a823          	sw	a3,48(a1)
    2660:	0887a683          	lw	a3,136(a5)
    2664:	02e5aa23          	sw	a4,52(a1)
    2668:	08c7a703          	lw	a4,140(a5)
    266c:	02d5ac23          	sw	a3,56(a1)
    2670:	02e5ae23          	sw	a4,60(a1)
    2674:	0a07a703          	lw	a4,160(a5)
    2678:	0a47a783          	lw	a5,164(a5)
    267c:	04e5a023          	sw	a4,64(a1)
    2680:	04f5a223          	sw	a5,68(a1)
    2684:	00008067          	ret
    2688:	ff800513          	li	a0,-8
    268c:	00008067          	ret

00002690 <blit_pair_validate>:
    2690:	fd010113          	addi	sp,sp,-48
    2694:	00a12623          	sw	a0,12(sp)
    2698:	02812623          	sw	s0,44(sp)
    269c:	02912423          	sw	s1,40(sp)
    26a0:	03212223          	sw	s2,36(sp)
    26a4:	00d12423          	sw	a3,8(sp)
    26a8:	00e11023          	sh	a4,0(sp)
    26ac:	00b11123          	sh	a1,2(sp)
    26b0:	00f11223          	sh	a5,4(sp)
    26b4:	00c11323          	sh	a2,6(sp)
    26b8:	00200513          	li	a0,2
    26bc:	10080263          	beqz	a6,27c0 <blit_pair_validate+0x130>
    26c0:	10088063          	beqz	a7,27c0 <blit_pair_validate+0x130>
    26c4:	00181413          	slli	s0,a6,0x1
    26c8:	00810293          	addi	t0,sp,8
    26cc:	01010f93          	addi	t6,sp,16
    26d0:	01810f13          	addi	t5,sp,24
    26d4:	00000e13          	li	t3,0
    26d8:	fff88493          	addi	s1,a7,-1
    26dc:	00200393          	li	t2,2
    26e0:	0002a303          	lw	t1,0(t0) # 12dc <memset+0xb4>
    26e4:	10030463          	beqz	t1,27ec <blit_pair_validate+0x15c>
    26e8:	00032703          	lw	a4,0(t1)
    26ec:	10070063          	beqz	a4,27ec <blit_pair_validate+0x15c>
    26f0:	00c32783          	lw	a5,12(t1)
    26f4:	00f76533          	or	a0,a4,a5
    26f8:	00157513          	andi	a0,a0,1
    26fc:	0e051063          	bnez	a0,27dc <blit_pair_validate+0x14c>
    2700:	00835583          	lhu	a1,8(t1)
    2704:	00159613          	slli	a2,a1,0x1
    2708:	0cc7ee63          	bltu	a5,a2,27e4 <blit_pair_validate+0x154>
    270c:	00a35683          	lhu	a3,10(t1)
    2710:	0c068e63          	beqz	a3,27ec <blit_pair_validate+0x15c>
    2714:	01c10eb3          	add	t4,sp,t3
    2718:	000ed903          	lhu	s2,0(t4)
    271c:	01090eb3          	add	t4,s2,a6
    2720:	0dd5e663          	bltu	a1,t4,27ec <blit_pair_validate+0x15c>
    2724:	00410593          	addi	a1,sp,4
    2728:	01c585b3          	add	a1,a1,t3
    272c:	0005de83          	lhu	t4,0(a1)
    2730:	01d885b3          	add	a1,a7,t4
    2734:	0ab6ec63          	bltu	a3,a1,27ec <blit_pair_validate+0x15c>
    2738:	fff68693          	addi	a3,a3,-1 # ffff <__global_pointer$+0x127f>
    273c:	02d785b3          	mul	a1,a5,a3
    2740:	02f6a6b3          	mulhsu	a3,a3,a5
    2744:	00c58633          	add	a2,a1,a2
    2748:	00b635b3          	sltu	a1,a2,a1
    274c:	00d585b3          	add	a1,a1,a3
    2750:	00432683          	lw	a3,4(t1)
    2754:	08059c63          	bnez	a1,27ec <blit_pair_validate+0x15c>
    2758:	08c6ea63          	bltu	a3,a2,27ec <blit_pair_validate+0x15c>
    275c:	fff74693          	not	a3,a4
    2760:	08c6e663          	bltu	a3,a2,27ec <blit_pair_validate+0x15c>
    2764:	03d78eb3          	mul	t4,a5,t4
    2768:	00191913          	slli	s2,s2,0x1
    276c:	01270733          	add	a4,a4,s2
    2770:	00428293          	addi	t0,t0,4
    2774:	004f8f93          	addi	t6,t6,4
    2778:	004f0f13          	addi	t5,t5,4
    277c:	02f487b3          	mul	a5,s1,a5
    2780:	01d70733          	add	a4,a4,t4
    2784:	feefae23          	sw	a4,-4(t6)
    2788:	008787b3          	add	a5,a5,s0
    278c:	00e787b3          	add	a5,a5,a4
    2790:	feff2e23          	sw	a5,-4(t5)
    2794:	047e1063          	bne	t3,t2,27d4 <blit_pair_validate+0x144>
    2798:	01012783          	lw	a5,16(sp)
    279c:	01c12683          	lw	a3,28(sp)
    27a0:	01412703          	lw	a4,20(sp)
    27a4:	00d7f663          	bgeu	a5,a3,27b0 <blit_pair_validate+0x120>
    27a8:	01812683          	lw	a3,24(sp)
    27ac:	04d76463          	bltu	a4,a3,27f4 <blit_pair_validate+0x164>
    27b0:	03012683          	lw	a3,48(sp)
    27b4:	00e6a023          	sw	a4,0(a3)
    27b8:	03412703          	lw	a4,52(sp)
    27bc:	00f72023          	sw	a5,0(a4)
    27c0:	02c12403          	lw	s0,44(sp)
    27c4:	02812483          	lw	s1,40(sp)
    27c8:	02412903          	lw	s2,36(sp)
    27cc:	03010113          	addi	sp,sp,48
    27d0:	00008067          	ret
    27d4:	00200e13          	li	t3,2
    27d8:	f09ff06f          	j	26e0 <blit_pair_validate+0x50>
    27dc:	00300513          	li	a0,3
    27e0:	fe1ff06f          	j	27c0 <blit_pair_validate+0x130>
    27e4:	00400513          	li	a0,4
    27e8:	fd9ff06f          	j	27c0 <blit_pair_validate+0x130>
    27ec:	00500513          	li	a0,5
    27f0:	fd1ff06f          	j	27c0 <blit_pair_validate+0x130>
    27f4:	00600513          	li	a0,6
    27f8:	fc9ff06f          	j	27c0 <blit_pair_validate+0x130>

000027fc <golden_fill>:
    27fc:	00050813          	mv	a6,a0
    2800:	0c050a63          	beqz	a0,28d4 <golden_fill+0xd8>
    2804:	00052883          	lw	a7,0(a0)
    2808:	00500513          	li	a0,5
    280c:	0c088663          	beqz	a7,28d8 <golden_fill+0xdc>
    2810:	00200513          	li	a0,2
    2814:	0c068263          	beqz	a3,28d8 <golden_fill+0xdc>
    2818:	0c070063          	beqz	a4,28d8 <golden_fill+0xdc>
    281c:	00885f03          	lhu	t5,8(a6)
    2820:	0a0f0c63          	beqz	t5,28d8 <golden_fill+0xdc>
    2824:	00a85e83          	lhu	t4,10(a6)
    2828:	0a0e8863          	beqz	t4,28d8 <golden_fill+0xdc>
    282c:	0018f893          	andi	a7,a7,1
    2830:	00300513          	li	a0,3
    2834:	0a089263          	bnez	a7,28d8 <golden_fill+0xdc>
    2838:	00c82303          	lw	t1,12(a6)
    283c:	00137513          	andi	a0,t1,1
    2840:	08051263          	bnez	a0,28c4 <golden_fill+0xc8>
    2844:	001f1e13          	slli	t3,t5,0x1
    2848:	09c36263          	bltu	t1,t3,28cc <golden_fill+0xd0>
    284c:	fffe8f93          	addi	t6,t4,-1
    2850:	03f308b3          	mul	a7,t1,t6
    2854:	026fa333          	mulhsu	t1,t6,t1
    2858:	01c88e33          	add	t3,a7,t3
    285c:	011e38b3          	sltu	a7,t3,a7
    2860:	006888b3          	add	a7,a7,t1
    2864:	00482303          	lw	t1,4(a6)
    2868:	06089663          	bnez	a7,28d4 <golden_fill+0xd8>
    286c:	07c36463          	bltu	t1,t3,28d4 <golden_fill+0xd8>
    2870:	00d588b3          	add	a7,a1,a3
    2874:	071f6063          	bltu	t5,a7,28d4 <golden_fill+0xd8>
    2878:	00c70733          	add	a4,a4,a2
    287c:	04eeec63          	bltu	t4,a4,28d4 <golden_fill+0xd8>
    2880:	00159593          	slli	a1,a1,0x1
    2884:	0087de13          	srli	t3,a5,0x8
    2888:	00e66463          	bltu	a2,a4,2890 <golden_fill+0x94>
    288c:	00008067          	ret
    2890:	00c82303          	lw	t1,12(a6)
    2894:	00082883          	lw	a7,0(a6)
    2898:	02660333          	mul	t1,a2,t1
    289c:	00b30333          	add	t1,t1,a1
    28a0:	006888b3          	add	a7,a7,t1
    28a4:	00000313          	li	t1,0
    28a8:	00f88023          	sb	a5,0(a7)
    28ac:	01c880a3          	sb	t3,1(a7)
    28b0:	00130313          	addi	t1,t1,1
    28b4:	00288893          	addi	a7,a7,2
    28b8:	fed368e3          	bltu	t1,a3,28a8 <golden_fill+0xac>
    28bc:	00160613          	addi	a2,a2,1
    28c0:	fc9ff06f          	j	2888 <golden_fill+0x8c>
    28c4:	00300513          	li	a0,3
    28c8:	00008067          	ret
    28cc:	00400513          	li	a0,4
    28d0:	00008067          	ret
    28d4:	00500513          	li	a0,5
    28d8:	00008067          	ret

000028dc <golden_copy>:
    28dc:	fc010113          	addi	sp,sp,-64
    28e0:	02812e23          	sw	s0,60(sp)
    28e4:	02912c23          	sw	s1,56(sp)
    28e8:	03212a23          	sw	s2,52(sp)
    28ec:	03312823          	sw	s3,48(sp)
    28f0:	03412623          	sw	s4,44(sp)
    28f4:	00d12423          	sw	a3,8(sp)
    28f8:	00a12623          	sw	a0,12(sp)
    28fc:	00e11023          	sh	a4,0(sp)
    2900:	00b11123          	sh	a1,2(sp)
    2904:	00f11223          	sh	a5,4(sp)
    2908:	00c11323          	sh	a2,6(sp)
    290c:	16080063          	beqz	a6,2a6c <golden_copy+0x190>
    2910:	00050e13          	mv	t3,a0
    2914:	00200513          	li	a0,2
    2918:	12088863          	beqz	a7,2a48 <golden_copy+0x16c>
    291c:	00181393          	slli	t2,a6,0x1
    2920:	00810293          	addi	t0,sp,8
    2924:	01010f93          	addi	t6,sp,16
    2928:	01810f13          	addi	t5,sp,24
    292c:	00000e93          	li	t4,0
    2930:	fff88493          	addi	s1,a7,-1
    2934:	00200413          	li	s0,2
    2938:	0002a903          	lw	s2,0(t0)
    293c:	14090463          	beqz	s2,2a84 <golden_copy+0x1a8>
    2940:	00092703          	lw	a4,0(s2)
    2944:	14070063          	beqz	a4,2a84 <golden_copy+0x1a8>
    2948:	00c92783          	lw	a5,12(s2)
    294c:	00f76533          	or	a0,a4,a5
    2950:	00157513          	andi	a0,a0,1
    2954:	12051063          	bnez	a0,2a74 <golden_copy+0x198>
    2958:	00895303          	lhu	t1,8(s2)
    295c:	00131593          	slli	a1,t1,0x1
    2960:	10b7ee63          	bltu	a5,a1,2a7c <golden_copy+0x1a0>
    2964:	00a95603          	lhu	a2,10(s2)
    2968:	10060e63          	beqz	a2,2a84 <golden_copy+0x1a8>
    296c:	01d109b3          	add	s3,sp,t4
    2970:	0009da03          	lhu	s4,0(s3)
    2974:	010a09b3          	add	s3,s4,a6
    2978:	11336663          	bltu	t1,s3,2a84 <golden_copy+0x1a8>
    297c:	00410313          	addi	t1,sp,4
    2980:	01d30333          	add	t1,t1,t4
    2984:	00035983          	lhu	s3,0(t1)
    2988:	01198333          	add	t1,s3,a7
    298c:	0e666c63          	bltu	a2,t1,2a84 <golden_copy+0x1a8>
    2990:	fff60613          	addi	a2,a2,-1
    2994:	02c78333          	mul	t1,a5,a2
    2998:	02f62633          	mulhsu	a2,a2,a5
    299c:	00b305b3          	add	a1,t1,a1
    29a0:	0065b333          	sltu	t1,a1,t1
    29a4:	00c30333          	add	t1,t1,a2
    29a8:	00492603          	lw	a2,4(s2)
    29ac:	0c031c63          	bnez	t1,2a84 <golden_copy+0x1a8>
    29b0:	0cb66a63          	bltu	a2,a1,2a84 <golden_copy+0x1a8>
    29b4:	fff74613          	not	a2,a4
    29b8:	0cb66663          	bltu	a2,a1,2a84 <golden_copy+0x1a8>
    29bc:	033789b3          	mul	s3,a5,s3
    29c0:	001a1a13          	slli	s4,s4,0x1
    29c4:	01470733          	add	a4,a4,s4
    29c8:	00428293          	addi	t0,t0,4
    29cc:	004f8f93          	addi	t6,t6,4
    29d0:	004f0f13          	addi	t5,t5,4
    29d4:	02f487b3          	mul	a5,s1,a5
    29d8:	01370733          	add	a4,a4,s3
    29dc:	feefae23          	sw	a4,-4(t6)
    29e0:	007787b3          	add	a5,a5,t2
    29e4:	00e787b3          	add	a5,a5,a4
    29e8:	feff2e23          	sw	a5,-4(t5)
    29ec:	068e9c63          	bne	t4,s0,2a64 <golden_copy+0x188>
    29f0:	01012803          	lw	a6,16(sp)
    29f4:	01c12783          	lw	a5,28(sp)
    29f8:	01412303          	lw	t1,20(sp)
    29fc:	00f87663          	bgeu	a6,a5,2a08 <golden_copy+0x12c>
    2a00:	01812783          	lw	a5,24(sp)
    2a04:	08f36463          	bltu	t1,a5,2a8c <golden_copy+0x1b0>
    2a08:	00000793          	li	a5,0
    2a0c:	00000713          	li	a4,0
    2a10:	00c6a583          	lw	a1,12(a3)
    2a14:	00e80633          	add	a2,a6,a4
    2a18:	02b785b3          	mul	a1,a5,a1
    2a1c:	00b60633          	add	a2,a2,a1
    2a20:	00ce2583          	lw	a1,12(t3)
    2a24:	00064e83          	lbu	t4,0(a2)
    2a28:	00670633          	add	a2,a4,t1
    2a2c:	02b785b3          	mul	a1,a5,a1
    2a30:	00170713          	addi	a4,a4,1
    2a34:	00b60633          	add	a2,a2,a1
    2a38:	01d60023          	sb	t4,0(a2)
    2a3c:	fc776ae3          	bltu	a4,t2,2a10 <golden_copy+0x134>
    2a40:	00178793          	addi	a5,a5,1
    2a44:	fcf894e3          	bne	a7,a5,2a0c <golden_copy+0x130>
    2a48:	03c12403          	lw	s0,60(sp)
    2a4c:	03812483          	lw	s1,56(sp)
    2a50:	03412903          	lw	s2,52(sp)
    2a54:	03012983          	lw	s3,48(sp)
    2a58:	02c12a03          	lw	s4,44(sp)
    2a5c:	04010113          	addi	sp,sp,64
    2a60:	00008067          	ret
    2a64:	00200e93          	li	t4,2
    2a68:	ed1ff06f          	j	2938 <golden_copy+0x5c>
    2a6c:	00200513          	li	a0,2
    2a70:	fd9ff06f          	j	2a48 <golden_copy+0x16c>
    2a74:	00300513          	li	a0,3
    2a78:	fd1ff06f          	j	2a48 <golden_copy+0x16c>
    2a7c:	00400513          	li	a0,4
    2a80:	fc9ff06f          	j	2a48 <golden_copy+0x16c>
    2a84:	00500513          	li	a0,5
    2a88:	fc1ff06f          	j	2a48 <golden_copy+0x16c>
    2a8c:	00600513          	li	a0,6
    2a90:	fb9ff06f          	j	2a48 <golden_copy+0x16c>

00002a94 <golden_color_key>:
    2a94:	fc010113          	addi	sp,sp,-64
    2a98:	01c10313          	addi	t1,sp,28
    2a9c:	00612223          	sw	t1,4(sp)
    2aa0:	01810313          	addi	t1,sp,24
    2aa4:	00612023          	sw	t1,0(sp)
    2aa8:	02812c23          	sw	s0,56(sp)
    2aac:	02912a23          	sw	s1,52(sp)
    2ab0:	03212823          	sw	s2,48(sp)
    2ab4:	03312623          	sw	s3,44(sp)
    2ab8:	03412423          	sw	s4,40(sp)
    2abc:	02112e23          	sw	ra,60(sp)
    2ac0:	04015a03          	lhu	s4,64(sp)
    2ac4:	00050493          	mv	s1,a0
    2ac8:	00068913          	mv	s2,a3
    2acc:	00080993          	mv	s3,a6
    2ad0:	00088413          	mv	s0,a7
    2ad4:	bbdff0ef          	jal	2690 <blit_pair_validate>
    2ad8:	00051a63          	bnez	a0,2aec <golden_color_key+0x58>
    2adc:	01c12803          	lw	a6,28(sp)
    2ae0:	01812883          	lw	a7,24(sp)
    2ae4:	00000713          	li	a4,0
    2ae8:	02876263          	bltu	a4,s0,2b0c <golden_color_key+0x78>
    2aec:	03c12083          	lw	ra,60(sp)
    2af0:	03812403          	lw	s0,56(sp)
    2af4:	03412483          	lw	s1,52(sp)
    2af8:	03012903          	lw	s2,48(sp)
    2afc:	02c12983          	lw	s3,44(sp)
    2b00:	02812a03          	lw	s4,40(sp)
    2b04:	04010113          	addi	sp,sp,64
    2b08:	00008067          	ret
    2b0c:	00c92603          	lw	a2,12(s2)
    2b10:	00c4a583          	lw	a1,12(s1)
    2b14:	00000693          	li	a3,0
    2b18:	02c70633          	mul	a2,a4,a2
    2b1c:	02b705b3          	mul	a1,a4,a1
    2b20:	01060633          	add	a2,a2,a6
    2b24:	011585b3          	add	a1,a1,a7
    2b28:	0136e663          	bltu	a3,s3,2b34 <golden_color_key+0xa0>
    2b2c:	00170713          	addi	a4,a4,1
    2b30:	fb9ff06f          	j	2ae8 <golden_color_key+0x54>
    2b34:	00169313          	slli	t1,a3,0x1
    2b38:	006607b3          	add	a5,a2,t1
    2b3c:	0007ce03          	lbu	t3,0(a5)
    2b40:	0017c783          	lbu	a5,1(a5)
    2b44:	00879793          	slli	a5,a5,0x8
    2b48:	01c7e7b3          	or	a5,a5,t3
    2b4c:	00fa0a63          	beq	s4,a5,2b60 <golden_color_key+0xcc>
    2b50:	00658333          	add	t1,a1,t1
    2b54:	00f30023          	sb	a5,0(t1)
    2b58:	0087d793          	srli	a5,a5,0x8
    2b5c:	00f300a3          	sb	a5,1(t1)
    2b60:	00168693          	addi	a3,a3,1
    2b64:	fc5ff06f          	j	2b28 <golden_color_key+0x94>

00002b68 <golden_alpha_blend>:
    2b68:	fb010113          	addi	sp,sp,-80
    2b6c:	01c10313          	addi	t1,sp,28
    2b70:	00612223          	sw	t1,4(sp)
    2b74:	01810313          	addi	t1,sp,24
    2b78:	00612023          	sw	t1,0(sp)
    2b7c:	04812423          	sw	s0,72(sp)
    2b80:	03312e23          	sw	s3,60(sp)
    2b84:	03412c23          	sw	s4,56(sp)
    2b88:	03512a23          	sw	s5,52(sp)
    2b8c:	03612823          	sw	s6,48(sp)
    2b90:	03712623          	sw	s7,44(sp)
    2b94:	03a12023          	sw	s10,32(sp)
    2b98:	05014b83          	lbu	s7,80(sp)
    2b9c:	04112623          	sw	ra,76(sp)
    2ba0:	04912223          	sw	s1,68(sp)
    2ba4:	05212023          	sw	s2,64(sp)
    2ba8:	03812423          	sw	s8,40(sp)
    2bac:	03912223          	sw	s9,36(sp)
    2bb0:	00050a13          	mv	s4,a0
    2bb4:	00068a93          	mv	s5,a3
    2bb8:	00080b13          	mv	s6,a6
    2bbc:	00088993          	mv	s3,a7
    2bc0:	ad1ff0ef          	jal	2690 <blit_pair_validate>
    2bc4:	00050d13          	mv	s10,a0
    2bc8:	00000413          	li	s0,0
    2bcc:	06050663          	beqz	a0,2c38 <golden_alpha_blend+0xd0>
    2bd0:	04c12083          	lw	ra,76(sp)
    2bd4:	04812403          	lw	s0,72(sp)
    2bd8:	04412483          	lw	s1,68(sp)
    2bdc:	04012903          	lw	s2,64(sp)
    2be0:	03c12983          	lw	s3,60(sp)
    2be4:	03812a03          	lw	s4,56(sp)
    2be8:	03412a83          	lw	s5,52(sp)
    2bec:	03012b03          	lw	s6,48(sp)
    2bf0:	02c12b83          	lw	s7,44(sp)
    2bf4:	02812c03          	lw	s8,40(sp)
    2bf8:	02412c83          	lw	s9,36(sp)
    2bfc:	000d0513          	mv	a0,s10
    2c00:	02012d03          	lw	s10,32(sp)
    2c04:	05010113          	addi	sp,sp,80
    2c08:	00008067          	ret
    2c0c:	00caa483          	lw	s1,12(s5)
    2c10:	00ca2903          	lw	s2,12(s4)
    2c14:	01c12783          	lw	a5,28(sp)
    2c18:	029404b3          	mul	s1,s0,s1
    2c1c:	00000c13          	li	s8,0
    2c20:	03240933          	mul	s2,s0,s2
    2c24:	00f484b3          	add	s1,s1,a5
    2c28:	01812783          	lw	a5,24(sp)
    2c2c:	00f90933          	add	s2,s2,a5
    2c30:	016c6863          	bltu	s8,s6,2c40 <golden_alpha_blend+0xd8>
    2c34:	00140413          	addi	s0,s0,1
    2c38:	fd346ae3          	bltu	s0,s3,2c0c <golden_alpha_blend+0xa4>
    2c3c:	f95ff06f          	j	2bd0 <golden_alpha_blend+0x68>
    2c40:	001c1793          	slli	a5,s8,0x1
    2c44:	00f90cb3          	add	s9,s2,a5
    2c48:	00f487b3          	add	a5,s1,a5
    2c4c:	0007c503          	lbu	a0,0(a5)
    2c50:	001cc703          	lbu	a4,1(s9)
    2c54:	0017c783          	lbu	a5,1(a5)
    2c58:	000cc583          	lbu	a1,0(s9)
    2c5c:	00871713          	slli	a4,a4,0x8
    2c60:	00879793          	slli	a5,a5,0x8
    2c64:	00a7e533          	or	a0,a5,a0
    2c68:	000b8613          	mv	a2,s7
    2c6c:	00b765b3          	or	a1,a4,a1
    2c70:	018000ef          	jal	2c88 <rgb565_global_alpha>
    2c74:	00855793          	srli	a5,a0,0x8
    2c78:	00ac8023          	sb	a0,0(s9)
    2c7c:	00fc80a3          	sb	a5,1(s9)
    2c80:	001c0c13          	addi	s8,s8,1
    2c84:	fadff06f          	j	2c30 <golden_alpha_blend+0xc8>

00002c88 <rgb565_global_alpha>:
    2c88:	0ff00693          	li	a3,255
    2c8c:	40c68833          	sub	a6,a3,a2
    2c90:	00b5d713          	srli	a4,a1,0xb
    2c94:	03070733          	mul	a4,a4,a6
    2c98:	00b55793          	srli	a5,a0,0xb
    2c9c:	01f57893          	andi	a7,a0,31
    2ca0:	00555513          	srli	a0,a0,0x5
    2ca4:	03f57513          	andi	a0,a0,63
    2ca8:	02c787b3          	mul	a5,a5,a2
    2cac:	07f70713          	addi	a4,a4,127
    2cb0:	00f70733          	add	a4,a4,a5
    2cb4:	01f5f793          	andi	a5,a1,31
    2cb8:	030787b3          	mul	a5,a5,a6
    2cbc:	02c888b3          	mul	a7,a7,a2
    2cc0:	07f78793          	addi	a5,a5,127
    2cc4:	02d75733          	divu	a4,a4,a3
    2cc8:	011787b3          	add	a5,a5,a7
    2ccc:	02d7d7b3          	divu	a5,a5,a3
    2cd0:	00b71713          	slli	a4,a4,0xb
    2cd4:	00f76733          	or	a4,a4,a5
    2cd8:	0055d793          	srli	a5,a1,0x5
    2cdc:	03f7f793          	andi	a5,a5,63
    2ce0:	030787b3          	mul	a5,a5,a6
    2ce4:	02c50633          	mul	a2,a0,a2
    2ce8:	07f78793          	addi	a5,a5,127
    2cec:	00c787b3          	add	a5,a5,a2
    2cf0:	02d7d7b3          	divu	a5,a5,a3
    2cf4:	00579793          	slli	a5,a5,0x5
    2cf8:	00f76533          	or	a0,a4,a5
    2cfc:	01051513          	slli	a0,a0,0x10
    2d00:	01055513          	srli	a0,a0,0x10
    2d04:	00008067          	ret

00002d08 <framebuffer_init>:
    2d08:	00050a63          	beqz	a0,2d1c <framebuffer_init+0x14>
    2d0c:	020007b7          	lui	a5,0x2000
    2d10:	00f52023          	sw	a5,0(a0)
    2d14:	022007b7          	lui	a5,0x2200
    2d18:	00f52223          	sw	a5,4(a0)
    2d1c:	00008067          	ret

00002d20 <framebuffer_present>:
    2d20:	06058863          	beqz	a1,2d90 <framebuffer_present+0x70>
    2d24:	fe010113          	addi	sp,sp,-32
    2d28:	00812c23          	sw	s0,24(sp)
    2d2c:	00058413          	mv	s0,a1
    2d30:	0045a583          	lw	a1,4(a1)
    2d34:	01212823          	sw	s2,16(sp)
    2d38:	00060913          	mv	s2,a2
    2d3c:	00e10613          	addi	a2,sp,14
    2d40:	00912a23          	sw	s1,20(sp)
    2d44:	00112e23          	sw	ra,28(sp)
    2d48:	00050493          	mv	s1,a0
    2d4c:	e04ff0ef          	jal	2350 <gpu_present_async>
    2d50:	02051463          	bnez	a0,2d78 <framebuffer_present+0x58>
    2d54:	00e15583          	lhu	a1,14(sp)
    2d58:	00090613          	mv	a2,s2
    2d5c:	00048513          	mv	a0,s1
    2d60:	e68ff0ef          	jal	23c8 <gpu_wait_tag>
    2d64:	00051a63          	bnez	a0,2d78 <framebuffer_present+0x58>
    2d68:	00042783          	lw	a5,0(s0)
    2d6c:	00442703          	lw	a4,4(s0)
    2d70:	00f42223          	sw	a5,4(s0)
    2d74:	00e42023          	sw	a4,0(s0)
    2d78:	01c12083          	lw	ra,28(sp)
    2d7c:	01812403          	lw	s0,24(sp)
    2d80:	01412483          	lw	s1,20(sp)
    2d84:	01012903          	lw	s2,16(sp)
    2d88:	02010113          	addi	sp,sp,32
    2d8c:	00008067          	ret
    2d90:	ff800513          	li	a0,-8
    2d94:	00008067          	ret

00002d98 <append_fill>:
    2d98:	fe010113          	addi	sp,sp,-32
    2d9c:	00812c23          	sw	s0,24(sp)
    2da0:	00068413          	mv	s0,a3
    2da4:	000086b7          	lui	a3,0x8
    2da8:	00d506b3          	add	a3,a0,a3
    2dac:	00912a23          	sw	s1,20(sp)
    2db0:	00070493          	mv	s1,a4
    2db4:	0006d703          	lhu	a4,0(a3) # 8000 <game_update_cached+0xd4>
    2db8:	01512223          	sw	s5,4(sp)
    2dbc:	00112e23          	sw	ra,28(sp)
    2dc0:	00078a93          	mv	s5,a5
    2dc4:	01212823          	sw	s2,16(sp)
    2dc8:	01312623          	sw	s3,12(sp)
    2dcc:	01412423          	sw	s4,8(sp)
    2dd0:	01612023          	sw	s6,0(sp)
    2dd4:	3ff00793          	li	a5,1023
    2dd8:	08e7e663          	bltu	a5,a4,2e64 <append_fill+0xcc>
    2ddc:	00060913          	mv	s2,a2
    2de0:	032484b3          	mul	s1,s1,s2
    2de4:	00170793          	addi	a5,a4,1
    2de8:	00571713          	slli	a4,a4,0x5
    2dec:	00e50733          	add	a4,a0,a4
    2df0:	00058b13          	mv	s6,a1
    2df4:	00f69023          	sh	a5,0(a3)
    2df8:	02000613          	li	a2,32
    2dfc:	00000593          	li	a1,0
    2e00:	00070513          	mv	a0,a4
    2e04:	00141413          	slli	s0,s0,0x1
    2e08:	00080a13          	mv	s4,a6
    2e0c:	00088993          	mv	s3,a7
    2e10:	01640433          	add	s0,s0,s6
    2e14:	c14fe0ef          	jal	1228 <memset>
    2e18:	00940433          	add	s0,s0,s1
    2e1c:	00100793          	li	a5,1
    2e20:	00852223          	sw	s0,4(a0)
    2e24:	01252623          	sw	s2,12(a0)
    2e28:	01551823          	sh	s5,16(a0)
    2e2c:	01451923          	sh	s4,18(a0)
    2e30:	01351a23          	sh	s3,20(a0)
    2e34:	00f50e23          	sb	a5,28(a0)
    2e38:	00000513          	li	a0,0
    2e3c:	01c12083          	lw	ra,28(sp)
    2e40:	01812403          	lw	s0,24(sp)
    2e44:	01412483          	lw	s1,20(sp)
    2e48:	01012903          	lw	s2,16(sp)
    2e4c:	00c12983          	lw	s3,12(sp)
    2e50:	00812a03          	lw	s4,8(sp)
    2e54:	00412a83          	lw	s5,4(sp)
    2e58:	00012b03          	lw	s6,0(sp)
    2e5c:	02010113          	addi	sp,sp,32
    2e60:	00008067          	ret
    2e64:	ffc00513          	li	a0,-4
    2e68:	fd5ff06f          	j	2e3c <append_fill+0xa4>

00002e6c <text>:
    2e6c:	0005c783          	lbu	a5,0(a1)
    2e70:	00079663          	bnez	a5,2e7c <text+0x10>
    2e74:	00050023          	sb	zero,0(a0)
    2e78:	00008067          	ret
    2e7c:	00150513          	addi	a0,a0,1
    2e80:	00158593          	addi	a1,a1,1
    2e84:	fef50fa3          	sb	a5,-1(a0)
    2e88:	fe5ff06f          	j	2e6c <text>

00002e8c <number>:
    2e8c:	ff010113          	addi	sp,sp,-16
    2e90:	00410713          	addi	a4,sp,4
    2e94:	00000793          	li	a5,0
    2e98:	00070813          	mv	a6,a4
    2e9c:	00a00613          	li	a2,10
    2ea0:	00900893          	li	a7,9
    2ea4:	02c5f6b3          	remu	a3,a1,a2
    2ea8:	00178793          	addi	a5,a5,1 # 2200001 <__gpu_framebuffer_a+0x200001>
    2eac:	00170713          	addi	a4,a4,1
    2eb0:	03068693          	addi	a3,a3,48
    2eb4:	fed70fa3          	sb	a3,-1(a4)
    2eb8:	00058693          	mv	a3,a1
    2ebc:	02c5d5b3          	divu	a1,a1,a2
    2ec0:	fed8e2e3          	bltu	a7,a3,2ea4 <number+0x18>
    2ec4:	00078713          	mv	a4,a5
    2ec8:	00050693          	mv	a3,a0
    2ecc:	fff70713          	addi	a4,a4,-1
    2ed0:	00e80633          	add	a2,a6,a4
    2ed4:	00064603          	lbu	a2,0(a2)
    2ed8:	00168693          	addi	a3,a3,1
    2edc:	fec68fa3          	sb	a2,-1(a3)
    2ee0:	fe0716e3          	bnez	a4,2ecc <number+0x40>
    2ee4:	00f50533          	add	a0,a0,a5
    2ee8:	00050023          	sb	zero,0(a0)
    2eec:	01010113          	addi	sp,sp,16
    2ef0:	00008067          	ret

00002ef4 <hud_set_logo_enabled>:
    2ef4:	00a03533          	snez	a0,a0
    2ef8:	82a18023          	sb	a0,-2016(gp) # e5a0 <logo_enabled>
    2efc:	00008067          	ret

00002f00 <hud_logo_fits>:
    2f00:	8201c703          	lbu	a4,-2016(gp) # e5a0 <logo_enabled>
    2f04:	00050793          	mv	a5,a0
    2f08:	00000513          	li	a0,0
    2f0c:	04070a63          	beqz	a4,2f60 <hud_logo_fits+0x60>
    2f10:	04078663          	beqz	a5,2f5c <hud_logo_fits+0x5c>
    2f14:	00078513          	mv	a0,a5
    2f18:	10078713          	addi	a4,a5,256
    2f1c:	04000693          	li	a3,64
    2f20:	00e00613          	li	a2,14
    2f24:	2f000593          	li	a1,752
    2f28:	00000793          	li	a5,0
    2f2c:	00c0006f          	j	2f38 <hud_logo_fits+0x38>
    2f30:	00178793          	addi	a5,a5,1
    2f34:	02d78863          	beq	a5,a3,2f64 <hud_logo_fits+0x64>
    2f38:	00f50833          	add	a6,a0,a5
    2f3c:	00084803          	lbu	a6,0(a6)
    2f40:	fe0818e3          	bnez	a6,2f30 <hud_logo_fits+0x30>
    2f44:	02c787b3          	mul	a5,a5,a2
    2f48:	00878793          	addi	a5,a5,8
    2f4c:	00f5ec63          	bltu	a1,a5,2f64 <hud_logo_fits+0x64>
    2f50:	04050513          	addi	a0,a0,64
    2f54:	fce51ae3          	bne	a0,a4,2f28 <hud_logo_fits+0x28>
    2f58:	00100513          	li	a0,1
    2f5c:	00008067          	ret
    2f60:	00008067          	ret
    2f64:	00000513          	li	a0,0
    2f68:	00008067          	ret

00002f6c <hud_comparison_text>:
    2f6c:	4e050463          	beqz	a0,3454 <hud_comparison_text+0x4e8>
    2f70:	f7010113          	addi	sp,sp,-144
    2f74:	08812423          	sw	s0,136(sp)
    2f78:	08912223          	sw	s1,132(sp)
    2f7c:	08112623          	sw	ra,140(sp)
    2f80:	09212023          	sw	s2,128(sp)
    2f84:	07312e23          	sw	s3,124(sp)
    2f88:	07412c23          	sw	s4,120(sp)
    2f8c:	07512a23          	sw	s5,116(sp)
    2f90:	07612823          	sw	s6,112(sp)
    2f94:	07712623          	sw	s7,108(sp)
    2f98:	07812423          	sw	s8,104(sp)
    2f9c:	07912223          	sw	s9,100(sp)
    2fa0:	07a12023          	sw	s10,96(sp)
    2fa4:	05b12e23          	sw	s11,92(sp)
    2fa8:	00050413          	mv	s0,a0
    2fac:	00058493          	mv	s1,a1
    2fb0:	ff800513          	li	a0,-8
    2fb4:	20058a63          	beqz	a1,31c8 <hud_comparison_text+0x25c>
    2fb8:	00042783          	lw	a5,0(s0)
    2fbc:	05f5ebb7          	lui	s7,0x5f5e
    2fc0:	000189b7          	lui	s3,0x18
    2fc4:	00f12e23          	sw	a5,28(sp)
    2fc8:	00442783          	lw	a5,4(s0)
    2fcc:	01c10b13          	addi	s6,sp,28
    2fd0:	02410a93          	addi	s5,sp,36
    2fd4:	02f12023          	sw	a5,32(sp)
    2fd8:	00842783          	lw	a5,8(s0)
    2fdc:	02c10a13          	addi	s4,sp,44
    2fe0:	00000913          	li	s2,0
    2fe4:	02f12223          	sw	a5,36(sp)
    2fe8:	00c42783          	lw	a5,12(s0)
    2fec:	0ffb8b93          	addi	s7,s7,255 # 5f5e0ff <__gpu_framebuffer_a+0x3f5e0ff>
    2ff0:	69f98993          	addi	s3,s3,1695 # 1869f <scene+0x4fc7>
    2ff4:	02f12423          	sw	a5,40(sp)
    2ff8:	01244783          	lbu	a5,18(s0)
    2ffc:	0000dc37          	lui	s8,0xd
    3000:	0000ddb7          	lui	s11,0xd
    3004:	02f12623          	sw	a5,44(sp)
    3008:	01344783          	lbu	a5,19(s0)
    300c:	02f12823          	sw	a5,48(sp)
    3010:	0000d7b7          	lui	a5,0xd
    3014:	3a478793          	addi	a5,a5,932 # d3a4 <_data+0xf8>
    3018:	00f12423          	sw	a5,8(sp)
    301c:	000aad03          	lw	s10,0(s5)
    3020:	01312223          	sw	s3,4(sp)
    3024:	000b2c83          	lw	s9,0(s6)
    3028:	01abe863          	bltu	s7,s10,3038 <hud_comparison_text+0xcc>
    302c:	3e800793          	li	a5,1000
    3030:	02fd57b3          	divu	a5,s10,a5
    3034:	00f12223          	sw	a5,4(sp)
    3038:	00691513          	slli	a0,s2,0x6
    303c:	00a48533          	add	a0,s1,a0
    3040:	1c090663          	beqz	s2,320c <hud_comparison_text+0x2a0>
    3044:	00812583          	lw	a1,8(sp)
    3048:	e25ff0ef          	jal	2e6c <text>
    304c:	000a2683          	lw	a3,0(s4)
    3050:	00050613          	mv	a2,a0
    3054:	1c068263          	beqz	a3,3218 <hud_comparison_text+0x2ac>
    3058:	000c8793          	mv	a5,s9
    305c:	0199f663          	bgeu	s3,s9,3068 <hud_comparison_text+0xfc>
    3060:	000187b7          	lui	a5,0x18
    3064:	69f78793          	addi	a5,a5,1695 # 1869f <scene+0x4fc7>
    3068:	00a00c93          	li	s9,10
    306c:	0397d5b3          	divu	a1,a5,s9
    3070:	00060513          	mv	a0,a2
    3074:	00f12623          	sw	a5,12(sp)
    3078:	e15ff0ef          	jal	2e8c <number>
    307c:	434c0593          	addi	a1,s8,1076 # d434 <_data+0x188>
    3080:	dedff0ef          	jal	2e6c <text>
    3084:	00c12783          	lw	a5,12(sp)
    3088:	0397f5b3          	remu	a1,a5,s9
    308c:	e01ff0ef          	jal	2e8c <number>
    3090:	438d8593          	addi	a1,s11,1080 # d438 <_data+0x18c>
    3094:	dd9ff0ef          	jal	2e6c <text>
    3098:	00412583          	lw	a1,4(sp)
    309c:	df1ff0ef          	jal	2e8c <number>
    30a0:	434c0593          	addi	a1,s8,1076
    30a4:	dc9ff0ef          	jal	2e6c <text>
    30a8:	06400793          	li	a5,100
    30ac:	02fd55b3          	divu	a1,s10,a5
    30b0:	0395f5b3          	remu	a1,a1,s9
    30b4:	dd9ff0ef          	jal	2e8c <number>
    30b8:	02091063          	bnez	s2,30d8 <hud_comparison_text+0x16c>
    30bc:	02a44783          	lbu	a5,42(s0)
    30c0:	00078c63          	beqz	a5,30d8 <hud_comparison_text+0x16c>
    30c4:	02b44783          	lbu	a5,43(s0)
    30c8:	00078863          	beqz	a5,30d8 <hud_comparison_text+0x16c>
    30cc:	0000d5b7          	lui	a1,0xd
    30d0:	44858593          	addi	a1,a1,1096 # d448 <_data+0x19c>
    30d4:	d99ff0ef          	jal	2e6c <text>
    30d8:	004b0b13          	addi	s6,s6,4
    30dc:	004a8a93          	addi	s5,s5,4
    30e0:	004a0a13          	addi	s4,s4,4
    30e4:	12090063          	beqz	s2,3204 <hud_comparison_text+0x298>
    30e8:	02a44703          	lbu	a4,42(s0)
    30ec:	00500793          	li	a5,5
    30f0:	08048513          	addi	a0,s1,128
    30f4:	0c048493          	addi	s1,s1,192
    30f8:	12f71663          	bne	a4,a5,3224 <hud_comparison_text+0x2b8>
    30fc:	0000d5b7          	lui	a1,0xd
    3100:	46458593          	addi	a1,a1,1124 # d464 <_data+0x1b8>
    3104:	d69ff0ef          	jal	2e6c <text>
    3108:	01045583          	lhu	a1,16(s0)
    310c:	d81ff0ef          	jal	2e8c <number>
    3110:	0000d5b7          	lui	a1,0xd
    3114:	47858593          	addi	a1,a1,1144 # d478 <_data+0x1cc>
    3118:	d55ff0ef          	jal	2e6c <text>
    311c:	02445583          	lhu	a1,36(s0)
    3120:	d6dff0ef          	jal	2e8c <number>
    3124:	0000d5b7          	lui	a1,0xd
    3128:	48058593          	addi	a1,a1,1152 # d480 <_data+0x1d4>
    312c:	d41ff0ef          	jal	2e6c <text>
    3130:	01045583          	lhu	a1,16(s0)
    3134:	d59ff0ef          	jal	2e8c <number>
    3138:	0000e5b7          	lui	a1,0xe
    313c:	01c00613          	li	a2,28
    3140:	c5058593          	addi	a1,a1,-944 # dc50 <comparison_letters+0xb8>
    3144:	03410513          	addi	a0,sp,52
    3148:	9bcfe0ef          	jal	1304 <memcpy>
    314c:	03244783          	lbu	a5,50(s0)
    3150:	00600713          	li	a4,6
    3154:	00f77463          	bgeu	a4,a5,315c <hud_comparison_text+0x1f0>
    3158:	00000793          	li	a5,0
    315c:	00279793          	slli	a5,a5,0x2
    3160:	01010713          	addi	a4,sp,16
    3164:	04078793          	addi	a5,a5,64
    3168:	00e787b3          	add	a5,a5,a4
    316c:	fe47a583          	lw	a1,-28(a5)
    3170:	00048513          	mv	a0,s1
    3174:	cf9ff0ef          	jal	2e6c <text>
    3178:	03244683          	lbu	a3,50(s0)
    317c:	00300713          	li	a4,3
    3180:	00050793          	mv	a5,a0
    3184:	00d76e63          	bltu	a4,a3,31a0 <hud_comparison_text+0x234>
    3188:	0000d5b7          	lui	a1,0xd
    318c:	48858593          	addi	a1,a1,1160 # d488 <_data+0x1dc>
    3190:	cddff0ef          	jal	2e6c <text>
    3194:	03045583          	lhu	a1,48(s0)
    3198:	cf5ff0ef          	jal	2e8c <number>
    319c:	00050793          	mv	a5,a0
    31a0:	0000d5b7          	lui	a1,0xd
    31a4:	48c58593          	addi	a1,a1,1164 # d48c <_data+0x1e0>
    31a8:	00078513          	mv	a0,a5
    31ac:	cc1ff0ef          	jal	2e6c <text>
    31b0:	02e45583          	lhu	a1,46(s0)
    31b4:	cd9ff0ef          	jal	2e8c <number>
    31b8:	0000d5b7          	lui	a1,0xd
    31bc:	49458593          	addi	a1,a1,1172 # d494 <_data+0x1e8>
    31c0:	cadff0ef          	jal	2e6c <text>
    31c4:	00000513          	li	a0,0
    31c8:	08c12083          	lw	ra,140(sp)
    31cc:	08812403          	lw	s0,136(sp)
    31d0:	08412483          	lw	s1,132(sp)
    31d4:	08012903          	lw	s2,128(sp)
    31d8:	07c12983          	lw	s3,124(sp)
    31dc:	07812a03          	lw	s4,120(sp)
    31e0:	07412a83          	lw	s5,116(sp)
    31e4:	07012b03          	lw	s6,112(sp)
    31e8:	06c12b83          	lw	s7,108(sp)
    31ec:	06812c03          	lw	s8,104(sp)
    31f0:	06412c83          	lw	s9,100(sp)
    31f4:	06012d03          	lw	s10,96(sp)
    31f8:	05c12d83          	lw	s11,92(sp)
    31fc:	09010113          	addi	sp,sp,144
    3200:	00008067          	ret
    3204:	00100913          	li	s2,1
    3208:	e15ff06f          	j	301c <hud_comparison_text+0xb0>
    320c:	0000d5b7          	lui	a1,0xd
    3210:	3b058593          	addi	a1,a1,944 # d3b0 <_data+0x104>
    3214:	e35ff06f          	j	3048 <hud_comparison_text+0xdc>
    3218:	0000d7b7          	lui	a5,0xd
    321c:	45078593          	addi	a1,a5,1104 # d450 <_data+0x1a4>
    3220:	eb5ff06f          	j	30d4 <hud_comparison_text+0x168>
    3224:	01444783          	lbu	a5,20(s0)
    3228:	0a078e63          	beqz	a5,32e4 <hud_comparison_text+0x378>
    322c:	0000d5b7          	lui	a1,0xd
    3230:	3bc58593          	addi	a1,a1,956 # d3bc <_data+0x110>
    3234:	c39ff0ef          	jal	2e6c <text>
    3238:	02a44783          	lbu	a5,42(s0)
    323c:	02078063          	beqz	a5,325c <hud_comparison_text+0x2f0>
    3240:	00400713          	li	a4,4
    3244:	0ae78663          	beq	a5,a4,32f0 <hud_comparison_text+0x384>
    3248:	00100713          	li	a4,1
    324c:	0ae79863          	bne	a5,a4,32fc <hud_comparison_text+0x390>
    3250:	0000d5b7          	lui	a1,0xd
    3254:	3e458593          	addi	a1,a1,996 # d3e4 <_data+0x138>
    3258:	c15ff0ef          	jal	2e6c <text>
    325c:	01644783          	lbu	a5,22(s0)
    3260:	0a078463          	beqz	a5,3308 <hud_comparison_text+0x39c>
    3264:	0000d5b7          	lui	a1,0xd
    3268:	3ec58593          	addi	a1,a1,1004 # d3ec <_data+0x140>
    326c:	c01ff0ef          	jal	2e6c <text>
    3270:	01045583          	lhu	a1,16(s0)
    3274:	c19ff0ef          	jal	2e8c <number>
    3278:	01644703          	lbu	a4,22(s0)
    327c:	00050793          	mv	a5,a0
    3280:	02070263          	beqz	a4,32a4 <hud_comparison_text+0x338>
    3284:	02644703          	lbu	a4,38(s0)
    3288:	00070e63          	beqz	a4,32a4 <hud_comparison_text+0x338>
    328c:	0000d5b7          	lui	a1,0xd
    3290:	47858593          	addi	a1,a1,1144 # d478 <_data+0x1cc>
    3294:	bd9ff0ef          	jal	2e6c <text>
    3298:	02445583          	lhu	a1,36(s0)
    329c:	bf1ff0ef          	jal	2e8c <number>
    32a0:	00050793          	mv	a5,a0
    32a4:	0000d5b7          	lui	a1,0xd
    32a8:	00078513          	mv	a0,a5
    32ac:	4a858593          	addi	a1,a1,1192 # d4a8 <_data+0x1fc>
    32b0:	bbdff0ef          	jal	2e6c <text>
    32b4:	01544783          	lbu	a5,21(s0)
    32b8:	04078e63          	beqz	a5,3314 <hud_comparison_text+0x3a8>
    32bc:	0000e5b7          	lui	a1,0xe
    32c0:	a3858593          	addi	a1,a1,-1480 # da38 <_data+0x78c>
    32c4:	ba9ff0ef          	jal	2e6c <text>
    32c8:	02a44703          	lbu	a4,42(s0)
    32cc:	00400793          	li	a5,4
    32d0:	04f71863          	bne	a4,a5,3320 <hud_comparison_text+0x3b4>
    32d4:	0000d5b7          	lui	a1,0xd
    32d8:	4b058593          	addi	a1,a1,1200 # d4b0 <_data+0x204>
    32dc:	00048513          	mv	a0,s1
    32e0:	ee1ff06f          	j	31c0 <hud_comparison_text+0x254>
    32e4:	0000d5b7          	lui	a1,0xd
    32e8:	3c858593          	addi	a1,a1,968 # d3c8 <_data+0x11c>
    32ec:	f49ff06f          	j	3234 <hud_comparison_text+0x2c8>
    32f0:	0000d5b7          	lui	a1,0xd
    32f4:	3dc58593          	addi	a1,a1,988 # d3dc <_data+0x130>
    32f8:	f61ff06f          	j	3258 <hud_comparison_text+0x2ec>
    32fc:	0000d5b7          	lui	a1,0xd
    3300:	3d458593          	addi	a1,a1,980 # d3d4 <_data+0x128>
    3304:	f55ff06f          	j	3258 <hud_comparison_text+0x2ec>
    3308:	0000d5b7          	lui	a1,0xd
    330c:	3f858593          	addi	a1,a1,1016 # d3f8 <_data+0x14c>
    3310:	f5dff06f          	j	326c <hud_comparison_text+0x300>
    3314:	0000d5b7          	lui	a1,0xd
    3318:	3fc58593          	addi	a1,a1,1020 # d3fc <_data+0x150>
    331c:	fa9ff06f          	j	32c4 <hud_comparison_text+0x358>
    3320:	01644783          	lbu	a5,22(s0)
    3324:	12078263          	beqz	a5,3448 <hud_comparison_text+0x4dc>
    3328:	02644783          	lbu	a5,38(s0)
    332c:	0000d937          	lui	s2,0xd
    3330:	0e078263          	beqz	a5,3414 <hud_comparison_text+0x4a8>
    3334:	0000d5b7          	lui	a1,0xd
    3338:	4dc58593          	addi	a1,a1,1244 # d4dc <_data+0x230>
    333c:	00048513          	mv	a0,s1
    3340:	b2dff0ef          	jal	2e6c <text>
    3344:	02744583          	lbu	a1,39(s0)
    3348:	b45ff0ef          	jal	2e8c <number>
    334c:	0000d5b7          	lui	a1,0xd
    3350:	4e058593          	addi	a1,a1,1248 # d4e0 <_data+0x234>
    3354:	b19ff0ef          	jal	2e6c <text>
    3358:	01c42583          	lw	a1,28(s0)
    335c:	000f47b7          	lui	a5,0xf4
    3360:	23f78793          	addi	a5,a5,575 # f423f <__freertos_irq_stack_top+0xd679f>
    3364:	00b7f463          	bgeu	a5,a1,336c <hud_comparison_text+0x400>
    3368:	00078593          	mv	a1,a5
    336c:	b21ff0ef          	jal	2e8c <number>
    3370:	0000d5b7          	lui	a1,0xd
    3374:	4e858593          	addi	a1,a1,1256 # d4e8 <_data+0x23c>
    3378:	af5ff0ef          	jal	2e6c <text>
    337c:	02042583          	lw	a1,32(s0)
    3380:	000027b7          	lui	a5,0x2
    3384:	70f78793          	addi	a5,a5,1807 # 270f <blit_pair_validate+0x7f>
    3388:	00b7f463          	bgeu	a5,a1,3390 <hud_comparison_text+0x424>
    338c:	00078593          	mv	a1,a5
    3390:	afdff0ef          	jal	2e8c <number>
    3394:	0000d5b7          	lui	a1,0xd
    3398:	4f058593          	addi	a1,a1,1264 # d4f0 <_data+0x244>
    339c:	ad1ff0ef          	jal	2e6c <text>
    33a0:	01842583          	lw	a1,24(s0)
    33a4:	ae9ff0ef          	jal	2e8c <number>
    33a8:	4f890593          	addi	a1,s2,1272 # d4f8 <_data+0x24c>
    33ac:	ac1ff0ef          	jal	2e6c <text>
    33b0:	01744583          	lbu	a1,23(s0)
    33b4:	ad9ff0ef          	jal	2e8c <number>
    33b8:	02944783          	lbu	a5,41(s0)
    33bc:	02079463          	bnez	a5,33e4 <hud_comparison_text+0x478>
    33c0:	02844783          	lbu	a5,40(s0)
    33c4:	02079663          	bnez	a5,33f0 <hud_comparison_text+0x484>
    33c8:	02a44783          	lbu	a5,42(s0)
    33cc:	02078863          	beqz	a5,33fc <hud_comparison_text+0x490>
    33d0:	02c44783          	lbu	a5,44(s0)
    33d4:	02078a63          	beqz	a5,3408 <hud_comparison_text+0x49c>
    33d8:	0000d5b7          	lui	a1,0xd
    33dc:	42c58593          	addi	a1,a1,1068 # d42c <_data+0x180>
    33e0:	de1ff06f          	j	31c0 <hud_comparison_text+0x254>
    33e4:	0000d5b7          	lui	a1,0xd
    33e8:	41458593          	addi	a1,a1,1044 # d414 <_data+0x168>
    33ec:	dd5ff06f          	j	31c0 <hud_comparison_text+0x254>
    33f0:	0000d5b7          	lui	a1,0xd
    33f4:	40c58593          	addi	a1,a1,1036 # d40c <_data+0x160>
    33f8:	dc9ff06f          	j	31c0 <hud_comparison_text+0x254>
    33fc:	0000d5b7          	lui	a1,0xd
    3400:	41c58593          	addi	a1,a1,1052 # d41c <_data+0x170>
    3404:	dbdff06f          	j	31c0 <hud_comparison_text+0x254>
    3408:	0000d5b7          	lui	a1,0xd
    340c:	42458593          	addi	a1,a1,1060 # d424 <_data+0x178>
    3410:	db1ff06f          	j	31c0 <hud_comparison_text+0x254>
    3414:	0000d5b7          	lui	a1,0xd
    3418:	50058593          	addi	a1,a1,1280 # d500 <_data+0x254>
    341c:	00048513          	mv	a0,s1
    3420:	a4dff0ef          	jal	2e6c <text>
    3424:	01842583          	lw	a1,24(s0)
    3428:	a65ff0ef          	jal	2e8c <number>
    342c:	4f890593          	addi	a1,s2,1272
    3430:	a3dff0ef          	jal	2e6c <text>
    3434:	01744583          	lbu	a1,23(s0)
    3438:	a55ff0ef          	jal	2e8c <number>
    343c:	0000d5b7          	lui	a1,0xd
    3440:	50858593          	addi	a1,a1,1288 # d508 <_data+0x25c>
    3444:	d7dff06f          	j	31c0 <hud_comparison_text+0x254>
    3448:	0000d5b7          	lui	a1,0xd
    344c:	52058593          	addi	a1,a1,1312 # d520 <_data+0x274>
    3450:	e8dff06f          	j	32dc <hud_comparison_text+0x370>
    3454:	ff800513          	li	a0,-8
    3458:	00008067          	ret

0000345c <hud_build_comparison>:
    345c:	ea010113          	addi	sp,sp,-352
    3460:	15212823          	sw	s2,336(sp)
    3464:	14112e23          	sw	ra,348(sp)
    3468:	14812c23          	sw	s0,344(sp)
    346c:	14912a23          	sw	s1,340(sp)
    3470:	15312623          	sw	s3,332(sp)
    3474:	15412423          	sw	s4,328(sp)
    3478:	15512223          	sw	s5,324(sp)
    347c:	15612023          	sw	s6,320(sp)
    3480:	13712e23          	sw	s7,316(sp)
    3484:	13812c23          	sw	s8,312(sp)
    3488:	13912a23          	sw	s9,308(sp)
    348c:	13a12823          	sw	s10,304(sp)
    3490:	13b12623          	sw	s11,300(sp)
    3494:	ff800913          	li	s2,-8
    3498:	28060263          	beqz	a2,371c <hud_build_comparison+0x2c0>
    349c:	ffe007b7          	lui	a5,0xffe00
    34a0:	fff78793          	addi	a5,a5,-1 # ffdfffff <__gpu_framebuffer_a+0xfddfffff>
    34a4:	00f577b3          	and	a5,a0,a5
    34a8:	02000737          	lui	a4,0x2000
    34ac:	00050993          	mv	s3,a0
    34b0:	ff800913          	li	s2,-8
    34b4:	26e79463          	bne	a5,a4,371c <hud_build_comparison+0x2c0>
    34b8:	00058513          	mv	a0,a1
    34bc:	02010593          	addi	a1,sp,32
    34c0:	00060413          	mv	s0,a2
    34c4:	aa9ff0ef          	jal	2f6c <hud_comparison_text>
    34c8:	00050913          	mv	s2,a0
    34cc:	24051863          	bnez	a0,371c <hud_build_comparison+0x2c0>
    34d0:	000087b7          	lui	a5,0x8
    34d4:	00f407b3          	add	a5,s0,a5
    34d8:	00100493          	li	s1,1
    34dc:	00979023          	sh	s1,0(a5) # 8000 <game_update_cached+0xd4>
    34e0:	02000613          	li	a2,32
    34e4:	00000593          	li	a1,0
    34e8:	00040513          	mv	a0,s0
    34ec:	d3dfd0ef          	jal	1228 <memset>
    34f0:	78000793          	li	a5,1920
    34f4:	00f42623          	sw	a5,12(s0)
    34f8:	004807b7          	lui	a5,0x480
    34fc:	3c078793          	addi	a5,a5,960 # 4803c0 <__freertos_irq_stack_top+0x462920>
    3500:	0000eeb7          	lui	t4,0xe
    3504:	0000ef37          	lui	t5,0xe
    3508:	01342223          	sw	s3,4(s0)
    350c:	00f42823          	sw	a5,16(s0)
    3510:	00940e23          	sb	s1,28(s0)
    3514:	02010e13          	addi	t3,sp,32
    3518:	00000b93          	li	s7,0
    351c:	b50e8e93          	addi	t4,t4,-1200 # db50 <comparison_digits>
    3520:	b98f0f13          	addi	t5,t5,-1128 # db98 <comparison_letters>
    3524:	ffeb8793          	addi	a5,s7,-2
    3528:	fff00c13          	li	s8,-1
    352c:	00079463          	bnez	a5,3534 <hud_build_comparison+0xd8>
    3530:	7e000c13          	li	s8,2016
    3534:	01200a13          	li	s4,18
    3538:	034b8a33          	mul	s4,s7,s4
    353c:	010c1793          	slli	a5,s8,0x10
    3540:	0107d793          	srli	a5,a5,0x10
    3544:	00f12223          	sw	a5,4(sp)
    3548:	000e0c13          	mv	s8,t3
    354c:	00400b13          	li	s6,4
    3550:	003a0a13          	addi	s4,s4,3
    3554:	010a1a13          	slli	s4,s4,0x10
    3558:	010a5a13          	srli	s4,s4,0x10
    355c:	2500006f          	j	37ac <hud_build_comparison+0x350>
    3560:	00700613          	li	a2,7
    3564:	02c70633          	mul	a2,a4,a2
    3568:	fbf70593          	addi	a1,a4,-65 # 1ffffbf <__freertos_irq_stack_top+0x1fe251f>
    356c:	fd070513          	addi	a0,a4,-48
    3570:	00000693          	li	a3,0
    3574:	0ff5f593          	zext.b	a1,a1
    3578:	01900f93          	li	t6,25
    357c:	0ff57513          	zext.b	a0,a0
    3580:	00900293          	li	t0,9
    3584:	02d00393          	li	t2,45
    3588:	02e00493          	li	s1,46
    358c:	00700813          	li	a6,7
    3590:	04bfe463          	bltu	t6,a1,35d8 <hud_build_comparison+0x17c>
    3594:	01e607b3          	add	a5,a2,t5
    3598:	e397c783          	lbu	a5,-455(a5)
    359c:	01810893          	addi	a7,sp,24
    35a0:	00d888b3          	add	a7,a7,a3
    35a4:	00f88023          	sb	a5,0(a7)
    35a8:	00168693          	addi	a3,a3,1
    35ac:	00160613          	addi	a2,a2,1
    35b0:	ff0690e3          	bne	a3,a6,3590 <hud_build_comparison+0x134>
    35b4:	01810c93          	addi	s9,sp,24
    35b8:	000a0713          	mv	a4,s4
    35bc:	00000a93          	li	s5,0
    35c0:	01000d13          	li	s10,16
    35c4:	00500d93          	li	s11,5
    35c8:	00100293          	li	t0,1
    35cc:	00000693          	li	a3,0
    35d0:	00700f93          	li	t6,7
    35d4:	0480006f          	j	361c <hud_build_comparison+0x1c0>
    35d8:	00a2e863          	bltu	t0,a0,35e8 <hud_build_comparison+0x18c>
    35dc:	01d607b3          	add	a5,a2,t4
    35e0:	eb07c783          	lbu	a5,-336(a5)
    35e4:	fb9ff06f          	j	359c <hud_build_comparison+0x140>
    35e8:	00771c63          	bne	a4,t2,3600 <hud_build_comparison+0x1a4>
    35ec:	00300893          	li	a7,3
    35f0:	00e00793          	li	a5,14
    35f4:	fb1684e3          	beq	a3,a7,359c <hud_build_comparison+0x140>
    35f8:	00000793          	li	a5,0
    35fc:	fa1ff06f          	j	359c <hud_build_comparison+0x140>
    3600:	00000793          	li	a5,0
    3604:	f8971ce3          	bne	a4,s1,359c <hud_build_comparison+0x140>
    3608:	ffa68793          	addi	a5,a3,-6
    360c:	0017b793          	seqz	a5,a5
    3610:	00279793          	slli	a5,a5,0x2
    3614:	f89ff06f          	j	359c <hud_build_comparison+0x140>
    3618:	00048693          	mv	a3,s1
    361c:	000cc603          	lbu	a2,0(s9)
    3620:	00dd57b3          	srl	a5,s10,a3
    3624:	00168493          	addi	s1,a3,1
    3628:	00c7f7b3          	and	a5,a5,a2
    362c:	14078863          	beqz	a5,377c <hud_build_comparison+0x320>
    3630:	00068493          	mv	s1,a3
    3634:	00148493          	addi	s1,s1,1
    3638:	01b48863          	beq	s1,s11,3648 <hud_build_comparison+0x1ec>
    363c:	009d57b3          	srl	a5,s10,s1
    3640:	00c7f7b3          	and	a5,a5,a2
    3644:	fe0798e3          	bnez	a5,3634 <hud_build_comparison+0x1d8>
    3648:	40d487b3          	sub	a5,s1,a3
    364c:	00f29633          	sll	a2,t0,a5
    3650:	409d85b3          	sub	a1,s11,s1
    3654:	fff60613          	addi	a2,a2,-1
    3658:	00b61633          	sll	a2,a2,a1
    365c:	001a8813          	addi	a6,s5,1
    3660:	00000593          	li	a1,0
    3664:	00068663          	beqz	a3,3670 <hud_build_comparison+0x214>
    3668:	fff68593          	addi	a1,a3,-1
    366c:	00bd55b3          	srl	a1,s10,a1
    3670:	00000513          	li	a0,0
    3674:	01b48463          	beq	s1,s11,367c <hud_build_comparison+0x220>
    3678:	009d5533          	srl	a0,s10,s1
    367c:	00a5e5b3          	or	a1,a1,a0
    3680:	00b665b3          	or	a1,a2,a1
    3684:	01f80c63          	beq	a6,t6,369c <hud_build_comparison+0x240>
    3688:	01810513          	addi	a0,sp,24
    368c:	01050533          	add	a0,a0,a6
    3690:	00054503          	lbu	a0,0(a0)
    3694:	00b57533          	and	a0,a0,a1
    3698:	0cc50263          	beq	a0,a2,375c <hud_build_comparison+0x300>
    369c:	000c8593          	mv	a1,s9
    36a0:	000a8513          	mv	a0,s5
    36a4:	fff64613          	not	a2,a2
    36a8:	0b056e63          	bltu	a0,a6,3764 <hud_build_comparison+0x308>
    36ac:	41580833          	sub	a6,a6,s5
    36b0:	00db06b3          	add	a3,s6,a3
    36b4:	00412883          	lw	a7,4(sp)
    36b8:	00181813          	slli	a6,a6,0x1
    36bc:	00179793          	slli	a5,a5,0x1
    36c0:	00169693          	slli	a3,a3,0x1
    36c4:	01081813          	slli	a6,a6,0x10
    36c8:	01079793          	slli	a5,a5,0x10
    36cc:	01069693          	slli	a3,a3,0x10
    36d0:	0107d793          	srli	a5,a5,0x10
    36d4:	01085813          	srli	a6,a6,0x10
    36d8:	0106d693          	srli	a3,a3,0x10
    36dc:	78000613          	li	a2,1920
    36e0:	00098593          	mv	a1,s3
    36e4:	00040513          	mv	a0,s0
    36e8:	01c12623          	sw	t3,12(sp)
    36ec:	00e12423          	sw	a4,8(sp)
    36f0:	ea8ff0ef          	jal	2d98 <append_fill>
    36f4:	0000e7b7          	lui	a5,0xe
    36f8:	b5078e93          	addi	t4,a5,-1200 # db50 <comparison_digits>
    36fc:	0000e7b7          	lui	a5,0xe
    3700:	00812703          	lw	a4,8(sp)
    3704:	00c12e03          	lw	t3,12(sp)
    3708:	00100293          	li	t0,1
    370c:	00700f93          	li	t6,7
    3710:	b9878f13          	addi	t5,a5,-1128 # db98 <comparison_letters>
    3714:	06050463          	beqz	a0,377c <hud_build_comparison+0x320>
    3718:	00050913          	mv	s2,a0
    371c:	15c12083          	lw	ra,348(sp)
    3720:	15812403          	lw	s0,344(sp)
    3724:	15412483          	lw	s1,340(sp)
    3728:	14c12983          	lw	s3,332(sp)
    372c:	14812a03          	lw	s4,328(sp)
    3730:	14412a83          	lw	s5,324(sp)
    3734:	14012b03          	lw	s6,320(sp)
    3738:	13c12b83          	lw	s7,316(sp)
    373c:	13812c03          	lw	s8,312(sp)
    3740:	13412c83          	lw	s9,308(sp)
    3744:	13012d03          	lw	s10,304(sp)
    3748:	12c12d83          	lw	s11,300(sp)
    374c:	00090513          	mv	a0,s2
    3750:	15012903          	lw	s2,336(sp)
    3754:	16010113          	addi	sp,sp,352
    3758:	00008067          	ret
    375c:	00180813          	addi	a6,a6,1
    3760:	f25ff06f          	j	3684 <hud_build_comparison+0x228>
    3764:	0005c883          	lbu	a7,0(a1)
    3768:	00150513          	addi	a0,a0,1
    376c:	00158593          	addi	a1,a1,1
    3770:	00c8f8b3          	and	a7,a7,a2
    3774:	ff158fa3          	sb	a7,-1(a1)
    3778:	f31ff06f          	j	36a8 <hud_build_comparison+0x24c>
    377c:	e9b49ee3          	bne	s1,s11,3618 <hud_build_comparison+0x1bc>
    3780:	00270713          	addi	a4,a4,2
    3784:	01071713          	slli	a4,a4,0x10
    3788:	001a8a93          	addi	s5,s5,1
    378c:	00700793          	li	a5,7
    3790:	01075713          	srli	a4,a4,0x10
    3794:	001c8c93          	addi	s9,s9,1
    3798:	e2fa9ae3          	bne	s5,a5,35cc <hud_build_comparison+0x170>
    379c:	007b0b13          	addi	s6,s6,7
    37a0:	010b1b13          	slli	s6,s6,0x10
    37a4:	001c0c13          	addi	s8,s8,1
    37a8:	010b5b13          	srli	s6,s6,0x10
    37ac:	000c4703          	lbu	a4,0(s8)
    37b0:	da0718e3          	bnez	a4,3560 <hud_build_comparison+0x104>
    37b4:	001b8b93          	addi	s7,s7,1
    37b8:	00400793          	li	a5,4
    37bc:	040e0e13          	addi	t3,t3,64
    37c0:	d6fb92e3          	bne	s7,a5,3524 <hud_build_comparison+0xc8>
    37c4:	02010513          	addi	a0,sp,32
    37c8:	f38ff0ef          	jal	2f00 <hud_logo_fits>
    37cc:	f40508e3          	beqz	a0,371c <hud_build_comparison+0x2c0>
    37d0:	00008737          	lui	a4,0x8
    37d4:	00e40733          	add	a4,s0,a4
    37d8:	00075783          	lhu	a5,0(a4) # 8000 <game_update_cached+0xd4>
    37dc:	3ff00693          	li	a3,1023
    37e0:	06f6e263          	bltu	a3,a5,3844 <hud_build_comparison+0x3e8>
    37e4:	00178693          	addi	a3,a5,1
    37e8:	00579793          	slli	a5,a5,0x5
    37ec:	00f40433          	add	s0,s0,a5
    37f0:	00d71023          	sh	a3,0(a4)
    37f4:	02000613          	li	a2,32
    37f8:	00000593          	li	a1,0
    37fc:	00040513          	mv	a0,s0
    3800:	a29fd0ef          	jal	1228 <memset>
    3804:	02c507b7          	lui	a5,0x2c50
    3808:	00f42023          	sw	a5,0(s0)
    380c:	000017b7          	lui	a5,0x1
    3810:	d6078793          	addi	a5,a5,-672 # d60 <CUSTOM2+0xd05>
    3814:	00f989b3          	add	s3,s3,a5
    3818:	19000793          	li	a5,400
    381c:	00f42423          	sw	a5,8(s0)
    3820:	78000793          	li	a5,1920
    3824:	00f42623          	sw	a5,12(s0)
    3828:	004607b7          	lui	a5,0x460
    382c:	0c878793          	addi	a5,a5,200 # 4600c8 <__freertos_irq_stack_top+0x442628>
    3830:	00f42823          	sw	a5,16(s0)
    3834:	00200793          	li	a5,2
    3838:	01342223          	sw	s3,4(s0)
    383c:	00f40e23          	sb	a5,28(s0)
    3840:	eddff06f          	j	371c <hud_build_comparison+0x2c0>
    3844:	ffc00913          	li	s2,-4
    3848:	ed5ff06f          	j	371c <hud_build_comparison+0x2c0>

0000384c <hud_init_glyph_atlas>:
    384c:	fe010113          	addi	sp,sp,-32
    3850:	00010337          	lui	t1,0x10
    3854:	00005537          	lui	a0,0x5
    3858:	02c4ae37          	lui	t3,0x2c4a
    385c:	00812e23          	sw	s0,28(sp)
    3860:	00912c23          	sw	s1,24(sp)
    3864:	01212a23          	sw	s2,20(sp)
    3868:	01312823          	sw	s3,16(sp)
    386c:	01412623          	sw	s4,12(sp)
    3870:	01512423          	sw	s5,8(sp)
    3874:	00000893          	li	a7,0
    3878:	02c407b7          	lui	a5,0x2c40
    387c:	0000dfb7          	lui	t6,0xd
    3880:	00d00293          	li	t0,13
    3884:	00900393          	li	t2,9
    3888:	01000913          	li	s2,16
    388c:	fff30313          	addi	t1,t1,-1 # ffff <__global_pointer$+0x127f>
    3890:	00e00413          	li	s0,14
    3894:	00f00493          	li	s1,15
    3898:	cc850513          	addi	a0,a0,-824 # 4cc8 <perf_window_add+0x78>
    389c:	990e0e13          	addi	t3,t3,-1648 # 2c49990 <__gpu_framebuffer_a+0xc49990>
    38a0:	550f8813          	addi	a6,t6,1360 # d550 <_data+0x2a4>
    38a4:	00a78f33          	add	t5,a5,a0
    38a8:	00084583          	lbu	a1,0(a6)
    38ac:	00078e93          	mv	t4,a5
    38b0:	ffd00613          	li	a2,-3
    38b4:	00000693          	li	a3,0
    38b8:	02c2ea63          	bltu	t0,a2,38ec <hud_init_glyph_atlas+0xa0>
    38bc:	fbf58993          	addi	s3,a1,-65
    38c0:	0ff9fa93          	zext.b	s5,s3
    38c4:	01900a13          	li	s4,25
    38c8:	00165713          	srli	a4,a2,0x1
    38cc:	095a6e63          	bltu	s4,s5,3968 <hud_init_glyph_atlas+0x11c>
    38d0:	00700a13          	li	s4,7
    38d4:	034989b3          	mul	s3,s3,s4
    38d8:	0000e6b7          	lui	a3,0xe
    38dc:	b9868693          	addi	a3,a3,-1128 # db98 <comparison_letters>
    38e0:	013686b3          	add	a3,a3,s3
    38e4:	00e68733          	add	a4,a3,a4
    38e8:	00074683          	lbu	a3,0(a4)
    38ec:	00000713          	li	a4,0
    38f0:	00000a13          	li	s4,0
    38f4:	02e3e063          	bltu	t2,a4,3914 <hud_init_glyph_atlas+0xc8>
    38f8:	00175993          	srli	s3,a4,0x1
    38fc:	013959b3          	srl	s3,s2,s3
    3900:	00d9f9b3          	and	s3,s3,a3
    3904:	00098863          	beqz	s3,3914 <hud_init_glyph_atlas+0xc8>
    3908:	00030a13          	mv	s4,t1
    390c:	00088463          	beqz	a7,3914 <hud_init_glyph_atlas+0xc8>
    3910:	7e000a13          	li	s4,2016
    3914:	00171993          	slli	s3,a4,0x1
    3918:	013e89b3          	add	s3,t4,s3
    391c:	01499023          	sh	s4,0(s3)
    3920:	00170713          	addi	a4,a4,1
    3924:	fc8716e3          	bne	a4,s0,38f0 <hud_init_glyph_atlas+0xa4>
    3928:	00160613          	addi	a2,a2,1
    392c:	01ce8e93          	addi	t4,t4,28
    3930:	f89612e3          	bne	a2,s1,38b4 <hud_init_glyph_atlas+0x68>
    3934:	1f878793          	addi	a5,a5,504 # 2c401f8 <__gpu_framebuffer_a+0xc401f8>
    3938:	00180813          	addi	a6,a6,1
    393c:	f7e796e3          	bne	a5,t5,38a8 <hud_init_glyph_atlas+0x5c>
    3940:	00188893          	addi	a7,a7,1
    3944:	f5c79ee3          	bne	a5,t3,38a0 <hud_init_glyph_atlas+0x54>
    3948:	01c12403          	lw	s0,28(sp)
    394c:	01812483          	lw	s1,24(sp)
    3950:	01412903          	lw	s2,20(sp)
    3954:	01012983          	lw	s3,16(sp)
    3958:	00c12a03          	lw	s4,12(sp)
    395c:	00812a83          	lw	s5,8(sp)
    3960:	02010113          	addi	sp,sp,32
    3964:	00008067          	ret
    3968:	fd058993          	addi	s3,a1,-48
    396c:	0ff9fa93          	zext.b	s5,s3
    3970:	00900a13          	li	s4,9
    3974:	015a6c63          	bltu	s4,s5,398c <hud_init_glyph_atlas+0x140>
    3978:	0000e6b7          	lui	a3,0xe
    397c:	00700a13          	li	s4,7
    3980:	034989b3          	mul	s3,s3,s4
    3984:	b5068693          	addi	a3,a3,-1200 # db50 <comparison_digits>
    3988:	f59ff06f          	j	38e0 <hud_init_glyph_atlas+0x94>
    398c:	02d00993          	li	s3,45
    3990:	01359a63          	bne	a1,s3,39a4 <hud_init_glyph_atlas+0x158>
    3994:	00300993          	li	s3,3
    3998:	f5371ae3          	bne	a4,s3,38ec <hud_init_glyph_atlas+0xa0>
    399c:	00e00693          	li	a3,14
    39a0:	f4dff06f          	j	38ec <hud_init_glyph_atlas+0xa0>
    39a4:	02e00993          	li	s3,46
    39a8:	f53592e3          	bne	a1,s3,38ec <hud_init_glyph_atlas+0xa0>
    39ac:	ffa70713          	addi	a4,a4,-6
    39b0:	00173713          	seqz	a4,a4
    39b4:	00271693          	slli	a3,a4,0x2
    39b8:	f35ff06f          	j	38ec <hud_init_glyph_atlas+0xa0>

000039bc <hud_update_cache>:
    39bc:	e9010113          	addi	sp,sp,-368
    39c0:	16112623          	sw	ra,364(sp)
    39c4:	16812423          	sw	s0,360(sp)
    39c8:	16912223          	sw	s1,356(sp)
    39cc:	17212023          	sw	s2,352(sp)
    39d0:	15312e23          	sw	s3,348(sp)
    39d4:	15412c23          	sw	s4,344(sp)
    39d8:	15512a23          	sw	s5,340(sp)
    39dc:	15612823          	sw	s6,336(sp)
    39e0:	15712623          	sw	s7,332(sp)
    39e4:	15812423          	sw	s8,328(sp)
    39e8:	15912223          	sw	s9,324(sp)
    39ec:	15a12023          	sw	s10,320(sp)
    39f0:	13b12e23          	sw	s11,316(sp)
    39f4:	04051463          	bnez	a0,3a3c <hud_update_cache+0x80>
    39f8:	ff800993          	li	s3,-8
    39fc:	16c12083          	lw	ra,364(sp)
    3a00:	16812403          	lw	s0,360(sp)
    3a04:	16412483          	lw	s1,356(sp)
    3a08:	16012903          	lw	s2,352(sp)
    3a0c:	15812a03          	lw	s4,344(sp)
    3a10:	15412a83          	lw	s5,340(sp)
    3a14:	15012b03          	lw	s6,336(sp)
    3a18:	14c12b83          	lw	s7,332(sp)
    3a1c:	14812c03          	lw	s8,328(sp)
    3a20:	14412c83          	lw	s9,324(sp)
    3a24:	14012d03          	lw	s10,320(sp)
    3a28:	13c12d83          	lw	s11,316(sp)
    3a2c:	00098513          	mv	a0,s3
    3a30:	15c12983          	lw	s3,348(sp)
    3a34:	17010113          	addi	sp,sp,368
    3a38:	00008067          	ret
    3a3c:	00058493          	mv	s1,a1
    3a40:	fa058ce3          	beqz	a1,39f8 <hud_update_cache+0x3c>
    3a44:	00060a13          	mv	s4,a2
    3a48:	fa0608e3          	beqz	a2,39f8 <hud_update_cache+0x3c>
    3a4c:	00050413          	mv	s0,a0
    3a50:	10000613          	li	a2,256
    3a54:	00000593          	li	a1,0
    3a58:	03010513          	addi	a0,sp,48
    3a5c:	fccfd0ef          	jal	1228 <memset>
    3a60:	03010593          	addi	a1,sp,48
    3a64:	00040513          	mv	a0,s0
    3a68:	d04ff0ef          	jal	2f6c <hud_comparison_text>
    3a6c:	00050993          	mv	s3,a0
    3a70:	f80516e3          	bnez	a0,39fc <hud_update_cache+0x40>
    3a74:	03010513          	addi	a0,sp,48
    3a78:	c88ff0ef          	jal	2f00 <hud_logo_fits>
    3a7c:	1044c783          	lbu	a5,260(s1)
    3a80:	0ff57b13          	zext.b	s6,a0
    3a84:	02079063          	bnez	a5,3aa4 <hud_update_cache+0xe8>
    3a88:	000a0613          	mv	a2,s4
    3a8c:	00040593          	mv	a1,s0
    3a90:	02000537          	lui	a0,0x2000
    3a94:	9c9ff0ef          	jal	345c <hud_build_comparison>
    3a98:	02050663          	beqz	a0,3ac4 <hud_update_cache+0x108>
    3a9c:	00050993          	mv	s3,a0
    3aa0:	f5dff06f          	j	39fc <hud_update_cache+0x40>
    3aa4:	1054c783          	lbu	a5,261(s1)
    3aa8:	ff6790e3          	bne	a5,s6,3a88 <hud_update_cache+0xcc>
    3aac:	10000613          	li	a2,256
    3ab0:	03010593          	addi	a1,sp,48
    3ab4:	00048513          	mv	a0,s1
    3ab8:	db4fd0ef          	jal	106c <memcmp>
    3abc:	fc0516e3          	bnez	a0,3a88 <hud_update_cache+0xcc>
    3ac0:	f3dff06f          	j	39fc <hud_update_cache+0x40>
    3ac4:	0000eab7          	lui	s5,0xe
    3ac8:	c6ca8593          	addi	a1,s5,-916 # dc6c <comparison_letters+0xd4>
    3acc:	10048223          	sb	zero,260(s1)
    3ad0:	01000613          	li	a2,16
    3ad4:	01010513          	addi	a0,sp,16
    3ad8:	82dfd0ef          	jal	1304 <memcpy>
    3adc:	00008bb7          	lui	s7,0x8
    3ae0:	017a07b3          	add	a5,s4,s7
    3ae4:	00022db7          	lui	s11,0x22
    3ae8:	00460bb7          	lui	s7,0x460
    3aec:	c6ca8a93          	addi	s5,s5,-916
    3af0:	000a0913          	mv	s2,s4
    3af4:	00000d13          	li	s10,0
    3af8:	00f12623          	sw	a5,12(sp)
    3afc:	78000c93          	li	s9,1920
    3b00:	02000c37          	lui	s8,0x2000
    3b04:	bffd8d93          	addi	s11,s11,-1025 # 21bff <__freertos_irq_stack_top+0x415f>
    3b08:	0c8b8b93          	addi	s7,s7,200 # 4600c8 <__freertos_irq_stack_top+0x442628>
    3b0c:	010a8a93          	addi	s5,s5,16
    3b10:	00c12783          	lw	a5,12(sp)
    3b14:	0007d783          	lhu	a5,0(a5)
    3b18:	02fd6863          	bltu	s10,a5,3b48 <hud_update_cache+0x18c>
    3b1c:	10000613          	li	a2,256
    3b20:	03010593          	addi	a1,sp,48
    3b24:	00048513          	mv	a0,s1
    3b28:	fdcfd0ef          	jal	1304 <memcpy>
    3b2c:	00100793          	li	a5,1
    3b30:	10f48223          	sb	a5,260(s1)
    3b34:	1004a783          	lw	a5,256(s1)
    3b38:	116482a3          	sb	s6,261(s1)
    3b3c:	00178793          	addi	a5,a5,1
    3b40:	10f4a023          	sw	a5,256(s1)
    3b44:	eb9ff06f          	j	39fc <hud_update_cache+0x40>
    3b48:	00c92783          	lw	a5,12(s2)
    3b4c:	eb9796e3          	bne	a5,s9,39f8 <hud_update_cache+0x3c>
    3b50:	00492403          	lw	s0,4(s2)
    3b54:	eb8462e3          	bltu	s0,s8,39f8 <hud_update_cache+0x3c>
    3b58:	41840433          	sub	s0,s0,s8
    3b5c:	e88deee3          	bltu	s11,s0,39f8 <hud_update_cache+0x3c>
    3b60:	00147793          	andi	a5,s0,1
    3b64:	e8079ae3          	bnez	a5,39f8 <hud_update_cache+0x3c>
    3b68:	01c94783          	lbu	a5,28(s2)
    3b6c:	00100713          	li	a4,1
    3b70:	02e79e63          	bne	a5,a4,3bac <hud_update_cache+0x1f0>
    3b74:	03945633          	divu	a2,s0,s9
    3b78:	01495783          	lhu	a5,20(s2)
    3b7c:	01295703          	lhu	a4,18(s2)
    3b80:	01095683          	lhu	a3,16(s2)
    3b84:	01010513          	addi	a0,sp,16
    3b88:	039475b3          	remu	a1,s0,s9
    3b8c:	01061613          	slli	a2,a2,0x10
    3b90:	01065613          	srli	a2,a2,0x10
    3b94:	0015d593          	srli	a1,a1,0x1
    3b98:	c65fe0ef          	jal	27fc <golden_fill>
    3b9c:	02090913          	addi	s2,s2,32
    3ba0:	ee051ee3          	bnez	a0,3a9c <hud_update_cache+0xe0>
    3ba4:	001d0d13          	addi	s10,s10,1
    3ba8:	f69ff06f          	j	3b10 <hud_update_cache+0x154>
    3bac:	00200713          	li	a4,2
    3bb0:	e4e794e3          	bne	a5,a4,39f8 <hud_update_cache+0x3c>
    3bb4:	00092703          	lw	a4,0(s2)
    3bb8:	02c507b7          	lui	a5,0x2c50
    3bbc:	e2f71ee3          	bne	a4,a5,39f8 <hud_update_cache+0x3c>
    3bc0:	00892703          	lw	a4,8(s2)
    3bc4:	19000793          	li	a5,400
    3bc8:	e2f718e3          	bne	a4,a5,39f8 <hud_update_cache+0x3c>
    3bcc:	005d1793          	slli	a5,s10,0x5
    3bd0:	00fa07b3          	add	a5,s4,a5
    3bd4:	0107a783          	lw	a5,16(a5) # 2c50010 <__gpu_framebuffer_a+0xc50010>
    3bd8:	e37790e3          	bne	a5,s7,39f8 <hud_update_cache+0x3c>
    3bdc:	000a8593          	mv	a1,s5
    3be0:	01000613          	li	a2,16
    3be4:	02010513          	addi	a0,sp,32
    3be8:	f1cfd0ef          	jal	1304 <memcpy>
    3bec:	03945633          	divu	a2,s0,s9
    3bf0:	04600893          	li	a7,70
    3bf4:	0c800813          	li	a6,200
    3bf8:	00000793          	li	a5,0
    3bfc:	00000713          	li	a4,0
    3c00:	02010693          	addi	a3,sp,32
    3c04:	01010513          	addi	a0,sp,16
    3c08:	03947433          	remu	s0,s0,s9
    3c0c:	01061613          	slli	a2,a2,0x10
    3c10:	01065613          	srli	a2,a2,0x10
    3c14:	00145593          	srli	a1,s0,0x1
    3c18:	cc5fe0ef          	jal	28dc <golden_copy>
    3c1c:	f81ff06f          	j	3b9c <hud_update_cache+0x1e0>

00003c20 <hud_cached_command>:
    3c20:	08058663          	beqz	a1,3cac <hud_cached_command+0x8c>
    3c24:	ff010113          	addi	sp,sp,-16
    3c28:	00812423          	sw	s0,8(sp)
    3c2c:	00112623          	sw	ra,12(sp)
    3c30:	1045c703          	lbu	a4,260(a1)
    3c34:	00050413          	mv	s0,a0
    3c38:	ff800513          	li	a0,-8
    3c3c:	06070063          	beqz	a4,3c9c <hud_cached_command+0x7c>
    3c40:	00060793          	mv	a5,a2
    3c44:	04060c63          	beqz	a2,3c9c <hud_cached_command+0x7c>
    3c48:	ffe00737          	lui	a4,0xffe00
    3c4c:	fff70713          	addi	a4,a4,-1 # ffdfffff <__gpu_framebuffer_a+0xfddfffff>
    3c50:	00e47733          	and	a4,s0,a4
    3c54:	020006b7          	lui	a3,0x2000
    3c58:	04d71263          	bne	a4,a3,3c9c <hud_cached_command+0x7c>
    3c5c:	02000613          	li	a2,32
    3c60:	00000593          	li	a1,0
    3c64:	00078513          	mv	a0,a5
    3c68:	dc0fd0ef          	jal	1228 <memset>
    3c6c:	02c10737          	lui	a4,0x2c10
    3c70:	00e52023          	sw	a4,0(a0) # 2000000 <__gpu_framebuffer_a>
    3c74:	78000713          	li	a4,1920
    3c78:	00e52423          	sw	a4,8(a0)
    3c7c:	00e52623          	sw	a4,12(a0)
    3c80:	00480737          	lui	a4,0x480
    3c84:	3c070713          	addi	a4,a4,960 # 4803c0 <__freertos_irq_stack_top+0x462920>
    3c88:	00e52823          	sw	a4,16(a0)
    3c8c:	00200713          	li	a4,2
    3c90:	00852223          	sw	s0,4(a0)
    3c94:	00e50e23          	sb	a4,28(a0)
    3c98:	00000513          	li	a0,0
    3c9c:	00c12083          	lw	ra,12(sp)
    3ca0:	00812403          	lw	s0,8(sp)
    3ca4:	01010113          	addi	sp,sp,16
    3ca8:	00008067          	ret
    3cac:	ff800513          	li	a0,-8
    3cb0:	00008067          	ret

00003cb4 <update_gpu_target>:
    3cb4:	eb010113          	addi	sp,sp,-336
    3cb8:	14812423          	sw	s0,328(sp)
    3cbc:	14112623          	sw	ra,332(sp)
    3cc0:	14912223          	sw	s1,324(sp)
    3cc4:	15212023          	sw	s2,320(sp)
    3cc8:	13312e23          	sw	s3,316(sp)
    3ccc:	13412c23          	sw	s4,312(sp)
    3cd0:	13512a23          	sw	s5,308(sp)
    3cd4:	13612823          	sw	s6,304(sp)
    3cd8:	13712623          	sw	s7,300(sp)
    3cdc:	13812423          	sw	s8,296(sp)
    3ce0:	13912223          	sw	s9,292(sp)
    3ce4:	13a12023          	sw	s10,288(sp)
    3ce8:	11b12e23          	sw	s11,284(sp)
    3cec:	ff800413          	li	s0,-8
    3cf0:	1e050a63          	beqz	a0,3ee4 <update_gpu_target+0x230>
    3cf4:	00078993          	mv	s3,a5
    3cf8:	01054783          	lbu	a5,16(a0)
    3cfc:	00050a93          	mv	s5,a0
    3d00:	ff800413          	li	s0,-8
    3d04:	1e078063          	beqz	a5,3ee4 <update_gpu_target+0x230>
    3d08:	00058a13          	mv	s4,a1
    3d0c:	1c058c63          	beqz	a1,3ee4 <update_gpu_target+0x230>
    3d10:	00060493          	mv	s1,a2
    3d14:	1c060863          	beqz	a2,3ee4 <update_gpu_target+0x230>
    3d18:	00068913          	mv	s2,a3
    3d1c:	1c068463          	beqz	a3,3ee4 <update_gpu_target+0x230>
    3d20:	00070b13          	mv	s6,a4
    3d24:	1c070063          	beqz	a4,3ee4 <update_gpu_target+0x230>
    3d28:	10000613          	li	a2,256
    3d2c:	00000593          	li	a1,0
    3d30:	01010513          	addi	a0,sp,16
    3d34:	cf4fd0ef          	jal	1228 <memset>
    3d38:	01010593          	addi	a1,sp,16
    3d3c:	000a0513          	mv	a0,s4
    3d40:	a2cff0ef          	jal	2f6c <hud_comparison_text>
    3d44:	00050413          	mv	s0,a0
    3d48:	18051e63          	bnez	a0,3ee4 <update_gpu_target+0x230>
    3d4c:	01010513          	addi	a0,sp,16
    3d50:	9b0ff0ef          	jal	2f00 <hud_logo_fits>
    3d54:	000087b7          	lui	a5,0x8
    3d58:	00f907b3          	add	a5,s2,a5
    3d5c:	00079023          	sh	zero,0(a5) # 8000 <game_update_cached+0xd4>
    3d60:	1044c783          	lbu	a5,260(s1)
    3d64:	0ff57a13          	zext.b	s4,a0
    3d68:	14079e63          	bnez	a5,3ec4 <update_gpu_target+0x210>
    3d6c:	1044cb83          	lbu	s7,260(s1)
    3d70:	1a0b8a63          	beqz	s7,3f24 <update_gpu_target+0x270>
    3d74:	1054c783          	lbu	a5,261(s1)
    3d78:	20079063          	bnez	a5,3f78 <update_gpu_target+0x2c4>
    3d7c:	02c45837          	lui	a6,0x2c45
    3d80:	00008737          	lui	a4,0x8
    3d84:	001206b7          	lui	a3,0x120
    3d88:	71098c13          	addi	s8,s3,1808
    3d8c:	00000c93          	li	s9,0
    3d90:	cc880813          	addi	a6,a6,-824 # 2c44cc8 <__gpu_framebuffer_a+0xc44cc8>
    3d94:	00e90733          	add	a4,s2,a4
    3d98:	01900f93          	li	t6,25
    3d9c:	00e68693          	addi	a3,a3,14 # 12000e <__freertos_irq_stack_top+0x10256e>
    3da0:	ffec8793          	addi	a5,s9,-2
    3da4:	02c408b7          	lui	a7,0x2c40
    3da8:	00079463          	bnez	a5,3db0 <update_gpu_target+0xfc>
    3dac:	00080893          	mv	a7,a6
    3db0:	900c0d13          	addi	s10,s8,-1792 # 1fff900 <__freertos_irq_stack_top+0x1fe1e60>
    3db4:	006c9d93          	slli	s11,s9,0x6
    3db8:	010d8793          	addi	a5,s11,16
    3dbc:	002787b3          	add	a5,a5,sp
    3dc0:	0007c603          	lbu	a2,0(a5)
    3dc4:	200b8663          	beqz	s7,3fd0 <update_gpu_target+0x31c>
    3dc8:	01b487b3          	add	a5,s1,s11
    3dcc:	0007c783          	lbu	a5,0(a5)
    3dd0:	20c79463          	bne	a5,a2,3fd8 <update_gpu_target+0x324>
    3dd4:	01cd0d13          	addi	s10,s10,28
    3dd8:	001d8d93          	addi	s11,s11,1
    3ddc:	fd8d1ee3          	bne	s10,s8,3db8 <update_gpu_target+0x104>
    3de0:	00008c37          	lui	s8,0x8
    3de4:	700c0c13          	addi	s8,s8,1792 # 8700 <replay_seal_step+0xac>
    3de8:	001c8c93          	addi	s9,s9,1
    3dec:	00400793          	li	a5,4
    3df0:	018d0c33          	add	s8,s10,s8
    3df4:	fafc96e3          	bne	s9,a5,3da0 <update_gpu_target+0xec>
    3df8:	060a0c63          	beqz	s4,3e70 <update_gpu_target+0x1bc>
    3dfc:	000b8663          	beqz	s7,3e08 <update_gpu_target+0x154>
    3e00:	1054c783          	lbu	a5,261(s1)
    3e04:	06079663          	bnez	a5,3e70 <update_gpu_target+0x1bc>
    3e08:	000087b7          	lui	a5,0x8
    3e0c:	00f907b3          	add	a5,s2,a5
    3e10:	0007d803          	lhu	a6,0(a5) # 8000 <game_update_cached+0xd4>
    3e14:	02000613          	li	a2,32
    3e18:	00000593          	li	a1,0
    3e1c:	00180713          	addi	a4,a6,1
    3e20:	00581813          	slli	a6,a6,0x5
    3e24:	01090833          	add	a6,s2,a6
    3e28:	00e79023          	sh	a4,0(a5)
    3e2c:	00080513          	mv	a0,a6
    3e30:	bf8fd0ef          	jal	1228 <memset>
    3e34:	02c507b7          	lui	a5,0x2c50
    3e38:	00f52023          	sw	a5,0(a0)
    3e3c:	000017b7          	lui	a5,0x1
    3e40:	d6078793          	addi	a5,a5,-672 # d60 <CUSTOM2+0xd05>
    3e44:	00f989b3          	add	s3,s3,a5
    3e48:	19000793          	li	a5,400
    3e4c:	00f52423          	sw	a5,8(a0)
    3e50:	78000793          	li	a5,1920
    3e54:	00f52623          	sw	a5,12(a0)
    3e58:	004607b7          	lui	a5,0x460
    3e5c:	0c878793          	addi	a5,a5,200 # 4600c8 <__freertos_irq_stack_top+0x442628>
    3e60:	00f52823          	sw	a5,16(a0)
    3e64:	00200793          	li	a5,2
    3e68:	01352223          	sw	s3,4(a0)
    3e6c:	00f50e23          	sb	a5,28(a0)
    3e70:	000087b7          	lui	a5,0x8
    3e74:	10048223          	sb	zero,260(s1)
    3e78:	00f907b3          	add	a5,s2,a5
    3e7c:	0007d603          	lhu	a2,0(a5) # 8000 <game_update_cached+0xd4>
    3e80:	000b0693          	mv	a3,s6
    3e84:	00090593          	mv	a1,s2
    3e88:	000a8513          	mv	a0,s5
    3e8c:	52d000ef          	jal	4bb8 <perf_render_gpu>
    3e90:	00050413          	mv	s0,a0
    3e94:	04051863          	bnez	a0,3ee4 <update_gpu_target+0x230>
    3e98:	10000613          	li	a2,256
    3e9c:	01010593          	addi	a1,sp,16
    3ea0:	00048513          	mv	a0,s1
    3ea4:	c60fd0ef          	jal	1304 <memcpy>
    3ea8:	00100793          	li	a5,1
    3eac:	10f48223          	sb	a5,260(s1)
    3eb0:	1004a783          	lw	a5,256(s1)
    3eb4:	114482a3          	sb	s4,261(s1)
    3eb8:	00178793          	addi	a5,a5,1
    3ebc:	10f4a023          	sw	a5,256(s1)
    3ec0:	0240006f          	j	3ee4 <update_gpu_target+0x230>
    3ec4:	1054c783          	lbu	a5,261(s1)
    3ec8:	eb4792e3          	bne	a5,s4,3d6c <update_gpu_target+0xb8>
    3ecc:	10000613          	li	a2,256
    3ed0:	01010593          	addi	a1,sp,16
    3ed4:	00048513          	mv	a0,s1
    3ed8:	994fd0ef          	jal	106c <memcmp>
    3edc:	00050413          	mv	s0,a0
    3ee0:	e80516e3          	bnez	a0,3d6c <update_gpu_target+0xb8>
    3ee4:	14c12083          	lw	ra,332(sp)
    3ee8:	00040513          	mv	a0,s0
    3eec:	14812403          	lw	s0,328(sp)
    3ef0:	14412483          	lw	s1,324(sp)
    3ef4:	14012903          	lw	s2,320(sp)
    3ef8:	13c12983          	lw	s3,316(sp)
    3efc:	13812a03          	lw	s4,312(sp)
    3f00:	13412a83          	lw	s5,308(sp)
    3f04:	13012b03          	lw	s6,304(sp)
    3f08:	12c12b83          	lw	s7,300(sp)
    3f0c:	12812c03          	lw	s8,296(sp)
    3f10:	12412c83          	lw	s9,292(sp)
    3f14:	12012d03          	lw	s10,288(sp)
    3f18:	11c12d83          	lw	s11,284(sp)
    3f1c:	15010113          	addi	sp,sp,336
    3f20:	00008067          	ret
    3f24:	00008737          	lui	a4,0x8
    3f28:	00e90733          	add	a4,s2,a4
    3f2c:	00075783          	lhu	a5,0(a4) # 8000 <game_update_cached+0xd4>
    3f30:	02000613          	li	a2,32
    3f34:	00000593          	li	a1,0
    3f38:	00178693          	addi	a3,a5,1
    3f3c:	00579793          	slli	a5,a5,0x5
    3f40:	00f907b3          	add	a5,s2,a5
    3f44:	00d71023          	sh	a3,0(a4)
    3f48:	00078513          	mv	a0,a5
    3f4c:	adcfd0ef          	jal	1228 <memset>
    3f50:	78000713          	li	a4,1920
    3f54:	00e52623          	sw	a4,12(a0)
    3f58:	00480737          	lui	a4,0x480
    3f5c:	00050793          	mv	a5,a0
    3f60:	01352223          	sw	s3,4(a0)
    3f64:	3c070713          	addi	a4,a4,960 # 4803c0 <__freertos_irq_stack_top+0x462920>
    3f68:	00e7a823          	sw	a4,16(a5)
    3f6c:	00100713          	li	a4,1
    3f70:	00e78e23          	sb	a4,28(a5)
    3f74:	e09ff06f          	j	3d7c <update_gpu_target+0xc8>
    3f78:	e00a12e3          	bnez	s4,3d7c <update_gpu_target+0xc8>
    3f7c:	00008737          	lui	a4,0x8
    3f80:	00e90733          	add	a4,s2,a4
    3f84:	00075783          	lhu	a5,0(a4) # 8000 <game_update_cached+0xd4>
    3f88:	02000613          	li	a2,32
    3f8c:	00000593          	li	a1,0
    3f90:	00178693          	addi	a3,a5,1
    3f94:	00579793          	slli	a5,a5,0x5
    3f98:	00f907b3          	add	a5,s2,a5
    3f9c:	00d71023          	sh	a3,0(a4)
    3fa0:	00078513          	mv	a0,a5
    3fa4:	a84fd0ef          	jal	1228 <memset>
    3fa8:	00001737          	lui	a4,0x1
    3fac:	d6070713          	addi	a4,a4,-672 # d60 <CUSTOM2+0xd05>
    3fb0:	00e98733          	add	a4,s3,a4
    3fb4:	00e52223          	sw	a4,4(a0)
    3fb8:	78000713          	li	a4,1920
    3fbc:	00e52623          	sw	a4,12(a0)
    3fc0:	00460737          	lui	a4,0x460
    3fc4:	00050793          	mv	a5,a0
    3fc8:	0c870713          	addi	a4,a4,200 # 4600c8 <__freertos_irq_stack_top+0x442628>
    3fcc:	f9dff06f          	j	3f68 <update_gpu_target+0x2b4>
    3fd0:	0df67793          	andi	a5,a2,223
    3fd4:	e00780e3          	beqz	a5,3dd4 <update_gpu_target+0x120>
    3fd8:	00075783          	lhu	a5,0(a4)
    3fdc:	fbf60413          	addi	s0,a2,-65
    3fe0:	00178593          	addi	a1,a5,1
    3fe4:	00b71023          	sh	a1,0(a4)
    3fe8:	0ff47593          	zext.b	a1,s0
    3fec:	02bffa63          	bgeu	t6,a1,4020 <update_gpu_target+0x36c>
    3ff0:	fd060593          	addi	a1,a2,-48
    3ff4:	0ff5f593          	zext.b	a1,a1
    3ff8:	00900513          	li	a0,9
    3ffc:	fea60413          	addi	s0,a2,-22
    4000:	02b57063          	bgeu	a0,a1,4020 <update_gpu_target+0x36c>
    4004:	02d00593          	li	a1,45
    4008:	02400413          	li	s0,36
    400c:	00b60a63          	beq	a2,a1,4020 <update_gpu_target+0x36c>
    4010:	02e00593          	li	a1,46
    4014:	02600413          	li	s0,38
    4018:	00b61463          	bne	a2,a1,4020 <update_gpu_target+0x36c>
    401c:	02500413          	li	s0,37
    4020:	00579793          	slli	a5,a5,0x5
    4024:	00f907b3          	add	a5,s2,a5
    4028:	02000613          	li	a2,32
    402c:	00000593          	li	a1,0
    4030:	00078513          	mv	a0,a5
    4034:	01012623          	sw	a6,12(sp)
    4038:	00d12423          	sw	a3,8(sp)
    403c:	00e12223          	sw	a4,4(sp)
    4040:	01112023          	sw	a7,0(sp)
    4044:	9e4fd0ef          	jal	1228 <memset>
    4048:	1f800f13          	li	t5,504
    404c:	03e40433          	mul	s0,s0,t5
    4050:	00012883          	lw	a7,0(sp)
    4054:	00812683          	lw	a3,8(sp)
    4058:	01c00e93          	li	t4,28
    405c:	78000e13          	li	t3,1920
    4060:	00200313          	li	t1,2
    4064:	00c12803          	lw	a6,12(sp)
    4068:	00412703          	lw	a4,4(sp)
    406c:	01a52223          	sw	s10,4(a0)
    4070:	01d52423          	sw	t4,8(a0)
    4074:	01140433          	add	s0,s0,a7
    4078:	00852023          	sw	s0,0(a0)
    407c:	01c52623          	sw	t3,12(a0)
    4080:	00d52823          	sw	a3,16(a0)
    4084:	00650e23          	sb	t1,28(a0)
    4088:	01900f93          	li	t6,25
    408c:	d49ff06f          	j	3dd4 <update_gpu_target+0x120>

00004090 <hud_update_gpu_cache>:
    4090:	02c107b7          	lui	a5,0x2c10
    4094:	c21ff06f          	j	3cb4 <update_gpu_target>

00004098 <hud_render_gpu_direct>:
    4098:	00070813          	mv	a6,a4
    409c:	00078713          	mv	a4,a5
    40a0:	02060c63          	beqz	a2,40d8 <hud_render_gpu_direct+0x40>
    40a4:	ffe008b7          	lui	a7,0xffe00
    40a8:	fff88893          	addi	a7,a7,-1 # ffdfffff <__gpu_framebuffer_a+0xfddfffff>
    40ac:	011878b3          	and	a7,a6,a7
    40b0:	020007b7          	lui	a5,0x2000
    40b4:	02f89263          	bne	a7,a5,40d8 <hud_render_gpu_direct+0x40>
    40b8:	fde007b7          	lui	a5,0xfde00
    40bc:	00f807b3          	add	a5,a6,a5
    40c0:	00000893          	li	a7,0
    40c4:	00079463          	bnez	a5,40cc <hud_render_gpu_direct+0x34>
    40c8:	10800893          	li	a7,264
    40cc:	00080793          	mv	a5,a6
    40d0:	01160633          	add	a2,a2,a7
    40d4:	be1ff06f          	j	3cb4 <update_gpu_target>
    40d8:	ff800513          	li	a0,-8
    40dc:	00008067          	ret

000040e0 <asst_crc32>:
    40e0:	edb88737          	lui	a4,0xedb88
    40e4:	00b505b3          	add	a1,a0,a1
    40e8:	fff00793          	li	a5,-1
    40ec:	32070713          	addi	a4,a4,800 # edb88320 <__gpu_framebuffer_a+0xebb88320>
    40f0:	00b51663          	bne	a0,a1,40fc <asst_crc32+0x1c>
    40f4:	fff7c513          	not	a0,a5
    40f8:	00008067          	ret
    40fc:	00054683          	lbu	a3,0(a0)
    4100:	00150513          	addi	a0,a0,1
    4104:	00d7c7b3          	xor	a5,a5,a3
    4108:	00800693          	li	a3,8
    410c:	0017d613          	srli	a2,a5,0x1
    4110:	0017f793          	andi	a5,a5,1
    4114:	40f007b3          	neg	a5,a5
    4118:	00e7f7b3          	and	a5,a5,a4
    411c:	fff68693          	addi	a3,a3,-1
    4120:	00f647b3          	xor	a5,a2,a5
    4124:	fe0694e3          	bnez	a3,410c <asst_crc32+0x2c>
    4128:	fc9ff06f          	j	40f0 <asst_crc32+0x10>

0000412c <asst_encode>:
    412c:	00050793          	mv	a5,a0
    4130:	fff00513          	li	a0,-1
    4134:	14078063          	beqz	a5,4274 <asst_encode+0x148>
    4138:	12058e63          	beqz	a1,4274 <asst_encode+0x148>
    413c:	0005a683          	lw	a3,0(a1)
    4140:	41535737          	lui	a4,0x41535
    4144:	35470713          	addi	a4,a4,852 # 41535354 <__gpu_framebuffer_a+0x3f535354>
    4148:	12e69663          	bne	a3,a4,4274 <asst_encode+0x148>
    414c:	0185d683          	lhu	a3,24(a1)
    4150:	00100713          	li	a4,1
    4154:	12e69063          	bne	a3,a4,4274 <asst_encode+0x148>
    4158:	01c5d683          	lhu	a3,28(a1)
    415c:	40000713          	li	a4,1024
    4160:	10d76a63          	bltu	a4,a3,4274 <asst_encode+0x148>
    4164:	01e5d683          	lhu	a3,30(a1)
    4168:	00300713          	li	a4,3
    416c:	10d76463          	bltu	a4,a3,4274 <asst_encode+0x148>
    4170:	04100713          	li	a4,65
    4174:	00e78023          	sb	a4,0(a5) # fde00000 <__gpu_framebuffer_a+0xfbe00000>
    4178:	05300713          	li	a4,83
    417c:	00e780a3          	sb	a4,1(a5)
    4180:	00e78123          	sb	a4,2(a5)
    4184:	05400713          	li	a4,84
    4188:	00e781a3          	sb	a4,3(a5)
    418c:	0185d703          	lhu	a4,24(a1)
    4190:	00000513          	li	a0,0
    4194:	00875693          	srli	a3,a4,0x8
    4198:	00d78223          	sb	a3,4(a5)
    419c:	00e782a3          	sb	a4,5(a5)
    41a0:	01a5d703          	lhu	a4,26(a1)
    41a4:	00875693          	srli	a3,a4,0x8
    41a8:	00d78323          	sb	a3,6(a5)
    41ac:	00e783a3          	sb	a4,7(a5)
    41b0:	0045a703          	lw	a4,4(a1)
    41b4:	01875693          	srli	a3,a4,0x18
    41b8:	00d78423          	sb	a3,8(a5)
    41bc:	01075693          	srli	a3,a4,0x10
    41c0:	00d784a3          	sb	a3,9(a5)
    41c4:	00875693          	srli	a3,a4,0x8
    41c8:	00d78523          	sb	a3,10(a5)
    41cc:	00e785a3          	sb	a4,11(a5)
    41d0:	0085a703          	lw	a4,8(a1)
    41d4:	01875693          	srli	a3,a4,0x18
    41d8:	00d78623          	sb	a3,12(a5)
    41dc:	01075693          	srli	a3,a4,0x10
    41e0:	00d786a3          	sb	a3,13(a5)
    41e4:	00875693          	srli	a3,a4,0x8
    41e8:	00d78723          	sb	a3,14(a5)
    41ec:	00e787a3          	sb	a4,15(a5)
    41f0:	00c5a703          	lw	a4,12(a1)
    41f4:	01875693          	srli	a3,a4,0x18
    41f8:	00d78823          	sb	a3,16(a5)
    41fc:	01075693          	srli	a3,a4,0x10
    4200:	00d788a3          	sb	a3,17(a5)
    4204:	00875693          	srli	a3,a4,0x8
    4208:	00d78923          	sb	a3,18(a5)
    420c:	00e789a3          	sb	a4,19(a5)
    4210:	01c5d703          	lhu	a4,28(a1)
    4214:	00875693          	srli	a3,a4,0x8
    4218:	00d78a23          	sb	a3,20(a5)
    421c:	00e78aa3          	sb	a4,21(a5)
    4220:	01e5d703          	lhu	a4,30(a1)
    4224:	00875693          	srli	a3,a4,0x8
    4228:	00d78b23          	sb	a3,22(a5)
    422c:	00e78ba3          	sb	a4,23(a5)
    4230:	0105a703          	lw	a4,16(a1)
    4234:	01875693          	srli	a3,a4,0x18
    4238:	00d78c23          	sb	a3,24(a5)
    423c:	01075693          	srli	a3,a4,0x10
    4240:	00d78ca3          	sb	a3,25(a5)
    4244:	00875693          	srli	a3,a4,0x8
    4248:	00d78d23          	sb	a3,26(a5)
    424c:	00e78da3          	sb	a4,27(a5)
    4250:	0145a703          	lw	a4,20(a1)
    4254:	01875693          	srli	a3,a4,0x18
    4258:	00d78e23          	sb	a3,28(a5)
    425c:	01075693          	srli	a3,a4,0x10
    4260:	00d78ea3          	sb	a3,29(a5)
    4264:	00875693          	srli	a3,a4,0x8
    4268:	00d78f23          	sb	a3,30(a5)
    426c:	00e78fa3          	sb	a4,31(a5)
    4270:	00008067          	ret
    4274:	00008067          	ret

00004278 <asset_dma_start>:
    4278:	00050793          	mv	a5,a0
    427c:	fff00513          	li	a0,-1
    4280:	0a058063          	beqz	a1,4320 <asset_dma_start+0xa8>
    4284:	0a078263          	beqz	a5,4328 <asset_dma_start+0xb0>
    4288:	0005a603          	lw	a2,0(a1)
    428c:	08060e63          	beqz	a2,4328 <asset_dma_start+0xb0>
    4290:	0145a703          	lw	a4,20(a1)
    4294:	08070a63          	beqz	a4,4328 <asset_dma_start+0xb0>
    4298:	0045a683          	lw	a3,4(a1)
    429c:	0036f813          	andi	a6,a3,3
    42a0:	08081463          	bnez	a6,4328 <asset_dma_start+0xb0>
    42a4:	00c5a803          	lw	a6,12(a1)
    42a8:	00387893          	andi	a7,a6,3
    42ac:	06089e63          	bnez	a7,4328 <asset_dma_start+0xb0>
    42b0:	06e87c63          	bgeu	a6,a4,4328 <asset_dma_start+0xb0>
    42b4:	02400837          	lui	a6,0x2400
    42b8:	0706e863          	bltu	a3,a6,4328 <asset_dma_start+0xb0>
    42bc:	00e68733          	add	a4,a3,a4
    42c0:	06d76263          	bltu	a4,a3,4324 <asset_dma_start+0xac>
    42c4:	100006b7          	lui	a3,0x10000
    42c8:	04e6ee63          	bltu	a3,a4,4324 <asset_dma_start+0xac>
    42cc:	11c7a703          	lw	a4,284(a5)
    42d0:	ffe00513          	li	a0,-2
    42d4:	00177713          	andi	a4,a4,1
    42d8:	04071863          	bnez	a4,4328 <asset_dma_start+0xb0>
    42dc:	10c7a023          	sw	a2,256(a5)
    42e0:	0045a703          	lw	a4,4(a1)
    42e4:	10e7a223          	sw	a4,260(a5)
    42e8:	0085a703          	lw	a4,8(a1)
    42ec:	10e7a423          	sw	a4,264(a5)
    42f0:	00c5a703          	lw	a4,12(a1)
    42f4:	10e7a623          	sw	a4,268(a5)
    42f8:	0105a703          	lw	a4,16(a1)
    42fc:	10e7a823          	sw	a4,272(a5)
    4300:	0145a703          	lw	a4,20(a1)
    4304:	10e7aa23          	sw	a4,276(a5)
    4308:	0ff0000f          	fence
    430c:	00100713          	li	a4,1
    4310:	10e7ac23          	sw	a4,280(a5)
    4314:	0ff0000f          	fence
    4318:	00000513          	li	a0,0
    431c:	00008067          	ret
    4320:	00008067          	ret
    4324:	fff00513          	li	a0,-1
    4328:	00008067          	ret

0000432c <asset_dma_poll>:
    432c:	00050793          	mv	a5,a0
    4330:	fff00513          	li	a0,-1
    4334:	06078263          	beqz	a5,4398 <asset_dma_poll+0x6c>
    4338:	06058063          	beqz	a1,4398 <asset_dma_poll+0x6c>
    433c:	0ff0000f          	fence
    4340:	11c7a703          	lw	a4,284(a5)
    4344:	ffc00513          	li	a0,-4
    4348:	00e5a023          	sw	a4,0(a1)
    434c:	1207a683          	lw	a3,288(a5)
    4350:	00d5a223          	sw	a3,4(a1)
    4354:	1247a683          	lw	a3,292(a5)
    4358:	00d5a423          	sw	a3,8(a1)
    435c:	1287a683          	lw	a3,296(a5)
    4360:	00d5a623          	sw	a3,12(a1)
    4364:	12c7a683          	lw	a3,300(a5)
    4368:	00d5a823          	sw	a3,16(a1)
    436c:	1307a683          	lw	a3,304(a5)
    4370:	00d5aa23          	sw	a3,20(a1)
    4374:	1347a783          	lw	a5,308(a5)
    4378:	00f5ac23          	sw	a5,24(a1)
    437c:	00c77793          	andi	a5,a4,12
    4380:	00079c63          	bnez	a5,4398 <asset_dma_poll+0x6c>
    4384:	00277713          	andi	a4,a4,2
    4388:	00000513          	li	a0,0
    438c:	00071663          	bnez	a4,4398 <asset_dma_poll+0x6c>
    4390:	ffe00513          	li	a0,-2
    4394:	00008067          	ret
    4398:	00008067          	ret

0000439c <asset_dma_abort>:
    439c:	00050863          	beqz	a0,43ac <asset_dma_abort+0x10>
    43a0:	00200793          	li	a5,2
    43a4:	10f52c23          	sw	a5,280(a0)
    43a8:	0ff0000f          	fence
    43ac:	00008067          	ret

000043b0 <stop_dma>:
    43b0:	11c52783          	lw	a5,284(a0)
    43b4:	0017f793          	andi	a5,a5,1
    43b8:	0a078e63          	beqz	a5,4474 <stop_dma+0xc4>
    43bc:	fe010113          	addi	sp,sp,-32
    43c0:	00112e23          	sw	ra,28(sp)
    43c4:	00812c23          	sw	s0,24(sp)
    43c8:	00912a23          	sw	s1,20(sp)
    43cc:	00058413          	mv	s0,a1
    43d0:	01212823          	sw	s2,16(sp)
    43d4:	01312623          	sw	s3,12(sp)
    43d8:	01412423          	sw	s4,8(sp)
    43dc:	11c50993          	addi	s3,a0,284
    43e0:	fbdff0ef          	jal	439c <asset_dma_abort>
    43e4:	c44fd0ef          	jal	1828 <gpu_platform_cycles>
    43e8:	01400793          	li	a5,20
    43ec:	00058913          	mv	s2,a1
    43f0:	02f405b3          	mul	a1,s0,a5
    43f4:	00050493          	mv	s1,a0
    43f8:	3e800613          	li	a2,1000
    43fc:	00000693          	li	a3,0
    4400:	02f43433          	mulhu	s0,s0,a5
    4404:	3e758513          	addi	a0,a1,999
    4408:	00b535b3          	sltu	a1,a0,a1
    440c:	008585b3          	add	a1,a1,s0
    4410:	57c080ef          	jal	c98c <__udivdi3>
    4414:	00058413          	mv	s0,a1
    4418:	00050a13          	mv	s4,a0
    441c:	0009a783          	lw	a5,0(s3)
    4420:	0017f793          	andi	a5,a5,1
    4424:	04078463          	beqz	a5,446c <stop_dma+0xbc>
    4428:	c00fd0ef          	jal	1828 <gpu_platform_cycles>
    442c:	409506b3          	sub	a3,a0,s1
    4430:	00d53733          	sltu	a4,a0,a3
    4434:	412587b3          	sub	a5,a1,s2
    4438:	40e787b3          	sub	a5,a5,a4
    443c:	fe87e0e3          	bltu	a5,s0,441c <stop_dma+0x6c>
    4440:	00f41463          	bne	s0,a5,4448 <stop_dma+0x98>
    4444:	fd46ece3          	bltu	a3,s4,441c <stop_dma+0x6c>
    4448:	fea00513          	li	a0,-22
    444c:	01c12083          	lw	ra,28(sp)
    4450:	01812403          	lw	s0,24(sp)
    4454:	01412483          	lw	s1,20(sp)
    4458:	01012903          	lw	s2,16(sp)
    445c:	00c12983          	lw	s3,12(sp)
    4460:	00812a03          	lw	s4,8(sp)
    4464:	02010113          	addi	sp,sp,32
    4468:	00008067          	ret
    446c:	00000513          	li	a0,0
    4470:	fddff06f          	j	444c <stop_dma+0x9c>
    4474:	00000513          	li	a0,0
    4478:	00008067          	ret

0000447c <network_configure>:
    447c:	00050793          	mv	a5,a0
    4480:	fec00513          	li	a0,-20
    4484:	04078c63          	beqz	a5,44dc <network_configure+0x60>
    4488:	04058a63          	beqz	a1,44dc <network_configure+0x60>
    448c:	04060863          	beqz	a2,44dc <network_configure+0x60>
    4490:	04068663          	beqz	a3,44dc <network_configure+0x60>
    4494:	04070463          	beqz	a4,44dc <network_configure+0x60>
    4498:	2007a883          	lw	a7,512(a5)
    449c:	4e455837          	lui	a6,0x4e455
    44a0:	43180813          	addi	a6,a6,1073 # 4e455431 <__gpu_framebuffer_a+0x4c455431>
    44a4:	feb00513          	li	a0,-21
    44a8:	03089a63          	bne	a7,a6,44dc <network_configure+0x60>
    44ac:	2047a803          	lw	a6,516(a5)
    44b0:	fe900513          	li	a0,-23
    44b4:	00187813          	andi	a6,a6,1
    44b8:	02081263          	bnez	a6,44dc <network_configure+0x60>
    44bc:	20b7a623          	sw	a1,524(a5)
    44c0:	01071713          	slli	a4,a4,0x10
    44c4:	20c7a823          	sw	a2,528(a5)
    44c8:	00d766b3          	or	a3,a4,a3
    44cc:	20d7aa23          	sw	a3,532(a5)
    44d0:	0ff0000f          	fence
    44d4:	00000513          	li	a0,0
    44d8:	00008067          	ret
    44dc:	00008067          	ret

000044e0 <network_asset_fetch>:
    44e0:	f2010113          	addi	sp,sp,-224
    44e4:	0c112e23          	sw	ra,220(sp)
    44e8:	0c812c23          	sw	s0,216(sp)
    44ec:	0c912a23          	sw	s1,212(sp)
    44f0:	0d212823          	sw	s2,208(sp)
    44f4:	0d312623          	sw	s3,204(sp)
    44f8:	0d412423          	sw	s4,200(sp)
    44fc:	0d512223          	sw	s5,196(sp)
    4500:	0d612023          	sw	s6,192(sp)
    4504:	0b712e23          	sw	s7,188(sp)
    4508:	0b812c23          	sw	s8,184(sp)
    450c:	0b912a23          	sw	s9,180(sp)
    4510:	0ba12823          	sw	s10,176(sp)
    4514:	0bb12623          	sw	s11,172(sp)
    4518:	00c12a23          	sw	a2,20(sp)
    451c:	00d12e23          	sw	a3,28(sp)
    4520:	03012423          	sw	a6,40(sp)
    4524:	04089463          	bnez	a7,456c <network_asset_fetch+0x8c>
    4528:	fec00493          	li	s1,-20
    452c:	0dc12083          	lw	ra,220(sp)
    4530:	0d812403          	lw	s0,216(sp)
    4534:	0d012903          	lw	s2,208(sp)
    4538:	0cc12983          	lw	s3,204(sp)
    453c:	0c812a03          	lw	s4,200(sp)
    4540:	0c412a83          	lw	s5,196(sp)
    4544:	0c012b03          	lw	s6,192(sp)
    4548:	0bc12b83          	lw	s7,188(sp)
    454c:	0b812c03          	lw	s8,184(sp)
    4550:	0b412c83          	lw	s9,180(sp)
    4554:	0b012d03          	lw	s10,176(sp)
    4558:	0ac12d83          	lw	s11,172(sp)
    455c:	00048513          	mv	a0,s1
    4560:	0d412483          	lw	s1,212(sp)
    4564:	0e010113          	addi	sp,sp,224
    4568:	00008067          	ret
    456c:	00050413          	mv	s0,a0
    4570:	00058993          	mv	s3,a1
    4574:	01800613          	li	a2,24
    4578:	00000593          	li	a1,0
    457c:	00088513          	mv	a0,a7
    4580:	00070a93          	mv	s5,a4
    4584:	00078a13          	mv	s4,a5
    4588:	00088913          	mv	s2,a7
    458c:	c9dfc0ef          	jal	1228 <memset>
    4590:	f8040ce3          	beqz	s0,4528 <network_asset_fetch+0x48>
    4594:	f8098ae3          	beqz	s3,4528 <network_asset_fetch+0x48>
    4598:	01412783          	lw	a5,20(sp)
    459c:	f80786e3          	beqz	a5,4528 <network_asset_fetch+0x48>
    45a0:	f80a04e3          	beqz	s4,4528 <network_asset_fetch+0x48>
    45a4:	003af793          	andi	a5,s5,3
    45a8:	f80790e3          	bnez	a5,4528 <network_asset_fetch+0x48>
    45ac:	024007b7          	lui	a5,0x2400
    45b0:	f6faece3          	bltu	s5,a5,4528 <network_asset_fetch+0x48>
    45b4:	014a87b3          	add	a5,s5,s4
    45b8:	f757e8e3          	bltu	a5,s5,4528 <network_asset_fetch+0x48>
    45bc:	10000737          	lui	a4,0x10000
    45c0:	f6f764e3          	bltu	a4,a5,4528 <network_asset_fetch+0x48>
    45c4:	20042703          	lw	a4,512(s0)
    45c8:	4e4557b7          	lui	a5,0x4e455
    45cc:	43178793          	addi	a5,a5,1073 # 4e455431 <__gpu_framebuffer_a+0x4c455431>
    45d0:	feb00493          	li	s1,-21
    45d4:	f4f71ce3          	bne	a4,a5,452c <network_asset_fetch+0x4c>
    45d8:	a50fd0ef          	jal	1828 <gpu_platform_cycles>
    45dc:	01412783          	lw	a5,20(sp)
    45e0:	02a12623          	sw	a0,44(sp)
    45e4:	02b12823          	sw	a1,48(sp)
    45e8:	04f12423          	sw	a5,72(sp)
    45ec:	01c12783          	lw	a5,28(sp)
    45f0:	04810593          	addi	a1,sp,72
    45f4:	00040513          	mv	a0,s0
    45f8:	04012a23          	sw	zero,84(sp)
    45fc:	04012c23          	sw	zero,88(sp)
    4600:	05512623          	sw	s5,76(sp)
    4604:	04f12823          	sw	a5,80(sp)
    4608:	05412e23          	sw	s4,92(sp)
    460c:	c6dff0ef          	jal	4278 <asset_dma_start>
    4610:	00050493          	mv	s1,a0
    4614:	36051a63          	bnez	a0,4988 <network_asset_fetch+0x4a8>
    4618:	06400793          	li	a5,100
    461c:	02f985b3          	mul	a1,s3,a5
    4620:	3e800613          	li	a2,1000
    4624:	00000693          	li	a3,0
    4628:	00000b13          	li	s6,0
    462c:	02f9b7b3          	mulhu	a5,s3,a5
    4630:	3e758513          	addi	a0,a1,999
    4634:	00b535b3          	sltu	a1,a0,a1
    4638:	00f585b3          	add	a1,a1,a5
    463c:	350080ef          	jal	c98c <__udivdi3>
    4640:	01400793          	li	a5,20
    4644:	00b12623          	sw	a1,12(sp)
    4648:	02f985b3          	mul	a1,s3,a5
    464c:	02a12223          	sw	a0,36(sp)
    4650:	3e800613          	li	a2,1000
    4654:	00000693          	li	a3,0
    4658:	02f9b7b3          	mulhu	a5,s3,a5
    465c:	3e758513          	addi	a0,a1,999
    4660:	00b535b3          	sltu	a1,a0,a1
    4664:	00f585b3          	add	a1,a1,a5
    4668:	324080ef          	jal	c98c <__udivdi3>
    466c:	415357b7          	lui	a5,0x41535
    4670:	35478793          	addi	a5,a5,852 # 41535354 <__gpu_framebuffer_a+0x3f535354>
    4674:	02f12c23          	sw	a5,56(sp)
    4678:	000107b7          	lui	a5,0x10
    467c:	00178793          	addi	a5,a5,1 # 10001 <__global_pointer$+0x1281>
    4680:	02a12a23          	sw	a0,52(sp)
    4684:	02b12023          	sw	a1,32(sp)
    4688:	00012423          	sw	zero,8(sp)
    468c:	02f12e23          	sw	a5,60(sp)
    4690:	40000713          	li	a4,1024
    4694:	416a07b3          	sub	a5,s4,s6
    4698:	00e12823          	sw	a4,16(sp)
    469c:	00f76863          	bltu	a4,a5,46ac <network_asset_fetch+0x1cc>
    46a0:	01079793          	slli	a5,a5,0x10
    46a4:	0107d793          	srli	a5,a5,0x10
    46a8:	00f12823          	sw	a5,16(sp)
    46ac:	01012783          	lw	a5,16(sp)
    46b0:	00000b93          	li	s7,0
    46b4:	01678c33          	add	s8,a5,s6
    46b8:	00812783          	lw	a5,8(sp)
    46bc:	00178793          	addi	a5,a5,1
    46c0:	00f12c23          	sw	a5,24(sp)
    46c4:	11c42783          	lw	a5,284(s0)
    46c8:	000b9863          	bnez	s7,46d8 <network_asset_fetch+0x1f8>
    46cc:	00d7f793          	andi	a5,a5,13
    46d0:	00100713          	li	a4,1
    46d4:	06e78263          	beq	a5,a4,4738 <network_asset_fetch+0x258>
    46d8:	00098593          	mv	a1,s3
    46dc:	00040513          	mv	a0,s0
    46e0:	cd1ff0ef          	jal	43b0 <stop_dma>
    46e4:	00050c93          	mv	s9,a0
    46e8:	02051263          	bnez	a0,470c <network_asset_fetch+0x22c>
    46ec:	00812783          	lw	a5,8(sp)
    46f0:	04810593          	addi	a1,sp,72
    46f4:	00040513          	mv	a0,s0
    46f8:	05612a23          	sw	s6,84(sp)
    46fc:	04f12c23          	sw	a5,88(sp)
    4700:	b79ff0ef          	jal	4278 <asset_dma_start>
    4704:	02050a63          	beqz	a0,4738 <network_asset_fetch+0x258>
    4708:	fe900c93          	li	s9,-23
    470c:	00098593          	mv	a1,s3
    4710:	00040513          	mv	a0,s0
    4714:	c9dff0ef          	jal	43b0 <stop_dma>
    4718:	00050493          	mv	s1,a0
    471c:	22051e63          	bnez	a0,4958 <network_asset_fetch+0x478>
    4720:	000c8493          	mv	s1,s9
    4724:	2340006f          	j	4958 <network_asset_fetch+0x478>
    4728:	00892783          	lw	a5,8(s2)
    472c:	00178793          	addi	a5,a5,1
    4730:	00f92423          	sw	a5,8(s2)
    4734:	f91ff06f          	j	46c4 <network_asset_fetch+0x1e4>
    4738:	03812783          	lw	a5,56(sp)
    473c:	06010593          	addi	a1,sp,96
    4740:	08010513          	addi	a0,sp,128
    4744:	06f12023          	sw	a5,96(sp)
    4748:	01412783          	lw	a5,20(sp)
    474c:	07612623          	sw	s6,108(sp)
    4750:	06012a23          	sw	zero,116(sp)
    4754:	06f12223          	sw	a5,100(sp)
    4758:	01c12783          	lw	a5,28(sp)
    475c:	06f12423          	sw	a5,104(sp)
    4760:	00812783          	lw	a5,8(sp)
    4764:	06f12823          	sw	a5,112(sp)
    4768:	03c12783          	lw	a5,60(sp)
    476c:	06f12c23          	sw	a5,120(sp)
    4770:	01012783          	lw	a5,16(sp)
    4774:	06f11e23          	sh	a5,124(sp)
    4778:	017037b3          	snez	a5,s7
    477c:	00179793          	slli	a5,a5,0x1
    4780:	06f11f23          	sh	a5,126(sp)
    4784:	00492783          	lw	a5,4(s2)
    4788:	00178793          	addi	a5,a5,1
    478c:	00f92223          	sw	a5,4(s2)
    4790:	99dff0ef          	jal	412c <asst_encode>
    4794:	10051063          	bnez	a0,4894 <network_asset_fetch+0x3b4>
    4798:	890fd0ef          	jal	1828 <gpu_platform_cycles>
    479c:	00050d13          	mv	s10,a0
    47a0:	00058d93          	mv	s11,a1
    47a4:	00800613          	li	a2,8
    47a8:	20442783          	lw	a5,516(s0)
    47ac:	20440c93          	addi	s9,s0,516
    47b0:	0097f793          	andi	a5,a5,9
    47b4:	02c78c63          	beq	a5,a2,47ec <network_asset_fetch+0x30c>
    47b8:	870fd0ef          	jal	1828 <gpu_platform_cycles>
    47bc:	41a506b3          	sub	a3,a0,s10
    47c0:	00d53733          	sltu	a4,a0,a3
    47c4:	41b587b3          	sub	a5,a1,s11
    47c8:	40e787b3          	sub	a5,a5,a4
    47cc:	00c12703          	lw	a4,12(sp)
    47d0:	00800613          	li	a2,8
    47d4:	fce7eae3          	bltu	a5,a4,47a8 <network_asset_fetch+0x2c8>
    47d8:	00f71663          	bne	a4,a5,47e4 <network_asset_fetch+0x304>
    47dc:	02412783          	lw	a5,36(sp)
    47e0:	fcf6e4e3          	bltu	a3,a5,47a8 <network_asset_fetch+0x2c8>
    47e4:	fea00c93          	li	s9,-22
    47e8:	0b00006f          	j	4898 <network_asset_fetch+0x3b8>
    47ec:	08010713          	addi	a4,sp,128
    47f0:	22040693          	addi	a3,s0,544
    47f4:	24040593          	addi	a1,s0,576
    47f8:	00174783          	lbu	a5,1(a4) # 10000001 <__gpu_framebuffer_a+0xe000001>
    47fc:	00274603          	lbu	a2,2(a4)
    4800:	00468693          	addi	a3,a3,4 # 10000004 <__gpu_framebuffer_a+0xe000004>
    4804:	00879793          	slli	a5,a5,0x8
    4808:	01061613          	slli	a2,a2,0x10
    480c:	00c7e7b3          	or	a5,a5,a2
    4810:	00074603          	lbu	a2,0(a4)
    4814:	00470713          	addi	a4,a4,4
    4818:	00c7e7b3          	or	a5,a5,a2
    481c:	fff74603          	lbu	a2,-1(a4)
    4820:	01861613          	slli	a2,a2,0x18
    4824:	00c7e7b3          	or	a5,a5,a2
    4828:	fef6ae23          	sw	a5,-4(a3)
    482c:	fcd596e3          	bne	a1,a3,47f8 <network_asset_fetch+0x318>
    4830:	0ff0000f          	fence
    4834:	00100793          	li	a5,1
    4838:	20f42423          	sw	a5,520(s0)
    483c:	0ff0000f          	fence
    4840:	fe9fc0ef          	jal	1828 <gpu_platform_cycles>
    4844:	00050d13          	mv	s10,a0
    4848:	00058d93          	mv	s11,a1
    484c:	000ca783          	lw	a5,0(s9)
    4850:	0017f713          	andi	a4,a5,1
    4854:	00071a63          	bnez	a4,4868 <network_asset_fetch+0x388>
    4858:	0047f713          	andi	a4,a5,4
    485c:	12071263          	bnez	a4,4980 <network_asset_fetch+0x4a0>
    4860:	0027f793          	andi	a5,a5,2
    4864:	12079663          	bnez	a5,4990 <network_asset_fetch+0x4b0>
    4868:	fc1fc0ef          	jal	1828 <gpu_platform_cycles>
    486c:	41a506b3          	sub	a3,a0,s10
    4870:	00d53733          	sltu	a4,a0,a3
    4874:	41b587b3          	sub	a5,a1,s11
    4878:	40e787b3          	sub	a5,a5,a4
    487c:	00c12703          	lw	a4,12(sp)
    4880:	fce7e6e3          	bltu	a5,a4,484c <network_asset_fetch+0x36c>
    4884:	f6f710e3          	bne	a4,a5,47e4 <network_asset_fetch+0x304>
    4888:	02412783          	lw	a5,36(sp)
    488c:	fcf6e0e3          	bltu	a3,a5,484c <network_asset_fetch+0x36c>
    4890:	f55ff06f          	j	47e4 <network_asset_fetch+0x304>
    4894:	fec00c93          	li	s9,-20
    4898:	001b8b93          	addi	s7,s7,1
    489c:	00600793          	li	a5,6
    48a0:	e8fb94e3          	bne	s7,a5,4728 <network_asset_fetch+0x248>
    48a4:	0a0c8a63          	beqz	s9,4958 <network_asset_fetch+0x478>
    48a8:	e65ff06f          	j	470c <network_asset_fetch+0x22c>
    48ac:	0cfc6a63          	bltu	s8,a5,4980 <network_asset_fetch+0x4a0>
    48b0:	08812783          	lw	a5,136(sp)
    48b4:	01812703          	lw	a4,24(sp)
    48b8:	0cf76463          	bltu	a4,a5,4980 <network_asset_fetch+0x4a0>
    48bc:	f6dfc0ef          	jal	1828 <gpu_platform_cycles>
    48c0:	41a507b3          	sub	a5,a0,s10
    48c4:	02012703          	lw	a4,32(sp)
    48c8:	00f53533          	sltu	a0,a0,a5
    48cc:	419585b3          	sub	a1,a1,s9
    48d0:	40a585b3          	sub	a1,a1,a0
    48d4:	00e5e863          	bltu	a1,a4,48e4 <network_asset_fetch+0x404>
    48d8:	f0b716e3          	bne	a4,a1,47e4 <network_asset_fetch+0x304>
    48dc:	03412703          	lw	a4,52(sp)
    48e0:	f0e7f2e3          	bgeu	a5,a4,47e4 <network_asset_fetch+0x304>
    48e4:	08010593          	addi	a1,sp,128
    48e8:	00040513          	mv	a0,s0
    48ec:	a41ff0ef          	jal	432c <asset_dma_poll>
    48f0:	09b50863          	beq	a0,s11,4980 <network_asset_fetch+0x4a0>
    48f4:	08412783          	lw	a5,132(sp)
    48f8:	fb879ae3          	bne	a5,s8,48ac <network_asset_fetch+0x3cc>
    48fc:	08812783          	lw	a5,136(sp)
    4900:	01812703          	lw	a4,24(sp)
    4904:	fae796e3          	bne	a5,a4,48b0 <network_asset_fetch+0x3d0>
    4908:	11c42783          	lw	a5,284(s0)
    490c:	00c7f713          	andi	a4,a5,12
    4910:	06071863          	bnez	a4,4980 <network_asset_fetch+0x4a0>
    4914:	414c0733          	sub	a4,s8,s4
    4918:	0017d793          	srli	a5,a5,0x1
    491c:	00173713          	seqz	a4,a4
    4920:	0017f793          	andi	a5,a5,1
    4924:	04f71e63          	bne	a4,a5,4980 <network_asset_fetch+0x4a0>
    4928:	01812783          	lw	a5,24(sp)
    492c:	01892023          	sw	s8,0(s2)
    4930:	000c0b13          	mv	s6,s8
    4934:	00f12423          	sw	a5,8(sp)
    4938:	d54c6ce3          	bltu	s8,s4,4690 <network_asset_fetch+0x1b0>
    493c:	f11fc0ef          	jal	184c <gpu_platform_sync>
    4940:	000a0593          	mv	a1,s4
    4944:	000a8513          	mv	a0,s5
    4948:	f98ff0ef          	jal	40e0 <asst_crc32>
    494c:	02812783          	lw	a5,40(sp)
    4950:	fe800c93          	li	s9,-24
    4954:	daa79ce3          	bne	a5,a0,470c <network_asset_fetch+0x22c>
    4958:	ed1fc0ef          	jal	1828 <gpu_platform_cycles>
    495c:	02c12783          	lw	a5,44(sp)
    4960:	03012703          	lw	a4,48(sp)
    4964:	40f507b3          	sub	a5,a0,a5
    4968:	00f53533          	sltu	a0,a0,a5
    496c:	40e585b3          	sub	a1,a1,a4
    4970:	40a585b3          	sub	a1,a1,a0
    4974:	00f92823          	sw	a5,16(s2)
    4978:	00b92a23          	sw	a1,20(s2)
    497c:	bb1ff06f          	j	452c <network_asset_fetch+0x4c>
    4980:	fe900c93          	li	s9,-23
    4984:	f15ff06f          	j	4898 <network_asset_fetch+0x3b8>
    4988:	fe900493          	li	s1,-23
    498c:	ba1ff06f          	j	452c <network_asset_fetch+0x4c>
    4990:	e99fc0ef          	jal	1828 <gpu_platform_cycles>
    4994:	00050d13          	mv	s10,a0
    4998:	00058c93          	mv	s9,a1
    499c:	ffc00d93          	li	s11,-4
    49a0:	f45ff06f          	j	48e4 <network_asset_fetch+0x404>

000049a4 <perf_render_cpu>:
    49a4:	20050663          	beqz	a0,4bb0 <perf_render_cpu+0x20c>
    49a8:	fa010113          	addi	sp,sp,-96
    49ac:	04812c23          	sw	s0,88(sp)
    49b0:	04912a23          	sw	s1,84(sp)
    49b4:	04112e23          	sw	ra,92(sp)
    49b8:	05212823          	sw	s2,80(sp)
    49bc:	05312623          	sw	s3,76(sp)
    49c0:	05412423          	sw	s4,72(sp)
    49c4:	05512223          	sw	s5,68(sp)
    49c8:	05612023          	sw	s6,64(sp)
    49cc:	03712e23          	sw	s7,60(sp)
    49d0:	03812c23          	sw	s8,56(sp)
    49d4:	03912a23          	sw	s9,52(sp)
    49d8:	00050413          	mv	s0,a0
    49dc:	00058493          	mv	s1,a1
    49e0:	ff800513          	li	a0,-8
    49e4:	14058063          	beqz	a1,4b24 <perf_render_cpu+0x180>
    49e8:	000fda37          	lui	s4,0xfd
    49ec:	000fdab7          	lui	s5,0xfd
    49f0:	021c0b37          	lui	s6,0x21c0
    49f4:	00000993          	li	s3,0
    49f8:	02200bb7          	lui	s7,0x2200
    49fc:	02000c37          	lui	s8,0x2000
    4a00:	1ffa0a13          	addi	s4,s4,511 # fd1ff <__freertos_irq_stack_top+0xdf75f>
    4a04:	78000913          	li	s2,1920
    4a08:	200a8a93          	addi	s5,s5,512 # fd200 <__freertos_irq_stack_top+0xdf760>
    4a0c:	3c0b0b13          	addi	s6,s6,960 # 21c03c0 <__gpu_framebuffer_a+0x1c03c0>
    4a10:	00100c93          	li	s9,1
    4a14:	00442783          	lw	a5,4(s0)
    4a18:	0d77fa63          	bgeu	a5,s7,4aec <perf_render_cpu+0x148>
    4a1c:	0d87e463          	bltu	a5,s8,4ae4 <perf_render_cpu+0x140>
    4a20:	02000737          	lui	a4,0x2000
    4a24:	40e78633          	sub	a2,a5,a4
    4a28:	0aca6e63          	bltu	s4,a2,4ae4 <perf_render_cpu+0x140>
    4a2c:	00c42683          	lw	a3,12(s0)
    4a30:	0b269a63          	bne	a3,s2,4ae4 <perf_render_cpu+0x140>
    4a34:	0017f793          	andi	a5,a5,1
    4a38:	0a079663          	bnez	a5,4ae4 <perf_render_cpu+0x140>
    4a3c:	032675b3          	remu	a1,a2,s2
    4a40:	01245883          	lhu	a7,18(s0)
    4a44:	00e12823          	sw	a4,16(sp)
    4a48:	01512a23          	sw	s5,20(sp)
    4a4c:	01612c23          	sw	s6,24(sp)
    4a50:	01212e23          	sw	s2,28(sp)
    4a54:	00842303          	lw	t1,8(s0)
    4a58:	01045803          	lhu	a6,16(s0)
    4a5c:	03265633          	divu	a2,a2,s2
    4a60:	0015d593          	srli	a1,a1,0x1
    4a64:	01061613          	slli	a2,a2,0x10
    4a68:	01065613          	srli	a2,a2,0x10
    4a6c:	08088463          	beqz	a7,4af4 <perf_render_cpu+0x150>
    4a70:	fff88793          	addi	a5,a7,-1
    4a74:	02f30733          	mul	a4,t1,a5
    4a78:	0267a6b3          	mulhsu	a3,a5,t1
    4a7c:	00181793          	slli	a5,a6,0x1
    4a80:	00f707b3          	add	a5,a4,a5
    4a84:	00e7b733          	sltu	a4,a5,a4
    4a88:	00d70733          	add	a4,a4,a3
    4a8c:	00042503          	lw	a0,0(s0)
    4a90:	01c44683          	lbu	a3,28(s0)
    4a94:	02f12223          	sw	a5,36(sp)
    4a98:	02a12023          	sw	a0,32(sp)
    4a9c:	03011423          	sh	a6,40(sp)
    4aa0:	03111523          	sh	a7,42(sp)
    4aa4:	02612623          	sw	t1,44(sp)
    4aa8:	05968c63          	beq	a3,s9,4b00 <perf_render_cpu+0x15c>
    4aac:	02400337          	lui	t1,0x2400
    4ab0:	02656a63          	bltu	a0,t1,4ae4 <perf_render_cpu+0x140>
    4ab4:	00f507b3          	add	a5,a0,a5
    4ab8:	00a7b533          	sltu	a0,a5,a0
    4abc:	00e50533          	add	a0,a0,a4
    4ac0:	02051263          	bnez	a0,4ae4 <perf_render_cpu+0x140>
    4ac4:	10000737          	lui	a4,0x10000
    4ac8:	00f76e63          	bltu	a4,a5,4ae4 <perf_render_cpu+0x140>
    4acc:	00300793          	li	a5,3
    4ad0:	0af68063          	beq	a3,a5,4b70 <perf_render_cpu+0x1cc>
    4ad4:	00400793          	li	a5,4
    4ad8:	0af68c63          	beq	a3,a5,4b90 <perf_render_cpu+0x1ec>
    4adc:	00200793          	li	a5,2
    4ae0:	06f68c63          	beq	a3,a5,4b58 <perf_render_cpu+0x1b4>
    4ae4:	ff800513          	li	a0,-8
    4ae8:	03c0006f          	j	4b24 <perf_render_cpu+0x180>
    4aec:	02200737          	lui	a4,0x2200
    4af0:	f35ff06f          	j	4a24 <perf_render_cpu+0x80>
    4af4:	00000793          	li	a5,0
    4af8:	00000713          	li	a4,0
    4afc:	f91ff06f          	j	4a8c <perf_render_cpu+0xe8>
    4b00:	01445783          	lhu	a5,20(s0)
    4b04:	00088713          	mv	a4,a7
    4b08:	00080693          	mv	a3,a6
    4b0c:	01010513          	addi	a0,sp,16
    4b10:	cedfd0ef          	jal	27fc <golden_fill>
    4b14:	00051863          	bnez	a0,4b24 <perf_render_cpu+0x180>
    4b18:	00198993          	addi	s3,s3,1
    4b1c:	02040413          	addi	s0,s0,32
    4b20:	ef349ae3          	bne	s1,s3,4a14 <perf_render_cpu+0x70>
    4b24:	05c12083          	lw	ra,92(sp)
    4b28:	05812403          	lw	s0,88(sp)
    4b2c:	05412483          	lw	s1,84(sp)
    4b30:	05012903          	lw	s2,80(sp)
    4b34:	04c12983          	lw	s3,76(sp)
    4b38:	04812a03          	lw	s4,72(sp)
    4b3c:	04412a83          	lw	s5,68(sp)
    4b40:	04012b03          	lw	s6,64(sp)
    4b44:	03c12b83          	lw	s7,60(sp)
    4b48:	03812c03          	lw	s8,56(sp)
    4b4c:	03412c83          	lw	s9,52(sp)
    4b50:	06010113          	addi	sp,sp,96
    4b54:	00008067          	ret
    4b58:	00000793          	li	a5,0
    4b5c:	00000713          	li	a4,0
    4b60:	02010693          	addi	a3,sp,32
    4b64:	01010513          	addi	a0,sp,16
    4b68:	d75fd0ef          	jal	28dc <golden_copy>
    4b6c:	fa9ff06f          	j	4b14 <perf_render_cpu+0x170>
    4b70:	01645783          	lhu	a5,22(s0)
    4b74:	00000713          	li	a4,0
    4b78:	02010693          	addi	a3,sp,32
    4b7c:	00f12023          	sw	a5,0(sp)
    4b80:	01010513          	addi	a0,sp,16
    4b84:	00000793          	li	a5,0
    4b88:	f0dfd0ef          	jal	2a94 <golden_color_key>
    4b8c:	f89ff06f          	j	4b14 <perf_render_cpu+0x170>
    4b90:	01d44783          	lbu	a5,29(s0)
    4b94:	00000713          	li	a4,0
    4b98:	02010693          	addi	a3,sp,32
    4b9c:	00f12023          	sw	a5,0(sp)
    4ba0:	01010513          	addi	a0,sp,16
    4ba4:	00000793          	li	a5,0
    4ba8:	fc1fd0ef          	jal	2b68 <golden_alpha_blend>
    4bac:	f69ff06f          	j	4b14 <perf_render_cpu+0x170>
    4bb0:	ff800513          	li	a0,-8
    4bb4:	00008067          	ret

00004bb8 <perf_render_gpu>:
    4bb8:	08050863          	beqz	a0,4c48 <perf_render_gpu+0x90>
    4bbc:	fc010113          	addi	sp,sp,-64
    4bc0:	02812c23          	sw	s0,56(sp)
    4bc4:	03312623          	sw	s3,44(sp)
    4bc8:	02112e23          	sw	ra,60(sp)
    4bcc:	02912a23          	sw	s1,52(sp)
    4bd0:	03212823          	sw	s2,48(sp)
    4bd4:	00050413          	mv	s0,a0
    4bd8:	00058993          	mv	s3,a1
    4bdc:	ff800513          	li	a0,-8
    4be0:	04058663          	beqz	a1,4c2c <perf_render_gpu+0x74>
    4be4:	00060913          	mv	s2,a2
    4be8:	04060263          	beqz	a2,4c2c <perf_render_gpu+0x74>
    4bec:	00068613          	mv	a2,a3
    4bf0:	00011f23          	sh	zero,30(sp)
    4bf4:	00000493          	li	s1,0
    4bf8:	00549593          	slli	a1,s1,0x5
    4bfc:	01e10693          	addi	a3,sp,30
    4c00:	00b985b3          	add	a1,s3,a1
    4c04:	00040513          	mv	a0,s0
    4c08:	00c12623          	sw	a2,12(sp)
    4c0c:	a7cfd0ef          	jal	1e88 <gpu_submit>
    4c10:	00051e63          	bnez	a0,4c2c <perf_render_gpu+0x74>
    4c14:	00148493          	addi	s1,s1,1
    4c18:	00c12603          	lw	a2,12(sp)
    4c1c:	fc991ee3          	bne	s2,s1,4bf8 <perf_render_gpu+0x40>
    4c20:	01e15583          	lhu	a1,30(sp)
    4c24:	00040513          	mv	a0,s0
    4c28:	fa0fd0ef          	jal	23c8 <gpu_wait_tag>
    4c2c:	03c12083          	lw	ra,60(sp)
    4c30:	03812403          	lw	s0,56(sp)
    4c34:	03412483          	lw	s1,52(sp)
    4c38:	03012903          	lw	s2,48(sp)
    4c3c:	02c12983          	lw	s3,44(sp)
    4c40:	04010113          	addi	sp,sp,64
    4c44:	00008067          	ret
    4c48:	ff800513          	li	a0,-8
    4c4c:	00008067          	ret

00004c50 <perf_window_add>:
    4c50:	00050793          	mv	a5,a0
    4c54:	0a050263          	beqz	a0,4cf8 <perf_window_add+0xa8>
    4c58:	00c5e833          	or	a6,a1,a2
    4c5c:	ff800513          	li	a0,-8
    4c60:	08080e63          	beqz	a6,4cfc <perf_window_add+0xac>
    4c64:	08e66a63          	bltu	a2,a4,4cf8 <perf_window_add+0xa8>
    4c68:	00c71463          	bne	a4,a2,4c70 <perf_window_add+0x20>
    4c6c:	08d5e663          	bltu	a1,a3,4cf8 <perf_window_add+0xa8>
    4c70:	0107a883          	lw	a7,16(a5)
    4c74:	01d00813          	li	a6,29
    4c78:	ff800513          	li	a0,-8
    4c7c:	09186063          	bltu	a6,a7,4cfc <perf_window_add+0xac>
    4c80:	0047ae03          	lw	t3,4(a5)
    4c84:	0007a803          	lw	a6,0(a5)
    4c88:	fffe4513          	not	a0,t3
    4c8c:	fff84313          	not	t1,a6
    4c90:	06c56463          	bltu	a0,a2,4cf8 <perf_window_add+0xa8>
    4c94:	00a61463          	bne	a2,a0,4c9c <perf_window_add+0x4c>
    4c98:	06b36063          	bltu	t1,a1,4cf8 <perf_window_add+0xa8>
    4c9c:	00c7a303          	lw	t1,12(a5)
    4ca0:	0087a503          	lw	a0,8(a5)
    4ca4:	fff34e93          	not	t4,t1
    4ca8:	fff54f13          	not	t5,a0
    4cac:	04eee663          	bltu	t4,a4,4cf8 <perf_window_add+0xa8>
    4cb0:	01d71463          	bne	a4,t4,4cb8 <perf_window_add+0x68>
    4cb4:	04df6263          	bltu	t5,a3,4cf8 <perf_window_add+0xa8>
    4cb8:	00b805b3          	add	a1,a6,a1
    4cbc:	00d506b3          	add	a3,a0,a3
    4cc0:	0105b833          	sltu	a6,a1,a6
    4cc4:	00ce0e33          	add	t3,t3,a2
    4cc8:	00a6b533          	sltu	a0,a3,a0
    4ccc:	00e30333          	add	t1,t1,a4
    4cd0:	00650533          	add	a0,a0,t1
    4cd4:	01c80833          	add	a6,a6,t3
    4cd8:	00188893          	addi	a7,a7,1
    4cdc:	00a7a623          	sw	a0,12(a5)
    4ce0:	00b7a023          	sw	a1,0(a5)
    4ce4:	0107a223          	sw	a6,4(a5)
    4ce8:	00d7a423          	sw	a3,8(a5)
    4cec:	0117a823          	sw	a7,16(a5)
    4cf0:	00000513          	li	a0,0
    4cf4:	00008067          	ret
    4cf8:	ff800513          	li	a0,-8
    4cfc:	00008067          	ret

00004d00 <perf_fps_x10>:
    4d00:	00050793          	mv	a5,a0
    4d04:	06050663          	beqz	a0,4d70 <perf_fps_x10+0x70>
    4d08:	00052603          	lw	a2,0(a0)
    4d0c:	00452683          	lw	a3,4(a0)
    4d10:	00d66733          	or	a4,a2,a3
    4d14:	04070e63          	beqz	a4,4d70 <perf_fps_x10+0x70>
    4d18:	00058513          	mv	a0,a1
    4d1c:	0107a583          	lw	a1,16(a5)
    4d20:	01d00793          	li	a5,29
    4d24:	fff58713          	addi	a4,a1,-1
    4d28:	04e7e463          	bltu	a5,a4,4d70 <perf_fps_x10+0x70>
    4d2c:	04050a63          	beqz	a0,4d80 <perf_fps_x10+0x80>
    4d30:	02a58733          	mul	a4,a1,a0
    4d34:	ff010113          	addi	sp,sp,-16
    4d38:	00112623          	sw	ra,12(sp)
    4d3c:	02a5b5b3          	mulhu	a1,a1,a0
    4d40:	00a00513          	li	a0,10
    4d44:	02b505b3          	mul	a1,a0,a1
    4d48:	02e53833          	mulhu	a6,a0,a4
    4d4c:	02e50533          	mul	a0,a0,a4
    4d50:	010585b3          	add	a1,a1,a6
    4d54:	439070ef          	jal	c98c <__udivdi3>
    4d58:	02059063          	bnez	a1,4d78 <perf_fps_x10+0x78>
    4d5c:	ffe00793          	li	a5,-2
    4d60:	00a7ec63          	bltu	a5,a0,4d78 <perf_fps_x10+0x78>
    4d64:	00c12083          	lw	ra,12(sp)
    4d68:	01010113          	addi	sp,sp,16
    4d6c:	00008067          	ret
    4d70:	00000513          	li	a0,0
    4d74:	00008067          	ret
    4d78:	fff00513          	li	a0,-1
    4d7c:	fe9ff06f          	j	4d64 <perf_fps_x10+0x64>
    4d80:	00008067          	ret

00004d84 <perf_render_us>:
    4d84:	00050793          	mv	a5,a0
    4d88:	0e050063          	beqz	a0,4e68 <perf_render_us+0xe4>
    4d8c:	01052703          	lw	a4,16(a0)
    4d90:	01d00693          	li	a3,29
    4d94:	fff70613          	addi	a2,a4,-1 # 21fffff <__gpu_framebuffer_a+0x1fffff>
    4d98:	0cc6e863          	bltu	a3,a2,4e68 <perf_render_us+0xe4>
    4d9c:	00058513          	mv	a0,a1
    4da0:	0c058c63          	beqz	a1,4e78 <perf_render_us+0xf4>
    4da4:	02b70633          	mul	a2,a4,a1
    4da8:	fe010113          	addi	sp,sp,-32
    4dac:	01212a23          	sw	s2,20(sp)
    4db0:	01312823          	sw	s3,16(sp)
    4db4:	0087a903          	lw	s2,8(a5)
    4db8:	00c7a983          	lw	s3,12(a5)
    4dbc:	00812c23          	sw	s0,24(sp)
    4dc0:	00090513          	mv	a0,s2
    4dc4:	00112e23          	sw	ra,28(sp)
    4dc8:	02b736b3          	mulhu	a3,a4,a1
    4dcc:	00098593          	mv	a1,s3
    4dd0:	00c12623          	sw	a2,12(sp)
    4dd4:	00d12423          	sw	a3,8(sp)
    4dd8:	3b5070ef          	jal	c98c <__udivdi3>
    4ddc:	00050413          	mv	s0,a0
    4de0:	08059863          	bnez	a1,4e70 <perf_render_us+0xec>
    4de4:	000017b7          	lui	a5,0x1
    4de8:	0c678793          	addi	a5,a5,198 # 10c6 <memcmp+0x5a>
    4dec:	08a7e263          	bltu	a5,a0,4e70 <perf_render_us+0xec>
    4df0:	00c12603          	lw	a2,12(sp)
    4df4:	00812683          	lw	a3,8(sp)
    4df8:	00090513          	mv	a0,s2
    4dfc:	00098593          	mv	a1,s3
    4e00:	000f4937          	lui	s2,0xf4
    4e04:	038080ef          	jal	ce3c <__umoddi3>
    4e08:	24090913          	addi	s2,s2,576 # f4240 <__freertos_irq_stack_top+0xd67a0>
    4e0c:	032537b3          	mulhu	a5,a0,s2
    4e10:	00c12603          	lw	a2,12(sp)
    4e14:	00812683          	lw	a3,8(sp)
    4e18:	032585b3          	mul	a1,a1,s2
    4e1c:	03250533          	mul	a0,a0,s2
    4e20:	00f585b3          	add	a1,a1,a5
    4e24:	369070ef          	jal	c98c <__udivdi3>
    4e28:	028907b3          	mul	a5,s2,s0
    4e2c:	00050713          	mv	a4,a0
    4e30:	03243433          	mulhu	s0,s0,s2
    4e34:	00f50533          	add	a0,a0,a5
    4e38:	00e53733          	sltu	a4,a0,a4
    4e3c:	008585b3          	add	a1,a1,s0
    4e40:	00b70733          	add	a4,a4,a1
    4e44:	02071663          	bnez	a4,4e70 <perf_render_us+0xec>
    4e48:	ffe00793          	li	a5,-2
    4e4c:	02a7e263          	bltu	a5,a0,4e70 <perf_render_us+0xec>
    4e50:	01c12083          	lw	ra,28(sp)
    4e54:	01812403          	lw	s0,24(sp)
    4e58:	01412903          	lw	s2,20(sp)
    4e5c:	01012983          	lw	s3,16(sp)
    4e60:	02010113          	addi	sp,sp,32
    4e64:	00008067          	ret
    4e68:	00000513          	li	a0,0
    4e6c:	00008067          	ret
    4e70:	fff00513          	li	a0,-1
    4e74:	fddff06f          	j	4e50 <perf_render_us+0xcc>
    4e78:	00008067          	ret

00004e7c <append>:
    4e7c:	ff010113          	addi	sp,sp,-16
    4e80:	00812423          	sw	s0,8(sp)
    4e84:	00009437          	lui	s0,0x9
    4e88:	00850433          	add	s0,a0,s0
    4e8c:	12042783          	lw	a5,288(s0) # 9120 <v3_runtime_advance+0xa8>
    4e90:	00112623          	sw	ra,12(sp)
    4e94:	00912223          	sw	s1,4(sp)
    4e98:	06b78e63          	beq	a5,a1,4f14 <append+0x98>
    4e9c:	00060493          	mv	s1,a2
    4ea0:	00178713          	addi	a4,a5,1
    4ea4:	00579793          	slli	a5,a5,0x5
    4ea8:	12e42023          	sw	a4,288(s0)
    4eac:	00f50533          	add	a0,a0,a5
    4eb0:	02000613          	li	a2,32
    4eb4:	00048593          	mv	a1,s1
    4eb8:	c4cfc0ef          	jal	1304 <memcpy>
    4ebc:	0124d703          	lhu	a4,18(s1)
    4ec0:	0104d783          	lhu	a5,16(s1)
    4ec4:	02e787b3          	mul	a5,a5,a4
    4ec8:	12842703          	lw	a4,296(s0)
    4ecc:	00f70733          	add	a4,a4,a5
    4ed0:	12e42423          	sw	a4,296(s0)
    4ed4:	01c4c683          	lbu	a3,28(s1)
    4ed8:	00400713          	li	a4,4
    4edc:	00e68e63          	beq	a3,a4,4ef8 <append+0x7c>
    4ee0:	00000513          	li	a0,0
    4ee4:	00c12083          	lw	ra,12(sp)
    4ee8:	00812403          	lw	s0,8(sp)
    4eec:	00412483          	lw	s1,4(sp)
    4ef0:	01010113          	addi	sp,sp,16
    4ef4:	00008067          	ret
    4ef8:	12c42703          	lw	a4,300(s0)
    4efc:	00170713          	addi	a4,a4,1
    4f00:	12e42623          	sw	a4,300(s0)
    4f04:	13042703          	lw	a4,304(s0)
    4f08:	00f707b3          	add	a5,a4,a5
    4f0c:	12f42823          	sw	a5,304(s0)
    4f10:	fd1ff06f          	j	4ee0 <append+0x64>
    4f14:	ffc00513          	li	a0,-4
    4f18:	fcdff06f          	j	4ee4 <append+0x68>

00004f1c <pixel_coordinate>:
    4f1c:	00050793          	mv	a5,a0
    4f20:	10000513          	li	a0,256
    4f24:	02a7c533          	div	a0,a5,a0
    4f28:	0007d863          	bgez	a5,4f38 <pixel_coordinate+0x1c>
    4f2c:	0ff7f793          	zext.b	a5,a5
    4f30:	00078463          	beqz	a5,4f38 <pixel_coordinate+0x1c>
    4f34:	fff50513          	addi	a0,a0,-1
    4f38:	00008067          	ret

00004f3c <bullet_campaign_valid>:
    4f3c:	06050a63          	beqz	a0,4fb0 <bullet_campaign_valid+0x74>
    4f40:	000057b7          	lui	a5,0x5
    4f44:	00f507b3          	add	a5,a0,a5
    4f48:	0287c803          	lbu	a6,40(a5) # 5028 <bullet_enemy_position+0x70>
    4f4c:	00100713          	li	a4,1
    4f50:	00000513          	li	a0,0
    4f54:	07076063          	bltu	a4,a6,4fb4 <bullet_campaign_valid+0x78>
    4f58:	0297c603          	lbu	a2,41(a5)
    4f5c:	04c76c63          	bltu	a4,a2,4fb4 <bullet_campaign_valid+0x78>
    4f60:	0257c703          	lbu	a4,37(a5)
    4f64:	00600593          	li	a1,6
    4f68:	04e5e663          	bltu	a1,a4,4fb4 <bullet_campaign_valid+0x78>
    4f6c:	0267c683          	lbu	a3,38(a5)
    4f70:	04d5e263          	bltu	a1,a3,4fb4 <bullet_campaign_valid+0x78>
    4f74:	00d766b3          	or	a3,a4,a3
    4f78:	0277c703          	lbu	a4,39(a5)
    4f7c:	02e5ec63          	bltu	a1,a4,4fb4 <bullet_campaign_valid+0x78>
    4f80:	00d76733          	or	a4,a4,a3
    4f84:	00081863          	bnez	a6,4f94 <bullet_campaign_valid+0x58>
    4f88:	02071663          	bnez	a4,4fb4 <bullet_campaign_valid+0x78>
    4f8c:	00164513          	xori	a0,a2,1
    4f90:	00008067          	ret
    4f94:	00e03533          	snez	a0,a4
    4f98:	00060e63          	beqz	a2,4fb4 <bullet_campaign_valid+0x78>
    4f9c:	00000513          	li	a0,0
    4fa0:	00071a63          	bnez	a4,4fb4 <bullet_campaign_valid+0x78>
    4fa4:	0247c503          	lbu	a0,36(a5)
    4fa8:	00a03533          	snez	a0,a0
    4fac:	00008067          	ret
    4fb0:	00000513          	li	a0,0
    4fb4:	00008067          	ret

00004fb8 <bullet_enemy_position>:
    4fb8:	00050793          	mv	a5,a0
    4fbc:	14050a63          	beqz	a0,5110 <bullet_enemy_position+0x158>
    4fc0:	00200713          	li	a4,2
    4fc4:	ff800513          	li	a0,-8
    4fc8:	14b76663          	bltu	a4,a1,5114 <bullet_enemy_position+0x15c>
    4fcc:	14060463          	beqz	a2,5114 <bullet_enemy_position+0x15c>
    4fd0:	14068263          	beqz	a3,5114 <bullet_enemy_position+0x15c>
    4fd4:	0000e737          	lui	a4,0xe
    4fd8:	00359513          	slli	a0,a1,0x3
    4fdc:	cf070713          	addi	a4,a4,-784 # dcf0 <centers>
    4fe0:	00a70733          	add	a4,a4,a0
    4fe4:	00072503          	lw	a0,0(a4)
    4fe8:	00472303          	lw	t1,4(a4)
    4fec:	00005737          	lui	a4,0x5
    4ff0:	00a62023          	sw	a0,0(a2)
    4ff4:	0066a023          	sw	t1,0(a3)
    4ff8:	00e78533          	add	a0,a5,a4
    4ffc:	02854783          	lbu	a5,40(a0)
    5000:	00078663          	beqz	a5,500c <bullet_enemy_position+0x54>
    5004:	01452f83          	lw	t6,20(a0)
    5008:	000f9663          	bnez	t6,5014 <bullet_enemy_position+0x5c>
    500c:	00000513          	li	a0,0
    5010:	00008067          	ret
    5014:	07800813          	li	a6,120
    5018:	030fd733          	divu	a4,t6,a6
    501c:	9e3787b7          	lui	a5,0x9e378
    5020:	00158893          	addi	a7,a1,1
    5024:	9b978793          	addi	a5,a5,-1607 # 9e3779b9 <__gpu_framebuffer_a+0x9c3779b9>
    5028:	85ebdf37          	lui	t5,0x85ebd
    502c:	a6bf0f13          	addi	t5,t5,-1429 # 85ebca6b <__gpu_framebuffer_a+0x83ebca6b>
    5030:	7feb3eb7          	lui	t4,0x7feb3
    5034:	52de8e93          	addi	t4,t4,1325 # 7feb352d <__gpu_framebuffer_a+0x7deb352d>
    5038:	0000ee37          	lui	t3,0xe
    503c:	ce4e0e13          	addi	t3,t3,-796 # dce4 <minimum_y.2>
    5040:	00259593          	slli	a1,a1,0x2
    5044:	00be05b3          	add	a1,t3,a1
    5048:	07700293          	li	t0,119
    504c:	0005a583          	lw	a1,0(a1)
    5050:	02f888b3          	mul	a7,a7,a5
    5054:	00052783          	lw	a5,0(a0)
    5058:	00f8c8b3          	xor	a7,a7,a5
    505c:	03e707b3          	mul	a5,a4,t5
    5060:	0117c7b3          	xor	a5,a5,a7
    5064:	0107d513          	srli	a0,a5,0x10
    5068:	00a7c7b3          	xor	a5,a5,a0
    506c:	03d787b3          	mul	a5,a5,t4
    5070:	00f7d513          	srli	a0,a5,0xf
    5074:	00a7c7b3          	xor	a5,a5,a0
    5078:	00062503          	lw	a0,0(a2)
    507c:	030ff833          	remu	a6,t6,a6
    5080:	f8850e13          	addi	t3,a0,-120
    5084:	05f2f063          	bgeu	t0,t6,50c4 <bullet_enemy_position+0x10c>
    5088:	fff70713          	addi	a4,a4,-1 # 4fff <bullet_enemy_position+0x47>
    508c:	03e70733          	mul	a4,a4,t5
    5090:	01174733          	xor	a4,a4,a7
    5094:	01075513          	srli	a0,a4,0x10
    5098:	00a74733          	xor	a4,a4,a0
    509c:	03d70733          	mul	a4,a4,t4
    50a0:	06100893          	li	a7,97
    50a4:	00f75513          	srli	a0,a4,0xf
    50a8:	00a74733          	xor	a4,a4,a0
    50ac:	0f100513          	li	a0,241
    50b0:	02a77533          	remu	a0,a4,a0
    50b4:	01075713          	srli	a4,a4,0x10
    50b8:	03177733          	remu	a4,a4,a7
    50bc:	01c50533          	add	a0,a0,t3
    50c0:	00b70333          	add	t1,a4,a1
    50c4:	0f100713          	li	a4,241
    50c8:	02e7f733          	remu	a4,a5,a4
    50cc:	07800893          	li	a7,120
    50d0:	0107d793          	srli	a5,a5,0x10
    50d4:	01c70733          	add	a4,a4,t3
    50d8:	40a70733          	sub	a4,a4,a0
    50dc:	03070733          	mul	a4,a4,a6
    50e0:	03174733          	div	a4,a4,a7
    50e4:	00a70733          	add	a4,a4,a0
    50e8:	00e62023          	sw	a4,0(a2)
    50ec:	06100713          	li	a4,97
    50f0:	02e7f7b3          	remu	a5,a5,a4
    50f4:	00b787b3          	add	a5,a5,a1
    50f8:	406787b3          	sub	a5,a5,t1
    50fc:	030787b3          	mul	a5,a5,a6
    5100:	0317c7b3          	div	a5,a5,a7
    5104:	006787b3          	add	a5,a5,t1
    5108:	00f6a023          	sw	a5,0(a3)
    510c:	f01ff06f          	j	500c <bullet_enemy_position+0x54>
    5110:	ff800513          	li	a0,-8
    5114:	00008067          	ret

00005118 <spawn>:
    5118:	000057b7          	lui	a5,0x5
    511c:	fc010113          	addi	sp,sp,-64
    5120:	00f507b3          	add	a5,a0,a5
    5124:	02812c23          	sw	s0,56(sp)
    5128:	0147a403          	lw	s0,20(a5) # 5014 <bullet_enemy_position+0x5c>
    512c:	03c00713          	li	a4,60
    5130:	03512223          	sw	s5,36(sp)
    5134:	02e45733          	divu	a4,s0,a4
    5138:	00300a93          	li	s5,3
    513c:	01712e23          	sw	s7,28(sp)
    5140:	02912a23          	sw	s1,52(sp)
    5144:	03212823          	sw	s2,48(sp)
    5148:	03412423          	sw	s4,40(sp)
    514c:	03612023          	sw	s6,32(sp)
    5150:	01912a23          	sw	s9,20(sp)
    5154:	02112e23          	sw	ra,60(sp)
    5158:	03312623          	sw	s3,44(sp)
    515c:	01812c23          	sw	s8,24(sp)
    5160:	0007a483          	lw	s1,0(a5)
    5164:	00050a13          	mv	s4,a0
    5168:	00058913          	mv	s2,a1
    516c:	00000c93          	li	s9,0
    5170:	0355fbb3          	remu	s7,a1,s5
    5174:	00377b13          	andi	s6,a4,3
    5178:	00200713          	li	a4,2
    517c:	0355dab3          	divu	s5,a1,s5
    5180:	00eb9663          	bne	s7,a4,518c <spawn+0x74>
    5184:	0047ac83          	lw	s9,4(a5)
    5188:	003cdc93          	srli	s9,s9,0x3
    518c:	00000993          	li	s3,0
    5190:	00060e63          	beqz	a2,51ac <spawn+0x94>
    5194:	03000993          	li	s3,48
    5198:	00a00793          	li	a5,10
    519c:	033959b3          	divu	s3,s2,s3
    51a0:	02f9f9b3          	remu	s3,s3,a5
    51a4:	00198993          	addi	s3,s3,1
    51a8:	00499993          	slli	s3,s3,0x4
    51ac:	00100713          	li	a4,1
    51b0:	0f000793          	li	a5,240
    51b4:	00eb8a63          	beq	s7,a4,51c8 <spawn+0xb0>
    51b8:	00200713          	li	a4,2
    51bc:	1e000793          	li	a5,480
    51c0:	00eb9463          	bne	s7,a4,51c8 <spawn+0xb0>
    51c4:	2d000793          	li	a5,720
    51c8:	00f12423          	sw	a5,8(sp)
    51cc:	00100713          	li	a4,1
    51d0:	06400793          	li	a5,100
    51d4:	00eb8a63          	beq	s7,a4,51e8 <spawn+0xd0>
    51d8:	00200713          	li	a4,2
    51dc:	11800793          	li	a5,280
    51e0:	00eb9463          	bne	s7,a4,51e8 <spawn+0xd0>
    51e4:	0dc00793          	li	a5,220
    51e8:	00f12623          	sw	a5,12(sp)
    51ec:	000057b7          	lui	a5,0x5
    51f0:	00fa07b3          	add	a5,s4,a5
    51f4:	0287cc03          	lbu	s8,40(a5) # 5028 <bullet_enemy_position+0x70>
    51f8:	000c0c63          	beqz	s8,5210 <spawn+0xf8>
    51fc:	00c10693          	addi	a3,sp,12
    5200:	00810613          	addi	a2,sp,8
    5204:	000b8593          	mv	a1,s7
    5208:	000a0513          	mv	a0,s4
    520c:	dadff0ef          	jal	4fb8 <bullet_enemy_position>
    5210:	00100793          	li	a5,1
    5214:	0efb8e63          	beq	s7,a5,5310 <spawn+0x1f8>
    5218:	0074c793          	xori	a5,s1,7
    521c:	015787b3          	add	a5,a5,s5
    5220:	002b1713          	slli	a4,s6,0x2
    5224:	00e787b3          	add	a5,a5,a4
    5228:	019787b3          	add	a5,a5,s9
    522c:	00f7f793          	andi	a5,a5,15
    5230:	0000e6b7          	lui	a3,0xe
    5234:	d0868713          	addi	a4,a3,-760 # dd08 <directions>
    5238:	00279793          	slli	a5,a5,0x2
    523c:	00f70733          	add	a4,a4,a5
    5240:	00071583          	lh	a1,0(a4)
    5244:	00271703          	lh	a4,2(a4)
    5248:	00c12803          	lw	a6,12(sp)
    524c:	033587b3          	mul	a5,a1,s3
    5250:	00812603          	lw	a2,8(sp)
    5254:	00881813          	slli	a6,a6,0x8
    5258:	d0868693          	addi	a3,a3,-760
    525c:	00861613          	slli	a2,a2,0x8
    5260:	02e98533          	mul	a0,s3,a4
    5264:	00f60633          	add	a2,a2,a5
    5268:	01400793          	li	a5,20
    526c:	00a809b3          	add	s3,a6,a0
    5270:	006b0813          	addi	a6,s6,6
    5274:	03070733          	mul	a4,a4,a6
    5278:	00400513          	li	a0,4
    527c:	02a74733          	div	a4,a4,a0
    5280:	02f907b3          	mul	a5,s2,a5
    5284:	030585b3          	mul	a1,a1,a6
    5288:	00fa07b3          	add	a5,s4,a5
    528c:	00e79523          	sh	a4,10(a5)
    5290:	00600813          	li	a6,6
    5294:	01690733          	add	a4,s2,s6
    5298:	00c7a023          	sw	a2,0(a5)
    529c:	0137a223          	sw	s3,4(a5)
    52a0:	01778723          	sb	s7,14(a5)
    52a4:	00079623          	sh	zero,12(a5)
    52a8:	00079823          	sh	zero,16(a5)
    52ac:	02a5c5b3          	div	a1,a1,a0
    52b0:	03077733          	remu	a4,a4,a6
    52b4:	00b79423          	sh	a1,8(a5)
    52b8:	00e787a3          	sb	a4,15(a5)
    52bc:	020c0063          	beqz	s8,52dc <spawn+0x1c4>
    52c0:	017a05b3          	add	a1,s4,s7
    52c4:	00005737          	lui	a4,0x5
    52c8:	00b70733          	add	a4,a4,a1
    52cc:	02574703          	lbu	a4,37(a4) # 5025 <bullet_enemy_position+0x6d>
    52d0:	04071e63          	bnez	a4,532c <spawn+0x214>
    52d4:	fff00713          	li	a4,-1
    52d8:	00e79623          	sh	a4,12(a5)
    52dc:	03c12083          	lw	ra,60(sp)
    52e0:	03812403          	lw	s0,56(sp)
    52e4:	03412483          	lw	s1,52(sp)
    52e8:	03012903          	lw	s2,48(sp)
    52ec:	02c12983          	lw	s3,44(sp)
    52f0:	02812a03          	lw	s4,40(sp)
    52f4:	02412a83          	lw	s5,36(sp)
    52f8:	02012b03          	lw	s6,32(sp)
    52fc:	01c12b83          	lw	s7,28(sp)
    5300:	01812c03          	lw	s8,24(sp)
    5304:	01412c83          	lw	s9,20(sp)
    5308:	04010113          	addi	sp,sp,64
    530c:	00008067          	ret
    5310:	00500713          	li	a4,5
    5314:	02eaf733          	remu	a4,s5,a4
    5318:	001b1793          	slli	a5,s6,0x1
    531c:	0027f793          	andi	a5,a5,2
    5320:	00170713          	addi	a4,a4,1
    5324:	00e787b3          	add	a5,a5,a4
    5328:	f09ff06f          	j	5230 <spawn+0x118>
    532c:	0b400713          	li	a4,180
    5330:	02e45733          	divu	a4,s0,a4
    5334:	01270733          	add	a4,a4,s2
    5338:	03077733          	remu	a4,a4,a6
    533c:	00e788a3          	sb	a4,17(a5)
    5340:	fff70713          	addi	a4,a4,-1
    5344:	0ff77713          	zext.b	a4,a4
    5348:	f8e56ae3          	bltu	a0,a4,52dc <spawn+0x1c4>
    534c:	0000e5b7          	lui	a1,0xe
    5350:	00271713          	slli	a4,a4,0x2
    5354:	c8c58593          	addi	a1,a1,-884 # dc8c <comparison_letters+0xf4>
    5358:	00b70733          	add	a4,a4,a1
    535c:	00072703          	lw	a4,0(a4)
    5360:	00070067          	jr	a4
    5364:	00005737          	lui	a4,0x5
    5368:	00ea0a33          	add	s4,s4,a4
    536c:	00ca2683          	lw	a3,12(s4)
    5370:	010a2703          	lw	a4,16(s4)
    5374:	00869693          	slli	a3,a3,0x8
    5378:	00871713          	slli	a4,a4,0x8
    537c:	40c686b3          	sub	a3,a3,a2
    5380:	41370733          	sub	a4,a4,s3
    5384:	41f6d513          	srai	a0,a3,0x1f
    5388:	41f75813          	srai	a6,a4,0x1f
    538c:	00d54633          	xor	a2,a0,a3
    5390:	00e845b3          	xor	a1,a6,a4
    5394:	410585b3          	sub	a1,a1,a6
    5398:	40a60633          	sub	a2,a2,a0
    539c:	00b65463          	bge	a2,a1,53a4 <spawn+0x28c>
    53a0:	00058613          	mv	a2,a1
    53a4:	00000593          	li	a1,0
    53a8:	00060a63          	beqz	a2,53bc <spawn+0x2a4>
    53ac:	00969693          	slli	a3,a3,0x9
    53b0:	02c6c6b3          	div	a3,a3,a2
    53b4:	01069593          	slli	a1,a3,0x10
    53b8:	4105d593          	srai	a1,a1,0x10
    53bc:	00b79423          	sh	a1,8(a5)
    53c0:	20000693          	li	a3,512
    53c4:	00060a63          	beqz	a2,53d8 <spawn+0x2c0>
    53c8:	00971713          	slli	a4,a4,0x9
    53cc:	02c74733          	div	a4,a4,a2
    53d0:	01071693          	slli	a3,a4,0x10
    53d4:	4106d693          	srai	a3,a3,0x10
    53d8:	00d79523          	sh	a3,10(a5)
    53dc:	f01ff06f          	j	52dc <spawn+0x1c4>
    53e0:	00500713          	li	a4,5
    53e4:	02e97733          	remu	a4,s2,a4
    53e8:	06000693          	li	a3,96
    53ec:	ffe70713          	addi	a4,a4,-2 # 4ffe <bullet_enemy_position+0x46>
    53f0:	02d70733          	mul	a4,a4,a3
    53f4:	08070713          	addi	a4,a4,128
    53f8:	00e79423          	sh	a4,8(a5)
    53fc:	18000713          	li	a4,384
    5400:	0240006f          	j	5424 <spawn+0x30c>
    5404:	00fafa93          	andi	s5,s5,15
    5408:	002a9a93          	slli	s5,s5,0x2
    540c:	015686b3          	add	a3,a3,s5
    5410:	0006d703          	lhu	a4,0(a3)
    5414:	00171713          	slli	a4,a4,0x1
    5418:	00e79423          	sh	a4,8(a5)
    541c:	0026d703          	lhu	a4,2(a3)
    5420:	00171713          	slli	a4,a4,0x1
    5424:	00e79523          	sh	a4,10(a5)
    5428:	eb5ff06f          	j	52dc <spawn+0x1c4>
    542c:	00500713          	li	a4,5
    5430:	02e97733          	remu	a4,s2,a4
    5434:	06000693          	li	a3,96
    5438:	ffe70713          	addi	a4,a4,-2
    543c:	02d70733          	mul	a4,a4,a3
    5440:	00e79423          	sh	a4,8(a5)
    5444:	0c000713          	li	a4,192
    5448:	fddff06f          	j	5424 <spawn+0x30c>
    544c:	00197913          	andi	s2,s2,1
    5450:	e0000713          	li	a4,-512
    5454:	fa0902e3          	beqz	s2,53f8 <spawn+0x2e0>
    5458:	20000713          	li	a4,512
    545c:	f9dff06f          	j	53f8 <spawn+0x2e0>

00005460 <bullet_reset>:
    5460:	0a050463          	beqz	a0,5508 <bullet_reset+0xa8>
    5464:	ff010113          	addi	sp,sp,-16
    5468:	00812423          	sw	s0,8(sp)
    546c:	00112623          	sw	ra,12(sp)
    5470:	00912223          	sw	s1,4(sp)
    5474:	01212023          	sw	s2,0(sp)
    5478:	fff58713          	addi	a4,a1,-1
    547c:	3ff00693          	li	a3,1023
    5480:	00058413          	mv	s0,a1
    5484:	ff800793          	li	a5,-8
    5488:	06e6e263          	bltu	a3,a4,54ec <bullet_reset+0x8c>
    548c:	00060913          	mv	s2,a2
    5490:	00005637          	lui	a2,0x5
    5494:	02c60613          	addi	a2,a2,44 # 502c <bullet_enemy_position+0x74>
    5498:	00000593          	li	a1,0
    549c:	00050493          	mv	s1,a0
    54a0:	d89fb0ef          	jal	1228 <memset>
    54a4:	000057b7          	lui	a5,0x5
    54a8:	00f487b3          	add	a5,s1,a5
    54ac:	1e000713          	li	a4,480
    54b0:	00e7a623          	sw	a4,12(a5) # 500c <bullet_enemy_position+0x54>
    54b4:	00e7a823          	sw	a4,16(a5)
    54b8:	00300713          	li	a4,3
    54bc:	0127a023          	sw	s2,0(a5)
    54c0:	0087a423          	sw	s0,8(a5)
    54c4:	02e78223          	sb	a4,36(a5)
    54c8:	02078423          	sb	zero,40(a5)
    54cc:	00000913          	li	s2,0
    54d0:	00090593          	mv	a1,s2
    54d4:	00100613          	li	a2,1
    54d8:	00048513          	mv	a0,s1
    54dc:	00190913          	addi	s2,s2,1
    54e0:	c39ff0ef          	jal	5118 <spawn>
    54e4:	ff2416e3          	bne	s0,s2,54d0 <bullet_reset+0x70>
    54e8:	00000793          	li	a5,0
    54ec:	00c12083          	lw	ra,12(sp)
    54f0:	00812403          	lw	s0,8(sp)
    54f4:	00412483          	lw	s1,4(sp)
    54f8:	00012903          	lw	s2,0(sp)
    54fc:	00078513          	mv	a0,a5
    5500:	01010113          	addi	sp,sp,16
    5504:	00008067          	ret
    5508:	ff800793          	li	a5,-8
    550c:	00078513          	mv	a0,a5
    5510:	00008067          	ret

00005514 <bullet_reset_player>:
    5514:	0a050863          	beqz	a0,55c4 <bullet_reset_player+0xb0>
    5518:	ff010113          	addi	sp,sp,-16
    551c:	00812423          	sw	s0,8(sp)
    5520:	00112623          	sw	ra,12(sp)
    5524:	00912223          	sw	s1,4(sp)
    5528:	01212023          	sw	s2,0(sp)
    552c:	fff58713          	addi	a4,a1,-1
    5530:	3ff00693          	li	a3,1023
    5534:	00058413          	mv	s0,a1
    5538:	ff800793          	li	a5,-8
    553c:	06e6e663          	bltu	a3,a4,55a8 <bullet_reset_player+0x94>
    5540:	00060913          	mv	s2,a2
    5544:	00005637          	lui	a2,0x5
    5548:	02c60613          	addi	a2,a2,44 # 502c <bullet_enemy_position+0x74>
    554c:	00000593          	li	a1,0
    5550:	00050493          	mv	s1,a0
    5554:	cd5fb0ef          	jal	1228 <memset>
    5558:	000057b7          	lui	a5,0x5
    555c:	00f487b3          	add	a5,s1,a5
    5560:	1e000713          	li	a4,480
    5564:	00e7a623          	sw	a4,12(a5) # 500c <bullet_enemy_position+0x54>
    5568:	00e7a823          	sw	a4,16(a5)
    556c:	06060737          	lui	a4,0x6060
    5570:	60370713          	addi	a4,a4,1539 # 6060603 <__gpu_framebuffer_a+0x4060603>
    5574:	02e7a223          	sw	a4,36(a5)
    5578:	00100713          	li	a4,1
    557c:	0127a023          	sw	s2,0(a5)
    5580:	0087a423          	sw	s0,8(a5)
    5584:	02e78423          	sb	a4,40(a5)
    5588:	00000913          	li	s2,0
    558c:	00090593          	mv	a1,s2
    5590:	00100613          	li	a2,1
    5594:	00048513          	mv	a0,s1
    5598:	00190913          	addi	s2,s2,1
    559c:	b7dff0ef          	jal	5118 <spawn>
    55a0:	ff2416e3          	bne	s0,s2,558c <bullet_reset_player+0x78>
    55a4:	00000793          	li	a5,0
    55a8:	00c12083          	lw	ra,12(sp)
    55ac:	00812403          	lw	s0,8(sp)
    55b0:	00412483          	lw	s1,4(sp)
    55b4:	00012903          	lw	s2,0(sp)
    55b8:	00078513          	mv	a0,a5
    55bc:	01010113          	addi	sp,sp,16
    55c0:	00008067          	ret
    55c4:	ff800793          	li	a5,-8
    55c8:	00078513          	mv	a0,a5
    55cc:	00008067          	ret

000055d0 <step>:
    55d0:	f9010113          	addi	sp,sp,-112
    55d4:	07212023          	sw	s2,96(sp)
    55d8:	06112623          	sw	ra,108(sp)
    55dc:	06812423          	sw	s0,104(sp)
    55e0:	06912223          	sw	s1,100(sp)
    55e4:	05312e23          	sw	s3,92(sp)
    55e8:	05412c23          	sw	s4,88(sp)
    55ec:	05512a23          	sw	s5,84(sp)
    55f0:	05612823          	sw	s6,80(sp)
    55f4:	05712623          	sw	s7,76(sp)
    55f8:	05812423          	sw	s8,72(sp)
    55fc:	05912223          	sw	s9,68(sp)
    5600:	05a12023          	sw	s10,64(sp)
    5604:	03b12e23          	sw	s11,60(sp)
    5608:	00e12423          	sw	a4,8(sp)
    560c:	00058913          	mv	s2,a1
    5610:	74050e63          	beqz	a0,5d6c <step+0x79c>
    5614:	00005a37          	lui	s4,0x5
    5618:	01450a33          	add	s4,a0,s4
    561c:	008a2983          	lw	s3,8(s4) # 5008 <bullet_enemy_position+0x50>
    5620:	00068493          	mv	s1,a3
    5624:	3ff00713          	li	a4,1023
    5628:	fff98693          	addi	a3,s3,-1
    562c:	00050c93          	mv	s9,a0
    5630:	ff800793          	li	a5,-8
    5634:	18d76e63          	bltu	a4,a3,57d0 <step+0x200>
    5638:	024a4a83          	lbu	s5,36(s4)
    563c:	00300713          	li	a4,3
    5640:	19576863          	bltu	a4,s5,57d0 <step+0x200>
    5644:	00060413          	mv	s0,a2
    5648:	8f5ff0ef          	jal	4f3c <bullet_campaign_valid>
    564c:	ff800793          	li	a5,-8
    5650:	18050063          	beqz	a0,57d0 <step+0x200>
    5654:	020a5683          	lhu	a3,32(s4)
    5658:	03c00713          	li	a4,60
    565c:	16d76a63          	bltu	a4,a3,57d0 <step+0x200>
    5660:	00812583          	lw	a1,8(sp)
    5664:	000a9e63          	bnez	s5,5680 <step+0xb0>
    5668:	022a5703          	lhu	a4,34(s4)
    566c:	07700613          	li	a2,119
    5670:	fff70713          	addi	a4,a4,-1
    5674:	01071713          	slli	a4,a4,0x10
    5678:	01075713          	srli	a4,a4,0x10
    567c:	14e66a63          	bltu	a2,a4,57d0 <step+0x200>
    5680:	02090063          	beqz	s2,56a0 <step+0xd0>
    5684:	ff840713          	addi	a4,s0,-8
    5688:	3b000613          	li	a2,944
    568c:	ff800793          	li	a5,-8
    5690:	14e66063          	bltu	a2,a4,57d0 <step+0x200>
    5694:	fb048713          	addi	a4,s1,-80
    5698:	1c400613          	li	a2,452
    569c:	12e66a63          	bltu	a2,a4,57d0 <step+0x200>
    56a0:	01400713          	li	a4,20
    56a4:	02e98733          	mul	a4,s3,a4
    56a8:	00005537          	lui	a0,0x5
    56ac:	000c8d93          	mv	s11,s9
    56b0:	000c8613          	mv	a2,s9
    56b4:	00193e13          	seqz	t3,s2
    56b8:	00500313          	li	t1,5
    56bc:	00ac8533          	add	a0,s9,a0
    56c0:	01970733          	add	a4,a4,s9
    56c4:	00e64e83          	lbu	t4,14(a2)
    56c8:	001e3893          	seqz	a7,t3
    56cc:	00288893          	addi	a7,a7,2
    56d0:	69d8ce63          	blt	a7,t4,5d6c <step+0x79c>
    56d4:	00f64883          	lbu	a7,15(a2)
    56d8:	69136a63          	bltu	t1,a7,5d6c <step+0x79c>
    56dc:	02854883          	lbu	a7,40(a0) # 5028 <bullet_enemy_position+0x70>
    56e0:	00088663          	beqz	a7,56ec <step+0x11c>
    56e4:	01164e83          	lbu	t4,17(a2)
    56e8:	69d36263          	bltu	t1,t4,5d6c <step+0x79c>
    56ec:	01460613          	addi	a2,a2,20
    56f0:	fcc71ae3          	bne	a4,a2,56c4 <step+0xf4>
    56f4:	00005737          	lui	a4,0x5
    56f8:	00ec8733          	add	a4,s9,a4
    56fc:	00472a03          	lw	s4,4(a4) # 5004 <bullet_enemy_position+0x4c>
    5700:	001a0a13          	addi	s4,s4,1
    5704:	01472223          	sw	s4,4(a4)
    5708:	00090663          	beqz	s2,5714 <step+0x144>
    570c:	02974703          	lbu	a4,41(a4)
    5710:	08071e63          	bnez	a4,57ac <step+0x1dc>
    5714:	100a9663          	bnez	s5,5820 <step+0x250>
    5718:	000057b7          	lui	a5,0x5
    571c:	00fc8733          	add	a4,s9,a5
    5720:	02275683          	lhu	a3,34(a4)
    5724:	fff68693          	addi	a3,a3,-1
    5728:	01069693          	slli	a3,a3,0x10
    572c:	0106d693          	srli	a3,a3,0x10
    5730:	02d71123          	sh	a3,34(a4)
    5734:	06069c63          	bnez	a3,57ac <step+0x1dc>
    5738:	00072603          	lw	a2,0(a4)
    573c:	0c090a63          	beqz	s2,5810 <step+0x240>
    5740:	0c088863          	beqz	a7,5810 <step+0x240>
    5744:	06058863          	beqz	a1,57b4 <step+0x1e4>
    5748:	06bc8663          	beq	s9,a1,57b4 <step+0x1e4>
    574c:	00f587b3          	add	a5,a1,a5
    5750:	0287c703          	lbu	a4,40(a5) # 5028 <bullet_enemy_position+0x70>
    5754:	06070063          	beqz	a4,57b4 <step+0x1e4>
    5758:	0087a703          	lw	a4,8(a5)
    575c:	04e99c63          	bne	s3,a4,57b4 <step+0x1e4>
    5760:	0007a703          	lw	a4,0(a5)
    5764:	04c71863          	bne	a4,a2,57b4 <step+0x1e4>
    5768:	0047a783          	lw	a5,4(a5)
    576c:	04079463          	bnez	a5,57b4 <step+0x1e4>
    5770:	00005437          	lui	s0,0x5
    5774:	008587b3          	add	a5,a1,s0
    5778:	0147a703          	lw	a4,20(a5)
    577c:	02071c63          	bnez	a4,57b4 <step+0x1e4>
    5780:	0247c683          	lbu	a3,36(a5)
    5784:	00300713          	li	a4,3
    5788:	02e69663          	bne	a3,a4,57b4 <step+0x1e4>
    578c:	0297c783          	lbu	a5,41(a5)
    5790:	02079263          	bnez	a5,57b4 <step+0x1e4>
    5794:	00005637          	lui	a2,0x5
    5798:	02c60613          	addi	a2,a2,44 # 502c <bullet_enemy_position+0x74>
    579c:	000c8513          	mv	a0,s9
    57a0:	008c8433          	add	s0,s9,s0
    57a4:	b61fb0ef          	jal	1304 <memcpy>
    57a8:	01442223          	sw	s4,4(s0) # 5004 <bullet_enemy_position+0x4c>
    57ac:	00000793          	li	a5,0
    57b0:	0200006f          	j	57d0 <step+0x200>
    57b4:	00098593          	mv	a1,s3
    57b8:	000c8513          	mv	a0,s9
    57bc:	d59ff0ef          	jal	5514 <bullet_reset_player>
    57c0:	00005737          	lui	a4,0x5
    57c4:	00ec8733          	add	a4,s9,a4
    57c8:	00050793          	mv	a5,a0
    57cc:	01472223          	sw	s4,4(a4) # 5004 <bullet_enemy_position+0x4c>
    57d0:	06c12083          	lw	ra,108(sp)
    57d4:	06812403          	lw	s0,104(sp)
    57d8:	06412483          	lw	s1,100(sp)
    57dc:	06012903          	lw	s2,96(sp)
    57e0:	05c12983          	lw	s3,92(sp)
    57e4:	05812a03          	lw	s4,88(sp)
    57e8:	05412a83          	lw	s5,84(sp)
    57ec:	05012b03          	lw	s6,80(sp)
    57f0:	04c12b83          	lw	s7,76(sp)
    57f4:	04812c03          	lw	s8,72(sp)
    57f8:	04412c83          	lw	s9,68(sp)
    57fc:	04012d03          	lw	s10,64(sp)
    5800:	03c12d83          	lw	s11,60(sp)
    5804:	00078513          	mv	a0,a5
    5808:	07010113          	addi	sp,sp,112
    580c:	00008067          	ret
    5810:	00098593          	mv	a1,s3
    5814:	000c8513          	mv	a0,s9
    5818:	c49ff0ef          	jal	5460 <bullet_reset>
    581c:	fa5ff06f          	j	57c0 <step+0x1f0>
    5820:	00005637          	lui	a2,0x5
    5824:	00cc8633          	add	a2,s9,a2
    5828:	01462703          	lw	a4,20(a2) # 5014 <bullet_enemy_position+0x5c>
    582c:	00170713          	addi	a4,a4,1
    5830:	00e62a23          	sw	a4,20(a2)
    5834:	02091863          	bnez	s2,5864 <step+0x294>
    5838:	0f000413          	li	s0,240
    583c:	02877433          	remu	s0,a4,s0
    5840:	03b00613          	li	a2,59
    5844:	14867a63          	bgeu	a2,s0,5998 <step+0x3c8>
    5848:	0b300613          	li	a2,179
    584c:	12866e63          	bltu	a2,s0,5988 <step+0x3b8>
    5850:	07800613          	li	a2,120
    5854:	40860633          	sub	a2,a2,s0
    5858:	00300593          	li	a1,3
    585c:	02b60633          	mul	a2,a2,a1
    5860:	1e060413          	addi	s0,a2,480
    5864:	00005637          	lui	a2,0x5
    5868:	00cc8633          	add	a2,s9,a2
    586c:	00862623          	sw	s0,12(a2) # 500c <bullet_enemy_position+0x54>
    5870:	00091463          	bnez	s2,5878 <step+0x2a8>
    5874:	1e000493          	li	s1,480
    5878:	00005637          	lui	a2,0x5
    587c:	00cc8633          	add	a2,s9,a2
    5880:	00d037b3          	snez	a5,a3
    5884:	00962823          	sw	s1,16(a2) # 5010 <bullet_enemy_position+0x58>
    5888:	00f12423          	sw	a5,8(sp)
    588c:	00068663          	beqz	a3,5898 <step+0x2c8>
    5890:	fff68693          	addi	a3,a3,-1
    5894:	02d61023          	sh	a3,32(a2)
    5898:	01e00693          	li	a3,30
    589c:	02d77733          	remu	a4,a4,a3
    58a0:	02071463          	bnez	a4,58c8 <step+0x2f8>
    58a4:	00005737          	lui	a4,0x5
    58a8:	00ec8733          	add	a4,s9,a4
    58ac:	01872703          	lw	a4,24(a4) # 5018 <bullet_enemy_position+0x60>
    58b0:	fff00693          	li	a3,-1
    58b4:	00d70463          	beq	a4,a3,58bc <step+0x2ec>
    58b8:	00170713          	addi	a4,a4,1
    58bc:	000056b7          	lui	a3,0x5
    58c0:	00dc86b3          	add	a3,s9,a3
    58c4:	00e6ac23          	sw	a4,24(a3) # 5018 <bullet_enemy_position+0x60>
    58c8:	00005ab7          	lui	s5,0x5
    58cc:	015c87b3          	add	a5,s9,s5
    58d0:	00f12623          	sw	a5,12(sp)
    58d4:	fed40793          	addi	a5,s0,-19
    58d8:	0003cab7          	lui	s5,0x3c
    58dc:	0001ed37          	lui	s10,0x1e
    58e0:	00f12823          	sw	a5,16(sp)
    58e4:	00010b37          	lui	s6,0x10
    58e8:	00c40793          	addi	a5,s0,12
    58ec:	0f000a13          	li	s4,240
    58f0:	00000913          	li	s2,0
    58f4:	7fea8a93          	addi	s5,s5,2046 # 3c7fe <__freertos_irq_stack_top+0x1ed5e>
    58f8:	bffd0d13          	addi	s10,s10,-1025 # 1dbff <__freertos_irq_stack_top+0x15f>
    58fc:	00f12a23          	sw	a5,20(sp)
    5900:	fffb0b13          	addi	s6,s6,-1 # ffff <__global_pointer$+0x127f>
    5904:	00edc683          	lbu	a3,14(s11)
    5908:	00300713          	li	a4,3
    590c:	1ce69a63          	bne	a3,a4,5ae0 <step+0x510>
    5910:	00cddc03          	lhu	s8,12(s11)
    5914:	056c0c63          	beq	s8,s6,596c <step+0x39c>
    5918:	000da703          	lw	a4,0(s11)
    591c:	008d9503          	lh	a0,8(s11)
    5920:	004da683          	lw	a3,4(s11)
    5924:	00e50533          	add	a0,a0,a4
    5928:	00ad9703          	lh	a4,10(s11)
    592c:	00ada023          	sw	a0,0(s11)
    5930:	00d70733          	add	a4,a4,a3
    5934:	00eda223          	sw	a4,4(s11)
    5938:	00e12c23          	sw	a4,24(sp)
    593c:	de0ff0ef          	jal	4f1c <pixel_coordinate>
    5940:	00450b93          	addi	s7,a0,4
    5944:	3bf00693          	li	a3,959
    5948:	0176ee63          	bltu	a3,s7,5964 <step+0x394>
    594c:	01812703          	lw	a4,24(sp)
    5950:	00070513          	mv	a0,a4
    5954:	dc8ff0ef          	jal	4f1c <pixel_coordinate>
    5958:	fbc50693          	addi	a3,a0,-68
    595c:	1d300713          	li	a4,467
    5960:	04d77463          	bgeu	a4,a3,59a8 <step+0x3d8>
    5964:	fff00713          	li	a4,-1
    5968:	00ed9623          	sh	a4,12(s11)
    596c:	16700713          	li	a4,359
    5970:	00190913          	addi	s2,s2,1
    5974:	3eea0863          	beq	s4,a4,5d64 <step+0x794>
    5978:	001a0a13          	addi	s4,s4,1
    597c:	014d8d93          	addi	s11,s11,20
    5980:	f92992e3          	bne	s3,s2,5904 <step+0x334>
    5984:	e29ff06f          	j	57ac <step+0x1dc>
    5988:	00300613          	li	a2,3
    598c:	02c40433          	mul	s0,s0,a2
    5990:	f1040413          	addi	s0,s0,-240
    5994:	ed1ff06f          	j	5864 <step+0x294>
    5998:	00300613          	li	a2,3
    599c:	02c40433          	mul	s0,s0,a2
    59a0:	1e040413          	addi	s0,s0,480
    59a4:	ec1ff06f          	j	5864 <step+0x294>
    59a8:	001c0c13          	addi	s8,s8,1 # 2000001 <__gpu_framebuffer_a+0x1>
    59ac:	018d9623          	sh	s8,12(s11)
    59b0:	00450893          	addi	a7,a0,4
    59b4:	00000c13          	li	s8,0
    59b8:	00300e13          	li	t3,3
    59bc:	00c12783          	lw	a5,12(sp)
    59c0:	0287c303          	lbu	t1,40(a5)
    59c4:	02030c63          	beqz	t1,59fc <step+0x42c>
    59c8:	00005737          	lui	a4,0x5
    59cc:	02570713          	addi	a4,a4,37 # 5025 <bullet_enemy_position+0x6d>
    59d0:	00ec0733          	add	a4,s8,a4
    59d4:	00ec8733          	add	a4,s9,a4
    59d8:	00074703          	lbu	a4,0(a4)
    59dc:	02071063          	bnez	a4,59fc <step+0x42c>
    59e0:	001c0c13          	addi	s8,s8,1
    59e4:	fdcc1ce3          	bne	s8,t3,59bc <step+0x3ec>
    59e8:	00005737          	lui	a4,0x5
    59ec:	00ec8733          	add	a4,s9,a4
    59f0:	02974703          	lbu	a4,41(a4) # 5029 <bullet_enemy_position+0x71>
    59f4:	da071ce3          	bnez	a4,57ac <step+0x1dc>
    59f8:	f75ff06f          	j	596c <step+0x39c>
    59fc:	02c10693          	addi	a3,sp,44
    5a00:	02810613          	addi	a2,sp,40
    5a04:	000c0593          	mv	a1,s8
    5a08:	000c8513          	mv	a0,s9
    5a0c:	01112e23          	sw	a7,28(sp)
    5a10:	00612c23          	sw	t1,24(sp)
    5a14:	da4ff0ef          	jal	4fb8 <bullet_enemy_position>
    5a18:	02812683          	lw	a3,40(sp)
    5a1c:	01400613          	li	a2,20
    5a20:	02c12703          	lw	a4,44(sp)
    5a24:	40db86b3          	sub	a3,s7,a3
    5a28:	00a68693          	addi	a3,a3,10
    5a2c:	01c12883          	lw	a7,28(sp)
    5a30:	00300e13          	li	t3,3
    5a34:	fad666e3          	bltu	a2,a3,59e0 <step+0x410>
    5a38:	40e88733          	sub	a4,a7,a4
    5a3c:	00a70713          	addi	a4,a4,10
    5a40:	fae660e3          	bltu	a2,a4,59e0 <step+0x410>
    5a44:	fff00713          	li	a4,-1
    5a48:	00ed9623          	sh	a4,12(s11)
    5a4c:	00005737          	lui	a4,0x5
    5a50:	00ec8733          	add	a4,s9,a4
    5a54:	01872703          	lw	a4,24(a4) # 5018 <bullet_enemy_position+0x60>
    5a58:	fe600693          	li	a3,-26
    5a5c:	01812303          	lw	t1,24(sp)
    5a60:	00e6f463          	bgeu	a3,a4,5a68 <step+0x498>
    5a64:	fe600713          	li	a4,-26
    5a68:	000056b7          	lui	a3,0x5
    5a6c:	01970713          	addi	a4,a4,25
    5a70:	00dc85b3          	add	a1,s9,a3
    5a74:	00e5ac23          	sw	a4,24(a1)
    5a78:	f60308e3          	beqz	t1,59e8 <step+0x418>
    5a7c:	018c8c33          	add	s8,s9,s8
    5a80:	01868633          	add	a2,a3,s8
    5a84:	02564683          	lbu	a3,37(a2)
    5a88:	fff68693          	addi	a3,a3,-1 # 4fff <bullet_enemy_position+0x47>
    5a8c:	0ff6f693          	zext.b	a3,a3
    5a90:	02d602a3          	sb	a3,37(a2)
    5a94:	f4069ae3          	bnez	a3,59e8 <step+0x418>
    5a98:	f3700693          	li	a3,-201
    5a9c:	00e6f463          	bgeu	a3,a4,5aa4 <step+0x4d4>
    5aa0:	f3700713          	li	a4,-201
    5aa4:	0c870713          	addi	a4,a4,200
    5aa8:	000056b7          	lui	a3,0x5
    5aac:	00e5ac23          	sw	a4,24(a1)
    5ab0:	00dc86b3          	add	a3,s9,a3
    5ab4:	0246a603          	lw	a2,36(a3) # 5024 <bullet_enemy_position+0x6c>
    5ab8:	00000713          	li	a4,0
    5abc:	00861593          	slli	a1,a2,0x8
    5ac0:	0105d593          	srli	a1,a1,0x10
    5ac4:	00059663          	bnez	a1,5ad0 <step+0x500>
    5ac8:	0276c703          	lbu	a4,39(a3)
    5acc:	00173713          	seqz	a4,a4
    5ad0:	000056b7          	lui	a3,0x5
    5ad4:	00dc86b3          	add	a3,s9,a3
    5ad8:	02e684a3          	sb	a4,41(a3) # 5029 <bullet_enemy_position+0x71>
    5adc:	f0dff06f          	j	59e8 <step+0x418>
    5ae0:	00c12783          	lw	a5,12(sp)
    5ae4:	0287c603          	lbu	a2,40(a5)
    5ae8:	00060663          	beqz	a2,5af4 <step+0x524>
    5aec:	00cdd703          	lhu	a4,12(s11)
    5af0:	e7670ee3          	beq	a4,s6,596c <step+0x39c>
    5af4:	000da583          	lw	a1,0(s11)
    5af8:	7ff58713          	addi	a4,a1,2047
    5afc:	00eaee63          	bltu	s5,a4,5b18 <step+0x548>
    5b00:	004da503          	lw	a0,4(s11)
    5b04:	ffffc737          	lui	a4,0xffffc
    5b08:	00e50733          	add	a4,a0,a4
    5b0c:	00ed6663          	bltu	s10,a4,5b18 <step+0x548>
    5b10:	00cdd683          	lhu	a3,12(s11)
    5b14:	0146ec63          	bltu	a3,s4,5b2c <step+0x55c>
    5b18:	00000613          	li	a2,0
    5b1c:	00090593          	mv	a1,s2
    5b20:	000c8513          	mv	a0,s9
    5b24:	df4ff0ef          	jal	5118 <spawn>
    5b28:	e45ff06f          	j	596c <step+0x39c>
    5b2c:	04060a63          	beqz	a2,5b80 <step+0x5b0>
    5b30:	011dc703          	lbu	a4,17(s11)
    5b34:	00300893          	li	a7,3
    5b38:	11170e63          	beq	a4,a7,5c54 <step+0x684>
    5b3c:	00400893          	li	a7,4
    5b40:	15170a63          	beq	a4,a7,5c94 <step+0x6c4>
    5b44:	00200893          	li	a7,2
    5b48:	03171c63          	bne	a4,a7,5b80 <step+0x5b0>
    5b4c:	0000e8b7          	lui	a7,0xe
    5b50:	03c6f313          	andi	t1,a3,60
    5b54:	d0888893          	addi	a7,a7,-760 # dd08 <directions>
    5b58:	006888b3          	add	a7,a7,t1
    5b5c:	00089883          	lh	a7,0(a7)
    5b60:	06000313          	li	t1,96
    5b64:	02e8c8b3          	div	a7,a7,a4
    5b68:	00500713          	li	a4,5
    5b6c:	02e97733          	remu	a4,s2,a4
    5b70:	ffe70713          	addi	a4,a4,-2 # ffffbffe <__gpu_framebuffer_a+0xfdffbffe>
    5b74:	02670733          	mul	a4,a4,t1
    5b78:	00e88733          	add	a4,a7,a4
    5b7c:	00ed9423          	sh	a4,8(s11)
    5b80:	008d9703          	lh	a4,8(s11)
    5b84:	00ad9c03          	lh	s8,10(s11)
    5b88:	00168693          	addi	a3,a3,1
    5b8c:	00b705b3          	add	a1,a4,a1
    5b90:	00ac0c33          	add	s8,s8,a0
    5b94:	00bda023          	sw	a1,0(s11)
    5b98:	018da223          	sw	s8,4(s11)
    5b9c:	00dd9623          	sh	a3,12(s11)
    5ba0:	02060063          	beqz	a2,5bc0 <step+0x5f0>
    5ba4:	011dc603          	lbu	a2,17(s11)
    5ba8:	00500693          	li	a3,5
    5bac:	00d61a63          	bne	a2,a3,5bc0 <step+0x5f0>
    5bb0:	1005d063          	bgez	a1,5cb0 <step+0x6e0>
    5bb4:	000da023          	sw	zero,0(s11)
    5bb8:	40e00733          	neg	a4,a4
    5bbc:	00ed9423          	sh	a4,8(s11)
    5bc0:	000da503          	lw	a0,0(s11)
    5bc4:	b58ff0ef          	jal	4f1c <pixel_coordinate>
    5bc8:	01012783          	lw	a5,16(sp)
    5bcc:	00050b93          	mv	s7,a0
    5bd0:	d8f54ee3          	blt	a0,a5,596c <step+0x39c>
    5bd4:	01412783          	lw	a5,20(sp)
    5bd8:	d8a7cae3          	blt	a5,a0,596c <step+0x39c>
    5bdc:	000c0513          	mv	a0,s8
    5be0:	b3cff0ef          	jal	4f1c <pixel_coordinate>
    5be4:	fed48713          	addi	a4,s1,-19
    5be8:	d8e542e3          	blt	a0,a4,596c <step+0x39c>
    5bec:	00c48713          	addi	a4,s1,12
    5bf0:	d6a74ee3          	blt	a4,a0,596c <step+0x39c>
    5bf4:	00fdc703          	lbu	a4,15(s11)
    5bf8:	40950533          	sub	a0,a0,s1
    5bfc:	01350513          	addi	a0,a0,19
    5c00:	00671713          	slli	a4,a4,0x6
    5c04:	00a70733          	add	a4,a4,a0
    5c08:	02070613          	addi	a2,a4,32
    5c0c:	0000e6b7          	lui	a3,0xe
    5c10:	d4868693          	addi	a3,a3,-696 # dd48 <bullet_contact_masks>
    5c14:	00271713          	slli	a4,a4,0x2
    5c18:	00261613          	slli	a2,a2,0x2
    5c1c:	00c68633          	add	a2,a3,a2
    5c20:	00e686b3          	add	a3,a3,a4
    5c24:	0006a703          	lw	a4,0(a3)
    5c28:	408b8bb3          	sub	s7,s7,s0
    5c2c:	013b8b93          	addi	s7,s7,19 # 2200013 <__gpu_framebuffer_a+0x200013>
    5c30:	01775733          	srl	a4,a4,s7
    5c34:	00177713          	andi	a4,a4,1
    5c38:	00062603          	lw	a2,0(a2)
    5c3c:	0c070663          	beqz	a4,5d08 <step+0x738>
    5c40:	00812783          	lw	a5,8(sp)
    5c44:	08078063          	beqz	a5,5cc4 <step+0x6f4>
    5c48:	00100793          	li	a5,1
    5c4c:	00f12423          	sw	a5,8(sp)
    5c50:	d1dff06f          	j	596c <step+0x39c>
    5c54:	00c00893          	li	a7,12
    5c58:	0316d8b3          	divu	a7,a3,a7
    5c5c:	02e95733          	divu	a4,s2,a4
    5c60:	01170733          	add	a4,a4,a7
    5c64:	00f77713          	andi	a4,a4,15
    5c68:	0000e8b7          	lui	a7,0xe
    5c6c:	d0888893          	addi	a7,a7,-760 # dd08 <directions>
    5c70:	00271713          	slli	a4,a4,0x2
    5c74:	00e88733          	add	a4,a7,a4
    5c78:	00075883          	lhu	a7,0(a4)
    5c7c:	00275703          	lhu	a4,2(a4)
    5c80:	00189893          	slli	a7,a7,0x1
    5c84:	011d9423          	sh	a7,8(s11)
    5c88:	00171713          	slli	a4,a4,0x1
    5c8c:	00ed9523          	sh	a4,10(s11)
    5c90:	ef1ff06f          	j	5b80 <step+0x5b0>
    5c94:	0076f713          	andi	a4,a3,7
    5c98:	ee0714e3          	bnez	a4,5b80 <step+0x5b0>
    5c9c:	00ad9703          	lh	a4,10(s11)
    5ca0:	37f00893          	li	a7,895
    5ca4:	ece8cee3          	blt	a7,a4,5b80 <step+0x5b0>
    5ca8:	02070713          	addi	a4,a4,32
    5cac:	fe1ff06f          	j	5c8c <step+0x6bc>
    5cb0:	0003c6b7          	lui	a3,0x3c
    5cb4:	80068693          	addi	a3,a3,-2048 # 3b800 <__freertos_irq_stack_top+0x1dd60>
    5cb8:	f0b6d4e3          	bge	a3,a1,5bc0 <step+0x5f0>
    5cbc:	00dda023          	sw	a3,0(s11)
    5cc0:	ef9ff06f          	j	5bb8 <step+0x5e8>
    5cc4:	00005bb7          	lui	s7,0x5
    5cc8:	017c8bb3          	add	s7,s9,s7
    5ccc:	024bcc03          	lbu	s8,36(s7) # 5024 <bullet_enemy_position+0x6c>
    5cd0:	00000613          	li	a2,0
    5cd4:	00090593          	mv	a1,s2
    5cd8:	fffc0c13          	addi	s8,s8,-1
    5cdc:	0ffc7c13          	zext.b	s8,s8
    5ce0:	038b8223          	sb	s8,36(s7)
    5ce4:	000c8513          	mv	a0,s9
    5ce8:	c30ff0ef          	jal	5118 <spawn>
    5cec:	000c1863          	bnez	s8,5cfc <step+0x72c>
    5cf0:	007807b7          	lui	a5,0x780
    5cf4:	02fba023          	sw	a5,32(s7)
    5cf8:	ab5ff06f          	j	57ac <step+0x1dc>
    5cfc:	03c00713          	li	a4,60
    5d00:	02eb9023          	sh	a4,32(s7)
    5d04:	f45ff06f          	j	5c48 <step+0x678>
    5d08:	01765733          	srl	a4,a2,s7
    5d0c:	00177713          	andi	a4,a4,1
    5d10:	c4070ee3          	beqz	a4,596c <step+0x39c>
    5d14:	010dc703          	lbu	a4,16(s11)
    5d18:	c4071ae3          	bnez	a4,596c <step+0x39c>
    5d1c:	00100713          	li	a4,1
    5d20:	00ed8823          	sb	a4,16(s11)
    5d24:	00005737          	lui	a4,0x5
    5d28:	00ec8733          	add	a4,s9,a4
    5d2c:	01c72683          	lw	a3,28(a4) # 501c <bullet_enemy_position+0x64>
    5d30:	fff00613          	li	a2,-1
    5d34:	00c68663          	beq	a3,a2,5d40 <step+0x770>
    5d38:	00168693          	addi	a3,a3,1
    5d3c:	00d72e23          	sw	a3,28(a4)
    5d40:	000056b7          	lui	a3,0x5
    5d44:	00dc86b3          	add	a3,s9,a3
    5d48:	0186a703          	lw	a4,24(a3) # 5018 <bullet_enemy_position+0x60>
    5d4c:	ff500613          	li	a2,-11
    5d50:	00e67463          	bgeu	a2,a4,5d58 <step+0x788>
    5d54:	ff500713          	li	a4,-11
    5d58:	00a70713          	addi	a4,a4,10
    5d5c:	00e6ac23          	sw	a4,24(a3)
    5d60:	c0dff06f          	j	596c <step+0x39c>
    5d64:	0f000a13          	li	s4,240
    5d68:	c15ff06f          	j	597c <step+0x3ac>
    5d6c:	ff800793          	li	a5,-8
    5d70:	a61ff06f          	j	57d0 <step+0x200>

00005d74 <bullet_step_player>:
    5d74:	00060693          	mv	a3,a2
    5d78:	00000713          	li	a4,0
    5d7c:	00058613          	mv	a2,a1
    5d80:	00100593          	li	a1,1
    5d84:	84dff06f          	j	55d0 <step>

00005d88 <bullet_step_player_cached>:
    5d88:	00068713          	mv	a4,a3
    5d8c:	00060693          	mv	a3,a2
    5d90:	00058613          	mv	a2,a1
    5d94:	00100593          	li	a1,1
    5d98:	839ff06f          	j	55d0 <step>

00005d9c <bullet_shape_opaque>:
    5d9c:	00500793          	li	a5,5
    5da0:	00050713          	mv	a4,a0
    5da4:	02a7ec63          	bltu	a5,a0,5ddc <bullet_shape_opaque+0x40>
    5da8:	00c5e7b3          	or	a5,a1,a2
    5dac:	00700693          	li	a3,7
    5db0:	00000513          	li	a0,0
    5db4:	02f6e663          	bltu	a3,a5,5de0 <bullet_shape_opaque+0x44>
    5db8:	0000e7b7          	lui	a5,0xe
    5dbc:	00371713          	slli	a4,a4,0x3
    5dc0:	cb478793          	addi	a5,a5,-844 # dcb4 <masks.1>
    5dc4:	00e787b3          	add	a5,a5,a4
    5dc8:	00c78633          	add	a2,a5,a2
    5dcc:	00064503          	lbu	a0,0(a2)
    5dd0:	40b55533          	sra	a0,a0,a1
    5dd4:	00157513          	andi	a0,a0,1
    5dd8:	00008067          	ret
    5ddc:	00000513          	li	a0,0
    5de0:	00008067          	ret

00005de4 <sprite>:
    5de4:	f8010113          	addi	sp,sp,-128
    5de8:	05812c23          	sw	s8,88(sp)
    5dec:	00060c13          	mv	s8,a2
    5df0:	08412603          	lw	a2,132(sp)
    5df4:	07412423          	sw	s4,104(sp)
    5df8:	06112e23          	sw	ra,124(sp)
    5dfc:	06812c23          	sw	s0,120(sp)
    5e00:	06912a23          	sw	s1,116(sp)
    5e04:	07212823          	sw	s2,112(sp)
    5e08:	07312623          	sw	s3,108(sp)
    5e0c:	07512223          	sw	s5,100(sp)
    5e10:	07612023          	sw	s6,96(sp)
    5e14:	05712e23          	sw	s7,92(sp)
    5e18:	05912a23          	sw	s9,84(sp)
    5e1c:	05a12823          	sw	s10,80(sp)
    5e20:	05b12623          	sw	s11,76(sp)
    5e24:	00062023          	sw	zero,0(a2)
    5e28:	00a12623          	sw	a0,12(sp)
    5e2c:	00b12823          	sw	a1,16(sp)
    5e30:	3bf00613          	li	a2,959
    5e34:	00000a13          	li	s4,0
    5e38:	10e64c63          	blt	a2,a4,5f50 <sprite+0x16c>
    5e3c:	41000633          	neg	a2,a6
    5e40:	00080c93          	mv	s9,a6
    5e44:	00000a13          	li	s4,0
    5e48:	10e65463          	bge	a2,a4,5f50 <sprite+0x16c>
    5e4c:	21b00613          	li	a2,539
    5e50:	10f64063          	blt	a2,a5,5f50 <sprite+0x16c>
    5e54:	04800593          	li	a1,72
    5e58:	41058633          	sub	a2,a1,a6
    5e5c:	0ef65a63          	bge	a2,a5,5f50 <sprite+0x16c>
    5e60:	41f75613          	srai	a2,a4,0x1f
    5e64:	40e00b33          	neg	s6,a4
    5e68:	00cb7b33          	and	s6,s6,a2
    5e6c:	04700613          	li	a2,71
    5e70:	00088d93          	mv	s11,a7
    5e74:	00000413          	li	s0,0
    5e78:	00f64463          	blt	a2,a5,5e80 <sprite+0x9c>
    5e7c:	40f58433          	sub	s0,a1,a5
    5e80:	00070b93          	mv	s7,a4
    5e84:	00075463          	bgez	a4,5e8c <sprite+0xa8>
    5e88:	00000b93          	li	s7,0
    5e8c:	3c000d13          	li	s10,960
    5e90:	416c8733          	sub	a4,s9,s6
    5e94:	417d0d33          	sub	s10,s10,s7
    5e98:	01a77463          	bgeu	a4,s10,5ea0 <sprite+0xbc>
    5e9c:	00070d13          	mv	s10,a4
    5ea0:	00078a93          	mv	s5,a5
    5ea4:	04800793          	li	a5,72
    5ea8:	00fad463          	bge	s5,a5,5eb0 <sprite+0xcc>
    5eac:	04800a93          	li	s5,72
    5eb0:	21c00713          	li	a4,540
    5eb4:	408c87b3          	sub	a5,s9,s0
    5eb8:	415704b3          	sub	s1,a4,s5
    5ebc:	0097f463          	bgeu	a5,s1,5ec4 <sprite+0xe0>
    5ec0:	00078493          	mv	s1,a5
    5ec4:	08012703          	lw	a4,128(sp)
    5ec8:	fff00793          	li	a5,-1
    5ecc:	0cf71263          	bne	a4,a5,5f90 <sprite+0x1ac>
    5ed0:	3c000793          	li	a5,960
    5ed4:	02fa87b3          	mul	a5,s5,a5
    5ed8:	02012a23          	sw	zero,52(sp)
    5edc:	01012583          	lw	a1,16(sp)
    5ee0:	00c12503          	lw	a0,12(sp)
    5ee4:	02012e23          	sw	zero,60(sp)
    5ee8:	02012c23          	sw	zero,56(sp)
    5eec:	03a11823          	sh	s10,48(sp)
    5ef0:	02911923          	sh	s1,50(sp)
    5ef4:	03b10ea3          	sb	s11,61(sp)
    5ef8:	03940433          	mul	s0,s0,s9
    5efc:	017787b3          	add	a5,a5,s7
    5f00:	00179793          	slli	a5,a5,0x1
    5f04:	01878633          	add	a2,a5,s8
    5f08:	78000793          	li	a5,1920
    5f0c:	02f12623          	sw	a5,44(sp)
    5f10:	81f00793          	li	a5,-2017
    5f14:	02f11b23          	sh	a5,54(sp)
    5f18:	01b037b3          	snez	a5,s11
    5f1c:	02c12223          	sw	a2,36(sp)
    5f20:	01640433          	add	s0,s0,s6
    5f24:	00141413          	slli	s0,s0,0x1
    5f28:	00d406b3          	add	a3,s0,a3
    5f2c:	00378793          	addi	a5,a5,3
    5f30:	001c9c93          	slli	s9,s9,0x1
    5f34:	02010613          	addi	a2,sp,32
    5f38:	02d12023          	sw	a3,32(sp)
    5f3c:	03912423          	sw	s9,40(sp)
    5f40:	02f10e23          	sb	a5,60(sp)
    5f44:	f39fe0ef          	jal	4e7c <append>
    5f48:	00050a13          	mv	s4,a0
    5f4c:	0a050e63          	beqz	a0,6008 <sprite+0x224>
    5f50:	07c12083          	lw	ra,124(sp)
    5f54:	07812403          	lw	s0,120(sp)
    5f58:	07412483          	lw	s1,116(sp)
    5f5c:	07012903          	lw	s2,112(sp)
    5f60:	06c12983          	lw	s3,108(sp)
    5f64:	06412a83          	lw	s5,100(sp)
    5f68:	06012b03          	lw	s6,96(sp)
    5f6c:	05c12b83          	lw	s7,92(sp)
    5f70:	05812c03          	lw	s8,88(sp)
    5f74:	05412c83          	lw	s9,84(sp)
    5f78:	05012d03          	lw	s10,80(sp)
    5f7c:	04c12d83          	lw	s11,76(sp)
    5f80:	000a0513          	mv	a0,s4
    5f84:	06812a03          	lw	s4,104(sp)
    5f88:	08010113          	addi	sp,sp,128
    5f8c:	00008067          	ret
    5f90:	008b6633          	or	a2,s6,s0
    5f94:	02060263          	beqz	a2,5fb8 <sprite+0x1d4>
    5f98:	00040613          	mv	a2,s0
    5f9c:	00000a13          	li	s4,0
    5fa0:	00940933          	add	s2,s0,s1
    5fa4:	016d09b3          	add	s3,s10,s6
    5fa8:	05267c63          	bgeu	a2,s2,6000 <sprite+0x21c>
    5fac:	f20a12e3          	bnez	s4,5ed0 <sprite+0xec>
    5fb0:	000b0593          	mv	a1,s6
    5fb4:	0380006f          	j	5fec <sprite+0x208>
    5fb8:	ff9d62e3          	bltu	s10,s9,5f9c <sprite+0x1b8>
    5fbc:	ff94e0e3          	bltu	s1,s9,5f9c <sprite+0x1b8>
    5fc0:	f11ff06f          	j	5ed0 <sprite+0xec>
    5fc4:	08012503          	lw	a0,128(sp)
    5fc8:	00d12e23          	sw	a3,28(sp)
    5fcc:	00c12c23          	sw	a2,24(sp)
    5fd0:	00b12a23          	sw	a1,20(sp)
    5fd4:	dc9ff0ef          	jal	5d9c <bullet_shape_opaque>
    5fd8:	01812603          	lw	a2,24(sp)
    5fdc:	01c12683          	lw	a3,28(sp)
    5fe0:	00051c63          	bnez	a0,5ff8 <sprite+0x214>
    5fe4:	01412583          	lw	a1,20(sp)
    5fe8:	00158593          	addi	a1,a1,1
    5fec:	fd35ece3          	bltu	a1,s3,5fc4 <sprite+0x1e0>
    5ff0:	00160613          	addi	a2,a2,1
    5ff4:	fb5ff06f          	j	5fa8 <sprite+0x1c4>
    5ff8:	00100a13          	li	s4,1
    5ffc:	ff5ff06f          	j	5ff0 <sprite+0x20c>
    6000:	f40a08e3          	beqz	s4,5f50 <sprite+0x16c>
    6004:	ecdff06f          	j	5ed0 <sprite+0xec>
    6008:	08412703          	lw	a4,132(sp)
    600c:	00100793          	li	a5,1
    6010:	00f72023          	sw	a5,0(a4)
    6014:	f3dff06f          	j	5f50 <sprite+0x16c>

00006018 <build_frame>:
    6018:	f4010113          	addi	sp,sp,-192
    601c:	0a112e23          	sw	ra,188(sp)
    6020:	0a812c23          	sw	s0,184(sp)
    6024:	0a912a23          	sw	s1,180(sp)
    6028:	0b212823          	sw	s2,176(sp)
    602c:	0b312623          	sw	s3,172(sp)
    6030:	0b412423          	sw	s4,168(sp)
    6034:	0b512223          	sw	s5,164(sp)
    6038:	0b612023          	sw	s6,160(sp)
    603c:	09712e23          	sw	s7,156(sp)
    6040:	09812c23          	sw	s8,152(sp)
    6044:	09912a23          	sw	s9,148(sp)
    6048:	09a12823          	sw	s10,144(sp)
    604c:	09b12623          	sw	s11,140(sp)
    6050:	00e12e23          	sw	a4,28(sp)
    6054:	04079463          	bnez	a5,609c <build_frame+0x84>
    6058:	ff800793          	li	a5,-8
    605c:	0bc12083          	lw	ra,188(sp)
    6060:	0b812403          	lw	s0,184(sp)
    6064:	0b412483          	lw	s1,180(sp)
    6068:	0b012903          	lw	s2,176(sp)
    606c:	0ac12983          	lw	s3,172(sp)
    6070:	0a812a03          	lw	s4,168(sp)
    6074:	0a412a83          	lw	s5,164(sp)
    6078:	0a012b03          	lw	s6,160(sp)
    607c:	09c12b83          	lw	s7,156(sp)
    6080:	09812c03          	lw	s8,152(sp)
    6084:	09412c83          	lw	s9,148(sp)
    6088:	09012d03          	lw	s10,144(sp)
    608c:	08c12d83          	lw	s11,140(sp)
    6090:	00078513          	mv	a0,a5
    6094:	0c010113          	addi	sp,sp,192
    6098:	00008067          	ret
    609c:	00078413          	mv	s0,a5
    60a0:	000097b7          	lui	a5,0x9
    60a4:	00f407b3          	add	a5,s0,a5
    60a8:	1207a823          	sw	zero,304(a5) # 9130 <v3_runtime_advance+0xb8>
    60ac:	1207a623          	sw	zero,300(a5)
    60b0:	1207a423          	sw	zero,296(a5)
    60b4:	1207a223          	sw	zero,292(a5)
    60b8:	1207a023          	sw	zero,288(a5)
    60bc:	00050493          	mv	s1,a0
    60c0:	f8050ce3          	beqz	a0,6058 <build_frame+0x40>
    60c4:	000057b7          	lui	a5,0x5
    60c8:	00f507b3          	add	a5,a0,a5
    60cc:	0087ab03          	lw	s6,8(a5) # 5008 <bullet_enemy_position+0x50>
    60d0:	3ff00793          	li	a5,1023
    60d4:	fffb0713          	addi	a4,s6,-1
    60d8:	f8e7e0e3          	bltu	a5,a4,6058 <build_frame+0x40>
    60dc:	01c12783          	lw	a5,28(sp)
    60e0:	48800713          	li	a4,1160
    60e4:	fff78793          	addi	a5,a5,-1
    60e8:	f6f768e3          	bltu	a4,a5,6058 <build_frame+0x40>
    60ec:	00058913          	mv	s2,a1
    60f0:	00060a93          	mv	s5,a2
    60f4:	00068b93          	mv	s7,a3
    60f8:	00080993          	mv	s3,a6
    60fc:	e41fe0ef          	jal	4f3c <bullet_campaign_valid>
    6100:	f4050ce3          	beqz	a0,6058 <build_frame+0x40>
    6104:	00100793          	li	a5,1
    6108:	f557e8e3          	bltu	a5,s5,6058 <build_frame+0x40>
    610c:	ffe007b7          	lui	a5,0xffe00
    6110:	fff78793          	addi	a5,a5,-1 # ffdfffff <__gpu_framebuffer_a+0xfddfffff>
    6114:	00f977b3          	and	a5,s2,a5
    6118:	02000737          	lui	a4,0x2000
    611c:	f2e79ee3          	bne	a5,a4,6058 <build_frame+0x40>
    6120:	02c00a37          	lui	s4,0x2c00
    6124:	000a8463          	beqz	s5,612c <build_frame+0x114>
    6128:	02a00a37          	lui	s4,0x2a00
    612c:	04012a23          	sw	zero,84(sp)
    6130:	04012c23          	sw	zero,88(sp)
    6134:	04012e23          	sw	zero,92(sp)
    6138:	02b007b7          	lui	a5,0x2b00
    613c:	000a8463          	beqz	s5,6144 <build_frame+0x12c>
    6140:	029007b7          	lui	a5,0x2900
    6144:	04f12023          	sw	a5,64(sp)
    6148:	78000793          	li	a5,1920
    614c:	04f12423          	sw	a5,72(sp)
    6150:	04f12623          	sw	a5,76(sp)
    6154:	01c12583          	lw	a1,28(sp)
    6158:	021c07b7          	lui	a5,0x21c0
    615c:	3c078793          	addi	a5,a5,960 # 21c03c0 <__gpu_framebuffer_a+0x1c03c0>
    6160:	04f12823          	sw	a5,80(sp)
    6164:	04010613          	addi	a2,sp,64
    6168:	00200793          	li	a5,2
    616c:	00040513          	mv	a0,s0
    6170:	04f10e23          	sb	a5,92(sp)
    6174:	05212223          	sw	s2,68(sp)
    6178:	d05fe0ef          	jal	4e7c <append>
    617c:	00050793          	mv	a5,a0
    6180:	00000a93          	li	s5,0
    6184:	00098a63          	beqz	s3,6198 <build_frame+0x180>
    6188:	00005737          	lui	a4,0x5
    618c:	00e48733          	add	a4,s1,a4
    6190:	02974a83          	lbu	s5,41(a4) # 5029 <bullet_enemy_position+0x71>
    6194:	01503ab3          	snez	s5,s5
    6198:	00005337          	lui	t1,0x5
    619c:	500a0713          	addi	a4,s4,1280 # 2a00500 <__gpu_framebuffer_a+0xa00500>
    61a0:	00010eb7          	lui	t4,0x10
    61a4:	00048d93          	mv	s11,s1
    61a8:	00000c13          	li	s8,0
    61ac:	00648cb3          	add	s9,s1,t1
    61b0:	02e12023          	sw	a4,32(sp)
    61b4:	fff00d13          	li	s10,-1
    61b8:	00300f13          	li	t5,3
    61bc:	fffe8e93          	addi	t4,t4,-1 # ffff <__global_pointer$+0x127f>
    61c0:	00079863          	bnez	a5,61d0 <build_frame+0x1b8>
    61c4:	000a9663          	bnez	s5,61d0 <build_frame+0x1b8>
    61c8:	000b8463          	beqz	s7,61d0 <build_frame+0x1b8>
    61cc:	036c6a63          	bltu	s8,s6,6200 <build_frame+0x1e8>
    61d0:	01400713          	li	a4,20
    61d4:	02eb0b33          	mul	s6,s6,a4
    61d8:	00009cb7          	lui	s9,0x9
    61dc:	00010d37          	lui	s10,0x10
    61e0:	00005db7          	lui	s11,0x5
    61e4:	00048c13          	mv	s8,s1
    61e8:	0019b313          	seqz	t1,s3
    61ec:	01940cb3          	add	s9,s0,s9
    61f0:	fffd0d13          	addi	s10,s10,-1 # ffff <__global_pointer$+0x127f>
    61f4:	01b48db3          	add	s11,s1,s11
    61f8:	01648b33          	add	s6,s1,s6
    61fc:	14c0006f          	j	6348 <build_frame+0x330>
    6200:	02098063          	beqz	s3,6220 <build_frame+0x208>
    6204:	00edc783          	lbu	a5,14(s11) # 500e <bullet_enemy_position+0x56>
    6208:	01e78663          	beq	a5,t5,6214 <build_frame+0x1fc>
    620c:	028cc783          	lbu	a5,40(s9) # 9028 <v3_runtime_game_command+0xf8>
    6210:	00078863          	beqz	a5,6220 <build_frame+0x208>
    6214:	00cdd703          	lhu	a4,12(s11)
    6218:	00000793          	li	a5,0
    621c:	07d70463          	beq	a4,t4,6284 <build_frame+0x26c>
    6220:	000da503          	lw	a0,0(s11)
    6224:	cf9fe0ef          	jal	4f1c <pixel_coordinate>
    6228:	02a12223          	sw	a0,36(sp)
    622c:	004da503          	lw	a0,4(s11)
    6230:	cedfe0ef          	jal	4f1c <pixel_coordinate>
    6234:	004ca883          	lw	a7,4(s9)
    6238:	02412703          	lw	a4,36(sp)
    623c:	02012683          	lw	a3,32(sp)
    6240:	01c12583          	lw	a1,28(sp)
    6244:	00f8f893          	andi	a7,a7,15
    6248:	03810793          	addi	a5,sp,56
    624c:	01088893          	addi	a7,a7,16
    6250:	00f12223          	sw	a5,4(sp)
    6254:	ffe70713          	addi	a4,a4,-2
    6258:	ffe50793          	addi	a5,a0,-2
    625c:	01a12023          	sw	s10,0(sp)
    6260:	00289893          	slli	a7,a7,0x2
    6264:	00c00813          	li	a6,12
    6268:	00090613          	mv	a2,s2
    626c:	00040513          	mv	a0,s0
    6270:	b75ff0ef          	jal	5de4 <sprite>
    6274:	00010737          	lui	a4,0x10
    6278:	00050793          	mv	a5,a0
    627c:	fff70e93          	addi	t4,a4,-1 # ffff <__global_pointer$+0x127f>
    6280:	00300f13          	li	t5,3
    6284:	008c0c13          	addi	s8,s8,8
    6288:	0a0d8d93          	addi	s11,s11,160
    628c:	f35ff06f          	j	61c0 <build_frame+0x1a8>
    6290:	00ec4703          	lbu	a4,14(s8)
    6294:	00133793          	seqz	a5,t1
    6298:	00278793          	addi	a5,a5,2
    629c:	1ae7c063          	blt	a5,a4,643c <build_frame+0x424>
    62a0:	00fc4603          	lbu	a2,15(s8)
    62a4:	00500793          	li	a5,5
    62a8:	18c7ea63          	bltu	a5,a2,643c <build_frame+0x424>
    62ac:	00300793          	li	a5,3
    62b0:	00f70863          	beq	a4,a5,62c0 <build_frame+0x2a8>
    62b4:	00098c63          	beqz	s3,62cc <build_frame+0x2b4>
    62b8:	028dc783          	lbu	a5,40(s11)
    62bc:	00078863          	beqz	a5,62cc <build_frame+0x2b4>
    62c0:	00cc5703          	lhu	a4,12(s8)
    62c4:	00000793          	li	a5,0
    62c8:	07a70e63          	beq	a4,s10,6344 <build_frame+0x32c>
    62cc:	000c2503          	lw	a0,0(s8)
    62d0:	00761693          	slli	a3,a2,0x7
    62d4:	014686b3          	add	a3,a3,s4
    62d8:	02612623          	sw	t1,44(sp)
    62dc:	02c12423          	sw	a2,40(sp)
    62e0:	02d12223          	sw	a3,36(sp)
    62e4:	c39fe0ef          	jal	4f1c <pixel_coordinate>
    62e8:	02a12023          	sw	a0,32(sp)
    62ec:	004c2503          	lw	a0,4(s8)
    62f0:	c2dfe0ef          	jal	4f1c <pixel_coordinate>
    62f4:	02812603          	lw	a2,40(sp)
    62f8:	03810593          	addi	a1,sp,56
    62fc:	00b12223          	sw	a1,4(sp)
    6300:	02012703          	lw	a4,32(sp)
    6304:	02412683          	lw	a3,36(sp)
    6308:	01c12583          	lw	a1,28(sp)
    630c:	00050793          	mv	a5,a0
    6310:	00c12023          	sw	a2,0(sp)
    6314:	00000893          	li	a7,0
    6318:	00800813          	li	a6,8
    631c:	00090613          	mv	a2,s2
    6320:	00040513          	mv	a0,s0
    6324:	ac1ff0ef          	jal	5de4 <sprite>
    6328:	02c12303          	lw	t1,44(sp)
    632c:	00050793          	mv	a5,a0
    6330:	00051a63          	bnez	a0,6344 <build_frame+0x32c>
    6334:	124ca703          	lw	a4,292(s9)
    6338:	03812683          	lw	a3,56(sp)
    633c:	00d70733          	add	a4,a4,a3
    6340:	12eca223          	sw	a4,292(s9)
    6344:	014c0c13          	addi	s8,s8,20
    6348:	00079663          	bnez	a5,6354 <build_frame+0x33c>
    634c:	000a9463          	bnez	s5,6354 <build_frame+0x33c>
    6350:	f56c10e3          	bne	s8,s6,6290 <build_frame+0x278>
    6354:	00005637          	lui	a2,0x5
    6358:	00c48633          	add	a2,s1,a2
    635c:	02464c03          	lbu	s8,36(a2) # 5024 <bullet_enemy_position+0x6c>
    6360:	0a079463          	bnez	a5,6408 <build_frame+0x3f0>
    6364:	0e0b8063          	beqz	s7,6444 <build_frame+0x42c>
    6368:	05000b13          	li	s6,80
    636c:	0e0c0063          	beqz	s8,644c <build_frame+0x434>
    6370:	00c62703          	lw	a4,12(a2)
    6374:	01062783          	lw	a5,16(a2)
    6378:	02065603          	lhu	a2,32(a2)
    637c:	500a0693          	addi	a3,s4,1280
    6380:	ffa70713          	addi	a4,a4,-6
    6384:	ffa78793          	addi	a5,a5,-6
    6388:	04000893          	li	a7,64
    638c:	00060463          	beqz	a2,6394 <build_frame+0x37c>
    6390:	0c000893          	li	a7,192
    6394:	03810613          	addi	a2,sp,56
    6398:	01c12583          	lw	a1,28(sp)
    639c:	00c12223          	sw	a2,4(sp)
    63a0:	fff00613          	li	a2,-1
    63a4:	00c12023          	sw	a2,0(sp)
    63a8:	00c00813          	li	a6,12
    63ac:	00090613          	mv	a2,s2
    63b0:	00040513          	mv	a0,s0
    63b4:	a31ff0ef          	jal	5de4 <sprite>
    63b8:	00050793          	mv	a5,a0
    63bc:	04051a63          	bnez	a0,6410 <build_frame+0x3f8>
    63c0:	00005737          	lui	a4,0x5
    63c4:	00e48733          	add	a4,s1,a4
    63c8:	01072783          	lw	a5,16(a4) # 5010 <bullet_enemy_position+0x58>
    63cc:	00c72703          	lw	a4,12(a4)
    63d0:	03810693          	addi	a3,sp,56
    63d4:	01c12583          	lw	a1,28(sp)
    63d8:	00d12223          	sw	a3,4(sp)
    63dc:	fff00693          	li	a3,-1
    63e0:	00d12023          	sw	a3,0(sp)
    63e4:	ff878793          	addi	a5,a5,-8
    63e8:	00000893          	li	a7,0
    63ec:	01000813          	li	a6,16
    63f0:	ff870713          	addi	a4,a4,-8
    63f4:	300a0693          	addi	a3,s4,768
    63f8:	00090613          	mv	a2,s2
    63fc:	00040513          	mv	a0,s0
    6400:	9e5ff0ef          	jal	5de4 <sprite>
    6404:	00050793          	mv	a5,a0
    6408:	05000b13          	li	s6,80
    640c:	040c0063          	beqz	s8,644c <build_frame+0x434>
    6410:	00005737          	lui	a4,0x5
    6414:	00e48733          	add	a4,s1,a4
    6418:	01472703          	lw	a4,20(a4) # 5014 <bullet_enemy_position+0x5c>
    641c:	03c00693          	li	a3,60
    6420:	05000b13          	li	s6,80
    6424:	02d77733          	remu	a4,a4,a3
    6428:	02b00693          	li	a3,43
    642c:	02e6f063          	bgeu	a3,a4,644c <build_frame+0x434>
    6430:	fdf70713          	addi	a4,a4,-33
    6434:	00371b13          	slli	s6,a4,0x3
    6438:	0140006f          	j	644c <build_frame+0x434>
    643c:	ff800793          	li	a5,-8
    6440:	f15ff06f          	j	6354 <build_frame+0x33c>
    6444:	05000b13          	li	s6,80
    6448:	f60c1ce3          	bnez	s8,63c0 <build_frame+0x3a8>
    644c:	0000e337          	lui	t1,0xe
    6450:	00348713          	addi	a4,s1,3
    6454:	00005cb7          	lui	s9,0x5
    6458:	620a0c13          	addi	s8,s4,1568
    645c:	cf030d93          	addi	s11,t1,-784 # dcf0 <centers>
    6460:	02e12023          	sw	a4,32(sp)
    6464:	00048d13          	mv	s10,s1
    6468:	01948cb3          	add	s9,s1,s9
    646c:	08079a63          	bnez	a5,6500 <build_frame+0x4e8>
    6470:	02012703          	lw	a4,32(sp)
    6474:	0ba71663          	bne	a4,s10,6520 <build_frame+0x508>
    6478:	be0a82e3          	beqz	s5,605c <build_frame+0x44>
    647c:	02000613          	li	a2,32
    6480:	00000593          	li	a1,0
    6484:	06010513          	addi	a0,sp,96
    6488:	02f12023          	sw	a5,32(sp)
    648c:	d9dfa0ef          	jal	1228 <memset>
    6490:	00053737          	lui	a4,0x53
    6494:	ad070713          	addi	a4,a4,-1328 # 52ad0 <__freertos_irq_stack_top+0x35030>
    6498:	00e90733          	add	a4,s2,a4
    649c:	06e12223          	sw	a4,100(sp)
    64a0:	78000713          	li	a4,1920
    64a4:	06e12623          	sw	a4,108(sp)
    64a8:	009c0737          	lui	a4,0x9c0
    64ac:	0f070713          	addi	a4,a4,240 # 9c00f0 <__freertos_irq_stack_top+0x9a2650>
    64b0:	01c12583          	lw	a1,28(sp)
    64b4:	06e12823          	sw	a4,112(sp)
    64b8:	00b00713          	li	a4,11
    64bc:	06e11a23          	sh	a4,116(sp)
    64c0:	06010613          	addi	a2,sp,96
    64c4:	00100713          	li	a4,1
    64c8:	00040513          	mv	a0,s0
    64cc:	06e10e23          	sb	a4,124(sp)
    64d0:	9adfe0ef          	jal	4e7c <append>
    64d4:	02012783          	lw	a5,32(sp)
    64d8:	0000eab7          	lui	s5,0xe
    64dc:	00010c37          	lui	s8,0x10
    64e0:	ca0a8a93          	addi	s5,s5,-864 # dca0 <columns.0>
    64e4:	00000a13          	li	s4,0
    64e8:	00400693          	li	a3,4
    64ec:	fe0c0c13          	addi	s8,s8,-32 # ffe0 <__global_pointer$+0x1260>
    64f0:	00700c93          	li	s9,7
    64f4:	3c000813          	li	a6,960
    64f8:	1c050a63          	beqz	a0,66cc <build_frame+0x6b4>
    64fc:	00050793          	mv	a5,a0
    6500:	00009737          	lui	a4,0x9
    6504:	00e40433          	add	s0,s0,a4
    6508:	12042823          	sw	zero,304(s0)
    650c:	12042623          	sw	zero,300(s0)
    6510:	12042423          	sw	zero,296(s0)
    6514:	12042223          	sw	zero,292(s0)
    6518:	12042023          	sw	zero,288(s0)
    651c:	b41ff06f          	j	605c <build_frame+0x44>
    6520:	02098063          	beqz	s3,6540 <build_frame+0x528>
    6524:	028cc703          	lbu	a4,40(s9) # 5028 <bullet_enemy_position+0x70>
    6528:	00070c63          	beqz	a4,6540 <build_frame+0x528>
    652c:	00005737          	lui	a4,0x5
    6530:	02570713          	addi	a4,a4,37 # 5025 <bullet_enemy_position+0x6d>
    6534:	00ed0733          	add	a4,s10,a4
    6538:	00074703          	lbu	a4,0(a4)
    653c:	06070863          	beqz	a4,65ac <build_frame+0x594>
    6540:	000da783          	lw	a5,0(s11)
    6544:	02f12e23          	sw	a5,60(sp)
    6548:	004da783          	lw	a5,4(s11)
    654c:	06f12023          	sw	a5,96(sp)
    6550:	00098c63          	beqz	s3,6568 <build_frame+0x550>
    6554:	06010693          	addi	a3,sp,96
    6558:	03c10613          	addi	a2,sp,60
    655c:	409d05b3          	sub	a1,s10,s1
    6560:	00048513          	mv	a0,s1
    6564:	a55fe0ef          	jal	4fb8 <bullet_enemy_position>
    6568:	03c12e83          	lw	t4,60(sp)
    656c:	06012f03          	lw	t5,96(sp)
    6570:	040b9663          	bnez	s7,65bc <build_frame+0x5a4>
    6574:	03810793          	addi	a5,sp,56
    6578:	01c12583          	lw	a1,28(sp)
    657c:	00f12223          	sw	a5,4(sp)
    6580:	fff00793          	li	a5,-1
    6584:	00f12023          	sw	a5,0(sp)
    6588:	00000893          	li	a7,0
    658c:	ff8f0793          	addi	a5,t5,-8
    6590:	01000813          	li	a6,16
    6594:	ff8e8713          	addi	a4,t4,-8
    6598:	000c0693          	mv	a3,s8
    659c:	00090613          	mv	a2,s2
    65a0:	00040513          	mv	a0,s0
    65a4:	841ff0ef          	jal	5de4 <sprite>
    65a8:	00050793          	mv	a5,a0
    65ac:	001d0d13          	addi	s10,s10,1
    65b0:	200c0c13          	addi	s8,s8,512
    65b4:	008d8d93          	addi	s11,s11,8
    65b8:	eb5ff06f          	j	646c <build_frame+0x454>
    65bc:	03810793          	addi	a5,sp,56
    65c0:	01c12583          	lw	a1,28(sp)
    65c4:	00f12223          	sw	a5,4(sp)
    65c8:	fff00793          	li	a5,-1
    65cc:	00f12023          	sw	a5,0(sp)
    65d0:	ffae8713          	addi	a4,t4,-6
    65d4:	ffaf0793          	addi	a5,t5,-6
    65d8:	000b0893          	mv	a7,s6
    65dc:	00c00813          	li	a6,12
    65e0:	500a0693          	addi	a3,s4,1280
    65e4:	00090613          	mv	a2,s2
    65e8:	00040513          	mv	a0,s0
    65ec:	03e12423          	sw	t5,40(sp)
    65f0:	03d12223          	sw	t4,36(sp)
    65f4:	ff0ff0ef          	jal	5de4 <sprite>
    65f8:	02412e83          	lw	t4,36(sp)
    65fc:	02812f03          	lw	t5,40(sp)
    6600:	00050793          	mv	a5,a0
    6604:	fa0514e3          	bnez	a0,65ac <build_frame+0x594>
    6608:	f6dff06f          	j	6574 <build_frame+0x55c>
    660c:	00300b93          	li	s7,3
    6610:	1d800493          	li	s1,472
    6614:	11a00d93          	li	s11,282
    6618:	000c0713          	mv	a4,s8
    661c:	0d40006f          	j	66f0 <build_frame+0x6d8>
    6620:	00098613          	mv	a2,s3
    6624:	0008c583          	lbu	a1,0(a7)
    6628:	00160993          	addi	s3,a2,1
    662c:	00c5d733          	srl	a4,a1,a2
    6630:	00177713          	andi	a4,a4,1
    6634:	06070a63          	beqz	a4,66a8 <build_frame+0x690>
    6638:	00060993          	mv	s3,a2
    663c:	00198993          	addi	s3,s3,1
    6640:	01998863          	beq	s3,s9,6650 <build_frame+0x638>
    6644:	0135d733          	srl	a4,a1,s3
    6648:	00177713          	andi	a4,a4,1
    664c:	fe0718e3          	bnez	a4,663c <build_frame+0x624>
    6650:	03760733          	mul	a4,a2,s7
    6654:	40c98633          	sub	a2,s3,a2
    6658:	01c12583          	lw	a1,28(sp)
    665c:	00040513          	mv	a0,s0
    6660:	03112223          	sw	a7,36(sp)
    6664:	02f12023          	sw	a5,32(sp)
    6668:	01b70733          	add	a4,a4,s11
    666c:	03070733          	mul	a4,a4,a6
    6670:	02cd0633          	mul	a2,s10,a2
    6674:	00970733          	add	a4,a4,s1
    6678:	00171713          	slli	a4,a4,0x1
    667c:	01270733          	add	a4,a4,s2
    6680:	06e12223          	sw	a4,100(sp)
    6684:	06c11923          	sh	a2,114(sp)
    6688:	06010613          	addi	a2,sp,96
    668c:	ff0fe0ef          	jal	4e7c <append>
    6690:	02012783          	lw	a5,32(sp)
    6694:	02412883          	lw	a7,36(sp)
    6698:	3c000813          	li	a6,960
    669c:	00500313          	li	t1,5
    66a0:	00400693          	li	a3,4
    66a4:	00051663          	bnez	a0,66b0 <build_frame+0x698>
    66a8:	f7999ce3          	bne	s3,s9,6620 <build_frame+0x608>
    66ac:	00000513          	li	a0,0
    66b0:	001b0b13          	addi	s6,s6,1
    66b4:	00051663          	bnez	a0,66c0 <build_frame+0x6a8>
    66b8:	017484b3          	add	s1,s1,s7
    66bc:	046b1663          	bne	s6,t1,6708 <build_frame+0x6f0>
    66c0:	001a0a13          	addi	s4,s4,1
    66c4:	005a8a93          	addi	s5,s5,5
    66c8:	e31ff06f          	j	64f8 <build_frame+0x4e0>
    66cc:	98da08e3          	beq	s4,a3,605c <build_frame+0x44>
    66d0:	00300713          	li	a4,3
    66d4:	f2ea0ce3          	beq	s4,a4,660c <build_frame+0x5f4>
    66d8:	03800493          	li	s1,56
    66dc:	029a04b3          	mul	s1,s4,s1
    66e0:	00800b93          	li	s7,8
    66e4:	0d000d93          	li	s11,208
    66e8:	7e000713          	li	a4,2016
    66ec:	19448493          	addi	s1,s1,404
    66f0:	010b9d13          	slli	s10,s7,0x10
    66f4:	010d5d13          	srli	s10,s10,0x10
    66f8:	06e11a23          	sh	a4,116(sp)
    66fc:	07a11823          	sh	s10,112(sp)
    6700:	00000b13          	li	s6,0
    6704:	00500313          	li	t1,5
    6708:	00000613          	li	a2,0
    670c:	016a88b3          	add	a7,s5,s6
    6710:	f15ff06f          	j	6624 <build_frame+0x60c>

00006714 <bullet_build_frame_player>:
    6714:	00100813          	li	a6,1
    6718:	901ff06f          	j	6018 <build_frame>

0000671c <bullet_clip_background_for_hud>:
    671c:	00050793          	mv	a5,a0
    6720:	0c050c63          	beqz	a0,67f8 <bullet_clip_background_for_hud+0xdc>
    6724:	00009737          	lui	a4,0x9
    6728:	00e50733          	add	a4,a0,a4
    672c:	12072703          	lw	a4,288(a4) # 9120 <v3_runtime_advance+0xa8>
    6730:	ff800513          	li	a0,-8
    6734:	0c070463          	beqz	a4,67fc <bullet_clip_background_for_hud+0xe0>
    6738:	21b00713          	li	a4,539
    673c:	0cb76063          	bltu	a4,a1,67fc <bullet_clip_background_for_hud+0xe0>
    6740:	01c7c683          	lbu	a3,28(a5)
    6744:	00200713          	li	a4,2
    6748:	0ae69a63          	bne	a3,a4,67fc <bullet_clip_background_for_hud+0xe0>
    674c:	0107a683          	lw	a3,16(a5)
    6750:	021c0737          	lui	a4,0x21c0
    6754:	3c070713          	addi	a4,a4,960 # 21c03c0 <__gpu_framebuffer_a+0x1c03c0>
    6758:	0ae69263          	bne	a3,a4,67fc <bullet_clip_background_for_hud+0xe0>
    675c:	0087a703          	lw	a4,8(a5)
    6760:	78000693          	li	a3,1920
    6764:	08d71c63          	bne	a4,a3,67fc <bullet_clip_background_for_hud+0xe0>
    6768:	00c7a683          	lw	a3,12(a5)
    676c:	08e69863          	bne	a3,a4,67fc <bullet_clip_background_for_hud+0xe0>
    6770:	0047a803          	lw	a6,4(a5)
    6774:	ffe00737          	lui	a4,0xffe00
    6778:	fff70713          	addi	a4,a4,-1 # ffdfffff <__gpu_framebuffer_a+0xfddfffff>
    677c:	00e87733          	and	a4,a6,a4
    6780:	020006b7          	lui	a3,0x2000
    6784:	06d71c63          	bne	a4,a3,67fc <bullet_clip_background_for_hud+0xe0>
    6788:	0007a683          	lw	a3,0(a5)
    678c:	000fd737          	lui	a4,0xfd
    6790:	20070713          	addi	a4,a4,512 # fd200 <__freertos_irq_stack_top+0xdf760>
    6794:	00e68733          	add	a4,a3,a4
    6798:	06d76063          	bltu	a4,a3,67f8 <bullet_clip_background_for_hud+0xdc>
    679c:	10000637          	lui	a2,0x10000
    67a0:	04e66c63          	bltu	a2,a4,67f8 <bullet_clip_background_for_hud+0xdc>
    67a4:	00009737          	lui	a4,0x9
    67a8:	00e78733          	add	a4,a5,a4
    67ac:	12872603          	lw	a2,296(a4) # 9128 <v3_runtime_advance+0xb0>
    67b0:	0007f8b7          	lui	a7,0x7f
    67b4:	8ff88893          	addi	a7,a7,-1793 # 7e8ff <__freertos_irq_stack_top+0x60e5f>
    67b8:	04c8f263          	bgeu	a7,a2,67fc <bullet_clip_background_for_hud+0xe0>
    67bc:	78000513          	li	a0,1920
    67c0:	02a58533          	mul	a0,a1,a0
    67c4:	00a686b3          	add	a3,a3,a0
    67c8:	00d7a023          	sw	a3,0(a5)
    67cc:	21c00693          	li	a3,540
    67d0:	00a80833          	add	a6,a6,a0
    67d4:	40b686b3          	sub	a3,a3,a1
    67d8:	0107a223          	sw	a6,4(a5)
    67dc:	00d79923          	sh	a3,18(a5)
    67e0:	3c000793          	li	a5,960
    67e4:	02f585b3          	mul	a1,a1,a5
    67e8:	00000513          	li	a0,0
    67ec:	40b60633          	sub	a2,a2,a1
    67f0:	12c72423          	sw	a2,296(a4)
    67f4:	00008067          	ret
    67f8:	ff800513          	li	a0,-8
    67fc:	00008067          	ret

00006800 <_putchar>:
    6800:	f80107b7          	lui	a5,0xf8010
    6804:	00478793          	addi	a5,a5,4 # f8010004 <__gpu_framebuffer_a+0xf6010004>
    6808:	0007a703          	lw	a4,0(a5)
    680c:	01075693          	srli	a3,a4,0x10
    6810:	0ff6f693          	zext.b	a3,a3
    6814:	fe068ae3          	beqz	a3,6808 <_putchar+0x8>
    6818:	f80107b7          	lui	a5,0xf8010
    681c:	00a7a023          	sw	a0,0(a5) # f8010000 <__gpu_framebuffer_a+0xf6010000>
    6820:	00008067          	ret

00006824 <bsp_printf.constprop.0>:
    6824:	f8010113          	addi	sp,sp,-128
    6828:	05312623          	sw	s3,76(sp)
    682c:	06f12a23          	sw	a5,116(sp)
    6830:	0000d9b7          	lui	s3,0xd
    6834:	06410793          	addi	a5,sp,100
    6838:	05212823          	sw	s2,80(sp)
    683c:	05412423          	sw	s4,72(sp)
    6840:	05512223          	sw	s5,68(sp)
    6844:	05612023          	sw	s6,64(sp)
    6848:	03712e23          	sw	s7,60(sp)
    684c:	04112e23          	sw	ra,92(sp)
    6850:	04812c23          	sw	s0,88(sp)
    6854:	04912a23          	sw	s1,84(sp)
    6858:	03812c23          	sw	s8,56(sp)
    685c:	03912a23          	sw	s9,52(sp)
    6860:	06b12223          	sw	a1,100(sp)
    6864:	06c12423          	sw	a2,104(sp)
    6868:	06d12623          	sw	a3,108(sp)
    686c:	06e12823          	sw	a4,112(sp)
    6870:	07012c23          	sw	a6,120(sp)
    6874:	07112e23          	sw	a7,124(sp)
    6878:	00f12623          	sw	a5,12(sp)
    687c:	00000913          	li	s2,0
    6880:	5c098993          	addi	s3,s3,1472 # d5c0 <_data+0x314>
    6884:	02500a13          	li	s4,37
    6888:	06600a93          	li	s5,102
    688c:	06600b13          	li	s6,102
    6890:	06300b93          	li	s7,99
    6894:	013907b3          	add	a5,s2,s3
    6898:	0007c503          	lbu	a0,0(a5)
    689c:	02051c63          	bnez	a0,68d4 <bsp_printf.constprop.0+0xb0>
    68a0:	05c12083          	lw	ra,92(sp)
    68a4:	05812403          	lw	s0,88(sp)
    68a8:	05412483          	lw	s1,84(sp)
    68ac:	05012903          	lw	s2,80(sp)
    68b0:	04c12983          	lw	s3,76(sp)
    68b4:	04812a03          	lw	s4,72(sp)
    68b8:	04412a83          	lw	s5,68(sp)
    68bc:	04012b03          	lw	s6,64(sp)
    68c0:	03c12b83          	lw	s7,60(sp)
    68c4:	03812c03          	lw	s8,56(sp)
    68c8:	03412c83          	lw	s9,52(sp)
    68cc:	08010113          	addi	sp,sp,128
    68d0:	00008067          	ret
    68d4:	0d451863          	bne	a0,s4,69a4 <bsp_printf.constprop.0+0x180>
    68d8:	00190913          	addi	s2,s2,1
    68dc:	012987b3          	add	a5,s3,s2
    68e0:	0007c783          	lbu	a5,0(a5)
    68e4:	0e078063          	beqz	a5,69c4 <bsp_printf.constprop.0+0x1a0>
    68e8:	17578263          	beq	a5,s5,6a4c <bsp_printf.constprop.0+0x228>
    68ec:	04fb6c63          	bltu	s6,a5,6944 <bsp_printf.constprop.0+0x120>
    68f0:	0b778263          	beq	a5,s7,6994 <bsp_printf.constprop.0+0x170>
    68f4:	06400713          	li	a4,100
    68f8:	0ee78063          	beq	a5,a4,69d8 <bsp_printf.constprop.0+0x1b4>
    68fc:	05800713          	li	a4,88
    6900:	fce79ce3          	bne	a5,a4,68d8 <bsp_printf.constprop.0+0xb4>
    6904:	00c12783          	lw	a5,12(sp)
    6908:	0000d4b7          	lui	s1,0xd
    690c:	01c00413          	li	s0,28
    6910:	0007ac83          	lw	s9,0(a5)
    6914:	00478713          	addi	a4,a5,4
    6918:	00e12623          	sw	a4,12(sp)
    691c:	2f848493          	addi	s1,s1,760 # d2f8 <_data+0x4c>
    6920:	ffc00c13          	li	s8,-4
    6924:	008cd7b3          	srl	a5,s9,s0
    6928:	00f7f793          	andi	a5,a5,15
    692c:	00f487b3          	add	a5,s1,a5
    6930:	0007c503          	lbu	a0,0(a5)
    6934:	ffc40413          	addi	s0,s0,-4
    6938:	ec9ff0ef          	jal	6800 <_putchar>
    693c:	ff8414e3          	bne	s0,s8,6924 <bsp_printf.constprop.0+0x100>
    6940:	0840006f          	j	69c4 <bsp_printf.constprop.0+0x1a0>
    6944:	07300713          	li	a4,115
    6948:	06e78263          	beq	a5,a4,69ac <bsp_printf.constprop.0+0x188>
    694c:	07800713          	li	a4,120
    6950:	f8e794e3          	bne	a5,a4,68d8 <bsp_printf.constprop.0+0xb4>
    6954:	00c12783          	lw	a5,12(sp)
    6958:	0000d4b7          	lui	s1,0xd
    695c:	01c00413          	li	s0,28
    6960:	0007ac83          	lw	s9,0(a5)
    6964:	00478713          	addi	a4,a5,4
    6968:	00e12623          	sw	a4,12(sp)
    696c:	30c48493          	addi	s1,s1,780 # d30c <_data+0x60>
    6970:	ffc00c13          	li	s8,-4
    6974:	008cd7b3          	srl	a5,s9,s0
    6978:	00f7f793          	andi	a5,a5,15
    697c:	00f487b3          	add	a5,s1,a5
    6980:	0007c503          	lbu	a0,0(a5)
    6984:	ffc40413          	addi	s0,s0,-4
    6988:	e79ff0ef          	jal	6800 <_putchar>
    698c:	ff8414e3          	bne	s0,s8,6974 <bsp_printf.constprop.0+0x150>
    6990:	0340006f          	j	69c4 <bsp_printf.constprop.0+0x1a0>
    6994:	00c12783          	lw	a5,12(sp)
    6998:	0007c503          	lbu	a0,0(a5)
    699c:	00478713          	addi	a4,a5,4
    69a0:	00e12623          	sw	a4,12(sp)
    69a4:	e5dff0ef          	jal	6800 <_putchar>
    69a8:	01c0006f          	j	69c4 <bsp_printf.constprop.0+0x1a0>
    69ac:	00c12783          	lw	a5,12(sp)
    69b0:	0007a403          	lw	s0,0(a5)
    69b4:	00478713          	addi	a4,a5,4
    69b8:	00e12623          	sw	a4,12(sp)
    69bc:	00044503          	lbu	a0,0(s0)
    69c0:	00051663          	bnez	a0,69cc <bsp_printf.constprop.0+0x1a8>
    69c4:	00190913          	addi	s2,s2,1
    69c8:	ecdff06f          	j	6894 <bsp_printf.constprop.0+0x70>
    69cc:	00140413          	addi	s0,s0,1
    69d0:	e31ff0ef          	jal	6800 <_putchar>
    69d4:	fe9ff06f          	j	69bc <bsp_printf.constprop.0+0x198>
    69d8:	00c12783          	lw	a5,12(sp)
    69dc:	0007a483          	lw	s1,0(a5)
    69e0:	00478713          	addi	a4,a5,4
    69e4:	00e12623          	sw	a4,12(sp)
    69e8:	0004d863          	bgez	s1,69f8 <bsp_printf.constprop.0+0x1d4>
    69ec:	02d00513          	li	a0,45
    69f0:	e11ff0ef          	jal	6800 <_putchar>
    69f4:	409004b3          	neg	s1,s1
    69f8:	01010413          	addi	s0,sp,16
    69fc:	00040c13          	mv	s8,s0
    6a00:	00a00713          	li	a4,10
    6a04:	00049e63          	bnez	s1,6a20 <bsp_printf.constprop.0+0x1fc>
    6a08:	01840c63          	beq	s0,s8,6a20 <bsp_printf.constprop.0+0x1fc>
    6a0c:	fff44503          	lbu	a0,-1(s0)
    6a10:	fff40413          	addi	s0,s0,-1
    6a14:	dedff0ef          	jal	6800 <_putchar>
    6a18:	ff841ae3          	bne	s0,s8,6a0c <bsp_printf.constprop.0+0x1e8>
    6a1c:	fa9ff06f          	j	69c4 <bsp_printf.constprop.0+0x1a0>
    6a20:	02e4e7b3          	rem	a5,s1,a4
    6a24:	00140413          	addi	s0,s0,1
    6a28:	03078793          	addi	a5,a5,48
    6a2c:	02e4c4b3          	div	s1,s1,a4
    6a30:	fef40fa3          	sb	a5,-1(s0)
    6a34:	fd1ff06f          	j	6a04 <bsp_printf.constprop.0+0x1e0>
    6a38:	00140413          	addi	s0,s0,1
    6a3c:	dc5ff0ef          	jal	6800 <_putchar>
    6a40:	00044503          	lbu	a0,0(s0)
    6a44:	fe051ae3          	bnez	a0,6a38 <bsp_printf.constprop.0+0x214>
    6a48:	f7dff06f          	j	69c4 <bsp_printf.constprop.0+0x1a0>
    6a4c:	0000d437          	lui	s0,0xd
    6a50:	2ac40413          	addi	s0,s0,684 # d2ac <_data>
    6a54:	fedff06f          	j	6a40 <bsp_printf.constprop.0+0x21c>

00006a58 <bullet_init_local_assets>:
    6a58:	fb010113          	addi	sp,sp,-80
    6a5c:	04812423          	sw	s0,72(sp)
    6a60:	00001e37          	lui	t3,0x1
    6a64:	00001eb7          	lui	t4,0x1
    6a68:	00001f37          	lui	t5,0x1
    6a6c:	00002fb7          	lui	t6,0x2
    6a70:	000022b7          	lui	t0,0x2
    6a74:	000053b7          	lui	t2,0x5
    6a78:	00003437          	lui	s0,0x3
    6a7c:	03412c23          	sw	s4,56(sp)
    6a80:	03512a23          	sw	s5,52(sp)
    6a84:	03612823          	sw	s6,48(sp)
    6a88:	03712623          	sw	s7,44(sp)
    6a8c:	01b12e23          	sw	s11,28(sp)
    6a90:	04112623          	sw	ra,76(sp)
    6a94:	04912223          	sw	s1,68(sp)
    6a98:	05212023          	sw	s2,64(sp)
    6a9c:	03312e23          	sw	s3,60(sp)
    6aa0:	03812423          	sw	s8,40(sp)
    6aa4:	03912223          	sw	s9,36(sp)
    6aa8:	03a12023          	sw	s10,32(sp)
    6aac:	00000713          	li	a4,0
    6ab0:	05a00d93          	li	s11,90
    6ab4:	800e0e13          	addi	t3,t3,-2048 # 800 <CUSTOM2+0x7a5>
    6ab8:	03c00b93          	li	s7,60
    6abc:	07800b13          	li	s6,120
    6ac0:	01800a93          	li	s5,24
    6ac4:	00300a13          	li	s4,3
    6ac8:	107e8e93          	addi	t4,t4,263 # 1107 <strchr+0x1f>
    6acc:	ffdf0f13          	addi	t5,t5,-3 # ffd <CUSTOM2+0xfa2>
    6ad0:	a2cf8f93          	addi	t6,t6,-1492 # 1a2c <gpu_init+0x60>
    6ad4:	1af28293          	addi	t0,t0,431 # 21af <gpu_submit+0x327>
    6ad8:	a7138393          	addi	t2,t2,-1423 # 4a71 <perf_render_cpu+0xcd>
    6adc:	9ad40413          	addi	s0,s0,-1619 # 29ad <golden_copy+0xd1>
    6ae0:	03b756b3          	divu	a3,a4,s11
    6ae4:	08700793          	li	a5,135
    6ae8:	fb870893          	addi	a7,a4,-72
    6aec:	78000593          	li	a1,1920
    6af0:	09700813          	li	a6,151
    6af4:	00000313          	li	t1,0
    6af8:	00000613          	li	a2,0
    6afc:	00200913          	li	s2,2
    6b00:	3c000c13          	li	s8,960
    6b04:	02f757b3          	divu	a5,a4,a5
    6b08:	00368693          	addi	a3,a3,3 # 2000003 <__gpu_framebuffer_a+0x3>
    6b0c:	00569693          	slli	a3,a3,0x5
    6b10:	00778793          	addi	a5,a5,7
    6b14:	00f6e6b3          	or	a3,a3,a5
    6b18:	035757b3          	divu	a5,a4,s5
    6b1c:	01c6e6b3          	or	a3,a3,t3
    6b20:	01069693          	slli	a3,a3,0x10
    6b24:	0106d693          	srli	a3,a3,0x10
    6b28:	0378fd33          	remu	s10,a7,s7
    6b2c:	00f12423          	sw	a5,8(sp)
    6b30:	02b007b7          	lui	a5,0x2b00
    6b34:	0368fcb3          	remu	s9,a7,s6
    6b38:	02b705b3          	mul	a1,a4,a1
    6b3c:	00f585b3          	add	a1,a1,a5
    6b40:	034707b3          	mul	a5,a4,s4
    6b44:	03070833          	mul	a6,a4,a6
    6b48:	00f12623          	sw	a5,12(sp)
    6b4c:	21b00793          	li	a5,539
    6b50:	40e789b3          	sub	s3,a5,a4
    6b54:	04700793          	li	a5,71
    6b58:	00000513          	li	a0,0
    6b5c:	08e7f263          	bgeu	a5,a4,6be0 <bullet_init_local_assets+0x188>
    6b60:	00098793          	mv	a5,s3
    6b64:	0138f463          	bgeu	a7,s3,6b6c <bullet_init_local_assets+0x114>
    6b68:	00088793          	mv	a5,a7
    6b6c:	00f67463          	bgeu	a2,a5,6b74 <bullet_init_local_assets+0x11c>
    6b70:	00060793          	mv	a5,a2
    6b74:	3bf00513          	li	a0,959
    6b78:	40c50533          	sub	a0,a0,a2
    6b7c:	00f57463          	bgeu	a0,a5,6b84 <bullet_init_local_assets+0x12c>
    6b80:	00050793          	mv	a5,a0
    6b84:	037674b3          	remu	s1,a2,s7
    6b88:	000e8513          	mv	a0,t4
    6b8c:	00048663          	beqz	s1,6b98 <bullet_init_local_assets+0x140>
    6b90:	000d0463          	beqz	s10,6b98 <bullet_init_local_assets+0x140>
    6b94:	00068513          	mv	a0,a3
    6b98:	036674b3          	remu	s1,a2,s6
    6b9c:	0194e4b3          	or	s1,s1,s9
    6ba0:	00049463          	bnez	s1,6ba8 <bullet_init_local_assets+0x150>
    6ba4:	00040513          	mv	a0,s0
    6ba8:	006844b3          	xor	s1,a6,t1
    6bac:	03e4f4b3          	remu	s1,s1,t5
    6bb0:	00996463          	bltu	s2,s1,6bb8 <bullet_init_local_assets+0x160>
    6bb4:	00038513          	mv	a0,t2
    6bb8:	ff878493          	addi	s1,a5,-8 # 2affff8 <__gpu_framebuffer_a+0xaffff8>
    6bbc:	00100093          	li	ra,1
    6bc0:	0890f063          	bgeu	ra,s1,6c40 <bullet_init_local_assets+0x1e8>
    6bc4:	ff478793          	addi	a5,a5,-12
    6bc8:	00f96c63          	bltu	s2,a5,6be0 <bullet_init_local_assets+0x188>
    6bcc:	035657b3          	divu	a5,a2,s5
    6bd0:	00812083          	lw	ra,8(sp)
    6bd4:	001787b3          	add	a5,a5,ra
    6bd8:	0347f7b3          	remu	a5,a5,s4
    6bdc:	06078663          	beqz	a5,6c48 <bullet_init_local_assets+0x1f0>
    6be0:	00c12783          	lw	a5,12(sp)
    6be4:	00a59023          	sh	a0,0(a1)
    6be8:	00160613          	addi	a2,a2,1 # 10000001 <__gpu_framebuffer_a+0xe000001>
    6bec:	00258593          	addi	a1,a1,2
    6bf0:	04980813          	addi	a6,a6,73
    6bf4:	00f30333          	add	t1,t1,a5
    6bf8:	f5861ee3          	bne	a2,s8,6b54 <bullet_init_local_assets+0xfc>
    6bfc:	00170713          	addi	a4,a4,1
    6c00:	21c00793          	li	a5,540
    6c04:	ecf71ee3          	bne	a4,a5,6ae0 <bullet_init_local_assets+0x88>
    6c08:	0000ea37          	lui	s4,0xe
    6c0c:	00010bb7          	lui	s7,0x10
    6c10:	00010c37          	lui	s8,0x10
    6c14:	00004cb7          	lui	s9,0x4
    6c18:	348a0a13          	addi	s4,s4,840 # e348 <colors.2>
    6c1c:	00000993          	li	s3,0
    6c20:	81fb8b93          	addi	s7,s7,-2017 # f81f <__global_pointer$+0xa9f>
    6c24:	00900d13          	li	s10,9
    6c28:	fffc0c13          	addi	s8,s8,-1 # ffff <__global_pointer$+0x127f>
    6c2c:	02100d93          	li	s11,33
    6c30:	208c8c93          	addi	s9,s9,520 # 4208 <asst_encode+0xdc>
    6c34:	00699b13          	slli	s6,s3,0x6
    6c38:	00000913          	li	s2,0
    6c3c:	0700006f          	j	6cac <bullet_init_local_assets+0x254>
    6c40:	000f8513          	mv	a0,t6
    6c44:	f9dff06f          	j	6be0 <bullet_init_local_assets+0x188>
    6c48:	00028513          	mv	a0,t0
    6c4c:	f95ff06f          	j	6be0 <bullet_init_local_assets+0x188>
    6c50:	00090613          	mv	a2,s2
    6c54:	00040593          	mv	a1,s0
    6c58:	00098513          	mv	a0,s3
    6c5c:	940ff0ef          	jal	5d9c <bullet_shape_opaque>
    6c60:	000b8713          	mv	a4,s7
    6c64:	00800693          	li	a3,8
    6c68:	02050463          	beqz	a0,6c90 <bullet_init_local_assets+0x238>
    6c6c:	00141793          	slli	a5,s0,0x1
    6c70:	ff978793          	addi	a5,a5,-7
    6c74:	02f787b3          	mul	a5,a5,a5
    6c78:	000c0713          	mv	a4,s8
    6c7c:	009787b3          	add	a5,a5,s1
    6c80:	00fd5863          	bge	s10,a5,6c90 <bullet_init_local_assets+0x238>
    6c84:	000c8713          	mv	a4,s9
    6c88:	00fdc463          	blt	s11,a5,6c90 <bullet_init_local_assets+0x238>
    6c8c:	000a5703          	lhu	a4,0(s4)
    6c90:	00ea9023          	sh	a4,0(s5)
    6c94:	00140413          	addi	s0,s0,1
    6c98:	002a8a93          	addi	s5,s5,2
    6c9c:	fad41ae3          	bne	s0,a3,6c50 <bullet_init_local_assets+0x1f8>
    6ca0:	00190913          	addi	s2,s2,1
    6ca4:	008b0b13          	addi	s6,s6,8
    6ca8:	02890263          	beq	s2,s0,6ccc <bullet_init_local_assets+0x274>
    6cac:	00191793          	slli	a5,s2,0x1
    6cb0:	ff978793          	addi	a5,a5,-7
    6cb4:	02f784b3          	mul	s1,a5,a5
    6cb8:	001b1a93          	slli	s5,s6,0x1
    6cbc:	02c007b7          	lui	a5,0x2c00
    6cc0:	00fa8ab3          	add	s5,s5,a5
    6cc4:	00000413          	li	s0,0
    6cc8:	f89ff06f          	j	6c50 <bullet_init_local_assets+0x1f8>
    6ccc:	00198993          	addi	s3,s3,1
    6cd0:	00600793          	li	a5,6
    6cd4:	002a0a13          	addi	s4,s4,2
    6cd8:	f4f99ee3          	bne	s3,a5,6c34 <bullet_init_local_assets+0x1dc>
    6cdc:	00010337          	lui	t1,0x10
    6ce0:	000103b7          	lui	t2,0x10
    6ce4:	02c00837          	lui	a6,0x2c00
    6ce8:	00000713          	li	a4,0
    6cec:	00300413          	li	s0,3
    6cf0:	00700493          	li	s1,7
    6cf4:	fff30313          	addi	t1,t1,-1 # ffff <__global_pointer$+0x127f>
    6cf8:	81f38393          	addi	t2,t2,-2017 # f81f <__global_pointer$+0xa9f>
    6cfc:	00a00913          	li	s2,10
    6d00:	00200993          	li	s3,2
    6d04:	30f80813          	addi	a6,a6,783 # 2c0030f <__gpu_framebuffer_a+0xc0030f>
    6d08:	01100f93          	li	t6,17
    6d0c:	01000293          	li	t0,16
    6d10:	00571513          	slli	a0,a4,0x5
    6d14:	ffe70893          	addi	a7,a4,-2
    6d18:	ff100613          	li	a2,-15
    6d1c:	00b8b893          	sltiu	a7,a7,11
    6d20:	ffb70f13          	addi	t5,a4,-5
    6d24:	ff370e93          	addi	t4,a4,-13
    6d28:	01050533          	add	a0,a0,a6
    6d2c:	41f65793          	srai	a5,a2,0x1f
    6d30:	00c7c5b3          	xor	a1,a5,a2
    6d34:	40f585b3          	sub	a1,a1,a5
    6d38:	00000e13          	li	t3,0
    6d3c:	00b44463          	blt	s0,a1,6d44 <bullet_init_local_assets+0x2ec>
    6d40:	00088e13          	mv	t3,a7
    6d44:	03e4ea63          	bltu	s1,t5,6d78 <bullet_init_local_assets+0x320>
    6d48:	00171693          	slli	a3,a4,0x1
    6d4c:	ff868693          	addi	a3,a3,-8
    6d50:	00b6a6b3          	slt	a3,a3,a1
    6d54:	0016b693          	seqz	a3,a3
    6d58:	00030793          	mv	a5,t1
    6d5c:	020e1863          	bnez	t3,6d8c <bullet_init_local_assets+0x334>
    6d60:	00038793          	mv	a5,t2
    6d64:	02068463          	beqz	a3,6d8c <bullet_init_local_assets+0x334>
    6d68:	43000793          	li	a5,1072
    6d6c:	02e94063          	blt	s2,a4,6d8c <bullet_init_local_assets+0x334>
    6d70:	7ff00793          	li	a5,2047
    6d74:	0180006f          	j	6d8c <bullet_init_local_assets+0x334>
    6d78:	00000693          	li	a3,0
    6d7c:	fdd9eee3          	bltu	s3,t4,6d58 <bullet_init_local_assets+0x300>
    6d80:	120e0c63          	beqz	t3,6eb8 <bullet_init_local_assets+0x460>
    6d84:	000107b7          	lui	a5,0x10
    6d88:	fff78793          	addi	a5,a5,-1 # ffff <__global_pointer$+0x127f>
    6d8c:	00c506b3          	add	a3,a0,a2
    6d90:	00f69023          	sh	a5,0(a3)
    6d94:	00260613          	addi	a2,a2,2
    6d98:	f9f61ae3          	bne	a2,t6,6d2c <bullet_init_local_assets+0x2d4>
    6d9c:	00170713          	addi	a4,a4,1
    6da0:	f65718e3          	bne	a4,t0,6d10 <bullet_init_local_assets+0x2b8>
    6da4:	02c005b7          	lui	a1,0x2c00
    6da8:	ff500693          	li	a3,-11
    6dac:	00c00893          	li	a7,12
    6db0:	58f58593          	addi	a1,a1,1423 # 2c0058f <__gpu_framebuffer_a+0xc0058f>
    6db4:	01600313          	li	t1,22
    6db8:	00d00e13          	li	t3,13
    6dbc:	03168633          	mul	a2,a3,a7
    6dc0:	41f6d793          	srai	a5,a3,0x1f
    6dc4:	00d7c533          	xor	a0,a5,a3
    6dc8:	40f50533          	sub	a0,a0,a5
    6dcc:	ff500713          	li	a4,-11
    6dd0:	00b60633          	add	a2,a2,a1
    6dd4:	41f75813          	srai	a6,a4,0x1f
    6dd8:	00e847b3          	xor	a5,a6,a4
    6ddc:	410787b3          	sub	a5,a5,a6
    6de0:	00a787b3          	add	a5,a5,a0
    6de4:	40f307b3          	sub	a5,t1,a5
    6de8:	00679793          	slli	a5,a5,0x6
    6dec:	01079793          	slli	a5,a5,0x10
    6df0:	00e60eb3          	add	t4,a2,a4
    6df4:	0107d793          	srli	a5,a5,0x10
    6df8:	00fe9023          	sh	a5,0(t4)
    6dfc:	00270713          	addi	a4,a4,2
    6e00:	fdc71ae3          	bne	a4,t3,6dd4 <bullet_init_local_assets+0x37c>
    6e04:	00268693          	addi	a3,a3,2
    6e08:	fae69ae3          	bne	a3,a4,6dbc <bullet_init_local_assets+0x364>
    6e0c:	000107b7          	lui	a5,0x10
    6e10:	00010f37          	lui	t5,0x10
    6e14:	00008837          	lui	a6,0x8
    6e18:	fff78793          	addi	a5,a5,-1 # ffff <__global_pointer$+0x127f>
    6e1c:	02c00eb7          	lui	t4,0x2c00
    6e20:	000102b7          	lui	t0,0x10
    6e24:	81018513          	addi	a0,gp,-2032 # e590 <enemies.1>
    6e28:	00000893          	li	a7,0
    6e2c:	00200413          	li	s0,2
    6e30:	00100493          	li	s1,1
    6e34:	81ff0f13          	addi	t5,t5,-2017 # f81f <__global_pointer$+0xa9f>
    6e38:	00800913          	li	s2,8
    6e3c:	41080813          	addi	a6,a6,1040 # 8410 <initial_valid+0x7c>
    6e40:	00900993          	li	s3,9
    6e44:	00f12623          	sw	a5,12(sp)
    6e48:	00700a13          	li	s4,7
    6e4c:	62fe8e93          	addi	t4,t4,1583 # 2c0062f <__gpu_framebuffer_a+0xc0062f>
    6e50:	c8028293          	addi	t0,t0,-896 # fc80 <__global_pointer$+0xf00>
    6e54:	00055383          	lhu	t2,0(a0)
    6e58:	00589e13          	slli	t3,a7,0x5
    6e5c:	00000793          	li	a5,0
    6e60:	00d00b13          	li	s6,13
    6e64:	00600b93          	li	s7,6
    6e68:	ffb78f93          	addi	t6,a5,-5
    6e6c:	01de0733          	add	a4,t3,t4
    6e70:	ff100693          	li	a3,-15
    6e74:	ff378a93          	addi	s5,a5,-13
    6e78:	ffbfff93          	andi	t6,t6,-5
    6e7c:	00b00c13          	li	s8,11
    6e80:	00300c93          	li	s9,3
    6e84:	ffd78d13          	addi	s10,a5,-3
    6e88:	00c7ad93          	slti	s11,a5,12
    6e8c:	00e12423          	sw	a4,8(sp)
    6e90:	41f6d613          	srai	a2,a3,0x1f
    6e94:	00d64733          	xor	a4,a2,a3
    6e98:	40c70733          	sub	a4,a4,a2
    6e9c:	ff970613          	addi	a2,a4,-7
    6ea0:	02c46a63          	bltu	s0,a2,6ed4 <bullet_init_local_assets+0x47c>
    6ea4:	000d8613          	mv	a2,s11
    6ea8:	0c079e63          	bnez	a5,6f84 <bullet_init_local_assets+0x52c>
    6eac:	00000593          	li	a1,0
    6eb0:	00000613          	li	a2,0
    6eb4:	0dc0006f          	j	6f90 <bullet_init_local_assets+0x538>
    6eb8:	000107b7          	lui	a5,0x10
    6ebc:	00300693          	li	a3,3
    6ec0:	c8078793          	addi	a5,a5,-896 # fc80 <__global_pointer$+0xf00>
    6ec4:	ecb6d4e3          	bge	a3,a1,6d8c <bullet_init_local_assets+0x334>
    6ec8:	000107b7          	lui	a5,0x10
    6ecc:	81f78793          	addi	a5,a5,-2017 # f81f <__global_pointer$+0xa9f>
    6ed0:	ebdff06f          	j	6d8c <bullet_init_local_assets+0x334>
    6ed4:	0aecc663          	blt	s9,a4,6f80 <bullet_init_local_assets+0x528>
    6ed8:	fda9eae3          	bltu	s3,s10,6eac <bullet_init_local_assets+0x454>
    6edc:	00000613          	li	a2,0
    6ee0:	00100593          	li	a1,1
    6ee4:	0a0f9463          	bnez	t6,6f8c <bullet_init_local_assets+0x534>
    6ee8:	0eec5a63          	bge	s8,a4,6fdc <bullet_init_local_assets+0x584>
    6eec:	00000313          	li	t1,0
    6ef0:	00058663          	beqz	a1,6efc <bullet_init_local_assets+0x4a4>
    6ef4:	00c12703          	lw	a4,12(sp)
    6ef8:	00f9ca63          	blt	s3,a5,6f0c <bullet_init_local_assets+0x4b4>
    6efc:	0c060663          	beqz	a2,6fc8 <bullet_init_local_assets+0x570>
    6f00:	00080713          	mv	a4,a6
    6f04:	00f44463          	blt	s0,a5,6f0c <bullet_init_local_assets+0x4b4>
    6f08:	00028713          	mv	a4,t0
    6f0c:	00812603          	lw	a2,8(sp)
    6f10:	00d60633          	add	a2,a2,a3
    6f14:	00e61023          	sh	a4,0(a2)
    6f18:	00268693          	addi	a3,a3,2
    6f1c:	01100713          	li	a4,17
    6f20:	f6e698e3          	bne	a3,a4,6e90 <bullet_init_local_assets+0x438>
    6f24:	00178793          	addi	a5,a5,1
    6f28:	01000713          	li	a4,16
    6f2c:	020e0e13          	addi	t3,t3,32
    6f30:	f2e79ce3          	bne	a5,a4,6e68 <bullet_init_local_assets+0x410>
    6f34:	01088893          	addi	a7,a7,16
    6f38:	03000793          	li	a5,48
    6f3c:	00250513          	addi	a0,a0,2
    6f40:	f0f89ae3          	bne	a7,a5,6e54 <bullet_init_local_assets+0x3fc>
    6f44:	04c12083          	lw	ra,76(sp)
    6f48:	04812403          	lw	s0,72(sp)
    6f4c:	04412483          	lw	s1,68(sp)
    6f50:	04012903          	lw	s2,64(sp)
    6f54:	03c12983          	lw	s3,60(sp)
    6f58:	03812a03          	lw	s4,56(sp)
    6f5c:	03412a83          	lw	s5,52(sp)
    6f60:	03012b03          	lw	s6,48(sp)
    6f64:	02c12b83          	lw	s7,44(sp)
    6f68:	02812c03          	lw	s8,40(sp)
    6f6c:	02412c83          	lw	s9,36(sp)
    6f70:	02012d03          	lw	s10,32(sp)
    6f74:	01c12d83          	lw	s11,28(sp)
    6f78:	05010113          	addi	sp,sp,80
    6f7c:	00008067          	ret
    6f80:	00000613          	li	a2,0
    6f84:	00000593          	li	a1,0
    6f88:	f5dff06f          	j	6ee4 <bullet_init_local_assets+0x48c>
    6f8c:	05778863          	beq	a5,s7,6fdc <bullet_init_local_assets+0x584>
    6f90:	05478663          	beq	a5,s4,6fdc <bullet_init_local_assets+0x584>
    6f94:	03279063          	bne	a5,s2,6fb4 <bullet_init_local_assets+0x55c>
    6f98:	04eb5263          	bge	s6,a4,6fdc <bullet_init_local_assets+0x584>
    6f9c:	00080713          	mv	a4,a6
    6fa0:	f60616e3          	bnez	a2,6f0c <bullet_init_local_assets+0x4b4>
    6fa4:	00038713          	mv	a4,t2
    6fa8:	f60592e3          	bnez	a1,6f0c <bullet_init_local_assets+0x4b4>
    6fac:	000f0713          	mv	a4,t5
    6fb0:	f5dff06f          	j	6f0c <bullet_init_local_assets+0x4b4>
    6fb4:	f2e4cce3          	blt	s1,a4,6eec <bullet_init_local_assets+0x494>
    6fb8:	f354eae3          	bltu	s1,s5,6eec <bullet_init_local_assets+0x494>
    6fbc:	00010737          	lui	a4,0x10
    6fc0:	fff70713          	addi	a4,a4,-1 # ffff <__global_pointer$+0x127f>
    6fc4:	f49ff06f          	j	6f0c <bullet_init_local_assets+0x4b4>
    6fc8:	fc030ee3          	beqz	t1,6fa4 <bullet_init_local_assets+0x54c>
    6fcc:	00038713          	mv	a4,t2
    6fd0:	f3279ee3          	bne	a5,s2,6f0c <bullet_init_local_assets+0x4b4>
    6fd4:	43000713          	li	a4,1072
    6fd8:	f35ff06f          	j	6f0c <bullet_init_local_assets+0x4b4>
    6fdc:	00100313          	li	t1,1
    6fe0:	f11ff06f          	j	6ef0 <bullet_init_local_assets+0x498>

00006fe4 <bullet_load_network_assets>:
    6fe4:	fc010113          	addi	sp,sp,-64
    6fe8:	00002737          	lui	a4,0x2
    6fec:	03212823          	sw	s2,48(sp)
    6ff0:	f9070713          	addi	a4,a4,-112 # 1f90 <gpu_submit+0x108>
    6ff4:	00058913          	mv	s2,a1
    6ff8:	c0a80637          	lui	a2,0xc0a80
    6ffc:	c0a805b7          	lui	a1,0xc0a80
    7000:	00070693          	mv	a3,a4
    7004:	10260613          	addi	a2,a2,258 # c0a80102 <__gpu_framebuffer_a+0xbea80102>
    7008:	10358593          	addi	a1,a1,259 # c0a80103 <__gpu_framebuffer_a+0xbea80103>
    700c:	02812c23          	sw	s0,56(sp)
    7010:	02912a23          	sw	s1,52(sp)
    7014:	02112e23          	sw	ra,60(sp)
    7018:	03312623          	sw	s3,44(sp)
    701c:	00050493          	mv	s1,a0
    7020:	c5cfd0ef          	jal	447c <network_configure>
    7024:	00050413          	mv	s0,a0
    7028:	0a051263          	bnez	a0,70cc <bullet_load_network_assets+0xe8>
    702c:	4a955837          	lui	a6,0x4a955
    7030:	000fd7b7          	lui	a5,0xfd
    7034:	05f5e5b7          	lui	a1,0x5f5e
    7038:	02900737          	lui	a4,0x2900
    703c:	06500693          	li	a3,101
    7040:	00090613          	mv	a2,s2
    7044:	10058593          	addi	a1,a1,256 # 5f5e100 <__gpu_framebuffer_a+0x3f5e100>
    7048:	00810893          	addi	a7,sp,8
    704c:	6cc80813          	addi	a6,a6,1740 # 4a9556cc <__gpu_framebuffer_a+0x489556cc>
    7050:	20078793          	addi	a5,a5,512 # fd200 <__freertos_irq_stack_top+0xdf760>
    7054:	00048513          	mv	a0,s1
    7058:	c88fd0ef          	jal	44e0 <network_asset_fetch>
    705c:	01012683          	lw	a3,16(sp)
    7060:	00812603          	lw	a2,8(sp)
    7064:	0000d9b7          	lui	s3,0xd
    7068:	00050413          	mv	s0,a0
    706c:	00050713          	mv	a4,a0
    7070:	06500593          	li	a1,101
    7074:	5c098513          	addi	a0,s3,1472 # d5c0 <_data+0x314>
    7078:	facff0ef          	jal	6824 <bsp_printf.constprop.0>
    707c:	04041863          	bnez	s0,70cc <bullet_load_network_assets+0xe8>
    7080:	9d6b3837          	lui	a6,0x9d6b3
    7084:	000017b7          	lui	a5,0x1
    7088:	05f5e5b7          	lui	a1,0x5f5e
    708c:	02a00737          	lui	a4,0x2a00
    7090:	06600693          	li	a3,102
    7094:	00090613          	mv	a2,s2
    7098:	10058593          	addi	a1,a1,256 # 5f5e100 <__gpu_framebuffer_a+0x3f5e100>
    709c:	00810893          	addi	a7,sp,8
    70a0:	1f280813          	addi	a6,a6,498 # 9d6b31f2 <__gpu_framebuffer_a+0x9b6b31f2>
    70a4:	c2078793          	addi	a5,a5,-992 # c20 <CUSTOM2+0xbc5>
    70a8:	00048513          	mv	a0,s1
    70ac:	c34fd0ef          	jal	44e0 <network_asset_fetch>
    70b0:	01012683          	lw	a3,16(sp)
    70b4:	00812603          	lw	a2,8(sp)
    70b8:	00050413          	mv	s0,a0
    70bc:	00050713          	mv	a4,a0
    70c0:	06600593          	li	a1,102
    70c4:	5c098513          	addi	a0,s3,1472
    70c8:	f5cff0ef          	jal	6824 <bsp_printf.constprop.0>
    70cc:	03c12083          	lw	ra,60(sp)
    70d0:	00040513          	mv	a0,s0
    70d4:	03812403          	lw	s0,56(sp)
    70d8:	03412483          	lw	s1,52(sp)
    70dc:	03012903          	lw	s2,48(sp)
    70e0:	02c12983          	lw	s3,44(sp)
    70e4:	04010113          	addi	sp,sp,64
    70e8:	00008067          	ret

000070ec <bullet_prepare_assets>:
    70ec:	fe010113          	addi	sp,sp,-32
    70f0:	00112e23          	sw	ra,28(sp)
    70f4:	ef1ff0ef          	jal	6fe4 <bullet_load_network_assets>
    70f8:	00050863          	beqz	a0,7108 <bullet_prepare_assets+0x1c>
    70fc:	00a12623          	sw	a0,12(sp)
    7100:	959ff0ef          	jal	6a58 <bullet_init_local_assets>
    7104:	00c12503          	lw	a0,12(sp)
    7108:	01c12083          	lw	ra,28(sp)
    710c:	02010113          	addi	sp,sp,32
    7110:	00008067          	ret

00007114 <bullet_prepare_texture_cache>:
    7114:	00060693          	mv	a3,a2
    7118:	00059a63          	bnez	a1,712c <bullet_prepare_texture_cache+0x18>
    711c:	02a005b7          	lui	a1,0x2a00
    7120:	00001637          	lui	a2,0x1
    7124:	c2060613          	addi	a2,a2,-992 # c20 <CUSTOM2+0xbc5>
    7128:	b9cfb06f          	j	24c4 <gpu_texture_cache_load>
    712c:	02c005b7          	lui	a1,0x2c00
    7130:	ff1ff06f          	j	7120 <bullet_prepare_texture_cache+0xc>

00007134 <be32>:
    7134:	00054783          	lbu	a5,0(a0)
    7138:	00154703          	lbu	a4,1(a0)
    713c:	01879793          	slli	a5,a5,0x18
    7140:	01071713          	slli	a4,a4,0x10
    7144:	00e7e7b3          	or	a5,a5,a4
    7148:	00354703          	lbu	a4,3(a0)
    714c:	00254503          	lbu	a0,2(a0)
    7150:	00e7e7b3          	or	a5,a5,a4
    7154:	00851513          	slli	a0,a0,0x8
    7158:	00a7e533          	or	a0,a5,a0
    715c:	00008067          	ret

00007160 <put32>:
    7160:	0185d793          	srli	a5,a1,0x18
    7164:	00f50023          	sb	a5,0(a0)
    7168:	0105d793          	srli	a5,a1,0x10
    716c:	00f500a3          	sb	a5,1(a0)
    7170:	0085d793          	srli	a5,a1,0x8
    7174:	00f50123          	sb	a5,2(a0)
    7178:	00b501a3          	sb	a1,3(a0)
    717c:	00008067          	ret

00007180 <expire>:
    7180:	01654783          	lbu	a5,22(a0)
    7184:	00079663          	bnez	a5,7190 <expire+0x10>
    7188:	00000513          	li	a0,0
    718c:	00008067          	ret
    7190:	08452783          	lw	a5,132(a0)
    7194:	40f585b3          	sub	a1,a1,a5
    7198:	00b52823          	sw	a1,16(a0)
    719c:	0fa00793          	li	a5,250
    71a0:	feb7f4e3          	bgeu	a5,a1,7188 <expire+0x8>
    71a4:	00452783          	lw	a5,4(a0)
    71a8:	00052423          	sw	zero,8(a0)
    71ac:	00052223          	sw	zero,4(a0)
    71b0:	08f52623          	sw	a5,140(a0)
    71b4:	fff00793          	li	a5,-1
    71b8:	00052623          	sw	zero,12(a0)
    71bc:	00052a23          	sw	zero,20(a0)
    71c0:	00f52823          	sw	a5,16(a0)
    71c4:	0a0504a3          	sb	zero,169(a0)
    71c8:	0c051423          	sh	zero,200(a0)
    71cc:	0c050523          	sb	zero,202(a0)
    71d0:	0c050ea3          	sb	zero,221(a0)
    71d4:	00100513          	li	a0,1
    71d8:	00008067          	ret

000071dc <take>:
    71dc:	00052683          	lw	a3,0(a0)
    71e0:	00050793          	mv	a5,a0
    71e4:	3046a703          	lw	a4,772(a3)
    71e8:	00377513          	andi	a0,a4,3
    71ec:	08050a63          	beqz	a0,7280 <take+0xa4>
    71f0:	00277713          	andi	a4,a4,2
    71f4:	06070463          	beqz	a4,725c <take+0x80>
    71f8:	0007a703          	lw	a4,0(a5)
    71fc:	00000693          	li	a3,0
    7200:	02000513          	li	a0,32
    7204:	31072703          	lw	a4,784(a4) # 2a00310 <__gpu_framebuffer_a+0xa00310>
    7208:	00e62023          	sw	a4,0(a2)
    720c:	0007a703          	lw	a4,0(a5)
    7210:	00d58633          	add	a2,a1,a3
    7214:	32070713          	addi	a4,a4,800
    7218:	00d70733          	add	a4,a4,a3
    721c:	00072883          	lw	a7,0(a4)
    7220:	00000713          	li	a4,0
    7224:	00e8d833          	srl	a6,a7,a4
    7228:	01060023          	sb	a6,0(a2)
    722c:	00870713          	addi	a4,a4,8
    7230:	00160613          	addi	a2,a2,1
    7234:	fea718e3          	bne	a4,a0,7224 <take+0x48>
    7238:	00468693          	addi	a3,a3,4
    723c:	fce698e3          	bne	a3,a4,720c <take+0x30>
    7240:	0ff0000f          	fence
    7244:	0007a783          	lw	a5,0(a5)
    7248:	00100713          	li	a4,1
    724c:	30e7a623          	sw	a4,780(a5)
    7250:	0ff0000f          	fence
    7254:	00100513          	li	a0,1
    7258:	00008067          	ret
    725c:	00100713          	li	a4,1
    7260:	30e6a423          	sw	a4,776(a3)
    7264:	0ff0000f          	fence
    7268:	0007a703          	lw	a4,0(a5)
    726c:	ffd00513          	li	a0,-3
    7270:	30472703          	lw	a4,772(a4)
    7274:	00277713          	andi	a4,a4,2
    7278:	f80710e3          	bnez	a4,71f8 <take+0x1c>
    727c:	00008067          	ret
    7280:	00000513          	li	a0,0
    7284:	00008067          	ret

00007288 <nc_init>:
    7288:	0a050e63          	beqz	a0,7344 <nc_init+0xbc>
    728c:	fc010113          	addi	sp,sp,-64
    7290:	02812c23          	sw	s0,56(sp)
    7294:	02912a23          	sw	s1,52(sp)
    7298:	02112e23          	sw	ra,60(sp)
    729c:	0035f793          	andi	a5,a1,3
    72a0:	00050413          	mv	s0,a0
    72a4:	00058493          	mv	s1,a1
    72a8:	fff00513          	li	a0,-1
    72ac:	08079263          	bnez	a5,7330 <nc_init+0xa8>
    72b0:	00059463          	bnez	a1,72b8 <nc_init+0x30>
    72b4:	f81004b7          	lui	s1,0xf8100
    72b8:	0e000613          	li	a2,224
    72bc:	00000593          	li	a1,0
    72c0:	00040513          	mv	a0,s0
    72c4:	f65f90ef          	jal	1228 <memset>
    72c8:	fff00793          	li	a5,-1
    72cc:	00f42823          	sw	a5,16(s0)
    72d0:	0c800793          	li	a5,200
    72d4:	0af42023          	sw	a5,160(s0)
    72d8:	3004a703          	lw	a4,768(s1) # f8100300 <__gpu_framebuffer_a+0xf6100300>
    72dc:	4d4757b7          	lui	a5,0x4d475
    72e0:	00942023          	sw	s1,0(s0)
    72e4:	43178793          	addi	a5,a5,1073 # 4d475431 <__gpu_framebuffer_a+0x4b475431>
    72e8:	ffe00513          	li	a0,-2
    72ec:	04f71263          	bne	a4,a5,7330 <nc_init+0xa8>
    72f0:	3044a783          	lw	a5,772(s1)
    72f4:	00400493          	li	s1,4
    72f8:	0057d793          	srli	a5,a5,0x5
    72fc:	0017f793          	andi	a5,a5,1
    7300:	0cf40e23          	sb	a5,220(s0)
    7304:	00c10613          	addi	a2,sp,12
    7308:	01010593          	addi	a1,sp,16
    730c:	00040513          	mv	a0,s0
    7310:	ecdff0ef          	jal	71dc <take>
    7314:	00054e63          	bltz	a0,7330 <nc_init+0xa8>
    7318:	00050663          	beqz	a0,7324 <nc_init+0x9c>
    731c:	fff48493          	addi	s1,s1,-1
    7320:	fe0492e3          	bnez	s1,7304 <nc_init+0x7c>
    7324:	00100793          	li	a5,1
    7328:	0af40423          	sb	a5,168(s0)
    732c:	00000513          	li	a0,0
    7330:	03c12083          	lw	ra,60(sp)
    7334:	03812403          	lw	s0,56(sp)
    7338:	03412483          	lw	s1,52(sp)
    733c:	04010113          	addi	sp,sp,64
    7340:	00008067          	ret
    7344:	fff00513          	li	a0,-1
    7348:	00008067          	ret

0000734c <nc_poll>:
    734c:	f8010113          	addi	sp,sp,-128
    7350:	06112e23          	sw	ra,124(sp)
    7354:	06812c23          	sw	s0,120(sp)
    7358:	06912a23          	sw	s1,116(sp)
    735c:	07212823          	sw	s2,112(sp)
    7360:	07312623          	sw	s3,108(sp)
    7364:	07412423          	sw	s4,104(sp)
    7368:	07512223          	sw	s5,100(sp)
    736c:	07612023          	sw	s6,96(sp)
    7370:	05712e23          	sw	s7,92(sp)
    7374:	05812c23          	sw	s8,88(sp)
    7378:	05912a23          	sw	s9,84(sp)
    737c:	05a12823          	sw	s10,80(sp)
    7380:	05b12623          	sw	s11,76(sp)
    7384:	04061463          	bnez	a2,73cc <nc_poll+0x80>
    7388:	fff00913          	li	s2,-1
    738c:	07c12083          	lw	ra,124(sp)
    7390:	07812403          	lw	s0,120(sp)
    7394:	07412483          	lw	s1,116(sp)
    7398:	06c12983          	lw	s3,108(sp)
    739c:	06812a03          	lw	s4,104(sp)
    73a0:	06412a83          	lw	s5,100(sp)
    73a4:	06012b03          	lw	s6,96(sp)
    73a8:	05c12b83          	lw	s7,92(sp)
    73ac:	05812c03          	lw	s8,88(sp)
    73b0:	05412c83          	lw	s9,84(sp)
    73b4:	05012d03          	lw	s10,80(sp)
    73b8:	04c12d83          	lw	s11,76(sp)
    73bc:	00090513          	mv	a0,s2
    73c0:	07012903          	lw	s2,112(sp)
    73c4:	08010113          	addi	sp,sp,128
    73c8:	00008067          	ret
    73cc:	fff00793          	li	a5,-1
    73d0:	00062023          	sw	zero,0(a2)
    73d4:	00062223          	sw	zero,4(a2)
    73d8:	00062423          	sw	zero,8(a2)
    73dc:	00062823          	sw	zero,16(a2)
    73e0:	00f62623          	sw	a5,12(a2)
    73e4:	00050413          	mv	s0,a0
    73e8:	00060493          	mv	s1,a2
    73ec:	f8050ee3          	beqz	a0,7388 <nc_poll+0x3c>
    73f0:	0a854783          	lbu	a5,168(a0)
    73f4:	ffe00913          	li	s2,-2
    73f8:	f8078ae3          	beqz	a5,738c <nc_poll+0x40>
    73fc:	00058a93          	mv	s5,a1
    7400:	41474bb7          	lui	s7,0x41474
    7404:	d7dff0ef          	jal	7180 <expire>
    7408:	00050993          	mv	s3,a0
    740c:	00400b13          	li	s6,4
    7410:	331b8b93          	addi	s7,s7,817 # 41474331 <__gpu_framebuffer_a+0x3f474331>
    7414:	01c10613          	addi	a2,sp,28
    7418:	02010593          	addi	a1,sp,32
    741c:	00040513          	mv	a0,s0
    7420:	dbdff0ef          	jal	71dc <take>
    7424:	00050913          	mv	s2,a0
    7428:	00055c63          	bgez	a0,7440 <nc_poll+0xf4>
    742c:	01400613          	li	a2,20
    7430:	00440593          	addi	a1,s0,4
    7434:	00048513          	mv	a0,s1
    7438:	ecdf90ef          	jal	1304 <memcpy>
    743c:	f51ff06f          	j	738c <nc_poll+0x40>
    7440:	2c050263          	beqz	a0,7704 <nc_poll+0x3b8>
    7444:	01c12983          	lw	s3,28(sp)
    7448:	0fa00793          	li	a5,250
    744c:	0b37e863          	bltu	a5,s3,74fc <nc_poll+0x1b0>
    7450:	02010513          	addi	a0,sp,32
    7454:	ce1ff0ef          	jal	7134 <be32>
    7458:	0b751263          	bne	a0,s7,74fc <nc_poll+0x1b0>
    745c:	02414d03          	lbu	s10,36(sp)
    7460:	00100793          	li	a5,1
    7464:	08fd1c63          	bne	s10,a5,74fc <nc_poll+0x1b0>
    7468:	02614c03          	lbu	s8,38(sp)
    746c:	080c1863          	bnez	s8,74fc <nc_poll+0x1b0>
    7470:	02714703          	lbu	a4,39(sp)
    7474:	02000793          	li	a5,32
    7478:	08f71263          	bne	a4,a5,74fc <nc_poll+0x1b0>
    747c:	02810513          	addi	a0,sp,40
    7480:	cb5ff0ef          	jal	7134 <be32>
    7484:	06050c63          	beqz	a0,74fc <nc_poll+0x1b0>
    7488:	03c10513          	addi	a0,sp,60
    748c:	ca9ff0ef          	jal	7134 <be32>
    7490:	00050913          	mv	s2,a0
    7494:	01c00593          	li	a1,28
    7498:	02010513          	addi	a0,sp,32
    749c:	c45fc0ef          	jal	40e0 <asst_crc32>
    74a0:	04a91e63          	bne	s2,a0,74fc <nc_poll+0x1b0>
    74a4:	02514a03          	lbu	s4,37(sp)
    74a8:	03aa1863          	bne	s4,s10,74d8 <nc_poll+0x18c>
    74ac:	03010513          	addi	a0,sp,48
    74b0:	c85ff0ef          	jal	7134 <be32>
    74b4:	00050913          	mv	s2,a0
    74b8:	03410513          	addi	a0,sp,52
    74bc:	c79ff0ef          	jal	7134 <be32>
    74c0:	00a96933          	or	s2,s2,a0
    74c4:	03810513          	addi	a0,sp,56
    74c8:	c6dff0ef          	jal	7134 <be32>
    74cc:	00a96933          	or	s2,s2,a0
    74d0:	06090e63          	beqz	s2,754c <nc_poll+0x200>
    74d4:	0280006f          	j	74fc <nc_poll+0x1b0>
    74d8:	00200793          	li	a5,2
    74dc:	02fa1863          	bne	s4,a5,750c <nc_poll+0x1c0>
    74e0:	03010513          	addi	a0,sp,48
    74e4:	c51ff0ef          	jal	7134 <be32>
    74e8:	0ff00793          	li	a5,255
    74ec:	00a7e863          	bltu	a5,a0,74fc <nc_poll+0x1b0>
    74f0:	03810513          	addi	a0,sp,56
    74f4:	c41ff0ef          	jal	7134 <be32>
    74f8:	04050a63          	beqz	a0,754c <nc_poll+0x200>
    74fc:	0a442783          	lw	a5,164(s0)
    7500:	00178793          	addi	a5,a5,1
    7504:	0af42223          	sw	a5,164(s0)
    7508:	08c0006f          	j	7594 <nc_poll+0x248>
    750c:	00400793          	li	a5,4
    7510:	fefa16e3          	bne	s4,a5,74fc <nc_poll+0x1b0>
    7514:	03010513          	addi	a0,sp,48
    7518:	c1dff0ef          	jal	7134 <be32>
    751c:	00050d93          	mv	s11,a0
    7520:	03410513          	addi	a0,sp,52
    7524:	c11ff0ef          	jal	7134 <be32>
    7528:	00050913          	mv	s2,a0
    752c:	03810513          	addi	a0,sp,56
    7530:	c05ff0ef          	jal	7134 <be32>
    7534:	fc0504e3          	beqz	a0,74fc <nc_poll+0x1b0>
    7538:	00100793          	li	a5,1
    753c:	06fd9c63          	bne	s11,a5,75b4 <nc_poll+0x268>
    7540:	fff90913          	addi	s2,s2,-1
    7544:	00500793          	li	a5,5
    7548:	fb27eae3          	bltu	a5,s2,74fc <nc_poll+0x1b0>
    754c:	02810513          	addi	a0,sp,40
    7550:	be5ff0ef          	jal	7134 <be32>
    7554:	00050c93          	mv	s9,a0
    7558:	02c10513          	addi	a0,sp,44
    755c:	bd9ff0ef          	jal	7134 <be32>
    7560:	00100693          	li	a3,1
    7564:	01644703          	lbu	a4,22(s0)
    7568:	00050913          	mv	s2,a0
    756c:	08da1c63          	bne	s4,a3,7604 <nc_poll+0x2b8>
    7570:	04070863          	beqz	a4,75c0 <nc_poll+0x274>
    7574:	00442703          	lw	a4,4(s0)
    7578:	f8ec92e3          	bne	s9,a4,74fc <nc_poll+0x1b0>
    757c:	08842703          	lw	a4,136(s0)
    7580:	f6e51ee3          	bne	a0,a4,74fc <nc_poll+0x1b0>
    7584:	00100793          	li	a5,1
    7588:	09942823          	sw	s9,144(s0)
    758c:	09242a23          	sw	s2,148(s0)
    7590:	0af404a3          	sb	a5,169(s0)
    7594:	fffb0b13          	addi	s6,s6,-1
    7598:	00100993          	li	s3,1
    759c:	e60b1ce3          	bnez	s6,7414 <nc_poll+0xc8>
    75a0:	00100913          	li	s2,1
    75a4:	000a8593          	mv	a1,s5
    75a8:	00040513          	mv	a0,s0
    75ac:	bd5ff0ef          	jal	7180 <expire>
    75b0:	e7dff06f          	j	742c <nc_poll+0xe0>
    75b4:	ffed8d93          	addi	s11,s11,-2
    75b8:	f1b7fce3          	bgeu	a5,s11,74d0 <nc_poll+0x184>
    75bc:	f41ff06f          	j	74fc <nc_poll+0x1b0>
    75c0:	08c42703          	lw	a4,140(s0)
    75c4:	f2ec8ce3          	beq	s9,a4,74fc <nc_poll+0x1b0>
    75c8:	00042a23          	sw	zero,20(s0)
    75cc:	01342823          	sw	s3,16(s0)
    75d0:	413a89b3          	sub	s3,s5,s3
    75d4:	00042623          	sw	zero,12(s0)
    75d8:	01942223          	sw	s9,4(s0)
    75dc:	00a42423          	sw	a0,8(s0)
    75e0:	01440b23          	sb	s4,22(s0)
    75e4:	09342223          	sw	s3,132(s0)
    75e8:	08a42423          	sw	a0,136(s0)
    75ec:	0c041423          	sh	zero,200(s0)
    75f0:	0c040523          	sb	zero,202(s0)
    75f4:	0a040523          	sb	zero,170(s0)
    75f8:	0c040f23          	sb	zero,222(s0)
    75fc:	0c040ea3          	sb	zero,221(s0)
    7600:	f85ff06f          	j	7584 <nc_poll+0x238>
    7604:	ee070ce3          	beqz	a4,74fc <nc_poll+0x1b0>
    7608:	00442703          	lw	a4,4(s0)
    760c:	eeec98e3          	bne	s9,a4,74fc <nc_poll+0x1b0>
    7610:	00842703          	lw	a4,8(s0)
    7614:	40e50733          	sub	a4,a0,a4
    7618:	eee052e3          	blez	a4,74fc <nc_poll+0x1b0>
    761c:	08442703          	lw	a4,132(s0)
    7620:	413a8db3          	sub	s11,s5,s3
    7624:	40ed8733          	sub	a4,s11,a4
    7628:	ec074ae3          	bltz	a4,74fc <nc_poll+0x1b0>
    762c:	03410513          	addi	a0,sp,52
    7630:	b05ff0ef          	jal	7134 <be32>
    7634:	00400693          	li	a3,4
    7638:	0ada1863          	bne	s4,a3,76e8 <nc_poll+0x39c>
    763c:	00a12623          	sw	a0,12(sp)
    7640:	03010513          	addi	a0,sp,48
    7644:	af1ff0ef          	jal	7134 <be32>
    7648:	00050a13          	mv	s4,a0
    764c:	03810513          	addi	a0,sp,56
    7650:	ae5ff0ef          	jal	7134 <be32>
    7654:	0c845683          	lhu	a3,200(s0)
    7658:	00c12703          	lw	a4,12(sp)
    765c:	04068663          	beqz	a3,76a8 <nc_poll+0x35c>
    7660:	0bc42683          	lw	a3,188(s0)
    7664:	04d51263          	bne	a0,a3,76a8 <nc_poll+0x35c>
    7668:	0b442783          	lw	a5,180(s0)
    766c:	e8fa18e3          	bne	s4,a5,74fc <nc_poll+0x1b0>
    7670:	0b842783          	lw	a5,184(s0)
    7674:	e8e794e3          	bne	a5,a4,74fc <nc_poll+0x1b0>
    7678:	0c944783          	lbu	a5,201(s0)
    767c:	0b242823          	sw	s2,176(s0)
    7680:	00078663          	beqz	a5,768c <nc_poll+0x340>
    7684:	00100793          	li	a5,1
    7688:	0cf40523          	sb	a5,202(s0)
    768c:	00000513          	li	a0,0
    7690:	00a41a23          	sh	a0,20(s0)
    7694:	01840ba3          	sb	s8,23(s0)
    7698:	01242423          	sw	s2,8(s0)
    769c:	01342823          	sw	s3,16(s0)
    76a0:	09b42223          	sw	s11,132(s0)
    76a4:	ef1ff06f          	j	7594 <nc_poll+0x248>
    76a8:	0c844683          	lbu	a3,200(s0)
    76ac:	e40698e3          	bnez	a3,74fc <nc_poll+0x1b0>
    76b0:	0c944683          	lbu	a3,201(s0)
    76b4:	00068863          	beqz	a3,76c4 <nc_poll+0x378>
    76b8:	0bc42683          	lw	a3,188(s0)
    76bc:	40d506b3          	sub	a3,a0,a3
    76c0:	e2d05ee3          	blez	a3,74fc <nc_poll+0x1b0>
    76c4:	00100793          	li	a5,1
    76c8:	0b942623          	sw	s9,172(s0)
    76cc:	0b242823          	sw	s2,176(s0)
    76d0:	0b442a23          	sw	s4,180(s0)
    76d4:	0ae42c23          	sw	a4,184(s0)
    76d8:	0aa42e23          	sw	a0,188(s0)
    76dc:	0cf41423          	sh	a5,200(s0)
    76e0:	0c040523          	sb	zero,202(s0)
    76e4:	fa9ff06f          	j	768c <nc_poll+0x340>
    76e8:	00a42623          	sw	a0,12(s0)
    76ec:	03010513          	addi	a0,sp,48
    76f0:	a45ff0ef          	jal	7134 <be32>
    76f4:	01051513          	slli	a0,a0,0x10
    76f8:	01055513          	srli	a0,a0,0x10
    76fc:	000d0c13          	mv	s8,s10
    7700:	f91ff06f          	j	7690 <nc_poll+0x344>
    7704:	00098913          	mv	s2,s3
    7708:	e9dff06f          	j	75a4 <nc_poll+0x258>

0000770c <nc_take_game>:
    770c:	00050793          	mv	a5,a0
    7710:	04050863          	beqz	a0,7760 <nc_take_game+0x54>
    7714:	00058513          	mv	a0,a1
    7718:	fff00713          	li	a4,-1
    771c:	04058463          	beqz	a1,7764 <nc_take_game+0x58>
    7720:	0a87c683          	lbu	a3,168(a5)
    7724:	ffe00713          	li	a4,-2
    7728:	02068e63          	beqz	a3,7764 <nc_take_game+0x58>
    772c:	0c87c683          	lbu	a3,200(a5)
    7730:	00000713          	li	a4,0
    7734:	02068863          	beqz	a3,7764 <nc_take_game+0x58>
    7738:	ff010113          	addi	sp,sp,-16
    773c:	01400613          	li	a2,20
    7740:	0ac78593          	addi	a1,a5,172
    7744:	00112623          	sw	ra,12(sp)
    7748:	bbdf90ef          	jal	1304 <memcpy>
    774c:	00c12083          	lw	ra,12(sp)
    7750:	00100713          	li	a4,1
    7754:	00070513          	mv	a0,a4
    7758:	01010113          	addi	sp,sp,16
    775c:	00008067          	ret
    7760:	fff00713          	li	a4,-1
    7764:	00070513          	mv	a0,a4
    7768:	00008067          	ret

0000776c <nc_discard_pending_telemetry>:
    776c:	00050663          	beqz	a0,7778 <nc_discard_pending_telemetry+0xc>
    7770:	0c050ea3          	sb	zero,221(a0)
    7774:	0a050523          	sb	zero,170(a0)
    7778:	00008067          	ret

0000777c <nc_complete_game>:
    777c:	0a050c63          	beqz	a0,7834 <nc_complete_game+0xb8>
    7780:	ff010113          	addi	sp,sp,-16
    7784:	00812423          	sw	s0,8(sp)
    7788:	00112623          	sw	ra,12(sp)
    778c:	00912223          	sw	s1,4(sp)
    7790:	00050413          	mv	s0,a0
    7794:	fff00513          	li	a0,-1
    7798:	08058463          	beqz	a1,7820 <nc_complete_game+0xa4>
    779c:	00200793          	li	a5,2
    77a0:	00060493          	mv	s1,a2
    77a4:	06c7ee63          	bltu	a5,a2,7820 <nc_complete_game+0xa4>
    77a8:	0a844783          	lbu	a5,168(s0)
    77ac:	06078a63          	beqz	a5,7820 <nc_complete_game+0xa4>
    77b0:	01644783          	lbu	a5,22(s0)
    77b4:	06078663          	beqz	a5,7820 <nc_complete_game+0xa4>
    77b8:	0c844783          	lbu	a5,200(s0)
    77bc:	06078263          	beqz	a5,7820 <nc_complete_game+0xa4>
    77c0:	0005a783          	lw	a5,0(a1) # 2c00000 <__gpu_framebuffer_a+0xc00000>
    77c4:	00442703          	lw	a4,4(s0)
    77c8:	04e79c63          	bne	a5,a4,7820 <nc_complete_game+0xa4>
    77cc:	0ac42703          	lw	a4,172(s0)
    77d0:	04e79863          	bne	a5,a4,7820 <nc_complete_game+0xa4>
    77d4:	0105a703          	lw	a4,16(a1)
    77d8:	0bc42783          	lw	a5,188(s0)
    77dc:	04f71263          	bne	a4,a5,7820 <nc_complete_game+0xa4>
    77e0:	0085a703          	lw	a4,8(a1)
    77e4:	0b442783          	lw	a5,180(s0)
    77e8:	02f71c63          	bne	a4,a5,7820 <nc_complete_game+0xa4>
    77ec:	00c5a703          	lw	a4,12(a1)
    77f0:	0b842783          	lw	a5,184(s0)
    77f4:	02f71663          	bne	a4,a5,7820 <nc_complete_game+0xa4>
    77f8:	00040513          	mv	a0,s0
    77fc:	f71ff0ef          	jal	776c <nc_discard_pending_telemetry>
    7800:	09842783          	lw	a5,152(s0)
    7804:	0c942023          	sw	s1,192(s0)
    7808:	00000513          	li	a0,0
    780c:	0cf42223          	sw	a5,196(s0)
    7810:	10000793          	li	a5,256
    7814:	0cf41423          	sh	a5,200(s0)
    7818:	00100793          	li	a5,1
    781c:	0cf40523          	sb	a5,202(s0)
    7820:	00c12083          	lw	ra,12(sp)
    7824:	00812403          	lw	s0,8(sp)
    7828:	00412483          	lw	s1,4(sp)
    782c:	01010113          	addi	sp,sp,16
    7830:	00008067          	ret
    7834:	fff00513          	li	a0,-1
    7838:	00008067          	ret

0000783c <nc_try_publish>:
    783c:	38050063          	beqz	a0,7bbc <nc_try_publish+0x380>
    7840:	ef010113          	addi	sp,sp,-272
    7844:	10812423          	sw	s0,264(sp)
    7848:	10112623          	sw	ra,268(sp)
    784c:	10912223          	sw	s1,260(sp)
    7850:	11212023          	sw	s2,256(sp)
    7854:	0f312e23          	sw	s3,252(sp)
    7858:	0f412c23          	sw	s4,248(sp)
    785c:	0f512a23          	sw	s5,244(sp)
    7860:	0f612823          	sw	s6,240(sp)
    7864:	0a854703          	lbu	a4,168(a0)
    7868:	00050413          	mv	s0,a0
    786c:	ffe00513          	li	a0,-2
    7870:	2e070463          	beqz	a4,7b58 <nc_try_publish+0x31c>
    7874:	00060993          	mv	s3,a2
    7878:	00058c63          	beqz	a1,7890 <nc_try_publish+0x54>
    787c:	06c00613          	li	a2,108
    7880:	01840513          	addi	a0,s0,24
    7884:	a81f90ef          	jal	1304 <memcpy>
    7888:	00100793          	li	a5,1
    788c:	0af40523          	sb	a5,170(s0)
    7890:	00098593          	mv	a1,s3
    7894:	00040513          	mv	a0,s0
    7898:	8e9ff0ef          	jal	7180 <expire>
    789c:	0aa44703          	lbu	a4,170(s0)
    78a0:	0a042783          	lw	a5,160(s0)
    78a4:	00000493          	li	s1,0
    78a8:	02070663          	beqz	a4,78d4 <nc_try_publish+0x98>
    78ac:	0ab44703          	lbu	a4,171(s0)
    78b0:	00100493          	li	s1,1
    78b4:	02070063          	beqz	a4,78d4 <nc_try_publish+0x98>
    78b8:	09c42483          	lw	s1,156(s0)
    78bc:	06400713          	li	a4,100
    78c0:	409984b3          	sub	s1,s3,s1
    78c4:	00e7f463          	bgeu	a5,a4,78cc <nc_try_publish+0x90>
    78c8:	06400793          	li	a5,100
    78cc:	00f4b4b3          	sltu	s1,s1,a5
    78d0:	0014b493          	seqz	s1,s1
    78d4:	0dd44783          	lbu	a5,221(s0)
    78d8:	00000913          	li	s2,0
    78dc:	02078463          	beqz	a5,7904 <nc_try_publish+0xc8>
    78e0:	01644783          	lbu	a5,22(s0)
    78e4:	02078063          	beqz	a5,7904 <nc_try_publish+0xc8>
    78e8:	0de44783          	lbu	a5,222(s0)
    78ec:	00100913          	li	s2,1
    78f0:	00078a63          	beqz	a5,7904 <nc_try_publish+0xc8>
    78f4:	0d842903          	lw	s2,216(s0)
    78f8:	41298933          	sub	s2,s3,s2
    78fc:	0c893913          	sltiu	s2,s2,200
    7900:	00193913          	seqz	s2,s2
    7904:	0a944a03          	lbu	s4,169(s0)
    7908:	000a1a63          	bnez	s4,791c <nc_try_publish+0xe0>
    790c:	0ca44783          	lbu	a5,202(s0)
    7910:	00079663          	bnez	a5,791c <nc_try_publish+0xe0>
    7914:	0124e533          	or	a0,s1,s2
    7918:	24050063          	beqz	a0,7b58 <nc_try_publish+0x31c>
    791c:	00042783          	lw	a5,0(s0)
    7920:	00000513          	li	a0,0
    7924:	3047a783          	lw	a5,772(a5)
    7928:	0047f793          	andi	a5,a5,4
    792c:	22078663          	beqz	a5,7b58 <nc_try_publish+0x31c>
    7930:	08000613          	li	a2,128
    7934:	00000593          	li	a1,0
    7938:	07010513          	addi	a0,sp,112
    793c:	8edf90ef          	jal	1228 <memset>
    7940:	280a1263          	bnez	s4,7bc4 <nc_try_publish+0x388>
    7944:	0ca44783          	lbu	a5,202(s0)
    7948:	2e079463          	bnez	a5,7c30 <nc_try_publish+0x3f4>
    794c:	09842a83          	lw	s5,152(s0)
    7950:	001a8a93          	addi	s5,s5,1
    7954:	36048263          	beqz	s1,7cb8 <nc_try_publish+0x47c>
    7958:	01644783          	lbu	a5,22(s0)
    795c:	00000493          	li	s1,0
    7960:	00078463          	beqz	a5,7968 <nc_try_publish+0x12c>
    7964:	00442483          	lw	s1,4(s0)
    7968:	01842783          	lw	a5,24(s0)
    796c:	007f8737          	lui	a4,0x7f8
    7970:	fff70713          	addi	a4,a4,-1 # 7f7fff <__freertos_irq_stack_top+0x7da55f>
    7974:	00f12223          	sw	a5,4(sp)
    7978:	01c42783          	lw	a5,28(s0)
    797c:	414755b7          	lui	a1,0x41475
    7980:	43158593          	addi	a1,a1,1073 # 41475431 <__gpu_framebuffer_a+0x3f475431>
    7984:	00f12423          	sw	a5,8(sp)
    7988:	02042783          	lw	a5,32(s0)
    798c:	07010513          	addi	a0,sp,112
    7990:	06c00913          	li	s2,108
    7994:	00f12623          	sw	a5,12(sp)
    7998:	02442783          	lw	a5,36(s0)
    799c:	00f12823          	sw	a5,16(sp)
    79a0:	02842783          	lw	a5,40(s0)
    79a4:	00f12a23          	sw	a5,20(sp)
    79a8:	02c42783          	lw	a5,44(s0)
    79ac:	00f12c23          	sw	a5,24(sp)
    79b0:	03042783          	lw	a5,48(s0)
    79b4:	00f12e23          	sw	a5,28(sp)
    79b8:	03442783          	lw	a5,52(s0)
    79bc:	02f12023          	sw	a5,32(sp)
    79c0:	03842783          	lw	a5,56(s0)
    79c4:	02f12223          	sw	a5,36(sp)
    79c8:	03c42783          	lw	a5,60(s0)
    79cc:	02f12423          	sw	a5,40(sp)
    79d0:	04042783          	lw	a5,64(s0)
    79d4:	02f12623          	sw	a5,44(sp)
    79d8:	04442783          	lw	a5,68(s0)
    79dc:	02f12823          	sw	a5,48(sp)
    79e0:	04842783          	lw	a5,72(s0)
    79e4:	02f12a23          	sw	a5,52(sp)
    79e8:	04c42783          	lw	a5,76(s0)
    79ec:	02f12c23          	sw	a5,56(sp)
    79f0:	05042783          	lw	a5,80(s0)
    79f4:	02f12e23          	sw	a5,60(sp)
    79f8:	05442783          	lw	a5,84(s0)
    79fc:	04f12023          	sw	a5,64(sp)
    7a00:	05842783          	lw	a5,88(s0)
    7a04:	04f12223          	sw	a5,68(sp)
    7a08:	05c42783          	lw	a5,92(s0)
    7a0c:	04f12423          	sw	a5,72(sp)
    7a10:	06042783          	lw	a5,96(s0)
    7a14:	04f12623          	sw	a5,76(sp)
    7a18:	06442783          	lw	a5,100(s0)
    7a1c:	04f12823          	sw	a5,80(sp)
    7a20:	06842783          	lw	a5,104(s0)
    7a24:	04f12a23          	sw	a5,84(sp)
    7a28:	06c42783          	lw	a5,108(s0)
    7a2c:	00e7f7b3          	and	a5,a5,a4
    7a30:	04f12c23          	sw	a5,88(sp)
    7a34:	07042783          	lw	a5,112(s0)
    7a38:	04f12e23          	sw	a5,92(sp)
    7a3c:	07442783          	lw	a5,116(s0)
    7a40:	06f12023          	sw	a5,96(sp)
    7a44:	07842783          	lw	a5,120(s0)
    7a48:	06f12223          	sw	a5,100(sp)
    7a4c:	07c42783          	lw	a5,124(s0)
    7a50:	06f12423          	sw	a5,104(sp)
    7a54:	08042783          	lw	a5,128(s0)
    7a58:	06f12623          	sw	a5,108(sp)
    7a5c:	f04ff0ef          	jal	7160 <put32>
    7a60:	ffff87b7          	lui	a5,0xffff8
    7a64:	00178793          	addi	a5,a5,1 # ffff8001 <__gpu_framebuffer_a+0xfdff8001>
    7a68:	00048593          	mv	a1,s1
    7a6c:	06f11a23          	sh	a5,116(sp)
    7a70:	07810513          	addi	a0,sp,120
    7a74:	f8000793          	li	a5,-128
    7a78:	06f10ba3          	sb	a5,119(sp)
    7a7c:	ee4ff0ef          	jal	7160 <put32>
    7a80:	000a8593          	mv	a1,s5
    7a84:	07c10513          	addi	a0,sp,124
    7a88:	ed8ff0ef          	jal	7160 <put32>
    7a8c:	00000493          	li	s1,0
    7a90:	00410793          	addi	a5,sp,4
    7a94:	009787b3          	add	a5,a5,s1
    7a98:	0007a583          	lw	a1,0(a5)
    7a9c:	08010793          	addi	a5,sp,128
    7aa0:	00978533          	add	a0,a5,s1
    7aa4:	00448493          	addi	s1,s1,4
    7aa8:	eb8ff0ef          	jal	7160 <put32>
    7aac:	ff2492e3          	bne	s1,s2,7a90 <nc_try_publish+0x254>
    7ab0:	07c00593          	li	a1,124
    7ab4:	07010513          	addi	a0,sp,112
    7ab8:	e28fc0ef          	jal	40e0 <asst_crc32>
    7abc:	00050593          	mv	a1,a0
    7ac0:	0ec10513          	addi	a0,sp,236
    7ac4:	e9cff0ef          	jal	7160 <put32>
    7ac8:	00000913          	li	s2,0
    7acc:	00000493          	li	s1,0
    7ad0:	08000693          	li	a3,128
    7ad4:	00042783          	lw	a5,0(s0)
    7ad8:	07010713          	addi	a4,sp,112
    7adc:	00000613          	li	a2,0
    7ae0:	3cd7a023          	sw	a3,960(a5)
    7ae4:	34078593          	addi	a1,a5,832
    7ae8:	00174783          	lbu	a5,1(a4)
    7aec:	00274503          	lbu	a0,2(a4)
    7af0:	00470713          	addi	a4,a4,4
    7af4:	00879793          	slli	a5,a5,0x8
    7af8:	01051513          	slli	a0,a0,0x10
    7afc:	00a7e7b3          	or	a5,a5,a0
    7b00:	ffc74503          	lbu	a0,-4(a4)
    7b04:	00a7e7b3          	or	a5,a5,a0
    7b08:	fff74503          	lbu	a0,-1(a4)
    7b0c:	01851513          	slli	a0,a0,0x18
    7b10:	00a7e7b3          	or	a5,a5,a0
    7b14:	00c58533          	add	a0,a1,a2
    7b18:	00f52023          	sw	a5,0(a0)
    7b1c:	00460613          	addi	a2,a2,4
    7b20:	fcd664e3          	bltu	a2,a3,7ae8 <nc_try_publish+0x2ac>
    7b24:	0ff0000f          	fence
    7b28:	00042783          	lw	a5,0(s0)
    7b2c:	00100713          	li	a4,1
    7b30:	30e7ac23          	sw	a4,792(a5)
    7b34:	0ff0000f          	fence
    7b38:	00042783          	lw	a5,0(s0)
    7b3c:	ffd00513          	li	a0,-3
    7b40:	3047a783          	lw	a5,772(a5)
    7b44:	0087f793          	andi	a5,a5,8
    7b48:	00079863          	bnez	a5,7b58 <nc_try_publish+0x31c>
    7b4c:	020a0a63          	beqz	s4,7b80 <nc_try_publish+0x344>
    7b50:	0a0404a3          	sb	zero,169(s0)
    7b54:	00100513          	li	a0,1
    7b58:	10c12083          	lw	ra,268(sp)
    7b5c:	10812403          	lw	s0,264(sp)
    7b60:	10412483          	lw	s1,260(sp)
    7b64:	10012903          	lw	s2,256(sp)
    7b68:	0fc12983          	lw	s3,252(sp)
    7b6c:	0f812a03          	lw	s4,248(sp)
    7b70:	0f412a83          	lw	s5,244(sp)
    7b74:	0f012b03          	lw	s6,240(sp)
    7b78:	11010113          	addi	sp,sp,272
    7b7c:	00008067          	ret
    7b80:	00048663          	beqz	s1,7b8c <nc_try_publish+0x350>
    7b84:	0c040523          	sb	zero,202(s0)
    7b88:	fcdff06f          	j	7b54 <nc_try_publish+0x318>
    7b8c:	09842783          	lw	a5,152(s0)
    7b90:	00178793          	addi	a5,a5,1
    7b94:	00090c63          	beqz	s2,7bac <nc_try_publish+0x370>
    7b98:	0c040ea3          	sb	zero,221(s0)
    7b9c:	0ce40f23          	sb	a4,222(s0)
    7ba0:	0d342c23          	sw	s3,216(s0)
    7ba4:	08f42c23          	sw	a5,152(s0)
    7ba8:	fadff06f          	j	7b54 <nc_try_publish+0x318>
    7bac:	10000713          	li	a4,256
    7bb0:	0ae41523          	sh	a4,170(s0)
    7bb4:	09342e23          	sw	s3,156(s0)
    7bb8:	fedff06f          	j	7ba4 <nc_try_publish+0x368>
    7bbc:	fff00513          	li	a0,-1
    7bc0:	00008067          	ret
    7bc4:	414745b7          	lui	a1,0x41474
    7bc8:	09042903          	lw	s2,144(s0)
    7bcc:	33158593          	addi	a1,a1,817 # 41474331 <__gpu_framebuffer_a+0x3f474331>
    7bd0:	07010513          	addi	a0,sp,112
    7bd4:	09442483          	lw	s1,148(s0)
    7bd8:	d88ff0ef          	jal	7160 <put32>
    7bdc:	30100793          	li	a5,769
    7be0:	00090593          	mv	a1,s2
    7be4:	06f11a23          	sh	a5,116(sp)
    7be8:	07810513          	addi	a0,sp,120
    7bec:	02000793          	li	a5,32
    7bf0:	06f10ba3          	sb	a5,119(sp)
    7bf4:	d6cff0ef          	jal	7160 <put32>
    7bf8:	00048593          	mv	a1,s1
    7bfc:	07c10513          	addi	a0,sp,124
    7c00:	d60ff0ef          	jal	7160 <put32>
    7c04:	00100793          	li	a5,1
    7c08:	01c00593          	li	a1,28
    7c0c:	07010513          	addi	a0,sp,112
    7c10:	08f101a3          	sb	a5,131(sp)
    7c14:	cccfc0ef          	jal	40e0 <asst_crc32>
    7c18:	00050593          	mv	a1,a0
    7c1c:	08c10513          	addi	a0,sp,140
    7c20:	d40ff0ef          	jal	7160 <put32>
    7c24:	00000913          	li	s2,0
    7c28:	00000493          	li	s1,0
    7c2c:	1080006f          	j	7d34 <nc_try_publish+0x4f8>
    7c30:	414745b7          	lui	a1,0x41474
    7c34:	0ac42903          	lw	s2,172(s0)
    7c38:	33158593          	addi	a1,a1,817 # 41474331 <__gpu_framebuffer_a+0x3f474331>
    7c3c:	07010513          	addi	a0,sp,112
    7c40:	0b042483          	lw	s1,176(s0)
    7c44:	d1cff0ef          	jal	7160 <put32>
    7c48:	50100793          	li	a5,1281
    7c4c:	00090593          	mv	a1,s2
    7c50:	06f11a23          	sh	a5,116(sp)
    7c54:	07810513          	addi	a0,sp,120
    7c58:	02000793          	li	a5,32
    7c5c:	06f10ba3          	sb	a5,119(sp)
    7c60:	d00ff0ef          	jal	7160 <put32>
    7c64:	00048593          	mv	a1,s1
    7c68:	07c10513          	addi	a0,sp,124
    7c6c:	cf4ff0ef          	jal	7160 <put32>
    7c70:	0bc42583          	lw	a1,188(s0)
    7c74:	08010513          	addi	a0,sp,128
    7c78:	00000913          	li	s2,0
    7c7c:	ce4ff0ef          	jal	7160 <put32>
    7c80:	0c042583          	lw	a1,192(s0)
    7c84:	08410513          	addi	a0,sp,132
    7c88:	00100493          	li	s1,1
    7c8c:	cd4ff0ef          	jal	7160 <put32>
    7c90:	0c442583          	lw	a1,196(s0)
    7c94:	08810513          	addi	a0,sp,136
    7c98:	cc8ff0ef          	jal	7160 <put32>
    7c9c:	01c00593          	li	a1,28
    7ca0:	07010513          	addi	a0,sp,112
    7ca4:	c3cfc0ef          	jal	40e0 <asst_crc32>
    7ca8:	00050593          	mv	a1,a0
    7cac:	08c10513          	addi	a0,sp,140
    7cb0:	cb0ff0ef          	jal	7160 <put32>
    7cb4:	0800006f          	j	7d34 <nc_try_publish+0x4f8>
    7cb8:	ca0900e3          	beqz	s2,7958 <nc_try_publish+0x11c>
    7cbc:	414745b7          	lui	a1,0x41474
    7cc0:	00442b03          	lw	s6,4(s0)
    7cc4:	33158593          	addi	a1,a1,817 # 41474331 <__gpu_framebuffer_a+0x3f474331>
    7cc8:	07010513          	addi	a0,sp,112
    7ccc:	c94ff0ef          	jal	7160 <put32>
    7cd0:	60100793          	li	a5,1537
    7cd4:	06f11a23          	sh	a5,116(sp)
    7cd8:	000b0593          	mv	a1,s6
    7cdc:	02000793          	li	a5,32
    7ce0:	07810513          	addi	a0,sp,120
    7ce4:	06f10ba3          	sb	a5,119(sp)
    7ce8:	c78ff0ef          	jal	7160 <put32>
    7cec:	000a8593          	mv	a1,s5
    7cf0:	07c10513          	addi	a0,sp,124
    7cf4:	c6cff0ef          	jal	7160 <put32>
    7cf8:	0cc42583          	lw	a1,204(s0)
    7cfc:	08010513          	addi	a0,sp,128
    7d00:	c60ff0ef          	jal	7160 <put32>
    7d04:	0d042583          	lw	a1,208(s0)
    7d08:	08410513          	addi	a0,sp,132
    7d0c:	c54ff0ef          	jal	7160 <put32>
    7d10:	0d442583          	lw	a1,212(s0)
    7d14:	08810513          	addi	a0,sp,136
    7d18:	c48ff0ef          	jal	7160 <put32>
    7d1c:	01c00593          	li	a1,28
    7d20:	07010513          	addi	a0,sp,112
    7d24:	bbcfc0ef          	jal	40e0 <asst_crc32>
    7d28:	00050593          	mv	a1,a0
    7d2c:	08c10513          	addi	a0,sp,140
    7d30:	c30ff0ef          	jal	7160 <put32>
    7d34:	02000693          	li	a3,32
    7d38:	d9dff06f          	j	7ad4 <nc_try_publish+0x298>

00007d3c <input_update>:
    7d3c:	12050263          	beqz	a0,7e60 <input_update+0x124>
    7d40:	00051123          	sh	zero,2(a0)
    7d44:	00051223          	sh	zero,4(a0)
    7d48:	02058063          	beqz	a1,7d68 <input_update+0x2c>
    7d4c:	0125c783          	lbu	a5,18(a1)
    7d50:	00078c63          	beqz	a5,7d68 <input_update+0x2c>
    7d54:	0005a883          	lw	a7,0(a1)
    7d58:	00088863          	beqz	a7,7d68 <input_update+0x2c>
    7d5c:	00c5a703          	lw	a4,12(a1)
    7d60:	0fa00793          	li	a5,250
    7d64:	00e7fe63          	bgeu	a5,a4,7d80 <input_update+0x44>
    7d68:	00055783          	lhu	a5,0(a0)
    7d6c:	00051a23          	sh	zero,20(a0)
    7d70:	00051023          	sh	zero,0(a0)
    7d74:	00f51223          	sh	a5,4(a0)
    7d78:	00050b23          	sb	zero,22(a0)
    7d7c:	00008067          	ret
    7d80:	01454783          	lbu	a5,20(a0)
    7d84:	0045a303          	lw	t1,4(a1)
    7d88:	00078e63          	beqz	a5,7da4 <input_update+0x68>
    7d8c:	00852783          	lw	a5,8(a0)
    7d90:	00f89a63          	bne	a7,a5,7da4 <input_update+0x68>
    7d94:	00c52783          	lw	a5,12(a0)
    7d98:	40f307b3          	sub	a5,t1,a5
    7d9c:	00f04663          	bgtz	a5,7da8 <input_update+0x6c>
    7da0:	00008067          	ret
    7da4:	00050aa3          	sb	zero,21(a0)
    7da8:	0105d603          	lhu	a2,16(a1)
    7dac:	00300713          	li	a4,3
    7db0:	00367693          	andi	a3,a2,3
    7db4:	0fc67793          	andi	a5,a2,252
    7db8:	00e68463          	beq	a3,a4,7dc0 <input_update+0x84>
    7dbc:	0ff67793          	zext.b	a5,a2
    7dc0:	00c7f713          	andi	a4,a5,12
    7dc4:	00c00693          	li	a3,12
    7dc8:	00d71863          	bne	a4,a3,7dd8 <input_update+0x9c>
    7dcc:	ff37f793          	andi	a5,a5,-13
    7dd0:	01079793          	slli	a5,a5,0x10
    7dd4:	0107d793          	srli	a5,a5,0x10
    7dd8:	00055803          	lhu	a6,0(a0)
    7ddc:	fff7ce13          	not	t3,a5
    7de0:	fff84713          	not	a4,a6
    7de4:	00e7f733          	and	a4,a5,a4
    7de8:	01c87833          	and	a6,a6,t3
    7dec:	f3f77693          	andi	a3,a4,-193
    7df0:	01069693          	slli	a3,a3,0x10
    7df4:	01051223          	sh	a6,4(a0)
    7df8:	01554803          	lbu	a6,21(a0)
    7dfc:	0106d693          	srli	a3,a3,0x10
    7e00:	00d51123          	sh	a3,2(a0)
    7e04:	0085ae03          	lw	t3,8(a1)
    7e08:	00080863          	beqz	a6,7e18 <input_update+0xdc>
    7e0c:	01052803          	lw	a6,16(a0)
    7e10:	410e0833          	sub	a6,t3,a6
    7e14:	03005263          	blez	a6,7e38 <input_update+0xfc>
    7e18:	0c077713          	andi	a4,a4,192
    7e1c:	04071463          	bnez	a4,7e64 <input_update+0x128>
    7e20:	0c07f713          	andi	a4,a5,192
    7e24:	00e6e6b3          	or	a3,a3,a4
    7e28:	00100713          	li	a4,1
    7e2c:	00d51123          	sh	a3,2(a0)
    7e30:	01c52823          	sw	t3,16(a0)
    7e34:	00e50aa3          	sb	a4,21(a0)
    7e38:	00f51023          	sh	a5,0(a0)
    7e3c:	00100793          	li	a5,1
    7e40:	00f50a23          	sb	a5,20(a0)
    7e44:	01152423          	sw	a7,8(a0)
    7e48:	00652623          	sw	t1,12(a0)
    7e4c:	0135c703          	lbu	a4,19(a1)
    7e50:	00000793          	li	a5,0
    7e54:	00070463          	beqz	a4,7e5c <input_update+0x120>
    7e58:	00163793          	seqz	a5,a2
    7e5c:	00f50b23          	sb	a5,22(a0)
    7e60:	00008067          	ret
    7e64:	01071713          	slli	a4,a4,0x10
    7e68:	41075713          	srai	a4,a4,0x10
    7e6c:	fb9ff06f          	j	7e24 <input_update+0xe8>

00007e70 <reserve_shots>:
    7e70:	000057b7          	lui	a5,0x5
    7e74:	00f507b3          	add	a5,a0,a5
    7e78:	0087a603          	lw	a2,8(a5) # 5008 <bullet_enemy_position+0x50>
    7e7c:	00800713          	li	a4,8
    7e80:	00c76463          	bltu	a4,a2,7e88 <reserve_shots+0x18>
    7e84:	00165713          	srli	a4,a2,0x1
    7e88:	40e60733          	sub	a4,a2,a4
    7e8c:	01400793          	li	a5,20
    7e90:	02f707b3          	mul	a5,a4,a5
    7e94:	00300593          	li	a1,3
    7e98:	01400813          	li	a6,20
    7e9c:	fff00893          	li	a7,-1
    7ea0:	00200313          	li	t1,2
    7ea4:	00f507b3          	add	a5,a0,a5
    7ea8:	00c76463          	bltu	a4,a2,7eb0 <reserve_shots+0x40>
    7eac:	00008067          	ret
    7eb0:	00e7c683          	lbu	a3,14(a5)
    7eb4:	02b68663          	beq	a3,a1,7ee0 <reserve_shots+0x70>
    7eb8:	030706b3          	mul	a3,a4,a6
    7ebc:	00d506b3          	add	a3,a0,a3
    7ec0:	0006a023          	sw	zero,0(a3)
    7ec4:	0006a223          	sw	zero,4(a3)
    7ec8:	0006a423          	sw	zero,8(a3)
    7ecc:	0006a623          	sw	zero,12(a3)
    7ed0:	0006a823          	sw	zero,16(a3)
    7ed4:	01179623          	sh	a7,12(a5)
    7ed8:	00b78723          	sb	a1,14(a5)
    7edc:	006787a3          	sb	t1,15(a5)
    7ee0:	00170713          	addi	a4,a4,1
    7ee4:	01478793          	addi	a5,a5,20
    7ee8:	fc1ff06f          	j	7ea8 <reserve_shots+0x38>

00007eec <game_reset>:
    7eec:	ff010113          	addi	sp,sp,-16
    7ef0:	00812423          	sw	s0,8(sp)
    7ef4:	00912223          	sw	s1,4(sp)
    7ef8:	00112623          	sw	ra,12(sp)
    7efc:	00050493          	mv	s1,a0
    7f00:	e14fd0ef          	jal	5514 <bullet_reset_player>
    7f04:	00050413          	mv	s0,a0
    7f08:	00051663          	bnez	a0,7f14 <game_reset+0x28>
    7f0c:	00048513          	mv	a0,s1
    7f10:	f61ff0ef          	jal	7e70 <reserve_shots>
    7f14:	00c12083          	lw	ra,12(sp)
    7f18:	00040513          	mv	a0,s0
    7f1c:	00812403          	lw	s0,8(sp)
    7f20:	00412483          	lw	s1,4(sp)
    7f24:	01010113          	addi	sp,sp,16
    7f28:	00008067          	ret

00007f2c <game_update_cached>:
    7f2c:	20050863          	beqz	a0,813c <game_update_cached+0x210>
    7f30:	ff010113          	addi	sp,sp,-16
    7f34:	00912223          	sw	s1,4(sp)
    7f38:	00112623          	sw	ra,12(sp)
    7f3c:	00812423          	sw	s0,8(sp)
    7f40:	00058493          	mv	s1,a1
    7f44:	20058063          	beqz	a1,8144 <game_update_cached+0x218>
    7f48:	000057b7          	lui	a5,0x5
    7f4c:	00f507b3          	add	a5,a0,a5
    7f50:	0087a583          	lw	a1,8(a5) # 5008 <bullet_enemy_position+0x50>
    7f54:	00060693          	mv	a3,a2
    7f58:	3ff00713          	li	a4,1023
    7f5c:	fff58613          	addi	a2,a1,-1
    7f60:	00050413          	mv	s0,a0
    7f64:	1ec76063          	bltu	a4,a2,8144 <game_update_cached+0x218>
    7f68:	00c7a303          	lw	t1,12(a5)
    7f6c:	3b000713          	li	a4,944
    7f70:	ff830613          	addi	a2,t1,-8
    7f74:	1cc76863          	bltu	a4,a2,8144 <game_update_cached+0x218>
    7f78:	0107a883          	lw	a7,16(a5)
    7f7c:	1c400713          	li	a4,452
    7f80:	fb088613          	addi	a2,a7,-80
    7f84:	1cc76063          	bltu	a4,a2,8144 <game_update_cached+0x218>
    7f88:	0004d703          	lhu	a4,0(s1)
    7f8c:	0024d603          	lhu	a2,2(s1)
    7f90:	0044de03          	lhu	t3,4(s1)
    7f94:	00c76833          	or	a6,a4,a2
    7f98:	01c86833          	or	a6,a6,t3
    7f9c:	0ff00e13          	li	t3,255
    7fa0:	1b0e6263          	bltu	t3,a6,8144 <game_update_cached+0x218>
    7fa4:	04067613          	andi	a2,a2,64
    7fa8:	00060e63          	beqz	a2,7fc4 <game_update_cached+0x98>
    7fac:	00812403          	lw	s0,8(sp)
    7fb0:	00c12083          	lw	ra,12(sp)
    7fb4:	00412483          	lw	s1,4(sp)
    7fb8:	0007a603          	lw	a2,0(a5)
    7fbc:	01010113          	addi	sp,sp,16
    7fc0:	f2dff06f          	j	7eec <game_reset>
    7fc4:	00175793          	srli	a5,a4,0x1
    7fc8:	00177613          	andi	a2,a4,1
    7fcc:	0017f793          	andi	a5,a5,1
    7fd0:	00375513          	srli	a0,a4,0x3
    7fd4:	40c787b3          	sub	a5,a5,a2
    7fd8:	00275613          	srli	a2,a4,0x2
    7fdc:	00157513          	andi	a0,a0,1
    7fe0:	00167613          	andi	a2,a2,1
    7fe4:	02077593          	andi	a1,a4,32
    7fe8:	40c50533          	sub	a0,a0,a2
    7fec:	00100713          	li	a4,1
    7ff0:	00059a63          	bnez	a1,8004 <game_update_cached+0xd8>
    7ff4:	00400713          	li	a4,4
    7ff8:	00078663          	beqz	a5,8004 <game_update_cached+0xd8>
    7ffc:	00153713          	seqz	a4,a0
    8000:	00370713          	addi	a4,a4,3
    8004:	02f707b3          	mul	a5,a4,a5
    8008:	006785b3          	add	a1,a5,t1
    800c:	3b800793          	li	a5,952
    8010:	00b7d463          	bge	a5,a1,8018 <game_update_cached+0xec>
    8014:	3b800593          	li	a1,952
    8018:	00800793          	li	a5,8
    801c:	00f5d463          	bge	a1,a5,8024 <game_update_cached+0xf8>
    8020:	00800593          	li	a1,8
    8024:	02a70733          	mul	a4,a4,a0
    8028:	21400793          	li	a5,532
    802c:	01170633          	add	a2,a4,a7
    8030:	00c7d463          	bge	a5,a2,8038 <game_update_cached+0x10c>
    8034:	21400613          	li	a2,532
    8038:	05000793          	li	a5,80
    803c:	00f65463          	bge	a2,a5,8044 <game_update_cached+0x118>
    8040:	05000613          	li	a2,80
    8044:	00040513          	mv	a0,s0
    8048:	0e068263          	beqz	a3,812c <game_update_cached+0x200>
    804c:	d3dfd0ef          	jal	5d88 <bullet_step_player_cached>
    8050:	0c051463          	bnez	a0,8118 <game_update_cached+0x1ec>
    8054:	00040513          	mv	a0,s0
    8058:	e19ff0ef          	jal	7e70 <reserve_shots>
    805c:	000057b7          	lui	a5,0x5
    8060:	00f407b3          	add	a5,s0,a5
    8064:	0247c703          	lbu	a4,36(a5) # 5024 <bullet_enemy_position+0x6c>
    8068:	0a070263          	beqz	a4,810c <game_update_cached+0x1e0>
    806c:	0297c703          	lbu	a4,41(a5)
    8070:	08071e63          	bnez	a4,810c <game_update_cached+0x1e0>
    8074:	0004d703          	lhu	a4,0(s1)
    8078:	01077713          	andi	a4,a4,16
    807c:	08070863          	beqz	a4,810c <game_update_cached+0x1e0>
    8080:	0147a703          	lw	a4,20(a5)
    8084:	00600693          	li	a3,6
    8088:	02d77733          	remu	a4,a4,a3
    808c:	00100693          	li	a3,1
    8090:	06d71e63          	bne	a4,a3,810c <game_update_cached+0x1e0>
    8094:	0087a683          	lw	a3,8(a5)
    8098:	00800713          	li	a4,8
    809c:	00d76463          	bltu	a4,a3,80a4 <game_update_cached+0x178>
    80a0:	0016d713          	srli	a4,a3,0x1
    80a4:	00010637          	lui	a2,0x10
    80a8:	40e68733          	sub	a4,a3,a4
    80ac:	01400593          	li	a1,20
    80b0:	fff60613          	addi	a2,a2,-1 # ffff <__global_pointer$+0x127f>
    80b4:	04d77c63          	bgeu	a4,a3,810c <game_update_cached+0x1e0>
    80b8:	02b707b3          	mul	a5,a4,a1
    80bc:	00f407b3          	add	a5,s0,a5
    80c0:	00c7d503          	lhu	a0,12(a5)
    80c4:	06c51863          	bne	a0,a2,8134 <game_update_cached+0x208>
    80c8:	00005737          	lui	a4,0x5
    80cc:	00e40733          	add	a4,s0,a4
    80d0:	00c72683          	lw	a3,12(a4) # 500c <bullet_enemy_position+0x54>
    80d4:	01072703          	lw	a4,16(a4)
    80d8:	0007a423          	sw	zero,8(a5)
    80dc:	ffc68693          	addi	a3,a3,-4
    80e0:	ff070713          	addi	a4,a4,-16
    80e4:	00871713          	slli	a4,a4,0x8
    80e8:	00e7a223          	sw	a4,4(a5)
    80ec:	80000713          	li	a4,-2048
    80f0:	00869693          	slli	a3,a3,0x8
    80f4:	0007a623          	sw	zero,12(a5)
    80f8:	00e79523          	sh	a4,10(a5)
    80fc:	20300713          	li	a4,515
    8100:	0007a823          	sw	zero,16(a5)
    8104:	00d7a023          	sw	a3,0(a5)
    8108:	00e79723          	sh	a4,14(a5)
    810c:	0024d503          	lhu	a0,2(s1)
    8110:	00755513          	srli	a0,a0,0x7
    8114:	00157513          	andi	a0,a0,1
    8118:	00c12083          	lw	ra,12(sp)
    811c:	00812403          	lw	s0,8(sp)
    8120:	00412483          	lw	s1,4(sp)
    8124:	01010113          	addi	sp,sp,16
    8128:	00008067          	ret
    812c:	c49fd0ef          	jal	5d74 <bullet_step_player>
    8130:	f21ff06f          	j	8050 <game_update_cached+0x124>
    8134:	00170713          	addi	a4,a4,1
    8138:	f7dff06f          	j	80b4 <game_update_cached+0x188>
    813c:	ff800513          	li	a0,-8
    8140:	00008067          	ret
    8144:	ff800513          	li	a0,-8
    8148:	fd1ff06f          	j	8118 <game_update_cached+0x1ec>

0000814c <game_update>:
    814c:	00000613          	li	a2,0
    8150:	dddff06f          	j	7f2c <game_update_cached>

00008154 <game_build>:
    8154:	dc0fe06f          	j	6714 <bullet_build_frame_player>

00008158 <crc_word>:
    8158:	00052783          	lw	a5,0(a0)
    815c:	0000e6b7          	lui	a3,0xe
    8160:	00800713          	li	a4,8
    8164:	00f5c5b3          	xor	a1,a1,a5
    8168:	3c468693          	addi	a3,a3,964 # e3c4 <lut.0>
    816c:	00f5f793          	andi	a5,a1,15
    8170:	00279793          	slli	a5,a5,0x2
    8174:	00f687b3          	add	a5,a3,a5
    8178:	0007a783          	lw	a5,0(a5)
    817c:	0045d593          	srli	a1,a1,0x4
    8180:	fff70713          	addi	a4,a4,-1
    8184:	00f5c5b3          	xor	a1,a1,a5
    8188:	fe0712e3          	bnez	a4,816c <crc_word+0x14>
    818c:	00b52023          	sw	a1,0(a0)
    8190:	00008067          	ret

00008194 <checksum>:
    8194:	fd010113          	addi	sp,sp,-48
    8198:	fff00793          	li	a5,-1
    819c:	02812423          	sw	s0,40(sp)
    81a0:	02912223          	sw	s1,36(sp)
    81a4:	00200593          	li	a1,2
    81a8:	00050493          	mv	s1,a0
    81ac:	00005437          	lui	s0,0x5
    81b0:	00c10513          	addi	a0,sp,12
    81b4:	02112623          	sw	ra,44(sp)
    81b8:	00f12623          	sw	a5,12(sp)
    81bc:	00848433          	add	s0,s1,s0
    81c0:	03212023          	sw	s2,32(sp)
    81c4:	01312e23          	sw	s3,28(sp)
    81c8:	01412c23          	sw	s4,24(sp)
    81cc:	f8dff0ef          	jal	8158 <crc_word>
    81d0:	4dc42583          	lw	a1,1244(s0) # 54dc <bullet_reset+0x7c>
    81d4:	00c10513          	addi	a0,sp,12
    81d8:	00000913          	li	s2,0
    81dc:	f7dff0ef          	jal	8158 <crc_word>
    81e0:	4e042583          	lw	a1,1248(s0)
    81e4:	00c10513          	addi	a0,sp,12
    81e8:	f71ff0ef          	jal	8158 <crc_word>
    81ec:	4e845983          	lhu	s3,1256(s0)
    81f0:	00c10513          	addi	a0,sp,12
    81f4:	00098593          	mv	a1,s3
    81f8:	f61ff0ef          	jal	8158 <crc_word>
    81fc:	00842a03          	lw	s4,8(s0)
    8200:	00c10513          	addi	a0,sp,12
    8204:	000a0593          	mv	a1,s4
    8208:	f51ff0ef          	jal	8158 <crc_word>
    820c:	00042583          	lw	a1,0(s0)
    8210:	00c10513          	addi	a0,sp,12
    8214:	f45ff0ef          	jal	8158 <crc_word>
    8218:	00442583          	lw	a1,4(s0)
    821c:	00c10513          	addi	a0,sp,12
    8220:	f39ff0ef          	jal	8158 <crc_word>
    8224:	01442583          	lw	a1,20(s0)
    8228:	00c10513          	addi	a0,sp,12
    822c:	f2dff0ef          	jal	8158 <crc_word>
    8230:	01842583          	lw	a1,24(s0)
    8234:	00c10513          	addi	a0,sp,12
    8238:	f21ff0ef          	jal	8158 <crc_word>
    823c:	01c42583          	lw	a1,28(s0)
    8240:	00c10513          	addi	a0,sp,12
    8244:	f15ff0ef          	jal	8158 <crc_word>
    8248:	00c42583          	lw	a1,12(s0)
    824c:	00c10513          	addi	a0,sp,12
    8250:	f09ff0ef          	jal	8158 <crc_word>
    8254:	01042583          	lw	a1,16(s0)
    8258:	00c10513          	addi	a0,sp,12
    825c:	efdff0ef          	jal	8158 <crc_word>
    8260:	02045583          	lhu	a1,32(s0)
    8264:	00c10513          	addi	a0,sp,12
    8268:	ef1ff0ef          	jal	8158 <crc_word>
    826c:	02245583          	lhu	a1,34(s0)
    8270:	00c10513          	addi	a0,sp,12
    8274:	ee5ff0ef          	jal	8158 <crc_word>
    8278:	02444583          	lbu	a1,36(s0)
    827c:	00c10513          	addi	a0,sp,12
    8280:	ed9ff0ef          	jal	8158 <crc_word>
    8284:	02844583          	lbu	a1,40(s0)
    8288:	00c10513          	addi	a0,sp,12
    828c:	ecdff0ef          	jal	8158 <crc_word>
    8290:	02944583          	lbu	a1,41(s0)
    8294:	00c10513          	addi	a0,sp,12
    8298:	ec1ff0ef          	jal	8158 <crc_word>
    829c:	02544583          	lbu	a1,37(s0)
    82a0:	00c10513          	addi	a0,sp,12
    82a4:	eb5ff0ef          	jal	8158 <crc_word>
    82a8:	02644583          	lbu	a1,38(s0)
    82ac:	00c10513          	addi	a0,sp,12
    82b0:	ea9ff0ef          	jal	8158 <crc_word>
    82b4:	02744583          	lbu	a1,39(s0)
    82b8:	00c10513          	addi	a0,sp,12
    82bc:	00048413          	mv	s0,s1
    82c0:	e99ff0ef          	jal	8158 <crc_word>
    82c4:	052a1063          	bne	s4,s2,8304 <checksum+0x170>
    82c8:	000057b7          	lui	a5,0x5
    82cc:	02c78793          	addi	a5,a5,44 # 502c <bullet_enemy_position+0x74>
    82d0:	00f484b3          	add	s1,s1,a5
    82d4:	00000413          	li	s0,0
    82d8:	0b346263          	bltu	s0,s3,837c <checksum+0x1e8>
    82dc:	00c12503          	lw	a0,12(sp)
    82e0:	02c12083          	lw	ra,44(sp)
    82e4:	02812403          	lw	s0,40(sp)
    82e8:	02412483          	lw	s1,36(sp)
    82ec:	02012903          	lw	s2,32(sp)
    82f0:	01c12983          	lw	s3,28(sp)
    82f4:	01812a03          	lw	s4,24(sp)
    82f8:	fff54513          	not	a0,a0
    82fc:	03010113          	addi	sp,sp,48
    8300:	00008067          	ret
    8304:	00042583          	lw	a1,0(s0)
    8308:	00c10513          	addi	a0,sp,12
    830c:	00190913          	addi	s2,s2,1
    8310:	e49ff0ef          	jal	8158 <crc_word>
    8314:	00442583          	lw	a1,4(s0)
    8318:	00c10513          	addi	a0,sp,12
    831c:	01440413          	addi	s0,s0,20
    8320:	e39ff0ef          	jal	8158 <crc_word>
    8324:	ff441583          	lh	a1,-12(s0)
    8328:	00c10513          	addi	a0,sp,12
    832c:	e2dff0ef          	jal	8158 <crc_word>
    8330:	ff641583          	lh	a1,-10(s0)
    8334:	00c10513          	addi	a0,sp,12
    8338:	e21ff0ef          	jal	8158 <crc_word>
    833c:	ff845583          	lhu	a1,-8(s0)
    8340:	00c10513          	addi	a0,sp,12
    8344:	e15ff0ef          	jal	8158 <crc_word>
    8348:	ffa44583          	lbu	a1,-6(s0)
    834c:	00c10513          	addi	a0,sp,12
    8350:	e09ff0ef          	jal	8158 <crc_word>
    8354:	ffb44583          	lbu	a1,-5(s0)
    8358:	00c10513          	addi	a0,sp,12
    835c:	dfdff0ef          	jal	8158 <crc_word>
    8360:	ffc44583          	lbu	a1,-4(s0)
    8364:	00c10513          	addi	a0,sp,12
    8368:	df1ff0ef          	jal	8158 <crc_word>
    836c:	ffd44583          	lbu	a1,-3(s0)
    8370:	00c10513          	addi	a0,sp,12
    8374:	de5ff0ef          	jal	8158 <crc_word>
    8378:	f4dff06f          	j	82c4 <checksum+0x130>
    837c:	0004d583          	lhu	a1,0(s1)
    8380:	00c10513          	addi	a0,sp,12
    8384:	00140413          	addi	s0,s0,1
    8388:	dd1ff0ef          	jal	8158 <crc_word>
    838c:	00248493          	addi	s1,s1,2
    8390:	f49ff06f          	j	82d8 <checksum+0x144>

00008394 <initial_valid>:
    8394:	02051263          	bnez	a0,83b8 <initial_valid+0x24>
    8398:	00000513          	li	a0,0
    839c:	00008067          	ret
    83a0:	00000513          	li	a0,0
    83a4:	00c12083          	lw	ra,12(sp)
    83a8:	00812403          	lw	s0,8(sp)
    83ac:	00412483          	lw	s1,4(sp)
    83b0:	01010113          	addi	sp,sp,16
    83b4:	00008067          	ret
    83b8:	ff010113          	addi	sp,sp,-16
    83bc:	00912223          	sw	s1,4(sp)
    83c0:	000054b7          	lui	s1,0x5
    83c4:	009504b3          	add	s1,a0,s1
    83c8:	0084a783          	lw	a5,8(s1) # 5008 <bullet_enemy_position+0x50>
    83cc:	00812423          	sw	s0,8(sp)
    83d0:	00112623          	sw	ra,12(sp)
    83d4:	fff78793          	addi	a5,a5,-1
    83d8:	3ff00713          	li	a4,1023
    83dc:	00050413          	mv	s0,a0
    83e0:	fcf760e3          	bltu	a4,a5,83a0 <initial_valid+0xc>
    83e4:	0244c703          	lbu	a4,36(s1)
    83e8:	00300793          	li	a5,3
    83ec:	fae7eae3          	bltu	a5,a4,83a0 <initial_valid+0xc>
    83f0:	b4dfc0ef          	jal	4f3c <bullet_campaign_valid>
    83f4:	fa0506e3          	beqz	a0,83a0 <initial_valid+0xc>
    83f8:	00c4a783          	lw	a5,12(s1)
    83fc:	3b000713          	li	a4,944
    8400:	ff878793          	addi	a5,a5,-8
    8404:	f8f76ee3          	bltu	a4,a5,83a0 <initial_valid+0xc>
    8408:	0104a783          	lw	a5,16(s1)
    840c:	1c400713          	li	a4,452
    8410:	fb078793          	addi	a5,a5,-80
    8414:	f8f766e3          	bltu	a4,a5,83a0 <initial_valid+0xc>
    8418:	0204d703          	lhu	a4,32(s1)
    841c:	03c00793          	li	a5,60
    8420:	f8e7e0e3          	bltu	a5,a4,83a0 <initial_valid+0xc>
    8424:	0244c783          	lbu	a5,36(s1)
    8428:	00079e63          	bnez	a5,8444 <initial_valid+0xb0>
    842c:	0224d783          	lhu	a5,34(s1)
    8430:	07700713          	li	a4,119
    8434:	fff78793          	addi	a5,a5,-1
    8438:	01079793          	slli	a5,a5,0x10
    843c:	0107d793          	srli	a5,a5,0x10
    8440:	f6f760e3          	bltu	a4,a5,83a0 <initial_valid+0xc>
    8444:	000057b7          	lui	a5,0x5
    8448:	00f407b3          	add	a5,s0,a5
    844c:	0087a603          	lw	a2,8(a5) # 5008 <bullet_enemy_position+0x50>
    8450:	00e40513          	addi	a0,s0,14
    8454:	00000713          	li	a4,0
    8458:	00300593          	li	a1,3
    845c:	00500693          	li	a3,5
    8460:	00e61663          	bne	a2,a4,846c <initial_valid+0xd8>
    8464:	00100513          	li	a0,1
    8468:	f3dff06f          	j	83a4 <initial_valid+0x10>
    846c:	00054803          	lbu	a6,0(a0)
    8470:	f305e8e3          	bltu	a1,a6,83a0 <initial_valid+0xc>
    8474:	00154803          	lbu	a6,1(a0)
    8478:	f306e4e3          	bltu	a3,a6,83a0 <initial_valid+0xc>
    847c:	0287c803          	lbu	a6,40(a5)
    8480:	00080663          	beqz	a6,848c <initial_valid+0xf8>
    8484:	00354803          	lbu	a6,3(a0)
    8488:	f106ece3          	bltu	a3,a6,83a0 <initial_valid+0xc>
    848c:	00170713          	addi	a4,a4,1
    8490:	01450513          	addi	a0,a0,20
    8494:	fcdff06f          	j	8460 <initial_valid+0xcc>

00008498 <replay_init>:
    8498:	02051663          	bnez	a0,84c4 <replay_init+0x2c>
    849c:	ff800513          	li	a0,-8
    84a0:	00008067          	ret
    84a4:	ff800513          	li	a0,-8
    84a8:	01c12083          	lw	ra,28(sp)
    84ac:	01812403          	lw	s0,24(sp)
    84b0:	01412483          	lw	s1,20(sp)
    84b4:	01012903          	lw	s2,16(sp)
    84b8:	00c12983          	lw	s3,12(sp)
    84bc:	02010113          	addi	sp,sp,32
    84c0:	00008067          	ret
    84c4:	fe010113          	addi	sp,sp,-32
    84c8:	00812c23          	sw	s0,24(sp)
    84cc:	00050413          	mv	s0,a0
    84d0:	00058513          	mv	a0,a1
    84d4:	00912a23          	sw	s1,20(sp)
    84d8:	01212823          	sw	s2,16(sp)
    84dc:	00112e23          	sw	ra,28(sp)
    84e0:	01312623          	sw	s3,12(sp)
    84e4:	00058493          	mv	s1,a1
    84e8:	00060913          	mv	s2,a2
    84ec:	ea9ff0ef          	jal	8394 <initial_valid>
    84f0:	fa050ae3          	beqz	a0,84a4 <replay_init+0xc>
    84f4:	fa0908e3          	beqz	s2,84a4 <replay_init+0xc>
    84f8:	fa9406e3          	beq	s0,s1,84a4 <replay_init+0xc>
    84fc:	00005637          	lui	a2,0x5
    8500:	4ec60613          	addi	a2,a2,1260 # 54ec <bullet_reset+0x8c>
    8504:	00000593          	li	a1,0
    8508:	00040513          	mv	a0,s0
    850c:	d1df80ef          	jal	1228 <memset>
    8510:	00005637          	lui	a2,0x5
    8514:	000059b7          	lui	s3,0x5
    8518:	00048593          	mv	a1,s1
    851c:	00040513          	mv	a0,s0
    8520:	02c60613          	addi	a2,a2,44 # 502c <bullet_enemy_position+0x74>
    8524:	de1f80ef          	jal	1304 <memcpy>
    8528:	013484b3          	add	s1,s1,s3
    852c:	0004a783          	lw	a5,0(s1)
    8530:	01340433          	add	s0,s0,s3
    8534:	4f242023          	sw	s2,1248(s0)
    8538:	4cf42e23          	sw	a5,1244(s0)
    853c:	00000513          	li	a0,0
    8540:	f69ff06f          	j	84a8 <replay_init+0x10>

00008544 <replay_record>:
    8544:	00050793          	mv	a5,a0
    8548:	ff800513          	li	a0,-8
    854c:	06078c63          	beqz	a5,85c4 <replay_record+0x80>
    8550:	06058a63          	beqz	a1,85c4 <replay_record+0x80>
    8554:	00005637          	lui	a2,0x5
    8558:	00c78633          	add	a2,a5,a2
    855c:	4ea64703          	lbu	a4,1258(a2) # 54ea <bullet_reset+0x8a>
    8560:	06071263          	bnez	a4,85c4 <replay_record+0x80>
    8564:	0005d683          	lhu	a3,0(a1)
    8568:	0025d803          	lhu	a6,2(a1)
    856c:	0045d583          	lhu	a1,4(a1)
    8570:	0106e733          	or	a4,a3,a6
    8574:	00b76733          	or	a4,a4,a1
    8578:	0ff00593          	li	a1,255
    857c:	04e5e463          	bltu	a1,a4,85c4 <replay_record+0x80>
    8580:	4e865703          	lhu	a4,1256(a2)
    8584:	25700593          	li	a1,599
    8588:	ffc00513          	li	a0,-4
    858c:	02e5ec63          	bltu	a1,a4,85c4 <replay_record+0x80>
    8590:	00170593          	addi	a1,a4,1
    8594:	4eb61423          	sh	a1,1256(a2)
    8598:	00003637          	lui	a2,0x3
    859c:	81060613          	addi	a2,a2,-2032 # 2810 <golden_fill+0x14>
    85a0:	00c70733          	add	a4,a4,a2
    85a4:	00171713          	slli	a4,a4,0x1
    85a8:	0c087813          	andi	a6,a6,192
    85ac:	f3f6f693          	andi	a3,a3,-193
    85b0:	00e787b3          	add	a5,a5,a4
    85b4:	0106e6b3          	or	a3,a3,a6
    85b8:	00d79623          	sh	a3,12(a5)
    85bc:	00000513          	li	a0,0
    85c0:	00008067          	ret
    85c4:	00008067          	ret

000085c8 <replay_seal>:
    85c8:	02051263          	bnez	a0,85ec <replay_seal+0x24>
    85cc:	ff800513          	li	a0,-8
    85d0:	00008067          	ret
    85d4:	ff800513          	li	a0,-8
    85d8:	00c12083          	lw	ra,12(sp)
    85dc:	00812403          	lw	s0,8(sp)
    85e0:	00412483          	lw	s1,4(sp)
    85e4:	01010113          	addi	sp,sp,16
    85e8:	00008067          	ret
    85ec:	ff010113          	addi	sp,sp,-16
    85f0:	00812423          	sw	s0,8(sp)
    85f4:	00005437          	lui	s0,0x5
    85f8:	00912223          	sw	s1,4(sp)
    85fc:	00112623          	sw	ra,12(sp)
    8600:	00850433          	add	s0,a0,s0
    8604:	4e842783          	lw	a5,1256(s0) # 54e8 <bullet_reset+0x88>
    8608:	25800713          	li	a4,600
    860c:	00050493          	mv	s1,a0
    8610:	00879793          	slli	a5,a5,0x8
    8614:	0087d793          	srli	a5,a5,0x8
    8618:	fae79ee3          	bne	a5,a4,85d4 <replay_seal+0xc>
    861c:	d79ff0ef          	jal	8394 <initial_valid>
    8620:	fa050ae3          	beqz	a0,85d4 <replay_seal+0xc>
    8624:	4e042783          	lw	a5,1248(s0)
    8628:	fa0786e3          	beqz	a5,85d4 <replay_seal+0xc>
    862c:	4dc42703          	lw	a4,1244(s0)
    8630:	00042783          	lw	a5,0(s0)
    8634:	faf710e3          	bne	a4,a5,85d4 <replay_seal+0xc>
    8638:	00048513          	mv	a0,s1
    863c:	b59ff0ef          	jal	8194 <checksum>
    8640:	00100793          	li	a5,1
    8644:	4ea42223          	sw	a0,1252(s0)
    8648:	4ef40523          	sb	a5,1258(s0)
    864c:	00000513          	li	a0,0
    8650:	f89ff06f          	j	85d8 <replay_seal+0x10>

00008654 <replay_seal_step>:
    8654:	02051a63          	bnez	a0,8688 <replay_seal_step+0x34>
    8658:	ff800513          	li	a0,-8
    865c:	00008067          	ret
    8660:	ff800513          	li	a0,-8
    8664:	01c12083          	lw	ra,28(sp)
    8668:	01812403          	lw	s0,24(sp)
    866c:	01412483          	lw	s1,20(sp)
    8670:	01012903          	lw	s2,16(sp)
    8674:	00c12983          	lw	s3,12(sp)
    8678:	00812a03          	lw	s4,8(sp)
    867c:	00412a83          	lw	s5,4(sp)
    8680:	02010113          	addi	sp,sp,32
    8684:	00008067          	ret
    8688:	fe010113          	addi	sp,sp,-32
    868c:	01212823          	sw	s2,16(sp)
    8690:	00112e23          	sw	ra,28(sp)
    8694:	00812c23          	sw	s0,24(sp)
    8698:	00912a23          	sw	s1,20(sp)
    869c:	01312623          	sw	s3,12(sp)
    86a0:	01412423          	sw	s4,8(sp)
    86a4:	01512223          	sw	s5,4(sp)
    86a8:	00058913          	mv	s2,a1
    86ac:	fa058ae3          	beqz	a1,8660 <replay_seal_step+0xc>
    86b0:	fff60793          	addi	a5,a2,-1
    86b4:	0ff00713          	li	a4,255
    86b8:	00060993          	mv	s3,a2
    86bc:	faf762e3          	bltu	a4,a5,8660 <replay_seal_step+0xc>
    86c0:	000057b7          	lui	a5,0x5
    86c4:	00f507b3          	add	a5,a0,a5
    86c8:	4e87a703          	lw	a4,1256(a5) # 54e8 <bullet_reset+0x88>
    86cc:	25800693          	li	a3,600
    86d0:	00050413          	mv	s0,a0
    86d4:	00871713          	slli	a4,a4,0x8
    86d8:	00875713          	srli	a4,a4,0x8
    86dc:	f8d712e3          	bne	a4,a3,8660 <replay_seal_step+0xc>
    86e0:	0087a483          	lw	s1,8(a5)
    86e4:	3ff00713          	li	a4,1023
    86e8:	fff48693          	addi	a3,s1,-1
    86ec:	f6d76ae3          	bltu	a4,a3,8660 <replay_seal_step+0xc>
    86f0:	4e07a703          	lw	a4,1248(a5)
    86f4:	f60706e3          	beqz	a4,8660 <replay_seal_step+0xc>
    86f8:	4dc7a683          	lw	a3,1244(a5)
    86fc:	0007a703          	lw	a4,0(a5)
    8700:	f6e690e3          	bne	a3,a4,8660 <replay_seal_step+0xc>
    8704:	00900713          	li	a4,9
    8708:	02e484b3          	mul	s1,s1,a4
    870c:	4e87d783          	lhu	a5,1256(a5)
    8710:	00f484b3          	add	s1,s1,a5
    8714:	0045a783          	lw	a5,4(a1)
    8718:	01448493          	addi	s1,s1,20
    871c:	f497f2e3          	bgeu	a5,s1,8660 <replay_seal_step+0xc>
    8720:	00079a63          	bnez	a5,8734 <replay_seal_step+0xe0>
    8724:	c71ff0ef          	jal	8394 <initial_valid>
    8728:	f2050ce3          	beqz	a0,8660 <replay_seal_step+0xc>
    872c:	fff00793          	li	a5,-1
    8730:	00f92023          	sw	a5,0(s2)
    8734:	00492783          	lw	a5,4(s2)
    8738:	00048a13          	mv	s4,s1
    873c:	40f48733          	sub	a4,s1,a5
    8740:	01376463          	bltu	a4,s3,8748 <replay_seal_step+0xf4>
    8744:	01378a33          	add	s4,a5,s3
    8748:	0000e9b7          	lui	s3,0xe
    874c:	01300a93          	li	s5,19
    8750:	35498993          	addi	s3,s3,852 # e354 <colors.2+0xc>
    8754:	00492783          	lw	a5,4(s2)
    8758:	0347ee63          	bltu	a5,s4,8794 <replay_seal_step+0x140>
    875c:	00000513          	li	a0,0
    8760:	f097e2e3          	bltu	a5,s1,8664 <replay_seal_step+0x10>
    8764:	00040513          	mv	a0,s0
    8768:	c2dff0ef          	jal	8394 <initial_valid>
    876c:	ee050ae3          	beqz	a0,8660 <replay_seal_step+0xc>
    8770:	000057b7          	lui	a5,0x5
    8774:	00f40433          	add	s0,s0,a5
    8778:	00092783          	lw	a5,0(s2)
    877c:	00100513          	li	a0,1
    8780:	fff7c793          	not	a5,a5
    8784:	4ef42223          	sw	a5,1252(s0)
    8788:	00100793          	li	a5,1
    878c:	4ef40523          	sb	a5,1258(s0)
    8790:	ed5ff06f          	j	8664 <replay_seal_step+0x10>
    8794:	00178713          	addi	a4,a5,1 # 5001 <bullet_enemy_position+0x49>
    8798:	00e92223          	sw	a4,4(s2)
    879c:	14fae663          	bltu	s5,a5,88e8 <replay_seal_step+0x294>
    87a0:	00279793          	slli	a5,a5,0x2
    87a4:	013787b3          	add	a5,a5,s3
    87a8:	0007a783          	lw	a5,0(a5)
    87ac:	00078067          	jr	a5
    87b0:	000057b7          	lui	a5,0x5
    87b4:	00f407b3          	add	a5,s0,a5
    87b8:	4dc7a583          	lw	a1,1244(a5) # 54dc <bullet_reset+0x7c>
    87bc:	00090513          	mv	a0,s2
    87c0:	999ff0ef          	jal	8158 <crc_word>
    87c4:	f91ff06f          	j	8754 <replay_seal_step+0x100>
    87c8:	000057b7          	lui	a5,0x5
    87cc:	00f407b3          	add	a5,s0,a5
    87d0:	4e07a583          	lw	a1,1248(a5) # 54e0 <bullet_reset+0x80>
    87d4:	fe9ff06f          	j	87bc <replay_seal_step+0x168>
    87d8:	000057b7          	lui	a5,0x5
    87dc:	00f407b3          	add	a5,s0,a5
    87e0:	4e87d583          	lhu	a1,1256(a5) # 54e8 <bullet_reset+0x88>
    87e4:	fd9ff06f          	j	87bc <replay_seal_step+0x168>
    87e8:	000057b7          	lui	a5,0x5
    87ec:	00f407b3          	add	a5,s0,a5
    87f0:	0087a583          	lw	a1,8(a5) # 5008 <bullet_enemy_position+0x50>
    87f4:	fc9ff06f          	j	87bc <replay_seal_step+0x168>
    87f8:	000057b7          	lui	a5,0x5
    87fc:	00f407b3          	add	a5,s0,a5
    8800:	0007a583          	lw	a1,0(a5) # 5000 <bullet_enemy_position+0x48>
    8804:	fb9ff06f          	j	87bc <replay_seal_step+0x168>
    8808:	000057b7          	lui	a5,0x5
    880c:	00f407b3          	add	a5,s0,a5
    8810:	0047a583          	lw	a1,4(a5) # 5004 <bullet_enemy_position+0x4c>
    8814:	fa9ff06f          	j	87bc <replay_seal_step+0x168>
    8818:	000057b7          	lui	a5,0x5
    881c:	00f407b3          	add	a5,s0,a5
    8820:	0147a583          	lw	a1,20(a5) # 5014 <bullet_enemy_position+0x5c>
    8824:	f99ff06f          	j	87bc <replay_seal_step+0x168>
    8828:	000057b7          	lui	a5,0x5
    882c:	00f407b3          	add	a5,s0,a5
    8830:	0187a583          	lw	a1,24(a5) # 5018 <bullet_enemy_position+0x60>
    8834:	f89ff06f          	j	87bc <replay_seal_step+0x168>
    8838:	000057b7          	lui	a5,0x5
    883c:	00f407b3          	add	a5,s0,a5
    8840:	01c7a583          	lw	a1,28(a5) # 501c <bullet_enemy_position+0x64>
    8844:	f79ff06f          	j	87bc <replay_seal_step+0x168>
    8848:	000057b7          	lui	a5,0x5
    884c:	00f407b3          	add	a5,s0,a5
    8850:	00c7a583          	lw	a1,12(a5) # 500c <bullet_enemy_position+0x54>
    8854:	f69ff06f          	j	87bc <replay_seal_step+0x168>
    8858:	000057b7          	lui	a5,0x5
    885c:	00f407b3          	add	a5,s0,a5
    8860:	0107a583          	lw	a1,16(a5) # 5010 <bullet_enemy_position+0x58>
    8864:	f59ff06f          	j	87bc <replay_seal_step+0x168>
    8868:	000057b7          	lui	a5,0x5
    886c:	00f407b3          	add	a5,s0,a5
    8870:	0207d583          	lhu	a1,32(a5) # 5020 <bullet_enemy_position+0x68>
    8874:	f49ff06f          	j	87bc <replay_seal_step+0x168>
    8878:	000057b7          	lui	a5,0x5
    887c:	00f407b3          	add	a5,s0,a5
    8880:	0227d583          	lhu	a1,34(a5) # 5022 <bullet_enemy_position+0x6a>
    8884:	f39ff06f          	j	87bc <replay_seal_step+0x168>
    8888:	000057b7          	lui	a5,0x5
    888c:	00f407b3          	add	a5,s0,a5
    8890:	0247c583          	lbu	a1,36(a5) # 5024 <bullet_enemy_position+0x6c>
    8894:	f29ff06f          	j	87bc <replay_seal_step+0x168>
    8898:	000057b7          	lui	a5,0x5
    889c:	00f407b3          	add	a5,s0,a5
    88a0:	0287c583          	lbu	a1,40(a5) # 5028 <bullet_enemy_position+0x70>
    88a4:	f19ff06f          	j	87bc <replay_seal_step+0x168>
    88a8:	000057b7          	lui	a5,0x5
    88ac:	00f407b3          	add	a5,s0,a5
    88b0:	0297c583          	lbu	a1,41(a5) # 5029 <bullet_enemy_position+0x71>
    88b4:	f09ff06f          	j	87bc <replay_seal_step+0x168>
    88b8:	000057b7          	lui	a5,0x5
    88bc:	00f407b3          	add	a5,s0,a5
    88c0:	0257c583          	lbu	a1,37(a5) # 5025 <bullet_enemy_position+0x6d>
    88c4:	ef9ff06f          	j	87bc <replay_seal_step+0x168>
    88c8:	000057b7          	lui	a5,0x5
    88cc:	00f407b3          	add	a5,s0,a5
    88d0:	0267c583          	lbu	a1,38(a5) # 5026 <bullet_enemy_position+0x6e>
    88d4:	ee9ff06f          	j	87bc <replay_seal_step+0x168>
    88d8:	000057b7          	lui	a5,0x5
    88dc:	00f407b3          	add	a5,s0,a5
    88e0:	0277c583          	lbu	a1,39(a5) # 5027 <bullet_enemy_position+0x6f>
    88e4:	ed9ff06f          	j	87bc <replay_seal_step+0x168>
    88e8:	00005737          	lui	a4,0x5
    88ec:	00e40733          	add	a4,s0,a4
    88f0:	00872703          	lw	a4,8(a4) # 5008 <bullet_enemy_position+0x50>
    88f4:	00900693          	li	a3,9
    88f8:	fec78793          	addi	a5,a5,-20
    88fc:	02e68733          	mul	a4,a3,a4
    8900:	02e7e263          	bltu	a5,a4,8924 <replay_seal_step+0x2d0>
    8904:	40e787b3          	sub	a5,a5,a4
    8908:	00003737          	lui	a4,0x3
    890c:	81070713          	addi	a4,a4,-2032 # 2810 <golden_fill+0x14>
    8910:	00e787b3          	add	a5,a5,a4
    8914:	00179793          	slli	a5,a5,0x1
    8918:	00f407b3          	add	a5,s0,a5
    891c:	00c7d583          	lhu	a1,12(a5)
    8920:	e9dff06f          	j	87bc <replay_seal_step+0x168>
    8924:	02d7d733          	divu	a4,a5,a3
    8928:	01400613          	li	a2,20
    892c:	02d7f7b3          	remu	a5,a5,a3
    8930:	00700693          	li	a3,7
    8934:	02c70733          	mul	a4,a4,a2
    8938:	00e40733          	add	a4,s0,a4
    893c:	04f6ee63          	bltu	a3,a5,8998 <replay_seal_step+0x344>
    8940:	0000e6b7          	lui	a3,0xe
    8944:	00279793          	slli	a5,a5,0x2
    8948:	3a468693          	addi	a3,a3,932 # e3a4 <colors.2+0x5c>
    894c:	00d787b3          	add	a5,a5,a3
    8950:	0007a783          	lw	a5,0(a5)
    8954:	00078067          	jr	a5
    8958:	00072583          	lw	a1,0(a4)
    895c:	e61ff06f          	j	87bc <replay_seal_step+0x168>
    8960:	00472583          	lw	a1,4(a4)
    8964:	e59ff06f          	j	87bc <replay_seal_step+0x168>
    8968:	00871583          	lh	a1,8(a4)
    896c:	e51ff06f          	j	87bc <replay_seal_step+0x168>
    8970:	00a71583          	lh	a1,10(a4)
    8974:	e49ff06f          	j	87bc <replay_seal_step+0x168>
    8978:	00c75583          	lhu	a1,12(a4)
    897c:	e41ff06f          	j	87bc <replay_seal_step+0x168>
    8980:	00e74583          	lbu	a1,14(a4)
    8984:	e39ff06f          	j	87bc <replay_seal_step+0x168>
    8988:	00f74583          	lbu	a1,15(a4)
    898c:	e31ff06f          	j	87bc <replay_seal_step+0x168>
    8990:	01074583          	lbu	a1,16(a4)
    8994:	e29ff06f          	j	87bc <replay_seal_step+0x168>
    8998:	01174583          	lbu	a1,17(a4)
    899c:	e21ff06f          	j	87bc <replay_seal_step+0x168>
    89a0:	00200593          	li	a1,2
    89a4:	e19ff06f          	j	87bc <replay_seal_step+0x168>

000089a8 <replay_begin>:
    89a8:	02051663          	bnez	a0,89d4 <replay_begin+0x2c>
    89ac:	ff800513          	li	a0,-8
    89b0:	00008067          	ret
    89b4:	ff800513          	li	a0,-8
    89b8:	01c12083          	lw	ra,28(sp)
    89bc:	01812403          	lw	s0,24(sp)
    89c0:	01412483          	lw	s1,20(sp)
    89c4:	01012903          	lw	s2,16(sp)
    89c8:	00c12983          	lw	s3,12(sp)
    89cc:	02010113          	addi	sp,sp,32
    89d0:	00008067          	ret
    89d4:	fe010113          	addi	sp,sp,-32
    89d8:	01312623          	sw	s3,12(sp)
    89dc:	00112e23          	sw	ra,28(sp)
    89e0:	00812c23          	sw	s0,24(sp)
    89e4:	00912a23          	sw	s1,20(sp)
    89e8:	01212823          	sw	s2,16(sp)
    89ec:	00060993          	mv	s3,a2
    89f0:	fc0602e3          	beqz	a2,89b4 <replay_begin+0xc>
    89f4:	00068493          	mv	s1,a3
    89f8:	fa068ee3          	beqz	a3,89b4 <replay_begin+0xc>
    89fc:	00005437          	lui	s0,0x5
    8a00:	00850433          	add	s0,a0,s0
    8a04:	4ea44783          	lbu	a5,1258(s0) # 54ea <bullet_reset+0x8a>
    8a08:	00050913          	mv	s2,a0
    8a0c:	fa0784e3          	beqz	a5,89b4 <replay_begin+0xc>
    8a10:	4e845703          	lhu	a4,1256(s0)
    8a14:	25800793          	li	a5,600
    8a18:	f8f71ee3          	bne	a4,a5,89b4 <replay_begin+0xc>
    8a1c:	4e042783          	lw	a5,1248(s0)
    8a20:	f8b79ae3          	bne	a5,a1,89b4 <replay_begin+0xc>
    8a24:	f80788e3          	beqz	a5,89b4 <replay_begin+0xc>
    8a28:	96dff0ef          	jal	8394 <initial_valid>
    8a2c:	f80504e3          	beqz	a0,89b4 <replay_begin+0xc>
    8a30:	4dc42703          	lw	a4,1244(s0)
    8a34:	00042783          	lw	a5,0(s0)
    8a38:	f6f71ee3          	bne	a4,a5,89b4 <replay_begin+0xc>
    8a3c:	4e442403          	lw	s0,1252(s0)
    8a40:	00090513          	mv	a0,s2
    8a44:	f50ff0ef          	jal	8194 <checksum>
    8a48:	f6a416e3          	bne	s0,a0,89b4 <replay_begin+0xc>
    8a4c:	00005637          	lui	a2,0x5
    8a50:	02c60613          	addi	a2,a2,44 # 502c <bullet_enemy_position+0x74>
    8a54:	00090593          	mv	a1,s2
    8a58:	00098513          	mv	a0,s3
    8a5c:	8a9f80ef          	jal	1304 <memcpy>
    8a60:	00100793          	li	a5,1
    8a64:	00049223          	sh	zero,4(s1)
    8a68:	00049023          	sh	zero,0(s1)
    8a6c:	00049123          	sh	zero,2(s1)
    8a70:	00f48223          	sb	a5,4(s1)
    8a74:	00000513          	li	a0,0
    8a78:	f41ff06f          	j	89b8 <replay_begin+0x10>

00008a7c <replay_next>:
    8a7c:	10050c63          	beqz	a0,8b94 <replay_next+0x118>
    8a80:	fe010113          	addi	sp,sp,-32
    8a84:	00812c23          	sw	s0,24(sp)
    8a88:	00112e23          	sw	ra,28(sp)
    8a8c:	00912a23          	sw	s1,20(sp)
    8a90:	01212823          	sw	s2,16(sp)
    8a94:	01312623          	sw	s3,12(sp)
    8a98:	01412423          	sw	s4,8(sp)
    8a9c:	00050713          	mv	a4,a0
    8aa0:	00058413          	mv	s0,a1
    8aa4:	ff800513          	li	a0,-8
    8aa8:	04058863          	beqz	a1,8af8 <replay_next+0x7c>
    8aac:	00060793          	mv	a5,a2
    8ab0:	04060463          	beqz	a2,8af8 <replay_next+0x7c>
    8ab4:	000056b7          	lui	a3,0x5
    8ab8:	00d706b3          	add	a3,a4,a3
    8abc:	4ea6c603          	lbu	a2,1258(a3) # 54ea <bullet_reset+0x8a>
    8ac0:	02060c63          	beqz	a2,8af8 <replay_next+0x7c>
    8ac4:	4e86d683          	lhu	a3,1256(a3)
    8ac8:	25800613          	li	a2,600
    8acc:	02c69663          	bne	a3,a2,8af8 <replay_next+0x7c>
    8ad0:	0045c603          	lbu	a2,4(a1)
    8ad4:	02060263          	beqz	a2,8af8 <replay_next+0x7c>
    8ad8:	0005d483          	lhu	s1,0(a1)
    8adc:	0096ee63          	bltu	a3,s1,8af8 <replay_next+0x7c>
    8ae0:	02d49c63          	bne	s1,a3,8b18 <replay_next+0x9c>
    8ae4:	01800613          	li	a2,24
    8ae8:	00000593          	li	a1,0
    8aec:	00078513          	mv	a0,a5
    8af0:	f38f80ef          	jal	1228 <memset>
    8af4:	00000513          	li	a0,0
    8af8:	01c12083          	lw	ra,28(sp)
    8afc:	01812403          	lw	s0,24(sp)
    8b00:	01412483          	lw	s1,20(sp)
    8b04:	01012903          	lw	s2,16(sp)
    8b08:	00c12983          	lw	s3,12(sp)
    8b0c:	00812a03          	lw	s4,8(sp)
    8b10:	02010113          	addi	sp,sp,32
    8b14:	00008067          	ret
    8b18:	000036b7          	lui	a3,0x3
    8b1c:	81068693          	addi	a3,a3,-2032 # 2810 <golden_fill+0x14>
    8b20:	00d486b3          	add	a3,s1,a3
    8b24:	00169693          	slli	a3,a3,0x1
    8b28:	00d70733          	add	a4,a4,a3
    8b2c:	00c75903          	lhu	s2,12(a4)
    8b30:	0ff00713          	li	a4,255
    8b34:	ff800513          	li	a0,-8
    8b38:	fd2760e3          	bltu	a4,s2,8af8 <replay_next+0x7c>
    8b3c:	0025d983          	lhu	s3,2(a1)
    8b40:	01800613          	li	a2,24
    8b44:	00000593          	li	a1,0
    8b48:	00078513          	mv	a0,a5
    8b4c:	edcf80ef          	jal	1228 <memset>
    8b50:	01091a13          	slli	s4,s2,0x10
    8b54:	410a5a13          	srai	s4,s4,0x10
    8b58:	fff9c713          	not	a4,s3
    8b5c:	00ea7733          	and	a4,s4,a4
    8b60:	f3f77713          	andi	a4,a4,-193
    8b64:	0c097693          	andi	a3,s2,192
    8b68:	fffa4a13          	not	s4,s4
    8b6c:	00d76733          	or	a4,a4,a3
    8b70:	0149f9b3          	and	s3,s3,s4
    8b74:	01251023          	sh	s2,0(a0)
    8b78:	00e51123          	sh	a4,2(a0)
    8b7c:	01351223          	sh	s3,4(a0)
    8b80:	00148493          	addi	s1,s1,1
    8b84:	01241123          	sh	s2,2(s0)
    8b88:	00941023          	sh	s1,0(s0)
    8b8c:	00100513          	li	a0,1
    8b90:	f69ff06f          	j	8af8 <replay_next+0x7c>
    8b94:	ff800513          	li	a0,-8
    8b98:	00008067          	ret

00008b9c <enter_menu>:
    8b9c:	0000f7b7          	lui	a5,0xf
    8ba0:	00f50533          	add	a0,a0,a5
    8ba4:	00100793          	li	a5,1
    8ba8:	56f50c23          	sb	a5,1400(a0)
    8bac:	57c52783          	lw	a5,1404(a0)
    8bb0:	56b50b23          	sb	a1,1398(a0)
    8bb4:	56052823          	sw	zero,1392(a0)
    8bb8:	00178793          	addi	a5,a5,1 # f001 <__global_pointer$+0x281>
    8bbc:	56050a23          	sb	zero,1396(a0)
    8bc0:	54052223          	sw	zero,1348(a0)
    8bc4:	54051423          	sh	zero,1352(a0)
    8bc8:	54052c23          	sw	zero,1368(a0)
    8bcc:	54052e23          	sw	zero,1372(a0)
    8bd0:	56052023          	sw	zero,1376(a0)
    8bd4:	56052223          	sw	zero,1380(a0)
    8bd8:	56052423          	sw	zero,1384(a0)
    8bdc:	56f52e23          	sw	a5,1404(a0)
    8be0:	54052623          	sw	zero,1356(a0)
    8be4:	54052823          	sw	zero,1360(a0)
    8be8:	00008067          	ret

00008bec <begin_compare>:
    8bec:	ff010113          	addi	sp,sp,-16
    8bf0:	00912223          	sw	s1,4(sp)
    8bf4:	00050493          	mv	s1,a0
    8bf8:	00005537          	lui	a0,0x5
    8bfc:	02c50513          	addi	a0,a0,44 # 502c <bullet_enemy_position+0x74>
    8c00:	00812423          	sw	s0,8(sp)
    8c04:	00050613          	mv	a2,a0
    8c08:	00048593          	mv	a1,s1
    8c0c:	00a48533          	add	a0,s1,a0
    8c10:	0000f437          	lui	s0,0xf
    8c14:	00112623          	sw	ra,12(sp)
    8c18:	00848433          	add	s0,s1,s0
    8c1c:	ee8f80ef          	jal	1304 <memcpy>
    8c20:	0000f6b7          	lui	a3,0xf
    8c24:	0000a537          	lui	a0,0xa
    8c28:	56c42583          	lw	a1,1388(s0) # f56c <__global_pointer$+0x7ec>
    8c2c:	54468693          	addi	a3,a3,1348 # f544 <__global_pointer$+0x7c4>
    8c30:	05850513          	addi	a0,a0,88 # a058 <v3_demo_run+0x598>
    8c34:	00d486b3          	add	a3,s1,a3
    8c38:	00048613          	mv	a2,s1
    8c3c:	00a48533          	add	a0,s1,a0
    8c40:	d69ff0ef          	jal	89a8 <replay_begin>
    8c44:	02051263          	bnez	a0,8c68 <begin_compare+0x7c>
    8c48:	00100793          	li	a5,1
    8c4c:	56f40923          	sb	a5,1394(s0)
    8c50:	56041823          	sh	zero,1392(s0)
    8c54:	54042c23          	sw	zero,1368(s0)
    8c58:	54042e23          	sw	zero,1372(s0)
    8c5c:	56042023          	sw	zero,1376(s0)
    8c60:	56042223          	sw	zero,1380(s0)
    8c64:	56042423          	sw	zero,1384(s0)
    8c68:	00c12083          	lw	ra,12(sp)
    8c6c:	00812403          	lw	s0,8(sp)
    8c70:	00412483          	lw	s1,4(sp)
    8c74:	01010113          	addi	sp,sp,16
    8c78:	00008067          	ret

00008c7c <v3_runtime_status>:
    8c7c:	0000f837          	lui	a6,0xf
    8c80:	01050833          	add	a6,a0,a6
    8c84:	57784303          	lbu	t1,1399(a6) # f577 <__global_pointer$+0x7f7>
    8c88:	57484883          	lbu	a7,1396(a6)
    8c8c:	00000e93          	li	t4,0
    8c90:	00030463          	beqz	t1,8c98 <v3_runtime_status+0x1c>
    8c94:	0018be93          	seqz	t4,a7
    8c98:	0000f837          	lui	a6,0xf
    8c9c:	01050533          	add	a0,a0,a6
    8ca0:	57254803          	lbu	a6,1394(a0)
    8ca4:	57954503          	lbu	a0,1401(a0)
    8ca8:	ffe88893          	addi	a7,a7,-2
    8cac:	00603333          	snez	t1,t1
    8cb0:	01003e33          	snez	t3,a6
    8cb4:	00a03533          	snez	a0,a0
    8cb8:	0018b893          	seqz	a7,a7
    8cbc:	00b31f93          	slli	t6,t1,0xb
    8cc0:	001e0e13          	addi	t3,t3,1
    8cc4:	00e31313          	slli	t1,t1,0xe
    8cc8:	00c51513          	slli	a0,a0,0xc
    8ccc:	00d89893          	slli	a7,a7,0xd
    8cd0:	00000f13          	li	t5,0
    8cd4:	000e8463          	beqz	t4,8cdc <v3_runtime_status+0x60>
    8cd8:	50000f13          	li	t5,1280
    8cdc:	0015b593          	seqz	a1,a1
    8ce0:	00c03633          	snez	a2,a2
    8ce4:	00100393          	li	t2,1
    8ce8:	00359593          	slli	a1,a1,0x3
    8cec:	00461613          	slli	a2,a2,0x4
    8cf0:	02000293          	li	t0,32
    8cf4:	00781663          	bne	a6,t2,8d00 <v3_runtime_status+0x84>
    8cf8:	0017b793          	seqz	a5,a5
    8cfc:	00579293          	slli	t0,a5,0x5
    8d00:	00000393          	li	t2,0
    8d04:	00068a63          	beqz	a3,8d18 <v3_runtime_status+0x9c>
    8d08:	000e9863          	bnez	t4,8d18 <v3_runtime_status+0x9c>
    8d0c:	fff80813          	addi	a6,a6,-1 # efff <__global_pointer$+0x27f>
    8d10:	01003833          	snez	a6,a6
    8d14:	01081393          	slli	t2,a6,0x10
    8d18:	00e037b3          	snez	a5,a4
    8d1c:	01179793          	slli	a5,a5,0x11
    8d20:	0077e7b3          	or	a5,a5,t2
    8d24:	00c7e7b3          	or	a5,a5,a2
    8d28:	00b7e7b3          	or	a5,a5,a1
    8d2c:	01f7e7b3          	or	a5,a5,t6
    8d30:	0067e7b3          	or	a5,a5,t1
    8d34:	00a7e7b3          	or	a5,a5,a0
    8d38:	0117e7b3          	or	a5,a5,a7
    8d3c:	01c7e7b3          	or	a5,a5,t3
    8d40:	01e7e7b3          	or	a5,a5,t5
    8d44:	00700537          	lui	a0,0x700
    8d48:	0057e7b3          	or	a5,a5,t0
    8d4c:	08050513          	addi	a0,a0,128 # 700080 <__freertos_irq_stack_top+0x6e25e0>
    8d50:	00a7e533          	or	a0,a5,a0
    8d54:	00008067          	ret

00008d58 <v3_runtime_init>:
    8d58:	0a050663          	beqz	a0,8e04 <v3_runtime_init+0xac>
    8d5c:	fe010113          	addi	sp,sp,-32
    8d60:	00912a23          	sw	s1,20(sp)
    8d64:	00112e23          	sw	ra,28(sp)
    8d68:	00812c23          	sw	s0,24(sp)
    8d6c:	01212823          	sw	s2,16(sp)
    8d70:	01312623          	sw	s3,12(sp)
    8d74:	01412423          	sw	s4,8(sp)
    8d78:	01512223          	sw	s5,4(sp)
    8d7c:	00068493          	mv	s1,a3
    8d80:	08068663          	beqz	a3,8e0c <v3_runtime_init+0xb4>
    8d84:	00060a13          	mv	s4,a2
    8d88:	0000f637          	lui	a2,0xf
    8d8c:	00050413          	mv	s0,a0
    8d90:	00058993          	mv	s3,a1
    8d94:	58860613          	addi	a2,a2,1416 # f588 <__global_pointer$+0x808>
    8d98:	00000593          	li	a1,0
    8d9c:	0000f937          	lui	s2,0xf
    8da0:	c88f80ef          	jal	1228 <memset>
    8da4:	01240933          	add	s2,s0,s2
    8da8:	00100a93          	li	s5,1
    8dac:	56992623          	sw	s1,1388(s2) # f56c <__global_pointer$+0x7ec>
    8db0:	57590a23          	sb	s5,1396(s2)
    8db4:	000a0613          	mv	a2,s4
    8db8:	00098593          	mv	a1,s3
    8dbc:	00040513          	mv	a0,s0
    8dc0:	92cff0ef          	jal	7eec <game_reset>
    8dc4:	04051663          	bnez	a0,8e10 <v3_runtime_init+0xb8>
    8dc8:	0000a537          	lui	a0,0xa
    8dcc:	57590d23          	sb	s5,1402(s2)
    8dd0:	05850513          	addi	a0,a0,88 # a058 <v3_demo_run+0x598>
    8dd4:	00040593          	mv	a1,s0
    8dd8:	00a40533          	add	a0,s0,a0
    8ddc:	01812403          	lw	s0,24(sp)
    8de0:	01c12083          	lw	ra,28(sp)
    8de4:	01012903          	lw	s2,16(sp)
    8de8:	00c12983          	lw	s3,12(sp)
    8dec:	00812a03          	lw	s4,8(sp)
    8df0:	00412a83          	lw	s5,4(sp)
    8df4:	00048613          	mv	a2,s1
    8df8:	01412483          	lw	s1,20(sp)
    8dfc:	02010113          	addi	sp,sp,32
    8e00:	e98ff06f          	j	8498 <replay_init>
    8e04:	ff800513          	li	a0,-8
    8e08:	00008067          	ret
    8e0c:	ff800513          	li	a0,-8
    8e10:	01c12083          	lw	ra,28(sp)
    8e14:	01812403          	lw	s0,24(sp)
    8e18:	01412483          	lw	s1,20(sp)
    8e1c:	01012903          	lw	s2,16(sp)
    8e20:	00c12983          	lw	s3,12(sp)
    8e24:	00812a03          	lw	s4,8(sp)
    8e28:	00412a83          	lw	s5,4(sp)
    8e2c:	02010113          	addi	sp,sp,32
    8e30:	00008067          	ret

00008e34 <v3_level_count>:
    8e34:	fff50513          	addi	a0,a0,-1
    8e38:	00500793          	li	a5,5
    8e3c:	02a7e063          	bltu	a5,a0,8e5c <v3_level_count+0x28>
    8e40:	0000e7b7          	lui	a5,0xe
    8e44:	00251513          	slli	a0,a0,0x2
    8e48:	40478793          	addi	a5,a5,1028 # e404 <counts.0>
    8e4c:	00a787b3          	add	a5,a5,a0
    8e50:	0007a503          	lw	a0,0(a5)
    8e54:	40000793          	li	a5,1024
    8e58:	00a7f463          	bgeu	a5,a0,8e60 <v3_level_count+0x2c>
    8e5c:	00000513          	li	a0,0
    8e60:	00008067          	ret

00008e64 <restart_game>:
    8e64:	fe010113          	addi	sp,sp,-32
    8e68:	00812c23          	sw	s0,24(sp)
    8e6c:	0000f437          	lui	s0,0xf
    8e70:	00912a23          	sw	s1,20(sp)
    8e74:	01212823          	sw	s2,16(sp)
    8e78:	01312623          	sw	s3,12(sp)
    8e7c:	00112e23          	sw	ra,28(sp)
    8e80:	00850433          	add	s0,a0,s0
    8e84:	00050493          	mv	s1,a0
    8e88:	57544503          	lbu	a0,1397(s0) # f575 <__global_pointer$+0x7f5>
    8e8c:	00058993          	mv	s3,a1
    8e90:	00060913          	mv	s2,a2
    8e94:	fa1ff0ef          	jal	8e34 <v3_level_count>
    8e98:	00050593          	mv	a1,a0
    8e9c:	00700613          	li	a2,7
    8ea0:	00048513          	mv	a0,s1
    8ea4:	848ff0ef          	jal	7eec <game_reset>
    8ea8:	06051663          	bnez	a0,8f14 <restart_game+0xb0>
    8eac:	0000a537          	lui	a0,0xa
    8eb0:	56c42603          	lw	a2,1388(s0)
    8eb4:	05850513          	addi	a0,a0,88 # a058 <v3_demo_run+0x598>
    8eb8:	00048593          	mv	a1,s1
    8ebc:	00a48533          	add	a0,s1,a0
    8ec0:	dd8ff0ef          	jal	8498 <replay_init>
    8ec4:	04051863          	bnez	a0,8f14 <restart_game+0xb0>
    8ec8:	00100793          	li	a5,1
    8ecc:	56f40d23          	sb	a5,1402(s0)
    8ed0:	56f40a23          	sb	a5,1396(s0)
    8ed4:	56f40c23          	sb	a5,1400(s0)
    8ed8:	57c42783          	lw	a5,1404(s0)
    8edc:	54042623          	sw	zero,1356(s0)
    8ee0:	54042823          	sw	zero,1360(s0)
    8ee4:	00178793          	addi	a5,a5,1
    8ee8:	54042c23          	sw	zero,1368(s0)
    8eec:	54042e23          	sw	zero,1372(s0)
    8ef0:	56042023          	sw	zero,1376(s0)
    8ef4:	56042223          	sw	zero,1380(s0)
    8ef8:	56042423          	sw	zero,1384(s0)
    8efc:	54042223          	sw	zero,1348(s0)
    8f00:	54041423          	sh	zero,1352(s0)
    8f04:	56042823          	sw	zero,1392(s0)
    8f08:	59342023          	sw	s3,1408(s0)
    8f0c:	59242223          	sw	s2,1412(s0)
    8f10:	56f42e23          	sw	a5,1404(s0)
    8f14:	01c12083          	lw	ra,28(sp)
    8f18:	01812403          	lw	s0,24(sp)
    8f1c:	01412483          	lw	s1,20(sp)
    8f20:	01012903          	lw	s2,16(sp)
    8f24:	00c12983          	lw	s3,12(sp)
    8f28:	02010113          	addi	sp,sp,32
    8f2c:	00008067          	ret

00008f30 <v3_runtime_game_command>:
    8f30:	12050e63          	beqz	a0,906c <v3_runtime_game_command+0x13c>
    8f34:	fd010113          	addi	sp,sp,-48
    8f38:	0000f7b7          	lui	a5,0xf
    8f3c:	02812423          	sw	s0,40(sp)
    8f40:	02912223          	sw	s1,36(sp)
    8f44:	02112623          	sw	ra,44(sp)
    8f48:	03212023          	sw	s2,32(sp)
    8f4c:	01312e23          	sw	s3,28(sp)
    8f50:	00f507b3          	add	a5,a0,a5
    8f54:	00060413          	mv	s0,a2
    8f58:	00070613          	mv	a2,a4
    8f5c:	5777c703          	lbu	a4,1399(a5) # f577 <__global_pointer$+0x7f7>
    8f60:	00050493          	mv	s1,a0
    8f64:	08070263          	beqz	a4,8fe8 <v3_runtime_game_command+0xb8>
    8f68:	00068993          	mv	s3,a3
    8f6c:	06068e63          	beqz	a3,8fe8 <v3_runtime_game_command+0xb8>
    8f70:	00100713          	li	a4,1
    8f74:	00058913          	mv	s2,a1
    8f78:	02e59663          	bne	a1,a4,8fa4 <v3_runtime_game_command+0x74>
    8f7c:	fff40793          	addi	a5,s0,-1
    8f80:	00500713          	li	a4,5
    8f84:	06f76263          	bltu	a4,a5,8fe8 <v3_runtime_game_command+0xb8>
    8f88:	00040513          	mv	a0,s0
    8f8c:	00c12623          	sw	a2,12(sp)
    8f90:	ea5ff0ef          	jal	8e34 <v3_level_count>
    8f94:	00c12603          	lw	a2,12(sp)
    8f98:	06051063          	bnez	a0,8ff8 <v3_runtime_game_command+0xc8>
    8f9c:	00100793          	li	a5,1
    8fa0:	01c0006f          	j	8fbc <v3_runtime_game_command+0x8c>
    8fa4:	00200713          	li	a4,2
    8fa8:	02e59a63          	bne	a1,a4,8fdc <v3_runtime_game_command+0xac>
    8fac:	ff800793          	li	a5,-8
    8fb0:	00041663          	bnez	s0,8fbc <v3_runtime_game_command+0x8c>
    8fb4:	be9ff0ef          	jal	8b9c <enter_menu>
    8fb8:	00000793          	li	a5,0
    8fbc:	02c12083          	lw	ra,44(sp)
    8fc0:	02812403          	lw	s0,40(sp)
    8fc4:	02412483          	lw	s1,36(sp)
    8fc8:	02012903          	lw	s2,32(sp)
    8fcc:	01c12983          	lw	s3,28(sp)
    8fd0:	00078513          	mv	a0,a5
    8fd4:	03010113          	addi	sp,sp,48
    8fd8:	00008067          	ret
    8fdc:	00300713          	li	a4,3
    8fe0:	00e59463          	bne	a1,a4,8fe8 <v3_runtime_game_command+0xb8>
    8fe4:	00040663          	beqz	s0,8ff0 <v3_runtime_game_command+0xc0>
    8fe8:	ff800793          	li	a5,-8
    8fec:	fd1ff06f          	j	8fbc <v3_runtime_game_command+0x8c>
    8ff0:	5797c783          	lbu	a5,1401(a5)
    8ff4:	fa0784e3          	beqz	a5,8f9c <v3_runtime_game_command+0x6c>
    8ff8:	0000f7b7          	lui	a5,0xf
    8ffc:	00f487b3          	add	a5,s1,a5
    9000:	5747c703          	lbu	a4,1396(a5) # f574 <__global_pointer$+0x7f4>
    9004:	f8071ce3          	bnez	a4,8f9c <v3_runtime_game_command+0x6c>
    9008:	00300713          	li	a4,3
    900c:	02e91c63          	bne	s2,a4,9044 <v3_runtime_game_command+0x114>
    9010:	00200713          	li	a4,2
    9014:	56e78a23          	sb	a4,1396(a5)
    9018:	57c7a703          	lw	a4,1404(a5)
    901c:	56079923          	sh	zero,1394(a5)
    9020:	5937a023          	sw	s3,1408(a5)
    9024:	00170713          	addi	a4,a4,1
    9028:	5407ac23          	sw	zero,1368(a5)
    902c:	5407ae23          	sw	zero,1372(a5)
    9030:	5607a023          	sw	zero,1376(a5)
    9034:	5607a223          	sw	zero,1380(a5)
    9038:	5607a423          	sw	zero,1384(a5)
    903c:	56e7ae23          	sw	a4,1404(a5)
    9040:	f79ff06f          	j	8fb8 <v3_runtime_game_command+0x88>
    9044:	56878aa3          	sb	s0,1397(a5)
    9048:	02812403          	lw	s0,40(sp)
    904c:	02c12083          	lw	ra,44(sp)
    9050:	02012903          	lw	s2,32(sp)
    9054:	00098593          	mv	a1,s3
    9058:	00048513          	mv	a0,s1
    905c:	01c12983          	lw	s3,28(sp)
    9060:	02412483          	lw	s1,36(sp)
    9064:	03010113          	addi	sp,sp,48
    9068:	dfdff06f          	j	8e64 <restart_game>
    906c:	ff800793          	li	a5,-8
    9070:	00078513          	mv	a0,a5
    9074:	00008067          	ret

00009078 <v3_runtime_advance>:
    9078:	f9010113          	addi	sp,sp,-112
    907c:	06112623          	sw	ra,108(sp)
    9080:	06812423          	sw	s0,104(sp)
    9084:	06912223          	sw	s1,100(sp)
    9088:	07212023          	sw	s2,96(sp)
    908c:	05312e23          	sw	s3,92(sp)
    9090:	05412c23          	sw	s4,88(sp)
    9094:	05512a23          	sw	s5,84(sp)
    9098:	05612823          	sw	s6,80(sp)
    909c:	05712623          	sw	s7,76(sp)
    90a0:	48050c63          	beqz	a0,9538 <v3_runtime_advance+0x4c0>
    90a4:	48058a63          	beqz	a1,9538 <v3_runtime_advance+0x4c0>
    90a8:	0000f7b7          	lui	a5,0xf
    90ac:	00f507b3          	add	a5,a0,a5
    90b0:	5547d683          	lhu	a3,1364(a5) # f554 <__global_pointer$+0x7d4>
    90b4:	10000713          	li	a4,256
    90b8:	00050493          	mv	s1,a0
    90bc:	46d76e63          	bltu	a4,a3,9538 <v3_runtime_advance+0x4c0>
    90c0:	5777c903          	lbu	s2,1399(a5)
    90c4:	00060413          	mv	s0,a2
    90c8:	5747c783          	lbu	a5,1396(a5)
    90cc:	00090463          	beqz	s2,90d4 <v3_runtime_advance+0x5c>
    90d0:	02078663          	beqz	a5,90fc <v3_runtime_advance+0x84>
    90d4:	00200713          	li	a4,2
    90d8:	02e79663          	bne	a5,a4,9104 <v3_runtime_advance+0x8c>
    90dc:	0025d783          	lhu	a5,2(a1)
    90e0:	0407f793          	andi	a5,a5,64
    90e4:	00078c63          	beqz	a5,90fc <v3_runtime_advance+0x84>
    90e8:	0000f7b7          	lui	a5,0xf
    90ec:	00f487b3          	add	a5,s1,a5
    90f0:	57c7a703          	lw	a4,1404(a5) # f57c <__global_pointer$+0x7fc>
    90f4:	00170713          	addi	a4,a4,1
    90f8:	56e7ae23          	sw	a4,1404(a5)
    90fc:	00000413          	li	s0,0
    9100:	0540006f          	j	9154 <v3_runtime_advance+0xdc>
    9104:	0000f7b7          	lui	a5,0xf
    9108:	00f487b3          	add	a5,s1,a5
    910c:	5727c983          	lbu	s3,1394(a5) # f572 <__global_pointer$+0x7f2>
    9110:	06098a63          	beqz	s3,9184 <v3_runtime_advance+0x10c>
    9114:	0000f5b7          	lui	a1,0xf
    9118:	0000a537          	lui	a0,0xa
    911c:	54458593          	addi	a1,a1,1348 # f544 <__global_pointer$+0x7c4>
    9120:	05850513          	addi	a0,a0,88 # a058 <v3_demo_run+0x598>
    9124:	02810613          	addi	a2,sp,40
    9128:	00b485b3          	add	a1,s1,a1
    912c:	00a48533          	add	a0,s1,a0
    9130:	94dff0ef          	jal	8a7c <replay_next>
    9134:	00100793          	li	a5,1
    9138:	00050413          	mv	s0,a0
    913c:	3ef51e63          	bne	a0,a5,9538 <v3_runtime_advance+0x4c0>
    9140:	02810593          	addi	a1,sp,40
    9144:	00048513          	mv	a0,s1
    9148:	804ff0ef          	jal	814c <game_update>
    914c:	00055463          	bgez	a0,9154 <v3_runtime_advance+0xdc>
    9150:	00050413          	mv	s0,a0
    9154:	06c12083          	lw	ra,108(sp)
    9158:	00040513          	mv	a0,s0
    915c:	06812403          	lw	s0,104(sp)
    9160:	06412483          	lw	s1,100(sp)
    9164:	06012903          	lw	s2,96(sp)
    9168:	05c12983          	lw	s3,92(sp)
    916c:	05812a03          	lw	s4,88(sp)
    9170:	05412a83          	lw	s5,84(sp)
    9174:	05012b03          	lw	s6,80(sp)
    9178:	04c12b83          	lw	s7,76(sp)
    917c:	07010113          	addi	sp,sp,112
    9180:	00008067          	ret
    9184:	02090263          	beqz	s2,91a8 <v3_runtime_advance+0x130>
    9188:	000057b7          	lui	a5,0x5
    918c:	00f487b3          	add	a5,s1,a5
    9190:	0247c783          	lbu	a5,36(a5) # 5024 <bullet_enemy_position+0x6c>
    9194:	00079a63          	bnez	a5,91a8 <v3_runtime_advance+0x130>
    9198:	00100593          	li	a1,1
    919c:	00048513          	mv	a0,s1
    91a0:	9fdff0ef          	jal	8b9c <enter_menu>
    91a4:	f59ff06f          	j	90fc <v3_runtime_advance+0x84>
    91a8:	01800613          	li	a2,24
    91ac:	01010513          	addi	a0,sp,16
    91b0:	00b12623          	sw	a1,12(sp)
    91b4:	950f80ef          	jal	1304 <memcpy>
    91b8:	00c12583          	lw	a1,12(sp)
    91bc:	04090c63          	beqz	s2,9214 <v3_runtime_advance+0x19c>
    91c0:	0000f7b7          	lui	a5,0xf
    91c4:	00f487b3          	add	a5,s1,a5
    91c8:	5787c703          	lbu	a4,1400(a5) # f578 <__global_pointer$+0x7f8>
    91cc:	0a070263          	beqz	a4,9270 <v3_runtime_advance+0x1f8>
    91d0:	0145c703          	lbu	a4,20(a1)
    91d4:	02070a63          	beqz	a4,9208 <v3_runtime_advance+0x190>
    91d8:	0165c703          	lbu	a4,22(a1)
    91dc:	02070663          	beqz	a4,9208 <v3_runtime_advance+0x190>
    91e0:	5847a683          	lw	a3,1412(a5)
    91e4:	0085a603          	lw	a2,8(a1)
    91e8:	5807a783          	lw	a5,1408(a5)
    91ec:	00c5a703          	lw	a4,12(a1)
    91f0:	00f61663          	bne	a2,a5,91fc <v3_runtime_advance+0x184>
    91f4:	40d70733          	sub	a4,a4,a3
    91f8:	00e05863          	blez	a4,9208 <v3_runtime_advance+0x190>
    91fc:	0000f7b7          	lui	a5,0xf
    9200:	00f487b3          	add	a5,s1,a5
    9204:	56078c23          	sb	zero,1400(a5) # f578 <__global_pointer$+0x7f8>
    9208:	00012823          	sw	zero,16(sp)
    920c:	00011a23          	sh	zero,20(sp)
    9210:	01010593          	addi	a1,sp,16
    9214:	0025d783          	lhu	a5,2(a1)
    9218:	0807f713          	andi	a4,a5,128
    921c:	08070c63          	beqz	a4,92b4 <v3_runtime_advance+0x23c>
    9220:	0000f737          	lui	a4,0xf
    9224:	00e48733          	add	a4,s1,a4
    9228:	00100693          	li	a3,1
    922c:	56d709a3          	sb	a3,1395(a4) # f573 <__global_pointer$+0x7f3>
    9230:	0000f737          	lui	a4,0xf
    9234:	00e48733          	add	a4,s1,a4
    9238:	54274703          	lbu	a4,1346(a4) # f542 <__global_pointer$+0x7c2>
    923c:	08070463          	beqz	a4,92c4 <v3_runtime_advance+0x24c>
    9240:	06812403          	lw	s0,104(sp)
    9244:	06c12083          	lw	ra,108(sp)
    9248:	06012903          	lw	s2,96(sp)
    924c:	05c12983          	lw	s3,92(sp)
    9250:	05812a03          	lw	s4,88(sp)
    9254:	05412a83          	lw	s5,84(sp)
    9258:	05012b03          	lw	s6,80(sp)
    925c:	04c12b83          	lw	s7,76(sp)
    9260:	00048513          	mv	a0,s1
    9264:	06412483          	lw	s1,100(sp)
    9268:	07010113          	addi	sp,sp,112
    926c:	981ff06f          	j	8bec <begin_compare>
    9270:	0025d783          	lhu	a5,2(a1)
    9274:	0407f793          	andi	a5,a5,64
    9278:	f8078ee3          	beqz	a5,9214 <v3_runtime_advance+0x19c>
    927c:	06812403          	lw	s0,104(sp)
    9280:	00c5a603          	lw	a2,12(a1)
    9284:	06c12083          	lw	ra,108(sp)
    9288:	06012903          	lw	s2,96(sp)
    928c:	05c12983          	lw	s3,92(sp)
    9290:	05812a03          	lw	s4,88(sp)
    9294:	05412a83          	lw	s5,84(sp)
    9298:	05012b03          	lw	s6,80(sp)
    929c:	04c12b83          	lw	s7,76(sp)
    92a0:	0085a583          	lw	a1,8(a1)
    92a4:	00048513          	mv	a0,s1
    92a8:	06412483          	lw	s1,100(sp)
    92ac:	07010113          	addi	sp,sp,112
    92b0:	bb5ff06f          	j	8e64 <restart_game>
    92b4:	0000f737          	lui	a4,0xf
    92b8:	00e48733          	add	a4,s1,a4
    92bc:	57374703          	lbu	a4,1395(a4) # f573 <__global_pointer$+0x7f3>
    92c0:	f60718e3          	bnez	a4,9230 <v3_runtime_advance+0x1b8>
    92c4:	0003d737          	lui	a4,0x3d
    92c8:	09070713          	addi	a4,a4,144 # 3d090 <__freertos_irq_stack_top+0x1f5f0>
    92cc:	00877663          	bgeu	a4,s0,92d8 <v3_runtime_advance+0x260>
    92d0:	00100993          	li	s3,1
    92d4:	00070413          	mv	s0,a4
    92d8:	03c00713          	li	a4,60
    92dc:	02e40433          	mul	s0,s0,a4
    92e0:	0000f937          	lui	s2,0xf
    92e4:	01248933          	add	s2,s1,s2
    92e8:	55892703          	lw	a4,1368(s2) # f558 <__global_pointer$+0x7d8>
    92ec:	57390423          	sb	s3,1384(s2)
    92f0:	56695983          	lhu	s3,1382(s2)
    92f4:	0000aa37          	lui	s4,0xa
    92f8:	0000aab7          	lui	s5,0xa
    92fc:	01800613          	li	a2,24
    9300:	02810513          	addi	a0,sp,40
    9304:	00870733          	add	a4,a4,s0
    9308:	54e92c23          	sw	a4,1368(s2)
    930c:	56495703          	lhu	a4,1380(s2)
    9310:	000f4b37          	lui	s6,0xf4
    9314:	058a0a13          	addi	s4,s4,88 # a058 <v3_demo_run+0x598>
    9318:	00e7e433          	or	s0,a5,a4
    931c:	0045d783          	lhu	a5,4(a1)
    9320:	56891223          	sh	s0,1380(s2)
    9324:	00005bb7          	lui	s7,0x5
    9328:	00f9e9b3          	or	s3,s3,a5
    932c:	57391323          	sh	s3,1382(s2)
    9330:	01548ab3          	add	s5,s1,s5
    9334:	fd1f70ef          	jal	1304 <memcpy>
    9338:	23fb0b13          	addi	s6,s6,575 # f423f <__freertos_irq_stack_top+0xd679f>
    933c:	03311623          	sh	s3,44(sp)
    9340:	02811523          	sh	s0,42(sp)
    9344:	00000993          	li	s3,0
    9348:	01448a33          	add	s4,s1,s4
    934c:	017a8ab3          	add	s5,s5,s7
    9350:	55892783          	lw	a5,1368(s2)
    9354:	0efb7263          	bgeu	s6,a5,9438 <v3_runtime_advance+0x3c0>
    9358:	00400793          	li	a5,4
    935c:	0cf98e63          	beq	s3,a5,9438 <v3_runtime_advance+0x3c0>
    9360:	54294783          	lbu	a5,1346(s2)
    9364:	08078063          	beqz	a5,93e4 <v3_runtime_advance+0x36c>
    9368:	57a94783          	lbu	a5,1402(s2)
    936c:	000a0613          	mv	a2,s4
    9370:	00079463          	bnez	a5,9378 <v3_runtime_advance+0x300>
    9374:	00000613          	li	a2,0
    9378:	02810593          	addi	a1,sp,40
    937c:	00048513          	mv	a0,s1
    9380:	badfe0ef          	jal	7f2c <game_update_cached>
    9384:	00050413          	mv	s0,a0
    9388:	dc0546e3          	bltz	a0,9154 <v3_runtime_advance+0xdc>
    938c:	55892783          	lw	a5,1368(s2)
    9390:	fff0c737          	lui	a4,0xfff0c
    9394:	dc070713          	addi	a4,a4,-576 # fff0bdc0 <__gpu_framebuffer_a+0xfdf0bdc0>
    9398:	00e787b3          	add	a5,a5,a4
    939c:	54f92c23          	sw	a5,1368(s2)
    93a0:	55c92783          	lw	a5,1372(s2)
    93a4:	56092223          	sw	zero,1380(s2)
    93a8:	02011623          	sh	zero,44(sp)
    93ac:	00178793          	addi	a5,a5,1
    93b0:	54f92e23          	sw	a5,1372(s2)
    93b4:	57794783          	lbu	a5,1399(s2)
    93b8:	02011523          	sh	zero,42(sp)
    93bc:	00198993          	addi	s3,s3,1
    93c0:	04078863          	beqz	a5,9410 <v3_runtime_advance+0x398>
    93c4:	017487b3          	add	a5,s1,s7
    93c8:	0247c783          	lbu	a5,36(a5)
    93cc:	04079263          	bnez	a5,9410 <v3_runtime_advance+0x398>
    93d0:	00100593          	li	a1,1
    93d4:	00048513          	mv	a0,s1
    93d8:	fc4ff0ef          	jal	8b9c <enter_menu>
    93dc:	00098413          	mv	s0,s3
    93e0:	d75ff06f          	j	9154 <v3_runtime_advance+0xdc>
    93e4:	54095703          	lhu	a4,1344(s2)
    93e8:	25700793          	li	a5,599
    93ec:	f6e7eee3          	bltu	a5,a4,9368 <v3_runtime_advance+0x2f0>
    93f0:	0000a537          	lui	a0,0xa
    93f4:	05850513          	addi	a0,a0,88 # a058 <v3_demo_run+0x598>
    93f8:	02810593          	addi	a1,sp,40
    93fc:	00a48533          	add	a0,s1,a0
    9400:	944ff0ef          	jal	8544 <replay_record>
    9404:	00050413          	mv	s0,a0
    9408:	f60500e3          	beqz	a0,9368 <v3_runtime_advance+0x2f0>
    940c:	d49ff06f          	j	9154 <v3_runtime_advance+0xdc>
    9410:	55495783          	lhu	a5,1364(s2)
    9414:	08078e63          	beqz	a5,94b0 <v3_runtime_advance+0x438>
    9418:	57394783          	lbu	a5,1395(s2)
    941c:	f2078ae3          	beqz	a5,9350 <v3_runtime_advance+0x2d8>
    9420:	54294783          	lbu	a5,1346(s2)
    9424:	f20786e3          	beqz	a5,9350 <v3_runtime_advance+0x2d8>
    9428:	00048513          	mv	a0,s1
    942c:	fc0ff0ef          	jal	8bec <begin_compare>
    9430:	00050413          	mv	s0,a0
    9434:	d20510e3          	bnez	a0,9154 <v3_runtime_advance+0xdc>
    9438:	0000f937          	lui	s2,0xf
    943c:	01248933          	add	s2,s1,s2
    9440:	55495603          	lhu	a2,1364(s2) # f554 <__global_pointer$+0x7d4>
    9444:	08061e63          	bnez	a2,94e0 <v3_runtime_advance+0x468>
    9448:	0000f737          	lui	a4,0xf
    944c:	00e48733          	add	a4,s1,a4
    9450:	55872783          	lw	a5,1368(a4) # f558 <__global_pointer$+0x7d8>
    9454:	000f46b7          	lui	a3,0xf4
    9458:	23f68693          	addi	a3,a3,575 # f423f <__freertos_irq_stack_top+0xd679f>
    945c:	f8f6f0e3          	bgeu	a3,a5,93dc <v3_runtime_advance+0x364>
    9460:	00100693          	li	a3,1
    9464:	56d70423          	sb	a3,1384(a4)
    9468:	003d16b7          	lui	a3,0x3d1
    946c:	90068693          	addi	a3,a3,-1792 # 3d0900 <__freertos_irq_stack_top+0x3b2e60>
    9470:	f6f6f6e3          	bgeu	a3,a5,93dc <v3_runtime_advance+0x364>
    9474:	40d787b3          	sub	a5,a5,a3
    9478:	03c00693          	li	a3,60
    947c:	02d7d7b3          	divu	a5,a5,a3
    9480:	56072683          	lw	a3,1376(a4)
    9484:	fff00713          	li	a4,-1
    9488:	00f687b3          	add	a5,a3,a5
    948c:	00d7e463          	bltu	a5,a3,9494 <v3_runtime_advance+0x41c>
    9490:	00078713          	mv	a4,a5
    9494:	0000f7b7          	lui	a5,0xf
    9498:	00f484b3          	add	s1,s1,a5
    949c:	003d17b7          	lui	a5,0x3d1
    94a0:	90078793          	addi	a5,a5,-1792 # 3d0900 <__freertos_irq_stack_top+0x3b2e60>
    94a4:	56e4a023          	sw	a4,1376(s1)
    94a8:	54f4ac23          	sw	a5,1368(s1)
    94ac:	f31ff06f          	j	93dc <v3_runtime_advance+0x364>
    94b0:	540aa783          	lw	a5,1344(s5) # a540 <v3_demo_run+0xa80>
    94b4:	25800713          	li	a4,600
    94b8:	00879793          	slli	a5,a5,0x8
    94bc:	0087d793          	srli	a5,a5,0x8
    94c0:	f4e79ce3          	bne	a5,a4,9418 <v3_runtime_advance+0x3a0>
    94c4:	0000a537          	lui	a0,0xa
    94c8:	05850513          	addi	a0,a0,88 # a058 <v3_demo_run+0x598>
    94cc:	00a48533          	add	a0,s1,a0
    94d0:	8f8ff0ef          	jal	85c8 <replay_seal>
    94d4:	00050413          	mv	s0,a0
    94d8:	f40500e3          	beqz	a0,9418 <v3_runtime_advance+0x3a0>
    94dc:	c79ff06f          	j	9154 <v3_runtime_advance+0xdc>
    94e0:	54092783          	lw	a5,1344(s2)
    94e4:	25800713          	li	a4,600
    94e8:	00879793          	slli	a5,a5,0x8
    94ec:	0087d793          	srli	a5,a5,0x8
    94f0:	f4e79ce3          	bne	a5,a4,9448 <v3_runtime_advance+0x3d0>
    94f4:	0000f5b7          	lui	a1,0xf
    94f8:	0000a537          	lui	a0,0xa
    94fc:	54c58593          	addi	a1,a1,1356 # f54c <__global_pointer$+0x7cc>
    9500:	05850513          	addi	a0,a0,88 # a058 <v3_demo_run+0x598>
    9504:	00b485b3          	add	a1,s1,a1
    9508:	00a48533          	add	a0,s1,a0
    950c:	948ff0ef          	jal	8654 <replay_seal_step>
    9510:	00050413          	mv	s0,a0
    9514:	c40540e3          	bltz	a0,9154 <v3_runtime_advance+0xdc>
    9518:	f20508e3          	beqz	a0,9448 <v3_runtime_advance+0x3d0>
    951c:	57394783          	lbu	a5,1395(s2)
    9520:	f20784e3          	beqz	a5,9448 <v3_runtime_advance+0x3d0>
    9524:	00048513          	mv	a0,s1
    9528:	ec4ff0ef          	jal	8bec <begin_compare>
    952c:	00050413          	mv	s0,a0
    9530:	f0050ce3          	beqz	a0,9448 <v3_runtime_advance+0x3d0>
    9534:	c21ff06f          	j	9154 <v3_runtime_advance+0xdc>
    9538:	ff800413          	li	s0,-8
    953c:	c19ff06f          	j	9154 <v3_runtime_advance+0xdc>

00009540 <v3_runtime_frame_done>:
    9540:	10050663          	beqz	a0,964c <v3_runtime_frame_done+0x10c>
    9544:	ff010113          	addi	sp,sp,-16
    9548:	00812423          	sw	s0,8(sp)
    954c:	0000f437          	lui	s0,0xf
    9550:	00912223          	sw	s1,4(sp)
    9554:	00112623          	sw	ra,12(sp)
    9558:	01212023          	sw	s2,0(sp)
    955c:	00850433          	add	s0,a0,s0
    9560:	57244703          	lbu	a4,1394(s0) # f572 <__global_pointer$+0x7f2>
    9564:	00050493          	mv	s1,a0
    9568:	02071063          	bnez	a4,9588 <v3_runtime_frame_done+0x48>
    956c:	00000513          	li	a0,0
    9570:	00c12083          	lw	ra,12(sp)
    9574:	00812403          	lw	s0,8(sp)
    9578:	00412483          	lw	s1,4(sp)
    957c:	00012903          	lw	s2,0(sp)
    9580:	01010113          	addi	sp,sp,16
    9584:	00008067          	ret
    9588:	57045783          	lhu	a5,1392(s0)
    958c:	25700693          	li	a3,599
    9590:	00178793          	addi	a5,a5,1
    9594:	01079793          	slli	a5,a5,0x10
    9598:	0107d793          	srli	a5,a5,0x10
    959c:	56f41823          	sh	a5,1392(s0)
    95a0:	fcf6f6e3          	bgeu	a3,a5,956c <v3_runtime_frame_done+0x2c>
    95a4:	00100793          	li	a5,1
    95a8:	56c42903          	lw	s2,1388(s0)
    95ac:	02f71e63          	bne	a4,a5,95e8 <v3_runtime_frame_done+0xa8>
    95b0:	0000f6b7          	lui	a3,0xf
    95b4:	0000a537          	lui	a0,0xa
    95b8:	54468693          	addi	a3,a3,1348 # f544 <__global_pointer$+0x7c4>
    95bc:	05850513          	addi	a0,a0,88 # a058 <v3_demo_run+0x598>
    95c0:	00d486b3          	add	a3,s1,a3
    95c4:	00048613          	mv	a2,s1
    95c8:	00090593          	mv	a1,s2
    95cc:	00a48533          	add	a0,s1,a0
    95d0:	bd8ff0ef          	jal	89a8 <replay_begin>
    95d4:	f8051ee3          	bnez	a0,9570 <v3_runtime_frame_done+0x30>
    95d8:	00200793          	li	a5,2
    95dc:	56f40923          	sb	a5,1394(s0)
    95e0:	56041823          	sh	zero,1392(s0)
    95e4:	f8dff06f          	j	9570 <v3_runtime_frame_done+0x30>
    95e8:	000055b7          	lui	a1,0x5
    95ec:	02c58593          	addi	a1,a1,44 # 502c <bullet_enemy_position+0x74>
    95f0:	00058613          	mv	a2,a1
    95f4:	00b505b3          	add	a1,a0,a1
    95f8:	d0df70ef          	jal	1304 <memcpy>
    95fc:	0000a537          	lui	a0,0xa
    9600:	56042823          	sw	zero,1392(s0)
    9604:	56040d23          	sb	zero,1402(s0)
    9608:	54042c23          	sw	zero,1368(s0)
    960c:	54042e23          	sw	zero,1372(s0)
    9610:	56042023          	sw	zero,1376(s0)
    9614:	56042223          	sw	zero,1380(s0)
    9618:	56042423          	sw	zero,1384(s0)
    961c:	54042623          	sw	zero,1356(s0)
    9620:	54042823          	sw	zero,1360(s0)
    9624:	05850513          	addi	a0,a0,88 # a058 <v3_demo_run+0x598>
    9628:	00812403          	lw	s0,8(sp)
    962c:	00c12083          	lw	ra,12(sp)
    9630:	00090613          	mv	a2,s2
    9634:	00048593          	mv	a1,s1
    9638:	00012903          	lw	s2,0(sp)
    963c:	00a48533          	add	a0,s1,a0
    9640:	00412483          	lw	s1,4(sp)
    9644:	01010113          	addi	sp,sp,16
    9648:	e51fe06f          	j	8498 <replay_init>
    964c:	ff800513          	li	a0,-8
    9650:	00008067          	ret

00009654 <now_ms>:
    9654:	ff010113          	addi	sp,sp,-16
    9658:	00112623          	sw	ra,12(sp)
    965c:	9ccf80ef          	jal	1828 <gpu_platform_cycles>
    9660:	00018637          	lui	a2,0x18
    9664:	6a060613          	addi	a2,a2,1696 # 186a0 <scene+0x4fc8>
    9668:	00000693          	li	a3,0
    966c:	320030ef          	jal	c98c <__udivdi3>
    9670:	00c12083          	lw	ra,12(sp)
    9674:	01010113          	addi	sp,sp,16
    9678:	00008067          	ret

0000967c <_putchar>:
    967c:	f80107b7          	lui	a5,0xf8010
    9680:	00478793          	addi	a5,a5,4 # f8010004 <__gpu_framebuffer_a+0xf6010004>
    9684:	0007a703          	lw	a4,0(a5)
    9688:	01075693          	srli	a3,a4,0x10
    968c:	0ff6f693          	zext.b	a3,a3
    9690:	fe068ae3          	beqz	a3,9684 <_putchar+0x8>
    9694:	f80107b7          	lui	a5,0xf8010
    9698:	00a7a023          	sw	a0,0(a5) # f8010000 <__gpu_framebuffer_a+0xf6010000>
    969c:	00008067          	ret

000096a0 <bsp_printf>:
    96a0:	f8010113          	addi	sp,sp,-128
    96a4:	06f12a23          	sw	a5,116(sp)
    96a8:	06410793          	addi	a5,sp,100
    96ac:	05212823          	sw	s2,80(sp)
    96b0:	05312623          	sw	s3,76(sp)
    96b4:	05412423          	sw	s4,72(sp)
    96b8:	05512223          	sw	s5,68(sp)
    96bc:	05612023          	sw	s6,64(sp)
    96c0:	03712e23          	sw	s7,60(sp)
    96c4:	04112e23          	sw	ra,92(sp)
    96c8:	04812c23          	sw	s0,88(sp)
    96cc:	04912a23          	sw	s1,84(sp)
    96d0:	03812c23          	sw	s8,56(sp)
    96d4:	03912a23          	sw	s9,52(sp)
    96d8:	00050993          	mv	s3,a0
    96dc:	06b12223          	sw	a1,100(sp)
    96e0:	06c12423          	sw	a2,104(sp)
    96e4:	06d12623          	sw	a3,108(sp)
    96e8:	06e12823          	sw	a4,112(sp)
    96ec:	07012c23          	sw	a6,120(sp)
    96f0:	07112e23          	sw	a7,124(sp)
    96f4:	00f12623          	sw	a5,12(sp)
    96f8:	00000913          	li	s2,0
    96fc:	02500a13          	li	s4,37
    9700:	06600a93          	li	s5,102
    9704:	06600b13          	li	s6,102
    9708:	06300b93          	li	s7,99
    970c:	012987b3          	add	a5,s3,s2
    9710:	0007c503          	lbu	a0,0(a5)
    9714:	02051c63          	bnez	a0,974c <bsp_printf+0xac>
    9718:	05c12083          	lw	ra,92(sp)
    971c:	05812403          	lw	s0,88(sp)
    9720:	05412483          	lw	s1,84(sp)
    9724:	05012903          	lw	s2,80(sp)
    9728:	04c12983          	lw	s3,76(sp)
    972c:	04812a03          	lw	s4,72(sp)
    9730:	04412a83          	lw	s5,68(sp)
    9734:	04012b03          	lw	s6,64(sp)
    9738:	03c12b83          	lw	s7,60(sp)
    973c:	03812c03          	lw	s8,56(sp)
    9740:	03412c83          	lw	s9,52(sp)
    9744:	08010113          	addi	sp,sp,128
    9748:	00008067          	ret
    974c:	0d451863          	bne	a0,s4,981c <bsp_printf+0x17c>
    9750:	00190913          	addi	s2,s2,1
    9754:	012987b3          	add	a5,s3,s2
    9758:	0007c783          	lbu	a5,0(a5)
    975c:	0e078063          	beqz	a5,983c <bsp_printf+0x19c>
    9760:	17578263          	beq	a5,s5,98c4 <bsp_printf+0x224>
    9764:	04fb6c63          	bltu	s6,a5,97bc <bsp_printf+0x11c>
    9768:	0b778263          	beq	a5,s7,980c <bsp_printf+0x16c>
    976c:	06400713          	li	a4,100
    9770:	0ee78063          	beq	a5,a4,9850 <bsp_printf+0x1b0>
    9774:	05800713          	li	a4,88
    9778:	fce79ce3          	bne	a5,a4,9750 <bsp_printf+0xb0>
    977c:	00c12783          	lw	a5,12(sp)
    9780:	0000d4b7          	lui	s1,0xd
    9784:	01c00413          	li	s0,28
    9788:	0007ac83          	lw	s9,0(a5)
    978c:	00478713          	addi	a4,a5,4
    9790:	00e12623          	sw	a4,12(sp)
    9794:	2f848493          	addi	s1,s1,760 # d2f8 <_data+0x4c>
    9798:	ffc00c13          	li	s8,-4
    979c:	008cd7b3          	srl	a5,s9,s0
    97a0:	00f7f793          	andi	a5,a5,15
    97a4:	00f487b3          	add	a5,s1,a5
    97a8:	0007c503          	lbu	a0,0(a5)
    97ac:	ffc40413          	addi	s0,s0,-4
    97b0:	ecdff0ef          	jal	967c <_putchar>
    97b4:	ff8414e3          	bne	s0,s8,979c <bsp_printf+0xfc>
    97b8:	0840006f          	j	983c <bsp_printf+0x19c>
    97bc:	07300713          	li	a4,115
    97c0:	06e78263          	beq	a5,a4,9824 <bsp_printf+0x184>
    97c4:	07800713          	li	a4,120
    97c8:	f8e794e3          	bne	a5,a4,9750 <bsp_printf+0xb0>
    97cc:	00c12783          	lw	a5,12(sp)
    97d0:	0000d4b7          	lui	s1,0xd
    97d4:	01c00413          	li	s0,28
    97d8:	0007ac83          	lw	s9,0(a5)
    97dc:	00478713          	addi	a4,a5,4
    97e0:	00e12623          	sw	a4,12(sp)
    97e4:	30c48493          	addi	s1,s1,780 # d30c <_data+0x60>
    97e8:	ffc00c13          	li	s8,-4
    97ec:	008cd7b3          	srl	a5,s9,s0
    97f0:	00f7f793          	andi	a5,a5,15
    97f4:	00f487b3          	add	a5,s1,a5
    97f8:	0007c503          	lbu	a0,0(a5)
    97fc:	ffc40413          	addi	s0,s0,-4
    9800:	e7dff0ef          	jal	967c <_putchar>
    9804:	ff8414e3          	bne	s0,s8,97ec <bsp_printf+0x14c>
    9808:	0340006f          	j	983c <bsp_printf+0x19c>
    980c:	00c12783          	lw	a5,12(sp)
    9810:	0007c503          	lbu	a0,0(a5)
    9814:	00478713          	addi	a4,a5,4
    9818:	00e12623          	sw	a4,12(sp)
    981c:	e61ff0ef          	jal	967c <_putchar>
    9820:	01c0006f          	j	983c <bsp_printf+0x19c>
    9824:	00c12783          	lw	a5,12(sp)
    9828:	0007a403          	lw	s0,0(a5)
    982c:	00478713          	addi	a4,a5,4
    9830:	00e12623          	sw	a4,12(sp)
    9834:	00044503          	lbu	a0,0(s0)
    9838:	00051663          	bnez	a0,9844 <bsp_printf+0x1a4>
    983c:	00190913          	addi	s2,s2,1
    9840:	ecdff06f          	j	970c <bsp_printf+0x6c>
    9844:	00140413          	addi	s0,s0,1
    9848:	e35ff0ef          	jal	967c <_putchar>
    984c:	fe9ff06f          	j	9834 <bsp_printf+0x194>
    9850:	00c12783          	lw	a5,12(sp)
    9854:	0007a483          	lw	s1,0(a5)
    9858:	00478713          	addi	a4,a5,4
    985c:	00e12623          	sw	a4,12(sp)
    9860:	0004d863          	bgez	s1,9870 <bsp_printf+0x1d0>
    9864:	02d00513          	li	a0,45
    9868:	e15ff0ef          	jal	967c <_putchar>
    986c:	409004b3          	neg	s1,s1
    9870:	01010413          	addi	s0,sp,16
    9874:	00040c13          	mv	s8,s0
    9878:	00a00713          	li	a4,10
    987c:	00049e63          	bnez	s1,9898 <bsp_printf+0x1f8>
    9880:	01840c63          	beq	s0,s8,9898 <bsp_printf+0x1f8>
    9884:	fff44503          	lbu	a0,-1(s0)
    9888:	fff40413          	addi	s0,s0,-1
    988c:	df1ff0ef          	jal	967c <_putchar>
    9890:	ff841ae3          	bne	s0,s8,9884 <bsp_printf+0x1e4>
    9894:	fa9ff06f          	j	983c <bsp_printf+0x19c>
    9898:	02e4e7b3          	rem	a5,s1,a4
    989c:	00140413          	addi	s0,s0,1
    98a0:	03078793          	addi	a5,a5,48
    98a4:	02e4c4b3          	div	s1,s1,a4
    98a8:	fef40fa3          	sb	a5,-1(s0)
    98ac:	fd1ff06f          	j	987c <bsp_printf+0x1dc>
    98b0:	00140413          	addi	s0,s0,1
    98b4:	dc9ff0ef          	jal	967c <_putchar>
    98b8:	00044503          	lbu	a0,0(s0)
    98bc:	fe051ae3          	bnez	a0,98b0 <bsp_printf+0x210>
    98c0:	f7dff06f          	j	983c <bsp_printf+0x19c>
    98c4:	0000d437          	lui	s0,0xd
    98c8:	2ac40413          	addi	s0,s0,684 # d2ac <_data>
    98cc:	fedff06f          	j	98b8 <bsp_printf+0x218>

000098d0 <v3_build_gpu_scene>:
    98d0:	10050263          	beqz	a0,99d4 <v3_build_gpu_scene+0x104>
    98d4:	fc010113          	addi	sp,sp,-64
    98d8:	02812c23          	sw	s0,56(sp)
    98dc:	02112e23          	sw	ra,60(sp)
    98e0:	02912a23          	sw	s1,52(sp)
    98e4:	03212823          	sw	s2,48(sp)
    98e8:	00078413          	mv	s0,a5
    98ec:	0e078863          	beqz	a5,99dc <v3_build_gpu_scene+0x10c>
    98f0:	00080493          	mv	s1,a6
    98f4:	0e080463          	beqz	a6,99dc <v3_build_gpu_scene+0x10c>
    98f8:	00100913          	li	s2,1
    98fc:	0ed96063          	bltu	s2,a3,99dc <v3_build_gpu_scene+0x10c>
    9900:	00082023          	sw	zero,0(a6)
    9904:	00050313          	mv	t1,a0
    9908:	00058e13          	mv	t3,a1
    990c:	00060e93          	mv	t4,a2
    9910:	08068263          	beqz	a3,9994 <v3_build_gpu_scene+0xc4>
    9914:	000057b7          	lui	a5,0x5
    9918:	00f507b3          	add	a5,a0,a5
    991c:	0297c783          	lbu	a5,41(a5) # 5029 <bullet_enemy_position+0x71>
    9920:	06079a63          	bnez	a5,9994 <v3_build_gpu_scene+0xc4>
    9924:	01c10793          	addi	a5,sp,28
    9928:	00070893          	mv	a7,a4
    992c:	00f12023          	sw	a5,0(sp)
    9930:	00100713          	li	a4,1
    9934:	04800793          	li	a5,72
    9938:	48900813          	li	a6,1161
    993c:	00100693          	li	a3,1
    9940:	6bc020ef          	jal	bffc <gpu_instances_build_into>
    9944:	00009737          	lui	a4,0x9
    9948:	00e407b3          	add	a5,s0,a4
    994c:	01c12703          	lw	a4,28(sp)
    9950:	12e7a023          	sw	a4,288(a5)
    9954:	02012703          	lw	a4,32(sp)
    9958:	12e7a223          	sw	a4,292(a5)
    995c:	02812703          	lw	a4,40(sp)
    9960:	12e7a423          	sw	a4,296(a5)
    9964:	02412703          	lw	a4,36(sp)
    9968:	12e7a623          	sw	a4,300(a5)
    996c:	02c12703          	lw	a4,44(sp)
    9970:	12e7a823          	sw	a4,304(a5)
    9974:	00051463          	bnez	a0,997c <v3_build_gpu_scene+0xac>
    9978:	0124a023          	sw	s2,0(s1)
    997c:	03c12083          	lw	ra,60(sp)
    9980:	03812403          	lw	s0,56(sp)
    9984:	03412483          	lw	s1,52(sp)
    9988:	03012903          	lw	s2,48(sp)
    998c:	04010113          	addi	sp,sp,64
    9990:	00008067          	ret
    9994:	00040793          	mv	a5,s0
    9998:	48900713          	li	a4,1161
    999c:	00100693          	li	a3,1
    99a0:	000e8613          	mv	a2,t4
    99a4:	000e0593          	mv	a1,t3
    99a8:	00030513          	mv	a0,t1
    99ac:	fa8fe0ef          	jal	8154 <game_build>
    99b0:	fc0516e3          	bnez	a0,997c <v3_build_gpu_scene+0xac>
    99b4:	00040513          	mv	a0,s0
    99b8:	03812403          	lw	s0,56(sp)
    99bc:	03c12083          	lw	ra,60(sp)
    99c0:	03412483          	lw	s1,52(sp)
    99c4:	03012903          	lw	s2,48(sp)
    99c8:	04800593          	li	a1,72
    99cc:	04010113          	addi	sp,sp,64
    99d0:	d4dfc06f          	j	671c <bullet_clip_background_for_hud>
    99d4:	ff800513          	li	a0,-8
    99d8:	00008067          	ret
    99dc:	ff800513          	li	a0,-8
    99e0:	f9dff06f          	j	997c <v3_build_gpu_scene+0xac>

000099e4 <v3_apply_game_command>:
    99e4:	02051463          	bnez	a0,9a0c <v3_apply_game_command+0x28>
    99e8:	ff800513          	li	a0,-8
    99ec:	00008067          	ret
    99f0:	ff800513          	li	a0,-8
    99f4:	02c12083          	lw	ra,44(sp)
    99f8:	02812403          	lw	s0,40(sp)
    99fc:	02412483          	lw	s1,36(sp)
    9a00:	02012903          	lw	s2,32(sp)
    9a04:	03010113          	addi	sp,sp,48
    9a08:	00008067          	ret
    9a0c:	fd010113          	addi	sp,sp,-48
    9a10:	02812423          	sw	s0,40(sp)
    9a14:	02112623          	sw	ra,44(sp)
    9a18:	02912223          	sw	s1,36(sp)
    9a1c:	03212023          	sw	s2,32(sp)
    9a20:	00060413          	mv	s0,a2
    9a24:	fc0606e3          	beqz	a2,99f0 <v3_apply_game_command+0xc>
    9a28:	00058493          	mv	s1,a1
    9a2c:	00050913          	mv	s2,a0
    9a30:	00c10593          	addi	a1,sp,12
    9a34:	00048513          	mv	a0,s1
    9a38:	cd5fd0ef          	jal	770c <nc_take_game>
    9a3c:	00100793          	li	a5,1
    9a40:	faf518e3          	bne	a0,a5,99f0 <v3_apply_game_command+0xc>
    9a44:	0164c783          	lbu	a5,22(s1)
    9a48:	fa0784e3          	beqz	a5,99f0 <v3_apply_game_command+0xc>
    9a4c:	00042683          	lw	a3,0(s0)
    9a50:	0044a783          	lw	a5,4(s1)
    9a54:	f8f69ee3          	bne	a3,a5,99f0 <v3_apply_game_command+0xc>
    9a58:	00c12783          	lw	a5,12(sp)
    9a5c:	f8f69ae3          	bne	a3,a5,99f0 <v3_apply_game_command+0xc>
    9a60:	01042703          	lw	a4,16(s0)
    9a64:	01c12783          	lw	a5,28(sp)
    9a68:	f8f714e3          	bne	a4,a5,99f0 <v3_apply_game_command+0xc>
    9a6c:	00842583          	lw	a1,8(s0)
    9a70:	01412783          	lw	a5,20(sp)
    9a74:	f6f59ee3          	bne	a1,a5,99f0 <v3_apply_game_command+0xc>
    9a78:	00c42603          	lw	a2,12(s0)
    9a7c:	01812783          	lw	a5,24(sp)
    9a80:	f6f618e3          	bne	a2,a5,99f0 <v3_apply_game_command+0xc>
    9a84:	00442703          	lw	a4,4(s0)
    9a88:	00090513          	mv	a0,s2
    9a8c:	ca4ff0ef          	jal	8f30 <v3_runtime_game_command>
    9a90:	00050913          	mv	s2,a0
    9a94:	00200613          	li	a2,2
    9a98:	00054463          	bltz	a0,9aa0 <v3_apply_game_command+0xbc>
    9a9c:	00a03633          	snez	a2,a0
    9aa0:	00040593          	mv	a1,s0
    9aa4:	00048513          	mv	a0,s1
    9aa8:	cd5fd0ef          	jal	777c <nc_complete_game>
    9aac:	f40544e3          	bltz	a0,99f4 <v3_apply_game_command+0x10>
    9ab0:	00090513          	mv	a0,s2
    9ab4:	f52050e3          	blez	s2,99f4 <v3_apply_game_command+0x10>
    9ab8:	00000513          	li	a0,0
    9abc:	f39ff06f          	j	99f4 <v3_apply_game_command+0x10>

00009ac0 <v3_demo_run>:
    9ac0:	a8010113          	addi	sp,sp,-1408
    9ac4:	55a12823          	sw	s10,1360(sp)
    9ac8:	02a12a23          	sw	a0,52(sp)
    9acc:	02c12e23          	sw	a2,60(sp)
    9ad0:	00058d13          	mv	s10,a1
    9ad4:	01800613          	li	a2,24
    9ad8:	00000593          	li	a1,0
    9adc:	18c10513          	addi	a0,sp,396
    9ae0:	56812c23          	sw	s0,1400(sp)
    9ae4:	56112e23          	sw	ra,1404(sp)
    9ae8:	56912a23          	sw	s1,1396(sp)
    9aec:	57212823          	sw	s2,1392(sp)
    9af0:	57312623          	sw	s3,1388(sp)
    9af4:	57412423          	sw	s4,1384(sp)
    9af8:	57512223          	sw	s5,1380(sp)
    9afc:	57612023          	sw	s6,1376(sp)
    9b00:	55712e23          	sw	s7,1372(sp)
    9b04:	55812c23          	sw	s8,1368(sp)
    9b08:	55912a23          	sw	s9,1364(sp)
    9b0c:	55b12623          	sw	s11,1356(sp)
    9b10:	00068413          	mv	s0,a3
    9b14:	02e12c23          	sw	a4,56(sp)
    9b18:	04f12623          	sw	a5,76(sp)
    9b1c:	12012823          	sw	zero,304(sp)
    9b20:	12012a23          	sw	zero,308(sp)
    9b24:	12012c23          	sw	zero,312(sp)
    9b28:	12012e23          	sw	zero,316(sp)
    9b2c:	14012023          	sw	zero,320(sp)
    9b30:	ef8f70ef          	jal	1228 <memset>
    9b34:	f81005b7          	lui	a1,0xf8100
    9b38:	46010513          	addi	a0,sp,1120
    9b3c:	f4cfd0ef          	jal	7288 <nc_init>
    9b40:	04050c63          	beqz	a0,9b98 <v3_demo_run+0xd8>
    9b44:	00050593          	mv	a1,a0
    9b48:	0000d537          	lui	a0,0xd
    9b4c:	60c50513          	addi	a0,a0,1548 # d60c <_data+0x360>
    9b50:	b51ff0ef          	jal	96a0 <bsp_printf>
    9b54:	00100d93          	li	s11,1
    9b58:	57c12083          	lw	ra,1404(sp)
    9b5c:	57812403          	lw	s0,1400(sp)
    9b60:	57412483          	lw	s1,1396(sp)
    9b64:	57012903          	lw	s2,1392(sp)
    9b68:	56c12983          	lw	s3,1388(sp)
    9b6c:	56812a03          	lw	s4,1384(sp)
    9b70:	56412a83          	lw	s5,1380(sp)
    9b74:	56012b03          	lw	s6,1376(sp)
    9b78:	55c12b83          	lw	s7,1372(sp)
    9b7c:	55812c03          	lw	s8,1368(sp)
    9b80:	55412c83          	lw	s9,1364(sp)
    9b84:	55012d03          	lw	s10,1360(sp)
    9b88:	000d8513          	mv	a0,s11
    9b8c:	54c12d83          	lw	s11,1356(sp)
    9b90:	58010113          	addi	sp,sp,1408
    9b94:	00008067          	ret
    9b98:	0001d737          	lui	a4,0x1d
    9b9c:	88470793          	addi	a5,a4,-1916 # 1c884 <physical_hud>
    9ba0:	20078623          	sb	zero,524(a5)
    9ba4:	10078223          	sb	zero,260(a5)
    9ba8:	02d107b7          	lui	a5,0x2d10
    9bac:	01478793          	addi	a5,a5,20 # 2d10014 <__gpu_framebuffer_a+0xd10014>
    9bb0:	0007a783          	lw	a5,0(a5)
    9bb4:	88470713          	addi	a4,a4,-1916
    9bb8:	08e12623          	sw	a4,140(sp)
    9bbc:	06f12c23          	sw	a5,120(sp)
    9bc0:	07812703          	lw	a4,120(sp)
    9bc4:	00100793          	li	a5,1
    9bc8:	f8e7e6e3          	bltu	a5,a4,9b54 <v3_demo_run+0x94>
    9bcc:	07812583          	lw	a1,120(sp)
    9bd0:	0000d537          	lui	a0,0xd
    9bd4:	64050513          	addi	a0,a0,1600 # d640 <_data+0x394>
    9bd8:	ac9ff0ef          	jal	96a0 <bsp_printf>
    9bdc:	03c12603          	lw	a2,60(sp)
    9be0:	03412583          	lw	a1,52(sp)
    9be4:	12810513          	addi	a0,sp,296
    9be8:	0c9020ef          	jal	c4b0 <gpu_frame_list_init>
    9bec:	06a12a23          	sw	a0,116(sp)
    9bf0:	f60512e3          	bnez	a0,9b54 <v3_demo_run+0x94>
    9bf4:	12e14583          	lbu	a1,302(sp)
    9bf8:	00058e63          	beqz	a1,9c14 <v3_demo_run+0x154>
    9bfc:	02d107b7          	lui	a5,0x2d10
    9c00:	00478793          	addi	a5,a5,4 # 2d10004 <__gpu_framebuffer_a+0xd10004>
    9c04:	0007a783          	lw	a5,0(a5)
    9c08:	fff78793          	addi	a5,a5,-1
    9c0c:	0017b793          	seqz	a5,a5
    9c10:	06f12a23          	sw	a5,116(sp)
    9c14:	07412603          	lw	a2,116(sp)
    9c18:	0000d537          	lui	a0,0xd
    9c1c:	65c50513          	addi	a0,a0,1628 # d65c <_data+0x3b0>
    9c20:	a81ff0ef          	jal	96a0 <bsp_printf>
    9c24:	000306b7          	lui	a3,0x30
    9c28:	00268693          	addi	a3,a3,2 # 30002 <__freertos_irq_stack_top+0x12562>
    9c2c:	00700613          	li	a2,7
    9c30:	40000593          	li	a1,1024
    9c34:	02d00537          	lui	a0,0x2d00
    9c38:	920ff0ef          	jal	8d58 <v3_runtime_init>
    9c3c:	04a12023          	sw	a0,64(sp)
    9c40:	f0051ae3          	bnez	a0,9b54 <v3_demo_run+0x94>
    9c44:	02d107b7          	lui	a5,0x2d10
    9c48:	00c7a583          	lw	a1,12(a5) # 2d1000c <__gpu_framebuffer_a+0xd1000c>
    9c4c:	eff5f793          	andi	a5,a1,-257
    9c50:	f00792e3          	bnez	a5,9b54 <v3_demo_run+0x94>
    9c54:	02d0f7b7          	lui	a5,0x2d0f
    9c58:	0000d537          	lui	a0,0xd
    9c5c:	54b79a23          	sh	a1,1364(a5) # 2d0f554 <__gpu_framebuffer_a+0xd0f554>
    9c60:	68450513          	addi	a0,a0,1668 # d684 <_data+0x3d8>
    9c64:	a3dff0ef          	jal	96a0 <bsp_printf>
    9c68:	02d107b7          	lui	a5,0x2d10
    9c6c:	0007a783          	lw	a5,0(a5) # 2d10000 <__gpu_framebuffer_a+0xd10000>
    9c70:	0000d537          	lui	a0,0xd
    9c74:	6a050513          	addi	a0,a0,1696 # d6a0 <_data+0x3f4>
    9c78:	fff78593          	addi	a1,a5,-1
    9c7c:	0015b593          	seqz	a1,a1
    9c80:	04f12823          	sw	a5,80(sp)
    9c84:	a1dff0ef          	jal	96a0 <bsp_printf>
    9c88:	05012703          	lw	a4,80(sp)
    9c8c:	00100793          	li	a5,1
    9c90:	00f71e63          	bne	a4,a5,9cac <v3_demo_run+0x1ec>
    9c94:	02d107b7          	lui	a5,0x2d10
    9c98:	00878793          	addi	a5,a5,8 # 2d10008 <__gpu_framebuffer_a+0xd10008>
    9c9c:	0007a783          	lw	a5,0(a5)
    9ca0:	fff78793          	addi	a5,a5,-1
    9ca4:	0017b793          	seqz	a5,a5
    9ca8:	04f12023          	sw	a5,64(sp)
    9cac:	04012583          	lw	a1,64(sp)
    9cb0:	0000d537          	lui	a0,0xd
    9cb4:	6bc50513          	addi	a0,a0,1724 # d6bc <_data+0x410>
    9cb8:	9e9ff0ef          	jal	96a0 <bsp_printf>
    9cbc:	03412503          	lw	a0,52(sp)
    9cc0:	00100693          	li	a3,1
    9cc4:	60000613          	li	a2,1536
    9cc8:	10000593          	li	a1,256
    9ccc:	fa4f80ef          	jal	2470 <gpu_set_qos>
    9cd0:	e80512e3          	bnez	a0,9b54 <v3_demo_run+0x94>
    9cd4:	03812503          	lw	a0,56(sp)
    9cd8:	02000613          	li	a2,32
    9cdc:	00000593          	li	a1,0
    9ce0:	004d2483          	lw	s1,4(s10)
    9ce4:	d44f70ef          	jal	1228 <memset>
    9ce8:	03812783          	lw	a5,56(sp)
    9cec:	03812703          	lw	a4,56(sp)
    9cf0:	03412503          	lw	a0,52(sp)
    9cf4:	0097a223          	sw	s1,4(a5)
    9cf8:	78000793          	li	a5,1920
    9cfc:	00f72623          	sw	a5,12(a4)
    9d00:	021c07b7          	lui	a5,0x21c0
    9d04:	3c078793          	addi	a5,a5,960 # 21c03c0 <__gpu_framebuffer_a+0x1c03c0>
    9d08:	00f72823          	sw	a5,16(a4)
    9d0c:	009896b7          	lui	a3,0x989
    9d10:	00100793          	li	a5,1
    9d14:	00f70e23          	sb	a5,28(a4)
    9d18:	68068693          	addi	a3,a3,1664 # 989680 <__freertos_irq_stack_top+0x96bbe0>
    9d1c:	00100613          	li	a2,1
    9d20:	00070593          	mv	a1,a4
    9d24:	e95fa0ef          	jal	4bb8 <perf_render_gpu>
    9d28:	e20516e3          	bnez	a0,9b54 <v3_demo_run+0x94>
    9d2c:	03412503          	lw	a0,52(sp)
    9d30:	00989637          	lui	a2,0x989
    9d34:	68060613          	addi	a2,a2,1664 # 989680 <__freertos_irq_stack_top+0x96bbe0>
    9d38:	000d0593          	mv	a1,s10
    9d3c:	fe5f80ef          	jal	2d20 <framebuffer_present>
    9d40:	e0051ae3          	bnez	a0,9b54 <v3_demo_run+0x94>
    9d44:	9b0f90ef          	jal	2ef4 <hud_set_logo_enabled>
    9d48:	01800613          	li	a2,24
    9d4c:	00000593          	li	a1,0
    9d50:	15810513          	addi	a0,sp,344
    9d54:	cd4f70ef          	jal	1228 <memset>
    9d58:	ad1f70ef          	jal	1828 <gpu_platform_cycles>
    9d5c:	03c12783          	lw	a5,60(sp)
    9d60:	00050613          	mv	a2,a0
    9d64:	feb00713          	li	a4,-21
    9d68:	02078e63          	beqz	a5,9da4 <v3_demo_run+0x2e4>
    9d6c:	00051463          	bnez	a0,9d74 <v3_demo_run+0x2b4>
    9d70:	00100613          	li	a2,1
    9d74:	b4cc7837          	lui	a6,0xb4cc7
    9d78:	000077b7          	lui	a5,0x7
    9d7c:	05f5e5b7          	lui	a1,0x5f5e
    9d80:	02c50737          	lui	a4,0x2c50
    9d84:	15810893          	addi	a7,sp,344
    9d88:	85380813          	addi	a6,a6,-1965 # b4cc6853 <__gpu_framebuffer_a+0xb2cc6853>
    9d8c:	d6078793          	addi	a5,a5,-672 # 6d60 <bullet_init_local_assets+0x308>
    9d90:	06700693          	li	a3,103
    9d94:	10058593          	addi	a1,a1,256 # 5f5e100 <__gpu_framebuffer_a+0x3f5e100>
    9d98:	f8100537          	lui	a0,0xf8100
    9d9c:	f44fa0ef          	jal	44e0 <network_asset_fetch>
    9da0:	00050713          	mv	a4,a0
    9da4:	00173793          	seqz	a5,a4
    9da8:	00078513          	mv	a0,a5
    9dac:	04e12423          	sw	a4,72(sp)
    9db0:	04f12223          	sw	a5,68(sp)
    9db4:	940f90ef          	jal	2ef4 <hud_set_logo_enabled>
    9db8:	04c12783          	lw	a5,76(sp)
    9dbc:	04812703          	lw	a4,72(sp)
    9dc0:	16012683          	lw	a3,352(sp)
    9dc4:	15812603          	lw	a2,344(sp)
    9dc8:	10078223          	sb	zero,260(a5)
    9dcc:	04412783          	lw	a5,68(sp)
    9dd0:	0000d537          	lui	a0,0xd
    9dd4:	06700593          	li	a1,103
    9dd8:	6d850513          	addi	a0,a0,1752 # d6d8 <_data+0x42c>
    9ddc:	8c5ff0ef          	jal	96a0 <bsp_printf>
    9de0:	03400613          	li	a2,52
    9de4:	00000593          	li	a1,0
    9de8:	1dc10513          	addi	a0,sp,476
    9dec:	c3cf70ef          	jal	1228 <memset>
    9df0:	03c14783          	lbu	a5,60(sp)
    9df4:	06400613          	li	a2,100
    9df8:	00000593          	li	a1,0
    9dfc:	0cf12223          	sw	a5,196(sp)
    9e00:	1ef108a3          	sb	a5,497(sp)
    9e04:	38410513          	addi	a0,sp,900
    9e08:	00100793          	li	a5,1
    9e0c:	1ef10923          	sb	a5,498(sp)
    9e10:	20f10123          	sb	a5,514(sp)
    9e14:	c14f70ef          	jal	1228 <memset>
    9e18:	202617b7          	lui	a5,0x20261
    9e1c:	01578793          	addi	a5,a5,21 # 20261015 <__gpu_framebuffer_a+0x1e261015>
    9e20:	36f12e23          	sw	a5,892(sp)
    9e24:	000307b7          	lui	a5,0x30
    9e28:	00278793          	addi	a5,a5,2 # 30002 <__freertos_irq_stack_top+0x12562>
    9e2c:	01800613          	li	a2,24
    9e30:	00000593          	li	a1,0
    9e34:	17010513          	addi	a0,sp,368
    9e38:	38f12023          	sw	a5,896(sp)
    9e3c:	becf70ef          	jal	1228 <memset>
    9e40:	01800613          	li	a2,24
    9e44:	00000593          	li	a1,0
    9e48:	1a410513          	addi	a0,sp,420
    9e4c:	bdcf70ef          	jal	1228 <memset>
    9e50:	02d0f4b7          	lui	s1,0x2d0f
    9e54:	5794c783          	lbu	a5,1401(s1) # 2d0f579 <__gpu_framebuffer_a+0xd0f579>
    9e58:	1af10ba3          	sb	a5,439(sp)
    9e5c:	00600793          	li	a5,6
    9e60:	1af10c23          	sb	a5,440(sp)
    9e64:	9c5f70ef          	jal	1828 <gpu_platform_cycles>
    9e68:	00050913          	mv	s2,a0
    9e6c:	03412503          	lw	a0,52(sp)
    9e70:	00058993          	mv	s3,a1
    9e74:	21010593          	addi	a1,sp,528
    9e78:	f4cf80ef          	jal	25c4 <gpu_read_perf_snapshot>
    9e7c:	cc051ce3          	bnez	a0,9b54 <v3_demo_run+0x94>
    9e80:	23812783          	lw	a5,568(sp)
    9e84:	23c12603          	lw	a2,572(sp)
    9e88:	0000d537          	lui	a0,0xd
    9e8c:	00078593          	mv	a1,a5
    9e90:	71450513          	addi	a0,a0,1812 # d714 <_data+0x468>
    9e94:	0af12a23          	sw	a5,180(sp)
    9e98:	809ff0ef          	jal	96a0 <bsp_printf>
    9e9c:	03412503          	lw	a0,52(sp)
    9ea0:	25810593          	addi	a1,sp,600
    9ea4:	f20f80ef          	jal	25c4 <gpu_read_perf_snapshot>
    9ea8:	04a12223          	sw	a0,68(sp)
    9eac:	ca0514e3          	bnez	a0,9b54 <v3_demo_run+0x94>
    9eb0:	28012783          	lw	a5,640(sp)
    9eb4:	000015b7          	lui	a1,0x1
    9eb8:	0000d537          	lui	a0,0xd
    9ebc:	0cf12e23          	sw	a5,220(sp)
    9ec0:	28412783          	lw	a5,644(sp)
    9ec4:	e1058593          	addi	a1,a1,-496 # e10 <CUSTOM2+0xdb5>
    9ec8:	74450513          	addi	a0,a0,1860 # d744 <_data+0x498>
    9ecc:	0ef12623          	sw	a5,236(sp)
    9ed0:	fd0ff0ef          	jal	96a0 <bsp_printf>
    9ed4:	5774c783          	lbu	a5,1399(s1)
    9ed8:	14078463          	beqz	a5,a020 <v3_demo_run+0x560>
    9edc:	04412803          	lw	a6,68(sp)
    9ee0:	0000d7b7          	lui	a5,0xd
    9ee4:	5f478793          	addi	a5,a5,1524 # d5f4 <_data+0x348>
    9ee8:	03c12683          	lw	a3,60(sp)
    9eec:	00030637          	lui	a2,0x30
    9ef0:	202615b7          	lui	a1,0x20261
    9ef4:	0000d537          	lui	a0,0xd
    9ef8:	02d00737          	lui	a4,0x2d00
    9efc:	00260613          	addi	a2,a2,2 # 30002 <__freertos_irq_stack_top+0x12562>
    9f00:	01558593          	addi	a1,a1,21 # 20261015 <__gpu_framebuffer_a+0x1e261015>
    9f04:	77850513          	addi	a0,a0,1912 # d778 <_data+0x4cc>
    9f08:	f98ff0ef          	jal	96a0 <bsp_printf>
    9f0c:	00000b93          	li	s7,0
    9f10:	06012223          	sw	zero,100(sp)
    9f14:	0a012823          	sw	zero,176(sp)
    9f18:	06012823          	sw	zero,112(sp)
    9f1c:	08012c23          	sw	zero,152(sp)
    9f20:	06012423          	sw	zero,104(sp)
    9f24:	08012e23          	sw	zero,156(sp)
    9f28:	08012a23          	sw	zero,148(sp)
    9f2c:	0a012623          	sw	zero,172(sp)
    9f30:	0a012423          	sw	zero,168(sp)
    9f34:	08012823          	sw	zero,144(sp)
    9f38:	04012a23          	sw	zero,84(sp)
    9f3c:	06012623          	sw	zero,108(sp)
    9f40:	04012223          	sw	zero,68(sp)
    9f44:	04012423          	sw	zero,72(sp)
    9f48:	06012023          	sw	zero,96(sp)
    9f4c:	00090493          	mv	s1,s2
    9f50:	00098a13          	mv	s4,s3
    9f54:	0c012a23          	sw	zero,212(sp)
    9f58:	0c012823          	sw	zero,208(sp)
    9f5c:	04012e23          	sw	zero,92(sp)
    9f60:	04012c23          	sw	zero,88(sp)
    9f64:	0a012023          	sw	zero,160(sp)
    9f68:	08012423          	sw	zero,136(sp)
    9f6c:	0c012023          	sw	zero,192(sp)
    9f70:	08012223          	sw	zero,132(sp)
    9f74:	0a012e23          	sw	zero,188(sp)
    9f78:	08012023          	sw	zero,128(sp)
    9f7c:	0a012c23          	sw	zero,184(sp)
    9f80:	03412503          	lw	a0,52(sp)
    9f84:	2a010593          	addi	a1,sp,672
    9f88:	e3cf80ef          	jal	25c4 <gpu_read_perf_snapshot>
    9f8c:	00050b13          	mv	s6,a0
    9f90:	00050463          	beqz	a0,9f98 <v3_demo_run+0x4d8>
    9f94:	0b40106f          	j	b048 <v3_demo_run+0x1588>
    9f98:	ebcff0ef          	jal	9654 <now_ms>
    9f9c:	00050593          	mv	a1,a0
    9fa0:	13010613          	addi	a2,sp,304
    9fa4:	46010513          	addi	a0,sp,1120
    9fa8:	ba4fd0ef          	jal	734c <nc_poll>
    9fac:	00050d93          	mv	s11,a0
    9fb0:	04054a63          	bltz	a0,a004 <v3_demo_run+0x544>
    9fb4:	13010593          	addi	a1,sp,304
    9fb8:	18c10513          	addi	a0,sp,396
    9fbc:	d81fd0ef          	jal	7d3c <input_update>
    9fc0:	14410593          	addi	a1,sp,324
    9fc4:	46010513          	addi	a0,sp,1120
    9fc8:	f44fd0ef          	jal	770c <nc_take_game>
    9fcc:	00050d93          	mv	s11,a0
    9fd0:	02054a63          	bltz	a0,a004 <v3_demo_run+0x544>
    9fd4:	04050e63          	beqz	a0,a030 <v3_demo_run+0x570>
    9fd8:	14410613          	addi	a2,sp,324
    9fdc:	46010593          	addi	a1,sp,1120
    9fe0:	02d00537          	lui	a0,0x2d00
    9fe4:	a01ff0ef          	jal	99e4 <v3_apply_game_command>
    9fe8:	00050d93          	mv	s11,a0
    9fec:	04055263          	bgez	a0,a030 <v3_demo_run+0x570>
    9ff0:	e64ff0ef          	jal	9654 <now_ms>
    9ff4:	00050613          	mv	a2,a0
    9ff8:	00000593          	li	a1,0
    9ffc:	46010513          	addi	a0,sp,1120
    a000:	83dfd0ef          	jal	783c <nc_try_publish>
    a004:	03412783          	lw	a5,52(sp)
    a008:	0000e537          	lui	a0,0xe
    a00c:	000d8593          	mv	a1,s11
    a010:	0137c603          	lbu	a2,19(a5)
    a014:	a0c50513          	addi	a0,a0,-1524 # da0c <_data+0x760>
    a018:	e88ff0ef          	jal	96a0 <bsp_printf>
    a01c:	b39ff06f          	j	9b54 <v3_demo_run+0x94>
    a020:	0000d7b7          	lui	a5,0xd
    a024:	5fc78793          	addi	a5,a5,1532 # d5fc <_data+0x350>
    a028:	40000813          	li	a6,1024
    a02c:	ebdff06f          	j	9ee8 <v3_demo_run+0x428>
    a030:	e24ff0ef          	jal	9654 <now_ms>
    a034:	00050613          	mv	a2,a0
    a038:	00000593          	li	a1,0
    a03c:	46010513          	addi	a0,sp,1120
    a040:	ffcfd0ef          	jal	783c <nc_try_publish>
    a044:	fe4f70ef          	jal	1828 <gpu_platform_cycles>
    a048:	04012783          	lw	a5,64(sp)
    a04c:	06a12e23          	sw	a0,124(sp)
    a050:	0eb12023          	sw	a1,224(sp)
    a054:	12011123          	sh	zero,290(sp)
    a058:	40950533          	sub	a0,a0,s1
    a05c:	41458a33          	sub	s4,a1,s4
    a060:	66078863          	beqz	a5,a6d0 <v3_demo_run+0xc10>
    a064:	07c12783          	lw	a5,124(sp)
    a068:	06400613          	li	a2,100
    a06c:	00000693          	li	a3,0
    a070:	00a7b5b3          	sltu	a1,a5,a0
    a074:	40ba05b3          	sub	a1,s4,a1
    a078:	115020ef          	jal	c98c <__udivdi3>
    a07c:	02d0f7b7          	lui	a5,0x2d0f
    a080:	5727c603          	lbu	a2,1394(a5) # 2d0f572 <__gpu_framebuffer_a+0xd0f572>
    a084:	00100693          	li	a3,1
    a088:	004d2703          	lw	a4,4(s10)
    a08c:	00050493          	mv	s1,a0
    a090:	5ed60463          	beq	a2,a3,a678 <v3_demo_run+0xbb8>
    a094:	5777c683          	lbu	a3,1399(a5)
    a098:	00068663          	beqz	a3,a0a4 <v3_demo_run+0x5e4>
    a09c:	5747c783          	lbu	a5,1396(a5)
    a0a0:	5c078c63          	beqz	a5,a678 <v3_demo_run+0xbb8>
    a0a4:	03c12683          	lw	a3,60(sp)
    a0a8:	00100793          	li	a5,1
    a0ac:	00d7f663          	bgeu	a5,a3,a0b8 <v3_demo_run+0x5f8>
    a0b0:	ff800d93          	li	s11,-8
    a0b4:	f51ff06f          	j	a004 <v3_demo_run+0x544>
    a0b8:	ffe007b7          	lui	a5,0xffe00
    a0bc:	fff78793          	addi	a5,a5,-1 # ffdfffff <__gpu_framebuffer_a+0xfddfffff>
    a0c0:	00f777b3          	and	a5,a4,a5
    a0c4:	020006b7          	lui	a3,0x2000
    a0c8:	fed794e3          	bne	a5,a3,a0b0 <v3_demo_run+0x5f0>
    a0cc:	03c12683          	lw	a3,60(sp)
    a0d0:	02b227b7          	lui	a5,0x2b22
    a0d4:	c0078793          	addi	a5,a5,-1024 # 2b21c00 <__gpu_framebuffer_a+0xb21c00>
    a0d8:	00068663          	beqz	a3,a0e4 <v3_demo_run+0x624>
    a0dc:	029227b7          	lui	a5,0x2922
    a0e0:	c0078793          	addi	a5,a5,-1024 # 2921c00 <__gpu_framebuffer_a+0x921c00>
    a0e4:	1af12e23          	sw	a5,444(sp)
    a0e8:	000227b7          	lui	a5,0x22
    a0ec:	c0078793          	addi	a5,a5,-1024 # 21c00 <__freertos_irq_stack_top+0x4160>
    a0f0:	00f70733          	add	a4,a4,a5
    a0f4:	78000793          	li	a5,1920
    a0f8:	1cf12223          	sw	a5,452(sp)
    a0fc:	1cf12423          	sw	a5,456(sp)
    a100:	03412503          	lw	a0,52(sp)
    a104:	3c000793          	li	a5,960
    a108:	1cf11623          	sh	a5,460(sp)
    a10c:	00989637          	lui	a2,0x989
    a110:	1d400793          	li	a5,468
    a114:	1c012c23          	sw	zero,472(sp)
    a118:	1cf11723          	sh	a5,462(sp)
    a11c:	12210693          	addi	a3,sp,290
    a120:	00200793          	li	a5,2
    a124:	68060613          	addi	a2,a2,1664 # 989680 <__freertos_irq_stack_top+0x96bbe0>
    a128:	1bc10593          	addi	a1,sp,444
    a12c:	1c012823          	sw	zero,464(sp)
    a130:	1c012a23          	sw	zero,468(sp)
    a134:	1ce12023          	sw	a4,448(sp)
    a138:	1cf10c23          	sb	a5,472(sp)
    a13c:	d4df70ef          	jal	1e88 <gpu_submit>
    a140:	00050d93          	mv	s11,a0
    a144:	5e051463          	bnez	a0,a72c <v3_demo_run+0xc6c>
    a148:	04012a03          	lw	s4,64(sp)
    a14c:	02d0fc37          	lui	s8,0x2d0f
    a150:	00048613          	mv	a2,s1
    a154:	18c10593          	addi	a1,sp,396
    a158:	02d00537          	lui	a0,0x2d00
    a15c:	572c4c83          	lbu	s9,1394(s8) # 2d0f572 <__gpu_framebuffer_a+0xd0f572>
    a160:	f19fe0ef          	jal	9078 <v3_runtime_advance>
    a164:	00050d93          	mv	s11,a0
    a168:	e8054ee3          	bltz	a0,a004 <v3_demo_run+0x544>
    a16c:	572c4703          	lbu	a4,1394(s8)
    a170:	500c8863          	beqz	s9,a680 <v3_demo_run+0xbc0>
    a174:	02d0f7b7          	lui	a5,0x2d0f
    a178:	5727c703          	lbu	a4,1394(a5) # 2d0f572 <__gpu_framebuffer_a+0xd0f572>
    a17c:	520a1463          	bnez	s4,a6a4 <v3_demo_run+0xbe4>
    a180:	00000a93          	li	s5,0
    a184:	02d0f737          	lui	a4,0x2d0f
    a188:	57774783          	lbu	a5,1399(a4) # 2d0f577 <__gpu_framebuffer_a+0xd0f577>
    a18c:	57274a03          	lbu	s4,1394(a4)
    a190:	00000493          	li	s1,0
    a194:	00078663          	beqz	a5,a1a0 <v3_demo_run+0x6e0>
    a198:	57474483          	lbu	s1,1396(a4)
    a19c:	0014b493          	seqz	s1,s1
    a1a0:	02d0f7b7          	lui	a5,0x2d0f
    a1a4:	57c7a783          	lw	a5,1404(a5) # 2d0f57c <__gpu_framebuffer_a+0xd0f57c>
    a1a8:	0cf12423          	sw	a5,200(sp)
    a1ac:	09778c63          	beq	a5,s7,a244 <v3_demo_run+0x784>
    a1b0:	01800613          	li	a2,24
    a1b4:	00000593          	li	a1,0
    a1b8:	17010513          	addi	a0,sp,368
    a1bc:	86cf70ef          	jal	1228 <memset>
    a1c0:	04c12783          	lw	a5,76(sp)
    a1c4:	1a410513          	addi	a0,sp,420
    a1c8:	10078223          	sb	zero,260(a5)
    a1cc:	090010ef          	jal	b25c <game_menu_invalidate>
    a1d0:	08c12783          	lw	a5,140(sp)
    a1d4:	46010513          	addi	a0,sp,1120
    a1d8:	20078623          	sb	zero,524(a5)
    a1dc:	10078223          	sb	zero,260(a5)
    a1e0:	d8cfd0ef          	jal	776c <nc_discard_pending_telemetry>
    a1e4:	c70ff0ef          	jal	9654 <now_ms>
    a1e8:	f3850793          	addi	a5,a0,-200 # 2cfff38 <__gpu_framebuffer_a+0xcfff38>
    a1ec:	0af12023          	sw	a5,160(sp)
    a1f0:	e38f70ef          	jal	1828 <gpu_platform_cycles>
    a1f4:	00050913          	mv	s2,a0
    a1f8:	00058993          	mv	s3,a1
    a1fc:	52048e63          	beqz	s1,a738 <v3_demo_run+0xc78>
    a200:	0000d5b7          	lui	a1,0xd
    a204:	5f458593          	addi	a1,a1,1524 # d5f4 <_data+0x348>
    a208:	02d0f7b7          	lui	a5,0x2d0f
    a20c:	5757c603          	lbu	a2,1397(a5) # 2d0f575 <__gpu_framebuffer_a+0xd0f575>
    a210:	00000693          	li	a3,0
    a214:	00049663          	bnez	s1,a220 <v3_demo_run+0x760>
    a218:	02d057b7          	lui	a5,0x2d05
    a21c:	0087a683          	lw	a3,8(a5) # 2d05008 <__gpu_framebuffer_a+0xd05008>
    a220:	02d0f737          	lui	a4,0x2d0f
    a224:	57674783          	lbu	a5,1398(a4) # 2d0f576 <__gpu_framebuffer_a+0xd0f576>
    a228:	57c72703          	lw	a4,1404(a4)
    a22c:	0000d537          	lui	a0,0xd
    a230:	7bc50513          	addi	a0,a0,1980 # d7bc <_data+0x510>
    a234:	c6cff0ef          	jal	96a0 <bsp_printf>
    a238:	06012623          	sw	zero,108(sp)
    a23c:	04012223          	sw	zero,68(sp)
    a240:	06012023          	sw	zero,96(sp)
    a244:	020a0663          	beqz	s4,a270 <v3_demo_run+0x7b0>
    a248:	01800613          	li	a2,24
    a24c:	00000593          	li	a1,0
    a250:	17010513          	addi	a0,sp,368
    a254:	fd5f60ef          	jal	1228 <memset>
    a258:	04c12783          	lw	a5,76(sp)
    a25c:	06012023          	sw	zero,96(sp)
    a260:	10078223          	sb	zero,260(a5)
    a264:	08c12783          	lw	a5,140(sp)
    a268:	20078623          	sb	zero,524(a5)
    a26c:	10078223          	sb	zero,260(a5)
    a270:	05012783          	lw	a5,80(sp)
    a274:	00100713          	li	a4,1
    a278:	00e79a63          	bne	a5,a4,a28c <v3_demo_run+0x7cc>
    a27c:	00049863          	bnez	s1,a28c <v3_demo_run+0x7cc>
    a280:	56fa0463          	beq	s4,a5,a7e8 <v3_demo_run+0xd28>
    a284:	4c0a8063          	beqz	s5,a744 <v3_demo_run+0xc84>
    a288:	00100b13          	li	s6,1
    a28c:	d9cf70ef          	jal	1828 <gpu_platform_cycles>
    a290:	0eb12a23          	sw	a1,244(sp)
    a294:	0ea12823          	sw	a0,240(sp)
    a298:	12012223          	sw	zero,292(sp)
    a29c:	004d2583          	lw	a1,4(s10)
    a2a0:	54048863          	beqz	s1,a7f0 <v3_demo_run+0xd30>
    a2a4:	000097b7          	lui	a5,0x9
    a2a8:	00f407b3          	add	a5,s0,a5
    a2ac:	1207a823          	sw	zero,304(a5) # 9130 <v3_runtime_advance+0xb8>
    a2b0:	1207a623          	sw	zero,300(a5)
    a2b4:	1207a223          	sw	zero,292(a5)
    a2b8:	1207a023          	sw	zero,288(a5)
    a2bc:	d6cf70ef          	jal	1828 <gpu_platform_cycles>
    a2c0:	0ca12c23          	sw	a0,216(sp)
    a2c4:	0eb12223          	sw	a1,228(sp)
    a2c8:	d84f70ef          	jal	184c <gpu_platform_sync>
    a2cc:	d5cf70ef          	jal	1828 <gpu_platform_cycles>
    a2d0:	12412783          	lw	a5,292(sp)
    a2d4:	0ea12c23          	sw	a0,248(sp)
    a2d8:	0eb12e23          	sw	a1,252(sp)
    a2dc:	0cf12623          	sw	a5,204(sp)
    a2e0:	58078463          	beqz	a5,a868 <v3_demo_run+0xda8>
    a2e4:	560b0e63          	beqz	s6,a860 <v3_demo_run+0xda0>
    a2e8:	12215583          	lhu	a1,290(sp)
    a2ec:	03412503          	lw	a0,52(sp)
    a2f0:	00989637          	lui	a2,0x989
    a2f4:	68060613          	addi	a2,a2,1664 # 989680 <__freertos_irq_stack_top+0x96bbe0>
    a2f8:	8d0f80ef          	jal	23c8 <gpu_wait_tag>
    a2fc:	00050d93          	mv	s11,a0
    a300:	d00512e3          	bnez	a0,a004 <v3_demo_run+0x544>
    a304:	00100793          	li	a5,1
    a308:	00009737          	lui	a4,0x9
    a30c:	00e40733          	add	a4,s0,a4
    a310:	12072603          	lw	a2,288(a4) # 9120 <v3_runtime_advance+0xa8>
    a314:	02d0f6b7          	lui	a3,0x2d0f
    a318:	57c6a683          	lw	a3,1404(a3) # 2d0f57c <__gpu_framebuffer_a+0xd0f57c>
    a31c:	00479593          	slli	a1,a5,0x4
    a320:	00989737          	lui	a4,0x989
    a324:	40f60633          	sub	a2,a2,a5
    a328:	02d207b7          	lui	a5,0x2d20
    a32c:	68070713          	addi	a4,a4,1664 # 989680 <__freertos_irq_stack_top+0x96bbe0>
    a330:	00f585b3          	add	a1,a1,a5
    a334:	12810513          	addi	a0,sp,296
    a338:	528020ef          	jal	c860 <gpu_frame_list_render_span>
    a33c:	00050d93          	mv	s11,a0
    a340:	d0cf70ef          	jal	184c <gpu_platform_sync>
    a344:	ce4f70ef          	jal	1828 <gpu_platform_cycles>
    a348:	0eb12423          	sw	a1,232(sp)
    a34c:	00050c13          	mv	s8,a0
    a350:	ca0d9ae3          	bnez	s11,a004 <v3_demo_run+0x544>
    a354:	000097b7          	lui	a5,0x9
    a358:	00f407b3          	add	a5,s0,a5
    a35c:	1247df83          	lhu	t6,292(a5) # 9124 <v3_runtime_advance+0xac>
    a360:	04412783          	lw	a5,68(sp)
    a364:	00f036b3          	snez	a3,a5
    a368:	00049463          	bnez	s1,a370 <v3_demo_run+0x8b0>
    a36c:	00068d93          	mv	s11,a3
    a370:	02d057b7          	lui	a5,0x2d05
    a374:	0247c803          	lbu	a6,36(a5) # 2d05024 <__gpu_framebuffer_a+0xd05024>
    a378:	0207db83          	lhu	s7,32(a5)
    a37c:	00009737          	lui	a4,0x9
    a380:	fffa0c93          	addi	s9,s4,-1
    a384:	00e40733          	add	a4,s0,a4
    a388:	2c812f03          	lw	t5,712(sp)
    a38c:	0187ae83          	lw	t4,24(a5)
    a390:	01c7ae03          	lw	t3,28(a5)
    a394:	12c75303          	lhu	t1,300(a4) # 912c <v3_runtime_advance+0xb4>
    a398:	0ffdfa93          	zext.b	s5,s11
    a39c:	01903cb3          	snez	s9,s9
    a3a0:	0014c893          	xori	a7,s1,1
    a3a4:	01703bb3          	snez	s7,s7
    a3a8:	00183293          	seqz	t0,a6
    a3ac:	00400b13          	li	s6,4
    a3b0:	00049e63          	bnez	s1,a3cc <v3_demo_run+0x90c>
    a3b4:	00100b13          	li	s6,1
    a3b8:	000a0a63          	beqz	s4,a3cc <v3_demo_run+0x90c>
    a3bc:	00100793          	li	a5,1
    a3c0:	00300b13          	li	s6,3
    a3c4:	00fa1463          	bne	s4,a5,a3cc <v3_demo_run+0x90c>
    a3c8:	00200b13          	li	s6,2
    a3cc:	14214603          	lbu	a2,322(sp)
    a3d0:	03c12583          	lw	a1,60(sp)
    a3d4:	00000793          	li	a5,0
    a3d8:	00000713          	li	a4,0
    a3dc:	02d00537          	lui	a0,0x2d00
    a3e0:	10512e23          	sw	t0,284(sp)
    a3e4:	11012c23          	sw	a6,280(sp)
    a3e8:	11112a23          	sw	a7,276(sp)
    a3ec:	10612823          	sw	t1,272(sp)
    a3f0:	11c12623          	sw	t3,268(sp)
    a3f4:	11d12423          	sw	t4,264(sp)
    a3f8:	11e12223          	sw	t5,260(sp)
    a3fc:	11f12023          	sw	t6,256(sp)
    a400:	87dfe0ef          	jal	8c7c <v3_runtime_status>
    a404:	0aa12223          	sw	a0,164(sp)
    a408:	02d0f737          	lui	a4,0x2d0f
    a40c:	01d00613          	li	a2,29
    a410:	00000593          	li	a1,0
    a414:	1f310513          	addi	a0,sp,499
    a418:	56874d83          	lbu	s11,1384(a4) # 2d0f568 <__gpu_framebuffer_a+0xd0f568>
    a41c:	e0df60ef          	jal	1228 <memset>
    a420:	04412783          	lw	a5,68(sp)
    a424:	10012f83          	lw	t6,256(sp)
    a428:	10412f03          	lw	t5,260(sp)
    a42c:	1ef12023          	sw	a5,480(sp)
    a430:	06c12783          	lw	a5,108(sp)
    a434:	10812e83          	lw	t4,264(sp)
    a438:	10c12e03          	lw	t3,268(sp)
    a43c:	1ef12423          	sw	a5,488(sp)
    a440:	0c412783          	lw	a5,196(sp)
    a444:	11012303          	lw	t1,272(sp)
    a448:	11412883          	lw	a7,276(sp)
    a44c:	1ef108a3          	sb	a5,497(sp)
    a450:	0a412783          	lw	a5,164(sp)
    a454:	11812803          	lw	a6,280(sp)
    a458:	11c12283          	lw	t0,284(sp)
    a45c:	0057d793          	srli	a5,a5,0x5
    a460:	0017f793          	andi	a5,a5,1
    a464:	00100693          	li	a3,1
    a468:	20f103a3          	sb	a5,519(sp)
    a46c:	1c012e23          	sw	zero,476(sp)
    a470:	1e012223          	sw	zero,484(sp)
    a474:	1ff11623          	sh	t6,492(sp)
    a478:	1e010723          	sb	zero,494(sp)
    a47c:	1f5107a3          	sb	s5,495(sp)
    a480:	1f910823          	sb	s9,496(sp)
    a484:	1ed10923          	sb	a3,498(sp)
    a488:	1fe12a23          	sw	t5,500(sp)
    a48c:	1fd12c23          	sw	t4,504(sp)
    a490:	1fc12e23          	sw	t3,508(sp)
    a494:	20611023          	sh	t1,512(sp)
    a498:	21110123          	sb	a7,514(sp)
    a49c:	210101a3          	sb	a6,515(sp)
    a4a0:	21710223          	sb	s7,516(sp)
    a4a4:	205102a3          	sb	t0,517(sp)
    a4a8:	21610323          	sb	s6,518(sp)
    a4ac:	21b10423          	sb	s11,520(sp)
    a4b0:	07812783          	lw	a5,120(sp)
    a4b4:	4cd79c63          	bne	a5,a3,a98c <v3_demo_run+0xecc>
    a4b8:	4cfa0c63          	beq	s4,a5,a990 <v3_demo_run+0xed0>
    a4bc:	004d2703          	lw	a4,4(s10)
    a4c0:	03812683          	lw	a3,56(sp)
    a4c4:	03412503          	lw	a0,52(sp)
    a4c8:	009897b7          	lui	a5,0x989
    a4cc:	0001d637          	lui	a2,0x1d
    a4d0:	68078793          	addi	a5,a5,1664 # 989680 <__freertos_irq_stack_top+0x96bbe0>
    a4d4:	88460613          	addi	a2,a2,-1916 # 1c884 <physical_hud>
    a4d8:	1dc10593          	addi	a1,sp,476
    a4dc:	bbdf90ef          	jal	4098 <hud_render_gpu_direct>
    a4e0:	00050d93          	mv	s11,a0
    a4e4:	b20510e3          	bnez	a0,a004 <v3_demo_run+0x544>
    a4e8:	b64f70ef          	jal	184c <gpu_platform_sync>
    a4ec:	b3cf70ef          	jal	1828 <gpu_platform_cycles>
    a4f0:	10a12023          	sw	a0,256(sp)
    a4f4:	03412503          	lw	a0,52(sp)
    a4f8:	10b12223          	sw	a1,260(sp)
    a4fc:	2e810593          	addi	a1,sp,744
    a500:	8c4f80ef          	jal	25c4 <gpu_read_perf_snapshot>
    a504:	00050d93          	mv	s11,a0
    a508:	ae051ee3          	bnez	a0,a004 <v3_demo_run+0x544>
    a50c:	b1cf70ef          	jal	1828 <gpu_platform_cycles>
    a510:	41250bb3          	sub	s7,a0,s2
    a514:	017537b3          	sltu	a5,a0,s7
    a518:	413585b3          	sub	a1,a1,s3
    a51c:	06400613          	li	a2,100
    a520:	00000693          	li	a3,0
    a524:	40f585b3          	sub	a1,a1,a5
    a528:	000b8513          	mv	a0,s7
    a52c:	460020ef          	jal	c98c <__udivdi3>
    a530:	0aa12223          	sw	a0,164(sp)
    a534:	03412503          	lw	a0,52(sp)
    a538:	00989637          	lui	a2,0x989
    a53c:	68060613          	addi	a2,a2,1664 # 989680 <__freertos_irq_stack_top+0x96bbe0>
    a540:	000d0593          	mv	a1,s10
    a544:	fdcf80ef          	jal	2d20 <framebuffer_present>
    a548:	00050d93          	mv	s11,a0
    a54c:	aa051ce3          	bnez	a0,a004 <v3_demo_run+0x544>
    a550:	ad8f70ef          	jal	1828 <gpu_platform_cycles>
    a554:	41250933          	sub	s2,a0,s2
    a558:	012537b3          	sltu	a5,a0,s2
    a55c:	413589b3          	sub	s3,a1,s3
    a560:	06012a83          	lw	s5,96(sp)
    a564:	00050b13          	mv	s6,a0
    a568:	00058c93          	mv	s9,a1
    a56c:	40f989b3          	sub	s3,s3,a5
    a570:	0a049263          	bnez	s1,a614 <v3_demo_run+0xb54>
    a574:	0f812783          	lw	a5,248(sp)
    a578:	0fc12703          	lw	a4,252(sp)
    a57c:	06400613          	li	a2,100
    a580:	40fc0533          	sub	a0,s8,a5
    a584:	0e812783          	lw	a5,232(sp)
    a588:	00ac3c33          	sltu	s8,s8,a0
    a58c:	00000693          	li	a3,0
    a590:	40e785b3          	sub	a1,a5,a4
    a594:	418585b3          	sub	a1,a1,s8
    a598:	3f4020ef          	jal	c98c <__udivdi3>
    a59c:	06400693          	li	a3,100
    a5a0:	02a6b733          	mulhu	a4,a3,a0
    a5a4:	00090593          	mv	a1,s2
    a5a8:	00098613          	mv	a2,s3
    a5ac:	02a686b3          	mul	a3,a3,a0
    a5b0:	17010513          	addi	a0,sp,368
    a5b4:	e9cfa0ef          	jal	4c50 <perf_window_add>
    a5b8:	00050d93          	mv	s11,a0
    a5bc:	a40514e3          	bnez	a0,a004 <v3_demo_run+0x544>
    a5c0:	06012703          	lw	a4,96(sp)
    a5c4:	0001d7b7          	lui	a5,0x1d
    a5c8:	80c78793          	addi	a5,a5,-2036 # 1c80c <work_samples>
    a5cc:	00271713          	slli	a4,a4,0x2
    a5d0:	00e787b3          	add	a5,a5,a4
    a5d4:	0a412703          	lw	a4,164(sp)
    a5d8:	001a8a93          	addi	s5,s5,1
    a5dc:	00e7a023          	sw	a4,0(a5)
    a5e0:	00100793          	li	a5,1
    a5e4:	02fa0863          	beq	s4,a5,a614 <v3_demo_run+0xb54>
    a5e8:	06400613          	li	a2,100
    a5ec:	00000693          	li	a3,0
    a5f0:	00090513          	mv	a0,s2
    a5f4:	00098593          	mv	a1,s3
    a5f8:	394020ef          	jal	c98c <__udivdi3>
    a5fc:	000057b7          	lui	a5,0x5
    a600:	e2078793          	addi	a5,a5,-480 # 4e20 <perf_render_us+0x9c>
    a604:	00a7f863          	bgeu	a5,a0,a614 <v3_demo_run+0xb54>
    a608:	05c12783          	lw	a5,92(sp)
    a60c:	00178793          	addi	a5,a5,1
    a610:	04f12e23          	sw	a5,92(sp)
    a614:	31012983          	lw	s3,784(sp)
    a618:	a80a1ce3          	bnez	s4,a0b0 <v3_demo_run+0x5f0>
    a61c:	03412503          	lw	a0,52(sp)
    a620:	33010593          	addi	a1,sp,816
    a624:	fa1f70ef          	jal	25c4 <gpu_read_perf_snapshot>
    a628:	00050d93          	mv	s11,a0
    a62c:	9c051ce3          	bnez	a0,a004 <v3_demo_run+0x544>
    a630:	03412783          	lw	a5,52(sp)
    a634:	35812703          	lw	a4,856(sp)
    a638:	0dc12603          	lw	a2,220(sp)
    a63c:	35c12683          	lw	a3,860(sp)
    a640:	0137c783          	lbu	a5,19(a5)
    a644:	00c71863          	bne	a4,a2,a654 <v3_demo_run+0xb94>
    a648:	0ec12603          	lw	a2,236(sp)
    a64c:	00c69463          	bne	a3,a2,a654 <v3_demo_run+0xb94>
    a650:	3c078463          	beqz	a5,aa18 <v3_demo_run+0xf58>
    a654:	06412603          	lw	a2,100(sp)
    a658:	0dc12683          	lw	a3,220(sp)
    a65c:	06412583          	lw	a1,100(sp)
    a660:	0000d537          	lui	a0,0xd
    a664:	01e63613          	sltiu	a2,a2,30
    a668:	7fc50513          	addi	a0,a0,2044 # d7fc <_data+0x550>
    a66c:	834ff0ef          	jal	96a0 <bsp_printf>
    a670:	ff900d93          	li	s11,-7
    a674:	991ff06f          	j	a004 <v3_demo_run+0x544>
    a678:	00000a13          	li	s4,0
    a67c:	ad1ff06f          	j	a14c <v3_demo_run+0x68c>
    a680:	00100793          	li	a5,1
    a684:	1cf716e3          	bne	a4,a5,b050 <v3_demo_run+0x1590>
    a688:	00000613          	li	a2,0
    a68c:	18c10593          	addi	a1,sp,396
    a690:	02d00537          	lui	a0,0x2d00
    a694:	9e5fe0ef          	jal	9078 <v3_runtime_advance>
    a698:	00050d93          	mv	s11,a0
    a69c:	ac055ce3          	bgez	a0,a174 <v3_demo_run+0x6b4>
    a6a0:	965ff06f          	j	a004 <v3_demo_run+0x544>
    a6a4:	00100793          	li	a5,1
    a6a8:	1af716e3          	bne	a4,a5,b054 <v3_demo_run+0x1594>
    a6ac:	12215583          	lhu	a1,290(sp)
    a6b0:	03412503          	lw	a0,52(sp)
    a6b4:	00989637          	lui	a2,0x989
    a6b8:	68060613          	addi	a2,a2,1664 # 989680 <__freertos_irq_stack_top+0x96bbe0>
    a6bc:	d0df70ef          	jal	23c8 <gpu_wait_tag>
    a6c0:	00050d93          	mv	s11,a0
    a6c4:	aa050ee3          	beqz	a0,a180 <v3_demo_run+0x6c0>
    a6c8:	04012a83          	lw	s5,64(sp)
    a6cc:	0640006f          	j	a730 <v3_demo_run+0xc70>
    a6d0:	07c12783          	lw	a5,124(sp)
    a6d4:	06400613          	li	a2,100
    a6d8:	00000693          	li	a3,0
    a6dc:	00a7b5b3          	sltu	a1,a5,a0
    a6e0:	40ba05b3          	sub	a1,s4,a1
    a6e4:	2a8020ef          	jal	c98c <__udivdi3>
    a6e8:	00050613          	mv	a2,a0
    a6ec:	02d0f4b7          	lui	s1,0x2d0f
    a6f0:	18c10593          	addi	a1,sp,396
    a6f4:	02d00537          	lui	a0,0x2d00
    a6f8:	5724cc03          	lbu	s8,1394(s1) # 2d0f572 <__gpu_framebuffer_a+0xd0f572>
    a6fc:	97dfe0ef          	jal	9078 <v3_runtime_advance>
    a700:	00050d93          	mv	s11,a0
    a704:	900540e3          	bltz	a0,a004 <v3_demo_run+0x544>
    a708:	5724c703          	lbu	a4,1394(s1)
    a70c:	a60c1ae3          	bnez	s8,a180 <v3_demo_run+0x6c0>
    a710:	00100793          	li	a5,1
    a714:	a6f716e3          	bne	a4,a5,a180 <v3_demo_run+0x6c0>
    a718:	00000613          	li	a2,0
    a71c:	18c10593          	addi	a1,sp,396
    a720:	02d00537          	lui	a0,0x2d00
    a724:	955fe0ef          	jal	9078 <v3_runtime_advance>
    a728:	00050d93          	mv	s11,a0
    a72c:	00000a93          	li	s5,0
    a730:	a40ddae3          	bgez	s11,a184 <v3_demo_run+0x6c4>
    a734:	8d1ff06f          	j	a004 <v3_demo_run+0x544>
    a738:	0000d5b7          	lui	a1,0xd
    a73c:	60458593          	addi	a1,a1,1540 # d604 <_data+0x358>
    a740:	ac9ff06f          	j	a208 <v3_demo_run+0x748>
    a744:	03c12783          	lw	a5,60(sp)
    a748:	05012683          	lw	a3,80(sp)
    a74c:	004d2703          	lw	a4,4(s10)
    a750:	96f6e0e3          	bltu	a3,a5,a0b0 <v3_demo_run+0x5f0>
    a754:	ffe007b7          	lui	a5,0xffe00
    a758:	fff78793          	addi	a5,a5,-1 # ffdfffff <__gpu_framebuffer_a+0xfddfffff>
    a75c:	00f777b3          	and	a5,a4,a5
    a760:	020006b7          	lui	a3,0x2000
    a764:	94d796e3          	bne	a5,a3,a0b0 <v3_demo_run+0x5f0>
    a768:	03c12683          	lw	a3,60(sp)
    a76c:	02b227b7          	lui	a5,0x2b22
    a770:	c0078793          	addi	a5,a5,-1024 # 2b21c00 <__gpu_framebuffer_a+0xb21c00>
    a774:	00068663          	beqz	a3,a780 <v3_demo_run+0xcc0>
    a778:	029227b7          	lui	a5,0x2922
    a77c:	c0078793          	addi	a5,a5,-1024 # 2921c00 <__gpu_framebuffer_a+0x921c00>
    a780:	1af12e23          	sw	a5,444(sp)
    a784:	000227b7          	lui	a5,0x22
    a788:	c0078793          	addi	a5,a5,-1024 # 21c00 <__freertos_irq_stack_top+0x4160>
    a78c:	00f70733          	add	a4,a4,a5
    a790:	78000793          	li	a5,1920
    a794:	1cf12223          	sw	a5,452(sp)
    a798:	1cf12423          	sw	a5,456(sp)
    a79c:	03412503          	lw	a0,52(sp)
    a7a0:	3c000793          	li	a5,960
    a7a4:	1cf11623          	sh	a5,460(sp)
    a7a8:	00989637          	lui	a2,0x989
    a7ac:	1d400793          	li	a5,468
    a7b0:	1c012c23          	sw	zero,472(sp)
    a7b4:	1cf11723          	sh	a5,462(sp)
    a7b8:	12210693          	addi	a3,sp,290
    a7bc:	00200793          	li	a5,2
    a7c0:	68060613          	addi	a2,a2,1664 # 989680 <__freertos_irq_stack_top+0x96bbe0>
    a7c4:	1bc10593          	addi	a1,sp,444
    a7c8:	1c012823          	sw	zero,464(sp)
    a7cc:	1c012a23          	sw	zero,468(sp)
    a7d0:	1ce12023          	sw	a4,448(sp)
    a7d4:	1cf10c23          	sb	a5,472(sp)
    a7d8:	eb0f70ef          	jal	1e88 <gpu_submit>
    a7dc:	00050d93          	mv	s11,a0
    a7e0:	aa0504e3          	beqz	a0,a288 <v3_demo_run+0x7c8>
    a7e4:	821ff06f          	j	a004 <v3_demo_run+0x544>
    a7e8:	00000b13          	li	s6,0
    a7ec:	aa1ff06f          	j	a28c <v3_demo_run+0x7cc>
    a7f0:	07412783          	lw	a5,116(sp)
    a7f4:	02078a63          	beqz	a5,a828 <v3_demo_run+0xd68>
    a7f8:	00100793          	li	a5,1
    a7fc:	02fa0663          	beq	s4,a5,a828 <v3_demo_run+0xd68>
    a800:	03c12603          	lw	a2,60(sp)
    a804:	12410813          	addi	a6,sp,292
    a808:	00040793          	mv	a5,s0
    a80c:	02d20737          	lui	a4,0x2d20
    a810:	00100693          	li	a3,1
    a814:	02d00537          	lui	a0,0x2d00
    a818:	8b8ff0ef          	jal	98d0 <v3_build_gpu_scene>
    a81c:	00050d93          	mv	s11,a0
    a820:	a8050ee3          	beqz	a0,a2bc <v3_demo_run+0x7fc>
    a824:	fe0ff06f          	j	a004 <v3_demo_run+0x544>
    a828:	03c12603          	lw	a2,60(sp)
    a82c:	00040793          	mv	a5,s0
    a830:	48900713          	li	a4,1161
    a834:	00100693          	li	a3,1
    a838:	02d00537          	lui	a0,0x2d00
    a83c:	919fd0ef          	jal	8154 <game_build>
    a840:	00050d93          	mv	s11,a0
    a844:	fc051063          	bnez	a0,a004 <v3_demo_run+0x544>
    a848:	00100793          	li	a5,1
    a84c:	a6fa08e3          	beq	s4,a5,a2bc <v3_demo_run+0x7fc>
    a850:	04800593          	li	a1,72
    a854:	00040513          	mv	a0,s0
    a858:	ec5fb0ef          	jal	671c <bullet_clip_background_for_hud>
    a85c:	fc1ff06f          	j	a81c <v3_demo_run+0xd5c>
    a860:	00000793          	li	a5,0
    a864:	aa5ff06f          	j	a308 <v3_demo_run+0x848>
    a868:	02048e63          	beqz	s1,a8a4 <v3_demo_run+0xde4>
    a86c:	004d2683          	lw	a3,4(s10)
    a870:	02d0f737          	lui	a4,0x2d0f
    a874:	03812803          	lw	a6,56(sp)
    a878:	14214783          	lbu	a5,322(sp)
    a87c:	57c72703          	lw	a4,1404(a4) # 2d0f57c <__gpu_framebuffer_a+0xd0f57c>
    a880:	03412503          	lw	a0,52(sp)
    a884:	fe000637          	lui	a2,0xfe000
    a888:	00c68633          	add	a2,a3,a2
    a88c:	009898b7          	lui	a7,0x989
    a890:	68088893          	addi	a7,a7,1664 # 989680 <__freertos_irq_stack_top+0x96bbe0>
    a894:	00c03633          	snez	a2,a2
    a898:	1a410593          	addi	a1,sp,420
    a89c:	1cd000ef          	jal	b268 <game_menu_draw>
    a8a0:	a9dff06f          	j	a33c <v3_demo_run+0x87c>
    a8a4:	00100793          	li	a5,1
    a8a8:	00fa1e63          	bne	s4,a5,a8c4 <v3_demo_run+0xe04>
    a8ac:	000097b7          	lui	a5,0x9
    a8b0:	00f407b3          	add	a5,s0,a5
    a8b4:	1207a583          	lw	a1,288(a5) # 9120 <v3_runtime_advance+0xa8>
    a8b8:	00040513          	mv	a0,s0
    a8bc:	8e8fa0ef          	jal	49a4 <perf_render_cpu>
    a8c0:	a7dff06f          	j	a33c <v3_demo_run+0x87c>
    a8c4:	0a0b0663          	beqz	s6,a970 <v3_demo_run+0xeb0>
    a8c8:	12215583          	lhu	a1,290(sp)
    a8cc:	ff800d93          	li	s11,-8
    a8d0:	a60408e3          	beqz	s0,a340 <v3_demo_run+0x880>
    a8d4:	000097b7          	lui	a5,0x9
    a8d8:	00f407b3          	add	a5,s0,a5
    a8dc:	1207a783          	lw	a5,288(a5) # 9120 <v3_runtime_advance+0xa8>
    a8e0:	48800713          	li	a4,1160
    a8e4:	fff78613          	addi	a2,a5,-1
    a8e8:	a4c76ce3          	bltu	a4,a2,a340 <v3_demo_run+0x880>
    a8ec:	01c44683          	lbu	a3,28(s0)
    a8f0:	00200713          	li	a4,2
    a8f4:	a4e696e3          	bne	a3,a4,a340 <v3_demo_run+0x880>
    a8f8:	01845703          	lhu	a4,24(s0)
    a8fc:	a40712e3          	bnez	a4,a340 <v3_demo_run+0x880>
    a900:	00042683          	lw	a3,0(s0)
    a904:	1bc12703          	lw	a4,444(sp)
    a908:	a2e69ce3          	bne	a3,a4,a340 <v3_demo_run+0x880>
    a90c:	00442683          	lw	a3,4(s0)
    a910:	1c012703          	lw	a4,448(sp)
    a914:	a2e696e3          	bne	a3,a4,a340 <v3_demo_run+0x880>
    a918:	00842683          	lw	a3,8(s0)
    a91c:	1c412703          	lw	a4,452(sp)
    a920:	a2e690e3          	bne	a3,a4,a340 <v3_demo_run+0x880>
    a924:	00c42683          	lw	a3,12(s0)
    a928:	1c812703          	lw	a4,456(sp)
    a92c:	a0e69ae3          	bne	a3,a4,a340 <v3_demo_run+0x880>
    a930:	01042683          	lw	a3,16(s0)
    a934:	1cc12703          	lw	a4,460(sp)
    a938:	a0e694e3          	bne	a3,a4,a340 <v3_demo_run+0x880>
    a93c:	00100713          	li	a4,1
    a940:	00e78e63          	beq	a5,a4,a95c <v3_demo_run+0xe9c>
    a944:	009896b7          	lui	a3,0x989
    a948:	68068693          	addi	a3,a3,1664 # 989680 <__freertos_irq_stack_top+0x96bbe0>
    a94c:	02040593          	addi	a1,s0,32
    a950:	03412503          	lw	a0,52(sp)
    a954:	a64fa0ef          	jal	4bb8 <perf_render_gpu>
    a958:	9e5ff06f          	j	a33c <v3_demo_run+0x87c>
    a95c:	03412503          	lw	a0,52(sp)
    a960:	00989637          	lui	a2,0x989
    a964:	68060613          	addi	a2,a2,1664 # 989680 <__freertos_irq_stack_top+0x96bbe0>
    a968:	a61f70ef          	jal	23c8 <gpu_wait_tag>
    a96c:	9d1ff06f          	j	a33c <v3_demo_run+0x87c>
    a970:	000097b7          	lui	a5,0x9
    a974:	00f407b3          	add	a5,s0,a5
    a978:	009896b7          	lui	a3,0x989
    a97c:	1207a603          	lw	a2,288(a5) # 9120 <v3_runtime_advance+0xa8>
    a980:	68068693          	addi	a3,a3,1664 # 989680 <__freertos_irq_stack_top+0x96bbe0>
    a984:	00040593          	mv	a1,s0
    a988:	fc9ff06f          	j	a950 <v3_demo_run+0xe90>
    a98c:	04da1863          	bne	s4,a3,a9dc <v3_demo_run+0xf1c>
    a990:	03812603          	lw	a2,56(sp)
    a994:	04c12583          	lw	a1,76(sp)
    a998:	1dc10513          	addi	a0,sp,476
    a99c:	820f90ef          	jal	39bc <hud_update_cache>
    a9a0:	00050d93          	mv	s11,a0
    a9a4:	e6051063          	bnez	a0,a004 <v3_demo_run+0x544>
    a9a8:	ea5f60ef          	jal	184c <gpu_platform_sync>
    a9ac:	03812603          	lw	a2,56(sp)
    a9b0:	04c12583          	lw	a1,76(sp)
    a9b4:	004d2503          	lw	a0,4(s10)
    a9b8:	a68f90ef          	jal	3c20 <hud_cached_command>
    a9bc:	00050d93          	mv	s11,a0
    a9c0:	e4051263          	bnez	a0,a004 <v3_demo_run+0x544>
    a9c4:	00100793          	li	a5,1
    a9c8:	02fa1a63          	bne	s4,a5,a9fc <v3_demo_run+0xf3c>
    a9cc:	03812503          	lw	a0,56(sp)
    a9d0:	00100593          	li	a1,1
    a9d4:	fd1f90ef          	jal	49a4 <perf_render_cpu>
    a9d8:	b09ff06f          	j	a4e0 <v3_demo_run+0xa20>
    a9dc:	03812683          	lw	a3,56(sp)
    a9e0:	04c12603          	lw	a2,76(sp)
    a9e4:	03412503          	lw	a0,52(sp)
    a9e8:	00989737          	lui	a4,0x989
    a9ec:	68070713          	addi	a4,a4,1664 # 989680 <__freertos_irq_stack_top+0x96bbe0>
    a9f0:	1dc10593          	addi	a1,sp,476
    a9f4:	e9cf90ef          	jal	4090 <hud_update_gpu_cache>
    a9f8:	fa9ff06f          	j	a9a0 <v3_demo_run+0xee0>
    a9fc:	03812583          	lw	a1,56(sp)
    aa00:	03412503          	lw	a0,52(sp)
    aa04:	009896b7          	lui	a3,0x989
    aa08:	68068693          	addi	a3,a3,1664 # 989680 <__freertos_irq_stack_top+0x96bbe0>
    aa0c:	00100613          	li	a2,1
    aa10:	9a8fa0ef          	jal	4bb8 <perf_render_gpu>
    aa14:	acdff06f          	j	a4e0 <v3_demo_run+0xa20>
    aa18:	06412703          	lw	a4,100(sp)
    aa1c:	01d00793          	li	a5,29
    aa20:	10e7fe63          	bgeu	a5,a4,ab3c <v3_demo_run+0x107c>
    aa24:	05412683          	lw	a3,84(sp)
    aa28:	000097b7          	lui	a5,0x9
    aa2c:	00f407b3          	add	a5,s0,a5
    aa30:	1247a703          	lw	a4,292(a5) # 9124 <v3_runtime_advance+0xac>
    aa34:	12c7a783          	lw	a5,300(a5)
    aa38:	00069663          	bnez	a3,aa44 <v3_demo_run+0xf84>
    aa3c:	06f12823          	sw	a5,112(sp)
    aa40:	06e12423          	sw	a4,104(sp)
    aa44:	05412683          	lw	a3,84(sp)
    aa48:	09012603          	lw	a2,144(sp)
    aa4c:	00168693          	addi	a3,a3,1
    aa50:	04d12a23          	sw	a3,84(sp)
    aa54:	001976b7          	lui	a3,0x197
    aa58:	e6a68693          	addi	a3,a3,-406 # 196e6a <__freertos_irq_stack_top+0x1793ca>
    aa5c:	0176b6b3          	sltu	a3,a3,s7
    aa60:	00d606b3          	add	a3,a2,a3
    aa64:	08d12823          	sw	a3,144(sp)
    aa68:	0a812603          	lw	a2,168(sp)
    aa6c:	002626b7          	lui	a3,0x262
    aa70:	5a068693          	addi	a3,a3,1440 # 2625a0 <__freertos_irq_stack_top+0x244b00>
    aa74:	0126b6b3          	sltu	a3,a3,s2
    aa78:	00d606b3          	add	a3,a2,a3
    aa7c:	0ad12423          	sw	a3,168(sp)
    aa80:	08012683          	lw	a3,128(sp)
    aa84:	08012603          	lw	a2,128(sp)
    aa88:	017686b3          	add	a3,a3,s7
    aa8c:	00c6b633          	sltu	a2,a3,a2
    aa90:	08d12023          	sw	a3,128(sp)
    aa94:	0b812683          	lw	a3,184(sp)
    aa98:	00d606b3          	add	a3,a2,a3
    aa9c:	0ad12c23          	sw	a3,184(sp)
    aaa0:	08412683          	lw	a3,132(sp)
    aaa4:	08412603          	lw	a2,132(sp)
    aaa8:	012686b3          	add	a3,a3,s2
    aaac:	00c6b633          	sltu	a2,a3,a2
    aab0:	08d12223          	sw	a3,132(sp)
    aab4:	0bc12683          	lw	a3,188(sp)
    aab8:	00d606b3          	add	a3,a2,a3
    aabc:	0ad12e23          	sw	a3,188(sp)
    aac0:	04812603          	lw	a2,72(sp)
    aac4:	08812683          	lw	a3,136(sp)
    aac8:	00c686b3          	add	a3,a3,a2
    aacc:	08812603          	lw	a2,136(sp)
    aad0:	08d12423          	sw	a3,136(sp)
    aad4:	00c6b633          	sltu	a2,a3,a2
    aad8:	0c012683          	lw	a3,192(sp)
    aadc:	00d606b3          	add	a3,a2,a3
    aae0:	0cd12023          	sw	a3,192(sp)
    aae4:	0ac12683          	lw	a3,172(sp)
    aae8:	0176f463          	bgeu	a3,s7,aaf0 <v3_demo_run+0x1030>
    aaec:	0b712623          	sw	s7,172(sp)
    aaf0:	09412683          	lw	a3,148(sp)
    aaf4:	0126f463          	bgeu	a3,s2,aafc <v3_demo_run+0x103c>
    aaf8:	09212a23          	sw	s2,148(sp)
    aafc:	09c12683          	lw	a3,156(sp)
    ab00:	04812603          	lw	a2,72(sp)
    ab04:	00c6f463          	bgeu	a3,a2,ab0c <v3_demo_run+0x104c>
    ab08:	08c12e23          	sw	a2,156(sp)
    ab0c:	06812683          	lw	a3,104(sp)
    ab10:	00d77463          	bgeu	a4,a3,ab18 <v3_demo_run+0x1058>
    ab14:	06e12423          	sw	a4,104(sp)
    ab18:	09812683          	lw	a3,152(sp)
    ab1c:	00e6f463          	bgeu	a3,a4,ab24 <v3_demo_run+0x1064>
    ab20:	08e12c23          	sw	a4,152(sp)
    ab24:	07012703          	lw	a4,112(sp)
    ab28:	00e7f463          	bgeu	a5,a4,ab30 <v3_demo_run+0x1070>
    ab2c:	06f12823          	sw	a5,112(sp)
    ab30:	0b012703          	lw	a4,176(sp)
    ab34:	00f77463          	bgeu	a4,a5,ab3c <v3_demo_run+0x107c>
    ab38:	0af12823          	sw	a5,176(sp)
    ab3c:	0001d737          	lui	a4,0x1d
    ab40:	80c70713          	addi	a4,a4,-2036 # 1c80c <work_samples>
    ab44:	3e810593          	addi	a1,sp,1000
    ab48:	00000693          	li	a3,0
    ab4c:	0480006f          	j	ab94 <v3_demo_run+0x10d4>
    ab50:	00a62023          	sw	a0,0(a2)
    ab54:	00088793          	mv	a5,a7
    ab58:	ffc60613          	addi	a2,a2,-4
    ab5c:	00078a63          	beqz	a5,ab70 <v3_demo_run+0x10b0>
    ab60:	ffc62503          	lw	a0,-4(a2)
    ab64:	00072803          	lw	a6,0(a4)
    ab68:	fff78893          	addi	a7,a5,-1
    ab6c:	fea862e3          	bltu	a6,a0,ab50 <v3_demo_run+0x1090>
    ab70:	00279793          	slli	a5,a5,0x2
    ab74:	0f010613          	addi	a2,sp,240
    ab78:	45078793          	addi	a5,a5,1104
    ab7c:	00c787b3          	add	a5,a5,a2
    ab80:	00072603          	lw	a2,0(a4)
    ab84:	00168693          	addi	a3,a3,1
    ab88:	00470713          	addi	a4,a4,4
    ab8c:	eac7a423          	sw	a2,-344(a5)
    ab90:	00458593          	addi	a1,a1,4
    ab94:	08da9263          	bne	s5,a3,ac18 <v3_demo_run+0x1158>
    ab98:	05812783          	lw	a5,88(sp)
    ab9c:	0b412703          	lw	a4,180(sp)
    aba0:	013787b3          	add	a5,a5,s3
    aba4:	40e787b3          	sub	a5,a5,a4
    aba8:	04f12c23          	sw	a5,88(sp)
    abac:	060a9c63          	bnez	s5,ac24 <v3_demo_run+0x1164>
    abb0:	00000b93          	li	s7,0
    abb4:	04012423          	sw	zero,72(sp)
    abb8:	a9dfe0ef          	jal	9654 <now_ms>
    abbc:	0a012783          	lw	a5,160(sp)
    abc0:	00050a13          	mv	s4,a0
    abc4:	40f50733          	sub	a4,a0,a5
    abc8:	0c700793          	li	a5,199
    abcc:	2ee7fe63          	bgeu	a5,a4,aec8 <v3_demo_run+0x1408>
    abd0:	f81007b7          	lui	a5,0xf8100
    abd4:	0cc12683          	lw	a3,204(sp)
    abd8:	3147ac03          	lw	s8,788(a5) # f8100314 <__gpu_framebuffer_a+0xf6100314>
    abdc:	00009737          	lui	a4,0x9
    abe0:	00e40733          	add	a4,s0,a4
    abe4:	12072783          	lw	a5,288(a4) # 9120 <v3_runtime_advance+0xa8>
    abe8:	12069463          	bnez	a3,ad10 <v3_demo_run+0x1250>
    abec:	00579793          	slli	a5,a5,0x5
    abf0:	00040713          	mv	a4,s0
    abf4:	008787b3          	add	a5,a5,s0
    abf8:	00000913          	li	s2,0
    abfc:	00300693          	li	a3,3
    ac00:	10e78e63          	beq	a5,a4,ad1c <v3_demo_run+0x125c>
    ac04:	01c74603          	lbu	a2,28(a4)
    ac08:	00d61463          	bne	a2,a3,ac10 <v3_demo_run+0x1150>
    ac0c:	00190913          	addi	s2,s2,1
    ac10:	02070713          	addi	a4,a4,32
    ac14:	fedff06f          	j	ac00 <v3_demo_run+0x1140>
    ac18:	00058613          	mv	a2,a1
    ac1c:	00068793          	mv	a5,a3
    ac20:	f3dff06f          	j	ab5c <v3_demo_run+0x109c>
    ac24:	05f00793          	li	a5,95
    ac28:	02fa87b3          	mul	a5,s5,a5
    ac2c:	06400713          	li	a4,100
    ac30:	04012423          	sw	zero,72(sp)
    ac34:	06378793          	addi	a5,a5,99
    ac38:	02e7d7b3          	divu	a5,a5,a4
    ac3c:	0f010713          	addi	a4,sp,240
    ac40:	fff78793          	addi	a5,a5,-1
    ac44:	00279793          	slli	a5,a5,0x2
    ac48:	45078793          	addi	a5,a5,1104
    ac4c:	00e787b3          	add	a5,a5,a4
    ac50:	ea87ab83          	lw	s7,-344(a5)
    ac54:	01e00793          	li	a5,30
    ac58:	f6fa90e3          	bne	s5,a5,abb8 <v3_demo_run+0x10f8>
    ac5c:	05f5e5b7          	lui	a1,0x5f5e
    ac60:	10058593          	addi	a1,a1,256 # 5f5e100 <__gpu_framebuffer_a+0x3f5e100>
    ac64:	17010513          	addi	a0,sp,368
    ac68:	898fa0ef          	jal	4d00 <perf_fps_x10>
    ac6c:	05f5e5b7          	lui	a1,0x5f5e
    ac70:	04a12223          	sw	a0,68(sp)
    ac74:	10058593          	addi	a1,a1,256 # 5f5e100 <__gpu_framebuffer_a+0x3f5e100>
    ac78:	17010513          	addi	a0,sp,368
    ac7c:	908fa0ef          	jal	4d84 <perf_render_us>
    ac80:	06a12623          	sw	a0,108(sp)
    ac84:	ba5f60ef          	jal	1828 <gpu_platform_cycles>
    ac88:	13c12583          	lw	a1,316(sp)
    ac8c:	02d05637          	lui	a2,0x2d05
    ac90:	01062783          	lw	a5,16(a2) # 2d05010 <__gpu_framebuffer_a+0xd05010>
    ac94:	00c62703          	lw	a4,12(a2)
    ac98:	00462603          	lw	a2,4(a2)
    ac9c:	00b12a23          	sw	a1,20(sp)
    aca0:	18c15583          	lhu	a1,396(sp)
    aca4:	000096b7          	lui	a3,0x9
    aca8:	00d406b3          	add	a3,s0,a3
    acac:	00b12823          	sw	a1,16(sp)
    acb0:	05c12583          	lw	a1,92(sp)
    acb4:	01712223          	sw	s7,4(sp)
    acb8:	04412883          	lw	a7,68(sp)
    acbc:	00b12623          	sw	a1,12(sp)
    acc0:	05812583          	lw	a1,88(sp)
    acc4:	00050913          	mv	s2,a0
    acc8:	0000e537          	lui	a0,0xe
    accc:	00b12423          	sw	a1,8(sp)
    acd0:	06c12583          	lw	a1,108(sp)
    acd4:	85450513          	addi	a0,a0,-1964 # d854 <_data+0x5a8>
    acd8:	00000a93          	li	s5,0
    acdc:	00b12023          	sw	a1,0(sp)
    ace0:	1246a803          	lw	a6,292(a3) # 9124 <v3_runtime_advance+0xac>
    ace4:	13412683          	lw	a3,308(sp)
    ace8:	00000593          	li	a1,0
    acec:	9b5fe0ef          	jal	96a0 <bsp_printf>
    acf0:	b39f60ef          	jal	1828 <gpu_platform_cycles>
    acf4:	412507b3          	sub	a5,a0,s2
    acf8:	01800613          	li	a2,24
    acfc:	00000593          	li	a1,0
    ad00:	17010513          	addi	a0,sp,368
    ad04:	04f12423          	sw	a5,72(sp)
    ad08:	d20f60ef          	jal	1228 <memset>
    ad0c:	eadff06f          	j	abb8 <v3_demo_run+0x10f8>
    ad10:	12c72903          	lw	s2,300(a4)
    ad14:	fff78793          	addi	a5,a5,-1
    ad18:	41278933          	sub	s2,a5,s2
    ad1c:	02d05737          	lui	a4,0x2d05
    ad20:	00472783          	lw	a5,4(a4) # 2d05004 <__gpu_framebuffer_a+0xd05004>
    ad24:	38f12223          	sw	a5,900(sp)
    ad28:	00000793          	li	a5,0
    ad2c:	00049463          	bnez	s1,ad34 <v3_demo_run+0x1274>
    ad30:	00872783          	lw	a5,8(a4)
    ad34:	38f12423          	sw	a5,904(sp)
    ad38:	000097b7          	lui	a5,0x9
    ad3c:	00f407b3          	add	a5,s0,a5
    ad40:	1247a783          	lw	a5,292(a5) # 9124 <v3_runtime_advance+0xac>
    ad44:	04412703          	lw	a4,68(sp)
    ad48:	38012a23          	sw	zero,916(sp)
    ad4c:	38f12623          	sw	a5,908(sp)
    ad50:	00a00793          	li	a5,10
    ad54:	02f707b3          	mul	a5,a4,a5
    ad58:	38f12823          	sw	a5,912(sp)
    ad5c:	00048463          	beqz	s1,ad64 <v3_demo_run+0x12a4>
    ad60:	0a012223          	sw	zero,164(sp)
    ad64:	0a412783          	lw	a5,164(sp)
    ad68:	00000513          	li	a0,0
    ad6c:	38f12c23          	sw	a5,920(sp)
    ad70:	02049863          	bnez	s1,ada0 <v3_demo_run+0x12e0>
    ad74:	2e812583          	lw	a1,744(sp)
    ad78:	2a012503          	lw	a0,672(sp)
    ad7c:	2ec12783          	lw	a5,748(sp)
    ad80:	2a412703          	lw	a4,676(sp)
    ad84:	40a58533          	sub	a0,a1,a0
    ad88:	00a5b5b3          	sltu	a1,a1,a0
    ad8c:	40e787b3          	sub	a5,a5,a4
    ad90:	06400613          	li	a2,100
    ad94:	00000693          	li	a3,0
    ad98:	40b785b3          	sub	a1,a5,a1
    ad9c:	3f1010ef          	jal	c98c <__udivdi3>
    ada0:	38a12e23          	sw	a0,924(sp)
    ada4:	00000513          	li	a0,0
    ada8:	02049863          	bnez	s1,add8 <v3_demo_run+0x1318>
    adac:	0d812783          	lw	a5,216(sp)
    adb0:	0f012703          	lw	a4,240(sp)
    adb4:	0f412683          	lw	a3,244(sp)
    adb8:	06400613          	li	a2,100
    adbc:	40e78533          	sub	a0,a5,a4
    adc0:	0e412703          	lw	a4,228(sp)
    adc4:	00a7b7b3          	sltu	a5,a5,a0
    adc8:	40d705b3          	sub	a1,a4,a3
    adcc:	40f585b3          	sub	a1,a1,a5
    add0:	00000693          	li	a3,0
    add4:	3b9010ef          	jal	c98c <__udivdi3>
    add8:	3aa12023          	sw	a0,928(sp)
    addc:	00048463          	beqz	s1,ade4 <v3_demo_run+0x1324>
    ade0:	00000b93          	li	s7,0
    ade4:	3d712a23          	sw	s7,980(sp)
    ade8:	00000513          	li	a0,0
    adec:	02049463          	bnez	s1,ae14 <v3_demo_run+0x1354>
    adf0:	10012783          	lw	a5,256(sp)
    adf4:	10412703          	lw	a4,260(sp)
    adf8:	06400613          	li	a2,100
    adfc:	40fb0533          	sub	a0,s6,a5
    ae00:	00ab37b3          	sltu	a5,s6,a0
    ae04:	40ec85b3          	sub	a1,s9,a4
    ae08:	00000693          	li	a3,0
    ae0c:	40f585b3          	sub	a1,a1,a5
    ae10:	37d010ef          	jal	c98c <__udivdi3>
    ae14:	05812783          	lw	a5,88(sp)
    ae18:	0d012703          	lw	a4,208(sp)
    ae1c:	04412683          	lw	a3,68(sp)
    ae20:	3af12c23          	sw	a5,952(sp)
    ae24:	03412783          	lw	a5,52(sp)
    ae28:	14214603          	lbu	a2,322(sp)
    ae2c:	03c12583          	lw	a1,60(sp)
    ae30:	0137c783          	lbu	a5,19(a5)
    ae34:	3ca12c23          	sw	a0,984(sp)
    ae38:	00d036b3          	snez	a3,a3
    ae3c:	3af12e23          	sw	a5,956(sp)
    ae40:	05c12783          	lw	a5,92(sp)
    ae44:	02d00537          	lui	a0,0x2d00
    ae48:	3f212223          	sw	s2,996(sp)
    ae4c:	3cf12023          	sw	a5,960(sp)
    ae50:	50412783          	lw	a5,1284(sp)
    ae54:	00fc07b3          	add	a5,s8,a5
    ae58:	40e787b3          	sub	a5,a5,a4
    ae5c:	0d412703          	lw	a4,212(sp)
    ae60:	40e787b3          	sub	a5,a5,a4
    ae64:	3cf12423          	sw	a5,968(sp)
    ae68:	13c12783          	lw	a5,316(sp)
    ae6c:	3cf12623          	sw	a5,972(sp)
    ae70:	000097b7          	lui	a5,0x9
    ae74:	00f407b3          	add	a5,s0,a5
    ae78:	12c7a703          	lw	a4,300(a5) # 912c <v3_runtime_advance+0xb4>
    ae7c:	1307a783          	lw	a5,304(a5)
    ae80:	3ce12e23          	sw	a4,988(sp)
    ae84:	3ef12023          	sw	a5,992(sp)
    ae88:	00000713          	li	a4,0
    ae8c:	00000793          	li	a5,0
    ae90:	dedfd0ef          	jal	8c7c <v3_runtime_status>
    ae94:	3ca12823          	sw	a0,976(sp)
    ae98:	000a0613          	mv	a2,s4
    ae9c:	37c10593          	addi	a1,sp,892
    aea0:	46010513          	addi	a0,sp,1120
    aea4:	999fc0ef          	jal	783c <nc_try_publish>
    aea8:	00050d93          	mv	s11,a0
    aeac:	94054c63          	bltz	a0,a004 <v3_demo_run+0x544>
    aeb0:	50412783          	lw	a5,1284(sp)
    aeb4:	0d812823          	sw	s8,208(sp)
    aeb8:	04012e23          	sw	zero,92(sp)
    aebc:	0cf12a23          	sw	a5,212(sp)
    aec0:	04012c23          	sw	zero,88(sp)
    aec4:	0b412023          	sw	s4,160(sp)
    aec8:	02d00537          	lui	a0,0x2d00
    aecc:	e74fe0ef          	jal	9540 <v3_runtime_frame_done>
    aed0:	00050d93          	mv	s11,a0
    aed4:	92051863          	bnez	a0,a004 <v3_demo_run+0x544>
    aed8:	06412783          	lw	a5,100(sp)
    aedc:	05412703          	lw	a4,84(sp)
    aee0:	00178793          	addi	a5,a5,1
    aee4:	06f12223          	sw	a5,100(sp)
    aee8:	000017b7          	lui	a5,0x1
    aeec:	e1078793          	addi	a5,a5,-496 # e10 <CUSTOM2+0xdb5>
    aef0:	12f71c63          	bne	a4,a5,b028 <v3_demo_run+0x1568>
    aef4:	02d0f6b7          	lui	a3,0x2d0f
    aef8:	5426c603          	lbu	a2,1346(a3) # 2d0f542 <__gpu_framebuffer_a+0xd0f542>
    aefc:	9a060a63          	beqz	a2,a0b0 <v3_demo_run+0x5f0>
    af00:	5406d703          	lhu	a4,1344(a3)
    af04:	25800793          	li	a5,600
    af08:	9af71463          	bne	a4,a5,a0b0 <v3_demo_run+0x5f0>
    af0c:	53c6a783          	lw	a5,1340(a3)
    af10:	5506a703          	lw	a4,1360(a3)
    af14:	5546d683          	lhu	a3,1364(a3)
    af18:	0000e537          	lui	a0,0xe
    af1c:	25800593          	li	a1,600
    af20:	8d050513          	addi	a0,a0,-1840 # d8d0 <_data+0x624>
    af24:	f7cfe0ef          	jal	96a0 <bsp_printf>
    af28:	09412503          	lw	a0,148(sp)
    af2c:	06400613          	li	a2,100
    af30:	00000693          	li	a3,0
    af34:	00000593          	li	a1,0
    af38:	255010ef          	jal	c98c <__udivdi3>
    af3c:	02a12e23          	sw	a0,60(sp)
    af40:	0ac12503          	lw	a0,172(sp)
    af44:	06400613          	li	a2,100
    af48:	00000693          	li	a3,0
    af4c:	00000593          	li	a1,0
    af50:	23d010ef          	jal	c98c <__udivdi3>
    af54:	0b812583          	lw	a1,184(sp)
    af58:	02a12c23          	sw	a0,56(sp)
    af5c:	08012503          	lw	a0,128(sp)
    af60:	00058637          	lui	a2,0x58
    af64:	e4060613          	addi	a2,a2,-448 # 57e40 <__freertos_irq_stack_top+0x3a3a0>
    af68:	00000693          	li	a3,0
    af6c:	221010ef          	jal	c98c <__udivdi3>
    af70:	08412603          	lw	a2,132(sp)
    af74:	0bc12683          	lw	a3,188(sp)
    af78:	02a12a23          	sw	a0,52(sp)
    af7c:	34600593          	li	a1,838
    af80:	30b8a537          	lui	a0,0x30b8a
    af84:	209010ef          	jal	c98c <__udivdi3>
    af88:	00050413          	mv	s0,a0
    af8c:	09c12503          	lw	a0,156(sp)
    af90:	06400613          	li	a2,100
    af94:	00000693          	li	a3,0
    af98:	00000593          	li	a1,0
    af9c:	1f1010ef          	jal	c98c <__udivdi3>
    afa0:	0c012583          	lw	a1,192(sp)
    afa4:	02a12023          	sw	a0,32(sp)
    afa8:	08812503          	lw	a0,136(sp)
    afac:	00058637          	lui	a2,0x58
    afb0:	e4060613          	addi	a2,a2,-448 # 57e40 <__freertos_irq_stack_top+0x3a3a0>
    afb4:	00000693          	li	a3,0
    afb8:	1d5010ef          	jal	c98c <__udivdi3>
    afbc:	0b012783          	lw	a5,176(sp)
    afc0:	09012883          	lw	a7,144(sp)
    afc4:	03c12803          	lw	a6,60(sp)
    afc8:	00f12c23          	sw	a5,24(sp)
    afcc:	07012783          	lw	a5,112(sp)
    afd0:	03412703          	lw	a4,52(sp)
    afd4:	00a12e23          	sw	a0,28(sp)
    afd8:	00f12a23          	sw	a5,20(sp)
    afdc:	09812783          	lw	a5,152(sp)
    afe0:	00012423          	sw	zero,8(sp)
    afe4:	00012223          	sw	zero,4(sp)
    afe8:	00f12823          	sw	a5,16(sp)
    afec:	06812783          	lw	a5,104(sp)
    aff0:	0000e537          	lui	a0,0xe
    aff4:	00040693          	mv	a3,s0
    aff8:	00f12623          	sw	a5,12(sp)
    affc:	0a812783          	lw	a5,168(sp)
    b000:	40000593          	li	a1,1024
    b004:	91050513          	addi	a0,a0,-1776 # d910 <_data+0x664>
    b008:	00f12023          	sw	a5,0(sp)
    b00c:	03812783          	lw	a5,56(sp)
    b010:	05412603          	lw	a2,84(sp)
    b014:	e8cfe0ef          	jal	96a0 <bsp_printf>
    b018:	0000e537          	lui	a0,0xe
    b01c:	9f050513          	addi	a0,a0,-1552 # d9f0 <_data+0x744>
    b020:	e80fe0ef          	jal	96a0 <bsp_printf>
    b024:	b35fe06f          	j	9b58 <v3_demo_run+0x98>
    b028:	0b312a23          	sw	s3,180(sp)
    b02c:	0c812b83          	lw	s7,200(sp)
    b030:	07c12483          	lw	s1,124(sp)
    b034:	0e012a03          	lw	s4,224(sp)
    b038:	07512023          	sw	s5,96(sp)
    b03c:	000b0913          	mv	s2,s6
    b040:	000c8993          	mv	s3,s9
    b044:	f3dfe06f          	j	9f80 <v3_demo_run+0x4c0>
    b048:	00050d93          	mv	s11,a0
    b04c:	fb9fe06f          	j	a004 <v3_demo_run+0x544>
    b050:	920a0863          	beqz	s4,a180 <v3_demo_run+0x6c0>
    b054:	02d0f7b7          	lui	a5,0x2d0f
    b058:	5777c703          	lbu	a4,1399(a5) # 2d0f577 <__gpu_framebuffer_a+0xd0f577>
    b05c:	00070663          	beqz	a4,b068 <v3_demo_run+0x15a8>
    b060:	5747c783          	lbu	a5,1396(a5)
    b064:	e4078463          	beqz	a5,a6ac <v3_demo_run+0xbec>
    b068:	04012a83          	lw	s5,64(sp)
    b06c:	918ff06f          	j	a184 <v3_demo_run+0x6c4>

0000b070 <fill>:
    b070:	000088b7          	lui	a7,0x8
    b074:	fe010113          	addi	sp,sp,-32
    b078:	011508b3          	add	a7,a0,a7
    b07c:	00812c23          	sw	s0,24(sp)
    b080:	00068413          	mv	s0,a3
    b084:	0008d683          	lhu	a3,0(a7) # 8000 <game_update_cached+0xd4>
    b088:	01212823          	sw	s2,16(sp)
    b08c:	00078913          	mv	s2,a5
    b090:	00168793          	addi	a5,a3,1
    b094:	00569693          	slli	a3,a3,0x5
    b098:	00912a23          	sw	s1,20(sp)
    b09c:	01312623          	sw	s3,12(sp)
    b0a0:	01412423          	sw	s4,8(sp)
    b0a4:	01512223          	sw	s5,4(sp)
    b0a8:	00112e23          	sw	ra,28(sp)
    b0ac:	00d506b3          	add	a3,a0,a3
    b0b0:	00058a13          	mv	s4,a1
    b0b4:	00060a93          	mv	s5,a2
    b0b8:	00f89023          	sh	a5,0(a7)
    b0bc:	00000593          	li	a1,0
    b0c0:	02000613          	li	a2,32
    b0c4:	00068513          	mv	a0,a3
    b0c8:	00070993          	mv	s3,a4
    b0cc:	00080493          	mv	s1,a6
    b0d0:	958f60ef          	jal	1228 <memset>
    b0d4:	3c000793          	li	a5,960
    b0d8:	02f40433          	mul	s0,s0,a5
    b0dc:	78000793          	li	a5,1920
    b0e0:	00f52623          	sw	a5,12(a0)
    b0e4:	00100793          	li	a5,1
    b0e8:	00f50e23          	sb	a5,28(a0)
    b0ec:	01c12083          	lw	ra,28(sp)
    b0f0:	01351823          	sh	s3,16(a0)
    b0f4:	01251923          	sh	s2,18(a0)
    b0f8:	00951a23          	sh	s1,20(a0)
    b0fc:	01012903          	lw	s2,16(sp)
    b100:	01540433          	add	s0,s0,s5
    b104:	00141413          	slli	s0,s0,0x1
    b108:	014405b3          	add	a1,s0,s4
    b10c:	01812403          	lw	s0,24(sp)
    b110:	00b52223          	sw	a1,4(a0)
    b114:	01412483          	lw	s1,20(sp)
    b118:	00c12983          	lw	s3,12(sp)
    b11c:	00812a03          	lw	s4,8(sp)
    b120:	00412a83          	lw	s5,4(sp)
    b124:	02010113          	addi	sp,sp,32
    b128:	00008067          	ret

0000b12c <text>:
    b12c:	fd010113          	addi	sp,sp,-48
    b130:	03212023          	sw	s2,32(sp)
    b134:	01812423          	sw	s8,8(sp)
    b138:	01912223          	sw	s9,4(sp)
    b13c:	02112623          	sw	ra,44(sp)
    b140:	02812423          	sw	s0,40(sp)
    b144:	02912223          	sw	s1,36(sp)
    b148:	01312e23          	sw	s3,28(sp)
    b14c:	01412c23          	sw	s4,24(sp)
    b150:	01512a23          	sw	s5,20(sp)
    b154:	01612823          	sw	s6,16(sp)
    b158:	01712623          	sw	s7,12(sp)
    b15c:	01a12023          	sw	s10,0(sp)
    b160:	0017f793          	andi	a5,a5,1
    b164:	00050913          	mv	s2,a0
    b168:	00070c13          	mv	s8,a4
    b16c:	02c40cb7          	lui	s9,0x2c40
    b170:	00078663          	beqz	a5,b17c <text+0x50>
    b174:	02c45cb7          	lui	s9,0x2c45
    b178:	cc8c8c93          	addi	s9,s9,-824 # 2c44cc8 <__gpu_framebuffer_a+0xc44cc8>
    b17c:	3c000793          	li	a5,960
    b180:	02f68433          	mul	s0,a3,a5
    b184:	000089b7          	lui	s3,0x8
    b188:	00120d37          	lui	s10,0x120
    b18c:	0000da37          	lui	s4,0xd
    b190:	013909b3          	add	s3,s2,s3
    b194:	1f800a93          	li	s5,504
    b198:	01c00b13          	li	s6,28
    b19c:	78000b93          	li	s7,1920
    b1a0:	00ed0d13          	addi	s10,s10,14 # 12000e <__freertos_irq_stack_top+0x10256e>
    b1a4:	00c40433          	add	s0,s0,a2
    b1a8:	00141413          	slli	s0,s0,0x1
    b1ac:	00b40433          	add	s0,s0,a1
    b1b0:	000c4583          	lbu	a1,0(s8)
    b1b4:	02059e63          	bnez	a1,b1f0 <text+0xc4>
    b1b8:	02c12083          	lw	ra,44(sp)
    b1bc:	02812403          	lw	s0,40(sp)
    b1c0:	02412483          	lw	s1,36(sp)
    b1c4:	02012903          	lw	s2,32(sp)
    b1c8:	01c12983          	lw	s3,28(sp)
    b1cc:	01812a03          	lw	s4,24(sp)
    b1d0:	01412a83          	lw	s5,20(sp)
    b1d4:	01012b03          	lw	s6,16(sp)
    b1d8:	00c12b83          	lw	s7,12(sp)
    b1dc:	00812c03          	lw	s8,8(sp)
    b1e0:	00412c83          	lw	s9,4(sp)
    b1e4:	00012d03          	lw	s10,0(sp)
    b1e8:	03010113          	addi	sp,sp,48
    b1ec:	00008067          	ret
    b1f0:	550a0513          	addi	a0,s4,1360 # d550 <_data+0x2a4>
    b1f4:	ef5f50ef          	jal	10e8 <strchr>
    b1f8:	02600493          	li	s1,38
    b1fc:	00050663          	beqz	a0,b208 <text+0xdc>
    b200:	550a0493          	addi	s1,s4,1360
    b204:	409504b3          	sub	s1,a0,s1
    b208:	035484b3          	mul	s1,s1,s5
    b20c:	0009d783          	lhu	a5,0(s3) # 8000 <game_update_cached+0xd4>
    b210:	02000613          	li	a2,32
    b214:	00000593          	li	a1,0
    b218:	00178713          	addi	a4,a5,1
    b21c:	00579793          	slli	a5,a5,0x5
    b220:	00f907b3          	add	a5,s2,a5
    b224:	00e99023          	sh	a4,0(s3)
    b228:	00078513          	mv	a0,a5
    b22c:	ffdf50ef          	jal	1228 <memset>
    b230:	019484b3          	add	s1,s1,s9
    b234:	00200713          	li	a4,2
    b238:	00852223          	sw	s0,4(a0)
    b23c:	00952023          	sw	s1,0(a0)
    b240:	01652423          	sw	s6,8(a0)
    b244:	01752623          	sw	s7,12(a0)
    b248:	01a52823          	sw	s10,16(a0)
    b24c:	00e50e23          	sb	a4,28(a0)
    b250:	001c0c13          	addi	s8,s8,1
    b254:	01c40413          	addi	s0,s0,28
    b258:	f59ff06f          	j	b1b0 <text+0x84>

0000b25c <game_menu_invalidate>:
    b25c:	00050463          	beqz	a0,b264 <game_menu_invalidate+0x8>
    b260:	00050823          	sb	zero,16(a0)
    b264:	00008067          	ret

0000b268 <game_menu_draw>:
    b268:	f4010113          	addi	sp,sp,-192
    b26c:	0a112e23          	sw	ra,188(sp)
    b270:	0a812c23          	sw	s0,184(sp)
    b274:	0a912a23          	sw	s1,180(sp)
    b278:	0b212823          	sw	s2,176(sp)
    b27c:	0b312623          	sw	s3,172(sp)
    b280:	0b412423          	sw	s4,168(sp)
    b284:	0b512223          	sw	s5,164(sp)
    b288:	0b612023          	sw	s6,160(sp)
    b28c:	09712e23          	sw	s7,156(sp)
    b290:	09812c23          	sw	s8,152(sp)
    b294:	09912a23          	sw	s9,148(sp)
    b298:	09a12823          	sw	s10,144(sp)
    b29c:	09b12623          	sw	s11,140(sp)
    b2a0:	00a12023          	sw	a0,0(sp)
    b2a4:	00e12423          	sw	a4,8(sp)
    b2a8:	00f12623          	sw	a5,12(sp)
    b2ac:	01112223          	sw	a7,4(sp)
    b2b0:	40050663          	beqz	a0,b6bc <game_menu_draw+0x454>
    b2b4:	01054783          	lbu	a5,16(a0)
    b2b8:	ff800513          	li	a0,-8
    b2bc:	32078463          	beqz	a5,b5e4 <game_menu_draw+0x37c>
    b2c0:	00058913          	mv	s2,a1
    b2c4:	32058063          	beqz	a1,b5e4 <game_menu_draw+0x37c>
    b2c8:	00080413          	mv	s0,a6
    b2cc:	30080c63          	beqz	a6,b5e4 <game_menu_draw+0x37c>
    b2d0:	00100793          	li	a5,1
    b2d4:	00060993          	mv	s3,a2
    b2d8:	30c7e663          	bltu	a5,a2,b5e4 <game_menu_draw+0x37c>
    b2dc:	30088463          	beqz	a7,b5e4 <game_menu_draw+0x37c>
    b2e0:	00068493          	mv	s1,a3
    b2e4:	020007b7          	lui	a5,0x2000
    b2e8:	00060463          	beqz	a2,b2f0 <game_menu_draw+0x88>
    b2ec:	022007b7          	lui	a5,0x2200
    b2f0:	ff800513          	li	a0,-8
    b2f4:	2e979863          	bne	a5,s1,b5e4 <game_menu_draw+0x37c>
    b2f8:	01494783          	lbu	a5,20(s2)
    b2fc:	0fb7f713          	andi	a4,a5,251
    b300:	00070663          	beqz	a4,b30c <game_menu_draw+0xa4>
    b304:	00600713          	li	a4,6
    b308:	2ce79e63          	bne	a5,a4,b5e4 <game_menu_draw+0x37c>
    b30c:	00c12703          	lw	a4,12(sp)
    b310:	00100a13          	li	s4,1
    b314:	013a1a33          	sll	s4,s4,s3
    b318:	00e03c33          	snez	s8,a4
    b31c:	00600713          	li	a4,6
    b320:	0ffa7a13          	zext.b	s4,s4
    b324:	00400a93          	li	s5,4
    b328:	00e79463          	bne	a5,a4,b330 <game_menu_draw+0xc8>
    b32c:	00600a93          	li	s5,6
    b330:	01094783          	lbu	a5,16(s2)
    b334:	0147f733          	and	a4,a5,s4
    b338:	2e071463          	bnez	a4,b620 <game_menu_draw+0x3b8>
    b33c:	00008737          	lui	a4,0x8
    b340:	00e40733          	add	a4,s0,a4
    b344:	00071023          	sh	zero,0(a4) # 8000 <game_update_cached+0xd4>
    b348:	00100713          	li	a4,1
    b34c:	fffa4693          	not	a3,s4
    b350:	00d7f7b3          	and	a5,a5,a3
    b354:	00f90823          	sb	a5,16(s2)
    b358:	1e070663          	beqz	a4,b544 <game_menu_draw+0x2dc>
    b35c:	00000813          	li	a6,0
    b360:	1d400793          	li	a5,468
    b364:	3c000713          	li	a4,960
    b368:	04800693          	li	a3,72
    b36c:	00000613          	li	a2,0
    b370:	00048593          	mv	a1,s1
    b374:	00040513          	mv	a0,s0
    b378:	cf9ff0ef          	jal	b070 <fill>
    b37c:	0000e737          	lui	a4,0xe
    b380:	00100793          	li	a5,1
    b384:	a5870713          	addi	a4,a4,-1448 # da58 <_data+0x7ac>
    b388:	06000693          	li	a3,96
    b38c:	10e00613          	li	a2,270
    b390:	00048593          	mv	a1,s1
    b394:	00040513          	mv	a0,s0
    b398:	d95ff0ef          	jal	b12c <text>
    b39c:	0000e5b7          	lui	a1,0xe
    b3a0:	41c58b93          	addi	s7,a1,1052 # e41c <counts.0+0x18>
    b3a4:	01800613          	li	a2,24
    b3a8:	41c58593          	addi	a1,a1,1052
    b3ac:	03810513          	addi	a0,sp,56
    b3b0:	f55f50ef          	jal	1304 <memcpy>
    b3b4:	01800613          	li	a2,24
    b3b8:	018b8593          	addi	a1,s7,24 # 5018 <bullet_enemy_position+0x60>
    b3bc:	05010513          	addi	a0,sp,80
    b3c0:	f45f50ef          	jal	1304 <memcpy>
    b3c4:	01000613          	li	a2,16
    b3c8:	030b8593          	addi	a1,s7,48
    b3cc:	02810513          	addi	a0,sp,40
    b3d0:	f35f50ef          	jal	1304 <memcpy>
    b3d4:	01800613          	li	a2,24
    b3d8:	040b8593          	addi	a1,s7,64
    b3dc:	06810513          	addi	a0,sp,104
    b3e0:	f25f50ef          	jal	1304 <memcpy>
    b3e4:	ffaa8793          	addi	a5,s5,-6
    b3e8:	0017b713          	seqz	a4,a5
    b3ec:	06800313          	li	t1,104
    b3f0:	00079463          	bnez	a5,b3f8 <game_menu_draw+0x190>
    b3f4:	05000313          	li	t1,80
    b3f8:	ffc30793          	addi	a5,t1,-4
    b3fc:	00f12823          	sw	a5,16(sp)
    b400:	26070463          	beqz	a4,b668 <game_menu_draw+0x400>
    b404:	00e00d93          	li	s11,14
    b408:	02e00d13          	li	s10,46
    b40c:	002a9e13          	slli	t3,s5,0x2
    b410:	00000b13          	li	s6,0
    b414:	00600e93          	li	t4,6
    b418:	05010793          	addi	a5,sp,80
    b41c:	01da8463          	beq	s5,t4,b424 <game_menu_draw+0x1bc>
    b420:	02810793          	addi	a5,sp,40
    b424:	016787b3          	add	a5,a5,s6
    b428:	0007ac83          	lw	s9,0(a5) # 2200000 <__gpu_framebuffer_a+0x200000>
    b42c:	03810793          	addi	a5,sp,56
    b430:	016787b3          	add	a5,a5,s6
    b434:	0007ab83          	lw	s7,0(a5)
    b438:	7e000813          	li	a6,2016
    b43c:	00030793          	mv	a5,t1
    b440:	17000713          	li	a4,368
    b444:	000c8693          	mv	a3,s9
    b448:	000b8613          	mv	a2,s7
    b44c:	00048593          	mv	a1,s1
    b450:	00040513          	mv	a0,s0
    b454:	01c12e23          	sw	t3,28(sp)
    b458:	00612c23          	sw	t1,24(sp)
    b45c:	c15ff0ef          	jal	b070 <fill>
    b460:	01012783          	lw	a5,16(sp)
    b464:	00000813          	li	a6,0
    b468:	16c00713          	li	a4,364
    b46c:	002c8693          	addi	a3,s9,2
    b470:	002b8613          	addi	a2,s7,2
    b474:	00048593          	mv	a1,s1
    b478:	00040513          	mv	a0,s0
    b47c:	bf5ff0ef          	jal	b070 <fill>
    b480:	06810793          	addi	a5,sp,104
    b484:	01678733          	add	a4,a5,s6
    b488:	00072703          	lw	a4,0(a4)
    b48c:	010b8613          	addi	a2,s7,16
    b490:	00000793          	li	a5,0
    b494:	019d86b3          	add	a3,s11,s9
    b498:	00048593          	mv	a1,s1
    b49c:	00040513          	mv	a0,s0
    b4a0:	00c12a23          	sw	a2,20(sp)
    b4a4:	c89ff0ef          	jal	b12c <text>
    b4a8:	01412603          	lw	a2,20(sp)
    b4ac:	0000e737          	lui	a4,0xe
    b4b0:	00100793          	li	a5,1
    b4b4:	a6c70713          	addi	a4,a4,-1428 # da6c <_data+0x7c0>
    b4b8:	019d06b3          	add	a3,s10,s9
    b4bc:	00048593          	mv	a1,s1
    b4c0:	00040513          	mv	a0,s0
    b4c4:	c69ff0ef          	jal	b12c <text>
    b4c8:	01c12e03          	lw	t3,28(sp)
    b4cc:	004b0b13          	addi	s6,s6,4
    b4d0:	01812303          	lw	t1,24(sp)
    b4d4:	00600e93          	li	t4,6
    b4d8:	f5cb10e3          	bne	s6,t3,b418 <game_menu_draw+0x1b0>
    b4dc:	01394783          	lbu	a5,19(s2)
    b4e0:	18078a63          	beqz	a5,b674 <game_menu_draw+0x40c>
    b4e4:	7e000813          	li	a6,2016
    b4e8:	03000793          	li	a5,48
    b4ec:	30000713          	li	a4,768
    b4f0:	19c00693          	li	a3,412
    b4f4:	06000613          	li	a2,96
    b4f8:	00048593          	mv	a1,s1
    b4fc:	00040513          	mv	a0,s0
    b500:	b71ff0ef          	jal	b070 <fill>
    b504:	02c00793          	li	a5,44
    b508:	2fc00713          	li	a4,764
    b50c:	19e00693          	li	a3,414
    b510:	06200613          	li	a2,98
    b514:	00000813          	li	a6,0
    b518:	00048593          	mv	a1,s1
    b51c:	00040513          	mv	a0,s0
    b520:	b51ff0ef          	jal	b070 <fill>
    b524:	0000e737          	lui	a4,0xe
    b528:	00100793          	li	a5,1
    b52c:	a7c70713          	addi	a4,a4,-1412 # da7c <_data+0x7d0>
    b530:	1aa00693          	li	a3,426
    b534:	06c00613          	li	a2,108
    b538:	00048593          	mv	a1,s1
    b53c:	00040513          	mv	a0,s0
    b540:	bedff0ef          	jal	b12c <text>
    b544:	01200793          	li	a5,18
    b548:	00000813          	li	a6,0
    b54c:	25800713          	li	a4,600
    b550:	1e000693          	li	a3,480
    b554:	06000613          	li	a2,96
    b558:	00048593          	mv	a1,s1
    b55c:	00040513          	mv	a0,s0
    b560:	b11ff0ef          	jal	b070 <fill>
    b564:	00c12783          	lw	a5,12(sp)
    b568:	12078263          	beqz	a5,b68c <game_menu_draw+0x424>
    b56c:	0000e737          	lui	a4,0xe
    b570:	a2c70713          	addi	a4,a4,-1492 # da2c <_data+0x780>
    b574:	000c0793          	mv	a5,s8
    b578:	1e000693          	li	a3,480
    b57c:	06000613          	li	a2,96
    b580:	00048593          	mv	a1,s1
    b584:	00040513          	mv	a0,s0
    b588:	00008cb7          	lui	s9,0x8
    b58c:	ba1ff0ef          	jal	b12c <text>
    b590:	00000b93          	li	s7,0
    b594:	06011423          	sh	zero,104(sp)
    b598:	01940cb3          	add	s9,s0,s9
    b59c:	000cd783          	lhu	a5,0(s9) # 8000 <game_update_cached+0xd4>
    b5a0:	0efbec63          	bltu	s7,a5,b698 <game_menu_draw+0x430>
    b5a4:	00412603          	lw	a2,4(sp)
    b5a8:	06815583          	lhu	a1,104(sp)
    b5ac:	00012503          	lw	a0,0(sp)
    b5b0:	e19f60ef          	jal	23c8 <gpu_wait_tag>
    b5b4:	02051863          	bnez	a0,b5e4 <game_menu_draw+0x37c>
    b5b8:	00812703          	lw	a4,8(sp)
    b5bc:	00299793          	slli	a5,s3,0x2
    b5c0:	00f907b3          	add	a5,s2,a5
    b5c4:	0097a023          	sw	s1,0(a5)
    b5c8:	00e7a423          	sw	a4,8(a5)
    b5cc:	013909b3          	add	s3,s2,s3
    b5d0:	018988a3          	sb	s8,17(s3)
    b5d4:	01598aa3          	sb	s5,21(s3)
    b5d8:	01094783          	lbu	a5,16(s2)
    b5dc:	00fa6a33          	or	s4,s4,a5
    b5e0:	01490823          	sb	s4,16(s2)
    b5e4:	0bc12083          	lw	ra,188(sp)
    b5e8:	0b812403          	lw	s0,184(sp)
    b5ec:	0b412483          	lw	s1,180(sp)
    b5f0:	0b012903          	lw	s2,176(sp)
    b5f4:	0ac12983          	lw	s3,172(sp)
    b5f8:	0a812a03          	lw	s4,168(sp)
    b5fc:	0a412a83          	lw	s5,164(sp)
    b600:	0a012b03          	lw	s6,160(sp)
    b604:	09c12b83          	lw	s7,156(sp)
    b608:	09812c03          	lw	s8,152(sp)
    b60c:	09412c83          	lw	s9,148(sp)
    b610:	09012d03          	lw	s10,144(sp)
    b614:	08c12d83          	lw	s11,140(sp)
    b618:	0c010113          	addi	sp,sp,192
    b61c:	00008067          	ret
    b620:	00299713          	slli	a4,s3,0x2
    b624:	00e90733          	add	a4,s2,a4
    b628:	00872683          	lw	a3,8(a4)
    b62c:	00812603          	lw	a2,8(sp)
    b630:	d0c696e3          	bne	a3,a2,b33c <game_menu_draw+0xd4>
    b634:	00072703          	lw	a4,0(a4)
    b638:	d09712e3          	bne	a4,s1,b33c <game_menu_draw+0xd4>
    b63c:	013906b3          	add	a3,s2,s3
    b640:	0156c703          	lbu	a4,21(a3)
    b644:	cf571ce3          	bne	a4,s5,b33c <game_menu_draw+0xd4>
    b648:	00008737          	lui	a4,0x8
    b64c:	00e40733          	add	a4,s0,a4
    b650:	00071023          	sh	zero,0(a4) # 8000 <game_update_cached+0xd4>
    b654:	0116c703          	lbu	a4,17(a3)
    b658:	00000513          	li	a0,0
    b65c:	f98704e3          	beq	a4,s8,b5e4 <game_menu_draw+0x37c>
    b660:	00000713          	li	a4,0
    b664:	ce9ff06f          	j	b34c <game_menu_draw+0xe4>
    b668:	01400d93          	li	s11,20
    b66c:	03800d13          	li	s10,56
    b670:	d9dff06f          	j	b40c <game_menu_draw+0x1a4>
    b674:	0000e737          	lui	a4,0xe
    b678:	00000793          	li	a5,0
    b67c:	aa070713          	addi	a4,a4,-1376 # daa0 <_data+0x7f4>
    b680:	1b400693          	li	a3,436
    b684:	06000613          	li	a2,96
    b688:	eb1ff06f          	j	b538 <game_menu_draw+0x2d0>
    b68c:	0000e737          	lui	a4,0xe
    b690:	a4070713          	addi	a4,a4,-1472 # da40 <_data+0x794>
    b694:	ee1ff06f          	j	b574 <game_menu_draw+0x30c>
    b698:	00412603          	lw	a2,4(sp)
    b69c:	00012503          	lw	a0,0(sp)
    b6a0:	005b9593          	slli	a1,s7,0x5
    b6a4:	06810693          	addi	a3,sp,104
    b6a8:	00b405b3          	add	a1,s0,a1
    b6ac:	fdcf60ef          	jal	1e88 <gpu_submit>
    b6b0:	f2051ae3          	bnez	a0,b5e4 <game_menu_draw+0x37c>
    b6b4:	001b8b93          	addi	s7,s7,1
    b6b8:	ee5ff06f          	j	b59c <game_menu_draw+0x334>
    b6bc:	ff800513          	li	a0,-8
    b6c0:	f25ff06f          	j	b5e4 <game_menu_draw+0x37c>

0000b6c4 <append>:
    b6c4:	00452303          	lw	t1,4(a0)
    b6c8:	00032e03          	lw	t3,0(t1)
    b6cc:	08be0263          	beq	t3,a1,b750 <append+0x8c>
    b6d0:	00052503          	lw	a0,0(a0)
    b6d4:	001e0593          	addi	a1,t3,1
    b6d8:	004e1e13          	slli	t3,t3,0x4
    b6dc:	00b32023          	sw	a1,0(t1)
    b6e0:	01c50533          	add	a0,a0,t3
    b6e4:	00e52423          	sw	a4,8(a0)
    b6e8:	01081713          	slli	a4,a6,0x10
    b6ec:	00f76733          	or	a4,a4,a5
    b6f0:	030787b3          	mul	a5,a5,a6
    b6f4:	fff60593          	addi	a1,a2,-1
    b6f8:	00e52623          	sw	a4,12(a0)
    b6fc:	0015b593          	seqz	a1,a1
    b700:	00c32703          	lw	a4,12(t1)
    b704:	01089893          	slli	a7,a7,0x10
    b708:	00859593          	slli	a1,a1,0x8
    b70c:	00c8e8b3          	or	a7,a7,a2
    b710:	0115e5b3          	or	a1,a1,a7
    b714:	00b52023          	sw	a1,0(a0)
    b718:	00f70733          	add	a4,a4,a5
    b71c:	00d52223          	sw	a3,4(a0)
    b720:	00e32623          	sw	a4,12(t1)
    b724:	00100713          	li	a4,1
    b728:	00e60663          	beq	a2,a4,b734 <append+0x70>
    b72c:	00000513          	li	a0,0
    b730:	00008067          	ret
    b734:	00832703          	lw	a4,8(t1)
    b738:	00170713          	addi	a4,a4,1
    b73c:	00e32423          	sw	a4,8(t1)
    b740:	01032703          	lw	a4,16(t1)
    b744:	00f707b3          	add	a5,a4,a5
    b748:	00f32823          	sw	a5,16(t1)
    b74c:	fe1ff06f          	j	b72c <append+0x68>
    b750:	ffc00513          	li	a0,-4
    b754:	00008067          	ret

0000b758 <clipped_sprite>:
    b758:	fa010113          	addi	sp,sp,-96
    b75c:	05512223          	sw	s5,68(sp)
    b760:	06412a83          	lw	s5,100(sp)
    b764:	04112e23          	sw	ra,92(sp)
    b768:	04812c23          	sw	s0,88(sp)
    b76c:	04912a23          	sw	s1,84(sp)
    b770:	05212823          	sw	s2,80(sp)
    b774:	05312623          	sw	s3,76(sp)
    b778:	05412423          	sw	s4,72(sp)
    b77c:	05612023          	sw	s6,64(sp)
    b780:	03712e23          	sw	s7,60(sp)
    b784:	03812c23          	sw	s8,56(sp)
    b788:	03912a23          	sw	s9,52(sp)
    b78c:	03a12823          	sw	s10,48(sp)
    b790:	03b12623          	sw	s11,44(sp)
    b794:	00d12823          	sw	a3,16(sp)
    b798:	00a12423          	sw	a0,8(sp)
    b79c:	00b12623          	sw	a1,12(sp)
    b7a0:	000aa023          	sw	zero,0(s5)
    b7a4:	3bf00693          	li	a3,959
    b7a8:	04e6d263          	bge	a3,a4,b7ec <clipped_sprite+0x94>
    b7ac:	00000513          	li	a0,0
    b7b0:	05c12083          	lw	ra,92(sp)
    b7b4:	05812403          	lw	s0,88(sp)
    b7b8:	05412483          	lw	s1,84(sp)
    b7bc:	05012903          	lw	s2,80(sp)
    b7c0:	04c12983          	lw	s3,76(sp)
    b7c4:	04812a03          	lw	s4,72(sp)
    b7c8:	04412a83          	lw	s5,68(sp)
    b7cc:	04012b03          	lw	s6,64(sp)
    b7d0:	03c12b83          	lw	s7,60(sp)
    b7d4:	03812c03          	lw	s8,56(sp)
    b7d8:	03412c83          	lw	s9,52(sp)
    b7dc:	03012d03          	lw	s10,48(sp)
    b7e0:	02c12d83          	lw	s11,44(sp)
    b7e4:	06010113          	addi	sp,sp,96
    b7e8:	00008067          	ret
    b7ec:	410006b3          	neg	a3,a6
    b7f0:	00080d93          	mv	s11,a6
    b7f4:	fae6dce3          	bge	a3,a4,b7ac <clipped_sprite+0x54>
    b7f8:	21b00693          	li	a3,539
    b7fc:	faf6c8e3          	blt	a3,a5,b7ac <clipped_sprite+0x54>
    b800:	04800593          	li	a1,72
    b804:	410586b3          	sub	a3,a1,a6
    b808:	faf6d2e3          	bge	a3,a5,b7ac <clipped_sprite+0x54>
    b80c:	00060c13          	mv	s8,a2
    b810:	40e006b3          	neg	a3,a4
    b814:	41f75613          	srai	a2,a4,0x1f
    b818:	00c6f933          	and	s2,a3,a2
    b81c:	04700613          	li	a2,71
    b820:	00000493          	li	s1,0
    b824:	00f64463          	blt	a2,a5,b82c <clipped_sprite+0xd4>
    b828:	40f584b3          	sub	s1,a1,a5
    b82c:	00070b13          	mv	s6,a4
    b830:	00075463          	bgez	a4,b838 <clipped_sprite+0xe0>
    b834:	00000b13          	li	s6,0
    b838:	00078413          	mv	s0,a5
    b83c:	04800793          	li	a5,72
    b840:	00f45463          	bge	s0,a5,b848 <clipped_sprite+0xf0>
    b844:	04800413          	li	s0,72
    b848:	3c000793          	li	a5,960
    b84c:	412d8733          	sub	a4,s11,s2
    b850:	416787b3          	sub	a5,a5,s6
    b854:	00f77463          	bgeu	a4,a5,b85c <clipped_sprite+0x104>
    b858:	00070793          	mv	a5,a4
    b85c:	21c00813          	li	a6,540
    b860:	409d8733          	sub	a4,s11,s1
    b864:	40880833          	sub	a6,a6,s0
    b868:	01077463          	bgeu	a4,a6,b870 <clipped_sprite+0x118>
    b86c:	00070813          	mv	a6,a4
    b870:	06012683          	lw	a3,96(sp)
    b874:	fff00713          	li	a4,-1
    b878:	04e69263          	bne	a3,a4,b8bc <clipped_sprite+0x164>
    b87c:	3c000313          	li	t1,960
    b880:	02640333          	mul	t1,s0,t1
    b884:	01012603          	lw	a2,16(sp)
    b888:	00c12583          	lw	a1,12(sp)
    b88c:	00812503          	lw	a0,8(sp)
    b890:	03b48733          	mul	a4,s1,s11
    b894:	01630333          	add	t1,t1,s6
    b898:	00131313          	slli	t1,t1,0x1
    b89c:	018306b3          	add	a3,t1,s8
    b8a0:	01270733          	add	a4,a4,s2
    b8a4:	00171713          	slli	a4,a4,0x1
    b8a8:	e1dff0ef          	jal	b6c4 <append>
    b8ac:	f00512e3          	bnez	a0,b7b0 <clipped_sprite+0x58>
    b8b0:	00100793          	li	a5,1
    b8b4:	00faa023          	sw	a5,0(s5)
    b8b8:	ef9ff06f          	j	b7b0 <clipped_sprite+0x58>
    b8bc:	00996bb3          	or	s7,s2,s1
    b8c0:	020b8263          	beqz	s7,b8e4 <clipped_sprite+0x18c>
    b8c4:	00048b93          	mv	s7,s1
    b8c8:	00000d13          	li	s10,0
    b8cc:	010489b3          	add	s3,s1,a6
    b8d0:	00f90a33          	add	s4,s2,a5
    b8d4:	073bf063          	bgeu	s7,s3,b934 <clipped_sprite+0x1dc>
    b8d8:	fa0d12e3          	bnez	s10,b87c <clipped_sprite+0x124>
    b8dc:	00090c93          	mv	s9,s2
    b8e0:	0400006f          	j	b920 <clipped_sprite+0x1c8>
    b8e4:	ffb7e2e3          	bltu	a5,s11,b8c8 <clipped_sprite+0x170>
    b8e8:	ffb860e3          	bltu	a6,s11,b8c8 <clipped_sprite+0x170>
    b8ec:	f91ff06f          	j	b87c <clipped_sprite+0x124>
    b8f0:	06012503          	lw	a0,96(sp)
    b8f4:	000b8613          	mv	a2,s7
    b8f8:	000c8593          	mv	a1,s9
    b8fc:	01112e23          	sw	a7,28(sp)
    b900:	01012c23          	sw	a6,24(sp)
    b904:	00f12a23          	sw	a5,20(sp)
    b908:	c94fa0ef          	jal	5d9c <bullet_shape_opaque>
    b90c:	01412783          	lw	a5,20(sp)
    b910:	01812803          	lw	a6,24(sp)
    b914:	01c12883          	lw	a7,28(sp)
    b918:	00051a63          	bnez	a0,b92c <clipped_sprite+0x1d4>
    b91c:	001c8c93          	addi	s9,s9,1
    b920:	fd4ce8e3          	bltu	s9,s4,b8f0 <clipped_sprite+0x198>
    b924:	001b8b93          	addi	s7,s7,1
    b928:	fadff06f          	j	b8d4 <clipped_sprite+0x17c>
    b92c:	00100d13          	li	s10,1
    b930:	ff5ff06f          	j	b924 <clipped_sprite+0x1cc>
    b934:	e60d0ce3          	beqz	s10,b7ac <clipped_sprite+0x54>
    b938:	f45ff06f          	j	b87c <clipped_sprite+0x124>

0000b93c <sprite>:
    b93c:	ff010113          	addi	sp,sp,-16
    b940:	3c000393          	li	t2,960
    b944:	00812423          	sw	s0,8(sp)
    b948:	00912223          	sw	s1,4(sp)
    b94c:	00112623          	sw	ra,12(sp)
    b950:	41038fb3          	sub	t6,t2,a6
    b954:	00068e93          	mv	t4,a3
    b958:	01012483          	lw	s1,16(sp)
    b95c:	01412403          	lw	s0,20(sp)
    b960:	00050313          	mv	t1,a0
    b964:	00058f13          	mv	t5,a1
    b968:	00080e13          	mv	t3,a6
    b96c:	00088693          	mv	a3,a7
    b970:	00efea63          	bltu	t6,a4,b984 <sprite+0x48>
    b974:	1d400f93          	li	t6,468
    b978:	fb878293          	addi	t0,a5,-72
    b97c:	410f8fb3          	sub	t6,t6,a6
    b980:	025ffa63          	bgeu	t6,t0,b9b4 <sprite+0x78>
    b984:	00812a23          	sw	s0,20(sp)
    b988:	00812403          	lw	s0,8(sp)
    b98c:	00912823          	sw	s1,16(sp)
    b990:	00c12083          	lw	ra,12(sp)
    b994:	00412483          	lw	s1,4(sp)
    b998:	00068893          	mv	a7,a3
    b99c:	000e0813          	mv	a6,t3
    b9a0:	000e8693          	mv	a3,t4
    b9a4:	000f0593          	mv	a1,t5
    b9a8:	00030513          	mv	a0,t1
    b9ac:	01010113          	addi	sp,sp,16
    b9b0:	da9ff06f          	j	b758 <clipped_sprite>
    b9b4:	02778333          	mul	t1,a5,t2
    b9b8:	00080793          	mv	a5,a6
    b9bc:	00e30333          	add	t1,t1,a4
    b9c0:	00131313          	slli	t1,t1,0x1
    b9c4:	00c306b3          	add	a3,t1,a2
    b9c8:	00000713          	li	a4,0
    b9cc:	000e8613          	mv	a2,t4
    b9d0:	cf5ff0ef          	jal	b6c4 <append>
    b9d4:	00153793          	seqz	a5,a0
    b9d8:	00c12083          	lw	ra,12(sp)
    b9dc:	00f42023          	sw	a5,0(s0)
    b9e0:	00812403          	lw	s0,8(sp)
    b9e4:	00412483          	lw	s1,4(sp)
    b9e8:	01010113          	addi	sp,sp,16
    b9ec:	00008067          	ret

0000b9f0 <gpu_instances_init>:
    b9f0:	00050793          	mv	a5,a0
    b9f4:	ff800513          	li	a0,-8
    b9f8:	04078863          	beqz	a5,ba48 <gpu_instances_init+0x58>
    b9fc:	04058663          	beqz	a1,ba48 <gpu_instances_init+0x58>
    ba00:	0105c703          	lbu	a4,16(a1)
    ba04:	04070263          	beqz	a4,ba48 <gpu_instances_init+0x58>
    ba08:	0005a703          	lw	a4,0(a1)
    ba0c:	0007a223          	sw	zero,4(a5)
    ba10:	00b7a023          	sw	a1,0(a5)
    ba14:	00872683          	lw	a3,8(a4)
    ba18:	01169613          	slli	a2,a3,0x11
    ba1c:	00064663          	bltz	a2,ba28 <gpu_instances_init+0x38>
    ba20:	00000513          	li	a0,0
    ba24:	00008067          	ret
    ba28:	40072683          	lw	a3,1024(a4)
    ba2c:	494e5737          	lui	a4,0x494e5
    ba30:	33170713          	addi	a4,a4,817 # 494e5331 <__gpu_framebuffer_a+0x474e5331>
    ba34:	fff00513          	li	a0,-1
    ba38:	00e69863          	bne	a3,a4,ba48 <gpu_instances_init+0x58>
    ba3c:	00100713          	li	a4,1
    ba40:	00e78223          	sb	a4,4(a5)
    ba44:	fddff06f          	j	ba20 <gpu_instances_init+0x30>
    ba48:	00008067          	ret

0000ba4c <gpu_instances_templates>:
    ba4c:	12058063          	beqz	a1,bb6c <gpu_instances_templates+0x120>
    ba50:	ff010113          	addi	sp,sp,-16
    ba54:	00912223          	sw	s1,4(sp)
    ba58:	00112623          	sw	ra,12(sp)
    ba5c:	00050493          	mv	s1,a0
    ba60:	00812423          	sw	s0,8(sp)
    ba64:	00100793          	li	a5,1
    ba68:	00000513          	li	a0,0
    ba6c:	1097e463          	bltu	a5,s1,bb74 <gpu_instances_templates+0x128>
    ba70:	00058413          	mv	s0,a1
    ba74:	1c000613          	li	a2,448
    ba78:	00000593          	li	a1,0
    ba7c:	00040513          	mv	a0,s0
    ba80:	fa8f50ef          	jal	1228 <memset>
    ba84:	0c048063          	beqz	s1,bb44 <gpu_instances_templates+0xf8>
    ba88:	02a005b7          	lui	a1,0x2a00
    ba8c:	029007b7          	lui	a5,0x2900
    ba90:	00f42223          	sw	a5,4(s0)
    ba94:	78000793          	li	a5,1920
    ba98:	00f42423          	sw	a5,8(s0)
    ba9c:	00f42623          	sw	a5,12(s0)
    baa0:	3c000793          	li	a5,960
    baa4:	00200713          	li	a4,2
    baa8:	00f42823          	sw	a5,16(s0)
    baac:	000106b7          	lui	a3,0x10
    bab0:	21c00793          	li	a5,540
    bab4:	fffff637          	lui	a2,0xfffff
    bab8:	00e42023          	sw	a4,0(s0)
    babc:	00f42a23          	sw	a5,20(s0)
    bac0:	00042c23          	sw	zero,24(s0)
    bac4:	00100513          	li	a0,1
    bac8:	01c40413          	addi	s0,s0,28
    bacc:	00c00713          	li	a4,12
    bad0:	50000793          	li	a5,1280
    bad4:	00100893          	li	a7,1
    bad8:	78000313          	li	t1,1920
    badc:	81f68693          	addi	a3,a3,-2017 # f81f <__global_pointer$+0xa9f>
    bae0:	00c00e13          	li	t3,12
    bae4:	00700e93          	li	t4,7
    bae8:	00800f13          	li	t5,8
    baec:	42060613          	addi	a2,a2,1056 # fffff420 <__gpu_framebuffer_a+0xfdfff420>
    baf0:	00300813          	li	a6,3
    baf4:	01151463          	bne	a0,a7,bafc <gpu_instances_templates+0xb0>
    baf8:	00400813          	li	a6,4
    bafc:	00b787b3          	add	a5,a5,a1
    bb00:	00f42223          	sw	a5,4(s0)
    bb04:	00171793          	slli	a5,a4,0x1
    bb08:	01042023          	sw	a6,0(s0)
    bb0c:	00f42423          	sw	a5,8(s0)
    bb10:	00642623          	sw	t1,12(s0)
    bb14:	00e42823          	sw	a4,16(s0)
    bb18:	00e42a23          	sw	a4,20(s0)
    bb1c:	00d42c23          	sw	a3,24(s0)
    bb20:	00150513          	addi	a0,a0,1
    bb24:	01c40413          	addi	s0,s0,28
    bb28:	05c50663          	beq	a0,t3,bb74 <gpu_instances_templates+0x128>
    bb2c:	02aef263          	bgeu	t4,a0,bb50 <gpu_instances_templates+0x104>
    bb30:	03e50863          	beq	a0,t5,bb60 <gpu_instances_templates+0x114>
    bb34:	00951793          	slli	a5,a0,0x9
    bb38:	00c787b3          	add	a5,a5,a2
    bb3c:	01000713          	li	a4,16
    bb40:	fb1ff06f          	j	baf0 <gpu_instances_templates+0xa4>
    bb44:	02c005b7          	lui	a1,0x2c00
    bb48:	02b007b7          	lui	a5,0x2b00
    bb4c:	f45ff06f          	j	ba90 <gpu_instances_templates+0x44>
    bb50:	00751793          	slli	a5,a0,0x7
    bb54:	f0078793          	addi	a5,a5,-256 # 2afff00 <__gpu_framebuffer_a+0xafff00>
    bb58:	00800713          	li	a4,8
    bb5c:	f95ff06f          	j	baf0 <gpu_instances_templates+0xa4>
    bb60:	01000713          	li	a4,16
    bb64:	30000793          	li	a5,768
    bb68:	f89ff06f          	j	baf0 <gpu_instances_templates+0xa4>
    bb6c:	00000513          	li	a0,0
    bb70:	00008067          	ret
    bb74:	00c12083          	lw	ra,12(sp)
    bb78:	00812403          	lw	s0,8(sp)
    bb7c:	00412483          	lw	s1,4(sp)
    bb80:	01010113          	addi	sp,sp,16
    bb84:	00008067          	ret

0000bb88 <gpu_instance_expand>:
    bb88:	28050863          	beqz	a0,be18 <gpu_instance_expand+0x290>
    bb8c:	00050713          	mv	a4,a0
    bb90:	ff800513          	li	a0,-8
    bb94:	28058a63          	beqz	a1,be28 <gpu_instance_expand+0x2a0>
    bb98:	28068863          	beqz	a3,be28 <gpu_instance_expand+0x2a0>
    bb9c:	0005a783          	lw	a5,0(a1) # 2c00000 <__gpu_framebuffer_a+0xc00000>
    bba0:	fd010113          	addi	sp,sp,-48
    bba4:	01312e23          	sw	s3,28(sp)
    bba8:	0187d513          	srli	a0,a5,0x18
    bbac:	0087d813          	srli	a6,a5,0x8
    bbb0:	01512a23          	sw	s5,20(sp)
    bbb4:	00060993          	mv	s3,a2
    bbb8:	0107da93          	srli	s5,a5,0x10
    bbbc:	0ff7f613          	zext.b	a2,a5
    bbc0:	0f07f793          	andi	a5,a5,240
    bbc4:	00f567b3          	or	a5,a0,a5
    bbc8:	02112623          	sw	ra,44(sp)
    bbcc:	02812423          	sw	s0,40(sp)
    bbd0:	02912223          	sw	s1,36(sp)
    bbd4:	03212023          	sw	s2,32(sp)
    bbd8:	01412c23          	sw	s4,24(sp)
    bbdc:	01612823          	sw	s6,16(sp)
    bbe0:	01712623          	sw	s7,12(sp)
    bbe4:	01812423          	sw	s8,8(sp)
    bbe8:	01912223          	sw	s9,4(sp)
    bbec:	0ff87813          	zext.b	a6,a6
    bbf0:	ff800513          	li	a0,-8
    bbf4:	1e079863          	bnez	a5,bde4 <gpu_instance_expand+0x25c>
    bbf8:	01c00793          	li	a5,28
    bbfc:	02f60633          	mul	a2,a2,a5
    bc00:	00c5aa03          	lw	s4,12(a1)
    bc04:	00200893          	li	a7,2
    bc08:	010a1793          	slli	a5,s4,0x10
    bc0c:	0107d793          	srli	a5,a5,0x10
    bc10:	010a5313          	srli	t1,s4,0x10
    bc14:	00c70733          	add	a4,a4,a2
    bc18:	00072903          	lw	s2,0(a4)
    bc1c:	ffe90613          	addi	a2,s2,-2
    bc20:	1cc8e263          	bltu	a7,a2,bde4 <gpu_instance_expand+0x25c>
    bc24:	ffc90893          	addi	a7,s2,-4
    bc28:	0018b893          	seqz	a7,a7
    bc2c:	1b089c63          	bne	a7,a6,bde4 <gpu_instance_expand+0x25c>
    bc30:	00400513          	li	a0,4
    bc34:	00a90663          	beq	s2,a0,bc40 <gpu_instance_expand+0xb8>
    bc38:	ff800513          	li	a0,-8
    bc3c:	1a0a9463          	bnez	s5,bde4 <gpu_instance_expand+0x25c>
    bc40:	ff800513          	li	a0,-8
    bc44:	1a078063          	beqz	a5,bde4 <gpu_instance_expand+0x25c>
    bc48:	18030e63          	beqz	t1,bde4 <gpu_instance_expand+0x25c>
    bc4c:	01072803          	lw	a6,16(a4)
    bc50:	00010e37          	lui	t3,0x10
    bc54:	ffee0e13          	addi	t3,t3,-2 # fffe <__global_pointer$+0x127e>
    bc58:	fff80893          	addi	a7,a6,-1
    bc5c:	00010f37          	lui	t5,0x10
    bc60:	191e6263          	bltu	t3,a7,bde4 <gpu_instance_expand+0x25c>
    bc64:	01472e83          	lw	t4,20(a4)
    bc68:	fffe8893          	addi	a7,t4,-1
    bc6c:	171e6c63          	bltu	t3,a7,bde4 <gpu_instance_expand+0x25c>
    bc70:	16f86a63          	bltu	a6,a5,bde4 <gpu_instance_expand+0x25c>
    bc74:	166ee863          	bltu	t4,t1,bde4 <gpu_instance_expand+0x25c>
    bc78:	01872b03          	lw	s6,24(a4)
    bc7c:	17eb7463          	bgeu	s6,t5,bde4 <gpu_instance_expand+0x25c>
    bc80:	0045ab83          	lw	s7,4(a1)
    bc84:	0085a583          	lw	a1,8(a1)
    bc88:	00872403          	lw	s0,8(a4)
    bc8c:	00c72483          	lw	s1,12(a4)
    bc90:	00472e03          	lw	t3,4(a4)
    bc94:	00bbe733          	or	a4,s7,a1
    bc98:	00876733          	or	a4,a4,s0
    bc9c:	00976733          	or	a4,a4,s1
    bca0:	01c76733          	or	a4,a4,t3
    bca4:	00177713          	andi	a4,a4,1
    bca8:	12071e63          	bnez	a4,bde4 <gpu_instance_expand+0x25c>
    bcac:	00179793          	slli	a5,a5,0x1
    bcb0:	12f46a63          	bltu	s0,a5,bde4 <gpu_instance_expand+0x25c>
    bcb4:	12f4e863          	bltu	s1,a5,bde4 <gpu_instance_expand+0x25c>
    bcb8:	fff30313          	addi	t1,t1,-1
    bcbc:	02830fb3          	mul	t6,t1,s0
    bcc0:	00be0c33          	add	s8,t3,a1
    bcc4:	01cc3733          	sltu	a4,s8,t3
    bcc8:	00181813          	slli	a6,a6,0x1
    bccc:	00000f13          	li	t5,0
    bcd0:	028332b3          	mulhu	t0,t1,s0
    bcd4:	018f8533          	add	a0,t6,s8
    bcd8:	01f53e33          	sltu	t3,a0,t6
    bcdc:	00e28eb3          	add	t4,t0,a4
    bce0:	01de0e33          	add	t3,t3,t4
    bce4:	00f50eb3          	add	t4,a0,a5
    bce8:	00aeb533          	sltu	a0,t4,a0
    bcec:	029333b3          	mulhu	t2,t1,s1
    bcf0:	01c50533          	add	a0,a0,t3
    bcf4:	02930e33          	mul	t3,t1,s1
    bcf8:	01778333          	add	t1,a5,s7
    bcfc:	00f33cb3          	sltu	s9,t1,a5
    bd00:	00f587b3          	add	a5,a1,a5
    bd04:	00b7b5b3          	sltu	a1,a5,a1
    bd08:	01f78fb3          	add	t6,a5,t6
    bd0c:	005585b3          	add	a1,a1,t0
    bd10:	00ffb7b3          	sltu	a5,t6,a5
    bd14:	00b787b3          	add	a5,a5,a1
    bd18:	019383b3          	add	t2,t2,s9
    bd1c:	031405b3          	mul	a1,s0,a7
    bd20:	006e0333          	add	t1,t3,t1
    bd24:	01c33e33          	sltu	t3,t1,t3
    bd28:	007e0e33          	add	t3,t3,t2
    bd2c:	031438b3          	mulhu	a7,s0,a7
    bd30:	01058833          	add	a6,a1,a6
    bd34:	00b835b3          	sltu	a1,a6,a1
    bd38:	011588b3          	add	a7,a1,a7
    bd3c:	0ef8e263          	bltu	a7,a5,be20 <gpu_instance_expand+0x298>
    bd40:	01179463          	bne	a5,a7,bd48 <gpu_instance_expand+0x1c0>
    bd44:	0df86e63          	bltu	a6,t6,be20 <gpu_instance_expand+0x298>
    bd48:	fe0005b7          	lui	a1,0xfe000
    bd4c:	00bc0833          	add	a6,s8,a1
    bd50:	018837b3          	sltu	a5,a6,s8
    bd54:	fff70893          	addi	a7,a4,-1
    bd58:	011787b3          	add	a5,a5,a7
    bd5c:	0c079263          	bnez	a5,be20 <gpu_instance_expand+0x298>
    bd60:	0cb87063          	bgeu	a6,a1,be20 <gpu_instance_expand+0x298>
    bd64:	0a051e63          	bnez	a0,be20 <gpu_instance_expand+0x298>
    bd68:	100007b7          	lui	a5,0x10000
    bd6c:	0bd7ea63          	bltu	a5,t4,be20 <gpu_instance_expand+0x298>
    bd70:	020005b7          	lui	a1,0x2000
    bd74:	ff800513          	li	a0,-8
    bd78:	06bbe663          	bltu	s7,a1,bde4 <gpu_instance_expand+0x25c>
    bd7c:	0a0e1263          	bnez	t3,be20 <gpu_instance_expand+0x298>
    bd80:	0a67e063          	bltu	a5,t1,be20 <gpu_instance_expand+0x298>
    bd84:	ffd67613          	andi	a2,a2,-3
    bd88:	02061263          	bnez	a2,bdac <gpu_instance_expand+0x224>
    bd8c:	02071063          	bnez	a4,bdac <gpu_instance_expand+0x224>
    bd90:	006c7e63          	bgeu	s8,t1,bdac <gpu_instance_expand+0x224>
    bd94:	01dbfc63          	bgeu	s7,t4,bdac <gpu_instance_expand+0x224>
    bd98:	00400793          	li	a5,4
    bd9c:	04f91463          	bne	s2,a5,bde4 <gpu_instance_expand+0x25c>
    bda0:	098b9063          	bne	s7,s8,be20 <gpu_instance_expand+0x298>
    bda4:	06ef1e63          	bne	t5,a4,be20 <gpu_instance_expand+0x298>
    bda8:	02941e63          	bne	s0,s1,bde4 <gpu_instance_expand+0x25c>
    bdac:	02000613          	li	a2,32
    bdb0:	00000593          	li	a1,0
    bdb4:	00068513          	mv	a0,a3
    bdb8:	c70f50ef          	jal	1228 <memset>
    bdbc:	01852023          	sw	s8,0(a0)
    bdc0:	01752223          	sw	s7,4(a0)
    bdc4:	00852423          	sw	s0,8(a0)
    bdc8:	00952623          	sw	s1,12(a0)
    bdcc:	01452823          	sw	s4,16(a0)
    bdd0:	01651b23          	sh	s6,22(a0)
    bdd4:	01351d23          	sh	s3,26(a0)
    bdd8:	01250e23          	sb	s2,28(a0)
    bddc:	01550ea3          	sb	s5,29(a0)
    bde0:	00000513          	li	a0,0
    bde4:	02c12083          	lw	ra,44(sp)
    bde8:	02812403          	lw	s0,40(sp)
    bdec:	02412483          	lw	s1,36(sp)
    bdf0:	02012903          	lw	s2,32(sp)
    bdf4:	01c12983          	lw	s3,28(sp)
    bdf8:	01812a03          	lw	s4,24(sp)
    bdfc:	01412a83          	lw	s5,20(sp)
    be00:	01012b03          	lw	s6,16(sp)
    be04:	00c12b83          	lw	s7,12(sp)
    be08:	00812c03          	lw	s8,8(sp)
    be0c:	00412c83          	lw	s9,4(sp)
    be10:	03010113          	addi	sp,sp,48
    be14:	00008067          	ret
    be18:	ff800513          	li	a0,-8
    be1c:	00008067          	ret
    be20:	ff800513          	li	a0,-8
    be24:	fc1ff06f          	j	bde4 <gpu_instance_expand+0x25c>
    be28:	00008067          	ret

0000be2c <gpu_instances_program>:
    be2c:	1c050463          	beqz	a0,bff4 <gpu_instances_program+0x1c8>
    be30:	00052783          	lw	a5,0(a0)
    be34:	fa010113          	addi	sp,sp,-96
    be38:	04912a23          	sw	s1,84(sp)
    be3c:	04112e23          	sw	ra,92(sp)
    be40:	04812c23          	sw	s0,88(sp)
    be44:	05212823          	sw	s2,80(sp)
    be48:	05312623          	sw	s3,76(sp)
    be4c:	05412423          	sw	s4,72(sp)
    be50:	05512223          	sw	s5,68(sp)
    be54:	05612023          	sw	s6,64(sp)
    be58:	03712e23          	sw	s7,60(sp)
    be5c:	03812c23          	sw	s8,56(sp)
    be60:	03912a23          	sw	s9,52(sp)
    be64:	00050493          	mv	s1,a0
    be68:	16078a63          	beqz	a5,bfdc <gpu_instances_program+0x1b0>
    be6c:	00058993          	mv	s3,a1
    be70:	16058663          	beqz	a1,bfdc <gpu_instances_program+0x1b0>
    be74:	fff60713          	addi	a4,a2,-1
    be78:	00f00693          	li	a3,15
    be7c:	00060b93          	mv	s7,a2
    be80:	14e6ee63          	bltu	a3,a4,bfdc <gpu_instances_program+0x1b0>
    be84:	00454703          	lbu	a4,4(a0)
    be88:	02071e63          	bnez	a4,bec4 <gpu_instances_program+0x98>
    be8c:	00000513          	li	a0,0
    be90:	05c12083          	lw	ra,92(sp)
    be94:	05812403          	lw	s0,88(sp)
    be98:	05412483          	lw	s1,84(sp)
    be9c:	05012903          	lw	s2,80(sp)
    bea0:	04c12983          	lw	s3,76(sp)
    bea4:	04812a03          	lw	s4,72(sp)
    bea8:	04412a83          	lw	s5,68(sp)
    beac:	04012b03          	lw	s6,64(sp)
    beb0:	03c12b83          	lw	s7,60(sp)
    beb4:	03812c03          	lw	s8,56(sp)
    beb8:	03412c83          	lw	s9,52(sp)
    bebc:	06010113          	addi	sp,sp,96
    bec0:	00008067          	ret
    bec4:	00554703          	lbu	a4,5(a0)
    bec8:	ffd00513          	li	a0,-3
    becc:	fc0712e3          	bnez	a4,be90 <gpu_instances_program+0x64>
    bed0:	0127c703          	lbu	a4,18(a5) # 10000012 <__gpu_framebuffer_a+0xe000012>
    bed4:	fa071ee3          	bnez	a4,be90 <gpu_instances_program+0x64>
    bed8:	0007ab03          	lw	s6,0(a5)
    bedc:	008b2903          	lw	s2,8(s6)
    bee0:	08097913          	andi	s2,s2,128
    bee4:	fa0916e3          	bnez	s2,be90 <gpu_instances_program+0x64>
    bee8:	00010c37          	lui	s8,0x10
    beec:	00058413          	mv	s0,a1
    bef0:	00058a13          	mv	s4,a1
    bef4:	00000a93          	li	s5,0
    bef8:	02000cb7          	lui	s9,0x2000
    befc:	fffc0c13          	addi	s8,s8,-1 # ffff <__global_pointer$+0x127f>
    bf00:	000a2783          	lw	a5,0(s4)
    bf04:	010a2703          	lw	a4,16(s4)
    bf08:	01010693          	addi	a3,sp,16
    bf0c:	ffc78793          	addi	a5,a5,-4
    bf10:	0017b793          	seqz	a5,a5
    bf14:	00879793          	slli	a5,a5,0x8
    bf18:	0157e7b3          	or	a5,a5,s5
    bf1c:	00f12023          	sw	a5,0(sp)
    bf20:	014a2783          	lw	a5,20(s4)
    bf24:	01877733          	and	a4,a4,s8
    bf28:	00000613          	li	a2,0
    bf2c:	01079793          	slli	a5,a5,0x10
    bf30:	00e7e7b3          	or	a5,a5,a4
    bf34:	00010593          	mv	a1,sp
    bf38:	00098513          	mv	a0,s3
    bf3c:	01912223          	sw	s9,4(sp)
    bf40:	00012423          	sw	zero,8(sp)
    bf44:	00f12623          	sw	a5,12(sp)
    bf48:	c41ff0ef          	jal	bb88 <gpu_instance_expand>
    bf4c:	08051863          	bnez	a0,bfdc <gpu_instances_program+0x1b0>
    bf50:	001a8793          	addi	a5,s5,1
    bf54:	01ca0a13          	addi	s4,s4,28
    bf58:	08fb9663          	bne	s7,a5,bfe4 <gpu_instances_program+0x1b8>
    bf5c:	42cb0693          	addi	a3,s6,1068
    bf60:	00042783          	lw	a5,0(s0)
    bf64:	01010713          	addi	a4,sp,16
    bf68:	00f12823          	sw	a5,16(sp)
    bf6c:	00442783          	lw	a5,4(s0)
    bf70:	00f12a23          	sw	a5,20(sp)
    bf74:	00842783          	lw	a5,8(s0)
    bf78:	00f12c23          	sw	a5,24(sp)
    bf7c:	00c42783          	lw	a5,12(s0)
    bf80:	00f12e23          	sw	a5,28(sp)
    bf84:	01042783          	lw	a5,16(s0)
    bf88:	02f12023          	sw	a5,32(sp)
    bf8c:	01442783          	lw	a5,20(s0)
    bf90:	02f12223          	sw	a5,36(sp)
    bf94:	01842783          	lw	a5,24(s0)
    bf98:	412b2623          	sw	s2,1036(s6)
    bf9c:	02f12423          	sw	a5,40(sp)
    bfa0:	410b0793          	addi	a5,s6,1040
    bfa4:	00072603          	lw	a2,0(a4)
    bfa8:	00478793          	addi	a5,a5,4
    bfac:	00470713          	addi	a4,a4,4
    bfb0:	fec7ae23          	sw	a2,-4(a5)
    bfb4:	fef698e3          	bne	a3,a5,bfa4 <gpu_instances_program+0x178>
    bfb8:	00190793          	addi	a5,s2,1
    bfbc:	01c40413          	addi	s0,s0,28
    bfc0:	032a9663          	bne	s5,s2,bfec <gpu_instances_program+0x1c0>
    bfc4:	0ff0000f          	fence
    bfc8:	0004a783          	lw	a5,0(s1)
    bfcc:	0007a783          	lw	a5,0(a5)
    bfd0:	4047a783          	lw	a5,1028(a5)
    bfd4:	0087f793          	andi	a5,a5,8
    bfd8:	ea078ae3          	beqz	a5,be8c <gpu_instances_program+0x60>
    bfdc:	ff800513          	li	a0,-8
    bfe0:	eb1ff06f          	j	be90 <gpu_instances_program+0x64>
    bfe4:	00078a93          	mv	s5,a5
    bfe8:	f19ff06f          	j	bf00 <gpu_instances_program+0xd4>
    bfec:	00078913          	mv	s2,a5
    bff0:	f71ff06f          	j	bf60 <gpu_instances_program+0x134>
    bff4:	ff800513          	li	a0,-8
    bff8:	00008067          	ret

0000bffc <gpu_instances_build_into>:
    bffc:	f9010113          	addi	sp,sp,-112
    c000:	06812423          	sw	s0,104(sp)
    c004:	07012403          	lw	s0,112(sp)
    c008:	06112623          	sw	ra,108(sp)
    c00c:	06912223          	sw	s1,100(sp)
    c010:	07212023          	sw	s2,96(sp)
    c014:	05312e23          	sw	s3,92(sp)
    c018:	05412c23          	sw	s4,88(sp)
    c01c:	05512a23          	sw	s5,84(sp)
    c020:	05612823          	sw	s6,80(sp)
    c024:	05712623          	sw	s7,76(sp)
    c028:	05812423          	sw	s8,72(sp)
    c02c:	05912223          	sw	s9,68(sp)
    c030:	05a12023          	sw	s10,64(sp)
    c034:	03b12e23          	sw	s11,60(sp)
    c038:	04041263          	bnez	s0,c07c <gpu_instances_build_into+0x80>
    c03c:	ff800513          	li	a0,-8
    c040:	06c12083          	lw	ra,108(sp)
    c044:	06812403          	lw	s0,104(sp)
    c048:	06412483          	lw	s1,100(sp)
    c04c:	06012903          	lw	s2,96(sp)
    c050:	05c12983          	lw	s3,92(sp)
    c054:	05812a03          	lw	s4,88(sp)
    c058:	05412a83          	lw	s5,84(sp)
    c05c:	05012b03          	lw	s6,80(sp)
    c060:	04c12b83          	lw	s7,76(sp)
    c064:	04812c03          	lw	s8,72(sp)
    c068:	04412c83          	lw	s9,68(sp)
    c06c:	04012d03          	lw	s10,64(sp)
    c070:	03c12d83          	lw	s11,60(sp)
    c074:	07010113          	addi	sp,sp,112
    c078:	00008067          	ret
    c07c:	00042823          	sw	zero,16(s0)
    c080:	00042423          	sw	zero,8(s0)
    c084:	00042623          	sw	zero,12(s0)
    c088:	00042223          	sw	zero,4(s0)
    c08c:	00042023          	sw	zero,0(s0)
    c090:	00050493          	mv	s1,a0
    c094:	fa0504e3          	beqz	a0,c03c <gpu_instances_build_into+0x40>
    c098:	00088c13          	mv	s8,a7
    c09c:	fa0880e3          	beqz	a7,c03c <gpu_instances_build_into+0x40>
    c0a0:	00005cb7          	lui	s9,0x5
    c0a4:	01950cb3          	add	s9,a0,s9
    c0a8:	00078b93          	mv	s7,a5
    c0ac:	008ca783          	lw	a5,8(s9) # 5008 <bullet_enemy_position+0x50>
    c0b0:	00070a13          	mv	s4,a4
    c0b4:	3ff00713          	li	a4,1023
    c0b8:	fff78793          	addi	a5,a5,-1
    c0bc:	f8f760e3          	bltu	a4,a5,c03c <gpu_instances_build_into+0x40>
    c0c0:	fff80793          	addi	a5,a6,-1
    c0c4:	48800713          	li	a4,1160
    c0c8:	00080993          	mv	s3,a6
    c0cc:	f6f768e3          	bltu	a4,a5,c03c <gpu_instances_build_into+0x40>
    c0d0:	00058913          	mv	s2,a1
    c0d4:	00060a93          	mv	s5,a2
    c0d8:	00068b13          	mv	s6,a3
    c0dc:	e61f80ef          	jal	4f3c <bullet_campaign_valid>
    c0e0:	f4050ee3          	beqz	a0,c03c <gpu_instances_build_into+0x40>
    c0e4:	000a0663          	beqz	s4,c0f0 <gpu_instances_build_into+0xf4>
    c0e8:	029cc783          	lbu	a5,41(s9)
    c0ec:	f40798e3          	bnez	a5,c03c <gpu_instances_build_into+0x40>
    c0f0:	016aeab3          	or	s5,s5,s6
    c0f4:	014aeab3          	or	s5,s5,s4
    c0f8:	00100793          	li	a5,1
    c0fc:	f557e0e3          	bltu	a5,s5,c03c <gpu_instances_build_into+0x40>
    c100:	21b00793          	li	a5,539
    c104:	f377ece3          	bltu	a5,s7,c03c <gpu_instances_build_into+0x40>
    c108:	ffe00737          	lui	a4,0xffe00
    c10c:	fff70713          	addi	a4,a4,-1 # ffdfffff <__gpu_framebuffer_a+0xfddfffff>
    c110:	00e97733          	and	a4,s2,a4
    c114:	020007b7          	lui	a5,0x2000
    c118:	f2f712e3          	bne	a4,a5,c03c <gpu_instances_build_into+0x40>
    c11c:	78000713          	li	a4,1920
    c120:	02eb8733          	mul	a4,s7,a4
    c124:	21c00813          	li	a6,540
    c128:	41780833          	sub	a6,a6,s7
    c12c:	00000893          	li	a7,0
    c130:	3c000793          	li	a5,960
    c134:	00000613          	li	a2,0
    c138:	00098593          	mv	a1,s3
    c13c:	02810513          	addi	a0,sp,40
    c140:	03812423          	sw	s8,40(sp)
    c144:	02812623          	sw	s0,44(sp)
    c148:	012706b3          	add	a3,a4,s2
    c14c:	d78ff0ef          	jal	b6c4 <append>
    c150:	00005c37          	lui	s8,0x5
    c154:	00010d37          	lui	s10,0x10
    c158:	00048b93          	mv	s7,s1
    c15c:	00048a93          	mv	s5,s1
    c160:	00000c93          	li	s9,0
    c164:	01848c33          	add	s8,s1,s8
    c168:	01c10d93          	addi	s11,sp,28
    c16c:	fff00313          	li	t1,-1
    c170:	00300e13          	li	t3,3
    c174:	fffd0d13          	addi	s10,s10,-1 # ffff <__global_pointer$+0x127f>
    c178:	00051863          	bnez	a0,c188 <gpu_instances_build_into+0x18c>
    c17c:	000b0663          	beqz	s6,c188 <gpu_instances_build_into+0x18c>
    c180:	008c2783          	lw	a5,8(s8) # 5008 <bullet_enemy_position+0x50>
    c184:	18fcea63          	bltu	s9,a5,c318 <gpu_instances_build_into+0x31c>
    c188:	01403cb3          	snez	s9,s4
    c18c:	00005ab7          	lui	s5,0x5
    c190:	00010d37          	lui	s10,0x10
    c194:	002c8c93          	addi	s9,s9,2
    c198:	00000c13          	li	s8,0
    c19c:	01548ab3          	add	s5,s1,s5
    c1a0:	00500d93          	li	s11,5
    c1a4:	00300313          	li	t1,3
    c1a8:	01c10e13          	addi	t3,sp,28
    c1ac:	fffd0d13          	addi	s10,s10,-1 # ffff <__global_pointer$+0x127f>
    c1b0:	06051c63          	bnez	a0,c228 <gpu_instances_build_into+0x22c>
    c1b4:	008aa783          	lw	a5,8(s5) # 5008 <bullet_enemy_position+0x50>
    c1b8:	1cfc6c63          	bltu	s8,a5,c390 <gpu_instances_build_into+0x394>
    c1bc:	024ac783          	lbu	a5,36(s5)
    c1c0:	040b0a63          	beqz	s6,c214 <gpu_instances_build_into+0x218>
    c1c4:	06078063          	beqz	a5,c224 <gpu_instances_build_into+0x228>
    c1c8:	00caa703          	lw	a4,12(s5)
    c1cc:	010aa783          	lw	a5,16(s5)
    c1d0:	020ad683          	lhu	a3,32(s5)
    c1d4:	ffa70713          	addi	a4,a4,-6
    c1d8:	ffa78793          	addi	a5,a5,-6 # 1fffffa <__freertos_irq_stack_top+0x1fe255a>
    c1dc:	04000893          	li	a7,64
    c1e0:	00068463          	beqz	a3,c1e8 <gpu_instances_build_into+0x1ec>
    c1e4:	0c000893          	li	a7,192
    c1e8:	01c10693          	addi	a3,sp,28
    c1ec:	00d12223          	sw	a3,4(sp)
    c1f0:	fff00693          	li	a3,-1
    c1f4:	00d12023          	sw	a3,0(sp)
    c1f8:	00c00813          	li	a6,12
    c1fc:	00100693          	li	a3,1
    c200:	00090613          	mv	a2,s2
    c204:	00098593          	mv	a1,s3
    c208:	02810513          	addi	a0,sp,40
    c20c:	f30ff0ef          	jal	b93c <sprite>
    c210:	00051c63          	bnez	a0,c228 <gpu_instances_build_into+0x22c>
    c214:	00005737          	lui	a4,0x5
    c218:	00e48733          	add	a4,s1,a4
    c21c:	02474783          	lbu	a5,36(a4) # 5024 <bullet_enemy_position+0x6c>
    c220:	1e079a63          	bnez	a5,c414 <gpu_instances_build_into+0x418>
    c224:	00000513          	li	a0,0
    c228:	000057b7          	lui	a5,0x5
    c22c:	00f487b3          	add	a5,s1,a5
    c230:	0247c703          	lbu	a4,36(a5) # 5024 <bullet_enemy_position+0x6c>
    c234:	05000b93          	li	s7,80
    c238:	02070063          	beqz	a4,c258 <gpu_instances_build_into+0x25c>
    c23c:	0147a783          	lw	a5,20(a5)
    c240:	03c00713          	li	a4,60
    c244:	02e7f7b3          	remu	a5,a5,a4
    c248:	02b00713          	li	a4,43
    c24c:	00f77663          	bgeu	a4,a5,c258 <gpu_instances_build_into+0x25c>
    c250:	00379793          	slli	a5,a5,0x3
    c254:	ef878b93          	addi	s7,a5,-264
    c258:	0000edb7          	lui	s11,0xe
    c25c:	00005ab7          	lui	s5,0x5
    c260:	474d8d93          	addi	s11,s11,1140 # e474 <centers.0>
    c264:	00000d13          	li	s10,0
    c268:	00300c13          	li	s8,3
    c26c:	fff00c93          	li	s9,-1
    c270:	01548ab3          	add	s5,s1,s5
    c274:	20051e63          	bnez	a0,c490 <gpu_instances_build_into+0x494>
    c278:	dd8d04e3          	beq	s10,s8,c040 <gpu_instances_build_into+0x44>
    c27c:	020a0263          	beqz	s4,c2a0 <gpu_instances_build_into+0x2a4>
    c280:	028ac783          	lbu	a5,40(s5) # 5028 <bullet_enemy_position+0x70>
    c284:	00078e63          	beqz	a5,c2a0 <gpu_instances_build_into+0x2a4>
    c288:	000057b7          	lui	a5,0x5
    c28c:	02578793          	addi	a5,a5,37 # 5025 <bullet_enemy_position+0x6d>
    c290:	00fd07b3          	add	a5,s10,a5
    c294:	00f487b3          	add	a5,s1,a5
    c298:	0007c783          	lbu	a5,0(a5)
    c29c:	06078863          	beqz	a5,c30c <gpu_instances_build_into+0x310>
    c2a0:	000da783          	lw	a5,0(s11)
    c2a4:	02f12023          	sw	a5,32(sp)
    c2a8:	004da783          	lw	a5,4(s11)
    c2ac:	02f12223          	sw	a5,36(sp)
    c2b0:	000a0c63          	beqz	s4,c2c8 <gpu_instances_build_into+0x2cc>
    c2b4:	02410693          	addi	a3,sp,36
    c2b8:	02010613          	addi	a2,sp,32
    c2bc:	000d0593          	mv	a1,s10
    c2c0:	00048513          	mv	a0,s1
    c2c4:	cf5f80ef          	jal	4fb8 <bullet_enemy_position>
    c2c8:	02012703          	lw	a4,32(sp)
    c2cc:	02412783          	lw	a5,36(sp)
    c2d0:	180b1263          	bnez	s6,c454 <gpu_instances_build_into+0x458>
    c2d4:	01c10793          	addi	a5,sp,28
    c2d8:	02012703          	lw	a4,32(sp)
    c2dc:	00f12223          	sw	a5,4(sp)
    c2e0:	02412783          	lw	a5,36(sp)
    c2e4:	01912023          	sw	s9,0(sp)
    c2e8:	00000893          	li	a7,0
    c2ec:	01000813          	li	a6,16
    c2f0:	ff878793          	addi	a5,a5,-8
    c2f4:	ff870713          	addi	a4,a4,-8
    c2f8:	009d0693          	addi	a3,s10,9
    c2fc:	00090613          	mv	a2,s2
    c300:	00098593          	mv	a1,s3
    c304:	02810513          	addi	a0,sp,40
    c308:	e34ff0ef          	jal	b93c <sprite>
    c30c:	001d0d13          	addi	s10,s10,1
    c310:	008d8d93          	addi	s11,s11,8
    c314:	f61ff06f          	j	c274 <gpu_instances_build_into+0x278>
    c318:	000a0e63          	beqz	s4,c334 <gpu_instances_build_into+0x338>
    c31c:	00eac783          	lbu	a5,14(s5)
    c320:	01c78663          	beq	a5,t3,c32c <gpu_instances_build_into+0x330>
    c324:	028c4783          	lbu	a5,40(s8)
    c328:	00078663          	beqz	a5,c334 <gpu_instances_build_into+0x338>
    c32c:	00cad783          	lhu	a5,12(s5)
    c330:	05a78a63          	beq	a5,s10,c384 <gpu_instances_build_into+0x388>
    c334:	004c2883          	lw	a7,4(s8)
    c338:	004aa783          	lw	a5,4(s5)
    c33c:	000aa703          	lw	a4,0(s5)
    c340:	00f8f893          	andi	a7,a7,15
    c344:	01088893          	addi	a7,a7,16
    c348:	4087d793          	srai	a5,a5,0x8
    c34c:	40875713          	srai	a4,a4,0x8
    c350:	00612023          	sw	t1,0(sp)
    c354:	01b12223          	sw	s11,4(sp)
    c358:	00289893          	slli	a7,a7,0x2
    c35c:	00c00813          	li	a6,12
    c360:	ffe78793          	addi	a5,a5,-2
    c364:	ffe70713          	addi	a4,a4,-2
    c368:	00100693          	li	a3,1
    c36c:	00090613          	mv	a2,s2
    c370:	00098593          	mv	a1,s3
    c374:	02810513          	addi	a0,sp,40
    c378:	dc4ff0ef          	jal	b93c <sprite>
    c37c:	00300e13          	li	t3,3
    c380:	fff00313          	li	t1,-1
    c384:	008c8c93          	addi	s9,s9,8
    c388:	0a0a8a93          	addi	s5,s5,160
    c38c:	dedff06f          	j	c178 <gpu_instances_build_into+0x17c>
    c390:	00ebc783          	lbu	a5,14(s7)
    c394:	10fcca63          	blt	s9,a5,c4a8 <gpu_instances_build_into+0x4ac>
    c398:	00fbc683          	lbu	a3,15(s7)
    c39c:	10dde663          	bltu	s11,a3,c4a8 <gpu_instances_build_into+0x4ac>
    c3a0:	00678863          	beq	a5,t1,c3b0 <gpu_instances_build_into+0x3b4>
    c3a4:	000a0a63          	beqz	s4,c3b8 <gpu_instances_build_into+0x3bc>
    c3a8:	028ac783          	lbu	a5,40(s5)
    c3ac:	00078663          	beqz	a5,c3b8 <gpu_instances_build_into+0x3bc>
    c3b0:	00cbd783          	lhu	a5,12(s7)
    c3b4:	05a78a63          	beq	a5,s10,c408 <gpu_instances_build_into+0x40c>
    c3b8:	004ba783          	lw	a5,4(s7)
    c3bc:	000ba703          	lw	a4,0(s7)
    c3c0:	00000893          	li	a7,0
    c3c4:	01c12223          	sw	t3,4(sp)
    c3c8:	00d12023          	sw	a3,0(sp)
    c3cc:	00800813          	li	a6,8
    c3d0:	4087d793          	srai	a5,a5,0x8
    c3d4:	40875713          	srai	a4,a4,0x8
    c3d8:	00268693          	addi	a3,a3,2
    c3dc:	00090613          	mv	a2,s2
    c3e0:	00098593          	mv	a1,s3
    c3e4:	02810513          	addi	a0,sp,40
    c3e8:	d54ff0ef          	jal	b93c <sprite>
    c3ec:	01c10e13          	addi	t3,sp,28
    c3f0:	00300313          	li	t1,3
    c3f4:	00051a63          	bnez	a0,c408 <gpu_instances_build_into+0x40c>
    c3f8:	00442783          	lw	a5,4(s0)
    c3fc:	01c12703          	lw	a4,28(sp)
    c400:	00e787b3          	add	a5,a5,a4
    c404:	00f42223          	sw	a5,4(s0)
    c408:	001c0c13          	addi	s8,s8,1
    c40c:	014b8b93          	addi	s7,s7,20
    c410:	da1ff06f          	j	c1b0 <gpu_instances_build_into+0x1b4>
    c414:	01072783          	lw	a5,16(a4)
    c418:	00c72703          	lw	a4,12(a4)
    c41c:	01c10693          	addi	a3,sp,28
    c420:	00d12223          	sw	a3,4(sp)
    c424:	fff00693          	li	a3,-1
    c428:	00d12023          	sw	a3,0(sp)
    c42c:	00000893          	li	a7,0
    c430:	01000813          	li	a6,16
    c434:	ff878793          	addi	a5,a5,-8
    c438:	ff870713          	addi	a4,a4,-8
    c43c:	00800693          	li	a3,8
    c440:	00090613          	mv	a2,s2
    c444:	00098593          	mv	a1,s3
    c448:	02810513          	addi	a0,sp,40
    c44c:	cf0ff0ef          	jal	b93c <sprite>
    c450:	dd9ff06f          	j	c228 <gpu_instances_build_into+0x22c>
    c454:	01c10693          	addi	a3,sp,28
    c458:	00d12223          	sw	a3,4(sp)
    c45c:	fff00693          	li	a3,-1
    c460:	00d12023          	sw	a3,0(sp)
    c464:	000b8893          	mv	a7,s7
    c468:	00c00813          	li	a6,12
    c46c:	ffa78793          	addi	a5,a5,-6
    c470:	ffa70713          	addi	a4,a4,-6
    c474:	00100693          	li	a3,1
    c478:	00090613          	mv	a2,s2
    c47c:	00098593          	mv	a1,s3
    c480:	02810513          	addi	a0,sp,40
    c484:	cb8ff0ef          	jal	b93c <sprite>
    c488:	e80512e3          	bnez	a0,c30c <gpu_instances_build_into+0x310>
    c48c:	e49ff06f          	j	c2d4 <gpu_instances_build_into+0x2d8>
    c490:	00042823          	sw	zero,16(s0)
    c494:	00042423          	sw	zero,8(s0)
    c498:	00042623          	sw	zero,12(s0)
    c49c:	00042223          	sw	zero,4(s0)
    c4a0:	00042023          	sw	zero,0(s0)
    c4a4:	b9dff06f          	j	c040 <gpu_instances_build_into+0x44>
    c4a8:	ff800513          	li	a0,-8
    c4ac:	d7dff06f          	j	c228 <gpu_instances_build_into+0x22c>

0000c4b0 <gpu_frame_list_init>:
    c4b0:	10050463          	beqz	a0,c5b8 <gpu_frame_list_init+0x108>
    c4b4:	e2010113          	addi	sp,sp,-480
    c4b8:	1c812c23          	sw	s0,472(sp)
    c4bc:	1c112e23          	sw	ra,476(sp)
    c4c0:	1c912a23          	sw	s1,468(sp)
    c4c4:	1d212823          	sw	s2,464(sp)
    c4c8:	00050413          	mv	s0,a0
    c4cc:	ff800513          	li	a0,-8
    c4d0:	06058863          	beqz	a1,c540 <gpu_frame_list_init+0x90>
    c4d4:	00100793          	li	a5,1
    c4d8:	00060493          	mv	s1,a2
    c4dc:	06c7e263          	bltu	a5,a2,c540 <gpu_frame_list_init+0x90>
    c4e0:	0135c783          	lbu	a5,19(a1) # 2000013 <__gpu_framebuffer_a+0x13>
    c4e4:	04079c63          	bnez	a5,c53c <gpu_frame_list_init+0x8c>
    c4e8:	0105c783          	lbu	a5,16(a1)
    c4ec:	04078a63          	beqz	a5,c540 <gpu_frame_list_init+0x90>
    c4f0:	0005a783          	lw	a5,0(a1)
    c4f4:	00042223          	sw	zero,4(s0)
    c4f8:	00b42023          	sw	a1,0(s0)
    c4fc:	0087a903          	lw	s2,8(a5)
    c500:	01091713          	slli	a4,s2,0x10
    c504:	0a075663          	bgez	a4,c5b0 <gpu_frame_list_init+0x100>
    c508:	01191713          	slli	a4,s2,0x11
    c50c:	fff00513          	li	a0,-1
    c510:	02075863          	bgez	a4,c540 <gpu_frame_list_init+0x90>
    c514:	5007a683          	lw	a3,1280(a5)
    c518:	464c5737          	lui	a4,0x464c5
    c51c:	43170713          	addi	a4,a4,1073 # 464c5431 <__gpu_framebuffer_a+0x444c5431>
    c520:	02e69063          	bne	a3,a4,c540 <gpu_frame_list_init+0x90>
    c524:	5047a783          	lw	a5,1284(a5)
    c528:	0047f713          	andi	a4,a5,4
    c52c:	02070663          	beqz	a4,c558 <gpu_frame_list_init+0xa8>
    c530:	0087d793          	srli	a5,a5,0x8
    c534:	00f589a3          	sb	a5,19(a1)
    c538:	00058823          	sb	zero,16(a1)
    c53c:	ff900513          	li	a0,-7
    c540:	1dc12083          	lw	ra,476(sp)
    c544:	1d812403          	lw	s0,472(sp)
    c548:	1d412483          	lw	s1,468(sp)
    c54c:	1d012903          	lw	s2,464(sp)
    c550:	1e010113          	addi	sp,sp,480
    c554:	00008067          	ret
    c558:	0017f793          	andi	a5,a5,1
    c55c:	ffd00513          	li	a0,-3
    c560:	fe0790e3          	bnez	a5,c540 <gpu_frame_list_init+0x90>
    c564:	00810513          	addi	a0,sp,8
    c568:	c88ff0ef          	jal	b9f0 <gpu_instances_init>
    c56c:	fc051ae3          	bnez	a0,c540 <gpu_frame_list_init+0x90>
    c570:	01010593          	addi	a1,sp,16
    c574:	00048513          	mv	a0,s1
    c578:	cd4ff0ef          	jal	ba4c <gpu_instances_templates>
    c57c:	00050613          	mv	a2,a0
    c580:	01010593          	addi	a1,sp,16
    c584:	00810513          	addi	a0,sp,8
    c588:	8a5ff0ef          	jal	be2c <gpu_instances_program>
    c58c:	fa051ae3          	bnez	a0,c540 <gpu_frame_list_init+0x90>
    c590:	000017b7          	lui	a5,0x1
    c594:	00b91713          	slli	a4,s2,0xb
    c598:	80078793          	addi	a5,a5,-2048 # 800 <CUSTOM2+0x7a5>
    c59c:	00075463          	bgez	a4,c5a4 <gpu_frame_list_init+0xf4>
    c5a0:	000017b7          	lui	a5,0x1
    c5a4:	00f41223          	sh	a5,4(s0)
    c5a8:	00100793          	li	a5,1
    c5ac:	00f40323          	sb	a5,6(s0)
    c5b0:	00000513          	li	a0,0
    c5b4:	f8dff06f          	j	c540 <gpu_frame_list_init+0x90>
    c5b8:	ff800513          	li	a0,-8
    c5bc:	00008067          	ret

0000c5c0 <gpu_frame_list_render>:
    c5c0:	fd010113          	addi	sp,sp,-48
    c5c4:	02912223          	sw	s1,36(sp)
    c5c8:	03212023          	sw	s2,32(sp)
    c5cc:	01312e23          	sw	s3,28(sp)
    c5d0:	01412c23          	sw	s4,24(sp)
    c5d4:	01512a23          	sw	s5,20(sp)
    c5d8:	02112623          	sw	ra,44(sp)
    c5dc:	02812423          	sw	s0,40(sp)
    c5e0:	01612823          	sw	s6,16(sp)
    c5e4:	01712623          	sw	s7,12(sp)
    c5e8:	01812423          	sw	s8,8(sp)
    c5ec:	01912223          	sw	s9,4(sp)
    c5f0:	00050493          	mv	s1,a0
    c5f4:	00058a93          	mv	s5,a1
    c5f8:	00060913          	mv	s2,a2
    c5fc:	00068993          	mv	s3,a3
    c600:	00070a13          	mv	s4,a4
    c604:	00050663          	beqz	a0,c610 <gpu_frame_list_render+0x50>
    c608:	00754783          	lbu	a5,7(a0)
    c60c:	0a079263          	bnez	a5,c6b0 <gpu_frame_list_render+0xf0>
    c610:	00491713          	slli	a4,s2,0x4
    c614:	015707b3          	add	a5,a4,s5
    c618:	01c95693          	srli	a3,s2,0x1c
    c61c:	00e7b733          	sltu	a4,a5,a4
    c620:	00d70733          	add	a4,a4,a3
    c624:	ff800513          	li	a0,-8
    c628:	08048663          	beqz	s1,c6b4 <gpu_frame_list_render+0xf4>
    c62c:	0004a403          	lw	s0,0(s1)
    c630:	08040263          	beqz	s0,c6b4 <gpu_frame_list_render+0xf4>
    c634:	01044683          	lbu	a3,16(s0)
    c638:	06068e63          	beqz	a3,c6b4 <gpu_frame_list_render+0xf4>
    c63c:	0064c683          	lbu	a3,6(s1)
    c640:	06068a63          	beqz	a3,c6b4 <gpu_frame_list_render+0xf4>
    c644:	060a0863          	beqz	s4,c6b4 <gpu_frame_list_render+0xf4>
    c648:	fff90693          	addi	a3,s2,-1
    c64c:	3ff00613          	li	a2,1023
    c650:	06d66263          	bltu	a2,a3,c6b4 <gpu_frame_list_render+0xf4>
    c654:	00faf693          	andi	a3,s5,15
    c658:	04069e63          	bnez	a3,c6b4 <gpu_frame_list_render+0xf4>
    c65c:	02d20637          	lui	a2,0x2d20
    c660:	04caea63          	bltu	s5,a2,c6b4 <gpu_frame_list_render+0xf4>
    c664:	0044d683          	lhu	a3,4(s1)
    c668:	00469693          	slli	a3,a3,0x4
    c66c:	00c686b3          	add	a3,a3,a2
    c670:	1e071463          	bnez	a4,c858 <gpu_frame_list_render+0x298>
    c674:	1ef6e263          	bltu	a3,a5,c858 <gpu_frame_list_render+0x298>
    c678:	fff78713          	addi	a4,a5,-1 # fff <CUSTOM2+0xfa4>
    c67c:	00f037b3          	snez	a5,a5
    c680:	fff78793          	addi	a5,a5,-1
    c684:	01279613          	slli	a2,a5,0x12
    c688:	00e75713          	srli	a4,a4,0xe
    c68c:	00ead693          	srli	a3,s5,0xe
    c690:	00e66733          	or	a4,a2,a4
    c694:	00e7d793          	srli	a5,a5,0xe
    c698:	1ce69063          	bne	a3,a4,c858 <gpu_frame_list_render+0x298>
    c69c:	1a079e63          	bnez	a5,c858 <gpu_frame_list_render+0x298>
    c6a0:	00042783          	lw	a5,0(s0)
    c6a4:	5047a783          	lw	a5,1284(a5)
    c6a8:	0017f793          	andi	a5,a5,1
    c6ac:	02078e63          	beqz	a5,c6e8 <gpu_frame_list_render+0x128>
    c6b0:	ffd00513          	li	a0,-3
    c6b4:	02c12083          	lw	ra,44(sp)
    c6b8:	02812403          	lw	s0,40(sp)
    c6bc:	02412483          	lw	s1,36(sp)
    c6c0:	02012903          	lw	s2,32(sp)
    c6c4:	01c12983          	lw	s3,28(sp)
    c6c8:	01812a03          	lw	s4,24(sp)
    c6cc:	01412a83          	lw	s5,20(sp)
    c6d0:	01012b03          	lw	s6,16(sp)
    c6d4:	00c12b83          	lw	s7,12(sp)
    c6d8:	00812c03          	lw	s8,8(sp)
    c6dc:	00412c83          	lw	s9,4(sp)
    c6e0:	03010113          	addi	sp,sp,48
    c6e4:	00008067          	ret
    c6e8:	01244783          	lbu	a5,18(s0)
    c6ec:	0a079463          	bnez	a5,c794 <gpu_frame_list_render+0x1d4>
    c6f0:	0004a783          	lw	a5,0(s1)
    c6f4:	0007a783          	lw	a5,0(a5)
    c6f8:	0087ab83          	lw	s7,8(a5)
    c6fc:	080bfb93          	andi	s7,s7,128
    c700:	fa0b98e3          	bnez	s7,c6b0 <gpu_frame_list_render+0xf0>
    c704:	0387a783          	lw	a5,56(a5)
    c708:	0ff7f793          	zext.b	a5,a5
    c70c:	00f409a3          	sb	a5,19(s0)
    c710:	06079e63          	bnez	a5,c78c <gpu_frame_list_render+0x1cc>
    c714:	00a45c83          	lhu	s9,10(s0)
    c718:	934f50ef          	jal	184c <gpu_platform_sync>
    c71c:	0004a783          	lw	a5,0(s1)
    c720:	012c8c33          	add	s8,s9,s2
    c724:	010c1c13          	slli	s8,s8,0x10
    c728:	0007a783          	lw	a5,0(a5)
    c72c:	010c5c13          	srli	s8,s8,0x10
    c730:	fffc0b13          	addi	s6,s8,-1
    c734:	5157a623          	sw	s5,1292(a5)
    c738:	5127a823          	sw	s2,1296(a5)
    c73c:	5197aa23          	sw	s9,1300(a5)
    c740:	010b1b13          	slli	s6,s6,0x10
    c744:	010b5b13          	srli	s6,s6,0x10
    c748:	5137ac23          	sw	s3,1304(a5)
    c74c:	0ff0000f          	fence
    c750:	0004a703          	lw	a4,0(s1)
    c754:	00100793          	li	a5,1
    c758:	00f483a3          	sb	a5,7(s1)
    c75c:	00072703          	lw	a4,0(a4)
    c760:	50f72423          	sw	a5,1288(a4)
    c764:	0ff0000f          	fence
    c768:	0004a783          	lw	a5,0(s1)
    c76c:	0007a683          	lw	a3,0(a5)
    c770:	50468713          	addi	a4,a3,1284
    c774:	00072783          	lw	a5,0(a4)
    c778:	0047f613          	andi	a2,a5,4
    c77c:	02060863          	beqz	a2,c7ac <gpu_frame_list_render+0x1ec>
    c780:	0087d793          	srli	a5,a5,0x8
    c784:	00f409a3          	sb	a5,19(s0)
    c788:	00040823          	sb	zero,16(s0)
    c78c:	ff900513          	li	a0,-7
    c790:	f25ff06f          	j	c6b4 <gpu_frame_list_render+0xf4>
    c794:	00e45583          	lhu	a1,14(s0)
    c798:	000a0613          	mv	a2,s4
    c79c:	00040513          	mv	a0,s0
    c7a0:	c29f50ef          	jal	23c8 <gpu_wait_tag>
    c7a4:	f40506e3          	beqz	a0,c6f0 <gpu_frame_list_render+0x130>
    c7a8:	f0dff06f          	j	c6b4 <gpu_frame_list_render+0xf4>
    c7ac:	0027f613          	andi	a2,a5,2
    c7b0:	00061c63          	bnez	a2,c7c8 <gpu_frame_list_render+0x208>
    c7b4:	001b8b93          	addi	s7,s7,1
    c7b8:	fb4beee3          	bltu	s7,s4,c774 <gpu_frame_list_render+0x1b4>
    c7bc:	00040823          	sb	zero,16(s0)
    c7c0:	ffb00513          	li	a0,-5
    c7c4:	ef1ff06f          	j	c6b4 <gpu_frame_list_render+0xf4>
    c7c8:	0017f793          	andi	a5,a5,1
    c7cc:	02079663          	bnez	a5,c7f8 <gpu_frame_list_render+0x238>
    c7d0:	51c6a783          	lw	a5,1308(a3)
    c7d4:	02f99263          	bne	s3,a5,c7f8 <gpu_frame_list_render+0x238>
    c7d8:	5246a783          	lw	a5,1316(a3)
    c7dc:	00f91e63          	bne	s2,a5,c7f8 <gpu_frame_list_render+0x238>
    c7e0:	5206a783          	lw	a5,1312(a3)
    c7e4:	00fb1a63          	bne	s6,a5,c7f8 <gpu_frame_list_render+0x238>
    c7e8:	0346a783          	lw	a5,52(a3)
    c7ec:	01079793          	slli	a5,a5,0x10
    c7f0:	0107d793          	srli	a5,a5,0x10
    c7f4:	01678863          	beq	a5,s6,c804 <gpu_frame_list_render+0x244>
    c7f8:	00040823          	sb	zero,16(s0)
    c7fc:	ffa00513          	li	a0,-6
    c800:	eb5ff06f          	j	c6b4 <gpu_frame_list_render+0xf4>
    c804:	0386a783          	lw	a5,56(a3)
    c808:	0ff7f793          	zext.b	a5,a5
    c80c:	00f409a3          	sb	a5,19(s0)
    c810:	f6079ce3          	bnez	a5,c788 <gpu_frame_list_render+0x1c8>
    c814:	00442783          	lw	a5,4(s0)
    c818:	000408a3          	sb	zero,17(s0)
    c81c:	00040923          	sb	zero,18(s0)
    c820:	012787b3          	add	a5,a5,s2
    c824:	00f42223          	sw	a5,4(s0)
    c828:	0086a783          	lw	a5,8(a3)
    c82c:	01444703          	lbu	a4,20(s0)
    c830:	01841523          	sh	s8,10(s0)
    c834:	0087d793          	srli	a5,a5,0x8
    c838:	01641623          	sh	s6,12(s0)
    c83c:	01641723          	sh	s6,14(s0)
    c840:	01f7f793          	andi	a5,a5,31
    c844:	00f77463          	bgeu	a4,a5,c84c <gpu_frame_list_render+0x28c>
    c848:	00f40a23          	sb	a5,20(s0)
    c84c:	000483a3          	sb	zero,7(s1)
    c850:	00000513          	li	a0,0
    c854:	e61ff06f          	j	c6b4 <gpu_frame_list_render+0xf4>
    c858:	ff800513          	li	a0,-8
    c85c:	e59ff06f          	j	c6b4 <gpu_frame_list_render+0xf4>

0000c860 <gpu_frame_list_render_span>:
    c860:	fd010113          	addi	sp,sp,-48
    c864:	02812423          	sw	s0,40(sp)
    c868:	03212023          	sw	s2,32(sp)
    c86c:	01312e23          	sw	s3,28(sp)
    c870:	01412c23          	sw	s4,24(sp)
    c874:	01512a23          	sw	s5,20(sp)
    c878:	02112623          	sw	ra,44(sp)
    c87c:	02912223          	sw	s1,36(sp)
    c880:	01612823          	sw	s6,16(sp)
    c884:	01712623          	sw	s7,12(sp)
    c888:	00050993          	mv	s3,a0
    c88c:	00058913          	mv	s2,a1
    c890:	00060413          	mv	s0,a2
    c894:	00068a13          	mv	s4,a3
    c898:	00070a93          	mv	s5,a4
    c89c:	00050863          	beqz	a0,c8ac <gpu_frame_list_render_span+0x4c>
    c8a0:	00754783          	lbu	a5,7(a0)
    c8a4:	ffd00513          	li	a0,-3
    c8a8:	0a079863          	bnez	a5,c958 <gpu_frame_list_render_span+0xf8>
    c8ac:	00441793          	slli	a5,s0,0x4
    c8b0:	01278633          	add	a2,a5,s2
    c8b4:	01c45713          	srli	a4,s0,0x1c
    c8b8:	00f637b3          	sltu	a5,a2,a5
    c8bc:	00e786b3          	add	a3,a5,a4
    c8c0:	ff800513          	li	a0,-8
    c8c4:	08098a63          	beqz	s3,c958 <gpu_frame_list_render_span+0xf8>
    c8c8:	0009a783          	lw	a5,0(s3)
    c8cc:	08078663          	beqz	a5,c958 <gpu_frame_list_render_span+0xf8>
    c8d0:	0107c783          	lbu	a5,16(a5)
    c8d4:	08078263          	beqz	a5,c958 <gpu_frame_list_render_span+0xf8>
    c8d8:	0069c783          	lbu	a5,6(s3)
    c8dc:	06078e63          	beqz	a5,c958 <gpu_frame_list_render_span+0xf8>
    c8e0:	060a8c63          	beqz	s5,c958 <gpu_frame_list_render_span+0xf8>
    c8e4:	06040a63          	beqz	s0,c958 <gpu_frame_list_render_span+0xf8>
    c8e8:	0049d783          	lhu	a5,4(s3)
    c8ec:	0687e663          	bltu	a5,s0,c958 <gpu_frame_list_render_span+0xf8>
    c8f0:	00f97713          	andi	a4,s2,15
    c8f4:	06071263          	bnez	a4,c958 <gpu_frame_list_render_span+0xf8>
    c8f8:	02d20737          	lui	a4,0x2d20
    c8fc:	04e96e63          	bltu	s2,a4,c958 <gpu_frame_list_render_span+0xf8>
    c900:	00479793          	slli	a5,a5,0x4
    c904:	00e787b3          	add	a5,a5,a4
    c908:	06069e63          	bnez	a3,c984 <gpu_frame_list_render_span+0x124>
    c90c:	06c7ec63          	bltu	a5,a2,c984 <gpu_frame_list_render_span+0x124>
    c910:	00004b37          	lui	s6,0x4
    c914:	fffb0b93          	addi	s7,s6,-1 # 3fff <update_gpu_target+0x34b>
    c918:	017974b3          	and	s1,s2,s7
    c91c:	409b04b3          	sub	s1,s6,s1
    c920:	0044d493          	srli	s1,s1,0x4
    c924:	00947463          	bgeu	s0,s1,c92c <gpu_frame_list_render_span+0xcc>
    c928:	00040493          	mv	s1,s0
    c92c:	000a8713          	mv	a4,s5
    c930:	000a0693          	mv	a3,s4
    c934:	00048613          	mv	a2,s1
    c938:	00090593          	mv	a1,s2
    c93c:	00098513          	mv	a0,s3
    c940:	c81ff0ef          	jal	c5c0 <gpu_frame_list_render>
    c944:	00051a63          	bnez	a0,c958 <gpu_frame_list_render_span+0xf8>
    c948:	00449793          	slli	a5,s1,0x4
    c94c:	40940433          	sub	s0,s0,s1
    c950:	00f90933          	add	s2,s2,a5
    c954:	fc0412e3          	bnez	s0,c918 <gpu_frame_list_render_span+0xb8>
    c958:	02c12083          	lw	ra,44(sp)
    c95c:	02812403          	lw	s0,40(sp)
    c960:	02412483          	lw	s1,36(sp)
    c964:	02012903          	lw	s2,32(sp)
    c968:	01c12983          	lw	s3,28(sp)
    c96c:	01812a03          	lw	s4,24(sp)
    c970:	01412a83          	lw	s5,20(sp)
    c974:	01012b03          	lw	s6,16(sp)
    c978:	00c12b83          	lw	s7,12(sp)
    c97c:	03010113          	addi	sp,sp,48
    c980:	00008067          	ret
    c984:	ff800513          	li	a0,-8
    c988:	fd1ff06f          	j	c958 <gpu_frame_list_render_span+0xf8>

0000c98c <__udivdi3>:
    c98c:	00060813          	mv	a6,a2
    c990:	00050893          	mv	a7,a0
    c994:	00058713          	mv	a4,a1
    c998:	0e069063          	bnez	a3,ca78 <__udivdi3+0xec>
    c99c:	12c5fe63          	bgeu	a1,a2,cad8 <__udivdi3+0x14c>
    c9a0:	000107b7          	lui	a5,0x10
    c9a4:	1ef66e63          	bltu	a2,a5,cba0 <__udivdi3+0x214>
    c9a8:	010007b7          	lui	a5,0x1000
    c9ac:	01800693          	li	a3,24
    c9b0:	00f67463          	bgeu	a2,a5,c9b8 <__udivdi3+0x2c>
    c9b4:	01000693          	li	a3,16
    c9b8:	00d65333          	srl	t1,a2,a3
    c9bc:	00002797          	auipc	a5,0x2
    c9c0:	ad078793          	addi	a5,a5,-1328 # e48c <__clz_tab>
    c9c4:	006787b3          	add	a5,a5,t1
    c9c8:	0007c783          	lbu	a5,0(a5)
    c9cc:	02000313          	li	t1,32
    c9d0:	00d787b3          	add	a5,a5,a3
    c9d4:	40f306b3          	sub	a3,t1,a5
    c9d8:	00f30c63          	beq	t1,a5,c9f0 <__udivdi3+0x64>
    c9dc:	00d59733          	sll	a4,a1,a3
    c9e0:	00f557b3          	srl	a5,a0,a5
    c9e4:	00d61833          	sll	a6,a2,a3
    c9e8:	00e7e733          	or	a4,a5,a4
    c9ec:	00d518b3          	sll	a7,a0,a3
    c9f0:	01085613          	srli	a2,a6,0x10
    c9f4:	02c75533          	divu	a0,a4,a2
    c9f8:	01081693          	slli	a3,a6,0x10
    c9fc:	0106d693          	srli	a3,a3,0x10
    ca00:	0108d793          	srli	a5,a7,0x10
    ca04:	02c77733          	remu	a4,a4,a2
    ca08:	02a685b3          	mul	a1,a3,a0
    ca0c:	01071713          	slli	a4,a4,0x10
    ca10:	00e7e7b3          	or	a5,a5,a4
    ca14:	00b7fc63          	bgeu	a5,a1,ca2c <__udivdi3+0xa0>
    ca18:	00f807b3          	add	a5,a6,a5
    ca1c:	fff50713          	addi	a4,a0,-1
    ca20:	0107e463          	bltu	a5,a6,ca28 <__udivdi3+0x9c>
    ca24:	40b7e063          	bltu	a5,a1,ce24 <__udivdi3+0x498>
    ca28:	00070513          	mv	a0,a4
    ca2c:	40b787b3          	sub	a5,a5,a1
    ca30:	02c7d733          	divu	a4,a5,a2
    ca34:	01089893          	slli	a7,a7,0x10
    ca38:	0108d893          	srli	a7,a7,0x10
    ca3c:	02c7f7b3          	remu	a5,a5,a2
    ca40:	02e686b3          	mul	a3,a3,a4
    ca44:	01079793          	slli	a5,a5,0x10
    ca48:	00f8e8b3          	or	a7,a7,a5
    ca4c:	00d8fe63          	bgeu	a7,a3,ca68 <__udivdi3+0xdc>
    ca50:	011808b3          	add	a7,a6,a7
    ca54:	fff70793          	addi	a5,a4,-1 # 2d1ffff <__gpu_framebuffer_a+0xd1ffff>
    ca58:	0108e663          	bltu	a7,a6,ca64 <__udivdi3+0xd8>
    ca5c:	ffe70713          	addi	a4,a4,-2
    ca60:	00d8e463          	bltu	a7,a3,ca68 <__udivdi3+0xdc>
    ca64:	00078713          	mv	a4,a5
    ca68:	01051513          	slli	a0,a0,0x10
    ca6c:	00e56533          	or	a0,a0,a4
    ca70:	00000593          	li	a1,0
    ca74:	00008067          	ret
    ca78:	00d5f863          	bgeu	a1,a3,ca88 <__udivdi3+0xfc>
    ca7c:	00000593          	li	a1,0
    ca80:	00000513          	li	a0,0
    ca84:	00008067          	ret
    ca88:	000107b7          	lui	a5,0x10
    ca8c:	1ef6e863          	bltu	a3,a5,cc7c <__udivdi3+0x2f0>
    ca90:	01000737          	lui	a4,0x1000
    ca94:	01800793          	li	a5,24
    ca98:	00e6f463          	bgeu	a3,a4,caa0 <__udivdi3+0x114>
    ca9c:	01000793          	li	a5,16
    caa0:	00f6d833          	srl	a6,a3,a5
    caa4:	00002717          	auipc	a4,0x2
    caa8:	9e870713          	addi	a4,a4,-1560 # e48c <__clz_tab>
    caac:	01070733          	add	a4,a4,a6
    cab0:	00074703          	lbu	a4,0(a4)
    cab4:	02000893          	li	a7,32
    cab8:	00f70733          	add	a4,a4,a5
    cabc:	40e88833          	sub	a6,a7,a4
    cac0:	1ee89663          	bne	a7,a4,ccac <__udivdi3+0x320>
    cac4:	32b6e463          	bltu	a3,a1,cdec <__udivdi3+0x460>
    cac8:	00c53533          	sltu	a0,a0,a2
    cacc:	00153513          	seqz	a0,a0
    cad0:	00000593          	li	a1,0
    cad4:	00008067          	ret
    cad8:	0c060c63          	beqz	a2,cbb0 <__udivdi3+0x224>
    cadc:	000107b7          	lui	a5,0x10
    cae0:	2ef67c63          	bgeu	a2,a5,cdd8 <__udivdi3+0x44c>
    cae4:	10063713          	sltiu	a4,a2,256
    cae8:	00173713          	seqz	a4,a4
    caec:	00371713          	slli	a4,a4,0x3
    caf0:	00e656b3          	srl	a3,a2,a4
    caf4:	00002797          	auipc	a5,0x2
    caf8:	99878793          	addi	a5,a5,-1640 # e48c <__clz_tab>
    cafc:	00d787b3          	add	a5,a5,a3
    cb00:	0007c783          	lbu	a5,0(a5)
    cb04:	02000693          	li	a3,32
    cb08:	00e787b3          	add	a5,a5,a4
    cb0c:	40f68eb3          	sub	t4,a3,a5
    cb10:	0cf69463          	bne	a3,a5,cbd8 <__udivdi3+0x24c>
    cb14:	40c587b3          	sub	a5,a1,a2
    cb18:	01065693          	srli	a3,a2,0x10
    cb1c:	01061613          	slli	a2,a2,0x10
    cb20:	01065613          	srli	a2,a2,0x10
    cb24:	00100593          	li	a1,1
    cb28:	02d7d533          	divu	a0,a5,a3
    cb2c:	0108d713          	srli	a4,a7,0x10
    cb30:	02d7f7b3          	remu	a5,a5,a3
    cb34:	02c50333          	mul	t1,a0,a2
    cb38:	01079793          	slli	a5,a5,0x10
    cb3c:	00f767b3          	or	a5,a4,a5
    cb40:	0067fc63          	bgeu	a5,t1,cb58 <__udivdi3+0x1cc>
    cb44:	00f807b3          	add	a5,a6,a5
    cb48:	fff50713          	addi	a4,a0,-1
    cb4c:	0107e463          	bltu	a5,a6,cb54 <__udivdi3+0x1c8>
    cb50:	2c67e463          	bltu	a5,t1,ce18 <__udivdi3+0x48c>
    cb54:	00070513          	mv	a0,a4
    cb58:	406787b3          	sub	a5,a5,t1
    cb5c:	02d7d733          	divu	a4,a5,a3
    cb60:	01089893          	slli	a7,a7,0x10
    cb64:	0108d893          	srli	a7,a7,0x10
    cb68:	02d7f7b3          	remu	a5,a5,a3
    cb6c:	02c70633          	mul	a2,a4,a2
    cb70:	01079793          	slli	a5,a5,0x10
    cb74:	00f8e8b3          	or	a7,a7,a5
    cb78:	00c8fe63          	bgeu	a7,a2,cb94 <__udivdi3+0x208>
    cb7c:	011808b3          	add	a7,a6,a7
    cb80:	fff70793          	addi	a5,a4,-1
    cb84:	0108e663          	bltu	a7,a6,cb90 <__udivdi3+0x204>
    cb88:	ffe70713          	addi	a4,a4,-2
    cb8c:	00c8e463          	bltu	a7,a2,cb94 <__udivdi3+0x208>
    cb90:	00078713          	mv	a4,a5
    cb94:	01051513          	slli	a0,a0,0x10
    cb98:	00e56533          	or	a0,a0,a4
    cb9c:	00008067          	ret
    cba0:	10063693          	sltiu	a3,a2,256
    cba4:	0016b693          	seqz	a3,a3
    cba8:	00369693          	slli	a3,a3,0x3
    cbac:	e0dff06f          	j	c9b8 <__udivdi3+0x2c>
    cbb0:	00000693          	li	a3,0
    cbb4:	00002797          	auipc	a5,0x2
    cbb8:	8d878793          	addi	a5,a5,-1832 # e48c <__clz_tab>
    cbbc:	00d787b3          	add	a5,a5,a3
    cbc0:	0007c783          	lbu	a5,0(a5)
    cbc4:	00000713          	li	a4,0
    cbc8:	02000693          	li	a3,32
    cbcc:	00e787b3          	add	a5,a5,a4
    cbd0:	40f68eb3          	sub	t4,a3,a5
    cbd4:	f4f680e3          	beq	a3,a5,cb14 <__udivdi3+0x188>
    cbd8:	01d61833          	sll	a6,a2,t4
    cbdc:	00f5d333          	srl	t1,a1,a5
    cbe0:	01085693          	srli	a3,a6,0x10
    cbe4:	02d35e33          	divu	t3,t1,a3
    cbe8:	01081613          	slli	a2,a6,0x10
    cbec:	01d595b3          	sll	a1,a1,t4
    cbf0:	01065613          	srli	a2,a2,0x10
    cbf4:	00f557b3          	srl	a5,a0,a5
    cbf8:	00b7e7b3          	or	a5,a5,a1
    cbfc:	0107d713          	srli	a4,a5,0x10
    cc00:	01d518b3          	sll	a7,a0,t4
    cc04:	02d37333          	remu	t1,t1,a3
    cc08:	03c605b3          	mul	a1,a2,t3
    cc0c:	01031313          	slli	t1,t1,0x10
    cc10:	00676733          	or	a4,a4,t1
    cc14:	00b77e63          	bgeu	a4,a1,cc30 <__udivdi3+0x2a4>
    cc18:	00e80733          	add	a4,a6,a4
    cc1c:	fffe0513          	addi	a0,t3,-1
    cc20:	1f076463          	bltu	a4,a6,ce08 <__udivdi3+0x47c>
    cc24:	1eb77263          	bgeu	a4,a1,ce08 <__udivdi3+0x47c>
    cc28:	ffee0e13          	addi	t3,t3,-2
    cc2c:	01070733          	add	a4,a4,a6
    cc30:	40b70733          	sub	a4,a4,a1
    cc34:	02d75533          	divu	a0,a4,a3
    cc38:	01079793          	slli	a5,a5,0x10
    cc3c:	0107d793          	srli	a5,a5,0x10
    cc40:	02d77733          	remu	a4,a4,a3
    cc44:	02a60333          	mul	t1,a2,a0
    cc48:	01071713          	slli	a4,a4,0x10
    cc4c:	00e7e7b3          	or	a5,a5,a4
    cc50:	0067fe63          	bgeu	a5,t1,cc6c <__udivdi3+0x2e0>
    cc54:	00f807b3          	add	a5,a6,a5
    cc58:	fff50713          	addi	a4,a0,-1
    cc5c:	1907ee63          	bltu	a5,a6,cdf8 <__udivdi3+0x46c>
    cc60:	1867fc63          	bgeu	a5,t1,cdf8 <__udivdi3+0x46c>
    cc64:	ffe50513          	addi	a0,a0,-2
    cc68:	010787b3          	add	a5,a5,a6
    cc6c:	010e1593          	slli	a1,t3,0x10
    cc70:	406787b3          	sub	a5,a5,t1
    cc74:	00a5e5b3          	or	a1,a1,a0
    cc78:	eb1ff06f          	j	cb28 <__udivdi3+0x19c>
    cc7c:	1006b793          	sltiu	a5,a3,256
    cc80:	0017b793          	seqz	a5,a5
    cc84:	00379793          	slli	a5,a5,0x3
    cc88:	00f6d833          	srl	a6,a3,a5
    cc8c:	00002717          	auipc	a4,0x2
    cc90:	80070713          	addi	a4,a4,-2048 # e48c <__clz_tab>
    cc94:	01070733          	add	a4,a4,a6
    cc98:	00074703          	lbu	a4,0(a4)
    cc9c:	02000893          	li	a7,32
    cca0:	00f70733          	add	a4,a4,a5
    cca4:	40e88833          	sub	a6,a7,a4
    cca8:	e0e88ee3          	beq	a7,a4,cac4 <__udivdi3+0x138>
    ccac:	00e65e33          	srl	t3,a2,a4
    ccb0:	010696b3          	sll	a3,a3,a6
    ccb4:	00de6e33          	or	t3,t3,a3
    ccb8:	00e5d8b3          	srl	a7,a1,a4
    ccbc:	010e5e93          	srli	t4,t3,0x10
    ccc0:	03d8d7b3          	divu	a5,a7,t4
    ccc4:	010e1313          	slli	t1,t3,0x10
    ccc8:	010595b3          	sll	a1,a1,a6
    cccc:	01035313          	srli	t1,t1,0x10
    ccd0:	00e55733          	srl	a4,a0,a4
    ccd4:	00b76733          	or	a4,a4,a1
    ccd8:	01075693          	srli	a3,a4,0x10
    ccdc:	01061633          	sll	a2,a2,a6
    cce0:	03d8f8b3          	remu	a7,a7,t4
    cce4:	02f305b3          	mul	a1,t1,a5
    cce8:	01089893          	slli	a7,a7,0x10
    ccec:	0116e6b3          	or	a3,a3,a7
    ccf0:	00b6fe63          	bgeu	a3,a1,cd0c <__udivdi3+0x380>
    ccf4:	00de06b3          	add	a3,t3,a3
    ccf8:	fff78893          	addi	a7,a5,-1
    ccfc:	11c6ea63          	bltu	a3,t3,ce10 <__udivdi3+0x484>
    cd00:	10b6f863          	bgeu	a3,a1,ce10 <__udivdi3+0x484>
    cd04:	ffe78793          	addi	a5,a5,-2
    cd08:	01c686b3          	add	a3,a3,t3
    cd0c:	40b686b3          	sub	a3,a3,a1
    cd10:	03d6d5b3          	divu	a1,a3,t4
    cd14:	01071713          	slli	a4,a4,0x10
    cd18:	01075713          	srli	a4,a4,0x10
    cd1c:	03d6f6b3          	remu	a3,a3,t4
    cd20:	02b308b3          	mul	a7,t1,a1
    cd24:	01069693          	slli	a3,a3,0x10
    cd28:	00d76733          	or	a4,a4,a3
    cd2c:	01177e63          	bgeu	a4,a7,cd48 <__udivdi3+0x3bc>
    cd30:	00ee0733          	add	a4,t3,a4
    cd34:	fff58693          	addi	a3,a1,-1
    cd38:	0dc76463          	bltu	a4,t3,ce00 <__udivdi3+0x474>
    cd3c:	0d177263          	bgeu	a4,a7,ce00 <__udivdi3+0x474>
    cd40:	ffe58593          	addi	a1,a1,-2
    cd44:	01c70733          	add	a4,a4,t3
    cd48:	01079793          	slli	a5,a5,0x10
    cd4c:	00010eb7          	lui	t4,0x10
    cd50:	00b7e7b3          	or	a5,a5,a1
    cd54:	fffe8693          	addi	a3,t4,-1 # ffff <__global_pointer$+0x127f>
    cd58:	00d7f5b3          	and	a1,a5,a3
    cd5c:	0107d313          	srli	t1,a5,0x10
    cd60:	00d676b3          	and	a3,a2,a3
    cd64:	01065613          	srli	a2,a2,0x10
    cd68:	02d58e33          	mul	t3,a1,a3
    cd6c:	41170733          	sub	a4,a4,a7
    cd70:	02d306b3          	mul	a3,t1,a3
    cd74:	010e5893          	srli	a7,t3,0x10
    cd78:	02c585b3          	mul	a1,a1,a2
    cd7c:	00d585b3          	add	a1,a1,a3
    cd80:	00b885b3          	add	a1,a7,a1
    cd84:	02c30333          	mul	t1,t1,a2
    cd88:	00d5f463          	bgeu	a1,a3,cd90 <__udivdi3+0x404>
    cd8c:	01d30333          	add	t1,t1,t4
    cd90:	0105d693          	srli	a3,a1,0x10
    cd94:	006686b3          	add	a3,a3,t1
    cd98:	02d76a63          	bltu	a4,a3,cdcc <__udivdi3+0x440>
    cd9c:	00d70863          	beq	a4,a3,cdac <__udivdi3+0x420>
    cda0:	00078513          	mv	a0,a5
    cda4:	00000593          	li	a1,0
    cda8:	00008067          	ret
    cdac:	000106b7          	lui	a3,0x10
    cdb0:	fff68693          	addi	a3,a3,-1 # ffff <__global_pointer$+0x127f>
    cdb4:	00d5f733          	and	a4,a1,a3
    cdb8:	01071713          	slli	a4,a4,0x10
    cdbc:	00de7e33          	and	t3,t3,a3
    cdc0:	01051533          	sll	a0,a0,a6
    cdc4:	01c70733          	add	a4,a4,t3
    cdc8:	fce57ce3          	bgeu	a0,a4,cda0 <__udivdi3+0x414>
    cdcc:	fff78513          	addi	a0,a5,-1
    cdd0:	00000593          	li	a1,0
    cdd4:	00008067          	ret
    cdd8:	010007b7          	lui	a5,0x1000
    cddc:	04f67a63          	bgeu	a2,a5,ce30 <__udivdi3+0x4a4>
    cde0:	01065693          	srli	a3,a2,0x10
    cde4:	01000713          	li	a4,16
    cde8:	d0dff06f          	j	caf4 <__udivdi3+0x168>
    cdec:	00000593          	li	a1,0
    cdf0:	00100513          	li	a0,1
    cdf4:	00008067          	ret
    cdf8:	00070513          	mv	a0,a4
    cdfc:	e71ff06f          	j	cc6c <__udivdi3+0x2e0>
    ce00:	00068593          	mv	a1,a3
    ce04:	f45ff06f          	j	cd48 <__udivdi3+0x3bc>
    ce08:	00050e13          	mv	t3,a0
    ce0c:	e25ff06f          	j	cc30 <__udivdi3+0x2a4>
    ce10:	00088793          	mv	a5,a7
    ce14:	ef9ff06f          	j	cd0c <__udivdi3+0x380>
    ce18:	ffe50513          	addi	a0,a0,-2
    ce1c:	010787b3          	add	a5,a5,a6
    ce20:	d39ff06f          	j	cb58 <__udivdi3+0x1cc>
    ce24:	ffe50513          	addi	a0,a0,-2
    ce28:	010787b3          	add	a5,a5,a6
    ce2c:	c01ff06f          	j	ca2c <__udivdi3+0xa0>
    ce30:	01865693          	srli	a3,a2,0x18
    ce34:	01800713          	li	a4,24
    ce38:	cbdff06f          	j	caf4 <__udivdi3+0x168>

0000ce3c <__umoddi3>:
    ce3c:	00060813          	mv	a6,a2
    ce40:	00050893          	mv	a7,a0
    ce44:	00058793          	mv	a5,a1
    ce48:	00058713          	mv	a4,a1
    ce4c:	0c069863          	bnez	a3,cf1c <__umoddi3+0xe0>
    ce50:	12c5fa63          	bgeu	a1,a2,cf84 <__umoddi3+0x148>
    ce54:	000107b7          	lui	a5,0x10
    ce58:	1cf66c63          	bltu	a2,a5,d030 <__umoddi3+0x1f4>
    ce5c:	010007b7          	lui	a5,0x1000
    ce60:	01800693          	li	a3,24
    ce64:	00f67463          	bgeu	a2,a5,ce6c <__umoddi3+0x30>
    ce68:	01000693          	li	a3,16
    ce6c:	00d65333          	srl	t1,a2,a3
    ce70:	00001797          	auipc	a5,0x1
    ce74:	61c78793          	addi	a5,a5,1564 # e48c <__clz_tab>
    ce78:	006787b3          	add	a5,a5,t1
    ce7c:	0007c783          	lbu	a5,0(a5)
    ce80:	02000313          	li	t1,32
    ce84:	00d787b3          	add	a5,a5,a3
    ce88:	40f306b3          	sub	a3,t1,a5
    ce8c:	00f30c63          	beq	t1,a5,cea4 <__umoddi3+0x68>
    ce90:	00d59733          	sll	a4,a1,a3
    ce94:	00f557b3          	srl	a5,a0,a5
    ce98:	00d61833          	sll	a6,a2,a3
    ce9c:	00e7e733          	or	a4,a5,a4
    cea0:	00d518b3          	sll	a7,a0,a3
    cea4:	01085593          	srli	a1,a6,0x10
    cea8:	02b75633          	divu	a2,a4,a1
    ceac:	01081313          	slli	t1,a6,0x10
    ceb0:	01035313          	srli	t1,t1,0x10
    ceb4:	0108d793          	srli	a5,a7,0x10
    ceb8:	02b77733          	remu	a4,a4,a1
    cebc:	02660633          	mul	a2,a2,t1
    cec0:	01071713          	slli	a4,a4,0x10
    cec4:	00e7e7b3          	or	a5,a5,a4
    cec8:	00c7f863          	bgeu	a5,a2,ced8 <__umoddi3+0x9c>
    cecc:	00f807b3          	add	a5,a6,a5
    ced0:	0107e463          	bltu	a5,a6,ced8 <__umoddi3+0x9c>
    ced4:	3cc7e263          	bltu	a5,a2,d298 <__umoddi3+0x45c>
    ced8:	40c787b3          	sub	a5,a5,a2
    cedc:	02b7d733          	divu	a4,a5,a1
    cee0:	01089513          	slli	a0,a7,0x10
    cee4:	01055513          	srli	a0,a0,0x10
    cee8:	02b7f7b3          	remu	a5,a5,a1
    ceec:	02670733          	mul	a4,a4,t1
    cef0:	01079793          	slli	a5,a5,0x10
    cef4:	00f56533          	or	a0,a0,a5
    cef8:	00e57a63          	bgeu	a0,a4,cf0c <__umoddi3+0xd0>
    cefc:	00a80533          	add	a0,a6,a0
    cf00:	01056663          	bltu	a0,a6,cf0c <__umoddi3+0xd0>
    cf04:	00e57463          	bgeu	a0,a4,cf0c <__umoddi3+0xd0>
    cf08:	01050533          	add	a0,a0,a6
    cf0c:	40e50533          	sub	a0,a0,a4
    cf10:	00d55533          	srl	a0,a0,a3
    cf14:	00000593          	li	a1,0
    cf18:	00008067          	ret
    cf1c:	00d5f463          	bgeu	a1,a3,cf24 <__umoddi3+0xe8>
    cf20:	00008067          	ret
    cf24:	00010737          	lui	a4,0x10
    cf28:	1ce6e663          	bltu	a3,a4,d0f4 <__umoddi3+0x2b8>
    cf2c:	01000737          	lui	a4,0x1000
    cf30:	01800813          	li	a6,24
    cf34:	00e6f463          	bgeu	a3,a4,cf3c <__umoddi3+0x100>
    cf38:	01000813          	li	a6,16
    cf3c:	0106d333          	srl	t1,a3,a6
    cf40:	00001717          	auipc	a4,0x1
    cf44:	54c70713          	addi	a4,a4,1356 # e48c <__clz_tab>
    cf48:	00670733          	add	a4,a4,t1
    cf4c:	00074703          	lbu	a4,0(a4)
    cf50:	02000313          	li	t1,32
    cf54:	01070733          	add	a4,a4,a6
    cf58:	40e30833          	sub	a6,t1,a4
    cf5c:	1ce31463          	bne	t1,a4,d124 <__umoddi3+0x2e8>
    cf60:	00b6e463          	bltu	a3,a1,cf68 <__umoddi3+0x12c>
    cf64:	00c56a63          	bltu	a0,a2,cf78 <__umoddi3+0x13c>
    cf68:	40c508b3          	sub	a7,a0,a2
    cf6c:	40d586b3          	sub	a3,a1,a3
    cf70:	011537b3          	sltu	a5,a0,a7
    cf74:	40f687b3          	sub	a5,a3,a5
    cf78:	00088513          	mv	a0,a7
    cf7c:	00078593          	mv	a1,a5
    cf80:	00008067          	ret
    cf84:	0a060e63          	beqz	a2,d040 <__umoddi3+0x204>
    cf88:	000107b7          	lui	a5,0x10
    cf8c:	2ef67463          	bgeu	a2,a5,d274 <__umoddi3+0x438>
    cf90:	10063713          	sltiu	a4,a2,256
    cf94:	00173713          	seqz	a4,a4
    cf98:	00371713          	slli	a4,a4,0x3
    cf9c:	00e656b3          	srl	a3,a2,a4
    cfa0:	00001797          	auipc	a5,0x1
    cfa4:	4ec78793          	addi	a5,a5,1260 # e48c <__clz_tab>
    cfa8:	00d787b3          	add	a5,a5,a3
    cfac:	0007c783          	lbu	a5,0(a5)
    cfb0:	02000313          	li	t1,32
    cfb4:	00e787b3          	add	a5,a5,a4
    cfb8:	40f306b3          	sub	a3,t1,a5
    cfbc:	0af31663          	bne	t1,a5,d068 <__umoddi3+0x22c>
    cfc0:	40c58733          	sub	a4,a1,a2
    cfc4:	01065313          	srli	t1,a2,0x10
    cfc8:	01061613          	slli	a2,a2,0x10
    cfcc:	01065613          	srli	a2,a2,0x10
    cfd0:	026755b3          	divu	a1,a4,t1
    cfd4:	0108d793          	srli	a5,a7,0x10
    cfd8:	02677733          	remu	a4,a4,t1
    cfdc:	02c585b3          	mul	a1,a1,a2
    cfe0:	01071713          	slli	a4,a4,0x10
    cfe4:	00e7e7b3          	or	a5,a5,a4
    cfe8:	00b7fa63          	bgeu	a5,a1,cffc <__umoddi3+0x1c0>
    cfec:	00f807b3          	add	a5,a6,a5
    cff0:	0107e663          	bltu	a5,a6,cffc <__umoddi3+0x1c0>
    cff4:	00b7f463          	bgeu	a5,a1,cffc <__umoddi3+0x1c0>
    cff8:	010787b3          	add	a5,a5,a6
    cffc:	40b787b3          	sub	a5,a5,a1
    d000:	0267d733          	divu	a4,a5,t1
    d004:	01089893          	slli	a7,a7,0x10
    d008:	0108d893          	srli	a7,a7,0x10
    d00c:	0267f7b3          	remu	a5,a5,t1
    d010:	02c70733          	mul	a4,a4,a2
    d014:	01079513          	slli	a0,a5,0x10
    d018:	00a8e533          	or	a0,a7,a0
    d01c:	eee560e3          	bltu	a0,a4,cefc <__umoddi3+0xc0>
    d020:	40e50533          	sub	a0,a0,a4
    d024:	00d55533          	srl	a0,a0,a3
    d028:	00000593          	li	a1,0
    d02c:	00008067          	ret
    d030:	10063693          	sltiu	a3,a2,256
    d034:	0016b693          	seqz	a3,a3
    d038:	00369693          	slli	a3,a3,0x3
    d03c:	e31ff06f          	j	ce6c <__umoddi3+0x30>
    d040:	00000693          	li	a3,0
    d044:	00001797          	auipc	a5,0x1
    d048:	44878793          	addi	a5,a5,1096 # e48c <__clz_tab>
    d04c:	00d787b3          	add	a5,a5,a3
    d050:	0007c783          	lbu	a5,0(a5)
    d054:	00000713          	li	a4,0
    d058:	02000313          	li	t1,32
    d05c:	00e787b3          	add	a5,a5,a4
    d060:	40f306b3          	sub	a3,t1,a5
    d064:	f4f30ee3          	beq	t1,a5,cfc0 <__umoddi3+0x184>
    d068:	00d61833          	sll	a6,a2,a3
    d06c:	00f5de33          	srl	t3,a1,a5
    d070:	01085313          	srli	t1,a6,0x10
    d074:	026e5eb3          	divu	t4,t3,t1
    d078:	01081613          	slli	a2,a6,0x10
    d07c:	00d595b3          	sll	a1,a1,a3
    d080:	00f55733          	srl	a4,a0,a5
    d084:	01065613          	srli	a2,a2,0x10
    d088:	00b76733          	or	a4,a4,a1
    d08c:	01075793          	srli	a5,a4,0x10
    d090:	00d518b3          	sll	a7,a0,a3
    d094:	026e7e33          	remu	t3,t3,t1
    d098:	02ce85b3          	mul	a1,t4,a2
    d09c:	010e1e13          	slli	t3,t3,0x10
    d0a0:	01c7e7b3          	or	a5,a5,t3
    d0a4:	00b7fa63          	bgeu	a5,a1,d0b8 <__umoddi3+0x27c>
    d0a8:	00f807b3          	add	a5,a6,a5
    d0ac:	0107e663          	bltu	a5,a6,d0b8 <__umoddi3+0x27c>
    d0b0:	00b7f463          	bgeu	a5,a1,d0b8 <__umoddi3+0x27c>
    d0b4:	010787b3          	add	a5,a5,a6
    d0b8:	40b787b3          	sub	a5,a5,a1
    d0bc:	0267d5b3          	divu	a1,a5,t1
    d0c0:	01071713          	slli	a4,a4,0x10
    d0c4:	01075713          	srli	a4,a4,0x10
    d0c8:	0267f7b3          	remu	a5,a5,t1
    d0cc:	02c585b3          	mul	a1,a1,a2
    d0d0:	01079793          	slli	a5,a5,0x10
    d0d4:	00f76733          	or	a4,a4,a5
    d0d8:	00b77a63          	bgeu	a4,a1,d0ec <__umoddi3+0x2b0>
    d0dc:	00e80733          	add	a4,a6,a4
    d0e0:	01076663          	bltu	a4,a6,d0ec <__umoddi3+0x2b0>
    d0e4:	00b77463          	bgeu	a4,a1,d0ec <__umoddi3+0x2b0>
    d0e8:	01070733          	add	a4,a4,a6
    d0ec:	40b70733          	sub	a4,a4,a1
    d0f0:	ee1ff06f          	j	cfd0 <__umoddi3+0x194>
    d0f4:	1006b813          	sltiu	a6,a3,256
    d0f8:	00183813          	seqz	a6,a6
    d0fc:	00381813          	slli	a6,a6,0x3
    d100:	0106d333          	srl	t1,a3,a6
    d104:	00001717          	auipc	a4,0x1
    d108:	38870713          	addi	a4,a4,904 # e48c <__clz_tab>
    d10c:	00670733          	add	a4,a4,t1
    d110:	00074703          	lbu	a4,0(a4)
    d114:	02000313          	li	t1,32
    d118:	01070733          	add	a4,a4,a6
    d11c:	40e30833          	sub	a6,t1,a4
    d120:	e4e300e3          	beq	t1,a4,cf60 <__umoddi3+0x124>
    d124:	010696b3          	sll	a3,a3,a6
    d128:	00e658b3          	srl	a7,a2,a4
    d12c:	00d8e8b3          	or	a7,a7,a3
    d130:	00e5de33          	srl	t3,a1,a4
    d134:	0108df13          	srli	t5,a7,0x10
    d138:	03ee57b3          	divu	a5,t3,t5
    d13c:	01089e93          	slli	t4,a7,0x10
    d140:	010ede93          	srli	t4,t4,0x10
    d144:	00e556b3          	srl	a3,a0,a4
    d148:	01051333          	sll	t1,a0,a6
    d14c:	010595b3          	sll	a1,a1,a6
    d150:	00b6e5b3          	or	a1,a3,a1
    d154:	0105d693          	srli	a3,a1,0x10
    d158:	01061633          	sll	a2,a2,a6
    d15c:	03ee7e33          	remu	t3,t3,t5
    d160:	02fe8533          	mul	a0,t4,a5
    d164:	010e1e13          	slli	t3,t3,0x10
    d168:	01c6e6b3          	or	a3,a3,t3
    d16c:	00a6fe63          	bgeu	a3,a0,d188 <__umoddi3+0x34c>
    d170:	00d886b3          	add	a3,a7,a3
    d174:	fff78e13          	addi	t3,a5,-1
    d178:	1116ec63          	bltu	a3,a7,d290 <__umoddi3+0x454>
    d17c:	10a6fa63          	bgeu	a3,a0,d290 <__umoddi3+0x454>
    d180:	ffe78793          	addi	a5,a5,-2
    d184:	011686b3          	add	a3,a3,a7
    d188:	40a686b3          	sub	a3,a3,a0
    d18c:	03e6d533          	divu	a0,a3,t5
    d190:	01059593          	slli	a1,a1,0x10
    d194:	0105d593          	srli	a1,a1,0x10
    d198:	03e6f6b3          	remu	a3,a3,t5
    d19c:	02ae8eb3          	mul	t4,t4,a0
    d1a0:	01069693          	slli	a3,a3,0x10
    d1a4:	00d5e5b3          	or	a1,a1,a3
    d1a8:	01d5fe63          	bgeu	a1,t4,d1c4 <__umoddi3+0x388>
    d1ac:	00b885b3          	add	a1,a7,a1
    d1b0:	fff50693          	addi	a3,a0,-1
    d1b4:	0d15ea63          	bltu	a1,a7,d288 <__umoddi3+0x44c>
    d1b8:	0dd5f863          	bgeu	a1,t4,d288 <__umoddi3+0x44c>
    d1bc:	ffe50513          	addi	a0,a0,-2
    d1c0:	011585b3          	add	a1,a1,a7
    d1c4:	01079693          	slli	a3,a5,0x10
    d1c8:	000102b7          	lui	t0,0x10
    d1cc:	00a6e6b3          	or	a3,a3,a0
    d1d0:	fff28513          	addi	a0,t0,-1 # ffff <__global_pointer$+0x127f>
    d1d4:	00a6fe33          	and	t3,a3,a0
    d1d8:	01065f93          	srli	t6,a2,0x10
    d1dc:	0106d693          	srli	a3,a3,0x10
    d1e0:	00a67533          	and	a0,a2,a0
    d1e4:	02ae0f33          	mul	t5,t3,a0
    d1e8:	41d585b3          	sub	a1,a1,t4
    d1ec:	02a68533          	mul	a0,a3,a0
    d1f0:	010f5793          	srli	a5,t5,0x10
    d1f4:	03fe0e33          	mul	t3,t3,t6
    d1f8:	00ae0e33          	add	t3,t3,a0
    d1fc:	01c787b3          	add	a5,a5,t3
    d200:	03f686b3          	mul	a3,a3,t6
    d204:	00a7f463          	bgeu	a5,a0,d20c <__umoddi3+0x3d0>
    d208:	005686b3          	add	a3,a3,t0
    d20c:	00010eb7          	lui	t4,0x10
    d210:	fffe8e93          	addi	t4,t4,-1 # ffff <__global_pointer$+0x127f>
    d214:	01d7f533          	and	a0,a5,t4
    d218:	0107de13          	srli	t3,a5,0x10
    d21c:	01051513          	slli	a0,a0,0x10
    d220:	01df7f33          	and	t5,t5,t4
    d224:	00de07b3          	add	a5,t3,a3
    d228:	01e50533          	add	a0,a0,t5
    d22c:	02f5e863          	bltu	a1,a5,d25c <__umoddi3+0x420>
    d230:	02f58463          	beq	a1,a5,d258 <__umoddi3+0x41c>
    d234:	40a30533          	sub	a0,t1,a0
    d238:	00a33333          	sltu	t1,t1,a0
    d23c:	40f585b3          	sub	a1,a1,a5
    d240:	406585b3          	sub	a1,a1,t1
    d244:	00e59733          	sll	a4,a1,a4
    d248:	01055533          	srl	a0,a0,a6
    d24c:	00a76533          	or	a0,a4,a0
    d250:	0105d5b3          	srl	a1,a1,a6
    d254:	00008067          	ret
    d258:	fca37ee3          	bgeu	t1,a0,d234 <__umoddi3+0x3f8>
    d25c:	40c50633          	sub	a2,a0,a2
    d260:	00c53533          	sltu	a0,a0,a2
    d264:	011508b3          	add	a7,a0,a7
    d268:	411787b3          	sub	a5,a5,a7
    d26c:	00060513          	mv	a0,a2
    d270:	fc5ff06f          	j	d234 <__umoddi3+0x3f8>
    d274:	010007b7          	lui	a5,0x1000
    d278:	02f67463          	bgeu	a2,a5,d2a0 <__umoddi3+0x464>
    d27c:	01065693          	srli	a3,a2,0x10
    d280:	01000713          	li	a4,16
    d284:	d1dff06f          	j	cfa0 <__umoddi3+0x164>
    d288:	00068513          	mv	a0,a3
    d28c:	f39ff06f          	j	d1c4 <__umoddi3+0x388>
    d290:	000e0793          	mv	a5,t3
    d294:	ef5ff06f          	j	d188 <__umoddi3+0x34c>
    d298:	010787b3          	add	a5,a5,a6
    d29c:	c3dff06f          	j	ced8 <__umoddi3+0x9c>
    d2a0:	01865693          	srli	a3,a2,0x18
    d2a4:	01800713          	li	a4,24
    d2a8:	cf9ff06f          	j	cfa0 <__umoddi3+0x164>
