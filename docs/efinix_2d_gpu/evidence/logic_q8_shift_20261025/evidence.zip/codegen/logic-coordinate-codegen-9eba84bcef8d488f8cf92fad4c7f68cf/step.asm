
D:\ZYNQ\smallproject\.worktrees\pango-riscv-cpu\generated\verification\v3\logic-coordinate-codegen-9eba84bcef8d488f8cf92fad4c7f68cf/bullet.o:     file format elf32-littleriscv


Disassembly of section .text.append:

Disassembly of section .text.pixel_coordinate:

Disassembly of section .text.bullet_campaign_valid:

Disassembly of section .text.bullet_enemy_position:

Disassembly of section .text.spawn:

Disassembly of section .text.bullet_reset:

Disassembly of section .text.bullet_reset_player:

Disassembly of section .text.step:

00000000 <step>:
   0:	f9010113          	addi	sp,sp,-112
   4:	07212023          	sw	s2,96(sp)
   8:	06112623          	sw	ra,108(sp)
   c:	06812423          	sw	s0,104(sp)
  10:	06912223          	sw	s1,100(sp)
  14:	05312e23          	sw	s3,92(sp)
  18:	05412c23          	sw	s4,88(sp)
  1c:	05512a23          	sw	s5,84(sp)
  20:	05612823          	sw	s6,80(sp)
  24:	05712623          	sw	s7,76(sp)
  28:	05812423          	sw	s8,72(sp)
  2c:	05912223          	sw	s9,68(sp)
  30:	05a12023          	sw	s10,64(sp)
  34:	03b12e23          	sw	s11,60(sp)
  38:	00e12423          	sw	a4,8(sp)
  3c:	00058913          	mv	s2,a1
  40:	78050463          	beqz	a0,7c8 <.L163>
			40: R_RISCV_BRANCH	.L163
  44:	00005a37          	lui	s4,0x5
  48:	01450a33          	add	s4,a0,s4
  4c:	008a2983          	lw	s3,8(s4) # 5008 <.L163+0x4840>
  50:	00068493          	mv	s1,a3
  54:	3ff00713          	li	a4,1023
  58:	fff98693          	addi	a3,s3,-1
  5c:	00050c93          	mv	s9,a0
  60:	ff800793          	li	a5,-8
  64:	1ad76463          	bltu	a4,a3,20c <.L101>
			64: R_RISCV_BRANCH	.L101
  68:	024a4a83          	lbu	s5,36(s4)
  6c:	00300713          	li	a4,3
  70:	19576e63          	bltu	a4,s5,20c <.L101>
			70: R_RISCV_BRANCH	.L101
  74:	00060413          	mv	s0,a2
  78:	00000097          	auipc	ra,0x0
			78: R_RISCV_CALL_PLT	bullet_campaign_valid
			78: R_RISCV_RELAX	*ABS*
  7c:	000080e7          	jalr	ra # 78 <step+0x78>
  80:	ff800793          	li	a5,-8
  84:	18050463          	beqz	a0,20c <.L101>
			84: R_RISCV_BRANCH	.L101
  88:	020a5683          	lhu	a3,32(s4)
  8c:	03c00713          	li	a4,60
  90:	16d76e63          	bltu	a4,a3,20c <.L101>
			90: R_RISCV_BRANCH	.L101
  94:	00812583          	lw	a1,8(sp)
  98:	000a9e63          	bnez	s5,b4 <.L103>
			98: R_RISCV_BRANCH	.L103
  9c:	022a5703          	lhu	a4,34(s4)
  a0:	07700613          	li	a2,119
  a4:	fff70713          	addi	a4,a4,-1
  a8:	01071713          	slli	a4,a4,0x10
  ac:	01075713          	srli	a4,a4,0x10
  b0:	14e66e63          	bltu	a2,a4,20c <.L101>
			b0: R_RISCV_BRANCH	.L101

000000b4 <.L103>:
  b4:	02090063          	beqz	s2,d4 <.L104>
			b4: R_RISCV_BRANCH	.L104
  b8:	ff840713          	addi	a4,s0,-8
  bc:	3b000613          	li	a2,944
  c0:	ff800793          	li	a5,-8
  c4:	14e66463          	bltu	a2,a4,20c <.L101>
			c4: R_RISCV_BRANCH	.L101
  c8:	fb048713          	addi	a4,s1,-80
  cc:	1c400613          	li	a2,452
  d0:	12e66e63          	bltu	a2,a4,20c <.L101>
			d0: R_RISCV_BRANCH	.L101

000000d4 <.L104>:
  d4:	01400713          	li	a4,20
  d8:	02e98733          	mul	a4,s3,a4
  dc:	00005537          	lui	a0,0x5
  e0:	000c8d93          	mv	s11,s9
  e4:	000c8613          	mv	a2,s9
  e8:	00193e13          	seqz	t3,s2
  ec:	00500313          	li	t1,5
  f0:	00ac8533          	add	a0,s9,a0
  f4:	01970733          	add	a4,a4,s9

000000f8 <.L108>:
  f8:	00e64e83          	lbu	t4,14(a2)
  fc:	001e3893          	seqz	a7,t3
 100:	00288893          	addi	a7,a7,2
 104:	6dd8c263          	blt	a7,t4,7c8 <.L163>
			104: R_RISCV_BRANCH	.L163
 108:	00f64883          	lbu	a7,15(a2)
 10c:	6b136e63          	bltu	t1,a7,7c8 <.L163>
			10c: R_RISCV_BRANCH	.L163
 110:	02854883          	lbu	a7,40(a0) # 5028 <.L163+0x4860>
 114:	00088663          	beqz	a7,120 <.L107>
			114: R_RISCV_BRANCH	.L107
 118:	01164e83          	lbu	t4,17(a2)
 11c:	6bd36663          	bltu	t1,t4,7c8 <.L163>
			11c: R_RISCV_BRANCH	.L163

00000120 <.L107>:
 120:	01460613          	addi	a2,a2,20
 124:	fcc71ae3          	bne	a4,a2,f8 <.L108>
			124: R_RISCV_BRANCH	.L108
 128:	00005737          	lui	a4,0x5
 12c:	00ec8733          	add	a4,s9,a4
 130:	00472a03          	lw	s4,4(a4) # 5004 <.L163+0x483c>
 134:	001a0a13          	addi	s4,s4,1
 138:	01472223          	sw	s4,4(a4)
 13c:	00090663          	beqz	s2,148 <.L109>
			13c: R_RISCV_BRANCH	.L109
 140:	02974703          	lbu	a4,41(a4)
 144:	0a071063          	bnez	a4,1e4 <.L110>
			144: R_RISCV_BRANCH	.L110

00000148 <.L109>:
 148:	100a9c63          	bnez	s5,260 <.L111>
			148: R_RISCV_BRANCH	.L111
 14c:	000057b7          	lui	a5,0x5
 150:	00fc8733          	add	a4,s9,a5
 154:	02275683          	lhu	a3,34(a4)
 158:	fff68693          	addi	a3,a3,-1
 15c:	01069693          	slli	a3,a3,0x10
 160:	0106d693          	srli	a3,a3,0x10
 164:	02d71123          	sh	a3,34(a4)
 168:	06069e63          	bnez	a3,1e4 <.L110>
			168: R_RISCV_BRANCH	.L110
 16c:	00072603          	lw	a2,0(a4)
 170:	0c090e63          	beqz	s2,24c <.L113>
			170: R_RISCV_BRANCH	.L113
 174:	0c088c63          	beqz	a7,24c <.L113>
			174: R_RISCV_BRANCH	.L113
 178:	06058a63          	beqz	a1,1ec <.L114>
			178: R_RISCV_BRANCH	.L114
 17c:	06bc8863          	beq	s9,a1,1ec <.L114>
			17c: R_RISCV_BRANCH	.L114
 180:	00f587b3          	add	a5,a1,a5
 184:	0287c703          	lbu	a4,40(a5) # 5028 <.L163+0x4860>
 188:	06070263          	beqz	a4,1ec <.L114>
			188: R_RISCV_BRANCH	.L114
 18c:	0087a703          	lw	a4,8(a5)
 190:	04e99e63          	bne	s3,a4,1ec <.L114>
			190: R_RISCV_BRANCH	.L114
 194:	0007a703          	lw	a4,0(a5)
 198:	04c71a63          	bne	a4,a2,1ec <.L114>
			198: R_RISCV_BRANCH	.L114
 19c:	0047a783          	lw	a5,4(a5)
 1a0:	04079663          	bnez	a5,1ec <.L114>
			1a0: R_RISCV_BRANCH	.L114
 1a4:	00005437          	lui	s0,0x5
 1a8:	008587b3          	add	a5,a1,s0
 1ac:	0147a703          	lw	a4,20(a5)
 1b0:	02071e63          	bnez	a4,1ec <.L114>
			1b0: R_RISCV_BRANCH	.L114
 1b4:	0247c683          	lbu	a3,36(a5)
 1b8:	00300713          	li	a4,3
 1bc:	02e69863          	bne	a3,a4,1ec <.L114>
			1bc: R_RISCV_BRANCH	.L114
 1c0:	0297c783          	lbu	a5,41(a5)
 1c4:	02079463          	bnez	a5,1ec <.L114>
			1c4: R_RISCV_BRANCH	.L114
 1c8:	00005637          	lui	a2,0x5
 1cc:	02c60613          	addi	a2,a2,44 # 502c <.L163+0x4864>
 1d0:	000c8513          	mv	a0,s9
 1d4:	008c8433          	add	s0,s9,s0
 1d8:	00000097          	auipc	ra,0x0
			1d8: R_RISCV_CALL_PLT	memcpy
			1d8: R_RISCV_RELAX	*ABS*
 1dc:	000080e7          	jalr	ra # 1d8 <.L109+0x90>
 1e0:	01442223          	sw	s4,4(s0) # 5004 <.L163+0x483c>

000001e4 <.L110>:
 1e4:	00000793          	li	a5,0
 1e8:	0240006f          	j	20c <.L101>
			1e8: R_RISCV_JAL	.L101

000001ec <.L114>:
 1ec:	00098593          	mv	a1,s3
 1f0:	000c8513          	mv	a0,s9
 1f4:	00000097          	auipc	ra,0x0
			1f4: R_RISCV_CALL_PLT	bullet_reset_player
			1f4: R_RISCV_RELAX	*ABS*
 1f8:	000080e7          	jalr	ra # 1f4 <.L114+0x8>

000001fc <.L217>:
 1fc:	00005737          	lui	a4,0x5
 200:	00ec8733          	add	a4,s9,a4
 204:	00050793          	mv	a5,a0
 208:	01472223          	sw	s4,4(a4) # 5004 <.L163+0x483c>

0000020c <.L101>:
 20c:	06c12083          	lw	ra,108(sp)
 210:	06812403          	lw	s0,104(sp)
 214:	06412483          	lw	s1,100(sp)
 218:	06012903          	lw	s2,96(sp)
 21c:	05c12983          	lw	s3,92(sp)
 220:	05812a03          	lw	s4,88(sp)
 224:	05412a83          	lw	s5,84(sp)
 228:	05012b03          	lw	s6,80(sp)
 22c:	04c12b83          	lw	s7,76(sp)
 230:	04812c03          	lw	s8,72(sp)
 234:	04412c83          	lw	s9,68(sp)
 238:	04012d03          	lw	s10,64(sp)
 23c:	03c12d83          	lw	s11,60(sp)
 240:	00078513          	mv	a0,a5
 244:	07010113          	addi	sp,sp,112
 248:	00008067          	ret

0000024c <.L113>:
 24c:	00098593          	mv	a1,s3
 250:	000c8513          	mv	a0,s9
 254:	00000097          	auipc	ra,0x0
			254: R_RISCV_CALL_PLT	bullet_reset
			254: R_RISCV_RELAX	*ABS*
 258:	000080e7          	jalr	ra # 254 <.L113+0x8>
 25c:	fa1ff06f          	j	1fc <.L217>
			25c: R_RISCV_JAL	.L217

00000260 <.L111>:
 260:	00005637          	lui	a2,0x5
 264:	00cc8633          	add	a2,s9,a2
 268:	01462703          	lw	a4,20(a2) # 5014 <.L163+0x484c>
 26c:	00170713          	addi	a4,a4,1
 270:	00e62a23          	sw	a4,20(a2)
 274:	02091863          	bnez	s2,2a4 <.L116>
			274: R_RISCV_BRANCH	.L116
 278:	0f000413          	li	s0,240
 27c:	02877433          	remu	s0,a4,s0
 280:	03b00613          	li	a2,59
 284:	14867e63          	bgeu	a2,s0,3e0 <.L117>
			284: R_RISCV_BRANCH	.L117
 288:	0b300613          	li	a2,179
 28c:	14866263          	bltu	a2,s0,3d0 <.L118>
			28c: R_RISCV_BRANCH	.L118
 290:	07800613          	li	a2,120
 294:	40860633          	sub	a2,a2,s0
 298:	00300593          	li	a1,3
 29c:	02b60633          	mul	a2,a2,a1
 2a0:	1e060413          	addi	s0,a2,480

000002a4 <.L116>:
 2a4:	00005637          	lui	a2,0x5
 2a8:	00cc8633          	add	a2,s9,a2
 2ac:	00862623          	sw	s0,12(a2) # 500c <.L163+0x4844>
 2b0:	00091463          	bnez	s2,2b8 <.L119>
			2b0: R_RISCV_BRANCH	.L119
 2b4:	1e000493          	li	s1,480

000002b8 <.L119>:
 2b8:	00005637          	lui	a2,0x5
 2bc:	00cc8633          	add	a2,s9,a2
 2c0:	00d037b3          	snez	a5,a3
 2c4:	00962823          	sw	s1,16(a2) # 5010 <.L163+0x4848>
 2c8:	00f12423          	sw	a5,8(sp)
 2cc:	00068663          	beqz	a3,2d8 <.L120>
			2cc: R_RISCV_BRANCH	.L120
 2d0:	fff68693          	addi	a3,a3,-1
 2d4:	02d61023          	sh	a3,32(a2)

000002d8 <.L120>:
 2d8:	01e00693          	li	a3,30
 2dc:	02d77733          	remu	a4,a4,a3
 2e0:	02071463          	bnez	a4,308 <.L121>
			2e0: R_RISCV_BRANCH	.L121
 2e4:	00005737          	lui	a4,0x5
 2e8:	00ec8733          	add	a4,s9,a4
 2ec:	01872703          	lw	a4,24(a4) # 5018 <.L163+0x4850>
 2f0:	fff00693          	li	a3,-1
 2f4:	00d70463          	beq	a4,a3,2fc <.L122>
			2f4: R_RISCV_BRANCH	.L122
 2f8:	00170713          	addi	a4,a4,1

000002fc <.L122>:
 2fc:	000056b7          	lui	a3,0x5
 300:	00dc86b3          	add	a3,s9,a3
 304:	00e6ac23          	sw	a4,24(a3) # 5018 <.L163+0x4850>

00000308 <.L121>:
 308:	00005ab7          	lui	s5,0x5
 30c:	015c87b3          	add	a5,s9,s5
 310:	00f12623          	sw	a5,12(sp)
 314:	fed40793          	addi	a5,s0,-19
 318:	0003cab7          	lui	s5,0x3c
 31c:	0001ed37          	lui	s10,0x1e
 320:	00f12823          	sw	a5,16(sp)
 324:	00010b37          	lui	s6,0x10
 328:	00c40793          	addi	a5,s0,12
 32c:	0f000a13          	li	s4,240
 330:	00000913          	li	s2,0
 334:	7fea8a93          	addi	s5,s5,2046 # 3c7fe <.L163+0x3c036>
 338:	bffd0d13          	addi	s10,s10,-1025 # 1dbff <.L163+0x1d437>
 33c:	00f12a23          	sw	a5,20(sp)
 340:	fffb0b13          	addi	s6,s6,-1 # ffff <.L163+0xf837>

00000344 <.L152>:
 344:	00edc683          	lbu	a3,14(s11)
 348:	00300713          	li	a4,3
 34c:	1ee69063          	bne	a3,a4,52c <.L123>
			34c: R_RISCV_BRANCH	.L123
 350:	00cddc03          	lhu	s8,12(s11)
 354:	076c0063          	beq	s8,s6,3b4 <.L127>
			354: R_RISCV_BRANCH	.L127
 358:	000da703          	lw	a4,0(s11)
 35c:	008d9503          	lh	a0,8(s11)
 360:	004da683          	lw	a3,4(s11)
 364:	00e50533          	add	a0,a0,a4
 368:	00ad9703          	lh	a4,10(s11)
 36c:	00ada023          	sw	a0,0(s11)
 370:	00d70733          	add	a4,a4,a3
 374:	00eda223          	sw	a4,4(s11)
 378:	00e12c23          	sw	a4,24(sp)
 37c:	00000097          	auipc	ra,0x0
			37c: R_RISCV_CALL_PLT	pixel_coordinate
			37c: R_RISCV_RELAX	*ABS*
 380:	000080e7          	jalr	ra # 37c <.L152+0x38>
 384:	00450b93          	addi	s7,a0,4
 388:	3bf00693          	li	a3,959
 38c:	0376e063          	bltu	a3,s7,3ac <.L125>
			38c: R_RISCV_BRANCH	.L125
 390:	01812703          	lw	a4,24(sp)
 394:	00070513          	mv	a0,a4
 398:	00000097          	auipc	ra,0x0
			398: R_RISCV_CALL_PLT	pixel_coordinate
			398: R_RISCV_RELAX	*ABS*
 39c:	000080e7          	jalr	ra # 398 <.L152+0x54>
 3a0:	fbc50693          	addi	a3,a0,-68
 3a4:	1d300713          	li	a4,467
 3a8:	04d77463          	bgeu	a4,a3,3f0 <.L126>
			3a8: R_RISCV_BRANCH	.L126

000003ac <.L125>:
 3ac:	fff00713          	li	a4,-1
 3b0:	00ed9623          	sh	a4,12(s11)

000003b4 <.L127>:
 3b4:	16700713          	li	a4,359
 3b8:	00190913          	addi	s2,s2,1
 3bc:	40ea0263          	beq	s4,a4,7c0 <.L166>
			3bc: R_RISCV_BRANCH	.L166
 3c0:	001a0a13          	addi	s4,s4,1

000003c4 <.L151>:
 3c4:	014d8d93          	addi	s11,s11,20
 3c8:	f7299ee3          	bne	s3,s2,344 <.L152>
			3c8: R_RISCV_BRANCH	.L152
 3cc:	e19ff06f          	j	1e4 <.L110>
			3cc: R_RISCV_JAL	.L110

000003d0 <.L118>:
 3d0:	00300613          	li	a2,3
 3d4:	02c40433          	mul	s0,s0,a2
 3d8:	f1040413          	addi	s0,s0,-240
 3dc:	ec9ff06f          	j	2a4 <.L116>
			3dc: R_RISCV_JAL	.L116

000003e0 <.L117>:
 3e0:	00300613          	li	a2,3
 3e4:	02c40433          	mul	s0,s0,a2
 3e8:	1e040413          	addi	s0,s0,480
 3ec:	eb9ff06f          	j	2a4 <.L116>
			3ec: R_RISCV_JAL	.L116

000003f0 <.L126>:
 3f0:	001c0c13          	addi	s8,s8,1
 3f4:	018d9623          	sh	s8,12(s11)
 3f8:	00450893          	addi	a7,a0,4
 3fc:	00000c13          	li	s8,0
 400:	00300e13          	li	t3,3

00000404 <.L129>:
 404:	00c12783          	lw	a5,12(sp)
 408:	0287c303          	lbu	t1,40(a5)
 40c:	02030c63          	beqz	t1,444 <.L128>
			40c: R_RISCV_BRANCH	.L128
 410:	00005737          	lui	a4,0x5
 414:	02570713          	addi	a4,a4,37 # 5025 <.L163+0x485d>
 418:	00ec0733          	add	a4,s8,a4
 41c:	00ec8733          	add	a4,s9,a4
 420:	00074703          	lbu	a4,0(a4)
 424:	02071063          	bnez	a4,444 <.L128>
			424: R_RISCV_BRANCH	.L128

00000428 <.L131>:
 428:	001c0c13          	addi	s8,s8,1
 42c:	fdcc1ce3          	bne	s8,t3,404 <.L129>
			42c: R_RISCV_BRANCH	.L129

00000430 <.L130>:
 430:	00005737          	lui	a4,0x5
 434:	00ec8733          	add	a4,s9,a4
 438:	02974703          	lbu	a4,41(a4) # 5029 <.L163+0x4861>
 43c:	da0714e3          	bnez	a4,1e4 <.L110>
			43c: R_RISCV_BRANCH	.L110
 440:	f75ff06f          	j	3b4 <.L127>
			440: R_RISCV_JAL	.L127

00000444 <.L128>:
 444:	02c10693          	addi	a3,sp,44
 448:	02810613          	addi	a2,sp,40
 44c:	000c0593          	mv	a1,s8
 450:	000c8513          	mv	a0,s9
 454:	01112e23          	sw	a7,28(sp)
 458:	00612c23          	sw	t1,24(sp)
 45c:	00000097          	auipc	ra,0x0
			45c: R_RISCV_CALL_PLT	bullet_enemy_position
			45c: R_RISCV_RELAX	*ABS*
 460:	000080e7          	jalr	ra # 45c <.L128+0x18>
 464:	02812683          	lw	a3,40(sp)
 468:	01400613          	li	a2,20
 46c:	02c12703          	lw	a4,44(sp)
 470:	40db86b3          	sub	a3,s7,a3
 474:	00a68693          	addi	a3,a3,10
 478:	01c12883          	lw	a7,28(sp)
 47c:	00300e13          	li	t3,3
 480:	fad664e3          	bltu	a2,a3,428 <.L131>
			480: R_RISCV_BRANCH	.L131
 484:	40e88733          	sub	a4,a7,a4
 488:	00a70713          	addi	a4,a4,10
 48c:	f8e66ee3          	bltu	a2,a4,428 <.L131>
			48c: R_RISCV_BRANCH	.L131
 490:	fff00713          	li	a4,-1
 494:	00ed9623          	sh	a4,12(s11)
 498:	00005737          	lui	a4,0x5
 49c:	00ec8733          	add	a4,s9,a4
 4a0:	01872703          	lw	a4,24(a4) # 5018 <.L163+0x4850>
 4a4:	fe600693          	li	a3,-26
 4a8:	01812303          	lw	t1,24(sp)
 4ac:	00e6f463          	bgeu	a3,a4,4b4 <.L132>
			4ac: R_RISCV_BRANCH	.L132
 4b0:	fe600713          	li	a4,-26

000004b4 <.L132>:
 4b4:	000056b7          	lui	a3,0x5
 4b8:	01970713          	addi	a4,a4,25
 4bc:	00dc85b3          	add	a1,s9,a3
 4c0:	00e5ac23          	sw	a4,24(a1)
 4c4:	f60306e3          	beqz	t1,430 <.L130>
			4c4: R_RISCV_BRANCH	.L130
 4c8:	018c8c33          	add	s8,s9,s8
 4cc:	01868633          	add	a2,a3,s8
 4d0:	02564683          	lbu	a3,37(a2)
 4d4:	fff68693          	addi	a3,a3,-1 # 4fff <.L163+0x4837>
 4d8:	0ff6f693          	zext.b	a3,a3
 4dc:	02d602a3          	sb	a3,37(a2)
 4e0:	f40698e3          	bnez	a3,430 <.L130>
			4e0: R_RISCV_BRANCH	.L130
 4e4:	f3700693          	li	a3,-201
 4e8:	00e6f463          	bgeu	a3,a4,4f0 <.L134>
			4e8: R_RISCV_BRANCH	.L134
 4ec:	f3700713          	li	a4,-201

000004f0 <.L134>:
 4f0:	0c870713          	addi	a4,a4,200
 4f4:	000056b7          	lui	a3,0x5
 4f8:	00e5ac23          	sw	a4,24(a1)
 4fc:	00dc86b3          	add	a3,s9,a3
 500:	0246a603          	lw	a2,36(a3) # 5024 <.L163+0x485c>
 504:	00000713          	li	a4,0
 508:	00861593          	slli	a1,a2,0x8
 50c:	0105d593          	srli	a1,a1,0x10
 510:	00059663          	bnez	a1,51c <.L135>
			510: R_RISCV_BRANCH	.L135
 514:	0276c703          	lbu	a4,39(a3)
 518:	00173713          	seqz	a4,a4

0000051c <.L135>:
 51c:	000056b7          	lui	a3,0x5
 520:	00dc86b3          	add	a3,s9,a3
 524:	02e684a3          	sb	a4,41(a3) # 5029 <.L163+0x4861>
 528:	f09ff06f          	j	430 <.L130>
			528: R_RISCV_JAL	.L130

0000052c <.L123>:
 52c:	00c12783          	lw	a5,12(sp)
 530:	0287c603          	lbu	a2,40(a5)
 534:	00060663          	beqz	a2,540 <.L137>
			534: R_RISCV_BRANCH	.L137
 538:	00cdd703          	lhu	a4,12(s11)
 53c:	e7670ce3          	beq	a4,s6,3b4 <.L127>
			53c: R_RISCV_BRANCH	.L127

00000540 <.L137>:
 540:	000da583          	lw	a1,0(s11)
 544:	7ff58713          	addi	a4,a1,2047
 548:	00eaee63          	bltu	s5,a4,564 <.L138>
			548: R_RISCV_BRANCH	.L138
 54c:	004da503          	lw	a0,4(s11)
 550:	ffffc737          	lui	a4,0xffffc
 554:	00e50733          	add	a4,a0,a4
 558:	00ed6663          	bltu	s10,a4,564 <.L138>
			558: R_RISCV_BRANCH	.L138
 55c:	00cdd683          	lhu	a3,12(s11)
 560:	0146ee63          	bltu	a3,s4,57c <.L139>
			560: R_RISCV_BRANCH	.L139

00000564 <.L138>:
 564:	00000613          	li	a2,0
 568:	00090593          	mv	a1,s2
 56c:	000c8513          	mv	a0,s9
 570:	00000097          	auipc	ra,0x0
			570: R_RISCV_CALL_PLT	spawn
			570: R_RISCV_RELAX	*ABS*
 574:	000080e7          	jalr	ra # 570 <.L138+0xc>
 578:	e3dff06f          	j	3b4 <.L127>
			578: R_RISCV_JAL	.L127

0000057c <.L139>:
 57c:	04060a63          	beqz	a2,5d0 <.L140>
			57c: R_RISCV_BRANCH	.L140
 580:	011dc703          	lbu	a4,17(s11)
 584:	00300893          	li	a7,3
 588:	13170263          	beq	a4,a7,6ac <.L141>
			588: R_RISCV_BRANCH	.L141
 58c:	00400893          	li	a7,4
 590:	15170e63          	beq	a4,a7,6ec <.L142>
			590: R_RISCV_BRANCH	.L142
 594:	00200893          	li	a7,2
 598:	03171c63          	bne	a4,a7,5d0 <.L140>
			598: R_RISCV_BRANCH	.L140
 59c:	000008b7          	lui	a7,0x0
			59c: R_RISCV_HI20	.LANCHOR0
			59c: R_RISCV_RELAX	*ABS*
 5a0:	03c6f313          	andi	t1,a3,60
 5a4:	00088893          	mv	a7,a7
			5a4: R_RISCV_LO12_I	.LANCHOR0
			5a4: R_RISCV_RELAX	*ABS*
 5a8:	006888b3          	add	a7,a7,t1
 5ac:	02489883          	lh	a7,36(a7) # 24 <step+0x24>
 5b0:	06000313          	li	t1,96
 5b4:	02e8c8b3          	div	a7,a7,a4
 5b8:	00500713          	li	a4,5
 5bc:	02e97733          	remu	a4,s2,a4
 5c0:	ffe70713          	addi	a4,a4,-2 # ffffbffe <.L163+0xffffb836>
 5c4:	02670733          	mul	a4,a4,t1
 5c8:	00e88733          	add	a4,a7,a4
 5cc:	00ed9423          	sh	a4,8(s11)

000005d0 <.L140>:
 5d0:	008d9703          	lh	a4,8(s11)
 5d4:	00ad9c03          	lh	s8,10(s11)
 5d8:	00168693          	addi	a3,a3,1
 5dc:	00b705b3          	add	a1,a4,a1
 5e0:	00ac0c33          	add	s8,s8,a0
 5e4:	00bda023          	sw	a1,0(s11)
 5e8:	018da223          	sw	s8,4(s11)
 5ec:	00dd9623          	sh	a3,12(s11)
 5f0:	02060063          	beqz	a2,610 <.L143>
			5f0: R_RISCV_BRANCH	.L143
 5f4:	011dc603          	lbu	a2,17(s11)
 5f8:	00500693          	li	a3,5
 5fc:	00d61a63          	bne	a2,a3,610 <.L143>
			5fc: R_RISCV_BRANCH	.L143
 600:	1005d463          	bgez	a1,708 <.L144>
			600: R_RISCV_BRANCH	.L144
 604:	000da023          	sw	zero,0(s11)

00000608 <.L219>:
 608:	40e00733          	neg	a4,a4
 60c:	00ed9423          	sh	a4,8(s11)

00000610 <.L143>:
 610:	000da503          	lw	a0,0(s11)
 614:	00000097          	auipc	ra,0x0
			614: R_RISCV_CALL_PLT	pixel_coordinate
			614: R_RISCV_RELAX	*ABS*
 618:	000080e7          	jalr	ra # 614 <.L143+0x4>
 61c:	01012783          	lw	a5,16(sp)
 620:	00050b93          	mv	s7,a0
 624:	d8f548e3          	blt	a0,a5,3b4 <.L127>
			624: R_RISCV_BRANCH	.L127
 628:	01412783          	lw	a5,20(sp)
 62c:	d8a7c4e3          	blt	a5,a0,3b4 <.L127>
			62c: R_RISCV_BRANCH	.L127
 630:	000c0513          	mv	a0,s8
 634:	00000097          	auipc	ra,0x0
			634: R_RISCV_CALL_PLT	pixel_coordinate
			634: R_RISCV_RELAX	*ABS*
 638:	000080e7          	jalr	ra # 634 <.L143+0x24>
 63c:	fed48713          	addi	a4,s1,-19
 640:	d6e54ae3          	blt	a0,a4,3b4 <.L127>
			640: R_RISCV_BRANCH	.L127
 644:	00c48713          	addi	a4,s1,12
 648:	d6a746e3          	blt	a4,a0,3b4 <.L127>
			648: R_RISCV_BRANCH	.L127
 64c:	00fdc703          	lbu	a4,15(s11)
 650:	40950533          	sub	a0,a0,s1
 654:	01350513          	addi	a0,a0,19
 658:	00671713          	slli	a4,a4,0x6
 65c:	00a70733          	add	a4,a4,a0
 660:	02070613          	addi	a2,a4,32
 664:	000006b7          	lui	a3,0x0
			664: R_RISCV_HI20	.LANCHOR0
			664: R_RISCV_RELAX	*ABS*
 668:	00068693          	mv	a3,a3
			668: R_RISCV_LO12_I	.LANCHOR0
			668: R_RISCV_RELAX	*ABS*
 66c:	00271713          	slli	a4,a4,0x2
 670:	00261613          	slli	a2,a2,0x2
 674:	00c68633          	add	a2,a3,a2
 678:	00e686b3          	add	a3,a3,a4
 67c:	0646a703          	lw	a4,100(a3) # 64 <step+0x64>
 680:	408b8bb3          	sub	s7,s7,s0
 684:	013b8b93          	addi	s7,s7,19
 688:	01775733          	srl	a4,a4,s7
 68c:	00177713          	andi	a4,a4,1
 690:	06462603          	lw	a2,100(a2)
 694:	0c070863          	beqz	a4,764 <.L145>
			694: R_RISCV_BRANCH	.L145
 698:	00812783          	lw	a5,8(sp)
 69c:	08078063          	beqz	a5,71c <.L146>
			69c: R_RISCV_BRANCH	.L146

000006a0 <.L148>:
 6a0:	00100793          	li	a5,1
 6a4:	00f12423          	sw	a5,8(sp)
 6a8:	d0dff06f          	j	3b4 <.L127>
			6a8: R_RISCV_JAL	.L127

000006ac <.L141>:
 6ac:	00c00893          	li	a7,12
 6b0:	0316d8b3          	divu	a7,a3,a7
 6b4:	02e95733          	divu	a4,s2,a4
 6b8:	01170733          	add	a4,a4,a7
 6bc:	00f77713          	andi	a4,a4,15
 6c0:	000008b7          	lui	a7,0x0
			6c0: R_RISCV_HI20	.LANCHOR0
			6c0: R_RISCV_RELAX	*ABS*
 6c4:	00088893          	mv	a7,a7
			6c4: R_RISCV_LO12_I	.LANCHOR0
			6c4: R_RISCV_RELAX	*ABS*
 6c8:	00271713          	slli	a4,a4,0x2
 6cc:	00e88733          	add	a4,a7,a4
 6d0:	02475883          	lhu	a7,36(a4)
 6d4:	02675703          	lhu	a4,38(a4)
 6d8:	00189893          	slli	a7,a7,0x1
 6dc:	011d9423          	sh	a7,8(s11)
 6e0:	00171713          	slli	a4,a4,0x1

000006e4 <.L218>:
 6e4:	00ed9523          	sh	a4,10(s11)
 6e8:	ee9ff06f          	j	5d0 <.L140>
			6e8: R_RISCV_JAL	.L140

000006ec <.L142>:
 6ec:	0076f713          	andi	a4,a3,7
 6f0:	ee0710e3          	bnez	a4,5d0 <.L140>
			6f0: R_RISCV_BRANCH	.L140
 6f4:	00ad9703          	lh	a4,10(s11)
 6f8:	37f00893          	li	a7,895
 6fc:	ece8cae3          	blt	a7,a4,5d0 <.L140>
			6fc: R_RISCV_BRANCH	.L140
 700:	02070713          	addi	a4,a4,32
 704:	fe1ff06f          	j	6e4 <.L218>
			704: R_RISCV_JAL	.L218

00000708 <.L144>:
 708:	0003c6b7          	lui	a3,0x3c
 70c:	80068693          	addi	a3,a3,-2048 # 3b800 <.L163+0x3b038>
 710:	f0b6d0e3          	bge	a3,a1,610 <.L143>
			710: R_RISCV_BRANCH	.L143
 714:	00dda023          	sw	a3,0(s11)
 718:	ef1ff06f          	j	608 <.L219>
			718: R_RISCV_JAL	.L219

0000071c <.L146>:
 71c:	00005bb7          	lui	s7,0x5
 720:	017c8bb3          	add	s7,s9,s7
 724:	024bcc03          	lbu	s8,36(s7) # 5024 <.L163+0x485c>
 728:	00000613          	li	a2,0
 72c:	00090593          	mv	a1,s2
 730:	fffc0c13          	addi	s8,s8,-1
 734:	0ffc7c13          	zext.b	s8,s8
 738:	038b8223          	sb	s8,36(s7)
 73c:	000c8513          	mv	a0,s9
 740:	00000097          	auipc	ra,0x0
			740: R_RISCV_CALL_PLT	spawn
			740: R_RISCV_RELAX	*ABS*
 744:	000080e7          	jalr	ra # 740 <.L146+0x24>
 748:	000c1863          	bnez	s8,758 <.L147>
			748: R_RISCV_BRANCH	.L147
 74c:	007807b7          	lui	a5,0x780
 750:	02fba023          	sw	a5,32(s7)
 754:	a91ff06f          	j	1e4 <.L110>
			754: R_RISCV_JAL	.L110

00000758 <.L147>:
 758:	03c00713          	li	a4,60
 75c:	02eb9023          	sh	a4,32(s7)
 760:	f41ff06f          	j	6a0 <.L148>
			760: R_RISCV_JAL	.L148

00000764 <.L145>:
 764:	01765733          	srl	a4,a2,s7
 768:	00177713          	andi	a4,a4,1
 76c:	c40704e3          	beqz	a4,3b4 <.L127>
			76c: R_RISCV_BRANCH	.L127
 770:	010dc703          	lbu	a4,16(s11)
 774:	c40710e3          	bnez	a4,3b4 <.L127>
			774: R_RISCV_BRANCH	.L127
 778:	00100713          	li	a4,1
 77c:	00ed8823          	sb	a4,16(s11)
 780:	00005737          	lui	a4,0x5
 784:	00ec8733          	add	a4,s9,a4
 788:	01c72683          	lw	a3,28(a4) # 501c <.L163+0x4854>
 78c:	fff00613          	li	a2,-1
 790:	00c68663          	beq	a3,a2,79c <.L149>
			790: R_RISCV_BRANCH	.L149
 794:	00168693          	addi	a3,a3,1
 798:	00d72e23          	sw	a3,28(a4)

0000079c <.L149>:
 79c:	000056b7          	lui	a3,0x5
 7a0:	00dc86b3          	add	a3,s9,a3
 7a4:	0186a703          	lw	a4,24(a3) # 5018 <.L163+0x4850>
 7a8:	ff500613          	li	a2,-11
 7ac:	00e67463          	bgeu	a2,a4,7b4 <.L150>
			7ac: R_RISCV_BRANCH	.L150
 7b0:	ff500713          	li	a4,-11

000007b4 <.L150>:
 7b4:	00a70713          	addi	a4,a4,10
 7b8:	00e6ac23          	sw	a4,24(a3)
 7bc:	bf9ff06f          	j	3b4 <.L127>
			7bc: R_RISCV_JAL	.L127

000007c0 <.L166>:
 7c0:	0f000a13          	li	s4,240
 7c4:	c01ff06f          	j	3c4 <.L151>
			7c4: R_RISCV_JAL	.L151

000007c8 <.L163>:
 7c8:	ff800793          	li	a5,-8
 7cc:	a41ff06f          	j	20c <.L101>
			7cc: R_RISCV_JAL	.L101

Disassembly of section .text.bullet_step:

Disassembly of section .text.bullet_step_player:

Disassembly of section .text.bullet_step_player_cached:

Disassembly of section .text.bullet_prepare_frame:

Disassembly of section .text.bullet_finish_window:

Disassembly of section .text.bullet_shape_opaque:

Disassembly of section .text.sprite:

Disassembly of section .text.build_frame:

Disassembly of section .text.bullet_build_frame:

Disassembly of section .text.bullet_build_frame_player:

Disassembly of section .text.bullet_clip_background_for_hud: