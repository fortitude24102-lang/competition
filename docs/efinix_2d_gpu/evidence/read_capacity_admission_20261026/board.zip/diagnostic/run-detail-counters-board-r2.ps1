$ErrorActionPreference='Stop'
Set-Location 'D:/ZYNQ/smallproject/.worktrees/pango-riscv-cpu'
$cpu='generated/verification/v3/cpu-builder-20261025'
$out="$cpu/detail-counters-board-r2"
$bit='D:/efinity_builds/alpha_early_candidate_20261025_r1/outflow/efinix_2d_gpu.bit'
$bin="$cpu/detail-counters900-r2/gpu_demo.bin"
$normal="$cpu/normal-logic-shift-r1/gpu_demo.bin"
if(Test-Path -LiteralPath $out){throw 'Diagnostic capture must be fresh'}
foreach($pair in @(@($bit,'ef240664097d115b1e2fbc60f336a9190d4e8a2941a760642627e3563fcebcb1'),@($bin,'d7c68cb32986bef851cf1bbd0a92d1a42e6c671f97282e763d4c0e0b5d1a3e71'),@($normal,'6000d1559cccaa91b340e2881db2afaed5c693cac2aa2e863f0340edb9c50b3c'))){if((Get-FileHash -LiteralPath $pair[0]).Hash.ToLowerInvariant() -ne $pair[1]){throw 'Diagnostic input identity changed'}}
$state=Invoke-RestMethod 'http://127.0.0.1:8765/api/status' -TimeoutSec 5
if($state.simulated -or $state.stale -or $state.owned -or !(1024 -band $state.telemetry.raw.status_flags)){throw 'Fresh real released normal MENU required'}
New-Item -ItemType Directory -Path $out | Out-Null
try {
 & D:/efinity/pgm/bin/ftdi_pgm.bat $bit -m jtag *> "$out/bit-load.log"
 if($LASTEXITCODE){throw 'Diagnostic BIT load failed'}
 Start-Sleep -Seconds 3
 & scripts/capture-game-probe.ps1 -Bin $bin -Log "$out/uart.log" -SerialPort COM9 -LogicCopy 1 -SealWords 256 -HudDirect 1 -Seconds 45 *> "$out/capture.log"
 $raw=Get-Content -LiteralPath "$out/uart.log" -Raw
 if($raw -notmatch '(?m)^V3_READY,[^\r\n]*network=1,[^\r\n]*mode=LIVE,[^\r\n]*count=1024' -or $raw -notmatch 'V3_SEAL_STATE,count=600,sealed=1,words=256,offset=9836,crc=a7bd652f'){throw 'Diagnostic workload identity changed'}
 & 'C:/Users/fortiutde/AppData/Local/Programs/Python/Python39/python.exe' tools/analyze_v3_detail_counters.py "$out/uart.log" > "$out/counters.json"
 if($LASTEXITCODE){throw 'Diagnostic counters rejected'}
 $counters=Get-Content -LiteralPath "$out/counters.json" -Raw|ConvertFrom-Json
 if($counters.scored_frames -ne 900 -or $counters.counter_frames_including_warmup -ne 930){throw 'Diagnostic window changed'}
 'PASS diagnostic930 counter frames; not a formal performance cohort'
} catch {
 $_|Out-String|Set-Content -LiteralPath "$out/failure.txt" -Encoding utf8
 throw
} finally {
 & scripts/test-game-menu-board.ps1 -Bin $normal -Bit $bit -LoadBit -SerialPort COM9 -OutDirectory "$out/final-menu" -ExpectedBuild 0x20261015 -LevelCount 6 -Python C:/Users/fortiutde/AppData/Local/Programs/Python/Python39/python.exe *> "$out/final-menu.log"
 $state=Invoke-RestMethod 'http://127.0.0.1:8765/api/status' -TimeoutSec 5
 if($state.simulated -or $state.stale -or $state.owned -or !(1024 -band $state.telemetry.raw.status_flags)){throw 'Diagnostic final MENU not fresh/released'}
 $state|ConvertTo-Json -Depth 8|Set-Content -LiteralPath "$out/final-state.json" -Encoding utf8
 'PASS diagnostic restored accepted normal MENU'
}

