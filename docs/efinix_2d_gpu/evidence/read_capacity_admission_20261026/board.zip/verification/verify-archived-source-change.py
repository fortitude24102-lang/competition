"""Bind the existing read-credit experiment to immutable sources, not later HEAD work."""
import hashlib
import json
from pathlib import Path
from zipfile import ZipFile

root = Path.cwd()
experiment = root / 'generated/verification/v3/read-credit-20261025'
archives = [
    ('alpha_early_prefetch_20261025', 'd701a96ef5aa9312bed6b22125f07cc0fa49def317fa891d7e8288a141247a7a'),
    ('read_capacity_admission_20261026', 'e14d63b7ddc278f2120178ca56d1bac8b2f445f71cb0de0e2a9c40c2249c5221'),
]
source_sets, manifests = [], []
for directory, expected in archives:
    path = root / 'docs/efinix_2d_gpu/evidence' / directory / 'evidence.zip'
    assert hashlib.sha256(path.read_bytes()).hexdigest() == expected
    with ZipFile(path) as archive:
        prefix = 'source/chisel/'
        sources = {name[len(prefix):]: archive.read(name) for name in archive.namelist()
                   if name.startswith(prefix + 'src/main/scala/gpu/') and name.endswith('.scala')}
        assert len(sources) == 38
        digest = hashlib.sha256()
        for name, data in sorted(sources.items()):
            digest.update(name.encode() + b'\0' + data)
        names = (['rtl-candidate-r1/gpu-build.json'] if directory == 'alpha_early_prefetch_20261025'
                 else [name for name in archive.namelist() if name.endswith('gpu-build.json')])
        matching = [json.loads(archive.read(name)) for name in names
                    if json.loads(archive.read(name))['sourceSha256'] == digest.hexdigest()]
        assert matching and all(manifest == matching[0] for manifest in matching)
        source_sets.append(sources)
        manifests.append(matching[0])
old, new = manifests
assert old['features'] == new['features'] and len(new['features']) == 18
assert source_sets[0].keys() == source_sets[1].keys()
assert [name for name in sorted(source_sets[0]) if source_sets[0][name] != source_sets[1][name]] == ['src/main/scala/gpu/DdrQosArbiter.scala']
assert old['rtlSha256'].keys() == new['rtlSha256'].keys()
assert [name for name in sorted(old['rtlSha256']) if old['rtlSha256'][name] != new['rtlSha256'][name]] == ['DdrQosArbiter.sv']
assert len(new['rtlSha256']) == 70
assert json.loads((experiment / 'rtl-candidate-r1/gpu-build.json').read_text()) == new
assert json.loads(Path('D:/efinity_builds/read_credit_candidate_20261026_r1/gpu-build.json').read_text()) == new
for name, expected in new['rtlSha256'].items():
    assert hashlib.sha256((experiment / 'rtl-candidate-r1' / name).read_bytes()).hexdigest() == expected
print('PASS immutable archives bind read-credit sources/18 features/70 RTL; later working-tree changes excluded')
