import json
from pathlib import Path
from statistics import mean

root = Path.cwd()
out = root / 'generated/verification/v3/read-credit-20261025'
folder = out / 'board-aba-r2'
runs = ('control-a1', 'candidate-b1', 'control-a2', 'candidate-b2')

def rows(path, prefix):
    result = []
    for line in path.read_text(encoding='utf-8-sig').splitlines():
        if line.startswith(prefix + ','):
            pairs = [field.split('=', 1) for field in line.split(',')[1:]]
            row = dict(pairs)
            assert len(row) == len(pairs)
            result.append(row)
    return result

def stop(path, prefix):
    records = rows(path, prefix)
    assert len(records) == 1 and int(records[0]['result']) == 0
    if prefix != 'V3_PROBE_STOP':
        assert int(records[0]['hardware']) == 0
    return records[0]

assert not (folder / 'experiment-failure.txt').exists()
groups, summaries = {}, []
for run in runs:
    path = folder / (run + '-probe-uart.log')
    stop(path, 'V3_PROBE_STOP')
    ready, probe, seal = (rows(path, p) for p in ('V3_READY', 'V3_PROBE', 'V3_SEAL_STATE'))
    assert len(ready) == len(probe) == len(seal) == 1
    assert all(ready[0][key] == value for key, value in dict(network='1', mode='LIVE', count='1024', build='20261015', epoch='00030002').items())
    assert seal[0] == dict(count='600', sealed='1', words='256', offset='9836', crc='a7bd652f')
    p = {key: int(value) for key, value in probe[0].items()}
    for key, expected in dict(target=1024, frames=3600, work_miss=0, late_present=0, under=0, errors=0, visible_min=1006, visible_max=1016, alpha_min=130, alpha_max=131).items():
        assert p[key] == expected
    assert p['work_max_us'] < 16666 and p['wall_max_us'] < 16666
    summaries.append(dict(name=run, **p))
    copy = folder / (run + '-copy-aligned-uart.log')
    stop(copy, 'COPY_BOARD_STOP')
    copies = rows(copy, 'COPY_BOARD')
    assert len(copies) == 4 and {int(v['trial']) for v in copies} == set(range(4))
    assert all(all(int(v[key]) == 0 for key in ('mismatch', 'under', 'failed')) for v in copies)
    alpha = folder / (run + '-alpha-oracle-uart.log')
    assert int(stop(alpha, 'ALPHA_PIPELINE_BOARD_STOP')['cases']) == 24
    alphas = rows(alpha, 'ALPHA_PIPELINE_BOARD')
    assert len(alphas) == 24 and {int(v['case']) for v in alphas} == set(range(24))
    phase = folder / (run + '-axi-phases-uart.log')
    stop(phase, 'SPRITE_PHASE_STOP')
    key = lambda value: (int(value['target']), int(value['tick']), value.get('stage', ''))
    phases = {key(v): v for v in rows(phase, 'SPRITE_PHASE')}
    axi = {key(v): v for v in rows(phase, 'AXI_PHASE')}
    fixtures = {key(v): v['list_crc'] for v in rows(phase, 'SPRITE_FIXTURE')}
    assert len(phases) == len(axi) == 24 and len(fixtures) == 6 and phases.keys() == axi.keys()
    assert all(int(v['under']) == 0 for v in phases.values())
    assert all(int(v['window']) > 0 and v['bcount'] == v['awcount'] for v in axi.values())
    groups[run] = dict(phases=phases, axi=axi, fixtures=fixtures, copies=copies, alphas=alphas)
baseline = groups[runs[0]]
for group in groups.values():
    assert group['fixtures'] == baseline['fixtures']
    for key, value in baseline['phases'].items():
        assert all(group['phases'][key][field] == value[field] for field in ('count', 'rd', 'wr', 'cache', 'under'))
    for index, value in enumerate(baseline['alphas']):
        assert all(group['alphas'][index][field] == value[field] for field in ('case', 'width', 'phase', 'cached', 'alpha', 'pixels', 'rd', 'wr', 'cache'))
axi = [value for group in groups.values() for value in group['axi'].values()]
result = dict(runs=summaries, ordinary_frames=14400, ordinary_assets='NETWORK1 LIVE1024',
              fixed_phase_assets='LOCAL0', phase_windows=len(axi), alpha_golden_cases=96, copy_golden_cases=16,
              fixture_and_byte_identity=True, read_credit_cycles=sum(int(v['rcredit']) for v in axi),
              read_sink_stall_cycles=sum(int(v['rsink']) for v in axi), observed_mean_work_gain_percent=0.0,
              adopted_for_performance=False, source_scope='immutable C4/E0, excludes Copy prefetch')
assert all(value['work_mean_us'] == 8778 for value in summaries)
(out / 'board-analysis-r2.json').write_text(json.dumps(result, indent=2))
print(json.dumps({key: value for key, value in result.items() if key != 'runs'}))
