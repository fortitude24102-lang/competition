param([string]$SerialPort='COM9')
$ErrorActionPreference='Stop'
Set-Location 'D:/ZYNQ/smallproject/.worktrees/pango-riscv-cpu'
$root=(Get-Location).Path
$experiment='generated/verification/v3/read-credit-20261025'
$cpu='generated/verification/v3/cpu-builder-20261025'
$alpha='generated/verification/v3/alpha-early-20261025'
$out="$experiment/board-aba-r1"
$control='D:/efinity_builds/alpha_early_candidate_20261025_r1/outflow/efinix_2d_gpu.bit'
$candidate='D:/efinity_builds/read_credit_candidate_20261026_r1/outflow/efinix_2d_gpu.bit'
$probe="$cpu/probe-logic-shift-r1/gpu_demo.bin"
$normal="$cpu/normal-logic-shift-r1/gpu_demo.bin"
function Read-Record([string]$Raw,[string]$Prefix) {
 $lines=@($Raw -split '\r?\n'|Where-Object {$_.StartsWith($Prefix+',')})
 if($lines.Count -ne 1){throw "Missing/duplicate $Prefix record"}
 $fields=[ordered]@{}
 foreach($item in $lines[0].Split(',')|Select-Object -Skip 1) {
  $parts=$item.Split('=',2)
  if($parts.Count -ne 2 -or $fields.Contains($parts[0])){throw 'Invalid or duplicate field'}
  $fields[$parts[0]]=$parts[1]
 }
 return $fields
}
function Assert-Stop([string]$Raw,[string]$Prefix) {
 $record=Read-Record $Raw $Prefix
 if(!$record.Contains('result') -or [long]$record.result -ne 0){throw "Failed $Prefix"}
 return $record
}
if(Test-Path -LiteralPath $out){throw 'Never overwrite a board experiment'}
if($SerialPort -notin [IO.Ports.SerialPort]::GetPortNames()){throw 'Required physical serial device is absent'}
if(!(Get-NetIPAddress -AddressFamily IPv4|Where-Object IPAddress -eq '192.168.1.2')){throw 'Required direct Ethernet address is absent'}
foreach($pair in @(@($control,'ef240664097d115b1e2fbc60f336a9190d4e8a2941a760642627e3563fcebcb1'),@($candidate,'6a8d19ddd10f2ac9fbef59d874113206aebfa63fe90268f571830c2e24928442'),@($probe,'d731f59769989ee44b49a08709acfeab57cc4bc0d9dad4995ad07185c494d1f6'),@($normal,'6000d1559cccaa91b340e2881db2afaed5c693cac2aa2e863f0340edb9c50b3c'))) {
 if((Get-FileHash -LiteralPath $pair[0]).Hash.ToLowerInvariant() -ne $pair[1]){throw 'Board experiment input identity mismatch'}
}
& 'C:/Users/fortiutde/AppData/Local/Programs/Python/Python39/python.exe' "$experiment/verify-archived-source-change.py"
if($LASTEXITCODE -ne 0){throw 'Source-change verification failed'}
& 'C:/Users/fortiutde/AppData/Local/Programs/Python/Python39/python.exe' "$experiment/verify-physical-inputs.py"
if($LASTEXITCODE -ne 0){throw 'Complete physical input verification failed'}
$bins=Get-Content "$alpha/input-bins.json" -Raw|ConvertFrom-Json
$assets=Get-Content 'generated/verification/v3/wide-copy-fair-20261024/asset-input-hashes.json' -Raw|ConvertFrom-Json
foreach($f in @($bins)+@($assets)){if((Get-FileHash -LiteralPath $f.Path).Hash -ne $f.Hash){throw 'Fixture or asset changed'}}
$state=Invoke-RestMethod 'http://127.0.0.1:8765/api/status' -TimeoutSec 5
if($state.simulated -or $state.stale -or $state.owned -or !(1024 -band $state.telemetry.raw.status_flags)){throw 'Recover a fresh real released normal MENU first'}
New-Item -ItemType Directory -Path $out|Out-Null
$results=@()
try {
 foreach($name in @('control-a1','candidate-b1','control-a2','candidate-b2')) {
  $bit=if($name.StartsWith('candidate')){$candidate}else{$control}
  & D:/efinity/pgm/bin/ftdi_pgm.bat $bit -m jtag *> "$out/$name-bit-load.log"
  if($LASTEXITCODE -ne 0){throw 'BIT JTAG load failed'}
  Start-Sleep -Seconds 3
  foreach($test in @(@('copy-aligned','COPY_BOARD_STOP'),@('axi-phases','SPRITE_PHASE_STOP'),@('alpha-oracle','ALPHA_PIPELINE_BOARD_STOP'))) {
   & scripts/measure-hud-glyphs-board.ps1 -Bin "$alpha/input-bins/$($test[0]).bin" -Log "$out/$name-$($test[0])-uart.log" -StopPattern $test[1] -SerialPort $SerialPort -Seconds 100 *> "$out/$name-$($test[0])-capture.log"
   $raw=Get-Content "$out/$name-$($test[0])-uart.log" -Raw
   $stop=Assert-Stop $raw $test[1]
   if(!$stop.Contains('hardware') -or [long]$stop.hardware -ne 0){throw 'Golden diagnostic hardware failure'}
   if($test[0] -eq 'alpha-oracle' -and [long]$stop.cases -ne 24){throw 'Incomplete Alpha golden matrix'}
  }
  & scripts/capture-game-probe.ps1 -Bin $probe -Log "$out/$name-probe-uart.log" -SerialPort $SerialPort -LogicCopy 1 -SealWords 256 -HudDirect 1 -Seconds 140 *> "$out/$name-probe-capture.log"
  $raw=Get-Content "$out/$name-probe-uart.log" -Raw
  $null=Assert-Stop $raw 'V3_PROBE_STOP'
  $ready=Read-Record $raw 'V3_READY'
  if($ready.network -ne '1' -or $ready.mode -ne 'LIVE' -or $ready.count -ne '1024'){throw 'Ordinary source bank or mode changed'}
  if($raw -notmatch 'V3_SEAL_STATE,count=600,sealed=1,words=256,offset=9836,crc=a7bd652f'){throw 'Replay input seal changed'}
  $record=Read-Record $raw 'V3_PROBE'
  foreach($item in @{target=1024;frames=3600;under=0;errors=0;visible_min=1006;visible_max=1016;alpha_min=130;alpha_max=131}.GetEnumerator()){if(!$record.Contains($item.Key) -or [long]$record[$item.Key] -ne $item.Value){throw "Ordinary workload/health mismatch: $($item.Key)"}}
  $row=[ordered]@{name=$name}
  foreach($item in $record.GetEnumerator()){$row[$item.Key]=[long]$item.Value}
  $results+=[pscustomobject]$row
  $results|ConvertTo-Json -Depth 4|Set-Content "$out/summary.json" -Encoding utf8
  Write-Output "$name mean=$($record.work_mean_us) max=$($record.work_max_us) miss=$($record.work_miss) late=$($record.late_present)"
 }
} catch {
 $_|Out-String|Set-Content "$out/experiment-failure.txt" -Encoding utf8
 throw
} finally {
 & scripts/test-game-menu-board.ps1 -Bin $normal -Bit $control -LoadBit -SerialPort $SerialPort -OutDirectory "$out/final-menu" -ExpectedBuild 0x20261015 -LevelCount 6 -Python C:/Users/fortiutde/AppData/Local/Programs/Python/Python39/python.exe *> "$out/final-menu.log"
 $state=Invoke-RestMethod 'http://127.0.0.1:8765/api/status' -TimeoutSec 5
 if($state.simulated -or $state.stale -or $state.owned -or !(1024 -band $state.telemetry.raw.status_flags)){throw 'Final normal MENU is not fresh/released'}
 $state|ConvertTo-Json -Depth 8|Set-Content "$out/final-state.json" -Encoding utf8
 'PASS restored accepted EF plus normal6000d155; new read-credit BIT remains experimental'
}
