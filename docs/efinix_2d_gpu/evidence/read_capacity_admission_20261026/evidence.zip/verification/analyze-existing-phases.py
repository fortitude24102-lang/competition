import hashlib
import json
from pathlib import Path
from statistics import mean
from zipfile import ZipFile

root = Path.cwd()
out = root / 'generated/verification/v3/read-credit-20261025'
folder = root / 'generated/verification/v3/alpha-early-20261025/board-aba-r1'
archive = root / 'docs/efinix_2d_gpu/evidence/alpha_early_prefetch_20261025/evidence.zip'
assert hashlib.sha256(archive.read_bytes()).hexdigest() == 'd701a96ef5aa9312bed6b22125f07cc0fa49def317fa891d7e8288a141247a7a'
groups, inputs = {}, []
with ZipFile(archive) as zipped:
    for run in ('control-a1', 'candidate-b1', 'control-a2'):
        name = run + '-axi-phases-uart.log'
        data = (folder / name).read_bytes()
        assert data == zipped.read('board-aba-r1/' + name)
        phases, axi, fixtures = {}, {}, {}
        text = data.decode('utf-8-sig')
        assert text.count('SPRITE_PHASE_STOP,result=0,hardware=0') == 1
        for line in text.splitlines():
            if not line.startswith(('SPRITE_PHASE,', 'AXI_PHASE,', 'SPRITE_FIXTURE,')):
                continue
            fields = dict(part.split('=', 1) for part in line.split(',')[1:])
            key = int(fields['target']), int(fields['tick'])
            if line.startswith('SPRITE_FIXTURE,'):
                assert key not in fixtures
                fixtures[key] = fields['list_crc']
                continue
            key += (fields.pop('stage'),)
            values = {k: int(v) for k, v in fields.items()}
            target = phases if line.startswith('SPRITE_PHASE,') else axi
            assert key not in target
            target[key] = values
        assert len(phases) == len(axi) == 24 and len(fixtures) == 6
        assert set(phases) == set(axi) and all(v['under'] == 0 for v in phases.values())
        assert all(0 < v['window'] < 4_000_000_000 and v['bcount'] == v['awcount'] for v in axi.values())
        groups[run] = dict(phases=phases, axi=axi, fixtures=fixtures)
        inputs.append(dict(name=name, sha256=hashlib.sha256(data).hexdigest()))
baseline = groups['control-a1']
for run in groups.values():
    assert run['fixtures'] == baseline['fixtures']
    for key in baseline['phases']:
        assert all(run['phases'][key][k] == baseline['phases'][key][k]
                   for k in ('count', 'rd', 'wr', 'cache', 'under'))
all_axi = [row for group in groups.values() for row in group['axi'].values()]
summary = dict(archived_inputs=inputs, phase_windows=len(all_axi),
               nonzero_read_credit_windows=sum(row['rcredit'] != 0 for row in all_axi),
               nonzero_read_sink_stall_windows=sum(row['rsink'] != 0 for row in all_axi),
               read_credit_cycles_total=sum(row['rcredit'] for row in all_axi),
               fixture_and_byte_identity=True, target1040={})
for run, group in groups.items():
    summary['target1040'][run] = {}
    for stage in ('BACKGROUND', 'ALPHA', 'KEY', 'FULL'):
        keys = [key for key in group['phases'] if key[0] == 1040 and key[2] == stage]
        p, a = [group['phases'][k] for k in keys], [group['axi'][k] for k in keys]
        summary['target1040'][run][stage] = dict(
            render_us=mean(v['ticks'] for v in p)/100,
            gpu_busy_us=mean(v['busy'] for v in p)/100,
            gpu_read_bytes=mean(v['rd'] for v in p), gpu_write_strobe_bytes=mean(v['wr'] for v in p),
            b_wait_us=mean(v['bwait'] for v in a)/100,
            aw_qos_us=mean(v['awqos'] for v in a)/100,
            r_gap_us=mean(v['rgap'] for v in a)/100,
            read_credit_cycles=sum(v['rcredit'] for v in a),
            warning='Channel waits overlap and these are fixed-stage diagnostics, not ordinary-frame CPU timings')
(out / 'existing-phase-analysis.json').write_text(json.dumps(summary, indent=2))
print(json.dumps(dict(phase_windows=summary['phase_windows'],
                     read_credit_cycles_total=summary['read_credit_cycles_total'],
                     nonzero_read_sink_stall_windows=summary['nonzero_read_sink_stall_windows'],
                     candidate1040=summary['target1040']['candidate-b1'])))
