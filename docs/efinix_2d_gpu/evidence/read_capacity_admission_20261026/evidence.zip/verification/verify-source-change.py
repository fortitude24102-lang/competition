import hashlib
import json
from pathlib import Path
from zipfile import ZipFile

root = Path.cwd()
out = root / 'generated/verification/v3/read-credit-20261025'
old_dir = root / 'generated/verification/v3/alpha-early-20261025/rtl-candidate-r1'
new_dir = out / 'rtl-candidate-r1'
old = json.loads((old_dir / 'gpu-build.json').read_text(encoding='utf-8-sig'))
new = json.loads((new_dir / 'gpu-build.json').read_text(encoding='utf-8-sig'))
assert old['schemaVersion'] == new['schemaVersion'] == 2
assert old['features'] == new['features'] and len(new['features']) == 18
assert set(old['rtlSha256']) == set(new['rtlSha256'])
rtl_delta = []
for name, digest in new['rtlSha256'].items():
    assert hashlib.sha256((new_dir / name).read_bytes()).hexdigest() == digest, name
    assert hashlib.sha256((old_dir / name).read_bytes()).hexdigest() == old['rtlSha256'][name], name
    if digest != old['rtlSha256'][name]:
        rtl_delta.append(name)
assert rtl_delta == ['DdrQosArbiter.sv'], rtl_delta
archive = root / 'docs/efinix_2d_gpu/evidence/alpha_early_prefetch_20261025/evidence.zip'
assert hashlib.sha256(archive.read_bytes()).hexdigest() == 'd701a96ef5aa9312bed6b22125f07cc0fa49def317fa891d7e8288a141247a7a'
old_digest, new_digest = hashlib.sha256(), hashlib.sha256()
source_delta = []
source_prefix = 'source/chisel/'
with ZipFile(archive) as zipped:
    assert json.loads(zipped.read('rtl-candidate-r1/gpu-build.json')) == old
    names = sorted(name for name in zipped.namelist()
                   if name.startswith(source_prefix + 'src/main/scala/gpu/') and name.endswith('.scala'))
    actual = sorted(p.relative_to(root / 'chisel').as_posix()
                    for p in (root / 'chisel/src/main/scala/gpu').rglob('*.scala'))
    assert [name[len(source_prefix):] for name in names] == actual and len(names) == 38
    for name in names:
        relative = name[len(source_prefix):]
        before, after = zipped.read(name), (root / 'chisel' / relative).read_bytes()
        old_digest.update(relative.encode() + b'\0' + before)
        new_digest.update(relative.encode() + b'\0' + after)
        if before != after:
            source_delta.append(relative)
        snapshot = out / 'source-snapshot/chisel' / relative
        snapshot.parent.mkdir(parents=True, exist_ok=True)
        if snapshot.exists():
            assert snapshot.read_bytes() == after, 'Never overwrite a different source snapshot'
        else:
            snapshot.write_bytes(after)
assert old_digest.hexdigest() == old['sourceSha256']
assert new_digest.hexdigest() == new['sourceSha256']
assert source_delta == ['src/main/scala/gpu/DdrQosArbiter.scala'], source_delta
control_bit = Path('D:/efinity_builds/alpha_early_candidate_20261025_r1/outflow/efinix_2d_gpu.bit')
assert hashlib.sha256(control_bit.read_bytes()).hexdigest() == 'ef240664097d115b1e2fbc60f336a9190d4e8a2941a760642627e3563fcebcb1'
physical_manifest = Path('D:/efinity_builds/read_credit_candidate_20261026_r1/gpu-build.json')
if physical_manifest.exists():
    assert json.loads(physical_manifest.read_text(encoding='utf-8-sig')) == new
result = dict(scope='Controlled source-code optimization, not a same-source feature toggle',
              old_source_sha256=old['sourceSha256'], new_source_sha256=new['sourceSha256'],
              source_delta=source_delta, rtl_delta=rtl_delta, source_files=38,
              rtl_files=len(new['rtlSha256']), identical_features=new['features'],
              control_bit_sha256=hashlib.sha256(control_bit.read_bytes()).hexdigest())
(out / 'source-change-verification.json').write_text(json.dumps(result, indent=2))
print(json.dumps({key: value for key, value in result.items() if key != 'identical_features'}))
