import json
from pathlib import Path
import shutil
import subprocess
import sys
import xml.etree.ElementTree as ET

out = Path('generated/verification/v3/read-credit-20261025')
fixture = out / 'input-guard-fixture-r1'
fixture.mkdir()
source = Path('D:/efinity_builds/read_credit_candidate_20261026_r1')
for name in ['efinix_2d_gpu.xml', 'efinix_2d_gpu.peri.xml', 'gpu-build.json'] + [p.name for p in source.glob('*.bin')]:
    shutil.copyfile(source / name, fixture / name)
command = [sys.executable, str(out / 'verify-physical-inputs.py'), '--new-build', str(fixture),
           '--manifest', str(fixture / 'frozen.json')]
subprocess.run(command + ['--freeze'], check=True, capture_output=True)
def rejects(label):
    result = subprocess.run(command, capture_output=True, text=True)
    assert result.returncode != 0, label
    print('PASS guard rejects ' + label)
xml = fixture / 'efinix_2d_gpu.xml'
original = xml.read_bytes()
tree = ET.fromstring(original)
seed = next(n for n in tree.iter() if 'seed' in n.attrib.get('name', '').lower())
seed.attrib['value'] = str(int(seed.attrib['value']) + 1)
xml.write_bytes(ET.tostring(tree))
rejects('changed P&R seed')
xml.write_bytes(original)
rom = next(fixture.glob('*.bin'))
original = rom.read_bytes()
rom.write_bytes(bytes([original[0] ^ 1]) + original[1:])
rejects('changed copied SoC ROM')
rom.write_bytes(original)
manifest = fixture / 'gpu-build.json'
original = manifest.read_bytes()
data = json.loads(original)
data['features']['alphaEarlyPrefetch'] = False
manifest.write_text(json.dumps(data))
rejects('physical manifest differing from generated manifest')
manifest.write_bytes(original)
subprocess.run(command, check=True, capture_output=True)
print('PASS restored fixture and actual comparison logic')
