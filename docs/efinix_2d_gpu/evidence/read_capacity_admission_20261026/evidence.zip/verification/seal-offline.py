import hashlib
import json
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

root = Path.cwd()
out = root / 'generated/verification/v3/read-credit-20261025'
dest = root / 'docs/efinix_2d_gpu/evidence/read_capacity_admission_20261026'
build = Path('D:/efinity_builds/read_credit_candidate_20261026_r1')
archive = dest / 'evidence.zip'
assert not archive.exists(), 'Never overwrite sealed evidence'
files = {}
def add(path, name):
    assert path.is_file() and name not in files, path
    files[name] = path
def tree(path, prefix):
    for child in sorted(path.rglob('*')):
        if child.is_file():
            add(child, prefix + '/' + child.relative_to(path).as_posix())
frozen = json.loads((out / 'physical-inputs-r1.json').read_text())
input_map = []
for i, (name, digest) in enumerate(sorted(frozen['files'].items())):
    path = Path(name)
    assert hashlib.sha256(path.read_bytes()).hexdigest() == digest
    target = f'physical-inputs/{i:03d}-{path.name}'
    add(path, target)
    input_map.append(dict(original_path=name, archive_path=target, sha256=digest))
(out / 'physical-input-archive-map.json').write_text(json.dumps(input_map, indent=2))
for name in ('verify-source-change.py', 'verify-physical-inputs.py', 'test-physical-input-guard.py',
             'build-physical-r1.ps1', 'build-physical-r1-before-input-audit.ps1',
             'control-DdrQosArbiter.scala', 'red.log', 'green-attempt1-invalid-test-id.log',
             'green-corrected-all-r2.log', 'integrated-and-generate-r1.log',
             'test-red.sh', 'test-all.sh', 'test-integrated-and-generate.sh',
             'physical-exec-r1.log', 'compile-candidate-r1.log', 'cdc-candidate-r1.log',
             'resource-cdc-candidate-r1.log', 'physical-result-r1.json',
             'physical-result-before-input-audit-r1.json', 'source-change-verification.json',
             'physical-inputs-r1.json', 'physical-input-archive-map.json',
             'physical-inputs-freeze-r1.log', 'physical-inputs-post-audit-r1.log',
             'input-guard-tests-r1.log', 'analyze-existing-phases.py', 'existing-phase-analysis.json'):
    add(out / name, 'verification/' + name)
tree(out / 'source-snapshot', 'source')
add(root / 'chisel/src/test/scala/gpu/DdrQosArbiterSpec.scala', 'source/chisel/src/test/scala/gpu/DdrQosArbiterSpec.scala')
for name in ('efinix_2d_gpu.bit', 'efinix_2d_gpu.map.v', 'efinix_2d_gpu.timing.rpt',
             'efinix_2d_gpu.hier_util.rpt', 'efinix_2d_gpu.res.csv', 'efinix_2d_gpu.hold_fixing.rpt',
             'net-mailbox-data.rpt', 'net-mailbox-request.rpt', 'net-mailbox-ack.rpt', 'net-mailbox-applied.sdc'):
    add(build / 'outflow' / name, 'physical/outflow/' + name)
add(Path('D:/efinity_builds/alpha_early_candidate_20261025_r1/outflow/efinix_2d_gpu.bit'), 'control/efinix_2d_gpu.bit')
for name in ('control-a1', 'candidate-b1', 'control-a2'):
    add(root / 'generated/verification/v3/alpha-early-20261025/board-aba-r1' / (name + '-axi-phases-uart.log'),
        'prior-alpha-phases/' + name + '-axi-phases-uart.log')
add(dest / 'README.md', 'README.md')
add(root / 'docs/efinix_2d_gpu/performance_bounds_20261026.md', 'performance_bounds_20261026.md')
add(Path(__file__), 'verification/seal-offline.py')
def no_credentials(value):
    if isinstance(value, dict):
        for key, item in value.items():
            assert key.lower() not in ('token', 'password', 'secret', 'authorization', 'cookie'), key
            no_credentials(item)
    elif isinstance(value, list):
        for item in value:
            no_credentials(item)
manifest = []
with ZipFile(archive, 'x', ZIP_DEFLATED, compresslevel=9) as zipped:
    for name, path in sorted(files.items()):
        data = path.read_bytes()
        if path.suffix == '.json':
            no_credentials(json.loads(data.decode('utf-8-sig')))
        manifest.append(dict(path=name, bytes=len(data), sha256=hashlib.sha256(data).hexdigest()))
        zipped.writestr(name, data)
    body = json.dumps(dict(payloads=manifest, physical_inputs=238, physical_qualified=True,
                           full_input_audit='post-build', board_tested=False,
                           hardware_implementation_commit='6f28220'), indent=2).encode()
    zipped.writestr('manifest.json', body)
with ZipFile(archive) as zipped:
    assert len(zipped.namelist()) == len(manifest)+1 == len(set(zipped.namelist()))
    for item in manifest:
        data = zipped.read(item['path'])
        assert len(data) == item['bytes'] and hashlib.sha256(data).hexdigest() == item['sha256']
digest = hashlib.sha256(archive.read_bytes()).hexdigest()
(dest / 'SHA256SUMS').write_text(digest + '  evidence.zip\n')
(dest / 'manifest.json').write_bytes(body)
summary = dict(sha256=digest, bytes=archive.stat().st_size, entries=len(manifest)+1)
(out / 'offline-seal-summary.json').write_text(json.dumps(summary, indent=2))
print(json.dumps(summary))
