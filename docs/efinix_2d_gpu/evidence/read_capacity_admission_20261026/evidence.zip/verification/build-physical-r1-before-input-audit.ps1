$ErrorActionPreference='Stop'
$root='D:/ZYNQ/smallproject/.worktrees/pango-riscv-cpu'
Set-Location $root
$out='generated/verification/v3/read-credit-20261025'
$rtl="$out/rtl-candidate-r1"
$build='D:/efinity_builds/read_credit_candidate_20261026_r1'
if(Test-Path -LiteralPath $build){throw 'Physical output must be fresh'}
foreach($log in @('green-corrected-all-r2.log','integrated-and-generate-r1.log')) {
 if(!(Select-String -LiteralPath "$out/$log" -SimpleMatch 'All tests passed.')){throw 'Required functional regression missing'}
}
& 'C:/Users/fortiutde/AppData/Local/Programs/Python/Python39/python.exe' "$out/verify-source-change.py"
if($LASTEXITCODE -ne 0){throw 'Archived-control/source-change verification failed'}
# This is a source change, not a feature-flag comparison. Validate the complete
# candidate manifest with the existing validator, and pin the archived control
# separately: all18 features and69/70 emitted sources are byte-identical.
& scripts/compare-gpu-build.ps1 -ReferenceGpuRtlDirectory $rtl -CandidateGpuRtlDirectory $rtl
$common=Get-Content -LiteralPath 'generated/verification/v3/wide-copy-fair-20261024/wide_copy_fair_20261024_r1-board-inputs.json' -Raw|ConvertFrom-Json
foreach($f in $common){if((Get-FileHash -LiteralPath $f.Path).Hash.ToLowerInvariant() -ne $f.Sha256){throw "Shared board input changed: $($f.Path)"}}
& scripts/test-efinix-board.ps1 -GpuRtlDirectory $rtl -OutputDirectory $build -Flow compile *> "$out/compile-candidate-r1.log"
if($LASTEXITCODE -ne 0){throw 'Read-credit physical compilation failed'}
Push-Location $build
try {
 & D:/efinity/bin/efx_run.bat efinix_2d_gpu --prj -f sta_tclsh --tcl_script "$root/scripts/report-net-mailbox-cdc.tcl" *> "$root/$out/cdc-candidate-r1.log"
 if($LASTEXITCODE -ne 0){throw 'Routed CDC extraction failed'}
} finally {Pop-Location}
& scripts/test-net-resource-report.ps1 -BuildDirectory $build -RequireRouted *> "$out/resource-cdc-candidate-r1.log"
$timing=Get-Content -LiteralPath "$build/outflow/efinix_2d_gpu.timing.rpt" -Raw
$rows=[regex]::Matches($timing,'(?m)^\S+\s+\S+\s+(-?[\d.]+)\s+(-?[\d.]+)\s+\(R-R\)\s*$')
if($rows.Count -ne 16 -or @($rows|Where-Object {[double]$_.Groups[2].Value -le 0}).Count){throw 'All16 final setup/hold relationships must have positive slack'}
foreach($f in $common){if((Get-FileHash -LiteralPath $f.Path).Hash.ToLowerInvariant() -ne $f.Sha256){throw 'Shared board input changed during compilation'}}
& 'C:/Users/fortiutde/AppData/Local/Programs/Python/Python39/python.exe' "$out/verify-source-change.py"
if($LASTEXITCODE -ne 0){throw 'Source or generated RTL changed during compilation'}
[ordered]@{physical_qualified=$true;build=$build;bit_sha256=(Get-FileHash -LiteralPath "$build/outflow/efinix_2d_gpu.bit").Hash.ToLowerInvariant();board_tested=$false}|ConvertTo-Json|Set-Content -LiteralPath "$out/physical-result-r1.json" -Encoding utf8
'PASS read-credit physical area, final timing, routed CDC and input identity gates'
