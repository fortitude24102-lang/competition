$ErrorActionPreference='Stop'
Set-Location 'D:/ZYNQ/smallproject/.worktrees/pango-riscv-cpu'
$out='generated/verification/v3/key-row-handoff-20261026';$build='D:/efinity_builds/key_row_handoff_20261026_r1'
$python='C:/Users/fortiutde/AppData/Local/Programs/Python/Python39/python.exe'
& $python "$out/verify-source-r1.py";if($LASTEXITCODE){throw 'Source/RTL identity failed'}
& $python "$out/physical-inputs-r1.py";if($LASTEXITCODE){throw 'Exact compiler stamp/input audit failed'}
$compile=Get-Content "$out/compile-physical-r1.log" -Raw
foreach($stage in 'map','interface','pnr','pgm'){if($compile -notmatch ($stage+'\s*:\s*PASS')){throw 'Incomplete native compilation'}}
& scripts/test-net-resource-report.ps1 -BuildDirectory $build -RequireRouted *> "$out/resource-cdc-qualified-r1.log"
$timing=Get-Content "$build/outflow/efinix_2d_gpu.timing.rpt" -Raw
$rows=[regex]::Matches($timing,'(?m)^\S+\s+\S+\s+(-?[\d.]+)\s+(-?[\d.]+)\s+\(R-R\)\s*$')
if($rows.Count -ne 16 -or @($rows|Where-Object {[double]$_.Groups[2].Value -le 0}).Count){throw 'Strict16 timing gate failed'}
$mapped=Get-Content "$build/outflow/efinix_2d_gpu.map.v" -Raw
foreach($stage in 'meta_n','sync_n'){if([regex]::Matches($mapped,('EFX_FF \\sapphire/nav_keys/'+$stage+'\[\d\]~FF')).Count -ne 5){throw 'Wrong mapped local synchronizer coverage'}}
[ordered]@{physical_qualified=$true;source_sha256=(Get-Content "$out/selected-source-r1.json" -Raw|ConvertFrom-Json).source_sha256;bit_sha256=(Get-FileHash "$build/outflow/efinix_2d_gpu.bit").Hash.ToLowerInvariant();xlr=54234;ram=186;dsp=38;core_setup_ns=0.492;core_hold_ns=0.026;strict_positive_relationships=16;precompile_inputs_frozen=170;input_scope='169 raw inputs unchanged plus canonical project; exact compiler-version stamp independently audited';original_wrapper_exit_code=1;original_wrapper_reason='Input guard stopped on compiler root sw_version update; native compilation and routed extraction completed';independent_qualification_exit_scope='This separate qualification result does not relabel the original wrapper';board_tested=$false}|ConvertTo-Json|Set-Content "$out/physical-result-r1.json" -Encoding utf8
'PASS independently qualified area, strict16 timing, routed CDC, local synchronizers and exact compiler-stamp/input audit'
