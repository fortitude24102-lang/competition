import hashlib,json,re
from pathlib import Path
root=Path.cwd();out=root/'generated/verification/v3/key-row-handoff-20261026'
old=root/'generated/verification/v3/wide-copy-prefetch-20261026/rtl-candidate-r1'
new=out/'rtl-candidate-r1'
before=json.loads((old/'gpu-build.json').read_text(encoding='utf-8-sig'))
after=json.loads((new/'gpu-build.json').read_text(encoding='utf-8-sig'))
assert before['features']==after['features'] and len(after['features'])==18
assert before['wideCopyDma']==after['wideCopyDma']==True
frozen=json.loads((out/'baseline-source-raw-hashes.json').read_text())
h=hashlib.sha256();changed=[];current={}
for p in sorted((root/'chisel/src/main/scala/gpu').glob('*.scala')):
 name=p.relative_to(root).as_posix();data=p.read_bytes();digest=hashlib.sha256(data).hexdigest();current[name]=digest
 h.update(p.relative_to(root/'chisel').as_posix().encode());h.update(b'\0');h.update(data)
 if digest!=frozen['files'][name]:changed.append(p.name)
assert sorted(changed)==['AxiWritePipeline.scala','CachedKeyStream.scala','Rgb565WordAligner.scala'],changed
assert h.hexdigest()==after['sourceSha256']
for base,manifest in ((old,before),(new,after)):
 names=[n.strip() for n in (base/'filelist.f').read_text().splitlines() if n.strip()]
 assert set(names)==set(manifest['rtlSha256'])
 for name,digest in manifest['rtlSha256'].items():assert hashlib.sha256((base/name).read_bytes()).hexdigest()==digest,name
def ports(p):
 header=p.read_text().split(');',1)[0]
 return re.findall(r'\b(input|output)\s+(?:wire\s+|logic\s+)?(\[[^\]]+\]\s+)?([A-Za-z_]\w*)',header)
assert ports(old/'Efinix2dGpuTop.sv')==ports(new/'Efinix2dGpuTop.sv')
result=dict(source_sha256=h.hexdigest(),features=after['features'],changed_sources=changed,source_files=current,rtl_files=len(after['rtlSha256']),top_ports_unchanged=True)
snapshot=out/'selected-source-r1.json'
if snapshot.exists():assert json.loads(snapshot.read_text())==result,'Source/RTL identity changed after selection'
else:snapshot.write_text(json.dumps(result,indent=2))
print(json.dumps({k:v for k,v in result.items() if k not in ('source_files','features')}))
