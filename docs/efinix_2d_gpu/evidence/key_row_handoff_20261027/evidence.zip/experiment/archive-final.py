import hashlib,json,re,zipfile
from pathlib import Path
root=Path.cwd();src=root/'generated/verification/v3/key-row-handoff-20261026'
dst=root/'docs/efinix_2d_gpu/evidence/key_row_handoff_20261027';dst.mkdir(parents=True,exist_ok=True)
protected=json.loads((root/'generated/verification/v3/wide-copy-fair-20261024/preexisting-file-hashes.json').read_text(encoding='utf-8-sig'))
for item in protected:assert hashlib.sha256(Path(item['Path']).read_bytes()).hexdigest()==item['Hash'].lower()
rows=json.loads((src/'board-short-r2/summary.json').read_text(encoding='utf-8-sig'))
assert len(rows)==4
for row in rows:
 assert row['frames']==720 and row['target']==1024
 assert all(row[k]==0 for k in ('work_miss','late_present','under','errors'))
 raw=(src/f"board-short-r2/{row['name']}-uart.log").read_text()
 assert len(re.findall(r'V3_SEAL_STATE,count=600,sealed=1,words=256,offset=9836,crc=a7bd652f',raw))==1
a=sum(r['work_mean_us'] for r in rows if r['name'].startswith('control'))/2
b=sum(r['work_mean_us'] for r in rows if r['name'].startswith('candidate'))/2
assert b<a
summary=dict(adopted=True,scope='Four short720-frame1024 ordinary cohorts; no new endurance claim',baseline_mean_us=a,candidate_mean_us=b,reduction_percent=(a-b)/a*100,baseline_bit_sha256=rows[0]['bit_sha256'],selected_bit_sha256=rows[1]['bit_sha256'],source_sha256=json.loads((src/'selected-source-r1.json').read_text())['source_sha256'],protected_files_unchanged=len(protected),further_optimization='Stopped at explicit user request; no hardware-limit claim')
(dst/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
archive=dst/'evidence.zip';assert not archive.exists()
extensions={'.log','.json','.py','.ps1','.sh','.xml','.scala','.txt','.v','.sv','.f'}
files=[p for p in src.rglob('*') if p.is_file() and p.suffix.lower() in extensions and 'baseline-source' not in p.relative_to(src).parts]
physical=Path('D:/efinity_builds/key_row_handoff_20261026_r1/outflow')
reports=[physical/n for n in ('efinix_2d_gpu.timing.rpt','efinix_2d_gpu.pinout.csv','net-mailbox-applied.sdc')]
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(files):z.write(p,'experiment/'+str(p.relative_to(src)).replace('\\','/'))
 for p in reports:z.write(p,'physical/'+p.name)
with zipfile.ZipFile(archive) as z:assert z.testzip() is None;entries=len(z.namelist())
sha=hashlib.sha256(archive.read_bytes()).hexdigest()
(dst/'evidence.sha256.txt').write_text(f'{sha}  evidence.zip\n')
print(json.dumps(dict(summary=summary,archive_bytes=archive.stat().st_size,entries=entries,archive_sha256=sha)))
