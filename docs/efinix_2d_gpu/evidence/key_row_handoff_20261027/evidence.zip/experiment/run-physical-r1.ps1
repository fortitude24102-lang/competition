$ErrorActionPreference='Stop'
$root='D:/ZYNQ/smallproject/.worktrees/pango-riscv-cpu'
Set-Location $root
$out='generated/verification/v3/key-row-handoff-20261026';$build='D:/efinity_builds/key_row_handoff_20261026_r1'
$python='C:/Users/fortiutde/AppData/Local/Programs/Python/Python39/python.exe'
if(Test-Path $build){throw 'Fresh physical directory required'}
& $python "$out/verify-source-r1.py";if($LASTEXITCODE){throw 'Source/RTL selection failed'}
& scripts/test-efinix-board.ps1 -GpuRtlDirectory "$out/rtl-candidate-r1" -OutputDirectory $build -PrepareOnly *> "$out/prepare-physical-r1.log"
& $python "$out/physical-inputs-r1.py" --freeze;if($LASTEXITCODE){throw 'Physical input freeze failed'}
Push-Location $build
try {
 & D:/efinity/bin/efx_run.bat efinix_2d_gpu --prj -f compile *> "$root/$out/compile-physical-r1.log"
 if($LASTEXITCODE){throw 'Physical compilation failed'}
 & D:/efinity/bin/efx_run.bat efinix_2d_gpu --prj -f sta_tclsh --tcl_script "$root/scripts/report-net-mailbox-cdc.tcl" *> "$root/$out/cdc-physical-r1.log"
 if($LASTEXITCODE){throw 'Routed CDC extraction failed'}
} finally {Pop-Location}
& $python "$out/verify-source-r1.py";if($LASTEXITCODE){throw 'Source/RTL changed during build'}
& $python "$out/physical-inputs-r1.py";if($LASTEXITCODE){throw 'Physical input identity failed'}
& scripts/test-net-resource-report.ps1 -BuildDirectory $build -RequireRouted *> "$out/resource-cdc-r1.log"
$timing=Get-Content "$build/outflow/efinix_2d_gpu.timing.rpt" -Raw
$rows=[regex]::Matches($timing,'(?m)^\S+\s+\S+\s+(-?[\d.]+)\s+(-?[\d.]+)\s+\(R-R\)\s*$')
if($rows.Count -ne 16 -or @($rows|Where-Object {[double]$_.Groups[2].Value -le 0}).Count){throw 'All16 timing relationships must be strictly positive'}
$mapped=Get-Content "$build/outflow/efinix_2d_gpu.map.v" -Raw
foreach($stage in 'meta_n','sync_n'){if([regex]::Matches($mapped,('EFX_FF \\sapphire/nav_keys/'+$stage+'\[\d\]~FF')).Count -ne 5){throw 'Local-input synchronizer coverage changed'}}
[ordered]@{physical_qualified=$true;source_sha256=(Get-Content "$out/selected-source-r1.json" -Raw|ConvertFrom-Json).source_sha256;bit_sha256=(Get-FileHash "$build/outflow/efinix_2d_gpu.bit").Hash.ToLowerInvariant();precompile_inputs_frozen=$true;board_tested=$false}|ConvertTo-Json|Set-Content "$out/physical-result-r1.json" -Encoding utf8
'PASS candidate physical area, strict16 timing, routed mailbox CDC, local synchronizers and precompile input identity'
