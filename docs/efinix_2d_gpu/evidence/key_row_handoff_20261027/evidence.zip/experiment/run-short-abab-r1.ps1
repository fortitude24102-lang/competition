$ErrorActionPreference='Stop'
$root='generated/verification/v3/key-row-handoff-20261026'
$out="$root/board-short-r2"
$control='D:/efinity_builds/local_keys_20261026_r2/outflow/efinix_2d_gpu.bit'
$candidate='D:/efinity_builds/key_row_handoff_20261026_r1/outflow/efinix_2d_gpu.bit'
$normal='generated/verification/v3/validation-hoist-20261026/normal-selected-r1/gpu_demo.bin'
if(Test-Path $out){throw 'Fresh capture required'}
New-Item -ItemType Directory $out|Out-Null
function Record($raw,$prefix) {
 $matches=[regex]::Matches($raw,"(?m)^$prefix,([^\r\n]+)")
 if($matches.Count -ne 1){throw "Expected one $prefix"}
 $row=@{};foreach($f in $matches[0].Groups[1].Value.Split(',')){$kv=$f.Split('=');$row[$kv[0]]=$kv[1]};return $row
}
$results=@()
try {
 foreach($name in @('control-a1','candidate-b1','control-a2','candidate-b2')) {
  $bit=if($name.StartsWith('candidate')){$candidate}else{$control}
  & D:/efinity/pgm/bin/ftdi_pgm.bat $bit -m jtag *> "$out/$name-bit.log"
  if($LASTEXITCODE){throw 'BIT load failed'}
  Start-Sleep -Seconds 2
  if($name -eq 'candidate-b1') {
   foreach($test in @(@('copy-aligned','COPY_BOARD_STOP'),@('axi-phases','SPRITE_PHASE_STOP'),@('alpha-oracle','ALPHA_PIPELINE_BOARD_STOP'))) {
    & scripts/measure-hud-glyphs-board.ps1 -Bin "generated/verification/v3/alpha-early-20261025/input-bins/$($test[0]).bin" -Log "$out/$name-$($test[0])-uart.log" -StopPattern $test[1] -SerialPort COM9 -Seconds 100 *> "$out/$name-$($test[0])-capture.log"
    $record=Record (Get-Content "$out/$name-$($test[0])-uart.log" -Raw) $test[1]
    if($record.result -ne '0' -or $record.hardware -ne '0'){throw 'Pixel oracle failed'}
   }
  }
  & scripts/capture-game-probe.ps1 -Bin "$root/probe-short-r2/gpu_demo.bin" -Log "$out/$name-uart.log" -SerialPort COM9 -LogicCopy 1 -SealWords 256 -HudDirect 1 -Seconds 65 *> "$out/$name-capture.log"
  $raw=Get-Content "$out/$name-uart.log" -Raw
  $stop=Record $raw 'V3_PROBE_STOP';$r=Record $raw 'V3_PROBE';$ready=Record $raw 'V3_READY'
  if($stop.result -ne '0' -or $ready.network -ne '1' -or $ready.count -ne '1024'){throw 'Wrong workload or failed stop'}
  foreach($item in @{target=1024;frames=720;under=0;errors=0;work_miss=0;late_present=0}.GetEnumerator()) {if(!$r.ContainsKey($item.Key) -or [long]$r[$item.Key] -ne $item.Value){throw "Short cohort failed $($item.Key)"}}
  $row=[ordered]@{name=$name;bit_sha256=(Get-FileHash $bit).Hash.ToLowerInvariant()};foreach($kv in $r.GetEnumerator()){$row[$kv.Key]=[long]$kv.Value}
  $results+=[pscustomobject]$row
  $results|ConvertTo-Json -Depth 4|Set-Content "$out/summary.json" -Encoding utf8
  Write-Output "$name mean=$($r.work_mean_us) max=$($r.work_max_us)"
 }
} finally {
 & scripts/test-game-menu-board.ps1 -Bin $normal -Bit $control -LoadBit -SerialPort COM9 -ExpectedBuild 0x20261015 -LevelCount 6 -Python C:/Users/fortiutde/AppData/Local/Programs/Python/Python39/python.exe -OutDirectory "$out/final-menu" *> "$out/final-menu.log"
}
