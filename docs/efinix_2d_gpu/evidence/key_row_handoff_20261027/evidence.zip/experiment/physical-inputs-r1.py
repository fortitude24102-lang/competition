import copy,hashlib,json,sys
from pathlib import Path
import xml.etree.ElementTree as ET
root=Path.cwd();out=root/'generated/verification/v3/key-row-handoff-20261026'
build=Path('D:/efinity_builds/key_row_handoff_20261026_r1');project=build/'efinix_2d_gpu.xml'
tree=ET.parse(project);paths={build/'efinix_2d_gpu.peri.xml',build/'gpu-build.json'}
def canonical(n):return [n.tag,[[k,v] for k,v in sorted(n.attrib.items())],(n.text or '').strip(),[canonical(c) for c in n]]
for n in tree.iter():
 kind=n.tag.split('}')[-1]
 if kind in ('design_file','sdc_file'):paths.add(Path(n.attrib['name']))
 elif kind=='ip':
  settings=Path(n.attrib['path']);paths.add(settings)
  for c in n:
   if c.tag.split('}')[-1]=='ip_src_file':paths.add(settings.parent/c.attrib['name'])
 elif kind=='param' and n.attrib.get('name')=='include':
  for directory in n.attrib['value'].split(';'):
   for p in Path(directory).rglob('*'):
    if p.is_file() and p.suffix in ('.v','.vh','.sv','.svh'):paths.add(p)
old=json.loads((root/'generated/verification/v3/local-keys-20261026/physical-inputs-after-launch-r2.json').read_text())
for name in old['files']:
 p=Path(name)
 if p.is_relative_to(root/'board/efinix_ti60'):paths.add(p)
roms=list(build.glob('*.bin'));assert len(roms)==4
rom_source=root/'board/efinix_ti60/vendor/sapphire_ddr3/par/ddr_demo_ti60/ip/soc'
for p in roms:
 assert p.read_bytes()==(rom_source/p.name).read_bytes();paths.update((p,rom_source/p.name))
assert (build/'efinix_2d_gpu.peri.xml').read_bytes()==(root/'board/efinix_ti60/efinix_2d_gpu.peri.xml').read_bytes()
selected=json.loads((out/'selected-source-r1.json').read_text())
result=dict(scope='Complete referenced project/IP/ROM and include-tree inputs, with shared controller source guards. Source/RTL hashes are independently selected and verified before this precompile freeze.',project_canonical=canonical(tree.getroot()),files={str(p.resolve()):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(paths)},source_sha256=selected['source_sha256'])
snapshot=out/'physical-inputs-before-compile-r1.json'
if '--freeze' in sys.argv:
 assert not snapshot.exists();snapshot.write_text(json.dumps(result,indent=2));(out/'project-before-compile-r1.xml').write_bytes(project.read_bytes())
else:
 frozen=json.loads(snapshot.read_text())
 def permitted_stamp(expected,actual):
  if expected==actual:return True
  old_attrs=dict(expected[1]);new_attrs=dict(actual[1])
  if old_attrs.get('sw_version')!='2025.2.288.3.8' or new_attrs.get('sw_version')!='2026.1.132':return False
  adjusted=copy.deepcopy(actual)
  adjusted[1]=[[k,old_attrs['sw_version'] if k=='sw_version' else v] for k,v in adjusted[1]]
  return adjusted==expected
 expected_project=frozen['project_canonical'];actual_project=result['project_canonical']
 assert permitted_stamp(expected_project,actual_project),'Project changed beyond the exact known compiler-version stamp'
 # Guard tests: unrelated root and nested settings and unknown versions remain rejected.
 for mutate in ('root','nested','version'):
  bad=copy.deepcopy(actual_project)
  if mutate=='root':bad[1].append(['unexpected_setting','1'])
  elif mutate=='nested':bad[3][0][1].append(['unexpected_setting','1'])
  else:bad[1]=[[k,'9999' if k=='sw_version' else v] for k,v in bad[1]]
  assert not permitted_stamp(expected_project,bad),'Compiler stamp exception accepted unrelated tampering'
 result['project_canonical']=expected_project
 assert frozen==result,'Raw physical inputs changed after precompile freeze'
 if expected_project!=actual_project:
  timing=(build/'outflow/efinix_2d_gpu.timing.rpt').read_text()
  assert 'Version: 2026.1.132' in timing
  audit=dict(scope='Exact compiler root sw_version update; not merely XML formatting. All other canonical project fields and all169 raw inputs remain unchanged.',attribute='sw_version',before='2025.2.288.3.8',after='2026.1.132',raw_inputs_unchanged=len(result['files']),other_canonical_settings_identical=True,negative_tamper_cases=3,before_project_sha256=hashlib.sha256((out/'project-before-compile-r1.xml').read_bytes()).hexdigest(),after_project_sha256=hashlib.sha256(project.read_bytes()).hexdigest())
  audit_path=out/'compiler-stamp-audit-r1.json'
  if audit_path.exists():assert json.loads(audit_path.read_text())==audit
  else:audit_path.write_text(json.dumps(audit,indent=2));(out/'project-after-compile-r1.xml').write_bytes(project.read_bytes())
  print('PASS exact compiler-version stamp audit;169 raw inputs and all other project settings unchanged; three negative tamper cases rejected')
print('PASS precompile-frozen physical inputs:',len(paths)+1,'including canonical project; four source-matching ROMs')
