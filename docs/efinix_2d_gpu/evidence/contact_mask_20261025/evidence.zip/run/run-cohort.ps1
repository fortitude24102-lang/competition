$ErrorActionPreference='Stop'
Set-Location 'D:/ZYNQ/smallproject/.worktrees/pango-riscv-cpu'
$out='generated/verification/v3/contact-mask-20261025'
$oldProbe='generated/verification/v3/late-frame-20261024/probe-fast-shape-r1/gpu_demo.bin'
$oldNormal='generated/verification/v3/late-frame-20261024/normal-shape-r1/gpu_demo.bin'
$normal=$oldNormal
$results=@()
function Read-Probe([string]$name) {
 $raw=Get-Content -LiteralPath "$out/$name-uart.log" -Raw
 if($raw -notmatch '(?m)^V3_PROBE_STOP,result=0\r?$' -or
    $raw -notmatch '(?m)^V3_SEAL_STATE,count=600,sealed=1,words=256,offset=9836,crc=a7bd652f\r?$') {throw "Incomplete workload: $name"}
 $lines=[regex]::Matches($raw,'(?m)^V3_PROBE,target=.*\r?$')
 if($lines.Count -ne 1){throw 'Probe summary count mismatch'}
 $row=[ordered]@{name=$name}
 foreach($field in ($lines[0].Value.Trim() -split ',' | Select-Object -Skip 1)) {
  $pair=$field -split '=';$row[$pair[0]]=[int]$pair[1]
 }
 foreach($pair in @{target=1024;frames=3600;fps_x10=600;under=0;errors=0;visible_min=1006;visible_max=1016;alpha_min=130;alpha_max=131}.GetEnumerator()) {
  if($row[$pair.Key] -ne $pair.Value){throw "Workload/health mismatch $name/$($pair.Key)"}
 }
 [pscustomobject]$row
}
function Capture([string]$name,[string]$bin) {
 & scripts/capture-game-probe.ps1 -Bin $bin -Log "$out/$name-uart.log" -SerialPort COM9 -LogicCopy 1 -SealWords 256 -HudDirect 1 -Seconds 90 *> "$out/$name-capture.log"
 if($LASTEXITCODE -ne 0){throw "Capture failed: $name"}
 $row=Read-Probe $name
 Write-Host ($row|ConvertTo-Json -Compress)
 $row
}
try {
 $results+=Read-Probe 'shape-a1'
 $results+=Capture 'contact-b1' "$out/probe-r1/gpu_demo.bin"
 $results+=Capture 'shape-a2' $oldProbe
 if($results[1].work_mean_us -lt $results[0].work_mean_us) {
  $results+=Capture 'contact-b2' "$out/probe-r1/gpu_demo.bin"
  $control=($results|Where-Object name -Like 'shape-*'|Measure-Object work_mean_us -Average).Average
  $candidate=@($results|Where-Object name -Like 'contact-*')
  if(@($candidate|Where-Object {$_.work_mean_us -ge $control}).Count -eq 0) {$normal="$out/normal-r1/gpu_demo.bin"}
 }
 $results|ConvertTo-Json -Depth 4|Set-Content -LiteralPath "$out/cohort-summary.json" -Encoding utf8
 Write-Host "Selected normal: $normal"
} finally {
 # Restore a normal MENU even if a terminal probe or qualification failed.
 & powershell.exe -NoProfile -ExecutionPolicy Bypass -File scripts/test-game-menu-board.ps1 -Bin $normal -Bit D:/efinity_builds/wide_copy_fair_20261024_r1/outflow/efinix_2d_gpu.bit -SerialPort COM9 -OutDirectory "$out/final-menu" -LevelCount 6 -ExpectedBuild 0x20261015 *> "$out/final-menu.log"
 if($LASTEXITCODE -ne 0){throw 'Final MENU check failed; see raw log'}
 $s=Invoke-RestMethod 'http://127.0.0.1:8765/api/status' -TimeoutSec 5
 if($s.simulated -or $s.owned -or $s.stale -or !(1024 -band $s.telemetry.raw.status_flags)){throw 'Final real released MENU is not fresh'}
 $s|ConvertTo-Json -Depth 8|Set-Content -LiteralPath "$out/final-state.json" -Encoding utf8
 Get-FileHash -LiteralPath $normal|Format-List
 Write-Host 'PASS final real six-tier MENU, control released'
}
