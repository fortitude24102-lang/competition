# Exact contact mask optimization

Baseline: b561162, existing worktree and wide BIT. Continue Ponytail full.
Scope: preserve every texel, collision, graze, step, object and render command.
Inspiration: pygame/pygame bitmask_convolve at 85fda3f719d437cf27106afae8c890e6b88ba5f5;
independent table generator from this project's masks, no imported library/code.
Project F sprite_inline reviewed; scanline-renderer replacement is too broad for this iteration.

1. Characterize 38400 contact/shield/graze cases against original analytic oracle;
   demonstrate missing/stale generated table check fails, then generate 1536-byte table.
2. Extend existing default-off ShapeLut candidate with two row lookups after broad phase.
   Keep scalar fallback and original API. Run oracle in both modes, gameplay and instance suites.
3. Build original/current probes at identical flags; compare source, BIN, stack and workload.
   Re-establish real board and run 3600-frame A/B/A if reachable, then restore best normal MENU.
   Require CRC/visible/Alpha equivalence, zero under/error, and reproducible performance gain.
4. One independent code review, archive exact evidence; preserve all preexisting user edits.

Limits: no claim of fewer late frames or strict 60 without actual board evidence.
Ruling: execute directly as continued optimization already authorized; no design approval pause.

Contact B1/B2 mean11662/11664us, both4late; old shape A1/A2 mean11802us,4/6late.
Independent review clean; complete default/candidate shared-C integration suites pass.
Ruling: one additional measured hotspot only: RV32 step disassembly emits REMU for
240+i%120 on every active object. Characterize every index before/at expiry with
inactive prefixes, then replace with induction240..359. This preserves scalar and
LUT semantics but intentionally changes default-off BIN (earlier exact identity
check applies to the contact-only revision). Keep only if board benefit reproduces.
