param([Parameter(Mandatory=$true)][string]$Bin,
 [Parameter(Mandatory=$true)][string]$Log,
 [Parameter(Mandatory=$true)][string]$StopPattern,
 [int]$Seconds=30,[string]$Port='COM9')
$ErrorActionPreference='Stop'
if(Test-Path -LiteralPath $Log){throw 'Refusing to overwrite capture'}
$diagnosticBin=(Resolve-Path -LiteralPath $Bin).Path.Replace('\','/')
if($diagnosticBin -match '[{};\r\n]'){throw 'Unsafe JTAG path'}
$diagnosticSerial=New-Object IO.Ports.SerialPort $Port,115200,'None',8,'One'
try {
 $diagnosticSerial.Open();$diagnosticSerial.DiscardInBuffer()
 Push-Location D:/efinity_builds/competition_day1_20260906/sapphire/soc/bsp/efinix/EfxSapphireSoc/openocd
 try {
  & D:/efinity/risc_v_gcc/openocd/bin/openocd.exe -f ftdi_ti.cfg -f debug_ti.cfg -c "init; reset halt; load_image {$diagnosticBin} 0x1000 bin; resume 0x1000; shutdown"
  if($LASTEXITCODE -ne 0){throw 'JTAG RAM load failed'}
 } finally {Pop-Location}
 $diagnosticTimer=[Diagnostics.Stopwatch]::StartNew();$diagnosticRaw=''
 while($diagnosticTimer.Elapsed.TotalSeconds -lt $Seconds) {
  $diagnosticChunk=$diagnosticSerial.ReadExisting()
  if($diagnosticChunk) {
   [IO.File]::AppendAllText([IO.Path]::GetFullPath($Log),$diagnosticChunk)
   $diagnosticRaw+=$diagnosticChunk;Write-Output $diagnosticChunk
   if($diagnosticRaw -match 'TRANSFORM_BOARD_FAIL|ALPHA_PIPELINE_BOARD_FAIL|SPRITE_PHASE_FAIL|failed=1|ZOOM_STOP'){throw 'Diagnostic firmware failure'}
   if($diagnosticRaw -match $StopPattern){return}
  }
  Start-Sleep -Milliseconds 20
 }
 throw 'Capture timeout; raw bytes retained'
} finally {
 if($diagnosticSerial.IsOpen){$diagnosticSerial.Close()}
 $diagnosticSerial.Dispose()
}
