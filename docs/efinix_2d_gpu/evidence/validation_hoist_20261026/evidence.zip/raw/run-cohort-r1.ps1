$ErrorActionPreference='Stop'
Set-Location 'D:/ZYNQ/smallproject/.worktrees/pango-riscv-cpu'
$out='generated/verification/v3/validation-hoist-20261026'
$bit='D:/efinity_builds/local_keys_20261026_r2/outflow/efinix_2d_gpu.bit'
$normal='generated/verification/v3/logic-invariant-20261026/normal-fast-r1/gpu_demo.bin'
$hashes=@{baseline='52258c56ccf84797faa106097d9a5de71455e8b9276b60c9cc204ec70a3d6c6e';locals='fea698b3426c75914595d1308ead8284d0dc27ffd0266e6a87a308f5b34a2e48';limits='e92b41ad22408bcca28aca87acbccc8ebbc6527f39f395590f1b0ab0fdfaaf6e'}
foreach($name in $hashes.Keys){if((Get-FileHash "$out/probe-$name-r1/gpu_demo.bin").Hash.ToLowerInvariant() -ne $hashes[$name]){throw 'Probe identity changed'}}
if((Get-FileHash $bit).Hash.ToLowerInvariant() -ne 'a98148a59541161874a5f8685c5338b3742b6e553c4ba2d3718f3d25a7c98436' -or
 (Get-FileHash $normal).Hash.ToLowerInvariant() -ne 'a6489281abd9aaa148e6293a85cde232b71da97ce10799b77947f194ce86513a'){throw 'Hardware/current-normal identity changed'}
if(Test-Path "$out/cohort-summary-r1.json"){throw 'Fresh cohort output required'}
function One([string]$text,[string]$prefix) {
 $records=@($text -split '\r?\n'|Where-Object {$_.StartsWith($prefix+',')})
 if($records.Count -ne 1){throw "Missing/duplicate $prefix"};return $records[0]
}
$state=Invoke-RestMethod http://127.0.0.1:8765/api/status -TimeoutSec 3
if($state.simulated -or $state.owned -or $state.stale -or !(1024 -band $state.telemetry.raw.status_flags)){throw 'Fresh real released MENU required'}
& C:/Users/fortiutde/AppData/Local/Programs/Python/Python39/python.exe generated/verification/v3/local-keys-20261026/check-inputs.py
if($LASTEXITCODE){throw 'Physical inputs changed'}
$rows=@()
try {
 & D:/efinity/pgm/bin/ftdi_pgm.bat $bit -m jtag *> "$out/cohort-bit-load-r1.log"
 if($LASTEXITCODE){throw 'Cohort JTAG BIT failed'}
 Start-Sleep -Seconds 3
 foreach($run in @(@('baseline','a1'),@('locals','b1'),@('limits','c1'),@('baseline','a2'),@('limits','c2'),@('locals','b2'))) {
  $variant=$run[0];$name=$run[1]
  & scripts/capture-game-probe.ps1 -Bin "$out/probe-$variant-r1/gpu_demo.bin" -Log "$out/$name-uart.log" -SerialPort COM9 -LogicCopy 1 -SealWords 256 -HudDirect 1 -Seconds 140 *> "$out/$name-capture.log"
  if($LASTEXITCODE){throw 'Capture failed'}
  $raw=Get-Content "$out/$name-uart.log" -Raw
  if((One $raw 'V3_PROBE_STOP') -ne 'V3_PROBE_STOP,result=0' -or
     (One $raw 'V3_SEAL_STATE') -ne 'V3_SEAL_STATE,count=600,sealed=1,words=256,offset=9836,crc=a7bd652f' -or
     (One $raw 'V3_READY') -ne 'V3_READY,build=20261015,epoch=00030002,network=1,state=02d00000,mode=LIVE,count=1024'){throw 'Altered/incomplete workload'}
  $record=One $raw 'V3_PROBE';$row=[ordered]@{name=$name;variant=$variant}
  foreach($field in $record.Split(',')|Select-Object -Skip 1){$p=$field.Split('=',2);if($p.Count -ne 2 -or $row.Contains($p[0])){throw 'Malformed probe'};$row[$p[0]]=[long]$p[1]}
  foreach($p in @{target=1024;frames=3600;work_miss=0;late_present=0;under=0;errors=0;visible_min=1006;visible_max=1016;alpha_min=130;alpha_max=131}.GetEnumerator()){if(!$row.Contains($p.Key) -or $row[$p.Key] -ne $p.Value){throw "Workload/health mismatch: $($p.Key)"}}
  if($row.work_max_us -ge 16666 -or $row.wall_max_us -ge 16666){throw 'Strict frame maximum failed'}
  $rows+=[pscustomobject]$row;$rows|ConvertTo-Json -Depth 4|Set-Content "$out/cohort-summary-r1.json" -Encoding utf8
  "$name $variant $record"
 }
 $meanA=($rows[0].work_mean_us+$rows[3].work_mean_us)/2.0
 $options=@()
 foreach($variant in 'locals','limits') {
  $samples=@($rows|Where-Object {$_.variant -eq $variant})
  $mean=($samples[0].work_mean_us+$samples[1].work_mean_us)/2.0
  $options+=[pscustomobject]@{variant=$variant;mean_us=$mean;reduction_percent=100.0*($meanA-$mean)/$meanA;repeatable=($samples[0].work_mean_us -lt $rows[0].work_mean_us -and $samples[1].work_mean_us -lt $rows[3].work_mean_us)}
 }
 $best=@($options|Where-Object {$_.repeatable}|Sort-Object mean_us|Select-Object -First 1)
 [ordered]@{control_mean_us=$meanA;options=$options;measured_best=if($best.Count){$best[0].variant}else{'baseline'};frames=21600;adopted=$false;scope='Measurement only; best candidate must pass complete integration and normal-menu qualification before adoption'}|ConvertTo-Json -Depth 5|Set-Content "$out/comparison-r1.json" -Encoding utf8
 'PASS six ordinary3600 cohorts; no adoption before full selected-candidate checks'
} catch {$_|Out-String|Set-Content "$out/cohort-failure-r1.txt" -Encoding utf8;throw}
finally {
 & scripts/test-game-menu-board.ps1 -Bin $normal -SerialPort COM9 -ExpectedBuild 0x20261015 -LevelCount 6 -Python C:/Users/fortiutde/AppData/Local/Programs/Python/Python39/python.exe -OutDirectory "$out/cohort-final-menu-r1" *> "$out/cohort-final-menu-r1.log"
 $state=Invoke-RestMethod http://127.0.0.1:8765/api/status -TimeoutSec 3
 if($state.simulated -or $state.stale -or $state.owned -or !(1024 -band $state.telemetry.raw.status_flags)){throw 'Interim current-normal MENU not fresh/released'}
 $state|ConvertTo-Json -Depth 8|Set-Content "$out/cohort-final-state-r1.json" -Encoding utf8
 'PASS prior accepted normal restored and released; no debugger reads afterward'
}
