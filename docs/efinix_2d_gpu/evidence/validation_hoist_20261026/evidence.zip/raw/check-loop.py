from pathlib import Path
import json,re,subprocess,sys
path=Path(sys.argv[1])
text=subprocess.check_output(['D:/efinity/risc_v_gcc/toolchain/bin/riscv-none-elf-objdump.exe','-d','--disassemble=step',str(path)],text=True)
instructions=[];active=False
for line in text.splitlines():
 m=re.match(r'\s*([0-9a-f]+):\s+[0-9a-f]{8}\s+(\S+)\s*(.*)',line)
 if not m:continue
 address,op,args=m.groups()
 if not active and op=='lbu' and re.search(r'\b14\(',args):active=True
 if active:
  instructions.append(line)
  if op=='bne':break
assert instructions and 'bne' in instructions[-1]
path.with_suffix('.validation-loop.txt').write_text('\n'.join(instructions)+'\n')
print(json.dumps(dict(object=str(path),interactive_loop_instructions=len(instructions),maximum=9)))
assert len(instructions)<=9,'Repeated invariant work remains inside object-validation loop'
