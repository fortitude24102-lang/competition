from pathlib import Path
import subprocess
out=Path('generated/verification/v3/validation-hoist-20261026')
source=(out/'baseline-bullet_demo.c').read_text()
old=''' for(unsigned i=0;i<s->count;i++) if(s->objects[i].kind>(manual?3:2) ||
  s->objects[i].shape>=BULLET_SHAPE_COUNT || (s->interactive && s->objects[i].path>=BULLET_PATH_COUNT)) return GPU_DRIVER_ARGUMENT;'''
assert old in source
variants={'baseline':old,
 'locals':''' unsigned max_kind=manual?3u:2u;int check_path=s->interactive;
 for(unsigned i=0;i<s->count;i++) if(s->objects[i].kind>max_kind ||
  s->objects[i].shape>=BULLET_SHAPE_COUNT || (check_path && s->objects[i].path>=BULLET_PATH_COUNT)) return GPU_DRIVER_ARGUMENT;''',
 'limits':''' unsigned max_kind=manual?3u:2u,max_path=s->interactive?BULLET_PATH_COUNT:256u;
 for(unsigned i=0;i<s->count;i++) if(s->objects[i].kind>max_kind ||
  s->objects[i].shape>=BULLET_SHAPE_COUNT || s->objects[i].path>=max_path) return GPU_DRIVER_ARGUMENT;'''}
for name,replacement in variants.items():
 path=out/(name+'.c');path.write_text(source.replace(old,replacement))
 obj=path.with_suffix('.o')
 subprocess.run(['D:/efinity/risc_v_gcc/toolchain/bin/riscv-none-elf-gcc.exe','-std=gnu11','-Os','-Wall','-Wextra','-Werror','-march=rv32im_zicsr','-mabi=ilp32','-ffreestanding','-ffunction-sections','-fdata-sections','-DBULLET_OBJECT_CAPACITY=1024','-DV3_SHAPE_LUT=1','-Isw/efinix_gpu/include','-c',str(path),'-o',str(obj)],check=True)
 assembly=subprocess.check_output(['D:/efinity/risc_v_gcc/toolchain/bin/riscv-none-elf-objdump.exe','-dr','--disassemble=step',str(obj)],text=True)
 path.with_suffix('.asm').write_text(assembly)
 print(name, 'compiled, inspect validation loop in',path.with_suffix('.asm'))
