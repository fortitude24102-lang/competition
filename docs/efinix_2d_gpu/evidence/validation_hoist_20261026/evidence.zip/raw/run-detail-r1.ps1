$ErrorActionPreference='Stop'
Set-Location 'D:/ZYNQ/smallproject/.worktrees/pango-riscv-cpu'
$out='generated/verification/v3/validation-hoist-20261026'
$normal='generated/verification/v3/logic-invariant-20261026/normal-fast-r1/gpu_demo.bin'
if((Get-FileHash $normal).Hash.ToLowerInvariant() -ne 'a6489281abd9aaa148e6293a85cde232b71da97ce10799b77947f194ce86513a'){throw 'Current normal identity mismatch'}
try {
 & scripts/capture-game-probe.ps1 -Bin "$out/detail-baseline-r1/gpu_demo.bin" -Log "$out/detail-baseline-uart-r1.log" -SerialPort COM9 -LogicCopy 1 -SealWords 256 -HudDirect 1 -Seconds 140 *> "$out/detail-capture-r1.log"
 if($LASTEXITCODE){throw 'Diagnostic capture failed'}
 & C:/Users/fortiutde/AppData/Local/Programs/Python/Python39/python.exe tools/analyze_v3_detail_counters.py "$out/detail-baseline-uart-r1.log" > "$out/detail-counters-r1.json"
 if($LASTEXITCODE){throw 'Diagnostic counter analysis failed'}
 Select-String -LiteralPath "$out/detail-baseline-uart-r1.log" -Pattern '^V3_WORST,|^V3_PROBE,' | ForEach-Object {$_.Line}
} finally {
 & scripts/test-game-menu-board.ps1 -Bin $normal -SerialPort COM9 -ExpectedBuild 0x20261015 -LevelCount 6 -Python C:/Users/fortiutde/AppData/Local/Programs/Python/Python39/python.exe -OutDirectory "$out/detail-final-menu-r1" *> "$out/detail-final-menu-r1.log"
 'PASS diagnostic ended and current accepted normal restored; no JTAG reads afterward'
}
