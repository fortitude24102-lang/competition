
generated\verification\v3\validation-hoist-20261026\locals.o:     file format elf32-littleriscv


Disassembly of section .text.append:

Disassembly of section .text.pixel_coordinate:

Disassembly of section .text.bullet_campaign_valid:

Disassembly of section .text.bullet_enemy_position:

Disassembly of section .text.spawn:

Disassembly of section .text.bullet_reset:

Disassembly of section .text.bullet_reset_player:

Disassembly of section .text.step:

00000000 <step>:
   0:	f9010113          	addi	sp,sp,-112
   4:	05612823          	sw	s6,80(sp)
   8:	06112623          	sw	ra,108(sp)
   c:	06812423          	sw	s0,104(sp)
  10:	06912223          	sw	s1,100(sp)
  14:	07212023          	sw	s2,96(sp)
  18:	05312e23          	sw	s3,92(sp)
  1c:	05412c23          	sw	s4,88(sp)
  20:	05512a23          	sw	s5,84(sp)
  24:	05712623          	sw	s7,76(sp)
  28:	05812423          	sw	s8,72(sp)
  2c:	05912223          	sw	s9,68(sp)
  30:	05a12023          	sw	s10,64(sp)
  34:	03b12e23          	sw	s11,60(sp)
  38:	00e12623          	sw	a4,12(sp)
  3c:	00058b13          	mv	s6,a1
  40:	76050263          	beqz	a0,7a4 <.L161>
			40: R_RISCV_BRANCH	.L161
  44:	00005437          	lui	s0,0x5
  48:	00850433          	add	s0,a0,s0
  4c:	00842a03          	lw	s4,8(s0) # 5008 <.L161+0x4864>
  50:	00068993          	mv	s3,a3
  54:	3ff00713          	li	a4,1023
  58:	fffa0693          	addi	a3,s4,-1
  5c:	00050493          	mv	s1,a0
  60:	ff800793          	li	a5,-8
  64:	1ad76463          	bltu	a4,a3,20c <.L101>
			64: R_RISCV_BRANCH	.L101
  68:	02444b83          	lbu	s7,36(s0)
  6c:	00300713          	li	a4,3
  70:	19776e63          	bltu	a4,s7,20c <.L101>
			70: R_RISCV_BRANCH	.L101
  74:	00060913          	mv	s2,a2
  78:	00000097          	auipc	ra,0x0
			78: R_RISCV_CALL_PLT	bullet_campaign_valid
			78: R_RISCV_RELAX	*ABS*
  7c:	000080e7          	jalr	ra # 78 <step+0x78>
  80:	ff800793          	li	a5,-8
  84:	18050463          	beqz	a0,20c <.L101>
			84: R_RISCV_BRANCH	.L101
  88:	02045703          	lhu	a4,32(s0)
  8c:	03c00693          	li	a3,60
  90:	16e6ee63          	bltu	a3,a4,20c <.L101>
			90: R_RISCV_BRANCH	.L101
  94:	00c12583          	lw	a1,12(sp)
  98:	000b9e63          	bnez	s7,b4 <.L103>
			98: R_RISCV_BRANCH	.L103
  9c:	02245683          	lhu	a3,34(s0)
  a0:	07700613          	li	a2,119
  a4:	fff68693          	addi	a3,a3,-1
  a8:	01069693          	slli	a3,a3,0x10
  ac:	0106d693          	srli	a3,a3,0x10
  b0:	14d66e63          	bltu	a2,a3,20c <.L101>
			b0: R_RISCV_BRANCH	.L101

000000b4 <.L103>:
  b4:	120b0863          	beqz	s6,1e4 <.L156>
			b4: R_RISCV_BRANCH	.L156
  b8:	ff890693          	addi	a3,s2,-8
  bc:	3b000613          	li	a2,944
  c0:	ff800793          	li	a5,-8
  c4:	14d66463          	bltu	a2,a3,20c <.L101>
			c4: R_RISCV_BRANCH	.L101
  c8:	fb098693          	addi	a3,s3,-80
  cc:	1c400613          	li	a2,452
  d0:	12d66e63          	bltu	a2,a3,20c <.L101>
			d0: R_RISCV_BRANCH	.L101
  d4:	00300613          	li	a2,3

000000d8 <.L104>:
  d8:	01400693          	li	a3,20
  dc:	02da06b3          	mul	a3,s4,a3
  e0:	000057b7          	lui	a5,0x5
  e4:	00f487b3          	add	a5,s1,a5
  e8:	0287cc83          	lbu	s9,40(a5) # 5028 <.L161+0x4884>
  ec:	00048413          	mv	s0,s1
  f0:	00048793          	mv	a5,s1
  f4:	00500513          	li	a0,5
  f8:	009686b3          	add	a3,a3,s1

000000fc <.L106>:
  fc:	00e7c883          	lbu	a7,14(a5)
 100:	6b166263          	bltu	a2,a7,7a4 <.L161>
			100: R_RISCV_BRANCH	.L161
 104:	00f7c883          	lbu	a7,15(a5)
 108:	69156e63          	bltu	a0,a7,7a4 <.L161>
			108: R_RISCV_BRANCH	.L161
 10c:	000c8663          	beqz	s9,118 <.L105>
			10c: R_RISCV_BRANCH	.L105
 110:	0117c883          	lbu	a7,17(a5)
 114:	69156863          	bltu	a0,a7,7a4 <.L161>
			114: R_RISCV_BRANCH	.L161

00000118 <.L105>:
 118:	01478793          	addi	a5,a5,20
 11c:	fef690e3          	bne	a3,a5,fc <.L106>
			11c: R_RISCV_BRANCH	.L106
 120:	000057b7          	lui	a5,0x5
 124:	00f487b3          	add	a5,s1,a5
 128:	0047aa83          	lw	s5,4(a5) # 5004 <.L161+0x4860>
 12c:	001a8a93          	addi	s5,s5,1
 130:	0157a223          	sw	s5,4(a5)
 134:	000b0663          	beqz	s6,140 <.L107>
			134: R_RISCV_BRANCH	.L107
 138:	0297c783          	lbu	a5,41(a5)
 13c:	0a079063          	bnez	a5,1dc <.L108>
			13c: R_RISCV_BRANCH	.L108

00000140 <.L107>:
 140:	120b9063          	bnez	s7,260 <.L109>
			140: R_RISCV_BRANCH	.L109
 144:	000057b7          	lui	a5,0x5
 148:	00f48733          	add	a4,s1,a5
 14c:	02275683          	lhu	a3,34(a4)
 150:	fff68693          	addi	a3,a3,-1
 154:	01069693          	slli	a3,a3,0x10
 158:	0106d693          	srli	a3,a3,0x10
 15c:	02d71123          	sh	a3,34(a4)
 160:	06069e63          	bnez	a3,1dc <.L108>
			160: R_RISCV_BRANCH	.L108
 164:	00072603          	lw	a2,0(a4)
 168:	0e0b0263          	beqz	s6,24c <.L111>
			168: R_RISCV_BRANCH	.L111
 16c:	0e0c8063          	beqz	s9,24c <.L111>
			16c: R_RISCV_BRANCH	.L111
 170:	06058e63          	beqz	a1,1ec <.L112>
			170: R_RISCV_BRANCH	.L112
 174:	06b48c63          	beq	s1,a1,1ec <.L112>
			174: R_RISCV_BRANCH	.L112
 178:	00f587b3          	add	a5,a1,a5
 17c:	0287c703          	lbu	a4,40(a5) # 5028 <.L161+0x4884>
 180:	06070663          	beqz	a4,1ec <.L112>
			180: R_RISCV_BRANCH	.L112
 184:	0087a703          	lw	a4,8(a5)
 188:	06ea1263          	bne	s4,a4,1ec <.L112>
			188: R_RISCV_BRANCH	.L112
 18c:	0007a703          	lw	a4,0(a5)
 190:	04c71e63          	bne	a4,a2,1ec <.L112>
			190: R_RISCV_BRANCH	.L112
 194:	0047a783          	lw	a5,4(a5)
 198:	04079a63          	bnez	a5,1ec <.L112>
			198: R_RISCV_BRANCH	.L112
 19c:	00005437          	lui	s0,0x5
 1a0:	008587b3          	add	a5,a1,s0
 1a4:	0147a703          	lw	a4,20(a5)
 1a8:	04071263          	bnez	a4,1ec <.L112>
			1a8: R_RISCV_BRANCH	.L112
 1ac:	0247c683          	lbu	a3,36(a5)
 1b0:	00300713          	li	a4,3
 1b4:	02e69c63          	bne	a3,a4,1ec <.L112>
			1b4: R_RISCV_BRANCH	.L112
 1b8:	0297c783          	lbu	a5,41(a5)
 1bc:	02079863          	bnez	a5,1ec <.L112>
			1bc: R_RISCV_BRANCH	.L112
 1c0:	00005637          	lui	a2,0x5
 1c4:	02c60613          	addi	a2,a2,44 # 502c <.L161+0x4888>
 1c8:	00048513          	mv	a0,s1
 1cc:	00848433          	add	s0,s1,s0
 1d0:	00000097          	auipc	ra,0x0
			1d0: R_RISCV_CALL_PLT	memcpy
			1d0: R_RISCV_RELAX	*ABS*
 1d4:	000080e7          	jalr	ra # 1d0 <.L107+0x90>
 1d8:	01542223          	sw	s5,4(s0) # 5004 <.L161+0x4860>

000001dc <.L108>:
 1dc:	00000793          	li	a5,0
 1e0:	02c0006f          	j	20c <.L101>
			1e0: R_RISCV_JAL	.L101

000001e4 <.L156>:
 1e4:	00200613          	li	a2,2
 1e8:	ef1ff06f          	j	d8 <.L104>
			1e8: R_RISCV_JAL	.L104

000001ec <.L112>:
 1ec:	000a0593          	mv	a1,s4
 1f0:	00048513          	mv	a0,s1
 1f4:	00000097          	auipc	ra,0x0
			1f4: R_RISCV_CALL_PLT	bullet_reset_player
			1f4: R_RISCV_RELAX	*ABS*
 1f8:	000080e7          	jalr	ra # 1f4 <.L112+0x8>

000001fc <.L212>:
 1fc:	00005737          	lui	a4,0x5
 200:	00e48733          	add	a4,s1,a4
 204:	00050793          	mv	a5,a0
 208:	01572223          	sw	s5,4(a4) # 5004 <.L161+0x4860>

0000020c <.L101>:
 20c:	06c12083          	lw	ra,108(sp)
 210:	06812403          	lw	s0,104(sp)
 214:	06412483          	lw	s1,100(sp)
 218:	06012903          	lw	s2,96(sp)
 21c:	05c12983          	lw	s3,92(sp)
 220:	05812a03          	lw	s4,88(sp)
 224:	05412a83          	lw	s5,84(sp)
 228:	05012b03          	lw	s6,80(sp)
 22c:	04c12b83          	lw	s7,76(sp)
 230:	04812c03          	lw	s8,72(sp)
 234:	04412c83          	lw	s9,68(sp)
 238:	04012d03          	lw	s10,64(sp)
 23c:	03c12d83          	lw	s11,60(sp)
 240:	00078513          	mv	a0,a5
 244:	07010113          	addi	sp,sp,112
 248:	00008067          	ret

0000024c <.L111>:
 24c:	000a0593          	mv	a1,s4
 250:	00048513          	mv	a0,s1
 254:	00000097          	auipc	ra,0x0
			254: R_RISCV_CALL_PLT	bullet_reset
			254: R_RISCV_RELAX	*ABS*
 258:	000080e7          	jalr	ra # 254 <.L111+0x8>
 25c:	fa1ff06f          	j	1fc <.L212>
			25c: R_RISCV_JAL	.L212

00000260 <.L109>:
 260:	000056b7          	lui	a3,0x5
 264:	00d486b3          	add	a3,s1,a3
 268:	0146a783          	lw	a5,20(a3) # 5014 <.L161+0x4870>
 26c:	00178793          	addi	a5,a5,1
 270:	00f6aa23          	sw	a5,20(a3)
 274:	020b1863          	bnez	s6,2a4 <.L114>
			274: R_RISCV_BRANCH	.L114
 278:	0f000913          	li	s2,240
 27c:	0327f933          	remu	s2,a5,s2
 280:	03b00693          	li	a3,59
 284:	1326fc63          	bgeu	a3,s2,3bc <.L115>
			284: R_RISCV_BRANCH	.L115
 288:	0b300693          	li	a3,179
 28c:	1326e063          	bltu	a3,s2,3ac <.L116>
			28c: R_RISCV_BRANCH	.L116
 290:	07800693          	li	a3,120
 294:	412686b3          	sub	a3,a3,s2
 298:	00300613          	li	a2,3
 29c:	02c686b3          	mul	a3,a3,a2
 2a0:	1e068913          	addi	s2,a3,480

000002a4 <.L114>:
 2a4:	000056b7          	lui	a3,0x5
 2a8:	00d486b3          	add	a3,s1,a3
 2ac:	0126a623          	sw	s2,12(a3) # 500c <.L161+0x4868>
 2b0:	000b1463          	bnez	s6,2b8 <.L117>
			2b0: R_RISCV_BRANCH	.L117
 2b4:	1e000993          	li	s3,480

000002b8 <.L117>:
 2b8:	000056b7          	lui	a3,0x5
 2bc:	00d486b3          	add	a3,s1,a3
 2c0:	0136a823          	sw	s3,16(a3) # 5010 <.L161+0x486c>
 2c4:	00e03c33          	snez	s8,a4
 2c8:	00070663          	beqz	a4,2d4 <.L118>
			2c8: R_RISCV_BRANCH	.L118
 2cc:	fff70713          	addi	a4,a4,-1
 2d0:	02e69023          	sh	a4,32(a3)

000002d4 <.L118>:
 2d4:	01e00713          	li	a4,30
 2d8:	02e7f7b3          	remu	a5,a5,a4
 2dc:	02079463          	bnez	a5,304 <.L119>
			2dc: R_RISCV_BRANCH	.L119
 2e0:	000057b7          	lui	a5,0x5
 2e4:	00f487b3          	add	a5,s1,a5
 2e8:	0187a783          	lw	a5,24(a5) # 5018 <.L161+0x4874>
 2ec:	fff00713          	li	a4,-1
 2f0:	00e78463          	beq	a5,a4,2f8 <.L120>
			2f0: R_RISCV_BRANCH	.L120
 2f4:	00178793          	addi	a5,a5,1

000002f8 <.L120>:
 2f8:	00005737          	lui	a4,0x5
 2fc:	00e48733          	add	a4,s1,a4
 300:	00f72c23          	sw	a5,24(a4) # 5018 <.L161+0x4874>

00000304 <.L119>:
 304:	fed90793          	addi	a5,s2,-19
 308:	0003cb37          	lui	s6,0x3c
 30c:	0001ebb7          	lui	s7,0x1e
 310:	00f12623          	sw	a5,12(sp)
 314:	00010ab7          	lui	s5,0x10
 318:	00c90793          	addi	a5,s2,12
 31c:	0f000d13          	li	s10,240
 320:	00000d93          	li	s11,0
 324:	7feb0b13          	addi	s6,s6,2046 # 3c7fe <.L161+0x3c05a>
 328:	bffb8b93          	addi	s7,s7,-1025 # 1dbff <.L161+0x1d45b>
 32c:	00f12823          	sw	a5,16(sp)
 330:	fffa8a93          	addi	s5,s5,-1 # ffff <.L161+0xf85b>

00000334 <.L149>:
 334:	00e44683          	lbu	a3,14(s0)
 338:	00300793          	li	a5,3
 33c:	1cf69463          	bne	a3,a5,504 <.L121>
			33c: R_RISCV_BRANCH	.L121
 340:	00c45683          	lhu	a3,12(s0)
 344:	05568663          	beq	a3,s5,390 <.L125>
			344: R_RISCV_BRANCH	.L125
 348:	00042783          	lw	a5,0(s0)
 34c:	00841303          	lh	t1,8(s0)
 350:	00442603          	lw	a2,4(s0)
 354:	00f30333          	add	t1,t1,a5
 358:	00a41783          	lh	a5,10(s0)
 35c:	00642023          	sw	t1,0(s0)
 360:	40835313          	srai	t1,t1,0x8
 364:	00c787b3          	add	a5,a5,a2
 368:	00f42223          	sw	a5,4(s0)
 36c:	00430313          	addi	t1,t1,4
 370:	3bf00613          	li	a2,959
 374:	00666a63          	bltu	a2,t1,388 <.L123>
			374: R_RISCV_BRANCH	.L123
 378:	4087d793          	srai	a5,a5,0x8
 37c:	fbc78593          	addi	a1,a5,-68
 380:	1d300613          	li	a2,467
 384:	04b67463          	bgeu	a2,a1,3cc <.L124>
			384: R_RISCV_BRANCH	.L124

00000388 <.L123>:
 388:	fff00793          	li	a5,-1
 38c:	00f41623          	sh	a5,12(s0)

00000390 <.L125>:
 390:	16700793          	li	a5,359
 394:	001d8d93          	addi	s11,s11,1
 398:	40fd0263          	beq	s10,a5,79c <.L164>
			398: R_RISCV_BRANCH	.L164
 39c:	001d0d13          	addi	s10,s10,1

000003a0 <.L148>:
 3a0:	01440413          	addi	s0,s0,20
 3a4:	f9ba18e3          	bne	s4,s11,334 <.L149>
			3a4: R_RISCV_BRANCH	.L149
 3a8:	e35ff06f          	j	1dc <.L108>
			3a8: R_RISCV_JAL	.L108

000003ac <.L116>:
 3ac:	00300693          	li	a3,3
 3b0:	02d90933          	mul	s2,s2,a3
 3b4:	f1090913          	addi	s2,s2,-240
 3b8:	eedff06f          	j	2a4 <.L114>
			3b8: R_RISCV_JAL	.L114

000003bc <.L115>:
 3bc:	00300693          	li	a3,3
 3c0:	02d90933          	mul	s2,s2,a3
 3c4:	1e090913          	addi	s2,s2,480
 3c8:	eddff06f          	j	2a4 <.L114>
			3c8: R_RISCV_JAL	.L114

000003cc <.L124>:
 3cc:	00168693          	addi	a3,a3,1
 3d0:	00d41623          	sh	a3,12(s0)
 3d4:	00478893          	addi	a7,a5,4
 3d8:	00000593          	li	a1,0
 3dc:	00300e13          	li	t3,3

000003e0 <.L127>:
 3e0:	020c8c63          	beqz	s9,418 <.L126>
			3e0: R_RISCV_BRANCH	.L126
 3e4:	000057b7          	lui	a5,0x5
 3e8:	02578793          	addi	a5,a5,37 # 5025 <.L161+0x4881>
 3ec:	00f587b3          	add	a5,a1,a5
 3f0:	00f487b3          	add	a5,s1,a5
 3f4:	0007c783          	lbu	a5,0(a5)
 3f8:	02079063          	bnez	a5,418 <.L126>
			3f8: R_RISCV_BRANCH	.L126

000003fc <.L129>:
 3fc:	00158593          	addi	a1,a1,1
 400:	ffc590e3          	bne	a1,t3,3e0 <.L127>
			400: R_RISCV_BRANCH	.L127

00000404 <.L128>:
 404:	000057b7          	lui	a5,0x5
 408:	00f487b3          	add	a5,s1,a5
 40c:	0297c783          	lbu	a5,41(a5) # 5029 <.L161+0x4885>
 410:	dc0796e3          	bnez	a5,1dc <.L108>
			410: R_RISCV_BRANCH	.L108
 414:	f7dff06f          	j	390 <.L125>
			414: R_RISCV_JAL	.L125

00000418 <.L126>:
 418:	02c10693          	addi	a3,sp,44
 41c:	02810613          	addi	a2,sp,40
 420:	00048513          	mv	a0,s1
 424:	01112e23          	sw	a7,28(sp)
 428:	00612c23          	sw	t1,24(sp)
 42c:	00b12a23          	sw	a1,20(sp)
 430:	00000097          	auipc	ra,0x0
			430: R_RISCV_CALL_PLT	bullet_enemy_position
			430: R_RISCV_RELAX	*ABS*
 434:	000080e7          	jalr	ra # 430 <.L126+0x18>
 438:	02812683          	lw	a3,40(sp)
 43c:	01812303          	lw	t1,24(sp)
 440:	01400613          	li	a2,20
 444:	02c12783          	lw	a5,44(sp)
 448:	40d306b3          	sub	a3,t1,a3
 44c:	00a68693          	addi	a3,a3,10
 450:	01412583          	lw	a1,20(sp)
 454:	01c12883          	lw	a7,28(sp)
 458:	00300e13          	li	t3,3
 45c:	fad660e3          	bltu	a2,a3,3fc <.L129>
			45c: R_RISCV_BRANCH	.L129
 460:	40f887b3          	sub	a5,a7,a5
 464:	00a78793          	addi	a5,a5,10
 468:	f8f66ae3          	bltu	a2,a5,3fc <.L129>
			468: R_RISCV_BRANCH	.L129
 46c:	fff00793          	li	a5,-1
 470:	00f41623          	sh	a5,12(s0)
 474:	000057b7          	lui	a5,0x5
 478:	00f487b3          	add	a5,s1,a5
 47c:	0187a783          	lw	a5,24(a5) # 5018 <.L161+0x4874>
 480:	fe600693          	li	a3,-26
 484:	00f6f463          	bgeu	a3,a5,48c <.L130>
			484: R_RISCV_BRANCH	.L130
 488:	fe600793          	li	a5,-26

0000048c <.L130>:
 48c:	000056b7          	lui	a3,0x5
 490:	01978793          	addi	a5,a5,25
 494:	00d48533          	add	a0,s1,a3
 498:	00f52c23          	sw	a5,24(a0)
 49c:	f60c84e3          	beqz	s9,404 <.L128>
			49c: R_RISCV_BRANCH	.L128
 4a0:	00b485b3          	add	a1,s1,a1
 4a4:	00b68633          	add	a2,a3,a1
 4a8:	02564683          	lbu	a3,37(a2)
 4ac:	fff68693          	addi	a3,a3,-1 # 4fff <.L161+0x485b>
 4b0:	0ff6f693          	zext.b	a3,a3
 4b4:	02d602a3          	sb	a3,37(a2)
 4b8:	f40696e3          	bnez	a3,404 <.L128>
			4b8: R_RISCV_BRANCH	.L128
 4bc:	f3700693          	li	a3,-201
 4c0:	00f6f463          	bgeu	a3,a5,4c8 <.L132>
			4c0: R_RISCV_BRANCH	.L132
 4c4:	f3700793          	li	a5,-201

000004c8 <.L132>:
 4c8:	0c878793          	addi	a5,a5,200
 4cc:	000056b7          	lui	a3,0x5
 4d0:	00f52c23          	sw	a5,24(a0)
 4d4:	00d486b3          	add	a3,s1,a3
 4d8:	0246a603          	lw	a2,36(a3) # 5024 <.L161+0x4880>
 4dc:	00000793          	li	a5,0
 4e0:	00861593          	slli	a1,a2,0x8
 4e4:	0105d593          	srli	a1,a1,0x10
 4e8:	00059663          	bnez	a1,4f4 <.L133>
			4e8: R_RISCV_BRANCH	.L133
 4ec:	0276c783          	lbu	a5,39(a3)
 4f0:	0017b793          	seqz	a5,a5

000004f4 <.L133>:
 4f4:	000056b7          	lui	a3,0x5
 4f8:	00d486b3          	add	a3,s1,a3
 4fc:	02f684a3          	sb	a5,41(a3) # 5029 <.L161+0x4885>
 500:	f05ff06f          	j	404 <.L128>
			500: R_RISCV_JAL	.L128

00000504 <.L121>:
 504:	000c8663          	beqz	s9,510 <.L135>
			504: R_RISCV_BRANCH	.L135
 508:	00c45783          	lhu	a5,12(s0)
 50c:	e95782e3          	beq	a5,s5,390 <.L125>
			50c: R_RISCV_BRANCH	.L125

00000510 <.L135>:
 510:	00042583          	lw	a1,0(s0)
 514:	7ff58793          	addi	a5,a1,2047
 518:	00fb6e63          	bltu	s6,a5,534 <.L136>
			518: R_RISCV_BRANCH	.L136
 51c:	00442603          	lw	a2,4(s0)
 520:	ffffc7b7          	lui	a5,0xffffc
 524:	00f607b3          	add	a5,a2,a5
 528:	00fbe663          	bltu	s7,a5,534 <.L136>
			528: R_RISCV_BRANCH	.L136
 52c:	00c45683          	lhu	a3,12(s0)
 530:	01a6ee63          	bltu	a3,s10,54c <.L137>
			530: R_RISCV_BRANCH	.L137

00000534 <.L136>:
 534:	00000613          	li	a2,0
 538:	000d8593          	mv	a1,s11
 53c:	00048513          	mv	a0,s1
 540:	00000097          	auipc	ra,0x0
			540: R_RISCV_CALL_PLT	spawn
			540: R_RISCV_RELAX	*ABS*
 544:	000080e7          	jalr	ra # 540 <.L136+0xc>
 548:	e49ff06f          	j	390 <.L125>
			548: R_RISCV_JAL	.L125

0000054c <.L137>:
 54c:	060c8663          	beqz	s9,5b8 <.L138>
			54c: R_RISCV_BRANCH	.L138
 550:	01144783          	lbu	a5,17(s0)
 554:	00300513          	li	a0,3
 558:	16a78063          	beq	a5,a0,6b8 <.L139>
			558: R_RISCV_BRANCH	.L139
 55c:	00400513          	li	a0,4
 560:	1aa78063          	beq	a5,a0,700 <.L140>
			560: R_RISCV_BRANCH	.L140
 564:	00200513          	li	a0,2
 568:	04a79863          	bne	a5,a0,5b8 <.L138>
			568: R_RISCV_BRANCH	.L138
 56c:	000007b7          	lui	a5,0x0
			56c: R_RISCV_HI20	directions
			56c: R_RISCV_RELAX	*ABS*
 570:	03c6f513          	andi	a0,a3,60
 574:	00078793          	mv	a5,a5
			574: R_RISCV_LO12_I	directions
			574: R_RISCV_RELAX	*ABS*
 578:	00a787b3          	add	a5,a5,a0
 57c:	00079883          	lh	a7,0(a5) # 0 <step>
 580:	0cd00793          	li	a5,205
 584:	02fd87b3          	mul	a5,s11,a5
 588:	00500513          	li	a0,5
 58c:	00a7d793          	srli	a5,a5,0xa
 590:	02a787b3          	mul	a5,a5,a0
 594:	06000513          	li	a0,96
 598:	40fd87b3          	sub	a5,s11,a5
 59c:	ffe78793          	addi	a5,a5,-2
 5a0:	02a787b3          	mul	a5,a5,a0
 5a4:	01f8d513          	srli	a0,a7,0x1f
 5a8:	01150533          	add	a0,a0,a7
 5ac:	40155513          	srai	a0,a0,0x1
 5b0:	00a787b3          	add	a5,a5,a0
 5b4:	00f41423          	sh	a5,8(s0)

000005b8 <.L138>:
 5b8:	00841503          	lh	a0,8(s0)
 5bc:	00a41783          	lh	a5,10(s0)
 5c0:	00168693          	addi	a3,a3,1
 5c4:	00b505b3          	add	a1,a0,a1
 5c8:	00c787b3          	add	a5,a5,a2
 5cc:	00b42023          	sw	a1,0(s0)
 5d0:	00f42223          	sw	a5,4(s0)
 5d4:	00d41623          	sh	a3,12(s0)
 5d8:	020c8063          	beqz	s9,5f8 <.L141>
			5d8: R_RISCV_BRANCH	.L141
 5dc:	01144603          	lbu	a2,17(s0)
 5e0:	00500693          	li	a3,5
 5e4:	00d61a63          	bne	a2,a3,5f8 <.L141>
			5e4: R_RISCV_BRANCH	.L141
 5e8:	1205da63          	bgez	a1,71c <.L142>
			5e8: R_RISCV_BRANCH	.L142
 5ec:	00042023          	sw	zero,0(s0)

000005f0 <.L214>:
 5f0:	40a00533          	neg	a0,a0
 5f4:	00a41423          	sh	a0,8(s0)

000005f8 <.L141>:
 5f8:	00042683          	lw	a3,0(s0)
 5fc:	00c12703          	lw	a4,12(sp)
 600:	4086d693          	srai	a3,a3,0x8
 604:	d8e6c6e3          	blt	a3,a4,390 <.L125>
			604: R_RISCV_BRANCH	.L125
 608:	01012703          	lw	a4,16(sp)
 60c:	d8d742e3          	blt	a4,a3,390 <.L125>
			60c: R_RISCV_BRANCH	.L125
 610:	4087d793          	srai	a5,a5,0x8
 614:	fed98613          	addi	a2,s3,-19
 618:	d6c7cce3          	blt	a5,a2,390 <.L125>
			618: R_RISCV_BRANCH	.L125
 61c:	00c98613          	addi	a2,s3,12
 620:	d6f648e3          	blt	a2,a5,390 <.L125>
			620: R_RISCV_BRANCH	.L125
 624:	412686b3          	sub	a3,a3,s2
 628:	01368613          	addi	a2,a3,19
 62c:	00f44683          	lbu	a3,15(s0)
 630:	413787b3          	sub	a5,a5,s3
 634:	01378793          	addi	a5,a5,19
 638:	00669693          	slli	a3,a3,0x6
 63c:	00f687b3          	add	a5,a3,a5
 640:	02078693          	addi	a3,a5,32
 644:	000005b7          	lui	a1,0x0
			644: R_RISCV_HI20	bullet_contact_masks
			644: R_RISCV_RELAX	*ABS*
 648:	00058593          	mv	a1,a1
			648: R_RISCV_LO12_I	bullet_contact_masks
			648: R_RISCV_RELAX	*ABS*
 64c:	00279793          	slli	a5,a5,0x2
 650:	00269693          	slli	a3,a3,0x2
 654:	00d586b3          	add	a3,a1,a3
 658:	00f585b3          	add	a1,a1,a5
 65c:	0005a783          	lw	a5,0(a1) # 0 <step>
 660:	0006a683          	lw	a3,0(a3)
 664:	00c7d7b3          	srl	a5,a5,a2
 668:	0017f793          	andi	a5,a5,1
 66c:	0c078a63          	beqz	a5,740 <.L143>
			66c: R_RISCV_BRANCH	.L143
 670:	0c0c1463          	bnez	s8,738 <.L144>
			670: R_RISCV_BRANCH	.L144
 674:	00005c37          	lui	s8,0x5
 678:	01848c33          	add	s8,s1,s8
 67c:	024c4783          	lbu	a5,36(s8) # 5024 <.L161+0x4880>
 680:	00000613          	li	a2,0
 684:	000d8593          	mv	a1,s11
 688:	fff78793          	addi	a5,a5,-1
 68c:	0ff7f793          	zext.b	a5,a5
 690:	02fc0223          	sb	a5,36(s8)
 694:	00048513          	mv	a0,s1
 698:	00f12a23          	sw	a5,20(sp)
 69c:	00000097          	auipc	ra,0x0
			69c: R_RISCV_CALL_PLT	spawn
			69c: R_RISCV_RELAX	*ABS*
 6a0:	000080e7          	jalr	ra # 69c <.L141+0xa4>
 6a4:	01412783          	lw	a5,20(sp)
 6a8:	08079463          	bnez	a5,730 <.L145>
			6a8: R_RISCV_BRANCH	.L145
 6ac:	007807b7          	lui	a5,0x780
 6b0:	02fc2023          	sw	a5,32(s8)
 6b4:	b29ff06f          	j	1dc <.L108>
			6b4: R_RISCV_JAL	.L108

000006b8 <.L139>:
 6b8:	2ab00513          	li	a0,683
 6bc:	02ad87b3          	mul	a5,s11,a0
 6c0:	02a68533          	mul	a0,a3,a0
 6c4:	00b7d793          	srli	a5,a5,0xb
 6c8:	00d55513          	srli	a0,a0,0xd
 6cc:	00a787b3          	add	a5,a5,a0
 6d0:	00f7f793          	andi	a5,a5,15
 6d4:	00000537          	lui	a0,0x0
			6d4: R_RISCV_HI20	directions
			6d4: R_RISCV_RELAX	*ABS*
 6d8:	00050513          	mv	a0,a0
			6d8: R_RISCV_LO12_I	directions
			6d8: R_RISCV_RELAX	*ABS*
 6dc:	00279793          	slli	a5,a5,0x2
 6e0:	00f507b3          	add	a5,a0,a5
 6e4:	0007d503          	lhu	a0,0(a5) # 780000 <.L161+0x77f85c>
 6e8:	0027d783          	lhu	a5,2(a5)
 6ec:	00151513          	slli	a0,a0,0x1
 6f0:	00a41423          	sh	a0,8(s0)
 6f4:	00179793          	slli	a5,a5,0x1

000006f8 <.L213>:
 6f8:	00f41523          	sh	a5,10(s0)
 6fc:	ebdff06f          	j	5b8 <.L138>
			6fc: R_RISCV_JAL	.L138

00000700 <.L140>:
 700:	0076f793          	andi	a5,a3,7
 704:	ea079ae3          	bnez	a5,5b8 <.L138>
			704: R_RISCV_BRANCH	.L138
 708:	00a41783          	lh	a5,10(s0)
 70c:	37f00513          	li	a0,895
 710:	eaf544e3          	blt	a0,a5,5b8 <.L138>
			710: R_RISCV_BRANCH	.L138
 714:	02078793          	addi	a5,a5,32
 718:	fe1ff06f          	j	6f8 <.L213>
			718: R_RISCV_JAL	.L213

0000071c <.L142>:
 71c:	0003c6b7          	lui	a3,0x3c
 720:	80068693          	addi	a3,a3,-2048 # 3b800 <.L161+0x3b05c>
 724:	ecb6dae3          	bge	a3,a1,5f8 <.L141>
			724: R_RISCV_BRANCH	.L141
 728:	00d42023          	sw	a3,0(s0)
 72c:	ec5ff06f          	j	5f0 <.L214>
			72c: R_RISCV_JAL	.L214

00000730 <.L145>:
 730:	03c00793          	li	a5,60
 734:	02fc1023          	sh	a5,32(s8)

00000738 <.L144>:
 738:	00100c13          	li	s8,1
 73c:	c55ff06f          	j	390 <.L125>
			73c: R_RISCV_JAL	.L125

00000740 <.L143>:
 740:	00c6d7b3          	srl	a5,a3,a2
 744:	0017f793          	andi	a5,a5,1
 748:	c40784e3          	beqz	a5,390 <.L125>
			748: R_RISCV_BRANCH	.L125
 74c:	01044783          	lbu	a5,16(s0)
 750:	c40790e3          	bnez	a5,390 <.L125>
			750: R_RISCV_BRANCH	.L125
 754:	00100793          	li	a5,1
 758:	00f40823          	sb	a5,16(s0)
 75c:	000057b7          	lui	a5,0x5
 760:	00f487b3          	add	a5,s1,a5
 764:	01c7a683          	lw	a3,28(a5) # 501c <.L161+0x4878>
 768:	fff00613          	li	a2,-1
 76c:	00c68663          	beq	a3,a2,778 <.L146>
			76c: R_RISCV_BRANCH	.L146
 770:	00168693          	addi	a3,a3,1
 774:	00d7ae23          	sw	a3,28(a5)

00000778 <.L146>:
 778:	000056b7          	lui	a3,0x5
 77c:	00d486b3          	add	a3,s1,a3
 780:	0186a783          	lw	a5,24(a3) # 5018 <.L161+0x4874>
 784:	ff500613          	li	a2,-11
 788:	00f67463          	bgeu	a2,a5,790 <.L147>
			788: R_RISCV_BRANCH	.L147
 78c:	ff500793          	li	a5,-11

00000790 <.L147>:
 790:	00a78793          	addi	a5,a5,10
 794:	00f6ac23          	sw	a5,24(a3)
 798:	bf9ff06f          	j	390 <.L125>
			798: R_RISCV_JAL	.L125

0000079c <.L164>:
 79c:	0f000d13          	li	s10,240
 7a0:	c01ff06f          	j	3a0 <.L148>
			7a0: R_RISCV_JAL	.L148

000007a4 <.L161>:
 7a4:	ff800793          	li	a5,-8
 7a8:	a65ff06f          	j	20c <.L101>
			7a8: R_RISCV_JAL	.L101

Disassembly of section .text.bullet_step:

Disassembly of section .text.bullet_step_player:

Disassembly of section .text.bullet_step_player_cached:

Disassembly of section .text.bullet_prepare_frame:

Disassembly of section .text.bullet_finish_window:

Disassembly of section .text.bullet_shape_opaque:

Disassembly of section .text.sprite:

Disassembly of section .text.build_frame:

Disassembly of section .text.bullet_build_frame:

Disassembly of section .text.bullet_build_frame_player:

Disassembly of section .text.bullet_clip_background_for_hud:
