
generated\verification\v3\validation-hoist-20261026\limits.o:     file format elf32-littleriscv


Disassembly of section .text.append:

Disassembly of section .text.pixel_coordinate:

Disassembly of section .text.bullet_campaign_valid:

Disassembly of section .text.bullet_enemy_position:

Disassembly of section .text.spawn:

Disassembly of section .text.bullet_reset:

Disassembly of section .text.bullet_reset_player:

Disassembly of section .text.step:

00000000 <step>:
   0:	f9010113          	addi	sp,sp,-112
   4:	05612823          	sw	s6,80(sp)
   8:	06112623          	sw	ra,108(sp)
   c:	06812423          	sw	s0,104(sp)
  10:	06912223          	sw	s1,100(sp)
  14:	07212023          	sw	s2,96(sp)
  18:	05312e23          	sw	s3,92(sp)
  1c:	05412c23          	sw	s4,88(sp)
  20:	05512a23          	sw	s5,84(sp)
  24:	05712623          	sw	s7,76(sp)
  28:	05812423          	sw	s8,72(sp)
  2c:	05912223          	sw	s9,68(sp)
  30:	05a12023          	sw	s10,64(sp)
  34:	03b12e23          	sw	s11,60(sp)
  38:	00e12623          	sw	a4,12(sp)
  3c:	00058b13          	mv	s6,a1
  40:	76050863          	beqz	a0,7b0 <.L163>
			40: R_RISCV_BRANCH	.L163
  44:	00005437          	lui	s0,0x5
  48:	00850433          	add	s0,a0,s0
  4c:	00842a03          	lw	s4,8(s0) # 5008 <.L163+0x4858>
  50:	00068993          	mv	s3,a3
  54:	3ff00713          	li	a4,1023
  58:	fffa0693          	addi	a3,s4,-1
  5c:	00050493          	mv	s1,a0
  60:	ff800793          	li	a5,-8
  64:	1ad76863          	bltu	a4,a3,214 <.L101>
			64: R_RISCV_BRANCH	.L101
  68:	02444b83          	lbu	s7,36(s0)
  6c:	00300713          	li	a4,3
  70:	1b776263          	bltu	a4,s7,214 <.L101>
			70: R_RISCV_BRANCH	.L101
  74:	00060913          	mv	s2,a2
  78:	00000097          	auipc	ra,0x0
			78: R_RISCV_CALL_PLT	bullet_campaign_valid
			78: R_RISCV_RELAX	*ABS*
  7c:	000080e7          	jalr	ra # 78 <step+0x78>
  80:	ff800793          	li	a5,-8
  84:	18050863          	beqz	a0,214 <.L101>
			84: R_RISCV_BRANCH	.L101
  88:	02045703          	lhu	a4,32(s0)
  8c:	03c00693          	li	a3,60
  90:	18e6e263          	bltu	a3,a4,214 <.L101>
			90: R_RISCV_BRANCH	.L101
  94:	00c12583          	lw	a1,12(sp)
  98:	000b9e63          	bnez	s7,b4 <.L103>
			98: R_RISCV_BRANCH	.L103
  9c:	02245683          	lhu	a3,34(s0)
  a0:	07700613          	li	a2,119
  a4:	fff68693          	addi	a3,a3,-1
  a8:	01069693          	slli	a3,a3,0x10
  ac:	0106d693          	srli	a3,a3,0x10
  b0:	16d66263          	bltu	a2,a3,214 <.L101>
			b0: R_RISCV_BRANCH	.L101

000000b4 <.L103>:
  b4:	120b0c63          	beqz	s6,1ec <.L157>
			b4: R_RISCV_BRANCH	.L157
  b8:	ff890693          	addi	a3,s2,-8
  bc:	3b000613          	li	a2,944
  c0:	ff800793          	li	a5,-8
  c4:	14d66863          	bltu	a2,a3,214 <.L101>
			c4: R_RISCV_BRANCH	.L101
  c8:	fb098693          	addi	a3,s3,-80
  cc:	1c400613          	li	a2,452
  d0:	14d66263          	bltu	a2,a3,214 <.L101>
			d0: R_RISCV_BRANCH	.L101
  d4:	00300613          	li	a2,3

000000d8 <.L104>:
  d8:	000057b7          	lui	a5,0x5
  dc:	00f487b3          	add	a5,s1,a5
  e0:	0287cc83          	lbu	s9,40(a5) # 5028 <.L163+0x4878>
  e4:	10000513          	li	a0,256
  e8:	000c8463          	beqz	s9,f0 <.L105>
			e8: R_RISCV_BRANCH	.L105
  ec:	00600513          	li	a0,6

000000f0 <.L105>:
  f0:	01400693          	li	a3,20
  f4:	02da06b3          	mul	a3,s4,a3
  f8:	00048413          	mv	s0,s1
  fc:	00048793          	mv	a5,s1
 100:	00500893          	li	a7,5
 104:	009686b3          	add	a3,a3,s1

00000108 <.L106>:
 108:	00e7c303          	lbu	t1,14(a5)
 10c:	6a666263          	bltu	a2,t1,7b0 <.L163>
			10c: R_RISCV_BRANCH	.L163
 110:	00f7c303          	lbu	t1,15(a5)
 114:	6868ee63          	bltu	a7,t1,7b0 <.L163>
			114: R_RISCV_BRANCH	.L163
 118:	0117c303          	lbu	t1,17(a5)
 11c:	68a37a63          	bgeu	t1,a0,7b0 <.L163>
			11c: R_RISCV_BRANCH	.L163
 120:	01478793          	addi	a5,a5,20
 124:	fef692e3          	bne	a3,a5,108 <.L106>
			124: R_RISCV_BRANCH	.L106
 128:	000057b7          	lui	a5,0x5
 12c:	00f487b3          	add	a5,s1,a5
 130:	0047aa83          	lw	s5,4(a5) # 5004 <.L163+0x4854>
 134:	001a8a93          	addi	s5,s5,1
 138:	0157a223          	sw	s5,4(a5)
 13c:	000b0663          	beqz	s6,148 <.L107>
			13c: R_RISCV_BRANCH	.L107
 140:	0297c783          	lbu	a5,41(a5)
 144:	0a079063          	bnez	a5,1e4 <.L108>
			144: R_RISCV_BRANCH	.L108

00000148 <.L107>:
 148:	120b9063          	bnez	s7,268 <.L109>
			148: R_RISCV_BRANCH	.L109
 14c:	000057b7          	lui	a5,0x5
 150:	00f48733          	add	a4,s1,a5
 154:	02275683          	lhu	a3,34(a4)
 158:	fff68693          	addi	a3,a3,-1
 15c:	01069693          	slli	a3,a3,0x10
 160:	0106d693          	srli	a3,a3,0x10
 164:	02d71123          	sh	a3,34(a4)
 168:	06069e63          	bnez	a3,1e4 <.L108>
			168: R_RISCV_BRANCH	.L108
 16c:	00072603          	lw	a2,0(a4)
 170:	0e0b0263          	beqz	s6,254 <.L111>
			170: R_RISCV_BRANCH	.L111
 174:	0e0c8063          	beqz	s9,254 <.L111>
			174: R_RISCV_BRANCH	.L111
 178:	06058e63          	beqz	a1,1f4 <.L112>
			178: R_RISCV_BRANCH	.L112
 17c:	06b48c63          	beq	s1,a1,1f4 <.L112>
			17c: R_RISCV_BRANCH	.L112
 180:	00f587b3          	add	a5,a1,a5
 184:	0287c703          	lbu	a4,40(a5) # 5028 <.L163+0x4878>
 188:	06070663          	beqz	a4,1f4 <.L112>
			188: R_RISCV_BRANCH	.L112
 18c:	0087a703          	lw	a4,8(a5)
 190:	06ea1263          	bne	s4,a4,1f4 <.L112>
			190: R_RISCV_BRANCH	.L112
 194:	0007a703          	lw	a4,0(a5)
 198:	04c71e63          	bne	a4,a2,1f4 <.L112>
			198: R_RISCV_BRANCH	.L112
 19c:	0047a783          	lw	a5,4(a5)
 1a0:	04079a63          	bnez	a5,1f4 <.L112>
			1a0: R_RISCV_BRANCH	.L112
 1a4:	00005437          	lui	s0,0x5
 1a8:	008587b3          	add	a5,a1,s0
 1ac:	0147a703          	lw	a4,20(a5)
 1b0:	04071263          	bnez	a4,1f4 <.L112>
			1b0: R_RISCV_BRANCH	.L112
 1b4:	0247c683          	lbu	a3,36(a5)
 1b8:	00300713          	li	a4,3
 1bc:	02e69c63          	bne	a3,a4,1f4 <.L112>
			1bc: R_RISCV_BRANCH	.L112
 1c0:	0297c783          	lbu	a5,41(a5)
 1c4:	02079863          	bnez	a5,1f4 <.L112>
			1c4: R_RISCV_BRANCH	.L112
 1c8:	00005637          	lui	a2,0x5
 1cc:	02c60613          	addi	a2,a2,44 # 502c <.L163+0x487c>
 1d0:	00048513          	mv	a0,s1
 1d4:	00848433          	add	s0,s1,s0
 1d8:	00000097          	auipc	ra,0x0
			1d8: R_RISCV_CALL_PLT	memcpy
			1d8: R_RISCV_RELAX	*ABS*
 1dc:	000080e7          	jalr	ra # 1d8 <.L107+0x90>
 1e0:	01542223          	sw	s5,4(s0) # 5004 <.L163+0x4854>

000001e4 <.L108>:
 1e4:	00000793          	li	a5,0
 1e8:	02c0006f          	j	214 <.L101>
			1e8: R_RISCV_JAL	.L101

000001ec <.L157>:
 1ec:	00200613          	li	a2,2
 1f0:	ee9ff06f          	j	d8 <.L104>
			1f0: R_RISCV_JAL	.L104

000001f4 <.L112>:
 1f4:	000a0593          	mv	a1,s4
 1f8:	00048513          	mv	a0,s1
 1fc:	00000097          	auipc	ra,0x0
			1fc: R_RISCV_CALL_PLT	bullet_reset_player
			1fc: R_RISCV_RELAX	*ABS*
 200:	000080e7          	jalr	ra # 1fc <.L112+0x8>

00000204 <.L212>:
 204:	00005737          	lui	a4,0x5
 208:	00e48733          	add	a4,s1,a4
 20c:	00050793          	mv	a5,a0
 210:	01572223          	sw	s5,4(a4) # 5004 <.L163+0x4854>

00000214 <.L101>:
 214:	06c12083          	lw	ra,108(sp)
 218:	06812403          	lw	s0,104(sp)
 21c:	06412483          	lw	s1,100(sp)
 220:	06012903          	lw	s2,96(sp)
 224:	05c12983          	lw	s3,92(sp)
 228:	05812a03          	lw	s4,88(sp)
 22c:	05412a83          	lw	s5,84(sp)
 230:	05012b03          	lw	s6,80(sp)
 234:	04c12b83          	lw	s7,76(sp)
 238:	04812c03          	lw	s8,72(sp)
 23c:	04412c83          	lw	s9,68(sp)
 240:	04012d03          	lw	s10,64(sp)
 244:	03c12d83          	lw	s11,60(sp)
 248:	00078513          	mv	a0,a5
 24c:	07010113          	addi	sp,sp,112
 250:	00008067          	ret

00000254 <.L111>:
 254:	000a0593          	mv	a1,s4
 258:	00048513          	mv	a0,s1
 25c:	00000097          	auipc	ra,0x0
			25c: R_RISCV_CALL_PLT	bullet_reset
			25c: R_RISCV_RELAX	*ABS*
 260:	000080e7          	jalr	ra # 25c <.L111+0x8>
 264:	fa1ff06f          	j	204 <.L212>
			264: R_RISCV_JAL	.L212

00000268 <.L109>:
 268:	000056b7          	lui	a3,0x5
 26c:	00d486b3          	add	a3,s1,a3
 270:	0146a783          	lw	a5,20(a3) # 5014 <.L163+0x4864>
 274:	00178793          	addi	a5,a5,1
 278:	00f6aa23          	sw	a5,20(a3)
 27c:	020b1863          	bnez	s6,2ac <.L114>
			27c: R_RISCV_BRANCH	.L114
 280:	0f000913          	li	s2,240
 284:	0327f933          	remu	s2,a5,s2
 288:	03b00693          	li	a3,59
 28c:	1326fc63          	bgeu	a3,s2,3c4 <.L115>
			28c: R_RISCV_BRANCH	.L115
 290:	0b300693          	li	a3,179
 294:	1326e063          	bltu	a3,s2,3b4 <.L116>
			294: R_RISCV_BRANCH	.L116
 298:	07800693          	li	a3,120
 29c:	412686b3          	sub	a3,a3,s2
 2a0:	00300613          	li	a2,3
 2a4:	02c686b3          	mul	a3,a3,a2
 2a8:	1e068913          	addi	s2,a3,480

000002ac <.L114>:
 2ac:	000056b7          	lui	a3,0x5
 2b0:	00d486b3          	add	a3,s1,a3
 2b4:	0126a623          	sw	s2,12(a3) # 500c <.L163+0x485c>
 2b8:	000b1463          	bnez	s6,2c0 <.L117>
			2b8: R_RISCV_BRANCH	.L117
 2bc:	1e000993          	li	s3,480

000002c0 <.L117>:
 2c0:	000056b7          	lui	a3,0x5
 2c4:	00d486b3          	add	a3,s1,a3
 2c8:	0136a823          	sw	s3,16(a3) # 5010 <.L163+0x4860>
 2cc:	00e03c33          	snez	s8,a4
 2d0:	00070663          	beqz	a4,2dc <.L118>
			2d0: R_RISCV_BRANCH	.L118
 2d4:	fff70713          	addi	a4,a4,-1
 2d8:	02e69023          	sh	a4,32(a3)

000002dc <.L118>:
 2dc:	01e00713          	li	a4,30
 2e0:	02e7f7b3          	remu	a5,a5,a4
 2e4:	02079463          	bnez	a5,30c <.L119>
			2e4: R_RISCV_BRANCH	.L119
 2e8:	000057b7          	lui	a5,0x5
 2ec:	00f487b3          	add	a5,s1,a5
 2f0:	0187a783          	lw	a5,24(a5) # 5018 <.L163+0x4868>
 2f4:	fff00713          	li	a4,-1
 2f8:	00e78463          	beq	a5,a4,300 <.L120>
			2f8: R_RISCV_BRANCH	.L120
 2fc:	00178793          	addi	a5,a5,1

00000300 <.L120>:
 300:	00005737          	lui	a4,0x5
 304:	00e48733          	add	a4,s1,a4
 308:	00f72c23          	sw	a5,24(a4) # 5018 <.L163+0x4868>

0000030c <.L119>:
 30c:	fed90793          	addi	a5,s2,-19
 310:	0003cb37          	lui	s6,0x3c
 314:	0001ebb7          	lui	s7,0x1e
 318:	00f12623          	sw	a5,12(sp)
 31c:	00010ab7          	lui	s5,0x10
 320:	00c90793          	addi	a5,s2,12
 324:	0f000d13          	li	s10,240
 328:	00000d93          	li	s11,0
 32c:	7feb0b13          	addi	s6,s6,2046 # 3c7fe <.L163+0x3c04e>
 330:	bffb8b93          	addi	s7,s7,-1025 # 1dbff <.L163+0x1d44f>
 334:	00f12823          	sw	a5,16(sp)
 338:	fffa8a93          	addi	s5,s5,-1 # ffff <.L163+0xf84f>

0000033c <.L150>:
 33c:	00e44683          	lbu	a3,14(s0)
 340:	00300793          	li	a5,3
 344:	1cf69463          	bne	a3,a5,50c <.L121>
			344: R_RISCV_BRANCH	.L121
 348:	00c45683          	lhu	a3,12(s0)
 34c:	05568663          	beq	a3,s5,398 <.L125>
			34c: R_RISCV_BRANCH	.L125
 350:	00042783          	lw	a5,0(s0)
 354:	00841303          	lh	t1,8(s0)
 358:	00442603          	lw	a2,4(s0)
 35c:	00f30333          	add	t1,t1,a5
 360:	00a41783          	lh	a5,10(s0)
 364:	00642023          	sw	t1,0(s0)
 368:	40835313          	srai	t1,t1,0x8
 36c:	00c787b3          	add	a5,a5,a2
 370:	00f42223          	sw	a5,4(s0)
 374:	00430313          	addi	t1,t1,4
 378:	3bf00613          	li	a2,959
 37c:	00666a63          	bltu	a2,t1,390 <.L123>
			37c: R_RISCV_BRANCH	.L123
 380:	4087d793          	srai	a5,a5,0x8
 384:	fbc78593          	addi	a1,a5,-68
 388:	1d300613          	li	a2,467
 38c:	04b67463          	bgeu	a2,a1,3d4 <.L124>
			38c: R_RISCV_BRANCH	.L124

00000390 <.L123>:
 390:	fff00793          	li	a5,-1
 394:	00f41623          	sh	a5,12(s0)

00000398 <.L125>:
 398:	16700793          	li	a5,359
 39c:	001d8d93          	addi	s11,s11,1
 3a0:	40fd0463          	beq	s10,a5,7a8 <.L166>
			3a0: R_RISCV_BRANCH	.L166
 3a4:	001d0d13          	addi	s10,s10,1

000003a8 <.L149>:
 3a8:	01440413          	addi	s0,s0,20
 3ac:	f94de8e3          	bltu	s11,s4,33c <.L150>
			3ac: R_RISCV_BRANCH	.L150
 3b0:	e35ff06f          	j	1e4 <.L108>
			3b0: R_RISCV_JAL	.L108

000003b4 <.L116>:
 3b4:	00300693          	li	a3,3
 3b8:	02d90933          	mul	s2,s2,a3
 3bc:	f1090913          	addi	s2,s2,-240
 3c0:	eedff06f          	j	2ac <.L114>
			3c0: R_RISCV_JAL	.L114

000003c4 <.L115>:
 3c4:	00300693          	li	a3,3
 3c8:	02d90933          	mul	s2,s2,a3
 3cc:	1e090913          	addi	s2,s2,480
 3d0:	eddff06f          	j	2ac <.L114>
			3d0: R_RISCV_JAL	.L114

000003d4 <.L124>:
 3d4:	00168693          	addi	a3,a3,1
 3d8:	00d41623          	sh	a3,12(s0)
 3dc:	00478893          	addi	a7,a5,4
 3e0:	00000593          	li	a1,0
 3e4:	00300e13          	li	t3,3

000003e8 <.L127>:
 3e8:	020c8c63          	beqz	s9,420 <.L126>
			3e8: R_RISCV_BRANCH	.L126
 3ec:	000057b7          	lui	a5,0x5
 3f0:	02578793          	addi	a5,a5,37 # 5025 <.L163+0x4875>
 3f4:	00f587b3          	add	a5,a1,a5
 3f8:	00f487b3          	add	a5,s1,a5
 3fc:	0007c783          	lbu	a5,0(a5)
 400:	02079063          	bnez	a5,420 <.L126>
			400: R_RISCV_BRANCH	.L126

00000404 <.L129>:
 404:	00158593          	addi	a1,a1,1
 408:	ffc590e3          	bne	a1,t3,3e8 <.L127>
			408: R_RISCV_BRANCH	.L127

0000040c <.L128>:
 40c:	000057b7          	lui	a5,0x5
 410:	00f487b3          	add	a5,s1,a5
 414:	0297c783          	lbu	a5,41(a5) # 5029 <.L163+0x4879>
 418:	dc0796e3          	bnez	a5,1e4 <.L108>
			418: R_RISCV_BRANCH	.L108
 41c:	f7dff06f          	j	398 <.L125>
			41c: R_RISCV_JAL	.L125

00000420 <.L126>:
 420:	02c10693          	addi	a3,sp,44
 424:	02810613          	addi	a2,sp,40
 428:	00048513          	mv	a0,s1
 42c:	01112e23          	sw	a7,28(sp)
 430:	00612c23          	sw	t1,24(sp)
 434:	00b12a23          	sw	a1,20(sp)
 438:	00000097          	auipc	ra,0x0
			438: R_RISCV_CALL_PLT	bullet_enemy_position
			438: R_RISCV_RELAX	*ABS*
 43c:	000080e7          	jalr	ra # 438 <.L126+0x18>
 440:	02812683          	lw	a3,40(sp)
 444:	01812303          	lw	t1,24(sp)
 448:	01400613          	li	a2,20
 44c:	02c12783          	lw	a5,44(sp)
 450:	40d306b3          	sub	a3,t1,a3
 454:	00a68693          	addi	a3,a3,10
 458:	01412583          	lw	a1,20(sp)
 45c:	01c12883          	lw	a7,28(sp)
 460:	00300e13          	li	t3,3
 464:	fad660e3          	bltu	a2,a3,404 <.L129>
			464: R_RISCV_BRANCH	.L129
 468:	40f887b3          	sub	a5,a7,a5
 46c:	00a78793          	addi	a5,a5,10
 470:	f8f66ae3          	bltu	a2,a5,404 <.L129>
			470: R_RISCV_BRANCH	.L129
 474:	fff00793          	li	a5,-1
 478:	00f41623          	sh	a5,12(s0)
 47c:	000057b7          	lui	a5,0x5
 480:	00f487b3          	add	a5,s1,a5
 484:	0187a783          	lw	a5,24(a5) # 5018 <.L163+0x4868>
 488:	fe600693          	li	a3,-26
 48c:	00f6f463          	bgeu	a3,a5,494 <.L130>
			48c: R_RISCV_BRANCH	.L130
 490:	fe600793          	li	a5,-26

00000494 <.L130>:
 494:	000056b7          	lui	a3,0x5
 498:	01978793          	addi	a5,a5,25
 49c:	00d48533          	add	a0,s1,a3
 4a0:	00f52c23          	sw	a5,24(a0)
 4a4:	f60c84e3          	beqz	s9,40c <.L128>
			4a4: R_RISCV_BRANCH	.L128
 4a8:	00b485b3          	add	a1,s1,a1
 4ac:	00b68633          	add	a2,a3,a1
 4b0:	02564683          	lbu	a3,37(a2)
 4b4:	fff68693          	addi	a3,a3,-1 # 4fff <.L163+0x484f>
 4b8:	0ff6f693          	zext.b	a3,a3
 4bc:	02d602a3          	sb	a3,37(a2)
 4c0:	f40696e3          	bnez	a3,40c <.L128>
			4c0: R_RISCV_BRANCH	.L128
 4c4:	f3700693          	li	a3,-201
 4c8:	00f6f463          	bgeu	a3,a5,4d0 <.L132>
			4c8: R_RISCV_BRANCH	.L132
 4cc:	f3700793          	li	a5,-201

000004d0 <.L132>:
 4d0:	0c878793          	addi	a5,a5,200
 4d4:	000056b7          	lui	a3,0x5
 4d8:	00f52c23          	sw	a5,24(a0)
 4dc:	00d486b3          	add	a3,s1,a3
 4e0:	0246a603          	lw	a2,36(a3) # 5024 <.L163+0x4874>
 4e4:	00000793          	li	a5,0
 4e8:	00861593          	slli	a1,a2,0x8
 4ec:	0105d593          	srli	a1,a1,0x10
 4f0:	00059663          	bnez	a1,4fc <.L133>
			4f0: R_RISCV_BRANCH	.L133
 4f4:	0276c783          	lbu	a5,39(a3)
 4f8:	0017b793          	seqz	a5,a5

000004fc <.L133>:
 4fc:	000056b7          	lui	a3,0x5
 500:	00d486b3          	add	a3,s1,a3
 504:	02f684a3          	sb	a5,41(a3) # 5029 <.L163+0x4879>
 508:	f05ff06f          	j	40c <.L128>
			508: R_RISCV_JAL	.L128

0000050c <.L121>:
 50c:	000c8663          	beqz	s9,518 <.L135>
			50c: R_RISCV_BRANCH	.L135
 510:	00c45783          	lhu	a5,12(s0)
 514:	e95782e3          	beq	a5,s5,398 <.L125>
			514: R_RISCV_BRANCH	.L125

00000518 <.L135>:
 518:	00042583          	lw	a1,0(s0)
 51c:	7ff58793          	addi	a5,a1,2047
 520:	00fb6e63          	bltu	s6,a5,53c <.L136>
			520: R_RISCV_BRANCH	.L136
 524:	00442603          	lw	a2,4(s0)
 528:	ffffc7b7          	lui	a5,0xffffc
 52c:	00f607b3          	add	a5,a2,a5
 530:	00fbe663          	bltu	s7,a5,53c <.L136>
			530: R_RISCV_BRANCH	.L136
 534:	00c45683          	lhu	a3,12(s0)
 538:	01a6ee63          	bltu	a3,s10,554 <.L137>
			538: R_RISCV_BRANCH	.L137

0000053c <.L136>:
 53c:	00000613          	li	a2,0
 540:	000d8593          	mv	a1,s11
 544:	00048513          	mv	a0,s1
 548:	00000097          	auipc	ra,0x0
			548: R_RISCV_CALL_PLT	spawn
			548: R_RISCV_RELAX	*ABS*
 54c:	000080e7          	jalr	ra # 548 <.L136+0xc>
 550:	e49ff06f          	j	398 <.L125>
			550: R_RISCV_JAL	.L125

00000554 <.L137>:
 554:	060c8663          	beqz	s9,5c0 <.L138>
			554: R_RISCV_BRANCH	.L138
 558:	01144783          	lbu	a5,17(s0)
 55c:	00300513          	li	a0,3
 560:	12a78263          	beq	a5,a0,684 <.L139>
			560: R_RISCV_BRANCH	.L139
 564:	00400513          	li	a0,4
 568:	16a78263          	beq	a5,a0,6cc <.L140>
			568: R_RISCV_BRANCH	.L140
 56c:	00200513          	li	a0,2
 570:	04a79863          	bne	a5,a0,5c0 <.L138>
			570: R_RISCV_BRANCH	.L138
 574:	000007b7          	lui	a5,0x0
			574: R_RISCV_HI20	directions
			574: R_RISCV_RELAX	*ABS*
 578:	03c6f513          	andi	a0,a3,60
 57c:	00078793          	mv	a5,a5
			57c: R_RISCV_LO12_I	directions
			57c: R_RISCV_RELAX	*ABS*
 580:	00a787b3          	add	a5,a5,a0
 584:	00079883          	lh	a7,0(a5) # 0 <step>
 588:	0cd00793          	li	a5,205
 58c:	02fd87b3          	mul	a5,s11,a5
 590:	00500513          	li	a0,5
 594:	00a7d793          	srli	a5,a5,0xa
 598:	02a787b3          	mul	a5,a5,a0
 59c:	06000513          	li	a0,96
 5a0:	40fd87b3          	sub	a5,s11,a5
 5a4:	ffe78793          	addi	a5,a5,-2
 5a8:	02a787b3          	mul	a5,a5,a0
 5ac:	01f8d513          	srli	a0,a7,0x1f
 5b0:	01150533          	add	a0,a0,a7
 5b4:	40155513          	srai	a0,a0,0x1
 5b8:	00a787b3          	add	a5,a5,a0
 5bc:	00f41423          	sh	a5,8(s0)

000005c0 <.L138>:
 5c0:	00841503          	lh	a0,8(s0)
 5c4:	00a41783          	lh	a5,10(s0)
 5c8:	00168693          	addi	a3,a3,1
 5cc:	00b505b3          	add	a1,a0,a1
 5d0:	00c787b3          	add	a5,a5,a2
 5d4:	00b42023          	sw	a1,0(s0)
 5d8:	00f42223          	sw	a5,4(s0)
 5dc:	00d41623          	sh	a3,12(s0)
 5e0:	020c8063          	beqz	s9,600 <.L141>
			5e0: R_RISCV_BRANCH	.L141
 5e4:	01144603          	lbu	a2,17(s0)
 5e8:	00500693          	li	a3,5
 5ec:	00d61a63          	bne	a2,a3,600 <.L141>
			5ec: R_RISCV_BRANCH	.L141
 5f0:	0e05dc63          	bgez	a1,6e8 <.L142>
			5f0: R_RISCV_BRANCH	.L142
 5f4:	00042023          	sw	zero,0(s0)

000005f8 <.L214>:
 5f8:	40a00533          	neg	a0,a0
 5fc:	00a41423          	sh	a0,8(s0)

00000600 <.L141>:
 600:	00042683          	lw	a3,0(s0)
 604:	00c12703          	lw	a4,12(sp)
 608:	4086d693          	srai	a3,a3,0x8
 60c:	d8e6c6e3          	blt	a3,a4,398 <.L125>
			60c: R_RISCV_BRANCH	.L125
 610:	01012703          	lw	a4,16(sp)
 614:	d8d742e3          	blt	a4,a3,398 <.L125>
			614: R_RISCV_BRANCH	.L125
 618:	4087d793          	srai	a5,a5,0x8
 61c:	fed98613          	addi	a2,s3,-19
 620:	d6c7cce3          	blt	a5,a2,398 <.L125>
			620: R_RISCV_BRANCH	.L125
 624:	00c98613          	addi	a2,s3,12
 628:	d6f648e3          	blt	a2,a5,398 <.L125>
			628: R_RISCV_BRANCH	.L125
 62c:	412686b3          	sub	a3,a3,s2
 630:	01368613          	addi	a2,a3,19
 634:	00f44683          	lbu	a3,15(s0)
 638:	413787b3          	sub	a5,a5,s3
 63c:	01378793          	addi	a5,a5,19
 640:	00669693          	slli	a3,a3,0x6
 644:	00f687b3          	add	a5,a3,a5
 648:	02078693          	addi	a3,a5,32
 64c:	000005b7          	lui	a1,0x0
			64c: R_RISCV_HI20	bullet_contact_masks
			64c: R_RISCV_RELAX	*ABS*
 650:	00058593          	mv	a1,a1
			650: R_RISCV_LO12_I	bullet_contact_masks
			650: R_RISCV_RELAX	*ABS*
 654:	00279793          	slli	a5,a5,0x2
 658:	00269693          	slli	a3,a3,0x2
 65c:	00d586b3          	add	a3,a1,a3
 660:	00f585b3          	add	a1,a1,a5
 664:	0005a783          	lw	a5,0(a1) # 0 <step>
 668:	0006a683          	lw	a3,0(a3)
 66c:	00c7d7b3          	srl	a5,a5,a2
 670:	0017f793          	andi	a5,a5,1
 674:	0c078c63          	beqz	a5,74c <.L143>
			674: R_RISCV_BRANCH	.L143
 678:	080c0263          	beqz	s8,6fc <.L144>
			678: R_RISCV_BRANCH	.L144

0000067c <.L146>:
 67c:	00100c13          	li	s8,1
 680:	d19ff06f          	j	398 <.L125>
			680: R_RISCV_JAL	.L125

00000684 <.L139>:
 684:	2ab00513          	li	a0,683
 688:	02ad87b3          	mul	a5,s11,a0
 68c:	02a68533          	mul	a0,a3,a0
 690:	00b7d793          	srli	a5,a5,0xb
 694:	00d55513          	srli	a0,a0,0xd
 698:	00a787b3          	add	a5,a5,a0
 69c:	00f7f793          	andi	a5,a5,15
 6a0:	00000537          	lui	a0,0x0
			6a0: R_RISCV_HI20	directions
			6a0: R_RISCV_RELAX	*ABS*
 6a4:	00050513          	mv	a0,a0
			6a4: R_RISCV_LO12_I	directions
			6a4: R_RISCV_RELAX	*ABS*
 6a8:	00279793          	slli	a5,a5,0x2
 6ac:	00f507b3          	add	a5,a0,a5
 6b0:	0007d503          	lhu	a0,0(a5)
 6b4:	0027d783          	lhu	a5,2(a5)
 6b8:	00151513          	slli	a0,a0,0x1
 6bc:	00a41423          	sh	a0,8(s0)
 6c0:	00179793          	slli	a5,a5,0x1

000006c4 <.L213>:
 6c4:	00f41523          	sh	a5,10(s0)
 6c8:	ef9ff06f          	j	5c0 <.L138>
			6c8: R_RISCV_JAL	.L138

000006cc <.L140>:
 6cc:	0076f793          	andi	a5,a3,7
 6d0:	ee0798e3          	bnez	a5,5c0 <.L138>
			6d0: R_RISCV_BRANCH	.L138
 6d4:	00a41783          	lh	a5,10(s0)
 6d8:	37f00513          	li	a0,895
 6dc:	eef542e3          	blt	a0,a5,5c0 <.L138>
			6dc: R_RISCV_BRANCH	.L138
 6e0:	02078793          	addi	a5,a5,32
 6e4:	fe1ff06f          	j	6c4 <.L213>
			6e4: R_RISCV_JAL	.L213

000006e8 <.L142>:
 6e8:	0003c6b7          	lui	a3,0x3c
 6ec:	80068693          	addi	a3,a3,-2048 # 3b800 <.L163+0x3b050>
 6f0:	f0b6d8e3          	bge	a3,a1,600 <.L141>
			6f0: R_RISCV_BRANCH	.L141
 6f4:	00d42023          	sw	a3,0(s0)
 6f8:	f01ff06f          	j	5f8 <.L214>
			6f8: R_RISCV_JAL	.L214

000006fc <.L144>:
 6fc:	00005c37          	lui	s8,0x5
 700:	01848c33          	add	s8,s1,s8
 704:	024c4783          	lbu	a5,36(s8) # 5024 <.L163+0x4874>
 708:	00000613          	li	a2,0
 70c:	000d8593          	mv	a1,s11
 710:	fff78793          	addi	a5,a5,-1
 714:	0ff7f793          	zext.b	a5,a5
 718:	02fc0223          	sb	a5,36(s8)
 71c:	00048513          	mv	a0,s1
 720:	00f12a23          	sw	a5,20(sp)
 724:	00000097          	auipc	ra,0x0
			724: R_RISCV_CALL_PLT	spawn
			724: R_RISCV_RELAX	*ABS*
 728:	000080e7          	jalr	ra # 724 <.L144+0x28>
 72c:	01412783          	lw	a5,20(sp)
 730:	00079863          	bnez	a5,740 <.L145>
			730: R_RISCV_BRANCH	.L145
 734:	007807b7          	lui	a5,0x780
 738:	02fc2023          	sw	a5,32(s8)
 73c:	aa9ff06f          	j	1e4 <.L108>
			73c: R_RISCV_JAL	.L108

00000740 <.L145>:
 740:	03c00793          	li	a5,60
 744:	02fc1023          	sh	a5,32(s8)
 748:	f35ff06f          	j	67c <.L146>
			748: R_RISCV_JAL	.L146

0000074c <.L143>:
 74c:	00c6d7b3          	srl	a5,a3,a2
 750:	0017f793          	andi	a5,a5,1
 754:	c40782e3          	beqz	a5,398 <.L125>
			754: R_RISCV_BRANCH	.L125
 758:	01044783          	lbu	a5,16(s0)
 75c:	c2079ee3          	bnez	a5,398 <.L125>
			75c: R_RISCV_BRANCH	.L125
 760:	00100793          	li	a5,1
 764:	00f40823          	sb	a5,16(s0)
 768:	000057b7          	lui	a5,0x5
 76c:	00f487b3          	add	a5,s1,a5
 770:	01c7a683          	lw	a3,28(a5) # 501c <.L163+0x486c>
 774:	fff00613          	li	a2,-1
 778:	00c68663          	beq	a3,a2,784 <.L147>
			778: R_RISCV_BRANCH	.L147
 77c:	00168693          	addi	a3,a3,1
 780:	00d7ae23          	sw	a3,28(a5)

00000784 <.L147>:
 784:	000056b7          	lui	a3,0x5
 788:	00d486b3          	add	a3,s1,a3
 78c:	0186a783          	lw	a5,24(a3) # 5018 <.L163+0x4868>
 790:	ff500613          	li	a2,-11
 794:	00f67463          	bgeu	a2,a5,79c <.L148>
			794: R_RISCV_BRANCH	.L148
 798:	ff500793          	li	a5,-11

0000079c <.L148>:
 79c:	00a78793          	addi	a5,a5,10
 7a0:	00f6ac23          	sw	a5,24(a3)
 7a4:	bf5ff06f          	j	398 <.L125>
			7a4: R_RISCV_JAL	.L125

000007a8 <.L166>:
 7a8:	0f000d13          	li	s10,240
 7ac:	bfdff06f          	j	3a8 <.L149>
			7ac: R_RISCV_JAL	.L149

000007b0 <.L163>:
 7b0:	ff800793          	li	a5,-8
 7b4:	a61ff06f          	j	214 <.L101>
			7b4: R_RISCV_JAL	.L101

Disassembly of section .text.bullet_step:

Disassembly of section .text.bullet_step_player:

Disassembly of section .text.bullet_step_player_cached:

Disassembly of section .text.bullet_prepare_frame:

Disassembly of section .text.bullet_finish_window:

Disassembly of section .text.bullet_shape_opaque:

Disassembly of section .text.sprite:

Disassembly of section .text.build_frame:

Disassembly of section .text.bullet_build_frame:

Disassembly of section .text.bullet_build_frame_player:

Disassembly of section .text.bullet_clip_background_for_hud:
