
generated\verification\v3\validation-hoist-20261026\baseline.o:     file format elf32-littleriscv


Disassembly of section .text.append:

Disassembly of section .text.pixel_coordinate:

Disassembly of section .text.bullet_campaign_valid:

Disassembly of section .text.bullet_enemy_position:

Disassembly of section .text.spawn:

Disassembly of section .text.bullet_reset:

Disassembly of section .text.bullet_reset_player:

Disassembly of section .text.step:

00000000 <step>:
   0:	f9010113          	addi	sp,sp,-112
   4:	05512a23          	sw	s5,84(sp)
   8:	06112623          	sw	ra,108(sp)
   c:	06812423          	sw	s0,104(sp)
  10:	06912223          	sw	s1,100(sp)
  14:	07212023          	sw	s2,96(sp)
  18:	05312e23          	sw	s3,92(sp)
  1c:	05412c23          	sw	s4,88(sp)
  20:	05612823          	sw	s6,80(sp)
  24:	05712623          	sw	s7,76(sp)
  28:	05812423          	sw	s8,72(sp)
  2c:	05912223          	sw	s9,68(sp)
  30:	05a12023          	sw	s10,64(sp)
  34:	03b12e23          	sw	s11,60(sp)
  38:	00e12423          	sw	a4,8(sp)
  3c:	00058a93          	mv	s5,a1
  40:	76050e63          	beqz	a0,7bc <.L162>
			40: R_RISCV_BRANCH	.L162
  44:	00005437          	lui	s0,0x5
  48:	00850433          	add	s0,a0,s0
  4c:	00842a03          	lw	s4,8(s0) # 5008 <.L162+0x484c>
  50:	00068993          	mv	s3,a3
  54:	3ff00713          	li	a4,1023
  58:	fffa0693          	addi	a3,s4,-1
  5c:	00050493          	mv	s1,a0
  60:	ff800793          	li	a5,-8
  64:	1ad76463          	bltu	a4,a3,20c <.L101>
			64: R_RISCV_BRANCH	.L101
  68:	02444b83          	lbu	s7,36(s0)
  6c:	00300713          	li	a4,3
  70:	19776e63          	bltu	a4,s7,20c <.L101>
			70: R_RISCV_BRANCH	.L101
  74:	00060913          	mv	s2,a2
  78:	00000097          	auipc	ra,0x0
			78: R_RISCV_CALL_PLT	bullet_campaign_valid
			78: R_RISCV_RELAX	*ABS*
  7c:	000080e7          	jalr	ra # 78 <step+0x78>
  80:	ff800793          	li	a5,-8
  84:	18050463          	beqz	a0,20c <.L101>
			84: R_RISCV_BRANCH	.L101
  88:	02045703          	lhu	a4,32(s0)
  8c:	03c00693          	li	a3,60
  90:	16e6ee63          	bltu	a3,a4,20c <.L101>
			90: R_RISCV_BRANCH	.L101
  94:	00812583          	lw	a1,8(sp)
  98:	000b9e63          	bnez	s7,b4 <.L103>
			98: R_RISCV_BRANCH	.L103
  9c:	02245683          	lhu	a3,34(s0)
  a0:	07700613          	li	a2,119
  a4:	fff68693          	addi	a3,a3,-1
  a8:	01069693          	slli	a3,a3,0x10
  ac:	0106d693          	srli	a3,a3,0x10
  b0:	14d66e63          	bltu	a2,a3,20c <.L101>
			b0: R_RISCV_BRANCH	.L101

000000b4 <.L103>:
  b4:	020a8063          	beqz	s5,d4 <.L104>
			b4: R_RISCV_BRANCH	.L104
  b8:	ff890693          	addi	a3,s2,-8
  bc:	3b000613          	li	a2,944
  c0:	ff800793          	li	a5,-8
  c4:	14d66463          	bltu	a2,a3,20c <.L101>
			c4: R_RISCV_BRANCH	.L101
  c8:	fb098693          	addi	a3,s3,-80
  cc:	1c400613          	li	a2,452
  d0:	12d66e63          	bltu	a2,a3,20c <.L101>
			d0: R_RISCV_BRANCH	.L101

000000d4 <.L104>:
  d4:	01400693          	li	a3,20
  d8:	02da06b3          	mul	a3,s4,a3
  dc:	00005637          	lui	a2,0x5
  e0:	00048413          	mv	s0,s1
  e4:	00048793          	mv	a5,s1
  e8:	001ab893          	seqz	a7,s5
  ec:	00500813          	li	a6,5
  f0:	00c48633          	add	a2,s1,a2
  f4:	009686b3          	add	a3,a3,s1

000000f8 <.L108>:
  f8:	00e7c303          	lbu	t1,14(a5)
  fc:	0018b513          	seqz	a0,a7
 100:	00250513          	addi	a0,a0,2
 104:	6a654c63          	blt	a0,t1,7bc <.L162>
			104: R_RISCV_BRANCH	.L162
 108:	00f7c503          	lbu	a0,15(a5)
 10c:	6aa86863          	bltu	a6,a0,7bc <.L162>
			10c: R_RISCV_BRANCH	.L162
 110:	02864503          	lbu	a0,40(a2) # 5028 <.L162+0x486c>
 114:	00050663          	beqz	a0,120 <.L107>
			114: R_RISCV_BRANCH	.L107
 118:	0117c303          	lbu	t1,17(a5)
 11c:	6a686063          	bltu	a6,t1,7bc <.L162>
			11c: R_RISCV_BRANCH	.L162

00000120 <.L107>:
 120:	01478793          	addi	a5,a5,20
 124:	fcd79ae3          	bne	a5,a3,f8 <.L108>
			124: R_RISCV_BRANCH	.L108
 128:	000057b7          	lui	a5,0x5
 12c:	00f487b3          	add	a5,s1,a5
 130:	0047ab03          	lw	s6,4(a5) # 5004 <.L162+0x4848>
 134:	001b0b13          	addi	s6,s6,1
 138:	0167a223          	sw	s6,4(a5)
 13c:	000a8663          	beqz	s5,148 <.L109>
			13c: R_RISCV_BRANCH	.L109
 140:	0297c783          	lbu	a5,41(a5)
 144:	0a079063          	bnez	a5,1e4 <.L110>
			144: R_RISCV_BRANCH	.L110

00000148 <.L109>:
 148:	100b9c63          	bnez	s7,260 <.L111>
			148: R_RISCV_BRANCH	.L111
 14c:	000057b7          	lui	a5,0x5
 150:	00f48733          	add	a4,s1,a5
 154:	02275683          	lhu	a3,34(a4)
 158:	fff68693          	addi	a3,a3,-1
 15c:	01069693          	slli	a3,a3,0x10
 160:	0106d693          	srli	a3,a3,0x10
 164:	02d71123          	sh	a3,34(a4)
 168:	06069e63          	bnez	a3,1e4 <.L110>
			168: R_RISCV_BRANCH	.L110
 16c:	00072603          	lw	a2,0(a4)
 170:	0c0a8e63          	beqz	s5,24c <.L113>
			170: R_RISCV_BRANCH	.L113
 174:	0c050c63          	beqz	a0,24c <.L113>
			174: R_RISCV_BRANCH	.L113
 178:	06058a63          	beqz	a1,1ec <.L114>
			178: R_RISCV_BRANCH	.L114
 17c:	06b48863          	beq	s1,a1,1ec <.L114>
			17c: R_RISCV_BRANCH	.L114
 180:	00f587b3          	add	a5,a1,a5
 184:	0287c703          	lbu	a4,40(a5) # 5028 <.L162+0x486c>
 188:	06070263          	beqz	a4,1ec <.L114>
			188: R_RISCV_BRANCH	.L114
 18c:	0087a703          	lw	a4,8(a5)
 190:	04ea1e63          	bne	s4,a4,1ec <.L114>
			190: R_RISCV_BRANCH	.L114
 194:	0007a703          	lw	a4,0(a5)
 198:	04c71a63          	bne	a4,a2,1ec <.L114>
			198: R_RISCV_BRANCH	.L114
 19c:	0047a783          	lw	a5,4(a5)
 1a0:	04079663          	bnez	a5,1ec <.L114>
			1a0: R_RISCV_BRANCH	.L114
 1a4:	00005437          	lui	s0,0x5
 1a8:	008587b3          	add	a5,a1,s0
 1ac:	0147a703          	lw	a4,20(a5)
 1b0:	02071e63          	bnez	a4,1ec <.L114>
			1b0: R_RISCV_BRANCH	.L114
 1b4:	0247c683          	lbu	a3,36(a5)
 1b8:	00300713          	li	a4,3
 1bc:	02e69863          	bne	a3,a4,1ec <.L114>
			1bc: R_RISCV_BRANCH	.L114
 1c0:	0297c783          	lbu	a5,41(a5)
 1c4:	02079463          	bnez	a5,1ec <.L114>
			1c4: R_RISCV_BRANCH	.L114
 1c8:	00005637          	lui	a2,0x5
 1cc:	02c60613          	addi	a2,a2,44 # 502c <.L162+0x4870>
 1d0:	00048513          	mv	a0,s1
 1d4:	00848433          	add	s0,s1,s0
 1d8:	00000097          	auipc	ra,0x0
			1d8: R_RISCV_CALL_PLT	memcpy
			1d8: R_RISCV_RELAX	*ABS*
 1dc:	000080e7          	jalr	ra # 1d8 <.L109+0x90>
 1e0:	01642223          	sw	s6,4(s0) # 5004 <.L162+0x4848>

000001e4 <.L110>:
 1e4:	00000793          	li	a5,0
 1e8:	0240006f          	j	20c <.L101>
			1e8: R_RISCV_JAL	.L101

000001ec <.L114>:
 1ec:	000a0593          	mv	a1,s4
 1f0:	00048513          	mv	a0,s1
 1f4:	00000097          	auipc	ra,0x0
			1f4: R_RISCV_CALL_PLT	bullet_reset_player
			1f4: R_RISCV_RELAX	*ABS*
 1f8:	000080e7          	jalr	ra # 1f4 <.L114+0x8>

000001fc <.L216>:
 1fc:	00005737          	lui	a4,0x5
 200:	00e48733          	add	a4,s1,a4
 204:	00050793          	mv	a5,a0
 208:	01672223          	sw	s6,4(a4) # 5004 <.L162+0x4848>

0000020c <.L101>:
 20c:	06c12083          	lw	ra,108(sp)
 210:	06812403          	lw	s0,104(sp)
 214:	06412483          	lw	s1,100(sp)
 218:	06012903          	lw	s2,96(sp)
 21c:	05c12983          	lw	s3,92(sp)
 220:	05812a03          	lw	s4,88(sp)
 224:	05412a83          	lw	s5,84(sp)
 228:	05012b03          	lw	s6,80(sp)
 22c:	04c12b83          	lw	s7,76(sp)
 230:	04812c03          	lw	s8,72(sp)
 234:	04412c83          	lw	s9,68(sp)
 238:	04012d03          	lw	s10,64(sp)
 23c:	03c12d83          	lw	s11,60(sp)
 240:	00078513          	mv	a0,a5
 244:	07010113          	addi	sp,sp,112
 248:	00008067          	ret

0000024c <.L113>:
 24c:	000a0593          	mv	a1,s4
 250:	00048513          	mv	a0,s1
 254:	00000097          	auipc	ra,0x0
			254: R_RISCV_CALL_PLT	bullet_reset
			254: R_RISCV_RELAX	*ABS*
 258:	000080e7          	jalr	ra # 254 <.L113+0x8>
 25c:	fa1ff06f          	j	1fc <.L216>
			25c: R_RISCV_JAL	.L216

00000260 <.L111>:
 260:	000056b7          	lui	a3,0x5
 264:	00d486b3          	add	a3,s1,a3
 268:	0146a783          	lw	a5,20(a3) # 5014 <.L162+0x4858>
 26c:	00178793          	addi	a5,a5,1
 270:	00f6aa23          	sw	a5,20(a3)
 274:	020a9863          	bnez	s5,2a4 <.L116>
			274: R_RISCV_BRANCH	.L116
 278:	0f000913          	li	s2,240
 27c:	0327f933          	remu	s2,a5,s2
 280:	03b00693          	li	a3,59
 284:	1526f063          	bgeu	a3,s2,3c4 <.L117>
			284: R_RISCV_BRANCH	.L117
 288:	0b300693          	li	a3,179
 28c:	1326e463          	bltu	a3,s2,3b4 <.L118>
			28c: R_RISCV_BRANCH	.L118
 290:	07800693          	li	a3,120
 294:	412686b3          	sub	a3,a3,s2
 298:	00300613          	li	a2,3
 29c:	02c686b3          	mul	a3,a3,a2
 2a0:	1e068913          	addi	s2,a3,480

000002a4 <.L116>:
 2a4:	000056b7          	lui	a3,0x5
 2a8:	00d486b3          	add	a3,s1,a3
 2ac:	0126a623          	sw	s2,12(a3) # 500c <.L162+0x4850>
 2b0:	000a9463          	bnez	s5,2b8 <.L119>
			2b0: R_RISCV_BRANCH	.L119
 2b4:	1e000993          	li	s3,480

000002b8 <.L119>:
 2b8:	000056b7          	lui	a3,0x5
 2bc:	00d486b3          	add	a3,s1,a3
 2c0:	0136a823          	sw	s3,16(a3) # 5010 <.L162+0x4854>
 2c4:	00e03cb3          	snez	s9,a4
 2c8:	00070663          	beqz	a4,2d4 <.L120>
			2c8: R_RISCV_BRANCH	.L120
 2cc:	fff70713          	addi	a4,a4,-1
 2d0:	02e69023          	sh	a4,32(a3)

000002d4 <.L120>:
 2d4:	01e00713          	li	a4,30
 2d8:	02e7f7b3          	remu	a5,a5,a4
 2dc:	02079463          	bnez	a5,304 <.L121>
			2dc: R_RISCV_BRANCH	.L121
 2e0:	000057b7          	lui	a5,0x5
 2e4:	00f487b3          	add	a5,s1,a5
 2e8:	0187a783          	lw	a5,24(a5) # 5018 <.L162+0x485c>
 2ec:	fff00713          	li	a4,-1
 2f0:	00e78463          	beq	a5,a4,2f8 <.L122>
			2f0: R_RISCV_BRANCH	.L122
 2f4:	00178793          	addi	a5,a5,1

000002f8 <.L122>:
 2f8:	00005737          	lui	a4,0x5
 2fc:	00e48733          	add	a4,s1,a4
 300:	00f72c23          	sw	a5,24(a4) # 5018 <.L162+0x485c>

00000304 <.L121>:
 304:	fed90793          	addi	a5,s2,-19
 308:	00005ab7          	lui	s5,0x5
 30c:	0003cbb7          	lui	s7,0x3c
 310:	0001ec37          	lui	s8,0x1e
 314:	00f12423          	sw	a5,8(sp)
 318:	00010b37          	lui	s6,0x10
 31c:	00c90793          	addi	a5,s2,12
 320:	0f000d93          	li	s11,240
 324:	00000d13          	li	s10,0
 328:	01548ab3          	add	s5,s1,s5
 32c:	7feb8b93          	addi	s7,s7,2046 # 3c7fe <.L162+0x3c042>
 330:	bffc0c13          	addi	s8,s8,-1025 # 1dbff <.L162+0x1d443>
 334:	00f12623          	sw	a5,12(sp)
 338:	fffb0b13          	addi	s6,s6,-1 # ffff <.L162+0xf843>

0000033c <.L151>:
 33c:	00e44683          	lbu	a3,14(s0)
 340:	00300793          	li	a5,3
 344:	1cf69a63          	bne	a3,a5,518 <.L123>
			344: R_RISCV_BRANCH	.L123
 348:	00c45683          	lhu	a3,12(s0)
 34c:	05668663          	beq	a3,s6,398 <.L127>
			34c: R_RISCV_BRANCH	.L127
 350:	00042783          	lw	a5,0(s0)
 354:	00841303          	lh	t1,8(s0)
 358:	00442603          	lw	a2,4(s0)
 35c:	00f30333          	add	t1,t1,a5
 360:	00a41783          	lh	a5,10(s0)
 364:	00642023          	sw	t1,0(s0)
 368:	40835313          	srai	t1,t1,0x8
 36c:	00c787b3          	add	a5,a5,a2
 370:	00f42223          	sw	a5,4(s0)
 374:	00430313          	addi	t1,t1,4
 378:	3bf00613          	li	a2,959
 37c:	00666a63          	bltu	a2,t1,390 <.L125>
			37c: R_RISCV_BRANCH	.L125
 380:	4087d793          	srai	a5,a5,0x8
 384:	fbc78593          	addi	a1,a5,-68
 388:	1d300613          	li	a2,467
 38c:	04b67463          	bgeu	a2,a1,3d4 <.L126>
			38c: R_RISCV_BRANCH	.L126

00000390 <.L125>:
 390:	fff00793          	li	a5,-1
 394:	00f41623          	sh	a5,12(s0)

00000398 <.L127>:
 398:	16700793          	li	a5,359
 39c:	001d0d13          	addi	s10,s10,1
 3a0:	40fd8a63          	beq	s11,a5,7b4 <.L165>
			3a0: R_RISCV_BRANCH	.L165
 3a4:	001d8d93          	addi	s11,s11,1

000003a8 <.L150>:
 3a8:	01440413          	addi	s0,s0,20
 3ac:	f9aa18e3          	bne	s4,s10,33c <.L151>
			3ac: R_RISCV_BRANCH	.L151
 3b0:	e35ff06f          	j	1e4 <.L110>
			3b0: R_RISCV_JAL	.L110

000003b4 <.L118>:
 3b4:	00300693          	li	a3,3
 3b8:	02d90933          	mul	s2,s2,a3
 3bc:	f1090913          	addi	s2,s2,-240
 3c0:	ee5ff06f          	j	2a4 <.L116>
			3c0: R_RISCV_JAL	.L116

000003c4 <.L117>:
 3c4:	00300693          	li	a3,3
 3c8:	02d90933          	mul	s2,s2,a3
 3cc:	1e090913          	addi	s2,s2,480
 3d0:	ed5ff06f          	j	2a4 <.L116>
			3d0: R_RISCV_JAL	.L116

000003d4 <.L126>:
 3d4:	00168693          	addi	a3,a3,1
 3d8:	00d41623          	sh	a3,12(s0)
 3dc:	00478893          	addi	a7,a5,4
 3e0:	00000593          	li	a1,0
 3e4:	00300e93          	li	t4,3

000003e8 <.L129>:
 3e8:	028ace03          	lbu	t3,40(s5) # 5028 <.L162+0x486c>
 3ec:	020e0c63          	beqz	t3,424 <.L128>
			3ec: R_RISCV_BRANCH	.L128
 3f0:	000057b7          	lui	a5,0x5
 3f4:	02578793          	addi	a5,a5,37 # 5025 <.L162+0x4869>
 3f8:	00f587b3          	add	a5,a1,a5
 3fc:	00f487b3          	add	a5,s1,a5
 400:	0007c783          	lbu	a5,0(a5)
 404:	02079063          	bnez	a5,424 <.L128>
			404: R_RISCV_BRANCH	.L128

00000408 <.L131>:
 408:	00158593          	addi	a1,a1,1
 40c:	fdd59ee3          	bne	a1,t4,3e8 <.L129>
			40c: R_RISCV_BRANCH	.L129

00000410 <.L130>:
 410:	000057b7          	lui	a5,0x5
 414:	00f487b3          	add	a5,s1,a5
 418:	0297c783          	lbu	a5,41(a5) # 5029 <.L162+0x486d>
 41c:	dc0794e3          	bnez	a5,1e4 <.L110>
			41c: R_RISCV_BRANCH	.L110
 420:	f79ff06f          	j	398 <.L127>
			420: R_RISCV_JAL	.L127

00000424 <.L128>:
 424:	02c10693          	addi	a3,sp,44
 428:	02810613          	addi	a2,sp,40
 42c:	00048513          	mv	a0,s1
 430:	01112e23          	sw	a7,28(sp)
 434:	00612c23          	sw	t1,24(sp)
 438:	00b12823          	sw	a1,16(sp)
 43c:	01c12a23          	sw	t3,20(sp)
 440:	00000097          	auipc	ra,0x0
			440: R_RISCV_CALL_PLT	bullet_enemy_position
			440: R_RISCV_RELAX	*ABS*
 444:	000080e7          	jalr	ra # 440 <.L128+0x1c>
 448:	02812683          	lw	a3,40(sp)
 44c:	01812303          	lw	t1,24(sp)
 450:	01400613          	li	a2,20
 454:	02c12783          	lw	a5,44(sp)
 458:	40d306b3          	sub	a3,t1,a3
 45c:	00a68693          	addi	a3,a3,10
 460:	01012583          	lw	a1,16(sp)
 464:	01c12883          	lw	a7,28(sp)
 468:	00300e93          	li	t4,3
 46c:	f8d66ee3          	bltu	a2,a3,408 <.L131>
			46c: R_RISCV_BRANCH	.L131
 470:	40f887b3          	sub	a5,a7,a5
 474:	00a78793          	addi	a5,a5,10
 478:	f8f668e3          	bltu	a2,a5,408 <.L131>
			478: R_RISCV_BRANCH	.L131
 47c:	fff00793          	li	a5,-1
 480:	00f41623          	sh	a5,12(s0)
 484:	000057b7          	lui	a5,0x5
 488:	00f487b3          	add	a5,s1,a5
 48c:	0187a783          	lw	a5,24(a5) # 5018 <.L162+0x485c>
 490:	fe600693          	li	a3,-26
 494:	01412e03          	lw	t3,20(sp)
 498:	00f6f463          	bgeu	a3,a5,4a0 <.L132>
			498: R_RISCV_BRANCH	.L132
 49c:	fe600793          	li	a5,-26

000004a0 <.L132>:
 4a0:	000056b7          	lui	a3,0x5
 4a4:	01978793          	addi	a5,a5,25
 4a8:	00d48533          	add	a0,s1,a3
 4ac:	00f52c23          	sw	a5,24(a0)
 4b0:	f60e00e3          	beqz	t3,410 <.L130>
			4b0: R_RISCV_BRANCH	.L130
 4b4:	00b485b3          	add	a1,s1,a1
 4b8:	00b68633          	add	a2,a3,a1
 4bc:	02564683          	lbu	a3,37(a2)
 4c0:	fff68693          	addi	a3,a3,-1 # 4fff <.L162+0x4843>
 4c4:	0ff6f693          	zext.b	a3,a3
 4c8:	02d602a3          	sb	a3,37(a2)
 4cc:	f40692e3          	bnez	a3,410 <.L130>
			4cc: R_RISCV_BRANCH	.L130
 4d0:	f3700693          	li	a3,-201
 4d4:	00f6f463          	bgeu	a3,a5,4dc <.L134>
			4d4: R_RISCV_BRANCH	.L134
 4d8:	f3700793          	li	a5,-201

000004dc <.L134>:
 4dc:	0c878793          	addi	a5,a5,200
 4e0:	000056b7          	lui	a3,0x5
 4e4:	00f52c23          	sw	a5,24(a0)
 4e8:	00d486b3          	add	a3,s1,a3
 4ec:	0246a603          	lw	a2,36(a3) # 5024 <.L162+0x4868>
 4f0:	00000793          	li	a5,0
 4f4:	00861593          	slli	a1,a2,0x8
 4f8:	0105d593          	srli	a1,a1,0x10
 4fc:	00059663          	bnez	a1,508 <.L135>
			4fc: R_RISCV_BRANCH	.L135
 500:	0276c783          	lbu	a5,39(a3)
 504:	0017b793          	seqz	a5,a5

00000508 <.L135>:
 508:	000056b7          	lui	a3,0x5
 50c:	00d486b3          	add	a3,s1,a3
 510:	02f684a3          	sb	a5,41(a3) # 5029 <.L162+0x486d>
 514:	efdff06f          	j	410 <.L130>
			514: R_RISCV_JAL	.L130

00000518 <.L123>:
 518:	028ac603          	lbu	a2,40(s5)
 51c:	00060663          	beqz	a2,528 <.L137>
			51c: R_RISCV_BRANCH	.L137
 520:	00c45783          	lhu	a5,12(s0)
 524:	e7678ae3          	beq	a5,s6,398 <.L127>
			524: R_RISCV_BRANCH	.L127

00000528 <.L137>:
 528:	00042503          	lw	a0,0(s0)
 52c:	7ff50793          	addi	a5,a0,2047
 530:	00fbee63          	bltu	s7,a5,54c <.L138>
			530: R_RISCV_BRANCH	.L138
 534:	00442583          	lw	a1,4(s0)
 538:	ffffc7b7          	lui	a5,0xffffc
 53c:	00f587b3          	add	a5,a1,a5
 540:	00fc6663          	bltu	s8,a5,54c <.L138>
			540: R_RISCV_BRANCH	.L138
 544:	00c45683          	lhu	a3,12(s0)
 548:	01b6ee63          	bltu	a3,s11,564 <.L139>
			548: R_RISCV_BRANCH	.L139

0000054c <.L138>:
 54c:	00000613          	li	a2,0
 550:	000d0593          	mv	a1,s10
 554:	00048513          	mv	a0,s1
 558:	00000097          	auipc	ra,0x0
			558: R_RISCV_CALL_PLT	spawn
			558: R_RISCV_RELAX	*ABS*
 55c:	000080e7          	jalr	ra # 558 <.L138+0xc>
 560:	e39ff06f          	j	398 <.L127>
			560: R_RISCV_JAL	.L127

00000564 <.L139>:
 564:	06060663          	beqz	a2,5d0 <.L140>
			564: R_RISCV_BRANCH	.L140
 568:	01144783          	lbu	a5,17(s0)
 56c:	00300893          	li	a7,3
 570:	17178063          	beq	a5,a7,6d0 <.L141>
			570: R_RISCV_BRANCH	.L141
 574:	00400893          	li	a7,4
 578:	1b178063          	beq	a5,a7,718 <.L142>
			578: R_RISCV_BRANCH	.L142
 57c:	00200893          	li	a7,2
 580:	05179863          	bne	a5,a7,5d0 <.L140>
			580: R_RISCV_BRANCH	.L140
 584:	000007b7          	lui	a5,0x0
			584: R_RISCV_HI20	directions
			584: R_RISCV_RELAX	*ABS*
 588:	03c6f893          	andi	a7,a3,60
 58c:	00078793          	mv	a5,a5
			58c: R_RISCV_LO12_I	directions
			58c: R_RISCV_RELAX	*ABS*
 590:	011787b3          	add	a5,a5,a7
 594:	00079303          	lh	t1,0(a5) # 0 <step>
 598:	0cd00793          	li	a5,205
 59c:	02fd07b3          	mul	a5,s10,a5
 5a0:	00500893          	li	a7,5
 5a4:	00a7d793          	srli	a5,a5,0xa
 5a8:	031787b3          	mul	a5,a5,a7
 5ac:	06000893          	li	a7,96
 5b0:	40fd07b3          	sub	a5,s10,a5
 5b4:	ffe78793          	addi	a5,a5,-2
 5b8:	031787b3          	mul	a5,a5,a7
 5bc:	01f35893          	srli	a7,t1,0x1f
 5c0:	006888b3          	add	a7,a7,t1
 5c4:	4018d893          	srai	a7,a7,0x1
 5c8:	011787b3          	add	a5,a5,a7
 5cc:	00f41423          	sh	a5,8(s0)

000005d0 <.L140>:
 5d0:	00841883          	lh	a7,8(s0)
 5d4:	00a41783          	lh	a5,10(s0)
 5d8:	00168693          	addi	a3,a3,1
 5dc:	00a88533          	add	a0,a7,a0
 5e0:	00b787b3          	add	a5,a5,a1
 5e4:	00a42023          	sw	a0,0(s0)
 5e8:	00f42223          	sw	a5,4(s0)
 5ec:	00d41623          	sh	a3,12(s0)
 5f0:	02060063          	beqz	a2,610 <.L143>
			5f0: R_RISCV_BRANCH	.L143
 5f4:	01144603          	lbu	a2,17(s0)
 5f8:	00500693          	li	a3,5
 5fc:	00d61a63          	bne	a2,a3,610 <.L143>
			5fc: R_RISCV_BRANCH	.L143
 600:	12055a63          	bgez	a0,734 <.L144>
			600: R_RISCV_BRANCH	.L144
 604:	00042023          	sw	zero,0(s0)

00000608 <.L218>:
 608:	411008b3          	neg	a7,a7
 60c:	01141423          	sh	a7,8(s0)

00000610 <.L143>:
 610:	00042683          	lw	a3,0(s0)
 614:	00812703          	lw	a4,8(sp)
 618:	4086d693          	srai	a3,a3,0x8
 61c:	d6e6cee3          	blt	a3,a4,398 <.L127>
			61c: R_RISCV_BRANCH	.L127
 620:	00c12703          	lw	a4,12(sp)
 624:	d6d74ae3          	blt	a4,a3,398 <.L127>
			624: R_RISCV_BRANCH	.L127
 628:	4087d793          	srai	a5,a5,0x8
 62c:	fed98613          	addi	a2,s3,-19
 630:	d6c7c4e3          	blt	a5,a2,398 <.L127>
			630: R_RISCV_BRANCH	.L127
 634:	00c98613          	addi	a2,s3,12
 638:	d6f640e3          	blt	a2,a5,398 <.L127>
			638: R_RISCV_BRANCH	.L127
 63c:	412686b3          	sub	a3,a3,s2
 640:	01368613          	addi	a2,a3,19
 644:	00f44683          	lbu	a3,15(s0)
 648:	413787b3          	sub	a5,a5,s3
 64c:	01378793          	addi	a5,a5,19
 650:	00669693          	slli	a3,a3,0x6
 654:	00f687b3          	add	a5,a3,a5
 658:	02078693          	addi	a3,a5,32
 65c:	000005b7          	lui	a1,0x0
			65c: R_RISCV_HI20	bullet_contact_masks
			65c: R_RISCV_RELAX	*ABS*
 660:	00058593          	mv	a1,a1
			660: R_RISCV_LO12_I	bullet_contact_masks
			660: R_RISCV_RELAX	*ABS*
 664:	00279793          	slli	a5,a5,0x2
 668:	00269693          	slli	a3,a3,0x2
 66c:	00d586b3          	add	a3,a1,a3
 670:	00f585b3          	add	a1,a1,a5
 674:	0005a783          	lw	a5,0(a1) # 0 <step>
 678:	0006a683          	lw	a3,0(a3)
 67c:	00c7d7b3          	srl	a5,a5,a2
 680:	0017f793          	andi	a5,a5,1
 684:	0c078a63          	beqz	a5,758 <.L145>
			684: R_RISCV_BRANCH	.L145
 688:	0c0c9463          	bnez	s9,750 <.L146>
			688: R_RISCV_BRANCH	.L146
 68c:	00005cb7          	lui	s9,0x5
 690:	01948cb3          	add	s9,s1,s9
 694:	024cc783          	lbu	a5,36(s9) # 5024 <.L162+0x4868>
 698:	00000613          	li	a2,0
 69c:	000d0593          	mv	a1,s10
 6a0:	fff78793          	addi	a5,a5,-1
 6a4:	0ff7f793          	zext.b	a5,a5
 6a8:	02fc8223          	sb	a5,36(s9)
 6ac:	00048513          	mv	a0,s1
 6b0:	00f12823          	sw	a5,16(sp)
 6b4:	00000097          	auipc	ra,0x0
			6b4: R_RISCV_CALL_PLT	spawn
			6b4: R_RISCV_RELAX	*ABS*
 6b8:	000080e7          	jalr	ra # 6b4 <.L143+0xa4>
 6bc:	01012783          	lw	a5,16(sp)
 6c0:	08079463          	bnez	a5,748 <.L147>
			6c0: R_RISCV_BRANCH	.L147
 6c4:	007807b7          	lui	a5,0x780
 6c8:	02fca023          	sw	a5,32(s9)
 6cc:	b19ff06f          	j	1e4 <.L110>
			6cc: R_RISCV_JAL	.L110

000006d0 <.L141>:
 6d0:	2ab00893          	li	a7,683
 6d4:	031d07b3          	mul	a5,s10,a7
 6d8:	031688b3          	mul	a7,a3,a7
 6dc:	00b7d793          	srli	a5,a5,0xb
 6e0:	00d8d893          	srli	a7,a7,0xd
 6e4:	011787b3          	add	a5,a5,a7
 6e8:	00f7f793          	andi	a5,a5,15
 6ec:	000008b7          	lui	a7,0x0
			6ec: R_RISCV_HI20	directions
			6ec: R_RISCV_RELAX	*ABS*
 6f0:	00088893          	mv	a7,a7
			6f0: R_RISCV_LO12_I	directions
			6f0: R_RISCV_RELAX	*ABS*
 6f4:	00279793          	slli	a5,a5,0x2
 6f8:	00f887b3          	add	a5,a7,a5
 6fc:	0007d883          	lhu	a7,0(a5) # 780000 <.L162+0x77f844>
 700:	0027d783          	lhu	a5,2(a5)
 704:	00189893          	slli	a7,a7,0x1
 708:	01141423          	sh	a7,8(s0)
 70c:	00179793          	slli	a5,a5,0x1

00000710 <.L217>:
 710:	00f41523          	sh	a5,10(s0)
 714:	ebdff06f          	j	5d0 <.L140>
			714: R_RISCV_JAL	.L140

00000718 <.L142>:
 718:	0076f793          	andi	a5,a3,7
 71c:	ea079ae3          	bnez	a5,5d0 <.L140>
			71c: R_RISCV_BRANCH	.L140
 720:	00a41783          	lh	a5,10(s0)
 724:	37f00893          	li	a7,895
 728:	eaf8c4e3          	blt	a7,a5,5d0 <.L140>
			728: R_RISCV_BRANCH	.L140
 72c:	02078793          	addi	a5,a5,32
 730:	fe1ff06f          	j	710 <.L217>
			730: R_RISCV_JAL	.L217

00000734 <.L144>:
 734:	0003c6b7          	lui	a3,0x3c
 738:	80068693          	addi	a3,a3,-2048 # 3b800 <.L162+0x3b044>
 73c:	eca6dae3          	bge	a3,a0,610 <.L143>
			73c: R_RISCV_BRANCH	.L143
 740:	00d42023          	sw	a3,0(s0)
 744:	ec5ff06f          	j	608 <.L218>
			744: R_RISCV_JAL	.L218

00000748 <.L147>:
 748:	03c00793          	li	a5,60
 74c:	02fc9023          	sh	a5,32(s9)

00000750 <.L146>:
 750:	00100c93          	li	s9,1
 754:	c45ff06f          	j	398 <.L127>
			754: R_RISCV_JAL	.L127

00000758 <.L145>:
 758:	00c6d7b3          	srl	a5,a3,a2
 75c:	0017f793          	andi	a5,a5,1
 760:	c2078ce3          	beqz	a5,398 <.L127>
			760: R_RISCV_BRANCH	.L127
 764:	01044783          	lbu	a5,16(s0)
 768:	c20798e3          	bnez	a5,398 <.L127>
			768: R_RISCV_BRANCH	.L127
 76c:	00100793          	li	a5,1
 770:	00f40823          	sb	a5,16(s0)
 774:	000057b7          	lui	a5,0x5
 778:	00f487b3          	add	a5,s1,a5
 77c:	01c7a683          	lw	a3,28(a5) # 501c <.L162+0x4860>
 780:	fff00613          	li	a2,-1
 784:	00c68663          	beq	a3,a2,790 <.L148>
			784: R_RISCV_BRANCH	.L148
 788:	00168693          	addi	a3,a3,1
 78c:	00d7ae23          	sw	a3,28(a5)

00000790 <.L148>:
 790:	000056b7          	lui	a3,0x5
 794:	00d486b3          	add	a3,s1,a3
 798:	0186a783          	lw	a5,24(a3) # 5018 <.L162+0x485c>
 79c:	ff500613          	li	a2,-11
 7a0:	00f67463          	bgeu	a2,a5,7a8 <.L149>
			7a0: R_RISCV_BRANCH	.L149
 7a4:	ff500793          	li	a5,-11

000007a8 <.L149>:
 7a8:	00a78793          	addi	a5,a5,10
 7ac:	00f6ac23          	sw	a5,24(a3)
 7b0:	be9ff06f          	j	398 <.L127>
			7b0: R_RISCV_JAL	.L127

000007b4 <.L165>:
 7b4:	0f000d93          	li	s11,240
 7b8:	bf1ff06f          	j	3a8 <.L150>
			7b8: R_RISCV_JAL	.L150

000007bc <.L162>:
 7bc:	ff800793          	li	a5,-8
 7c0:	a4dff06f          	j	20c <.L101>
			7c0: R_RISCV_JAL	.L101

Disassembly of section .text.bullet_step:

Disassembly of section .text.bullet_step_player:

Disassembly of section .text.bullet_step_player_cached:

Disassembly of section .text.bullet_prepare_frame:

Disassembly of section .text.bullet_finish_window:

Disassembly of section .text.bullet_shape_opaque:

Disassembly of section .text.sprite:

Disassembly of section .text.build_frame:

Disassembly of section .text.bullet_build_frame:

Disassembly of section .text.bullet_build_frame_player:

Disassembly of section .text.bullet_clip_background_for_hud:
