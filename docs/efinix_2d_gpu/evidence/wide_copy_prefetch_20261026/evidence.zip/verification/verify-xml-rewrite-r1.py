"""Audit this exact compiler formatting rewrite; do not relax the raw input guard."""
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET

out = Path('generated/verification/v3/wide-copy-prefetch-20261026')
frozen = json.loads((out / 'physical-inputs-before-build-r1.json').read_text())
project = Path('D:/efinity_builds/wide_copy_prefetch_20261026_r1/efinix_2d_gpu.xml').resolve()
before = (out / 'pre-build-project-exact.xml').read_bytes()
after = project.read_bytes()
sha = lambda value: hashlib.sha256(value).hexdigest()
assert len(frozen['files']) == 238
assert sha(before) == frozen['files'][str(project)] == 'dc9fef32f3bf19706341daa8fc152026f8c9bd59f4c0cf47d48c60307ea54516'
assert sha(after) == '5171ca183b7fd8e39eff831e25a128860c796d862501adface5da7264fec8f59'
assert ET.tostring(ET.fromstring(before)) == ET.tostring(ET.fromstring(after))
changed = [name for name, expected in frozen['files'].items() if sha(Path(name).read_bytes()) != expected]
assert changed == [str(project)], changed
result = dict(physical_input_files=238, unchanged_raw_input_files=237,
              only_raw_change=str(project), before_sha256=sha(before), after_sha256=sha(after),
              parsed_xml_identical=True, original_raw_guard_rejection_preserved=True,
              note='Exact R1 format-only rewrite of declaration/EOL; no general XML exception')
(out / 'xml-rewrite-audit-r1.json').write_text(json.dumps(result, indent=2))
print(json.dumps(result))
