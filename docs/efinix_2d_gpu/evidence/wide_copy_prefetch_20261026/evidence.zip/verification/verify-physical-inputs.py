import argparse
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET
from zipfile import ZipFile

parser = argparse.ArgumentParser()
parser.add_argument('--new-build', default='D:/efinity_builds/wide_copy_prefetch_20261026_r1')
parser.add_argument('--manifest')
parser.add_argument('--freeze', action='store_true')
args = parser.parse_args()
root = Path.cwd()
out = root / 'generated/verification/v3/wide-copy-prefetch-20261026'
new_build = Path(args.new_build)
old_build = Path('D:/efinity_builds/alpha_early_candidate_20261025_r1')
manifest_path = Path(args.manifest) if args.manifest else out / 'physical-inputs-r1.json'
old_manifest = json.loads((old_build / 'gpu-build.json').read_text(encoding='utf-8-sig'))
new_manifest = json.loads((out / 'rtl-candidate-r1/gpu-build.json').read_text(encoding='utf-8-sig'))
assert json.loads((new_build / 'gpu-build.json').read_text(encoding='utf-8-sig')) == new_manifest
archive = root / 'docs/efinix_2d_gpu/evidence/alpha_early_prefetch_20261025/evidence.zip'
assert hashlib.sha256(archive.read_bytes()).hexdigest() == 'd701a96ef5aa9312bed6b22125f07cc0fa49def317fa891d7e8288a141247a7a'
with ZipFile(archive) as zipped:
    assert json.loads(zipped.read('physical/candidate/gpu-build.json')) == old_manifest
    old_xml = zipped.read('physical/candidate/efinix_2d_gpu.xml')
    old_peri = zipped.read('physical/candidate/efinix_2d_gpu.peri.xml')
assert (old_build / 'efinix_2d_gpu.xml').read_bytes() == old_xml
assert (old_build / 'efinix_2d_gpu.peri.xml').read_bytes() == old_peri
assert (new_build / 'efinix_2d_gpu.peri.xml').read_bytes() == old_peri
paths = set()

def canonical(data, expected):
    tree = ET.fromstring(data)
    nodes = list(tree.iter())
    tops = [n for n in nodes if n.tag.split('}')[-1] == 'design_file'
            and Path(n.attrib['name']).name == 'Efinix2dGpuTop.sv']
    assert len(tops) == 1
    gpu_root = Path(tops[0].attrib['name']).resolve().parent
    selected = {Path(name).as_posix(): digest for name, digest in expected['rtlSha256'].items()}
    found = set()
    for node in nodes:
        kind = node.tag.split('}')[-1]
        if kind in ('design_file', 'sdc_file'):
            path = Path(node.attrib['name']).resolve()
            paths.add(path)
            if path.is_relative_to(gpu_root):
                name = path.relative_to(gpu_root).as_posix()
                assert name in selected and hashlib.sha256(path.read_bytes()).hexdigest() == selected[name]
                node.attrib['name'] = '@SELECTED_GPU/' + name
                found.add(name)
        elif kind == 'ip':
            settings = Path(node.attrib['path']).resolve()
            assert settings.is_file()
            paths.add(settings)
            for child in node:
                if child.tag.split('}')[-1] == 'ip_src_file':
                    paths.add(settings.parent / child.attrib['name'])
    assert found == set(selected)
    def freeze(node):
        return [node.tag, sorted(node.attrib.items()), (node.text or '').strip(), [freeze(n) for n in node]]
    return freeze(tree)

old_config = canonical(old_xml, old_manifest)
new_config = canonical((new_build / 'efinix_2d_gpu.xml').read_bytes(), new_manifest)
assert old_config == new_config, 'Physical project device/synthesis/P&R/settings differ beyond selected GPU paths'
for name in ('efinix_2d_gpu.xml', 'efinix_2d_gpu.peri.xml', 'gpu-build.json'):
    paths.update((old_build / name, new_build / name))
paths.update((root / 'board/efinix_ti60/efinix_2d_gpu.xml', root / 'board/efinix_ti60/efinix_2d_gpu.peri.xml'))
roms = sorted(p.name for p in old_build.glob('*.bin'))
assert len(roms) == 4 and sorted(p.name for p in new_build.glob('*.bin')) == roms
rom_source = root / 'board/efinix_ti60/vendor/sapphire_ddr3/par/ddr_demo_ti60/ip/soc'
for name in roms:
    before, after, source = old_build / name, new_build / name, rom_source / name
    assert before.read_bytes() == after.read_bytes() == source.read_bytes(), 'SoC ROM mismatch: ' + name
    paths.update((before, after, source))
common = json.loads((root / 'generated/verification/v3/wide-copy-fair-20261024/wide_copy_fair_20261024_r1-board-inputs.json').read_text(encoding='utf-8-sig'))
for record in common:
    path = Path(record['Path'])
    assert hashlib.sha256(path.read_bytes()).hexdigest() == record['Sha256']
    paths.add(path)
frozen = {str(path.resolve()): hashlib.sha256(path.read_bytes()).hexdigest() for path in sorted(paths)}
result = dict(files=frozen, canonical_project_sha256=hashlib.sha256(json.dumps(old_config).encode()).hexdigest(),
              project_config_matches_archived_control=True, rom_files=4, selected_gpu_features=new_manifest['features'])
if args.freeze:
    assert not manifest_path.exists(), 'Never overwrite a frozen physical input manifest'
    manifest_path.write_text(json.dumps(result, indent=2))
else:
    assert json.loads(manifest_path.read_text()) == result, 'Physical inputs changed since freeze'
print(json.dumps(dict(physical_input_files=len(frozen), project_and_periphery_match=True,
                      soc_roms_match=4, frozen_manifest=str(manifest_path))))

