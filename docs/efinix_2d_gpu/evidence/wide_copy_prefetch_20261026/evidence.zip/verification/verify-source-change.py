import hashlib
import json
from pathlib import Path
from zipfile import ZipFile

root = Path.cwd()
out = root / 'generated/verification/v3/wide-copy-prefetch-20261026'
old_dir = root / 'generated/verification/v3/read-credit-20261025/rtl-candidate-r1'
new_dir = out / 'rtl-candidate-r1'
old = json.loads((old_dir / 'gpu-build.json').read_text())
new = json.loads((new_dir / 'gpu-build.json').read_text())
archive = root / 'docs/efinix_2d_gpu/evidence/read_capacity_admission_20261026/evidence.zip'
assert hashlib.sha256(archive.read_bytes()).hexdigest() == 'e14d63b7ddc278f2120178ca56d1bac8b2f445f71cb0de0e2a9c40c2249c5221'
assert old['features'] == new['features'] and len(new['features']) == 18
assert old['rtlSha256'].keys() == new['rtlSha256'].keys()
rtl_delta = []
for name, expected in new['rtlSha256'].items():
    assert hashlib.sha256((old_dir / name).read_bytes()).hexdigest() == old['rtlSha256'][name]
    assert hashlib.sha256((new_dir / name).read_bytes()).hexdigest() == expected
    if expected != old['rtlSha256'][name]:
        rtl_delta.append(name)
assert rtl_delta == ['WideCopyDma.sv', 'verification/assert/WideCopyDma_Verification_Assert.sv'], rtl_delta
assertion = 'verification/assert/WideCopyDma_Verification_Assert.sv'
without_comments = lambda data: '\n'.join(line.split('//')[0].rstrip() for line in data.splitlines())
assert without_comments((old_dir / assertion).read_text()) == without_comments((new_dir / assertion).read_text())
old_digest, new_digest = hashlib.sha256(), hashlib.sha256()
source_delta = []
with ZipFile(archive) as zipped:
    assert any(json.loads(zipped.read(name)) == old for name in zipped.namelist() if name.endswith('gpu-build.json'))
    prefix = 'source/chisel/'
    names = sorted(name for name in zipped.namelist() if name.startswith(prefix + 'src/main/scala/gpu/') and name.endswith('.scala'))
    assert len(names) == 38
    for name in names:
        relative = name[len(prefix):]
        before = zipped.read(name)
        after = (root / 'chisel' / relative).read_bytes()
        assert (out / 'source-snapshot/chisel' / relative).read_bytes() == after
        old_digest.update(relative.encode() + b'\0' + before)
        new_digest.update(relative.encode() + b'\0' + after)
        if before != after:
            source_delta.append(relative)
assert source_delta == ['src/main/scala/gpu/WideCopyDma.scala'], source_delta
assert old_digest.hexdigest() == old['sourceSha256']
assert new_digest.hexdigest() == new['sourceSha256']
result = dict(old_source_sha256=old['sourceSha256'], new_source_sha256=new['sourceSha256'],
              source_delta=source_delta, rtl_delta=rtl_delta, source_files=38, rtl_files=len(new['rtlSha256']),
              identical_features=new['features'], physical_qualified=False, board_tested=False)
(out / 'source-change-verification.json').write_text(json.dumps(result, indent=2))
print(json.dumps({key: value for key, value in result.items() if key != 'identical_features'}))
