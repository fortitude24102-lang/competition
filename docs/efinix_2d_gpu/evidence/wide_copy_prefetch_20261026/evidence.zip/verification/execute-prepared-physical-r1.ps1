$ErrorActionPreference='Stop'
$root='D:/ZYNQ/smallproject/.worktrees/pango-riscv-cpu'
Set-Location $root
$out='generated/verification/v3/wide-copy-prefetch-20261026'
$build='D:/efinity_builds/wide_copy_prefetch_20261026_r1'
if(Test-Path -LiteralPath "$out/compile-candidate-r1.log"){throw 'Compilation was already attempted'}
$manifest=Get-Content -LiteralPath 'D:/efinity/MANIFEST' -Raw
if($manifest -notmatch '(?m)^base_version = 2026\.1\.132\r?$'){throw 'Installed compiler version changed'}
$xml=Get-Content -LiteralPath "$build/efinix_2d_gpu.xml" -Raw
if([regex]::Matches($xml,'sw_version="2025\.2\.288\.3\.8"').Count -ne 1){throw 'Unexpected prepared project metadata'}
if(Test-Path -LiteralPath "$out/pre-normalization-project.xml"){throw 'Preserve the first prepared project'}
Copy-Item -LiteralPath "$build/efinix_2d_gpu.xml" -Destination "$out/pre-normalization-project.xml"
# Align only the file-format version with the actual installed compiler and
# archived control. All device/synthesis/P&R attributes still compare strictly.
$xml.Replace('sw_version="2025.2.288.3.8"','sw_version="2026.1.132"') | Set-Content -LiteralPath "$build/efinix_2d_gpu.xml" -Encoding utf8
Copy-Item -LiteralPath 'D:/efinity/MANIFEST' -Destination "$out/compiler-MANIFEST-r1.txt"
& 'C:/Users/fortiutde/AppData/Local/Programs/Python/Python39/python.exe' "$out/verify-source-change.py"
if($LASTEXITCODE){throw 'Generated source identity failed'}
& 'C:/Users/fortiutde/AppData/Local/Programs/Python/Python39/python.exe' "$out/verify-physical-inputs.py" --manifest "$out/physical-inputs-before-build-r1.json" --freeze
if($LASTEXITCODE){throw 'Complete pre-build freeze failed'}
$common=Get-Content -LiteralPath 'generated/verification/v3/wide-copy-fair-20261024/wide_copy_fair_20261024_r1-board-inputs.json' -Raw|ConvertFrom-Json

Push-Location $build
try {
 & D:/efinity/bin/efx_run.bat efinix_2d_gpu --prj -f compile *> "$root/$out/compile-candidate-r1.log"
 if($LASTEXITCODE -ne 0){throw 'Copy-prefetch physical compilation failed'}
} finally {Pop-Location}
Push-Location $build
try {
 & D:/efinity/bin/efx_run.bat efinix_2d_gpu --prj -f sta_tclsh --tcl_script "$root/scripts/report-net-mailbox-cdc.tcl" *> "$root/$out/cdc-candidate-r1.log"
 if($LASTEXITCODE -ne 0){throw 'Routed CDC extraction failed'}
} finally {Pop-Location}
& scripts/test-net-resource-report.ps1 -BuildDirectory $build -RequireRouted *> "$out/resource-cdc-candidate-r1.log"
$timing=Get-Content -LiteralPath "$build/outflow/efinix_2d_gpu.timing.rpt" -Raw
$rows=[regex]::Matches($timing,'(?m)^\S+\s+\S+\s+(-?[\d.]+)\s+(-?[\d.]+)\s+\(R-R\)\s*$')
if($rows.Count -ne 16 -or @($rows|Where-Object {[double]$_.Groups[2].Value -le 0}).Count){throw 'All16 final setup/hold relationships must have positive slack'}
foreach($f in $common){if((Get-FileHash -LiteralPath $f.Path).Hash.ToLowerInvariant() -ne $f.Sha256){throw 'Shared board input changed during compilation'}}
& 'C:/Users/fortiutde/AppData/Local/Programs/Python/Python39/python.exe' "$out/verify-source-change.py"
if($LASTEXITCODE -ne 0){throw 'Source or generated RTL changed during compilation'}
& 'C:/Users/fortiutde/AppData/Local/Programs/Python/Python39/python.exe' "$out/verify-physical-inputs.py" --new-build $build --manifest "$out/physical-inputs-before-build-r1.json"
if($LASTEXITCODE -ne 0){throw 'Physical configuration/IP/ROM input changed during compilation'}
[ordered]@{physical_qualified=$true;build=$build;bit_sha256=(Get-FileHash -LiteralPath "$build/outflow/efinix_2d_gpu.bit").Hash.ToLowerInvariant();board_tested=$false}|ConvertTo-Json|Set-Content -LiteralPath "$out/physical-result-r1.json" -Encoding utf8
'PASS Copy-prefetch physical area, final timing, routed CDC and input identity gates'


