$ErrorActionPreference='Stop'
Set-Location 'D:/ZYNQ/smallproject/.worktrees/pango-riscv-cpu'
$out='generated/verification/v3/wide-copy-prefetch-20261026'
$build='D:/efinity_builds/wide_copy_prefetch_20261026_r1'
& 'C:/Users/fortiutde/AppData/Local/Programs/Python/Python39/python.exe' "$out/verify-xml-rewrite-r1.py"
if($LASTEXITCODE){throw 'Exact XML formatting audit failed'}
& 'C:/Users/fortiutde/AppData/Local/Programs/Python/Python39/python.exe' "$out/verify-source-change.py"
if($LASTEXITCODE){throw 'Source/RTL identity failed'}
& 'C:/Users/fortiutde/AppData/Local/Programs/Python/Python39/python.exe' "$out/verify-physical-inputs.py" --manifest "$out/physical-inputs-after-build-r1.json" --freeze
if($LASTEXITCODE){throw 'Complete final configuration audit failed'}
$compile=Get-Content -LiteralPath "$out/compile-candidate-r1.log" -Raw
foreach($phase in @('map','interface','pnr','pgm')){if($compile -notmatch ($phase+'\s*:\s*PASS')){throw 'Incomplete compilation'}}
& scripts/test-net-resource-report.ps1 -BuildDirectory $build -RequireRouted *> "$out/final-resource-cdc-r1.log"
$timing=Get-Content -LiteralPath "$build/outflow/efinix_2d_gpu.timing.rpt" -Raw
$rows=[regex]::Matches($timing,'(?m)^\S+\s+\S+\s+(-?[\d.]+)\s+(-?[\d.]+)\s+\(R-R\)\s*$')
if($rows.Count -ne 16 -or @($rows|Where-Object {[double]$_.Groups[2].Value -le 0}).Count){throw 'Strict positive16 timing gate failed'}
& 'C:/Users/fortiutde/AppData/Local/Programs/Python/Python39/python.exe' "$out/verify-physical-inputs.py" --manifest "$out/physical-inputs-after-build-r1.json"
if($LASTEXITCODE){throw 'Final input verification failed'}
[ordered]@{physical_qualified=$true;build=$build;bit_sha256=(Get-FileHash -LiteralPath "$build/outflow/efinix_2d_gpu.bit").Hash.ToLowerInvariant();source_sha256='0a0b96f1a83947ef14d6fc8bf93c82636f0ed682c12fa09dd564880d369d569a';xlr=54349;ram=186;dsp=38;core_setup_ns=0.236;core_hold_ns=0.026;input_audit_files=238;input_scope='238 frozen before build;237 raw unchanged; exact project XML format-only rewrite audited;238 final frozen and checked';board_tested=$false} | ConvertTo-Json -Depth 3 | Set-Content -LiteralPath "$out/physical-result-r1.json" -Encoding utf8
'PASS Copy-prefetch PPA/CDC/strict16 timing and complete input identity; XML rewrite audited separately'
