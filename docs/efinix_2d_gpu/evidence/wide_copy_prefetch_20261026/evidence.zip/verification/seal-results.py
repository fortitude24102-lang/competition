import hashlib
import json
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

root = Path.cwd()
work = root / 'generated/verification/v3/wide-copy-prefetch-20261026'
dest = root / 'docs/efinix_2d_gpu/evidence/wide_copy_prefetch_20261026'
assert not (dest / 'evidence.zip').exists()
payload = {'README.md': (dest / 'README.md').read_bytes()}
for directory in ('rtl-candidate-r1', 'source-snapshot', 'board-aba-r1', 'normal-menu-r1'):
    for file in sorted((work / directory).rglob('*')):
        if file.is_file(): payload[directory + '/' + file.relative_to(work / directory).as_posix()] = file.read_bytes()
for file in sorted(work.iterdir()):
    if file.is_file() and not file.name.startswith('active-') and file.suffix in ('.py', '.ps1', '.log', '.json', '.sh', '.xml', '.txt', '.scala'):
        payload['verification/' + file.name] = file.read_bytes()
manifest = json.loads((work / 'physical-inputs-after-build-r1.json').read_text())
mapping = []
for index, (name, expected) in enumerate(sorted(manifest['files'].items())):
    file = Path(name)
    data = file.read_bytes()
    assert hashlib.sha256(data).hexdigest() == expected
    entry = 'physical-inputs/' + f'{index:03d}-' + file.name
    payload[entry] = data
    mapping.append(dict(original=name, entry=entry, sha256=expected))
assert len(mapping) == 238
payload['physical-input-map.json'] = json.dumps(mapping, indent=2).encode()
build = Path('D:/efinity_builds/wide_copy_prefetch_20261026_r1')
for name in ('efinix_2d_gpu.map.rpt', 'efinix_2d_gpu.hier_util.rpt', 'efinix_2d_gpu.timing.rpt',
             'efinix_2d_gpu.map.v', 'net-mailbox-data.rpt', 'net-mailbox-request.rpt', 'net-mailbox-ack.rpt'):
    payload['physical/' + name] = (build / 'outflow' / name).read_bytes()
identities = (
    ('candidate/efinix_2d_gpu.bit', build / 'outflow/efinix_2d_gpu.bit', 'de149efdc78e1dded2c0e070efe52cd8e5e70fdc52e577dd7061c94902c72879'),
    ('control/efinix_2d_gpu.bit', Path('D:/efinity_builds/read_credit_candidate_20261026_r1/outflow/efinix_2d_gpu.bit'), '6a8d19ddd10f2ac9fbef59d874113206aebfa63fe90268f571830c2e24928442'),
    ('firmware/probe.bin', root / 'generated/verification/v3/cpu-builder-20261025/probe-logic-shift-r1/gpu_demo.bin', 'd731f59769989ee44b49a08709acfeab57cc4bc0d9dad4995ad07185c494d1f6'),
    ('firmware/normal.bin', root / 'generated/verification/v3/cpu-builder-20261025/normal-logic-shift-r1/gpu_demo.bin', '6000d1559cccaa91b340e2881db2afaed5c693cac2aa2e863f0340edb9c50b3c'),
)
for entry, file, expected in identities:
    data = file.read_bytes()
    assert hashlib.sha256(data).hexdigest() == expected
    payload[entry] = data
for name in ('scripts/measure-hud-glyphs-board.ps1', 'scripts/capture-game-probe.ps1', 'scripts/test-game-menu-board.ps1',
             'scripts/test-net-resource-report.ps1', 'scripts/report-net-mailbox-cdc.tcl', 'scripts/compare-gpu-build.ps1',
             'scripts/test-efinix-board.ps1', 'chisel/src/test/scala/gpu/WideCopyDmaSpec.scala',
             'docs/superpowers/plans/2026-10-26-wide-copy-prefetch.md'):
    payload['source/' + name] = (root / name).read_bytes()
control = root / 'generated/verification/v3/read-credit-20261025/rtl-candidate-r1'
for file in sorted(control.rglob('*')):
    if file.is_file(): payload['control-rtl/' + file.relative_to(control).as_posix()] = file.read_bytes()

def check_json(value):
    if isinstance(value, dict):
        assert not any(key.lower() in ('token', 'api_key', 'password', 'secret') for key in value)
        for child in value.values(): check_json(child)
    elif isinstance(value, list):
        for child in value: check_json(child)

for name, data in payload.items():
    if name.endswith('.json'): check_json(json.loads(data.decode('utf-8-sig')))
    elif name.endswith('.jsonl'):
        for line in data.decode('utf-8-sig').splitlines():
            if line.strip(): check_json(json.loads(line))
hashes = {name: hashlib.sha256(data).hexdigest() for name, data in sorted(payload.items())}
summary = dict(payloads=hashes, source_commit='4d8378d', functional_tests=20,
               physical_qualified=True, original_wrapper_exit=1, independent_qualification_exit=0,
               input_audit_files=238, xml_format_only_rewrite=True, board_tested=True,
               board_frames=14400, observed_mean_gain_percent=4 / 8778 * 100, xlr=54349, ram=186, dsp=38,
               selected_for_followup=True, long_qualified=False,
               immutable_control_archive_sha256='e14d63b7ddc278f2120178ca56d1bac8b2f445f71cb0de0e2a9c40c2249c5221')
payload['manifest.json'] = json.dumps(summary, indent=2).encode()
with ZipFile(dest / 'evidence.zip', 'x', compression=ZIP_DEFLATED, compresslevel=9) as archive:
    for name, data in sorted(payload.items()): archive.writestr(name, data)
with ZipFile(dest / 'evidence.zip') as archive:
    assert len(archive.namelist()) == len(payload)
    for name, data in payload.items(): assert archive.read(name) == data
result = dict(bytes=(dest / 'evidence.zip').stat().st_size, entries=len(payload),
              sha256=hashlib.sha256((dest / 'evidence.zip').read_bytes()).hexdigest(), all_payloads_verified=True)
(dest / 'artifact-manifest.json').write_text(json.dumps(result, indent=2))
(dest / 'SHA256SUMS').write_text('\n'.join(digest + '  ' + name for name, digest in hashes.items()) + '\n' + result['sha256'] + '  evidence.zip\n')
print(json.dumps(result))
