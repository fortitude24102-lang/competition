from pathlib import Path

out = Path('generated/verification/v3/wide-copy-prefetch-20261026')
text = Path('generated/verification/v3/read-credit-20261025/run-board-aba-r2.ps1').read_text(encoding='utf-8-sig')
changes = [
    ("$experiment='generated/verification/v3/read-credit-20261025'", "$experiment='generated/verification/v3/wide-copy-prefetch-20261026'"),
    ('$out="$experiment/board-aba-r2"', '$out="$experiment/board-aba-r1"'),
    ("$control='D:/efinity_builds/alpha_early_candidate_20261025_r1/outflow/efinix_2d_gpu.bit'", "$control='D:/efinity_builds/read_credit_candidate_20261026_r1/outflow/efinix_2d_gpu.bit'"),
    ("$candidate='D:/efinity_builds/read_credit_candidate_20261026_r1/outflow/efinix_2d_gpu.bit'", "$candidate='D:/efinity_builds/wide_copy_prefetch_20261026_r1/outflow/efinix_2d_gpu.bit'\n$restoreBit='D:/efinity_builds/alpha_early_candidate_20261025_r1/outflow/efinix_2d_gpu.bit'"),
    ("@($control,'ef240664097d115b1e2fbc60f336a9190d4e8a2941a760642627e3563fcebcb1')", "@($control,'6a8d19ddd10f2ac9fbef59d874113206aebfa63fe90268f571830c2e24928442')"),
    ("@($candidate,'6a8d19ddd10f2ac9fbef59d874113206aebfa63fe90268f571830c2e24928442')", "@($candidate,'de149efdc78e1dded2c0e070efe52cd8e5e70fdc52e577dd7061c94902c72879')"),
    ('foreach($pair in @(', "foreach($pair in @(@($restoreBit,'ef240664097d115b1e2fbc60f336a9190d4e8a2941a760642627e3563fcebcb1'),"),
    ('"$experiment/verify-archived-source-change.py"', "'generated/verification/v3/read-credit-20261025/verify-archived-source-change.py'"),
    ('"$experiment/verify-physical-inputs.py"', '"$experiment/verify-physical-inputs.py" --manifest "$experiment/physical-inputs-after-build-r1.json"'),
    ('-Bit $control -LoadBit', '-Bit $restoreBit -LoadBit'),
    ('new read-credit BIT remains experimental', 'Copy prefetch candidate remains experimental'),
]
for before, after in changes:
    assert text.count(before) == 1, before
    text = text.replace(before, after)
marker = '$bins=Get-Content'
assert text.count(marker) == 1
extra = '''if(!(Get-Content "$experiment/physical-result-r1.json" -Raw|ConvertFrom-Json).physical_qualified){throw 'Physical candidate is not qualified'}
& 'C:/Users/fortiutde/AppData/Local/Programs/Python/Python39/python.exe' "$experiment/verify-source-change.py"
if($LASTEXITCODE){throw 'Copy prefetch source/RTL identity failed'}
& 'C:/Users/fortiutde/AppData/Local/Programs/Python/Python39/python.exe' "$experiment/verify-xml-rewrite-r1.py"
if($LASTEXITCODE){throw 'Exact compiler XML formatting audit failed'}
'''
text = text.replace(marker, extra + marker)
path = out / 'run-board-aba-r1.ps1'
assert not path.exists()
path.write_text(text, encoding='utf-8')
print('PASS prepared isolated E0/0a Copy cohort; restore remains accepted C4 EF')
