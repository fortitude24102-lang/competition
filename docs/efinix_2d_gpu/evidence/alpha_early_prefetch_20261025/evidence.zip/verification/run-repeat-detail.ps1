$ErrorActionPreference='Stop'
Set-Location 'D:/ZYNQ/smallproject/.worktrees/pango-riscv-cpu'
$out='generated/verification/v3/alpha-early-20261025'
$candidate='D:/efinity_builds/alpha_early_candidate_20261025_r1/outflow/efinix_2d_gpu.bit'
$restore='D:/efinity_builds/wide_copy_fair_20261024_r1/outflow/efinix_2d_gpu.bit'
$detail='generated/verification/v3/hardware-limit-20261025/latest-frame-detail-r1/gpu_demo.bin'
if((Get-FileHash -LiteralPath $candidate -Algorithm SHA256).Hash.ToLowerInvariant() -ne 'ef240664097d115b1e2fbc60f336a9190d4e8a2941a760642627e3563fcebcb1'){throw 'Candidate BIT identity mismatch'}
if((Get-FileHash -LiteralPath $restore -Algorithm SHA256).Hash.ToLowerInvariant() -ne '4f19579ced2d8d08a2281292847d56d08c8bc767cc7253a9623c2c389aa81f3a'){throw 'Fallback BIT identity mismatch'}
if((Get-FileHash -LiteralPath $detail -Algorithm SHA256).Hash.ToLowerInvariant() -ne '252c269a2194cab861b675ba5d18a8d8321ed22fdc031c55554a376b04e18d1d'){throw 'Diagnostic BIN identity mismatch'}
if(!(Select-String -LiteralPath "$out/board-analysis-r1.log" -SimpleMatch 'BOARD_IDENTITIES_GOLDEN_AND_HEALTH,PASS')){throw 'Initial A/B/A not accepted'}
$state=Invoke-RestMethod 'http://127.0.0.1:8765/api/status' -TimeoutSec 5
if($state.simulated -or $state.owned -or $state.stale -or !(1024 -band $state.telemetry.raw.status_flags)){throw 'Fresh real released MENU required'}
try {
 & D:/efinity/pgm/bin/ftdi_pgm.bat $candidate -m jtag *> "$out/repeat-candidate-bit-load.log"
 if($LASTEXITCODE -ne 0){throw 'Candidate JTAG load failed'}
 Start-Sleep -Seconds 3
 foreach($run in @(@('candidate-b2',"$out/input-bins/probe1024.bin"),@('candidate-detail-b1',$detail))) {
  $name=$run[0]
  & scripts/capture-game-probe.ps1 -Bin $run[1] -Log "$out/$name-uart.log" -SerialPort COM9 -LogicCopy 1 -SealWords 256 -HudDirect 1 -Seconds 140 *> "$out/$name-capture.log"
  $raw=Get-Content -LiteralPath "$out/$name-uart.log" -Raw
  if($raw -notmatch 'V3_PROBE,target=1024,frames=3600,' -or $raw -notmatch ',under=0,errors=0,' -or $raw -notmatch 'V3_SEAL_STATE,count=600,sealed=1,words=256,offset=9836,crc=a7bd652f'){throw "Incomplete/unhealthy capture: $name"}
  if($raw -notmatch ',visible_min=1006,visible_max=1016,alpha_min=130,alpha_max=131,'){throw "Workload changed: $name"}
  if($name -eq 'candidate-detail-b1' -and $raw -notmatch 'V3_WORST,'){throw 'Worst-frame diagnostic missing'}
  $raw -split '\r?\n'|Where-Object {$_ -match '^V3_WORST|^V3_PROBE,'}
 }
} finally {
 & scripts/test-game-menu-board.ps1 -Bin "$out/input-bins/normal.bin" -Bit $restore -LoadBit -SerialPort COM9 -OutDirectory "$out/after-repeat-menu-r1" -ExpectedBuild 0x20261015 -LevelCount 6 -Python D:/efinity/python311/bin/python.exe *> "$out/after-repeat-menu-r1.log"
 $state=Invoke-RestMethod 'http://127.0.0.1:8765/api/status' -TimeoutSec 5
 if($state.simulated -or $state.owned -or $state.stale -or !(1024 -band $state.telemetry.raw.status_flags)){throw 'Final real normal MENU not fresh/released'}
 $state|ConvertTo-Json -Depth 8|Set-Content -LiteralPath "$out/after-repeat-state-r1.json" -Encoding utf8
 'PASS repeated candidate and diagnostic returned to known normal MENU'
}
