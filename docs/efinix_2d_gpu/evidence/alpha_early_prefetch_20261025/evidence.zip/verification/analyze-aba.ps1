$ErrorActionPreference='Stop'
$experiment=$PSScriptRoot
$rawRoot=Join-Path $experiment 'board-aba-r1'
function Fields([string]$line) {
 $row=@{}
 foreach($match in [regex]::Matches($line,'(?:^|,)([A-Za-z0-9_]+)=([^,\r\n]+)')) {
  $value=$match.Groups[2].Value
  $row[$match.Groups[1].Value]=if($value -match '^\d+$'){[long]$value}else{$value}
 }
 [pscustomobject]$row
}
$variants=@('control-a1','candidate-b1','control-a2')
$results=@();$phaseSets=@();$copySets=@();$fixtures=@();$alphaSets=@()
foreach($name in $variants) {
 $probe=Get-Content -LiteralPath "$rawRoot/$name-probe1024-uart.log"
 $row=Fields (@($probe|Where-Object {$_ -match '^V3_PROBE,'})[0])
 if($row.frames -ne 3600 -or $row.under -ne 0 -or $row.errors -ne 0){throw 'Incomplete/unhealthy normal1024 window'}
 $results+=[pscustomobject]@{Variant=$name;Metrics=$row}
 $phase=@(Get-Content -LiteralPath "$rawRoot/$name-axi-phases-uart.log"|Where-Object {$_ -match '^SPRITE_PHASE,'}|ForEach-Object {Fields $_})
 if($phase.Count -ne 24 -or @($phase|Where-Object {$_.under -ne 0}).Count){throw 'Phase count/health failure'}
 $phaseSets+=,@($phase)
 $fixtures+=,@(Get-Content -LiteralPath "$rawRoot/$name-axi-phases-uart.log"|Where-Object {$_ -match '^SPRITE_FIXTURE,'})
 $copy=@(Get-Content -LiteralPath "$rawRoot/$name-copy-aligned-uart.log"|Where-Object {$_ -match '^COPY_BOARD,'}|ForEach-Object {Fields $_})
 if($copy.Count -ne 4 -or @($copy|Where-Object {$_.mismatch -ne 0 -or $_.under -ne 0 -or $_.failed -ne 0}).Count){throw 'Copy golden/health failure'}
 $copySets+=,@($copy)
 $alpha=@(Get-Content -LiteralPath "$rawRoot/$name-alpha-oracle-uart.log"|Where-Object {$_ -match '^ALPHA_PIPELINE_BOARD,'}|ForEach-Object {Fields $_})
 if($alpha.Count -ne 24){throw 'Incomplete Alpha golden checks'}
 $alphaSets+=,@($alpha)
}
foreach($variant in 1,2) {
 if(@(Compare-Object $fixtures[0] $fixtures[$variant]).Count){throw 'Fixture CRC changed'}
 foreach($i in 0..23) {
  foreach($field in @('target','tick','stage','count','rd','wr','cache')) {
   if($phaseSets[0][$i].$field -cne $phaseSets[$variant][$i].$field){throw "Changed phase identity/bytes: $variant/$i/$field"}
  }
  foreach($field in @('case','width','phase','cached','alpha','pixels','rd','wr','cache')) {
   if($alphaSets[0][$i].$field -cne $alphaSets[$variant][$i].$field){throw "Changed Alpha case/bytes: $variant/$i/$field"}
  }
 }
 foreach($i in 0..3) {
  foreach($field in @('trial','width','height','stride','rd','wr')) {
   if($copySets[0][$i].$field -cne $copySets[$variant][$i].$field){throw 'Copy case/byte identity changed'}
  }
 }
}
$phases=@(foreach($variant in 0..2){foreach($stage in @('BACKGROUND','ALPHA','KEY','FULL')){
 $subset=@($phaseSets[$variant]|Where-Object {$_.target -eq 1040 -and $_.stage -eq $stage})
 [pscustomobject]@{Variant=$variants[$variant];Stage=$stage;MeanUs=[math]::Round(($subset.ticks|Measure-Object -Average).Average/100.0,3)}
}})
$meanA=($results[0].Metrics.work_mean_us+$results[2].Metrics.work_mean_us)/2.0
$workReduction=(1-$results[1].Metrics.work_mean_us/$meanA)*100
$copyMeanA=($copySets[0][0].us+$copySets[2][0].us)/2.0
$copyReduction=(1-$copySets[1][0].us/$copyMeanA)*100
$summary=[ordered]@{Normal1024=$results;Fixed1040=$phases;LargeCopy=@(0..2|ForEach-Object {[pscustomobject]@{Variant=$variants[$_];LargeCopyUs=$copySets[$_][0].us}});WorkReductionPercent=$workReduction;LargeCopyReductionPercent=$copyReduction;FixtureCrcAndPhaseByteIdentity='PASS';CopyGolden='12/12PASS';AlphaGolden='72/72PASS';StrictStable60=$false;ChallengeRun=$false;Restored='Known wide Copy BIT plus shape-phase normal six-level MENU'}
$summary|ConvertTo-Json -Depth 8|Set-Content -LiteralPath "$experiment/board-summary.json" -Encoding utf8
$results | ForEach-Object {[pscustomobject]@{Variant=$_.Variant;FPS=$_.Metrics.fps_x10/10;MeanMs=$_.Metrics.work_mean_us/1000.0;MaxMs=$_.Metrics.work_max_us/1000.0;OverBudget=$_.Metrics.work_miss;Late=$_.Metrics.late_present;Under=$_.Metrics.under;Errors=$_.Metrics.errors}}|Format-Table -AutoSize
$phases|Format-Table -AutoSize
"WORK_REDUCTION_PERCENT=$workReduction COPY_REDUCTION_PERCENT=$copyReduction"
'BOARD_IDENTITIES_GOLDEN_AND_HEALTH,PASS'
