set -euo pipefail
export JAVA_HOME=/mnt/d/Chisel-environment/wsl/java17-root/usr/lib/jvm/java-17-openjdk-amd64
export CHISEL_FIRTOOL_CACHE=/mnt/d/Chisel-environment/wsl/firtool-cache
unset CHISEL_FIRTOOL_PATH
cd /mnt/d/ZYNQ/smallproject/.worktrees/pango-riscv-cpu/chisel
IFS= read -r dependencies < target/streams/compile/dependencyClasspath/_global/streams/export
dependencies=${dependencies%$'\r'}
classpath="target/scala-2.13/classes:$dependencies"
flags=(--instances --frame-lists --key-prefetch --scanout-word-pipeline --transform-blit
  --alpha-pipeline --axi-diagnostics --key-write-pipeline --extended-list-arena
  --small-copy-prefetch --four-write-credits --alpha-row-prefetch --wide-copy-dma --split-verilog)
for variant in control candidate; do
  target="../generated/verification/v3/alpha-early-20261025/rtl-${variant}-eager-r1"
  test ! -e "$target"
  extra=()
  if [ "$variant" = candidate ]; then extra=(--alpha-early-prefetch); fi
  "$JAVA_HOME/bin/java" -Xmx2G -cp "$classpath" gpu.GenerateEfinix2dGpu \
    --target-dir "$target" "${flags[@]}" "${extra[@]}"
done
