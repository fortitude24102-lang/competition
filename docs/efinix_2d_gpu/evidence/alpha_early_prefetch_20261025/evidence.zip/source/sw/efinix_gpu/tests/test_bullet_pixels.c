#define _GNU_SOURCE
#include "bullet_demo.h"
#include "bullet_asset_catalog.h"
#include "perf_demo.h"
#include "hud.h"
#include "network_assets.h"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>

static bullet_state state;
static bullet_stream scene,clipped;
static hud_command_stream hud;
static hud_raster_cache cache;
static uint16_t oracle[960*540];
static gpu_command submitted[BULLET_MAX_COMMANDS];
static unsigned submit_count,wait_count,fetch_count;
static int fail_fetch;
static int cache_load_result;
static uint32_t cache_load_base,cache_load_bytes,cache_load_polls;
int gpu_submit(gpu_device *d,const gpu_command *c,uint32_t polls,uint16_t *tag) {
 assert(d && polls && submit_count<BULLET_MAX_COMMANDS);
 submitted[submit_count++]=*c; *tag=(uint16_t)submit_count; return 0;
}
int gpu_wait_tag(gpu_device *d,uint16_t tag,uint32_t polls) {
 assert(d && polls && tag==submit_count); ++wait_count; return 0;
}
int gpu_texture_cache_load(gpu_device *d,uint32_t base,uint32_t bytes,uint32_t polls) {
 assert(d);
 cache_load_base=base; cache_load_bytes=bytes; cache_load_polls=polls;
 return cache_load_result;
}
int gpu_fill_async(gpu_device *d,uint32_t dst,uint32_t stride,uint16_t w,uint16_t h,uint16_t color,uint16_t *tag) {
 gpu_command c={.op=GPU_OP_FILL,.dst_addr=dst,.dst_stride=stride,.width_pixels=w,.height_pixels=h,.color=color};
 return gpu_submit(d,&c,1,tag);
}
int network_configure(uintptr_t base,uint32_t local,uint32_t peer,uint16_t lp,uint16_t pp) {
 assert(base==GPU_APB_BASE && local && peer && lp==8080 && pp==8080); return 0;
}
int network_asset_fetch(uintptr_t base,uint32_t hz,uint32_t session,uint32_t id,
 uint32_t dst,uint32_t bytes,uint32_t crc,network_asset_report *r) {
 assert(base==GPU_APB_BASE && hz==100000000 && session==7);
 assert(id==101+fetch_count);
 assert(dst==(id==101?BULLET_BACKGROUND_ADDR:BULLET_ATLAS_ADDR));
 assert(bytes==(id==101?GPU_FRAME_BYTES:BULLET_ATLAS_BYTES));
 assert(crc==(id==101?BULLET_BACKGROUND_CRC:BULLET_ATLAS_CRC));
 ++fetch_count; *r=(network_asset_report){0};
 if(fail_fetch==(int)id) {
  memset((void *)(uintptr_t)BULLET_BACKGROUND_ADDR,0x55,GPU_FRAME_BYTES);
  memset((void *)(uintptr_t)BULLET_ATLAS_ADDR,0x55,BULLET_ATLAS_BYTES);
  return NETWORK_TIMEOUT; /* Model an abort that leaves writes pending. */
 }
 memcpy((void *)(uintptr_t)dst,(void *)(uintptr_t)(id==101?BULLET_LOCAL_BACKGROUND:BULLET_LOCAL_ATLAS),bytes);
 return 0;
}
static void compare_file(const char *path,uint32_t address,unsigned bytes) {
 FILE *f=fopen(path,"rb"); assert(f);
 for(unsigned i=0;i<bytes;i++) assert(fgetc(f)==((const unsigned char *)(uintptr_t)address)[i]);
 assert(fgetc(f)==EOF); assert(!fclose(f));
}
/* Independent scalar oracle, also emits the actual scene's pixel-pipe inputs.
 * Background is read before each operation, so overlaps and skipped key writes
 * affect subsequent alpha inputs. No golden_renderer/rgb565 helpers are used. */
static unsigned reference(const gpu_command *commands,unsigned count,FILE *vectors) {
 unsigned total=0;
 for(unsigned n=0;n<count;n++) {
  const gpu_command *c=&commands[n];
  unsigned off=(c->dst_addr-GPU_FRAMEBUFFER_A)/2;
  const uint16_t *src=(const uint16_t *)(uintptr_t)c->src_addr;
  for(unsigned y=0;y<c->height_pixels;y++) for(unsigned x=0;x<c->width_pixels;x++) {
   uint16_t *p=&oracle[off+y*960+x],bg=*p;
   uint16_t fg=c->op==GPU_OP_FILL?0:src[y*(c->src_stride/2)+x],pixel=fg;
   unsigned write=c->op!=GPU_OP_COLOR_KEY || fg!=c->color_key;
   if(c->op==GPU_OP_FILL) pixel=c->color;
   if(c->op==GPU_OP_ALPHA) {
    unsigned a=c->alpha,b=255-a;
    unsigned r=(((fg>>11)&31)*a+((bg>>11)&31)*b+127)/255;
    unsigned g=(((fg>>5)&63)*a+((bg>>5)&63)*b+127)/255;
    unsigned bl=((fg&31)*a+(bg&31)*b+127)/255;
    pixel=(uint16_t)((r<<11)|(g<<5)|bl);
   }
   if(vectors) assert(fprintf(vectors,"%x %04x %04x %04x %04x %02x %04x %x\n",
    c->op,fg,bg,c->color,c->color_key,c->alpha,pixel,write)>0);
   if(write) *p=pixel;
   ++total;
  }
 }
 return total;
}
static void compare_hud_clipped_frames(void) {
 static const unsigned ticks[]={0,90,180};
 for(unsigned network=0;network<2;network++) for(unsigned i=0;i<3;i++) {
  uint32_t full_dst=((network+i)&1u)?GPU_FRAMEBUFFER_B:GPU_FRAMEBUFFER_A;
  uint32_t clipped_dst=full_dst==GPU_FRAMEBUFFER_A?GPU_FRAMEBUFFER_B:GPU_FRAMEBUFFER_A;
  assert(!bullet_prepare_frame(&state,64,ticks[i],7));
  state.objects[0].x=100*256; state.objects[0].y=68*256; state.objects[0].shape=0;
  assert(!bullet_build_frame(&state,full_dst,(int)network,1,BULLET_MAX_COMMANDS,&scene));
  assert(!bullet_build_frame(&state,clipped_dst,(int)network,1,BULLET_MAX_COMMANDS,&clipped));
  uint32_t full_pixels=clipped.scene_pixels;
  assert(!bullet_clip_background_for_hud(&clipped,72));
  assert(clipped.commands[0].height_pixels==468);
  assert(clipped.commands[0].src_addr==scene.commands[0].src_addr+138240u);
  assert(clipped.commands[0].dst_addr==clipped_dst+138240u);
  assert(clipped.scene_pixels==full_pixels-69120u);
  hud_comparison metrics={.sprites=(uint16_t)clipped.visible,.gpu_active=1,
   .network_ready=(uint8_t)network,.bullet_demo=1,.gameplay=1,.hp=state.hp,
   .score=state.score,.grazes=state.grazes,.alpha_commands=(uint16_t)clipped.alpha_commands};
  assert(!hud_update_cache(&metrics,&cache,&hud));
  gpu_command full_hud,clipped_hud;
  assert(!hud_cached_command(full_dst,&cache,&full_hud));
  assert(!hud_cached_command(clipped_dst,&cache,&clipped_hud));
  memset((void *)(uintptr_t)full_dst,0x11,GPU_FRAME_BYTES);
  memset((void *)(uintptr_t)clipped_dst,0x22,GPU_FRAME_BYTES);
  assert(!perf_render_cpu(scene.commands,scene.count)); assert(!perf_render_cpu(&full_hud,1));
  assert(!perf_render_cpu(clipped.commands,clipped.count)); assert(!perf_render_cpu(&clipped_hud,1));
  assert(!memcmp((void *)(uintptr_t)full_dst,(void *)(uintptr_t)clipped_dst,GPU_FRAME_BYTES));
 }
}
int main(void) {
 const size_t bytes=0x00d00000u;
 void *memory=mmap((void *)(uintptr_t)GPU_FRAMEBUFFER_A,bytes,PROT_READ|PROT_WRITE,
  MAP_PRIVATE|MAP_ANONYMOUS|MAP_FIXED_NOREPLACE,-1,0);
 assert(memory==(void *)(uintptr_t)GPU_FRAMEBUFFER_A);
 bullet_init_local_assets();
 compare_file("sw/efinix_gpu/assets/bullet/background.rgb565",BULLET_LOCAL_BACKGROUND,GPU_FRAME_BYTES);
 compare_file("sw/efinix_gpu/assets/bullet/atlas.rgb565",BULLET_LOCAL_ATLAS,BULLET_ATLAS_BYTES);
 assert(golden_crc32((void *)(uintptr_t)BULLET_LOCAL_BACKGROUND,GPU_FRAME_BYTES)==BULLET_BACKGROUND_CRC);
 assert(golden_crc32((void *)(uintptr_t)BULLET_LOCAL_ATLAS,BULLET_ATLAS_BYTES)==BULLET_ATLAS_CRC);
 assert(!bullet_prepare_assets(GPU_APB_BASE,7) && fetch_count==2);
 gpu_device cache_device={0};
 assert(!bullet_prepare_texture_cache(&cache_device,0,123));
 assert(cache_load_base==BULLET_ATLAS_ADDR && cache_load_bytes==BULLET_ATLAS_BYTES &&
  cache_load_polls==123);
 for(int failed=101;failed<=102;failed++) {
  fetch_count=0; fail_fetch=failed;
  memset((void *)(uintptr_t)BULLET_LOCAL_BACKGROUND,0xaa,GPU_FRAME_BYTES);
  memset((void *)(uintptr_t)BULLET_LOCAL_ATLAS,0xaa,BULLET_ATLAS_BYTES);
  assert(bullet_prepare_assets(GPU_APB_BASE,7)==NETWORK_TIMEOUT && fetch_count==(unsigned)(failed-100));
  /* Late DMA writes after return cannot corrupt the disjoint fallback. */
  memset((void *)(uintptr_t)BULLET_BACKGROUND_ADDR,0xee,GPU_FRAME_BYTES);
  memset((void *)(uintptr_t)BULLET_ATLAS_ADDR,0xee,BULLET_ATLAS_BYTES);
  compare_file("sw/efinix_gpu/assets/bullet/background.rgb565",BULLET_LOCAL_BACKGROUND,GPU_FRAME_BYTES);
  compare_file("sw/efinix_gpu/assets/bullet/atlas.rgb565",BULLET_LOCAL_ATLAS,BULLET_ATLAS_BYTES);
  cache_load_result=GPU_DRIVER_HARDWARE;
  uint32_t atlas_crc=golden_crc32((void *)(uintptr_t)BULLET_LOCAL_ATLAS,BULLET_ATLAS_BYTES);
  assert(!bullet_prepare_frame(&state,32,37,7));
  assert(!bullet_build_frame(&state,GPU_FRAMEBUFFER_A,0,1,BULLET_MAX_COMMANDS,&scene));
  memset((void *)(uintptr_t)GPU_FRAMEBUFFER_A,0,GPU_FRAME_BYTES);
  assert(!perf_render_cpu(scene.commands,scene.count));
  uint32_t cpu_crc=golden_crc32((void *)(uintptr_t)GPU_FRAMEBUFFER_A,GPU_FRAME_BYTES);
  memset((void *)(uintptr_t)GPU_FRAMEBUFFER_A,0,GPU_FRAME_BYTES);
  assert(bullet_prepare_texture_cache(&cache_device,NETWORK_TIMEOUT,456)==GPU_DRIVER_HARDWARE);
  assert(cache_load_base==BULLET_LOCAL_ATLAS && cache_load_bytes==BULLET_ATLAS_BYTES &&
   cache_load_polls==456);
  assert(golden_crc32((void *)(uintptr_t)BULLET_LOCAL_ATLAS,BULLET_ATLAS_BYTES)==atlas_crc);
  assert(!perf_render_cpu(scene.commands,scene.count));
  assert(golden_crc32((void *)(uintptr_t)GPU_FRAMEBUFFER_A,GPU_FRAME_BYTES)==cpu_crc);
  cache_load_result=0;
 }
 fail_fetch=0; fetch_count=0;
 assert(!bullet_prepare_assets(GPU_APB_BASE,7));
 compare_hud_clipped_frames();
 unsigned tiers[]={32,64,128,256,512};
 for(unsigned t=0;t<5;t++) {
  assert(!bullet_prepare_frame(&state,tiers[t],37,7));
  /* Deliberate overlap and both-axis clipping, not just nicely spaced objects. */
  state.objects[0].x=-3*256; state.objects[0].y=70*256;
  state.objects[1].x=959*256; state.objects[1].y=539*256;
  state.objects[2].x=480*256; state.objects[2].y=480*256;
  assert(!bullet_build_frame(&state,GPU_FRAMEBUFFER_A,t%2u,1,BULLET_MAX_COMMANDS,&scene));
  assert(!perf_render_cpu(scene.commands,scene.count));
  memset(oracle,0,sizeof oracle);
  reference(scene.commands,scene.count,NULL);
  assert(!memcmp(oracle,(void *)(uintptr_t)GPU_FRAMEBUFFER_A,GPU_FRAME_BYTES));
  assert(scene.scene_pixels<=GPU_FRAME_WIDTH*GPU_FRAME_HEIGHT+tiers[t]*64u+1456u+(BULLET_MAX_TRAILS+1u)*144u);
 }
 /* Validate clipped visibility against real atlas bytes, not the analytic
  * mask helper used by the renderer. Includes left/right/HUD/bottom corners. */
 static const int positions[][2]={{-7,100},{-4,70},{959,100},{958,539},
  {0,65},{-7,539},{957,537},{950,500}};
 for(unsigned shape=0;shape<6;shape++) for(unsigned p=0;p<8;p++) {
  assert(!bullet_reset(&state,1,7));
  int x=positions[p][0],y=positions[p][1];
  state.objects[0].shape=(uint8_t)shape;
  state.objects[0].x=x*256; state.objects[0].y=y*256;
  const uint16_t *tile=(const uint16_t *)(uintptr_t)(BULLET_LOCAL_ATLAS+shape*128u);
  unsigned visible=0;
  for(int ty=0;ty<8;ty++) for(int tx=0;tx<8;tx++)
   if(x+tx>=0 && x+tx<960 && y+ty>=72 && y+ty<540 && tile[ty*8+tx]!=BULLET_COLOR_KEY) visible=1;
  assert(!bullet_build_frame(&state,GPU_FRAMEBUFFER_A,0,1,BULLET_MAX_COMMANDS,&scene));
  assert(scene.visible==visible);
 }
 /* Representative frame for real RTL: all background, 128 bullets, player,
  * three Alpha emitter halos, keyed aircraft and cached comparison HUD. */
 assert(!bullet_prepare_frame(&state,128,90,7));
 assert(!bullet_build_frame(&state,GPU_FRAMEBUFFER_A,0,1,BULLET_MAX_COMMANDS,&scene));
 gpu_device d={0};
 assert(!perf_render_gpu(&d,scene.commands,scene.count,100));
 assert(submit_count==scene.count && wait_count==1);
 for(unsigned i=0;i<scene.count;i++) {
  assert(submitted[i].op==scene.commands[i].op);
  assert(submitted[i].src_addr==scene.commands[i].src_addr);
  assert(submitted[i].dst_addr==scene.commands[i].dst_addr);
 }
 hud_comparison m={.sprites=128,.gpu_active=1,.network_ready=0};
 m.bullet_demo=1; m.underflows=17; m.error_code=3;
 char lines[HUD_COMPARISON_LINES][HUD_COMPARISON_COLUMNS];
 assert(!hud_comparison_text(&m,lines));
 assert(strstr(lines[2],"BULLETS 128"));
 assert(strstr(lines[3],"UFL 17 ERR 3"));
 m.underflows=0; m.error_code=0; /* Preview is not a fabricated board failure. */
 m.sprites=(uint16_t)scene.visible;
 m.gameplay=1; m.hp=state.hp; m.score=state.score; m.grazes=state.grazes;
 m.invulnerable=state.invulnerable!=0; m.game_over=state.hp==0;
 m.alpha_commands=(uint16_t)scene.alpha_commands;
 assert(!hud_build_comparison(GPU_FRAMEBUFFER_A,&m,&hud));
 assert(!perf_render_cpu(scene.commands,scene.count));
 assert(!perf_render_cpu(hud.commands,hud.count));
 assert(!hud_update_cache(&m,&cache,&hud));
 gpu_command cached;
 assert(!hud_cached_command(GPU_FRAMEBUFFER_B,&cache,&cached));
 assert(!perf_render_cpu(&cached,1));
 assert(!memcmp((void *)(uintptr_t)GPU_FRAMEBUFFER_A,(void *)(uintptr_t)GPU_FRAMEBUFFER_B,HUD_CACHE_BYTES));
 assert(!hud_cached_command(GPU_FRAMEBUFFER_A,&cache,&cached));
 assert(!perf_render_cpu(&cached,1));
 FILE *f=fopen("generated/verification/bullet-demo/pixels.txt","w"); assert(f);
 unsigned total=reference(scene.commands,scene.count,f);
 total+=reference(&cached,1,f);
 assert(!fclose(f));
 assert(!memcmp(oracle,(void *)(uintptr_t)GPU_FRAMEBUFFER_A,GPU_FRAME_BYTES));
 f=fopen("generated/verification/bullet-demo/frame.rgb565","wb"); assert(f);
 assert(fwrite(oracle,1,GPU_FRAME_BYTES,f)==GPU_FRAME_BYTES); assert(!fclose(f));
 printf("PASS bullet pixels: tiers=32/64/128/256/512; representative visible=%u commands=%u pixels=%u CRC=%08x\n",
  scene.visible,scene.count,total,golden_crc32(oracle,sizeof oracle));
 printf("PASS bullet gameplay: tick=%u hp=%u score=%u grazes=%u alpha_commands=%u alpha_pixels=%u\n",
  state.tick,state.hp,state.score,state.grazes,scene.alpha_commands,scene.alpha_pixels);
 static const unsigned preview_ticks[]={0,90,110,180};
 for(unsigned sample=0;sample<sizeof preview_ticks/sizeof preview_ticks[0];sample++) {
  unsigned tick=preview_ticks[sample];
  assert(!bullet_prepare_frame(&state,512,tick,7));
  assert(!bullet_build_frame(&state,GPU_FRAMEBUFFER_A,0,1,BULLET_MAX_COMMANDS,&scene));
  m.sprites=(uint16_t)scene.visible;
  m.hp=state.hp; m.score=state.score; m.grazes=state.grazes;
  m.invulnerable=state.invulnerable!=0; m.game_over=state.hp==0;
  m.alpha_commands=(uint16_t)scene.alpha_commands;
  assert(!hud_update_cache(&m,&cache,&hud));
  assert(!hud_cached_command(GPU_FRAMEBUFFER_A,&cache,&cached));
  assert(!perf_render_cpu(scene.commands,scene.count));
  assert(!perf_render_cpu(&cached,1));
  memset(oracle,0,sizeof oracle);
  reference(scene.commands,scene.count,NULL); reference(&cached,1,NULL);
  assert(!memcmp(oracle,(void *)(uintptr_t)GPU_FRAMEBUFFER_A,GPU_FRAME_BYTES));
  char path[128];
  snprintf(path,sizeof path,"generated/verification/bullet-demo/frame512_%03u.rgb565",tick);
  f=fopen(path,"wb"); assert(f);
  assert(fwrite(oracle,1,GPU_FRAME_BYTES,f)==GPU_FRAME_BYTES); assert(!fclose(f));
  printf("PASS preview512: tick=%u visible=%u commands=%u CRC=%08x\n",tick,scene.visible,scene.count,golden_crc32(oracle,sizeof oracle));
  printf("PASS effects512: tick=%u alpha_commands=%u alpha_pixels=%u hp=%u score=%u grazes=%u\n",
   tick,scene.alpha_commands,scene.alpha_pixels,state.hp,state.score,state.grazes);
 }
 /* Controlled collision fixtures, not claimed natural gameplay screenshots. */
 for(unsigned scenario=0;scenario<2;scenario++) {
  assert(!bullet_reset(&state,128,7));
  state.hp=scenario?1:3;
  state.objects[0].x=479*256; state.objects[0].y=476*256;
  state.objects[0].vx=state.objects[0].vy=0;
  assert(!bullet_step(&state) && state.hp==(scenario?0:2));
  assert(!bullet_build_frame(&state,GPU_FRAMEBUFFER_A,0,1,BULLET_MAX_COMMANDS,&scene));
  m.hp=state.hp; m.score=state.score; m.grazes=state.grazes;
  m.invulnerable=state.invulnerable!=0; m.game_over=state.hp==0;
  m.alpha_commands=(uint16_t)scene.alpha_commands; m.sprites=(uint16_t)scene.visible;
  assert(!hud_update_cache(&m,&cache,&hud));
  assert(!hud_cached_command(GPU_FRAMEBUFFER_A,&cache,&cached));
  assert(!perf_render_cpu(scene.commands,scene.count) && !perf_render_cpu(&cached,1));
  memset(oracle,0,sizeof oracle);
  reference(scene.commands,scene.count,NULL); reference(&cached,1,NULL);
  assert(!memcmp(oracle,(void *)(uintptr_t)GPU_FRAMEBUFFER_A,GPU_FRAME_BYTES));
  const char *path=scenario?"generated/verification/bullet-demo/game_over.rgb565":"generated/verification/bullet-demo/shield.rgb565";
  f=fopen(path,"wb"); assert(f);
  assert(fwrite(oracle,1,GPU_FRAME_BYTES,f)==GPU_FRAME_BYTES); assert(!fclose(f));
  printf("PASS scenario: %s hp=%u protection=%u CRC=%08x\n",scenario?"game_over":"shield",state.hp,state.invulnerable,golden_crc32(oracle,sizeof oracle));
 }
 assert(!munmap(memory,bytes));
 return 0;
}
