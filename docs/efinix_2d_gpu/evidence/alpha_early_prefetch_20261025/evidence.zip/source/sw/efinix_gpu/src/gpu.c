#include "gpu.h"
#ifndef GPU_SUBMIT_REVALIDATE
#define GPU_SUBMIT_REVALIDATE 0 /* Same-R7 board gate: small net benefit; 1 restores legacy. */
#endif
#ifndef GPU_SUBMIT_SHADOW
#define GPU_SUBMIT_SHADOW 0 /* Candidate only, requires same-scene board gate. */
#endif
#ifdef GPU_TEST_BACKEND
uint32_t gpu_io_read(uintptr_t a);
void gpu_io_write(uintptr_t a,uint32_t v);
void gpu_io_fence(void);
#else
static uint32_t gpu_io_read(uintptr_t a) { return *(volatile uint32_t *)a; }
static void gpu_io_write(uintptr_t a,uint32_t v) { *(volatile uint32_t *)a=v; }
static void gpu_io_fence(void) { __asm__ volatile("fence iorw,iorw" ::: "memory"); }
#endif

static uint32_t rd(gpu_device *d,unsigned r) { return gpu_io_read(d->base+r); }
static void wr(gpu_device *d,unsigned r,uint32_t v) { gpu_io_write(d->base+r,v); }

static int surface(uint32_t address,uint32_t stride,uint16_t width,uint16_t height) {
 if(!width || !height) return GPU_ERROR_ZERO_SIZE;
 if((address|stride)&1u) return GPU_ERROR_MISALIGNED_ADDRESS;
 uint32_t row=(uint32_t)width*2u;
 if(stride<row) return GPU_ERROR_STRIDE_TOO_SMALL;
 uint64_t end=(uint64_t)address+(uint64_t)(height-1u)*stride+row;
 if(address<GPU_FRAMEBUFFER_A || end>GPU_DDR_END_EXCLUSIVE) return GPU_ERROR_ADDRESS_RANGE;
 return 0;
}

static inline __attribute__((always_inline)) int validate(const gpu_command *c) {
 if(!c) return GPU_DRIVER_ARGUMENT;
 if(c->op==GPU_OP_TRANSFORM) {
  if(!c->width_pixels || !c->height_pixels || !c->src_width_pixels || !c->src_height_pixels)
   return GPU_ERROR_ZERO_SIZE;
  if(c->flags&~GPU_TRANSFORM_FLAGS_MASK) return GPU_ERROR_TRANSFORM_CONFIG;
  uint16_t sw=c->src_width_pixels,sh=c->src_height_pixels;
  int e=surface(c->src_addr,c->src_stride,sw,sh);if(e) return e;
  e=surface(c->dst_addr,c->dst_stride,c->width_pixels,c->height_pixels);if(e) return e;
  uint64_t se=(uint64_t)c->src_addr+(uint64_t)(sh-1u)*c->src_stride+(uint32_t)sw*2u;
  uint64_t de=(uint64_t)c->dst_addr+(uint64_t)(c->height_pixels-1u)*c->dst_stride+(uint32_t)c->width_pixels*2u;
  return (uint64_t)c->src_addr<de && (uint64_t)c->dst_addr<se ? GPU_ERROR_OVERLAPPING_COPY : 0;
 }
 if(c->flags) return GPU_DRIVER_ARGUMENT;
 int e;
 if(c->op==GPU_OP_FILL) return surface(c->dst_addr,c->dst_stride,c->width_pixels,c->height_pixels);
 if(c->op==GPU_OP_PRESENT)
  return c->dst_addr==GPU_FRAMEBUFFER_A || c->dst_addr==GPU_FRAMEBUFFER_B ? 0 : GPU_ERROR_ADDRESS_RANGE;
 if(c->op==GPU_OP_SPARSE) {
  if((c->src_addr&3u) || c->src_addr<GPU_FRAMEBUFFER_A ||
     c->src_addr>GPU_DDR_END_EXCLUSIVE-4u) return (c->src_addr&3u) ?
      GPU_ERROR_MISALIGNED_ADDRESS : GPU_ERROR_ADDRESS_RANGE;
  return surface(c->dst_addr,c->dst_stride,c->width_pixels,c->height_pixels);
 }
 if(c->op!=GPU_OP_COPY && c->op!=GPU_OP_COLOR_KEY && c->op!=GPU_OP_ALPHA)
  return GPU_ERROR_INVALID_OPCODE;
 e=surface(c->src_addr,c->src_stride,c->width_pixels,c->height_pixels); if(e) return e;
 e=surface(c->dst_addr,c->dst_stride,c->width_pixels,c->height_pixels); if(e) return e;
 uint32_t row=(uint32_t)c->width_pixels*2u;
 uint64_t src_end=(uint64_t)c->src_addr+(uint64_t)(c->height_pixels-1u)*c->src_stride+row;
 uint64_t dst_end=(uint64_t)c->dst_addr+(uint64_t)(c->height_pixels-1u)*c->dst_stride+row;
 if((uint64_t)c->src_addr<dst_end && (uint64_t)c->dst_addr<src_end)
  return GPU_ERROR_OVERLAPPING_COPY;
 return 0;
}

static int refresh(gpu_device *d) {
 uint16_t done=0,confirm=0;
 uint8_t error=0;
 for(unsigned attempt=0;attempt<3;attempt++) {
  done=(uint16_t)(rd(d,GPU_REG_LAST_DONE)&GPU_LAST_DONE_MASK);
  error=(uint8_t)(rd(d,GPU_REG_ERROR)&GPU_ERROR_MASK);
  confirm=(uint16_t)(rd(d,GPU_REG_LAST_DONE)&GPU_LAST_DONE_MASK);
  if(done==confirm) break;
  if(attempt==2) return GPU_DRIVER_TAG;
 }
 uint16_t advance=(uint16_t)(done-d->last_done);
 if(advance) {
  /* RTL keeps the first nonzero error sticky, so an in-order LAST_DONE jump
     safely retires every earlier tag in the same batch. */
  if(advance>d->outstanding) return GPU_DRIVER_TAG;
  d->hardware_error=error;
  if(d->hardware_error) return GPU_DRIVER_HARDWARE;
  d->outstanding=(uint8_t)(d->outstanding-advance);
  d->last_done=done;
  d->pending=d->outstanding!=0;
 }
 else {
  d->hardware_error=error;
  if(d->hardware_error) return GPU_DRIVER_HARDWARE;
 }
 return 0;
}

static inline __attribute__((always_inline)) void write_field(gpu_device *d,unsigned r,uint32_t v) {
#if GPU_SUBMIT_SHADOW
 unsigned index=(r-GPU_REG_OP)/4u;
 if(!d->shadow_valid || d->shadow_words[index]!=v) {
  wr(d,r,v);d->shadow_words[index]=v;
 }
#else
 wr(d,r,v);
#endif
}
static inline __attribute__((always_inline)) void write_command(gpu_device *d,const gpu_command *c,uint16_t tag) {
#if GPU_SUBMIT_SHADOW
 /* PRESENT is shared with the pure-CPU comparison; keep its original writes. */
 if(c->op==GPU_OP_PRESENT) d->shadow_valid=0;
#endif
 write_field(d,GPU_REG_OP,c->op); write_field(d,GPU_REG_SRC_ADDR,c->src_addr); write_field(d,GPU_REG_DST_ADDR,c->dst_addr);
 write_field(d,GPU_REG_SIZE,gpu_pack_size(c->width_pixels,c->height_pixels));
 write_field(d,GPU_REG_SRC_STRIDE,c->src_stride); write_field(d,GPU_REG_DST_STRIDE,c->dst_stride);
 write_field(d,GPU_REG_COLOR_KEY,gpu_pack_color_key(c->op==GPU_OP_TRANSFORM ? 0 : c->color,c->color_key));
 write_field(d,GPU_REG_ALPHA_FLAGS,gpu_pack_alpha_flags(c->alpha,c->flags));
 /* Outside the legacy eight-word delta cache: always write optional source size. */
 if(c->op==GPU_OP_TRANSFORM)
  wr(d,GPU_REG_TRANSFORM_SOURCE_SIZE,gpu_pack_size(c->src_width_pixels,c->src_height_pixels));
 wr(d,GPU_REG_TAG,tag);
 gpu_io_fence(); wr(d,GPU_REG_CONTROL,GPU_CONTROL_SUBMIT); gpu_io_fence();
#if GPU_SUBMIT_SHADOW
 d->shadow_valid=1;
#endif
}

int gpu_init(gpu_device *d,uintptr_t base) {
 if(!d || (base&3u)) return GPU_DRIVER_ARGUMENT;
 *d=(gpu_device){.base=base};
 if(rd(d,GPU_REG_ID)!=GPU_ID_VALUE) return GPU_DRIVER_ID;
 if(rd(d,GPU_REG_VERSION)!=GPU_VERSION_VALUE) return GPU_DRIVER_VERSION;
 d->last_done=(uint16_t)(rd(d,GPU_REG_LAST_DONE)&GPU_LAST_DONE_MASK);
 d->next_tag=(uint16_t)(d->last_done+1u);
 d->first_tag=d->next_tag;
 d->ready=1;
 return 0;
}

static inline __attribute__((always_inline)) int try_submit_validated(gpu_device *d,const gpu_command *c,uint16_t *tag) {
 d->hardware_error=(uint8_t)(rd(d,GPU_REG_ERROR)&GPU_ERROR_MASK);
 if(d->hardware_error) return GPU_DRIVER_HARDWARE;
 uint32_t status=rd(d,GPU_REG_STATUS);
 if(c->op==GPU_OP_TRANSFORM && !(status&GPU_STATUS_TRANSFORM_PRESENT)) return GPU_DRIVER_ARGUMENT;
 if(c->op==GPU_OP_TRANSFORM && (c->flags&GPU_TRANSFORM_GRAYSCALE) &&
    !(status&GPU_STATUS_GRAYSCALE_PRESENT)) return GPU_DRIVER_ARGUMENT;
 uint8_t level=(uint8_t)(status&GPU_STATUS_QUEUE_LEVEL_MASK);
 if(level>d->queue_high_watermark) d->queue_high_watermark=level;
 if((status&GPU_STATUS_FULL) || d->outstanding>=GPU_COMMAND_QUEUE_DEPTH) return GPU_DRIVER_AGAIN;
 uint16_t assigned=d->next_tag++;
 write_command(d,c,assigned);
 ++d->submitted_count;
 ++d->outstanding;
 d->pending=1;
 d->pending_tag=assigned;
 if(d->outstanding>d->queue_high_watermark) d->queue_high_watermark=d->outstanding;
 *tag=assigned;
 return 0;
}

int gpu_try_submit(gpu_device *d,const gpu_command *c,uint16_t *tag) {
 if(!d || !d->ready || !tag) return GPU_DRIVER_ARGUMENT;
 int e=validate(c);if(e) return e;
 return try_submit_validated(d,c,tag);
}

int gpu_submit(gpu_device *d,const gpu_command *c,uint32_t poll_limit,uint16_t *tag) {
#if !GPU_SUBMIT_REVALIDATE
 if(!d || !d->ready || !tag) return GPU_DRIVER_ARGUMENT;
 int error=validate(c);if(error) return error;
#endif
 while(1) {
#if GPU_SUBMIT_REVALIDATE
  int e=gpu_try_submit(d,c,tag);
#else
  int e=try_submit_validated(d,c,tag);
#endif
  if(e!=GPU_DRIVER_AGAIN) return e;
  if(!poll_limit--) return GPU_DRIVER_TIMEOUT;
  e=refresh(d); if(e) return e;
 }
}

static int known_tag(const gpu_device *d,uint16_t tag) {
 uint16_t offset=(uint16_t)(tag-d->first_tag);
 return d->submitted_count && (d->submitted_count>UINT16_MAX || offset<d->submitted_count);
}

int gpu_poll(gpu_device *d,uint16_t tag) {
 if(!d || !d->ready) return GPU_DRIVER_ARGUMENT;
 if(!known_tag(d,tag)) return GPU_DRIVER_TAG;
 int e=refresh(d); if(e) return e;
 uint16_t first_pending=(uint16_t)(d->next_tag-d->outstanding);
 if(d->outstanding && (uint16_t)(tag-first_pending)<d->outstanding) return GPU_POLL_PENDING;
 return 0;
}

int gpu_fill_async(gpu_device *d,uint32_t dst,uint32_t stride,uint16_t w,uint16_t h,uint16_t color,uint16_t *tag) {
 gpu_command c={.op=GPU_OP_FILL,.dst_addr=dst,.dst_stride=stride,.width_pixels=w,.height_pixels=h,.color=color};
 return gpu_try_submit(d,&c,tag);
}
int gpu_copy_async(gpu_device *d,uint32_t src,uint32_t dst,uint32_t ss,uint32_t ds,uint16_t w,uint16_t h,uint16_t *tag) {
 gpu_command c={.op=GPU_OP_COPY,.src_addr=src,.dst_addr=dst,.src_stride=ss,.dst_stride=ds,.width_pixels=w,.height_pixels=h};
 return gpu_try_submit(d,&c,tag);
}
int gpu_color_key_async(gpu_device *d,uint32_t src,uint32_t dst,uint32_t ss,uint32_t ds,uint16_t w,uint16_t h,uint16_t key,uint16_t *tag) {
 gpu_command c={.op=GPU_OP_COLOR_KEY,.src_addr=src,.dst_addr=dst,.src_stride=ss,.dst_stride=ds,.width_pixels=w,.height_pixels=h,.color_key=key};
 return gpu_try_submit(d,&c,tag);
}
int gpu_alpha_async(gpu_device *d,uint32_t src,uint32_t dst,uint32_t ss,uint32_t ds,uint16_t w,uint16_t h,uint8_t alpha,uint16_t *tag) {
 gpu_command c={.op=GPU_OP_ALPHA,.src_addr=src,.dst_addr=dst,.src_stride=ss,.dst_stride=ds,.width_pixels=w,.height_pixels=h,.alpha=alpha};
 return gpu_try_submit(d,&c,tag);
}
int gpu_sparse_async(gpu_device *d,uint32_t src,uint32_t dst,uint32_t ds,uint16_t w,uint16_t h,uint16_t *tag) {
 gpu_command c={.op=GPU_OP_SPARSE,.src_addr=src,.dst_addr=dst,.dst_stride=ds,
  .width_pixels=w,.height_pixels=h};
 return gpu_try_submit(d,&c,tag);
}
int gpu_present_async(gpu_device *d,uint32_t back,uint16_t *tag) {
 gpu_command c={.op=GPU_OP_PRESENT,.dst_addr=back,.dst_stride=2,.width_pixels=1,.height_pixels=1};
 return gpu_try_submit(d,&c,tag);
}
int gpu_transform_blit_async(gpu_device *d,uint32_t src,uint32_t dst,uint32_t ss,uint32_t ds,
 uint16_t sw,uint16_t sh,uint16_t w,uint16_t h,uint16_t flags,uint16_t key,uint16_t *tag) {
 gpu_command c={.op=GPU_OP_TRANSFORM,.src_addr=src,.dst_addr=dst,.src_stride=ss,.dst_stride=ds,
  .width_pixels=w,.height_pixels=h,.flags=flags,.color_key=key,
  .src_width_pixels=sw,.src_height_pixels=sh};
 return gpu_try_submit(d,&c,tag);
}
int gpu_wait_tag(gpu_device *d,uint16_t tag,uint32_t poll_limit) {
 if(!d || !d->ready) return GPU_DRIVER_ARGUMENT;
 if(!known_tag(d,tag)) return GPU_DRIVER_TAG;
 while(poll_limit--) {
  int e=gpu_poll(d,tag);
  if(e!=GPU_POLL_PENDING) return e;
 }
 return GPU_DRIVER_TIMEOUT;
}

int gpu_set_qos(gpu_device *d,uint16_t low,uint16_t high,int adaptive) {
 if(!d || !d->ready || low>=high || high>GPU_QOS_LOW_MASK || (adaptive!=0 && adaptive!=1))
  return GPU_DRIVER_ARGUMENT;
 wr(d,GPU_REG_QOS_WATERMARKS,gpu_pack_qos(low,high,adaptive));
 gpu_io_fence();
 return 0;
}

int gpu_clear_perf(gpu_device *d) {
 if(!d || !d->ready) return GPU_DRIVER_ARGUMENT;
 wr(d,GPU_REG_PERF_CONTROL,GPU_PERF_CONTROL_CLEAR);
 gpu_io_fence();
 return 0;
}

static int texture_cache_idle(gpu_device *d) {
 if(!d || !d->ready) return GPU_DRIVER_ARGUMENT;
 if(d->outstanding) return GPU_DRIVER_BUSY;
 uint32_t status=rd(d,GPU_REG_STATUS);
 if(!(status&GPU_STATUS_EMPTY) || (status&GPU_STATUS_BUSY)) return GPU_DRIVER_BUSY;
 if(rd(d,GPU_REG_TEXTURE_CACHE_STATUS)&GPU_TEXTURE_CACHE_STATUS_BUSY)
  return GPU_DRIVER_BUSY;
 return 0;
}

int gpu_texture_cache_load(gpu_device *d,uint32_t base,uint32_t bytes,uint32_t poll_limit) {
 if(!d || !d->ready || (base&3u) || bytes<4u || bytes>4096u || (bytes&3u) ||
    base<GPU_DENSE_ASSETS || (uint64_t)base+bytes>GPU_DDR_END_EXCLUSIVE)
  return GPU_DRIVER_ARGUMENT;
 int e=texture_cache_idle(d); if(e) return e;
 wr(d,GPU_REG_TEXTURE_CACHE_BASE,base);
 wr(d,GPU_REG_TEXTURE_CACHE_BYTES,bytes);
 gpu_io_fence();
 wr(d,GPU_REG_TEXTURE_CACHE_CONTROL,GPU_TEXTURE_CACHE_CONTROL_LOAD);
 gpu_io_fence();
 while(poll_limit--) {
  uint32_t status=rd(d,GPU_REG_TEXTURE_CACHE_STATUS);
  if(status&GPU_TEXTURE_CACHE_STATUS_ERROR) return GPU_DRIVER_HARDWARE;
  if(!(status&GPU_TEXTURE_CACHE_STATUS_BUSY))
   return status&GPU_TEXTURE_CACHE_STATUS_VALID ? 0 : GPU_DRIVER_HARDWARE;
 }
 return GPU_DRIVER_TIMEOUT;
}

int gpu_texture_cache_invalidate(gpu_device *d) {
 int e=texture_cache_idle(d); if(e) return e;
 gpu_io_fence();
 wr(d,GPU_REG_TEXTURE_CACHE_CONTROL,GPU_TEXTURE_CACHE_CONTROL_INVALIDATE);
 gpu_io_fence();
 return 0;
}

static uint64_t read64(gpu_device *d,unsigned low,unsigned high) {
 uint32_t lo=rd(d,low),hi=rd(d,high);
 return ((uint64_t)hi<<32)|lo;
}

int gpu_read_perf_snapshot(gpu_device *d,gpu_perf_snapshot *s) {
 if(!d || !d->ready || !s) return GPU_DRIVER_ARGUMENT;
 wr(d,GPU_REG_PERF_CONTROL,GPU_PERF_CONTROL_SNAPSHOT);
 gpu_io_fence();
 s->cycles=read64(d,GPU_REG_PERF_CYCLES_LO,GPU_REG_PERF_CYCLES_HI);
 s->pixels=read64(d,GPU_REG_PERF_PIXELS_LO,GPU_REG_PERF_PIXELS_HI);
 s->read_bytes=read64(d,GPU_REG_PERF_READ_BYTES_LO,GPU_REG_PERF_READ_BYTES_HI);
 s->write_bytes=read64(d,GPU_REG_PERF_WRITE_BYTES_LO,GPU_REG_PERF_WRITE_BYTES_HI);
 s->stalls=read64(d,GPU_REG_PERF_STALLS_LO,GPU_REG_PERF_STALLS_HI);
 s->underflows=read64(d,GPU_REG_PERF_UNDERFLOWS_LO,GPU_REG_PERF_UNDERFLOWS_HI);
 s->render_grants=read64(d,GPU_REG_PERF_RENDER_GRANTS_LO,GPU_REG_PERF_RENDER_GRANTS_HI);
 s->scanout_grants=read64(d,GPU_REG_PERF_SCANOUT_GRANTS_LO,GPU_REG_PERF_SCANOUT_GRANTS_HI);
 s->cache_bytes=read64(d,GPU_REG_PERF_CACHE_BYTES_LO,GPU_REG_PERF_CACHE_BYTES_HI);
 return 0;
}
