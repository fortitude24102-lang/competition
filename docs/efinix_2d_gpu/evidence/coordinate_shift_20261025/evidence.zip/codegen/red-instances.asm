
D:\ZYNQ\smallproject\.worktrees\pango-riscv-cpu\generated\verification\v3\coordinate-codegen-1aef9f0a10f945c79620ae520f2d12f0/instances.o:     file format elf32-littleriscv


Disassembly of section .text:

00000000 <coordinate>:
       0:	00050793          	mv	a5,a0
       4:	10000513          	li	a0,256
       8:	02a7c533          	div	a0,a5,a0
       c:	0007d863          	bgez	a5,1c <.L1>
      10:	0ff7f793          	zext.b	a5,a5
      14:	00078463          	beqz	a5,1c <.L1>
      18:	fff50513          	addi	a0,a0,-1

0000001c <.L1>:
      1c:	00008067          	ret

00000020 <sprite>:
      20:	fa010113          	addi	sp,sp,-96
      24:	05512223          	sw	s5,68(sp)
      28:	00068a93          	mv	s5,a3
      2c:	06412683          	lw	a3,100(sp)
      30:	04112e23          	sw	ra,92(sp)
      34:	04812c23          	sw	s0,88(sp)
      38:	04912a23          	sw	s1,84(sp)
      3c:	05212823          	sw	s2,80(sp)
      40:	05312623          	sw	s3,76(sp)
      44:	05412423          	sw	s4,72(sp)
      48:	05612023          	sw	s6,64(sp)
      4c:	03712e23          	sw	s7,60(sp)
      50:	03812c23          	sw	s8,56(sp)
      54:	03912a23          	sw	s9,52(sp)
      58:	03a12823          	sw	s10,48(sp)
      5c:	03b12623          	sw	s11,44(sp)
      60:	0006a023          	sw	zero,0(a3)
      64:	3bf00693          	li	a3,959
      68:	04e6d263          	bge	a3,a4,ac <.L7>

0000006c <.L26>:
      6c:	00000513          	li	a0,0

00000070 <.L6>:
      70:	05c12083          	lw	ra,92(sp)
      74:	05812403          	lw	s0,88(sp)
      78:	05412483          	lw	s1,84(sp)
      7c:	05012903          	lw	s2,80(sp)
      80:	04c12983          	lw	s3,76(sp)
      84:	04812a03          	lw	s4,72(sp)
      88:	04412a83          	lw	s5,68(sp)
      8c:	04012b03          	lw	s6,64(sp)
      90:	03c12b83          	lw	s7,60(sp)
      94:	03812c03          	lw	s8,56(sp)
      98:	03412c83          	lw	s9,52(sp)
      9c:	03012d03          	lw	s10,48(sp)
      a0:	02c12d83          	lw	s11,44(sp)
      a4:	06010113          	addi	sp,sp,96
      a8:	00008067          	ret

000000ac <.L7>:
      ac:	410006b3          	neg	a3,a6
      b0:	fae6dee3          	bge	a3,a4,6c <.L26>
      b4:	21b00693          	li	a3,539
      b8:	faf6cae3          	blt	a3,a5,6c <.L26>
      bc:	00058c13          	mv	s8,a1
      c0:	04800593          	li	a1,72
      c4:	410586b3          	sub	a3,a1,a6
      c8:	faf6d2e3          	bge	a3,a5,6c <.L26>
      cc:	00060c93          	mv	s9,a2
      d0:	40e006b3          	neg	a3,a4
      d4:	41f75613          	srai	a2,a4,0x1f
      d8:	00c6f4b3          	and	s1,a3,a2
      dc:	04700613          	li	a2,71
      e0:	00050b93          	mv	s7,a0
      e4:	00088d13          	mv	s10,a7
      e8:	00000413          	li	s0,0
      ec:	00f64463          	blt	a2,a5,f4 <.L11>
      f0:	40f58433          	sub	s0,a1,a5

000000f4 <.L11>:
      f4:	00070993          	mv	s3,a4
      f8:	00075463          	bgez	a4,100 <.L12>
      fc:	00000993          	li	s3,0

00000100 <.L12>:
     100:	00078913          	mv	s2,a5
     104:	04800793          	li	a5,72
     108:	00f95463          	bge	s2,a5,110 <.L13>
     10c:	04800913          	li	s2,72

00000110 <.L13>:
     110:	3c000793          	li	a5,960
     114:	40980733          	sub	a4,a6,s1
     118:	41378a33          	sub	s4,a5,s3
     11c:	01477463          	bgeu	a4,s4,124 <.L14>
     120:	00070a13          	mv	s4,a4

00000124 <.L14>:
     124:	21c00b13          	li	s6,540
     128:	408807b3          	sub	a5,a6,s0
     12c:	412b0b33          	sub	s6,s6,s2
     130:	0167f463          	bgeu	a5,s6,138 <.L15>
     134:	00078b13          	mv	s6,a5

00000138 <.L15>:
     138:	06012703          	lw	a4,96(sp)
     13c:	fff00793          	li	a5,-1
     140:	0af71c63          	bne	a4,a5,1f8 <.L16>

00000144 <.L19>:
     144:	3c000713          	li	a4,960
     148:	02e90733          	mul	a4,s2,a4
     14c:	004ba683          	lw	a3,4(s7)
     150:	ffc00513          	li	a0,-4
     154:	03040433          	mul	s0,s0,a6
     158:	01370733          	add	a4,a4,s3
     15c:	00171713          	slli	a4,a4,0x1
     160:	01970633          	add	a2,a4,s9
     164:	0006a703          	lw	a4,0(a3)
     168:	00940433          	add	s0,s0,s1
     16c:	00141413          	slli	s0,s0,0x1
     170:	f0ec00e3          	beq	s8,a4,70 <.L6>
     174:	000ba783          	lw	a5,0(s7)
     178:	00170593          	addi	a1,a4,1
     17c:	00471713          	slli	a4,a4,0x4
     180:	00e787b3          	add	a5,a5,a4
     184:	fffa8713          	addi	a4,s5,-1
     188:	00173713          	seqz	a4,a4
     18c:	010d1d13          	slli	s10,s10,0x10
     190:	00871713          	slli	a4,a4,0x8
     194:	015d6d33          	or	s10,s10,s5
     198:	01a768b3          	or	a7,a4,s10
     19c:	010b1713          	slli	a4,s6,0x10
     1a0:	00b6a023          	sw	a1,0(a3)
     1a4:	01476733          	or	a4,a4,s4
     1a8:	00e7a623          	sw	a4,12(a5)
     1ac:	0117a023          	sw	a7,0(a5)
     1b0:	00c7a223          	sw	a2,4(a5)
     1b4:	0087a423          	sw	s0,8(a5)
     1b8:	036a07b3          	mul	a5,s4,s6
     1bc:	00c6a703          	lw	a4,12(a3)
     1c0:	00f70733          	add	a4,a4,a5
     1c4:	00e6a623          	sw	a4,12(a3)
     1c8:	00100713          	li	a4,1
     1cc:	00ea9e63          	bne	s5,a4,1e8 <.L25>
     1d0:	0086a703          	lw	a4,8(a3)
     1d4:	00170713          	addi	a4,a4,1
     1d8:	00e6a423          	sw	a4,8(a3)
     1dc:	0106a703          	lw	a4,16(a3)
     1e0:	00f707b3          	add	a5,a4,a5
     1e4:	00f6a823          	sw	a5,16(a3)

000001e8 <.L25>:
     1e8:	06412703          	lw	a4,100(sp)
     1ec:	00100793          	li	a5,1
     1f0:	00f72023          	sw	a5,0(a4)
     1f4:	e79ff06f          	j	6c <.L26>

000001f8 <.L16>:
     1f8:	0084edb3          	or	s11,s1,s0
     1fc:	060d9e63          	bnez	s11,278 <.L30>
     200:	010a6463          	bltu	s4,a6,208 <.L18>
     204:	f50b70e3          	bgeu	s6,a6,144 <.L19>

00000208 <.L18>:
     208:	00000793          	li	a5,0
     20c:	01640733          	add	a4,s0,s6
     210:	014488b3          	add	a7,s1,s4
     214:	04c0006f          	j	260 <.L22>

00000218 <.L21>:
     218:	06012503          	lw	a0,96(sp)
     21c:	000d8613          	mv	a2,s11
     220:	01112e23          	sw	a7,28(sp)
     224:	00e12c23          	sw	a4,24(sp)
     228:	01012a23          	sw	a6,20(sp)
     22c:	00f12823          	sw	a5,16(sp)
     230:	00b12623          	sw	a1,12(sp)
     234:	00000097          	auipc	ra,0x0
     238:	000080e7          	jalr	ra # 234 <.L21+0x1c>
     23c:	01412803          	lw	a6,20(sp)
     240:	01812703          	lw	a4,24(sp)
     244:	01c12883          	lw	a7,28(sp)
     248:	02051463          	bnez	a0,270 <.L31>
     24c:	00c12583          	lw	a1,12(sp)
     250:	01012783          	lw	a5,16(sp)
     254:	00158593          	addi	a1,a1,1

00000258 <.L24>:
     258:	fd15e0e3          	bltu	a1,a7,218 <.L21>

0000025c <.L20>:
     25c:	001d8d93          	addi	s11,s11,1

00000260 <.L22>:
     260:	02edf063          	bgeu	s11,a4,280 <.L23>
     264:	ee0790e3          	bnez	a5,144 <.L19>
     268:	00048593          	mv	a1,s1
     26c:	fedff06f          	j	258 <.L24>

00000270 <.L31>:
     270:	00100793          	li	a5,1
     274:	fe9ff06f          	j	25c <.L20>

00000278 <.L30>:
     278:	00040d93          	mv	s11,s0
     27c:	f8dff06f          	j	208 <.L18>

00000280 <.L23>:
     280:	de0786e3          	beqz	a5,6c <.L26>
     284:	ec1ff06f          	j	144 <.L19>

00000288 <gpu_instances_init>:
     288:	00050793          	mv	a5,a0
     28c:	ff800513          	li	a0,-8
     290:	04078863          	beqz	a5,2e0 <.L38>
     294:	04058663          	beqz	a1,2e0 <.L38>
     298:	0105c703          	lbu	a4,16(a1)
     29c:	04070263          	beqz	a4,2e0 <.L38>
     2a0:	0005a703          	lw	a4,0(a1)
     2a4:	0007a223          	sw	zero,4(a5)
     2a8:	00b7a023          	sw	a1,0(a5)
     2ac:	00872683          	lw	a3,8(a4)
     2b0:	01169613          	slli	a2,a3,0x11
     2b4:	00064663          	bltz	a2,2c0 <.L40>

000002b8 <.L41>:
     2b8:	00000513          	li	a0,0
     2bc:	00008067          	ret

000002c0 <.L40>:
     2c0:	40072683          	lw	a3,1024(a4)
     2c4:	494e5737          	lui	a4,0x494e5
     2c8:	33170713          	addi	a4,a4,817 # 494e5331 <.L283+0x494e4211>
     2cc:	fff00513          	li	a0,-1
     2d0:	00e69863          	bne	a3,a4,2e0 <.L38>
     2d4:	00100713          	li	a4,1
     2d8:	00e78223          	sb	a4,4(a5)
     2dc:	fddff06f          	j	2b8 <.L41>

000002e0 <.L38>:
     2e0:	00008067          	ret

000002e4 <gpu_instances_templates>:
     2e4:	12058263          	beqz	a1,408 <.L54>
     2e8:	ff010113          	addi	sp,sp,-16
     2ec:	00912223          	sw	s1,4(sp)
     2f0:	00112623          	sw	ra,12(sp)
     2f4:	00050493          	mv	s1,a0
     2f8:	00812423          	sw	s0,8(sp)
     2fc:	00100793          	li	a5,1
     300:	00000513          	li	a0,0
     304:	1097e663          	bltu	a5,s1,410 <.L46>
     308:	00058413          	mv	s0,a1
     30c:	1c000613          	li	a2,448
     310:	00000593          	li	a1,0
     314:	00040513          	mv	a0,s0
     318:	00000097          	auipc	ra,0x0
     31c:	000080e7          	jalr	ra # 318 <gpu_instances_templates+0x34>
     320:	0c048063          	beqz	s1,3e0 <.L56>
     324:	02a005b7          	lui	a1,0x2a00
     328:	029007b7          	lui	a5,0x2900

0000032c <.L48>:
     32c:	00f42223          	sw	a5,4(s0)
     330:	78000793          	li	a5,1920
     334:	00f42423          	sw	a5,8(s0)
     338:	00f42623          	sw	a5,12(s0)
     33c:	3c000793          	li	a5,960
     340:	00200713          	li	a4,2
     344:	00f42823          	sw	a5,16(s0)
     348:	000106b7          	lui	a3,0x10
     34c:	21c00793          	li	a5,540
     350:	fffff637          	lui	a2,0xfffff
     354:	00e42023          	sw	a4,0(s0)
     358:	00f42a23          	sw	a5,20(s0)
     35c:	00042c23          	sw	zero,24(s0)
     360:	00100513          	li	a0,1
     364:	01c40413          	addi	s0,s0,28
     368:	00c00713          	li	a4,12
     36c:	50000793          	li	a5,1280
     370:	00100893          	li	a7,1
     374:	78000313          	li	t1,1920
     378:	81f68693          	addi	a3,a3,-2017 # f81f <.L283+0xe6ff>
     37c:	00c00e13          	li	t3,12
     380:	00700e93          	li	t4,7
     384:	00800f13          	li	t5,8
     388:	42060613          	addi	a2,a2,1056 # fffff420 <.L283+0xffffe300>

0000038c <.L49>:
     38c:	00300813          	li	a6,3
     390:	01151463          	bne	a0,a7,398 <.L51>
     394:	00400813          	li	a6,4

00000398 <.L51>:
     398:	00b787b3          	add	a5,a5,a1
     39c:	00f42223          	sw	a5,4(s0)
     3a0:	00171793          	slli	a5,a4,0x1
     3a4:	01042023          	sw	a6,0(s0)
     3a8:	00f42423          	sw	a5,8(s0)
     3ac:	00642623          	sw	t1,12(s0)
     3b0:	00e42823          	sw	a4,16(s0)
     3b4:	00e42a23          	sw	a4,20(s0)
     3b8:	00d42c23          	sw	a3,24(s0)
     3bc:	00150513          	addi	a0,a0,1
     3c0:	01c40413          	addi	s0,s0,28
     3c4:	05c50663          	beq	a0,t3,410 <.L46>
     3c8:	02aef263          	bgeu	t4,a0,3ec <.L52>
     3cc:	03e50863          	beq	a0,t5,3fc <.L57>
     3d0:	00951793          	slli	a5,a0,0x9
     3d4:	00c787b3          	add	a5,a5,a2
     3d8:	01000713          	li	a4,16
     3dc:	fb1ff06f          	j	38c <.L49>

000003e0 <.L56>:
     3e0:	02c005b7          	lui	a1,0x2c00
     3e4:	02b007b7          	lui	a5,0x2b00
     3e8:	f45ff06f          	j	32c <.L48>

000003ec <.L52>:
     3ec:	00751793          	slli	a5,a0,0x7
     3f0:	f0078793          	addi	a5,a5,-256 # 2afff00 <.L283+0x2afede0>
     3f4:	00800713          	li	a4,8
     3f8:	f95ff06f          	j	38c <.L49>

000003fc <.L57>:
     3fc:	01000713          	li	a4,16
     400:	30000793          	li	a5,768
     404:	f89ff06f          	j	38c <.L49>

00000408 <.L54>:
     408:	00000513          	li	a0,0
     40c:	00008067          	ret

00000410 <.L46>:
     410:	00c12083          	lw	ra,12(sp)
     414:	00812403          	lw	s0,8(sp)
     418:	00412483          	lw	s1,4(sp)
     41c:	01010113          	addi	sp,sp,16
     420:	00008067          	ret

00000424 <gpu_instance_expand>:
     424:	28050a63          	beqz	a0,6b8 <.L74>
     428:	00050713          	mv	a4,a0
     42c:	ff800513          	li	a0,-8
     430:	28058c63          	beqz	a1,6c8 <.L107>
     434:	28068a63          	beqz	a3,6c8 <.L107>
     438:	0005a783          	lw	a5,0(a1) # 2c00000 <.L283+0x2bfeee0>
     43c:	fd010113          	addi	sp,sp,-48
     440:	01312e23          	sw	s3,28(sp)
     444:	0187d513          	srli	a0,a5,0x18
     448:	0087d813          	srli	a6,a5,0x8
     44c:	01512a23          	sw	s5,20(sp)
     450:	00060993          	mv	s3,a2
     454:	0107da93          	srli	s5,a5,0x10
     458:	0ff7f613          	zext.b	a2,a5
     45c:	0f07f793          	andi	a5,a5,240
     460:	00f567b3          	or	a5,a0,a5
     464:	02112623          	sw	ra,44(sp)
     468:	02812423          	sw	s0,40(sp)
     46c:	02912223          	sw	s1,36(sp)
     470:	03212023          	sw	s2,32(sp)
     474:	01412c23          	sw	s4,24(sp)
     478:	01612823          	sw	s6,16(sp)
     47c:	01712623          	sw	s7,12(sp)
     480:	01812423          	sw	s8,8(sp)
     484:	01912223          	sw	s9,4(sp)
     488:	0ff87813          	zext.b	a6,a6
     48c:	ff800513          	li	a0,-8
     490:	1e079a63          	bnez	a5,684 <.L64>
     494:	01c00793          	li	a5,28
     498:	02f60633          	mul	a2,a2,a5
     49c:	00c5aa03          	lw	s4,12(a1)
     4a0:	00200893          	li	a7,2
     4a4:	010a1793          	slli	a5,s4,0x10
     4a8:	0107d793          	srli	a5,a5,0x10
     4ac:	010a5313          	srli	t1,s4,0x10
     4b0:	00c70733          	add	a4,a4,a2
     4b4:	00072903          	lw	s2,0(a4)
     4b8:	ffe90613          	addi	a2,s2,-2
     4bc:	1cc8e463          	bltu	a7,a2,684 <.L64>
     4c0:	ffc90893          	addi	a7,s2,-4
     4c4:	0018b893          	seqz	a7,a7
     4c8:	1b089e63          	bne	a7,a6,684 <.L64>
     4cc:	00400513          	li	a0,4
     4d0:	00a90663          	beq	s2,a0,4dc <.L66>
     4d4:	ff800513          	li	a0,-8
     4d8:	1a0a9663          	bnez	s5,684 <.L64>

000004dc <.L66>:
     4dc:	ff800513          	li	a0,-8
     4e0:	1a078263          	beqz	a5,684 <.L64>
     4e4:	1a030063          	beqz	t1,684 <.L64>
     4e8:	01072803          	lw	a6,16(a4)
     4ec:	00010e37          	lui	t3,0x10
     4f0:	ffee0e13          	addi	t3,t3,-2 # fffe <.L283+0xeede>
     4f4:	fff80893          	addi	a7,a6,-1
     4f8:	00010f37          	lui	t5,0x10
     4fc:	191e6463          	bltu	t3,a7,684 <.L64>
     500:	01472e83          	lw	t4,20(a4)
     504:	fffe8893          	addi	a7,t4,-1
     508:	171e6e63          	bltu	t3,a7,684 <.L64>
     50c:	16f86c63          	bltu	a6,a5,684 <.L64>
     510:	166eea63          	bltu	t4,t1,684 <.L64>
     514:	01872b03          	lw	s6,24(a4)
     518:	17eb7663          	bgeu	s6,t5,684 <.L64>
     51c:	0045ab83          	lw	s7,4(a1)
     520:	0085a583          	lw	a1,8(a1)
     524:	00872403          	lw	s0,8(a4)
     528:	00c72483          	lw	s1,12(a4)
     52c:	00472e03          	lw	t3,4(a4)
     530:	00bbe733          	or	a4,s7,a1
     534:	00876733          	or	a4,a4,s0
     538:	00976733          	or	a4,a4,s1
     53c:	01c76733          	or	a4,a4,t3
     540:	00177713          	andi	a4,a4,1
     544:	14071063          	bnez	a4,684 <.L64>
     548:	00179793          	slli	a5,a5,0x1
     54c:	12f46c63          	bltu	s0,a5,684 <.L64>
     550:	12f4ea63          	bltu	s1,a5,684 <.L64>
     554:	fff30313          	addi	t1,t1,-1
     558:	02830fb3          	mul	t6,t1,s0
     55c:	00be0c33          	add	s8,t3,a1
     560:	01cc3733          	sltu	a4,s8,t3
     564:	00181813          	slli	a6,a6,0x1
     568:	00000f13          	li	t5,0
     56c:	028332b3          	mulhu	t0,t1,s0
     570:	018f8533          	add	a0,t6,s8
     574:	01f53e33          	sltu	t3,a0,t6
     578:	00e28eb3          	add	t4,t0,a4
     57c:	01de0e33          	add	t3,t3,t4
     580:	00f50eb3          	add	t4,a0,a5
     584:	00aeb533          	sltu	a0,t4,a0
     588:	029333b3          	mulhu	t2,t1,s1
     58c:	01c50533          	add	a0,a0,t3
     590:	02930e33          	mul	t3,t1,s1
     594:	01778333          	add	t1,a5,s7
     598:	00f33cb3          	sltu	s9,t1,a5
     59c:	00f587b3          	add	a5,a1,a5
     5a0:	00b7b5b3          	sltu	a1,a5,a1
     5a4:	01f78fb3          	add	t6,a5,t6
     5a8:	005585b3          	add	a1,a1,t0
     5ac:	00ffb7b3          	sltu	a5,t6,a5
     5b0:	00b787b3          	add	a5,a5,a1
     5b4:	019383b3          	add	t2,t2,s9
     5b8:	031405b3          	mul	a1,s0,a7
     5bc:	006e0333          	add	t1,t3,t1
     5c0:	01c33e33          	sltu	t3,t1,t3
     5c4:	007e0e33          	add	t3,t3,t2
     5c8:	031438b3          	mulhu	a7,s0,a7
     5cc:	01058833          	add	a6,a1,a6
     5d0:	00b835b3          	sltu	a1,a6,a1
     5d4:	011588b3          	add	a7,a1,a7
     5d8:	0ef8e463          	bltu	a7,a5,6c0 <.L97>
     5dc:	01179463          	bne	a5,a7,5e4 <.L99>
     5e0:	0ff86063          	bltu	a6,t6,6c0 <.L97>

000005e4 <.L99>:
     5e4:	fe0005b7          	lui	a1,0xfe000
     5e8:	00bc0833          	add	a6,s8,a1
     5ec:	018837b3          	sltu	a5,a6,s8
     5f0:	fff70893          	addi	a7,a4,-1
     5f4:	011787b3          	add	a5,a5,a7
     5f8:	0c079463          	bnez	a5,6c0 <.L97>
     5fc:	0cb87263          	bgeu	a6,a1,6c0 <.L97>
     600:	0c051063          	bnez	a0,6c0 <.L97>
     604:	100007b7          	lui	a5,0x10000
     608:	0bd7ec63          	bltu	a5,t4,6c0 <.L97>
     60c:	020005b7          	lui	a1,0x2000
     610:	ff800513          	li	a0,-8
     614:	06bbe863          	bltu	s7,a1,684 <.L64>
     618:	0a0e1463          	bnez	t3,6c0 <.L97>
     61c:	0a67e263          	bltu	a5,t1,6c0 <.L97>
     620:	ffd67613          	andi	a2,a2,-3
     624:	02061263          	bnez	a2,648 <.L71>
     628:	02071063          	bnez	a4,648 <.L71>
     62c:	006c7e63          	bgeu	s8,t1,648 <.L71>
     630:	01dbfc63          	bgeu	s7,t4,648 <.L71>
     634:	00400793          	li	a5,4
     638:	04f91663          	bne	s2,a5,684 <.L64>
     63c:	098b9263          	bne	s7,s8,6c0 <.L97>
     640:	08ef1063          	bne	t5,a4,6c0 <.L97>
     644:	04941063          	bne	s0,s1,684 <.L64>

00000648 <.L71>:
     648:	02000613          	li	a2,32
     64c:	00000593          	li	a1,0
     650:	00068513          	mv	a0,a3
     654:	00000097          	auipc	ra,0x0
     658:	000080e7          	jalr	ra # 654 <.L71+0xc>
     65c:	01852023          	sw	s8,0(a0)
     660:	01752223          	sw	s7,4(a0)
     664:	00852423          	sw	s0,8(a0)
     668:	00952623          	sw	s1,12(a0)
     66c:	01452823          	sw	s4,16(a0)
     670:	01651b23          	sh	s6,22(a0)
     674:	01351d23          	sh	s3,26(a0)
     678:	01250e23          	sb	s2,28(a0)
     67c:	01550ea3          	sb	s5,29(a0)
     680:	00000513          	li	a0,0

00000684 <.L64>:
     684:	02c12083          	lw	ra,44(sp)
     688:	02812403          	lw	s0,40(sp)
     68c:	02412483          	lw	s1,36(sp)
     690:	02012903          	lw	s2,32(sp)
     694:	01c12983          	lw	s3,28(sp)
     698:	01812a03          	lw	s4,24(sp)
     69c:	01412a83          	lw	s5,20(sp)
     6a0:	01012b03          	lw	s6,16(sp)
     6a4:	00c12b83          	lw	s7,12(sp)
     6a8:	00812c03          	lw	s8,8(sp)
     6ac:	00412c83          	lw	s9,4(sp)
     6b0:	03010113          	addi	sp,sp,48
     6b4:	00008067          	ret

000006b8 <.L74>:
     6b8:	ff800513          	li	a0,-8
     6bc:	00008067          	ret

000006c0 <.L97>:
     6c0:	ff800513          	li	a0,-8
     6c4:	fc1ff06f          	j	684 <.L64>

000006c8 <.L107>:
     6c8:	00008067          	ret

000006cc <gpu_instances_program>:
     6cc:	1c050663          	beqz	a0,898 <.L134>
     6d0:	00052783          	lw	a5,0(a0)
     6d4:	fa010113          	addi	sp,sp,-96
     6d8:	04912a23          	sw	s1,84(sp)
     6dc:	04112e23          	sw	ra,92(sp)
     6e0:	04812c23          	sw	s0,88(sp)
     6e4:	05212823          	sw	s2,80(sp)
     6e8:	05312623          	sw	s3,76(sp)
     6ec:	05412423          	sw	s4,72(sp)
     6f0:	05512223          	sw	s5,68(sp)
     6f4:	05612023          	sw	s6,64(sp)
     6f8:	03712e23          	sw	s7,60(sp)
     6fc:	03812c23          	sw	s8,56(sp)
     700:	03912a23          	sw	s9,52(sp)
     704:	00050493          	mv	s1,a0
     708:	16078c63          	beqz	a5,880 <.L112>
     70c:	00058993          	mv	s3,a1
     710:	16058863          	beqz	a1,880 <.L112>
     714:	fff60713          	addi	a4,a2,-1
     718:	00f00693          	li	a3,15
     71c:	00060b93          	mv	s7,a2
     720:	16e6e063          	bltu	a3,a4,880 <.L112>
     724:	00454703          	lbu	a4,4(a0)
     728:	02071e63          	bnez	a4,764 <.L114>

0000072c <.L120>:
     72c:	00000513          	li	a0,0

00000730 <.L110>:
     730:	05c12083          	lw	ra,92(sp)
     734:	05812403          	lw	s0,88(sp)
     738:	05412483          	lw	s1,84(sp)
     73c:	05012903          	lw	s2,80(sp)
     740:	04c12983          	lw	s3,76(sp)
     744:	04812a03          	lw	s4,72(sp)
     748:	04412a83          	lw	s5,68(sp)
     74c:	04012b03          	lw	s6,64(sp)
     750:	03c12b83          	lw	s7,60(sp)
     754:	03812c03          	lw	s8,56(sp)
     758:	03412c83          	lw	s9,52(sp)
     75c:	06010113          	addi	sp,sp,96
     760:	00008067          	ret

00000764 <.L114>:
     764:	00554703          	lbu	a4,5(a0)
     768:	ffd00513          	li	a0,-3
     76c:	fc0712e3          	bnez	a4,730 <.L110>
     770:	0127c703          	lbu	a4,18(a5) # 10000012 <.L283+0xfffeef2>
     774:	fa071ee3          	bnez	a4,730 <.L110>
     778:	0007ab03          	lw	s6,0(a5)
     77c:	008b2903          	lw	s2,8(s6)
     780:	08097913          	andi	s2,s2,128
     784:	fa0916e3          	bnez	s2,730 <.L110>
     788:	00010c37          	lui	s8,0x10
     78c:	00058413          	mv	s0,a1
     790:	00058a13          	mv	s4,a1
     794:	00000a93          	li	s5,0
     798:	02000cb7          	lui	s9,0x2000
     79c:	fffc0c13          	addi	s8,s8,-1 # ffff <.L283+0xeedf>

000007a0 <.L117>:
     7a0:	000a2783          	lw	a5,0(s4)
     7a4:	010a2703          	lw	a4,16(s4)
     7a8:	01010693          	addi	a3,sp,16
     7ac:	ffc78793          	addi	a5,a5,-4
     7b0:	0017b793          	seqz	a5,a5
     7b4:	00879793          	slli	a5,a5,0x8
     7b8:	0157e7b3          	or	a5,a5,s5
     7bc:	00f12023          	sw	a5,0(sp)
     7c0:	014a2783          	lw	a5,20(s4)
     7c4:	01877733          	and	a4,a4,s8
     7c8:	00000613          	li	a2,0
     7cc:	01079793          	slli	a5,a5,0x10
     7d0:	00e7e7b3          	or	a5,a5,a4
     7d4:	00010593          	mv	a1,sp
     7d8:	00098513          	mv	a0,s3
     7dc:	01912223          	sw	s9,4(sp)
     7e0:	00012423          	sw	zero,8(sp)
     7e4:	00f12623          	sw	a5,12(sp)
     7e8:	00000097          	auipc	ra,0x0
     7ec:	000080e7          	jalr	ra # 7e8 <.L117+0x48>
     7f0:	08051863          	bnez	a0,880 <.L112>
     7f4:	001a8793          	addi	a5,s5,1
     7f8:	01ca0a13          	addi	s4,s4,28
     7fc:	08fb9663          	bne	s7,a5,888 <.L124>
     800:	42cb0693          	addi	a3,s6,1068

00000804 <.L119>:
     804:	00042783          	lw	a5,0(s0)
     808:	01010713          	addi	a4,sp,16
     80c:	00f12823          	sw	a5,16(sp)
     810:	00442783          	lw	a5,4(s0)
     814:	00f12a23          	sw	a5,20(sp)
     818:	00842783          	lw	a5,8(s0)
     81c:	00f12c23          	sw	a5,24(sp)
     820:	00c42783          	lw	a5,12(s0)
     824:	00f12e23          	sw	a5,28(sp)
     828:	01042783          	lw	a5,16(s0)
     82c:	02f12023          	sw	a5,32(sp)
     830:	01442783          	lw	a5,20(s0)
     834:	02f12223          	sw	a5,36(sp)
     838:	01842783          	lw	a5,24(s0)
     83c:	412b2623          	sw	s2,1036(s6)
     840:	02f12423          	sw	a5,40(sp)
     844:	410b0793          	addi	a5,s6,1040

00000848 <.L118>:
     848:	00072603          	lw	a2,0(a4)
     84c:	00478793          	addi	a5,a5,4
     850:	00470713          	addi	a4,a4,4
     854:	fec7ae23          	sw	a2,-4(a5)
     858:	fef698e3          	bne	a3,a5,848 <.L118>
     85c:	00190793          	addi	a5,s2,1
     860:	01c40413          	addi	s0,s0,28
     864:	032a9663          	bne	s5,s2,890 <.L125>
     868:	0ff0000f          	fence
     86c:	0004a783          	lw	a5,0(s1)
     870:	0007a783          	lw	a5,0(a5)
     874:	4047a783          	lw	a5,1028(a5)
     878:	0087f793          	andi	a5,a5,8
     87c:	ea0788e3          	beqz	a5,72c <.L120>

00000880 <.L112>:
     880:	ff800513          	li	a0,-8
     884:	eadff06f          	j	730 <.L110>

00000888 <.L124>:
     888:	00078a93          	mv	s5,a5
     88c:	f15ff06f          	j	7a0 <.L117>

00000890 <.L125>:
     890:	00078913          	mv	s2,a5
     894:	f71ff06f          	j	804 <.L119>

00000898 <.L134>:
     898:	ff800513          	li	a0,-8
     89c:	00008067          	ret

000008a0 <gpu_instances_render>:
     8a0:	00051663          	bnez	a0,8ac <.L139>
     8a4:	ff800513          	li	a0,-8
     8a8:	00008067          	ret

000008ac <.L139>:
     8ac:	fa010113          	addi	sp,sp,-96
     8b0:	04812c23          	sw	s0,88(sp)
     8b4:	00052403          	lw	s0,0(a0)
     8b8:	04912a23          	sw	s1,84(sp)
     8bc:	04112e23          	sw	ra,92(sp)
     8c0:	05212823          	sw	s2,80(sp)
     8c4:	05312623          	sw	s3,76(sp)
     8c8:	05412423          	sw	s4,72(sp)
     8cc:	05512223          	sw	s5,68(sp)
     8d0:	05612023          	sw	s6,64(sp)
     8d4:	03712e23          	sw	s7,60(sp)
     8d8:	03812c23          	sw	s8,56(sp)
     8dc:	00050493          	mv	s1,a0
     8e0:	1a040a63          	beqz	s0,a94 <.L149>
     8e4:	00058a13          	mv	s4,a1
     8e8:	1a058663          	beqz	a1,a94 <.L149>
     8ec:	00060913          	mv	s2,a2
     8f0:	1a060263          	beqz	a2,a94 <.L149>
     8f4:	000027b7          	lui	a5,0x2
     8f8:	00f607b3          	add	a5,a2,a5
     8fc:	4907a783          	lw	a5,1168(a5) # 2490 <.L283+0x1370>
     900:	24800713          	li	a4,584
     904:	fff78793          	addi	a5,a5,-1
     908:	18f76663          	bltu	a4,a5,a94 <.L149>
     90c:	00068993          	mv	s3,a3
     910:	18068263          	beqz	a3,a94 <.L149>
     914:	00554783          	lbu	a5,5(a0)
     918:	02078c63          	beqz	a5,950 <.L142>

0000091c <.L143>:
     91c:	ffd00513          	li	a0,-3

00000920 <.L138>:
     920:	05c12083          	lw	ra,92(sp)
     924:	05812403          	lw	s0,88(sp)
     928:	05412483          	lw	s1,84(sp)
     92c:	05012903          	lw	s2,80(sp)
     930:	04c12983          	lw	s3,76(sp)
     934:	04812a03          	lw	s4,72(sp)
     938:	04412a83          	lw	s5,68(sp)
     93c:	04012b03          	lw	s6,64(sp)
     940:	03c12b83          	lw	s7,60(sp)
     944:	03812c03          	lw	s8,56(sp)
     948:	06010113          	addi	sp,sp,96
     94c:	00008067          	ret

00000950 <.L142>:
     950:	01244783          	lbu	a5,18(s0)
     954:	fc0794e3          	bnez	a5,91c <.L143>
     958:	00454783          	lbu	a5,4(a0)
     95c:	04078663          	beqz	a5,9a8 <.L144>
     960:	00042783          	lw	a5,0(s0)
     964:	0087a703          	lw	a4,8(a5)
     968:	08077713          	andi	a4,a4,128
     96c:	fa0718e3          	bnez	a4,91c <.L143>
     970:	0387a703          	lw	a4,56(a5)
     974:	ff900513          	li	a0,-7
     978:	fa0714e3          	bnez	a4,920 <.L138>
     97c:	00a45703          	lhu	a4,10(s0)
     980:	44e7a223          	sw	a4,1092(a5)
     984:	00100713          	li	a4,1
     988:	40e7a423          	sw	a4,1032(a5)
     98c:	0ff0000f          	fence
     990:	0004a783          	lw	a5,0(s1)
     994:	0007a783          	lw	a5,0(a5)
     998:	4047a783          	lw	a5,1028(a5)
     99c:	0087f793          	andi	a5,a5,8
     9a0:	0e079a63          	bnez	a5,a94 <.L149>
     9a4:	00e482a3          	sb	a4,5(s1)

000009a8 <.L144>:
     9a8:	00002b37          	lui	s6,0x2
     9ac:	00011723          	sh	zero,14(sp)
     9b0:	00000a93          	li	s5,0
     9b4:	01690b33          	add	s6,s2,s6

000009b8 <.L145>:
     9b8:	490b2783          	lw	a5,1168(s6) # 2490 <.L283+0x1370>
     9bc:	04faea63          	bltu	s5,a5,a10 <.L155>
     9c0:	00e15583          	lhu	a1,14(sp)
     9c4:	00098613          	mv	a2,s3
     9c8:	00040513          	mv	a0,s0
     9cc:	00000097          	auipc	ra,0x0
     9d0:	000080e7          	jalr	ra # 9cc <.L145+0x14>
     9d4:	f40516e3          	bnez	a0,920 <.L138>
     9d8:	0044c783          	lbu	a5,4(s1)
     9dc:	f40782e3          	beqz	a5,920 <.L138>
     9e0:	0004a783          	lw	a5,0(s1)
     9e4:	00200713          	li	a4,2
     9e8:	0007a783          	lw	a5,0(a5)
     9ec:	40e7a423          	sw	a4,1032(a5)
     9f0:	0ff0000f          	fence
     9f4:	0004a783          	lw	a5,0(s1)
     9f8:	0007a783          	lw	a5,0(a5)
     9fc:	4047a783          	lw	a5,1028(a5)
     a00:	0017f793          	andi	a5,a5,1
     a04:	f0079ce3          	bnez	a5,91c <.L143>
     a08:	000482a3          	sb	zero,5(s1)
     a0c:	f15ff06f          	j	920 <.L138>

00000a10 <.L155>:
     a10:	00a45603          	lhu	a2,10(s0)
     a14:	01010693          	addi	a3,sp,16
     a18:	00090593          	mv	a1,s2
     a1c:	000a0513          	mv	a0,s4
     a20:	00000097          	auipc	ra,0x0
     a24:	000080e7          	jalr	ra # a20 <.L155+0x10>
     a28:	ee051ce3          	bnez	a0,920 <.L138>
     a2c:	0044c783          	lbu	a5,4(s1)
     a30:	02079663          	bnez	a5,a5c <.L159>
     a34:	00e10693          	addi	a3,sp,14
     a38:	00098613          	mv	a2,s3
     a3c:	01010593          	addi	a1,sp,16
     a40:	00040513          	mv	a0,s0
     a44:	00000097          	auipc	ra,0x0
     a48:	000080e7          	jalr	ra # a44 <.L155+0x34>
     a4c:	ec051ae3          	bnez	a0,920 <.L138>

00000a50 <.L154>:
     a50:	001a8a93          	addi	s5,s5,1
     a54:	01090913          	addi	s2,s2,16
     a58:	f61ff06f          	j	9b8 <.L145>

00000a5c <.L159>:
     a5c:	00098b93          	mv	s7,s3
     a60:	00f00c13          	li	s8,15

00000a64 <.L147>:
     a64:	01244783          	lbu	a5,18(s0)
     a68:	02078a63          	beqz	a5,a9c <.L148>
     a6c:	00e45583          	lhu	a1,14(s0)
     a70:	00040513          	mv	a0,s0
     a74:	00000097          	auipc	ra,0x0
     a78:	000080e7          	jalr	ra # a74 <.L147+0x10>
     a7c:	ea0542e3          	bltz	a0,920 <.L138>

00000a80 <.L151>:
     a80:	0004a783          	lw	a5,0(s1)
     a84:	0007a783          	lw	a5,0(a5)
     a88:	4047a703          	lw	a4,1028(a5)
     a8c:	00877693          	andi	a3,a4,8
     a90:	02068663          	beqz	a3,abc <.L180>

00000a94 <.L149>:
     a94:	ff800513          	li	a0,-8
     a98:	e89ff06f          	j	920 <.L138>

00000a9c <.L148>:
     a9c:	0004a783          	lw	a5,0(s1)
     aa0:	0007a783          	lw	a5,0(a5)
     aa4:	0387a783          	lw	a5,56(a5)
     aa8:	0ff7f793          	zext.b	a5,a5
     aac:	00f409a3          	sb	a5,19(s0)
     ab0:	fc0788e3          	beqz	a5,a80 <.L151>
     ab4:	ff900513          	li	a0,-7
     ab8:	e69ff06f          	j	920 <.L138>

00000abc <.L180>:
     abc:	00277713          	andi	a4,a4,2
     ac0:	08070e63          	beqz	a4,b5c <.L152>
     ac4:	01244703          	lbu	a4,18(s0)
     ac8:	08ec6a63          	bltu	s8,a4,b5c <.L152>
     acc:	00092703          	lw	a4,0(s2)
     ad0:	42e7a823          	sw	a4,1072(a5)
     ad4:	00492703          	lw	a4,4(s2)
     ad8:	42e7aa23          	sw	a4,1076(a5)
     adc:	00892703          	lw	a4,8(s2)
     ae0:	42e7ac23          	sw	a4,1080(a5)
     ae4:	00c92703          	lw	a4,12(s2)
     ae8:	42e7ae23          	sw	a4,1084(a5)
     aec:	0ff0000f          	fence
     af0:	0004a783          	lw	a5,0(s1)
     af4:	00100693          	li	a3,1
     af8:	0007a783          	lw	a5,0(a5)
     afc:	44d7a023          	sw	a3,1088(a5)
     b00:	0ff0000f          	fence
     b04:	0004a783          	lw	a5,0(s1)
     b08:	0007a783          	lw	a5,0(a5)
     b0c:	4047a783          	lw	a5,1028(a5)
     b10:	0087f793          	andi	a5,a5,8
     b14:	f80790e3          	bnez	a5,a94 <.L149>
     b18:	00a45703          	lhu	a4,10(s0)
     b1c:	00d408a3          	sb	a3,17(s0)
     b20:	00170793          	addi	a5,a4,1
     b24:	00f41523          	sh	a5,10(s0)
     b28:	00442783          	lw	a5,4(s0)
     b2c:	00e11723          	sh	a4,14(sp)
     b30:	00e41723          	sh	a4,14(s0)
     b34:	00178793          	addi	a5,a5,1
     b38:	00f42223          	sw	a5,4(s0)
     b3c:	01244783          	lbu	a5,18(s0)
     b40:	01444703          	lbu	a4,20(s0)
     b44:	00178793          	addi	a5,a5,1
     b48:	0ff7f793          	zext.b	a5,a5
     b4c:	00f40923          	sb	a5,18(s0)
     b50:	f0f770e3          	bgeu	a4,a5,a50 <.L154>
     b54:	00f40a23          	sb	a5,20(s0)
     b58:	ef9ff06f          	j	a50 <.L154>

00000b5c <.L152>:
     b5c:	fffb8793          	addi	a5,s7,-1
     b60:	000b8663          	beqz	s7,b6c <.L161>
     b64:	00078b93          	mv	s7,a5
     b68:	efdff06f          	j	a64 <.L147>

00000b6c <.L161>:
     b6c:	ffb00513          	li	a0,-5
     b70:	db1ff06f          	j	920 <.L138>

00000b74 <gpu_instances_build_into>:
     b74:	f8010113          	addi	sp,sp,-128
     b78:	06812c23          	sw	s0,120(sp)
     b7c:	08012403          	lw	s0,128(sp)
     b80:	06112e23          	sw	ra,124(sp)
     b84:	06912a23          	sw	s1,116(sp)
     b88:	07212823          	sw	s2,112(sp)
     b8c:	07312623          	sw	s3,108(sp)
     b90:	07412423          	sw	s4,104(sp)
     b94:	07512223          	sw	s5,100(sp)
     b98:	07612023          	sw	s6,96(sp)
     b9c:	05712e23          	sw	s7,92(sp)
     ba0:	05812c23          	sw	s8,88(sp)
     ba4:	05912a23          	sw	s9,84(sp)
     ba8:	05a12823          	sw	s10,80(sp)
     bac:	05b12623          	sw	s11,76(sp)
     bb0:	04041263          	bnez	s0,bf4 <.L186>

00000bb4 <.L188>:
     bb4:	ff800513          	li	a0,-8

00000bb8 <.L185>:
     bb8:	07c12083          	lw	ra,124(sp)
     bbc:	07812403          	lw	s0,120(sp)
     bc0:	07412483          	lw	s1,116(sp)
     bc4:	07012903          	lw	s2,112(sp)
     bc8:	06c12983          	lw	s3,108(sp)
     bcc:	06812a03          	lw	s4,104(sp)
     bd0:	06412a83          	lw	s5,100(sp)
     bd4:	06012b03          	lw	s6,96(sp)
     bd8:	05c12b83          	lw	s7,92(sp)
     bdc:	05812c03          	lw	s8,88(sp)
     be0:	05412c83          	lw	s9,84(sp)
     be4:	05012d03          	lw	s10,80(sp)
     be8:	04c12d83          	lw	s11,76(sp)
     bec:	08010113          	addi	sp,sp,128
     bf0:	00008067          	ret

00000bf4 <.L186>:
     bf4:	00042823          	sw	zero,16(s0)
     bf8:	00042423          	sw	zero,8(s0)
     bfc:	00042623          	sw	zero,12(s0)
     c00:	00042223          	sw	zero,4(s0)
     c04:	00042023          	sw	zero,0(s0)
     c08:	00050493          	mv	s1,a0
     c0c:	fa0504e3          	beqz	a0,bb4 <.L188>
     c10:	00088a13          	mv	s4,a7
     c14:	fa0880e3          	beqz	a7,bb4 <.L188>
     c18:	00003cb7          	lui	s9,0x3
     c1c:	01950cb3          	add	s9,a0,s9
     c20:	00078c13          	mv	s8,a5
     c24:	808ca783          	lw	a5,-2040(s9) # 2808 <.L283+0x16e8>
     c28:	00070a93          	mv	s5,a4
     c2c:	1ff00713          	li	a4,511
     c30:	fff78793          	addi	a5,a5,-1
     c34:	f8f760e3          	bltu	a4,a5,bb4 <.L188>
     c38:	fff80793          	addi	a5,a6,-1
     c3c:	24800713          	li	a4,584
     c40:	00080993          	mv	s3,a6
     c44:	f6f768e3          	bltu	a4,a5,bb4 <.L188>
     c48:	00058913          	mv	s2,a1
     c4c:	00060b93          	mv	s7,a2
     c50:	00068b13          	mv	s6,a3
     c54:	00000097          	auipc	ra,0x0
     c58:	000080e7          	jalr	ra # c54 <.L186+0x60>
     c5c:	f4050ce3          	beqz	a0,bb4 <.L188>
     c60:	000a8663          	beqz	s5,c6c <.L189>
     c64:	829cc783          	lbu	a5,-2007(s9)
     c68:	f40796e3          	bnez	a5,bb4 <.L188>

00000c6c <.L189>:
     c6c:	016bebb3          	or	s7,s7,s6
     c70:	015bebb3          	or	s7,s7,s5
     c74:	00100793          	li	a5,1
     c78:	f377eee3          	bltu	a5,s7,bb4 <.L188>
     c7c:	21b00793          	li	a5,539
     c80:	f387eae3          	bltu	a5,s8,bb4 <.L188>
     c84:	ffe00737          	lui	a4,0xffe00
     c88:	fff70713          	addi	a4,a4,-1 # ffdfffff <.L283+0xffdfeedf>
     c8c:	00e97733          	and	a4,s2,a4
     c90:	020007b7          	lui	a5,0x2000
     c94:	f2f710e3          	bne	a4,a5,bb4 <.L188>
     c98:	78000693          	li	a3,1920
     c9c:	02dc06b3          	mul	a3,s8,a3
     ca0:	21c00713          	li	a4,540
     ca4:	418707b3          	sub	a5,a4,s8
     ca8:	00042703          	lw	a4,0(s0)
     cac:	03412c23          	sw	s4,56(sp)
     cb0:	02812e23          	sw	s0,60(sp)
     cb4:	ffc00513          	li	a0,-4
     cb8:	01268633          	add	a2,a3,s2
     cbc:	04e98263          	beq	s3,a4,d00 <.L190>
     cc0:	00170593          	addi	a1,a4,1
     cc4:	00471713          	slli	a4,a4,0x4
     cc8:	00ea08b3          	add	a7,s4,a4
     ccc:	01079713          	slli	a4,a5,0x10
     cd0:	00b42023          	sw	a1,0(s0)
     cd4:	3c076713          	ori	a4,a4,960
     cd8:	00e8a623          	sw	a4,12(a7)
     cdc:	3c000713          	li	a4,960
     ce0:	02e787b3          	mul	a5,a5,a4
     ce4:	00c42703          	lw	a4,12(s0)
     ce8:	0008a023          	sw	zero,0(a7)
     cec:	00c8a223          	sw	a2,4(a7)
     cf0:	00d8a423          	sw	a3,8(a7)
     cf4:	00000513          	li	a0,0
     cf8:	00f707b3          	add	a5,a4,a5
     cfc:	00f42623          	sw	a5,12(s0)

00000d00 <.L190>:
     d00:	00003d37          	lui	s10,0x3
     d04:	00010337          	lui	t1,0x10
     d08:	00048b93          	mv	s7,s1
     d0c:	00048c93          	mv	s9,s1
     d10:	00000d93          	li	s11,0
     d14:	01a48d33          	add	s10,s1,s10
     d18:	02c10a13          	addi	s4,sp,44
     d1c:	fff00c13          	li	s8,-1
     d20:	00300e13          	li	t3,3
     d24:	fff30313          	addi	t1,t1,-1 # ffff <.L283+0xeedf>

00000d28 <.L191>:
     d28:	00051863          	bnez	a0,d38 <.L195>
     d2c:	000b0663          	beqz	s6,d38 <.L195>
     d30:	808d2783          	lw	a5,-2040(s10) # 2808 <.L283+0x16e8>
     d34:	1afde063          	bltu	s11,a5,ed4 <.L196>

00000d38 <.L195>:
     d38:	01503cb3          	snez	s9,s5
     d3c:	00003a37          	lui	s4,0x3
     d40:	00010db7          	lui	s11,0x10
     d44:	002c8c93          	addi	s9,s9,2
     d48:	00000c13          	li	s8,0
     d4c:	01448a33          	add	s4,s1,s4
     d50:	00500313          	li	t1,5
     d54:	00300e13          	li	t3,3
     d58:	02c10d13          	addi	s10,sp,44
     d5c:	fffd8d93          	addi	s11,s11,-1 # ffff <.L283+0xeedf>

00000d60 <.L199>:
     d60:	06051e63          	bnez	a0,ddc <.L210>
     d64:	808a2783          	lw	a5,-2040(s4) # 2808 <.L283+0x16e8>
     d68:	1efc6e63          	bltu	s8,a5,f64 <.L205>
     d6c:	824a4783          	lbu	a5,-2012(s4)
     d70:	040b0c63          	beqz	s6,dc8 <.L212>
     d74:	06078263          	beqz	a5,dd8 <.L208>
     d78:	80ca2703          	lw	a4,-2036(s4)
     d7c:	810a2783          	lw	a5,-2032(s4)
     d80:	820a5683          	lhu	a3,-2016(s4)
     d84:	ffa70713          	addi	a4,a4,-6
     d88:	ffa78793          	addi	a5,a5,-6 # 1fffffa <.L283+0x1ffeeda>
     d8c:	04000893          	li	a7,64
     d90:	00068463          	beqz	a3,d98 <.L211>
     d94:	0c000893          	li	a7,192

00000d98 <.L211>:
     d98:	02c10693          	addi	a3,sp,44
     d9c:	00d12223          	sw	a3,4(sp)
     da0:	fff00693          	li	a3,-1
     da4:	00d12023          	sw	a3,0(sp)
     da8:	00c00813          	li	a6,12
     dac:	00100693          	li	a3,1
     db0:	00090613          	mv	a2,s2
     db4:	00098593          	mv	a1,s3
     db8:	03810513          	addi	a0,sp,56
     dbc:	00000097          	auipc	ra,0x0
     dc0:	000080e7          	jalr	ra # dbc <.L211+0x24>
     dc4:	00051c63          	bnez	a0,ddc <.L210>

00000dc8 <.L212>:
     dc8:	00003737          	lui	a4,0x3
     dcc:	00e48733          	add	a4,s1,a4
     dd0:	82474783          	lbu	a5,-2012(a4) # 2824 <.L283+0x1704>
     dd4:	22079a63          	bnez	a5,1008 <.L207>

00000dd8 <.L208>:
     dd8:	00000513          	li	a0,0

00000ddc <.L210>:
     ddc:	000037b7          	lui	a5,0x3
     de0:	00f487b3          	add	a5,s1,a5
     de4:	8247c703          	lbu	a4,-2012(a5) # 2824 <.L283+0x1704>
     de8:	05000b93          	li	s7,80
     dec:	02070063          	beqz	a4,e0c <.L213>
     df0:	8147a783          	lw	a5,-2028(a5)
     df4:	03c00713          	li	a4,60
     df8:	02e7f7b3          	remu	a5,a5,a4
     dfc:	02b00713          	li	a4,43
     e00:	00f77663          	bgeu	a4,a5,e0c <.L213>
     e04:	00379793          	slli	a5,a5,0x3
     e08:	ef878b93          	addi	s7,a5,-264

00000e0c <.L213>:
     e0c:	00000db7          	lui	s11,0x0
     e10:	00003a37          	lui	s4,0x3
     e14:	000d8d93          	mv	s11,s11
     e18:	00000d13          	li	s10,0
     e1c:	00300c13          	li	s8,3
     e20:	fff00c93          	li	s9,-1
     e24:	01448a33          	add	s4,s1,s4

00000e28 <.L214>:
     e28:	26051263          	bnez	a0,108c <.L221>
     e2c:	d98d06e3          	beq	s10,s8,bb8 <.L185>
     e30:	020a8263          	beqz	s5,e54 <.L215>
     e34:	828a4783          	lbu	a5,-2008(s4) # 2828 <.L283+0x1708>
     e38:	00078e63          	beqz	a5,e54 <.L215>
     e3c:	000037b7          	lui	a5,0x3
     e40:	82578793          	addi	a5,a5,-2011 # 2825 <.L283+0x1705>
     e44:	00fd07b3          	add	a5,s10,a5
     e48:	00f487b3          	add	a5,s1,a5
     e4c:	0007c783          	lbu	a5,0(a5)
     e50:	06078c63          	beqz	a5,ec8 <.L216>

00000e54 <.L215>:
     e54:	000da783          	lw	a5,0(s11) # 0 <coordinate>
     e58:	02f12823          	sw	a5,48(sp)
     e5c:	004da783          	lw	a5,4(s11)
     e60:	02f12a23          	sw	a5,52(sp)
     e64:	000a8e63          	beqz	s5,e80 <.L217>
     e68:	03410693          	addi	a3,sp,52
     e6c:	03010613          	addi	a2,sp,48
     e70:	000d0593          	mv	a1,s10
     e74:	00048513          	mv	a0,s1
     e78:	00000097          	auipc	ra,0x0
     e7c:	000080e7          	jalr	ra # e78 <.L215+0x24>

00000e80 <.L217>:
     e80:	03012703          	lw	a4,48(sp)
     e84:	03412783          	lw	a5,52(sp)
     e88:	1c0b1263          	bnez	s6,104c <.L218>

00000e8c <.L220>:
     e8c:	02c10793          	addi	a5,sp,44
     e90:	03012703          	lw	a4,48(sp)
     e94:	00f12223          	sw	a5,4(sp)
     e98:	03412783          	lw	a5,52(sp)
     e9c:	01912023          	sw	s9,0(sp)
     ea0:	00000893          	li	a7,0
     ea4:	01000813          	li	a6,16
     ea8:	ff878793          	addi	a5,a5,-8
     eac:	ff870713          	addi	a4,a4,-8
     eb0:	009d0693          	addi	a3,s10,9
     eb4:	00090613          	mv	a2,s2
     eb8:	00098593          	mv	a1,s3
     ebc:	03810513          	addi	a0,sp,56
     ec0:	00000097          	auipc	ra,0x0
     ec4:	000080e7          	jalr	ra # ec0 <.L220+0x34>

00000ec8 <.L216>:
     ec8:	001d0d13          	addi	s10,s10,1
     ecc:	008d8d93          	addi	s11,s11,8
     ed0:	f59ff06f          	j	e28 <.L214>

00000ed4 <.L196>:
     ed4:	000a8e63          	beqz	s5,ef0 <.L192>
     ed8:	00ecc783          	lbu	a5,14(s9)
     edc:	01c78663          	beq	a5,t3,ee8 <.L193>
     ee0:	828d4783          	lbu	a5,-2008(s10)
     ee4:	00078663          	beqz	a5,ef0 <.L192>

00000ee8 <.L193>:
     ee8:	00ccd783          	lhu	a5,12(s9)
     eec:	06678663          	beq	a5,t1,f58 <.L194>

00000ef0 <.L192>:
     ef0:	000ca503          	lw	a0,0(s9)
     ef4:	00000097          	auipc	ra,0x0
     ef8:	000080e7          	jalr	ra # ef4 <.L192+0x4>
     efc:	00a12c23          	sw	a0,24(sp)
     f00:	004ca503          	lw	a0,4(s9)
     f04:	00000097          	auipc	ra,0x0
     f08:	000080e7          	jalr	ra # f04 <.L192+0x14>
     f0c:	804d2883          	lw	a7,-2044(s10)
     f10:	01812703          	lw	a4,24(sp)
     f14:	ffe50793          	addi	a5,a0,-2
     f18:	00f8f893          	andi	a7,a7,15
     f1c:	01088893          	addi	a7,a7,16
     f20:	01412223          	sw	s4,4(sp)
     f24:	01812023          	sw	s8,0(sp)
     f28:	00289893          	slli	a7,a7,0x2
     f2c:	00c00813          	li	a6,12
     f30:	ffe70713          	addi	a4,a4,-2
     f34:	00100693          	li	a3,1
     f38:	00090613          	mv	a2,s2
     f3c:	00098593          	mv	a1,s3
     f40:	03810513          	addi	a0,sp,56
     f44:	00000097          	auipc	ra,0x0
     f48:	000080e7          	jalr	ra # f44 <.L192+0x54>
     f4c:	000107b7          	lui	a5,0x10
     f50:	fff78313          	addi	t1,a5,-1 # ffff <.L283+0xeedf>
     f54:	00300e13          	li	t3,3

00000f58 <.L194>:
     f58:	008d8d93          	addi	s11,s11,8
     f5c:	0a0c8c93          	addi	s9,s9,160
     f60:	dc9ff06f          	j	d28 <.L191>

00000f64 <.L205>:
     f64:	00ebc783          	lbu	a5,14(s7)
     f68:	12fcce63          	blt	s9,a5,10a4 <.L228>
     f6c:	00fbc683          	lbu	a3,15(s7)
     f70:	12d36a63          	bltu	t1,a3,10a4 <.L228>
     f74:	01c78863          	beq	a5,t3,f84 <.L201>
     f78:	000a8a63          	beqz	s5,f8c <.L202>
     f7c:	828a4783          	lbu	a5,-2008(s4)
     f80:	00078663          	beqz	a5,f8c <.L202>

00000f84 <.L201>:
     f84:	00cbd783          	lhu	a5,12(s7)
     f88:	07b78a63          	beq	a5,s11,ffc <.L203>

00000f8c <.L202>:
     f8c:	000ba503          	lw	a0,0(s7)
     f90:	00d12e23          	sw	a3,28(sp)
     f94:	00000097          	auipc	ra,0x0
     f98:	000080e7          	jalr	ra # f94 <.L202+0x8>
     f9c:	00a12c23          	sw	a0,24(sp)
     fa0:	004ba503          	lw	a0,4(s7)
     fa4:	00000097          	auipc	ra,0x0
     fa8:	000080e7          	jalr	ra # fa4 <.L202+0x18>
     fac:	01c12683          	lw	a3,28(sp)
     fb0:	01812703          	lw	a4,24(sp)
     fb4:	00050793          	mv	a5,a0
     fb8:	00d12023          	sw	a3,0(sp)
     fbc:	01a12223          	sw	s10,4(sp)
     fc0:	00000893          	li	a7,0
     fc4:	00800813          	li	a6,8
     fc8:	00268693          	addi	a3,a3,2
     fcc:	00090613          	mv	a2,s2
     fd0:	00098593          	mv	a1,s3
     fd4:	03810513          	addi	a0,sp,56
     fd8:	00000097          	auipc	ra,0x0
     fdc:	000080e7          	jalr	ra # fd8 <.L202+0x4c>
     fe0:	00500313          	li	t1,5
     fe4:	00300e13          	li	t3,3
     fe8:	00051a63          	bnez	a0,ffc <.L203>
     fec:	00442783          	lw	a5,4(s0)
     ff0:	02c12703          	lw	a4,44(sp)
     ff4:	00e787b3          	add	a5,a5,a4
     ff8:	00f42223          	sw	a5,4(s0)

00000ffc <.L203>:
     ffc:	001c0c13          	addi	s8,s8,1
    1000:	014b8b93          	addi	s7,s7,20
    1004:	d5dff06f          	j	d60 <.L199>

00001008 <.L207>:
    1008:	81072783          	lw	a5,-2032(a4)
    100c:	80c72703          	lw	a4,-2036(a4)
    1010:	02c10693          	addi	a3,sp,44
    1014:	00d12223          	sw	a3,4(sp)
    1018:	fff00693          	li	a3,-1
    101c:	00d12023          	sw	a3,0(sp)
    1020:	00000893          	li	a7,0
    1024:	01000813          	li	a6,16
    1028:	ff878793          	addi	a5,a5,-8
    102c:	ff870713          	addi	a4,a4,-8
    1030:	00800693          	li	a3,8
    1034:	00090613          	mv	a2,s2
    1038:	00098593          	mv	a1,s3
    103c:	03810513          	addi	a0,sp,56
    1040:	00000097          	auipc	ra,0x0
    1044:	000080e7          	jalr	ra # 1040 <.L207+0x38>
    1048:	d95ff06f          	j	ddc <.L210>

0000104c <.L218>:
    104c:	02c10693          	addi	a3,sp,44
    1050:	00d12223          	sw	a3,4(sp)
    1054:	fff00693          	li	a3,-1
    1058:	00d12023          	sw	a3,0(sp)
    105c:	000b8893          	mv	a7,s7
    1060:	00c00813          	li	a6,12
    1064:	ffa78793          	addi	a5,a5,-6
    1068:	ffa70713          	addi	a4,a4,-6
    106c:	00100693          	li	a3,1
    1070:	00090613          	mv	a2,s2
    1074:	00098593          	mv	a1,s3
    1078:	03810513          	addi	a0,sp,56
    107c:	00000097          	auipc	ra,0x0
    1080:	000080e7          	jalr	ra # 107c <.L218+0x30>
    1084:	e40512e3          	bnez	a0,ec8 <.L216>
    1088:	e05ff06f          	j	e8c <.L220>

0000108c <.L221>:
    108c:	00042823          	sw	zero,16(s0)
    1090:	00042423          	sw	zero,8(s0)
    1094:	00042623          	sw	zero,12(s0)
    1098:	00042223          	sw	zero,4(s0)
    109c:	00042023          	sw	zero,0(s0)
    10a0:	b19ff06f          	j	bb8 <.L185>

000010a4 <.L228>:
    10a4:	ff800513          	li	a0,-8
    10a8:	d35ff06f          	j	ddc <.L210>

000010ac <gpu_instances_build>:
    10ac:	06080a63          	beqz	a6,1120 <.L283>
    10b0:	fc010113          	addi	sp,sp,-64
    10b4:	02812c23          	sw	s0,56(sp)
    10b8:	00080413          	mv	s0,a6
    10bc:	01c10813          	addi	a6,sp,28
    10c0:	01012023          	sw	a6,0(sp)
    10c4:	00040893          	mv	a7,s0
    10c8:	00078813          	mv	a6,a5
    10cc:	00070793          	mv	a5,a4
    10d0:	00000713          	li	a4,0
    10d4:	02112e23          	sw	ra,60(sp)
    10d8:	00000097          	auipc	ra,0x0
    10dc:	000080e7          	jalr	ra # 10d8 <gpu_instances_build+0x2c>
    10e0:	000027b7          	lui	a5,0x2
    10e4:	00f40833          	add	a6,s0,a5
    10e8:	01c12783          	lw	a5,28(sp)
    10ec:	03c12083          	lw	ra,60(sp)
    10f0:	03812403          	lw	s0,56(sp)
    10f4:	48f82823          	sw	a5,1168(a6)
    10f8:	02012783          	lw	a5,32(sp)
    10fc:	48f82a23          	sw	a5,1172(a6)
    1100:	02412783          	lw	a5,36(sp)
    1104:	48f82c23          	sw	a5,1176(a6)
    1108:	02812783          	lw	a5,40(sp)
    110c:	48f82e23          	sw	a5,1180(a6)
    1110:	02c12783          	lw	a5,44(sp)
    1114:	4af82023          	sw	a5,1184(a6)
    1118:	04010113          	addi	sp,sp,64
    111c:	00008067          	ret

00001120 <.L283>:
    1120:	ff800513          	li	a0,-8
    1124:	00008067          	ret