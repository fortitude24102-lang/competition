
D:\ZYNQ\smallproject\.worktrees\pango-riscv-cpu\generated\verification\v3\cpu-builder-20261025/probe-shift-r1/gpu_demo.elf:     file format elf32-littleriscv


Disassembly of section .init:

Disassembly of section .text:

0000bf34 <gpu_instances_build_into>:
    bf34:	f9010113          	addi	sp,sp,-112
    bf38:	06812423          	sw	s0,104(sp)
    bf3c:	07012403          	lw	s0,112(sp)
    bf40:	06112623          	sw	ra,108(sp)
    bf44:	06912223          	sw	s1,100(sp)
    bf48:	07212023          	sw	s2,96(sp)
    bf4c:	05312e23          	sw	s3,92(sp)
    bf50:	05412c23          	sw	s4,88(sp)
    bf54:	05512a23          	sw	s5,84(sp)
    bf58:	05612823          	sw	s6,80(sp)
    bf5c:	05712623          	sw	s7,76(sp)
    bf60:	05812423          	sw	s8,72(sp)
    bf64:	05912223          	sw	s9,68(sp)
    bf68:	05a12023          	sw	s10,64(sp)
    bf6c:	03b12e23          	sw	s11,60(sp)
    bf70:	04041263          	bnez	s0,bfb4 <gpu_instances_build_into+0x80>
    bf74:	ff800513          	li	a0,-8
    bf78:	06c12083          	lw	ra,108(sp)
    bf7c:	06812403          	lw	s0,104(sp)
    bf80:	06412483          	lw	s1,100(sp)
    bf84:	06012903          	lw	s2,96(sp)
    bf88:	05c12983          	lw	s3,92(sp)
    bf8c:	05812a03          	lw	s4,88(sp)
    bf90:	05412a83          	lw	s5,84(sp)
    bf94:	05012b03          	lw	s6,80(sp)
    bf98:	04c12b83          	lw	s7,76(sp)
    bf9c:	04812c03          	lw	s8,72(sp)
    bfa0:	04412c83          	lw	s9,68(sp)
    bfa4:	04012d03          	lw	s10,64(sp)
    bfa8:	03c12d83          	lw	s11,60(sp)
    bfac:	07010113          	addi	sp,sp,112
    bfb0:	00008067          	ret
    bfb4:	00042823          	sw	zero,16(s0)
    bfb8:	00042423          	sw	zero,8(s0)
    bfbc:	00042623          	sw	zero,12(s0)
    bfc0:	00042223          	sw	zero,4(s0)
    bfc4:	00042023          	sw	zero,0(s0)
    bfc8:	00050493          	mv	s1,a0
    bfcc:	fa0504e3          	beqz	a0,bf74 <gpu_instances_build_into+0x40>
    bfd0:	00088a13          	mv	s4,a7
    bfd4:	fa0880e3          	beqz	a7,bf74 <gpu_instances_build_into+0x40>
    bfd8:	00005cb7          	lui	s9,0x5
    bfdc:	01950cb3          	add	s9,a0,s9
    bfe0:	00078c13          	mv	s8,a5
    bfe4:	008ca783          	lw	a5,8(s9) # 5008 <bullet_enemy_position+0x50>
    bfe8:	00070a93          	mv	s5,a4
    bfec:	3ff00713          	li	a4,1023
    bff0:	fff78793          	addi	a5,a5,-1
    bff4:	f8f760e3          	bltu	a4,a5,bf74 <gpu_instances_build_into+0x40>
    bff8:	fff80793          	addi	a5,a6,-1
    bffc:	48800713          	li	a4,1160
    c000:	00080993          	mv	s3,a6
    c004:	f6f768e3          	bltu	a4,a5,bf74 <gpu_instances_build_into+0x40>
    c008:	00058913          	mv	s2,a1
    c00c:	00060b93          	mv	s7,a2
    c010:	00068b13          	mv	s6,a3
    c014:	f29f80ef          	jal	4f3c <bullet_campaign_valid>
    c018:	f4050ee3          	beqz	a0,bf74 <gpu_instances_build_into+0x40>
    c01c:	000a8663          	beqz	s5,c028 <gpu_instances_build_into+0xf4>
    c020:	029cc783          	lbu	a5,41(s9)
    c024:	f40798e3          	bnez	a5,bf74 <gpu_instances_build_into+0x40>
    c028:	016bebb3          	or	s7,s7,s6
    c02c:	015bebb3          	or	s7,s7,s5
    c030:	00100793          	li	a5,1
    c034:	f577e0e3          	bltu	a5,s7,bf74 <gpu_instances_build_into+0x40>
    c038:	21b00793          	li	a5,539
    c03c:	f387ece3          	bltu	a5,s8,bf74 <gpu_instances_build_into+0x40>
    c040:	ffe00737          	lui	a4,0xffe00
    c044:	fff70713          	addi	a4,a4,-1 # ffdfffff <__gpu_framebuffer_a+0xfddfffff>
    c048:	00e97733          	and	a4,s2,a4
    c04c:	020007b7          	lui	a5,0x2000
    c050:	f2f712e3          	bne	a4,a5,bf74 <gpu_instances_build_into+0x40>
    c054:	78000693          	li	a3,1920
    c058:	02dc06b3          	mul	a3,s8,a3
    c05c:	21c00713          	li	a4,540
    c060:	418707b3          	sub	a5,a4,s8
    c064:	00042703          	lw	a4,0(s0)
    c068:	03412423          	sw	s4,40(sp)
    c06c:	02812623          	sw	s0,44(sp)
    c070:	ffc00513          	li	a0,-4
    c074:	01268633          	add	a2,a3,s2
    c078:	04e98263          	beq	s3,a4,c0bc <gpu_instances_build_into+0x188>
    c07c:	00170593          	addi	a1,a4,1
    c080:	00471713          	slli	a4,a4,0x4
    c084:	00ea08b3          	add	a7,s4,a4
    c088:	01079713          	slli	a4,a5,0x10
    c08c:	00b42023          	sw	a1,0(s0)
    c090:	3c076713          	ori	a4,a4,960
    c094:	00e8a623          	sw	a4,12(a7)
    c098:	3c000713          	li	a4,960
    c09c:	02e787b3          	mul	a5,a5,a4
    c0a0:	00c42703          	lw	a4,12(s0)
    c0a4:	0008a023          	sw	zero,0(a7)
    c0a8:	00c8a223          	sw	a2,4(a7)
    c0ac:	00d8a423          	sw	a3,8(a7)
    c0b0:	00000513          	li	a0,0
    c0b4:	00f707b3          	add	a5,a4,a5
    c0b8:	00f42623          	sw	a5,12(s0)
    c0bc:	00005c37          	lui	s8,0x5
    c0c0:	00010d37          	lui	s10,0x10
    c0c4:	00048b93          	mv	s7,s1
    c0c8:	00048a13          	mv	s4,s1
    c0cc:	00000c93          	li	s9,0
    c0d0:	01848c33          	add	s8,s1,s8
    c0d4:	01c10d93          	addi	s11,sp,28
    c0d8:	fff00313          	li	t1,-1
    c0dc:	00300e13          	li	t3,3
    c0e0:	fffd0d13          	addi	s10,s10,-1 # ffff <__global_pointer$+0x1317>
    c0e4:	00051863          	bnez	a0,c0f4 <gpu_instances_build_into+0x1c0>
    c0e8:	000b0663          	beqz	s6,c0f4 <gpu_instances_build_into+0x1c0>
    c0ec:	008c2783          	lw	a5,8(s8) # 5008 <bullet_enemy_position+0x50>
    c0f0:	18fcea63          	bltu	s9,a5,c284 <gpu_instances_build_into+0x350>
    c0f4:	01503cb3          	snez	s9,s5
    c0f8:	00005a37          	lui	s4,0x5
    c0fc:	00010d37          	lui	s10,0x10
    c100:	002c8c93          	addi	s9,s9,2
    c104:	00000c13          	li	s8,0
    c108:	01448a33          	add	s4,s1,s4
    c10c:	00500d93          	li	s11,5
    c110:	00300313          	li	t1,3
    c114:	01c10e13          	addi	t3,sp,28
    c118:	fffd0d13          	addi	s10,s10,-1 # ffff <__global_pointer$+0x1317>
    c11c:	06051c63          	bnez	a0,c194 <gpu_instances_build_into+0x260>
    c120:	008a2783          	lw	a5,8(s4) # 5008 <bullet_enemy_position+0x50>
    c124:	1cfc6c63          	bltu	s8,a5,c2fc <gpu_instances_build_into+0x3c8>
    c128:	024a4783          	lbu	a5,36(s4)
    c12c:	040b0a63          	beqz	s6,c180 <gpu_instances_build_into+0x24c>
    c130:	06078063          	beqz	a5,c190 <gpu_instances_build_into+0x25c>
    c134:	00ca2703          	lw	a4,12(s4)
    c138:	010a2783          	lw	a5,16(s4)
    c13c:	020a5683          	lhu	a3,32(s4)
    c140:	ffa70713          	addi	a4,a4,-6
    c144:	ffa78793          	addi	a5,a5,-6 # 1fffffa <__freertos_irq_stack_top+0x1fe25fa>
    c148:	04000893          	li	a7,64
    c14c:	00068463          	beqz	a3,c154 <gpu_instances_build_into+0x220>
    c150:	0c000893          	li	a7,192
    c154:	01c10693          	addi	a3,sp,28
    c158:	00d12223          	sw	a3,4(sp)
    c15c:	fff00693          	li	a3,-1
    c160:	00d12023          	sw	a3,0(sp)
    c164:	00c00813          	li	a6,12
    c168:	00100693          	li	a3,1
    c16c:	00090613          	mv	a2,s2
    c170:	00098593          	mv	a1,s3
    c174:	02810513          	addi	a0,sp,40
    c178:	d4cff0ef          	jal	b6c4 <sprite>
    c17c:	00051c63          	bnez	a0,c194 <gpu_instances_build_into+0x260>
    c180:	00005737          	lui	a4,0x5
    c184:	00e48733          	add	a4,s1,a4
    c188:	02474783          	lbu	a5,36(a4) # 5024 <bullet_enemy_position+0x6c>
    c18c:	1e079a63          	bnez	a5,c380 <gpu_instances_build_into+0x44c>
    c190:	00000513          	li	a0,0
    c194:	000057b7          	lui	a5,0x5
    c198:	00f487b3          	add	a5,s1,a5
    c19c:	0247c703          	lbu	a4,36(a5) # 5024 <bullet_enemy_position+0x6c>
    c1a0:	05000b93          	li	s7,80
    c1a4:	02070063          	beqz	a4,c1c4 <gpu_instances_build_into+0x290>
    c1a8:	0147a783          	lw	a5,20(a5)
    c1ac:	03c00713          	li	a4,60
    c1b0:	02e7f7b3          	remu	a5,a5,a4
    c1b4:	02b00713          	li	a4,43
    c1b8:	00f77663          	bgeu	a4,a5,c1c4 <gpu_instances_build_into+0x290>
    c1bc:	00379793          	slli	a5,a5,0x3
    c1c0:	ef878b93          	addi	s7,a5,-264
    c1c4:	0000edb7          	lui	s11,0xe
    c1c8:	00005a37          	lui	s4,0x5
    c1cc:	3e0d8d93          	addi	s11,s11,992 # e3e0 <centers.0>
    c1d0:	00000d13          	li	s10,0
    c1d4:	00300c13          	li	s8,3
    c1d8:	fff00c93          	li	s9,-1
    c1dc:	01448a33          	add	s4,s1,s4
    c1e0:	20051e63          	bnez	a0,c3fc <gpu_instances_build_into+0x4c8>
    c1e4:	d98d0ae3          	beq	s10,s8,bf78 <gpu_instances_build_into+0x44>
    c1e8:	020a8263          	beqz	s5,c20c <gpu_instances_build_into+0x2d8>
    c1ec:	028a4783          	lbu	a5,40(s4) # 5028 <bullet_enemy_position+0x70>
    c1f0:	00078e63          	beqz	a5,c20c <gpu_instances_build_into+0x2d8>
    c1f4:	000057b7          	lui	a5,0x5
    c1f8:	02578793          	addi	a5,a5,37 # 5025 <bullet_enemy_position+0x6d>
    c1fc:	00fd07b3          	add	a5,s10,a5
    c200:	00f487b3          	add	a5,s1,a5
    c204:	0007c783          	lbu	a5,0(a5)
    c208:	06078863          	beqz	a5,c278 <gpu_instances_build_into+0x344>
    c20c:	000da783          	lw	a5,0(s11)
    c210:	02f12023          	sw	a5,32(sp)
    c214:	004da783          	lw	a5,4(s11)
    c218:	02f12223          	sw	a5,36(sp)
    c21c:	000a8c63          	beqz	s5,c234 <gpu_instances_build_into+0x300>
    c220:	02410693          	addi	a3,sp,36
    c224:	02010613          	addi	a2,sp,32
    c228:	000d0593          	mv	a1,s10
    c22c:	00048513          	mv	a0,s1
    c230:	d89f80ef          	jal	4fb8 <bullet_enemy_position>
    c234:	02012703          	lw	a4,32(sp)
    c238:	02412783          	lw	a5,36(sp)
    c23c:	180b1263          	bnez	s6,c3c0 <gpu_instances_build_into+0x48c>
    c240:	01c10793          	addi	a5,sp,28
    c244:	02012703          	lw	a4,32(sp)
    c248:	00f12223          	sw	a5,4(sp)
    c24c:	02412783          	lw	a5,36(sp)
    c250:	01912023          	sw	s9,0(sp)
    c254:	00000893          	li	a7,0
    c258:	01000813          	li	a6,16
    c25c:	ff878793          	addi	a5,a5,-8
    c260:	ff870713          	addi	a4,a4,-8
    c264:	009d0693          	addi	a3,s10,9
    c268:	00090613          	mv	a2,s2
    c26c:	00098593          	mv	a1,s3
    c270:	02810513          	addi	a0,sp,40
    c274:	c50ff0ef          	jal	b6c4 <sprite>
    c278:	001d0d13          	addi	s10,s10,1
    c27c:	008d8d93          	addi	s11,s11,8
    c280:	f61ff06f          	j	c1e0 <gpu_instances_build_into+0x2ac>
    c284:	000a8e63          	beqz	s5,c2a0 <gpu_instances_build_into+0x36c>
    c288:	00ea4783          	lbu	a5,14(s4)
    c28c:	01c78663          	beq	a5,t3,c298 <gpu_instances_build_into+0x364>
    c290:	028c4783          	lbu	a5,40(s8)
    c294:	00078663          	beqz	a5,c2a0 <gpu_instances_build_into+0x36c>
    c298:	00ca5783          	lhu	a5,12(s4)
    c29c:	05a78a63          	beq	a5,s10,c2f0 <gpu_instances_build_into+0x3bc>
    c2a0:	004c2883          	lw	a7,4(s8)
    c2a4:	004a2783          	lw	a5,4(s4)
    c2a8:	000a2703          	lw	a4,0(s4)
    c2ac:	00f8f893          	andi	a7,a7,15
    c2b0:	01088893          	addi	a7,a7,16
    c2b4:	4087d793          	srai	a5,a5,0x8
    c2b8:	40875713          	srai	a4,a4,0x8
    c2bc:	00612023          	sw	t1,0(sp)
    c2c0:	01b12223          	sw	s11,4(sp)
    c2c4:	00289893          	slli	a7,a7,0x2
    c2c8:	00c00813          	li	a6,12
    c2cc:	ffe78793          	addi	a5,a5,-2
    c2d0:	ffe70713          	addi	a4,a4,-2
    c2d4:	00100693          	li	a3,1
    c2d8:	00090613          	mv	a2,s2
    c2dc:	00098593          	mv	a1,s3
    c2e0:	02810513          	addi	a0,sp,40
    c2e4:	be0ff0ef          	jal	b6c4 <sprite>
    c2e8:	00300e13          	li	t3,3
    c2ec:	fff00313          	li	t1,-1
    c2f0:	008c8c93          	addi	s9,s9,8
    c2f4:	0a0a0a13          	addi	s4,s4,160
    c2f8:	dedff06f          	j	c0e4 <gpu_instances_build_into+0x1b0>
    c2fc:	00ebc783          	lbu	a5,14(s7)
    c300:	10fcca63          	blt	s9,a5,c414 <gpu_instances_build_into+0x4e0>
    c304:	00fbc683          	lbu	a3,15(s7)
    c308:	10dde663          	bltu	s11,a3,c414 <gpu_instances_build_into+0x4e0>
    c30c:	00678863          	beq	a5,t1,c31c <gpu_instances_build_into+0x3e8>
    c310:	000a8a63          	beqz	s5,c324 <gpu_instances_build_into+0x3f0>
    c314:	028a4783          	lbu	a5,40(s4)
    c318:	00078663          	beqz	a5,c324 <gpu_instances_build_into+0x3f0>
    c31c:	00cbd783          	lhu	a5,12(s7)
    c320:	05a78a63          	beq	a5,s10,c374 <gpu_instances_build_into+0x440>
    c324:	004ba783          	lw	a5,4(s7)
    c328:	000ba703          	lw	a4,0(s7)
    c32c:	00000893          	li	a7,0
    c330:	01c12223          	sw	t3,4(sp)
    c334:	00d12023          	sw	a3,0(sp)
    c338:	00800813          	li	a6,8
    c33c:	4087d793          	srai	a5,a5,0x8
    c340:	40875713          	srai	a4,a4,0x8
    c344:	00268693          	addi	a3,a3,2
    c348:	00090613          	mv	a2,s2
    c34c:	00098593          	mv	a1,s3
    c350:	02810513          	addi	a0,sp,40
    c354:	b70ff0ef          	jal	b6c4 <sprite>
    c358:	01c10e13          	addi	t3,sp,28
    c35c:	00300313          	li	t1,3
    c360:	00051a63          	bnez	a0,c374 <gpu_instances_build_into+0x440>
    c364:	00442783          	lw	a5,4(s0)
    c368:	01c12703          	lw	a4,28(sp)
    c36c:	00e787b3          	add	a5,a5,a4
    c370:	00f42223          	sw	a5,4(s0)
    c374:	001c0c13          	addi	s8,s8,1
    c378:	014b8b93          	addi	s7,s7,20
    c37c:	da1ff06f          	j	c11c <gpu_instances_build_into+0x1e8>
    c380:	01072783          	lw	a5,16(a4)
    c384:	00c72703          	lw	a4,12(a4)
    c388:	01c10693          	addi	a3,sp,28
    c38c:	00d12223          	sw	a3,4(sp)
    c390:	fff00693          	li	a3,-1
    c394:	00d12023          	sw	a3,0(sp)
    c398:	00000893          	li	a7,0
    c39c:	01000813          	li	a6,16
    c3a0:	ff878793          	addi	a5,a5,-8
    c3a4:	ff870713          	addi	a4,a4,-8
    c3a8:	00800693          	li	a3,8
    c3ac:	00090613          	mv	a2,s2
    c3b0:	00098593          	mv	a1,s3
    c3b4:	02810513          	addi	a0,sp,40
    c3b8:	b0cff0ef          	jal	b6c4 <sprite>
    c3bc:	dd9ff06f          	j	c194 <gpu_instances_build_into+0x260>
    c3c0:	01c10693          	addi	a3,sp,28
    c3c4:	00d12223          	sw	a3,4(sp)
    c3c8:	fff00693          	li	a3,-1
    c3cc:	00d12023          	sw	a3,0(sp)
    c3d0:	000b8893          	mv	a7,s7
    c3d4:	00c00813          	li	a6,12
    c3d8:	ffa78793          	addi	a5,a5,-6
    c3dc:	ffa70713          	addi	a4,a4,-6
    c3e0:	00100693          	li	a3,1
    c3e4:	00090613          	mv	a2,s2
    c3e8:	00098593          	mv	a1,s3
    c3ec:	02810513          	addi	a0,sp,40
    c3f0:	ad4ff0ef          	jal	b6c4 <sprite>
    c3f4:	e80512e3          	bnez	a0,c278 <gpu_instances_build_into+0x344>
    c3f8:	e49ff06f          	j	c240 <gpu_instances_build_into+0x30c>
    c3fc:	00042823          	sw	zero,16(s0)
    c400:	00042423          	sw	zero,8(s0)
    c404:	00042623          	sw	zero,12(s0)
    c408:	00042223          	sw	zero,4(s0)
    c40c:	00042023          	sw	zero,0(s0)
    c410:	b69ff06f          	j	bf78 <gpu_instances_build_into+0x44>
    c414:	ff800513          	li	a0,-8
    c418:	d7dff06f          	j	c194 <gpu_instances_build_into+0x260>
