
D:\ZYNQ\smallproject\.worktrees\pango-riscv-cpu\generated\verification\v3\coordinate-codegen-b855a4c0e5cb45b28f627b458505b895/instances.o:     file format elf32-littleriscv


Disassembly of section .text:

00000000 <sprite>:
       0:	fa010113          	addi	sp,sp,-96
       4:	05512223          	sw	s5,68(sp)
       8:	00068a93          	mv	s5,a3
       c:	06412683          	lw	a3,100(sp)
      10:	04112e23          	sw	ra,92(sp)
      14:	04812c23          	sw	s0,88(sp)
      18:	04912a23          	sw	s1,84(sp)
      1c:	05212823          	sw	s2,80(sp)
      20:	05312623          	sw	s3,76(sp)
      24:	05412423          	sw	s4,72(sp)
      28:	05612023          	sw	s6,64(sp)
      2c:	03712e23          	sw	s7,60(sp)
      30:	03812c23          	sw	s8,56(sp)
      34:	03912a23          	sw	s9,52(sp)
      38:	03a12823          	sw	s10,48(sp)
      3c:	03b12623          	sw	s11,44(sp)
      40:	0006a023          	sw	zero,0(a3)
      44:	3bf00693          	li	a3,959
      48:	04e6d263          	bge	a3,a4,8c <.L2>

0000004c <.L21>:
      4c:	00000513          	li	a0,0

00000050 <.L1>:
      50:	05c12083          	lw	ra,92(sp)
      54:	05812403          	lw	s0,88(sp)
      58:	05412483          	lw	s1,84(sp)
      5c:	05012903          	lw	s2,80(sp)
      60:	04c12983          	lw	s3,76(sp)
      64:	04812a03          	lw	s4,72(sp)
      68:	04412a83          	lw	s5,68(sp)
      6c:	04012b03          	lw	s6,64(sp)
      70:	03c12b83          	lw	s7,60(sp)
      74:	03812c03          	lw	s8,56(sp)
      78:	03412c83          	lw	s9,52(sp)
      7c:	03012d03          	lw	s10,48(sp)
      80:	02c12d83          	lw	s11,44(sp)
      84:	06010113          	addi	sp,sp,96
      88:	00008067          	ret

0000008c <.L2>:
      8c:	410006b3          	neg	a3,a6
      90:	fae6dee3          	bge	a3,a4,4c <.L21>
      94:	21b00693          	li	a3,539
      98:	faf6cae3          	blt	a3,a5,4c <.L21>
      9c:	00058c13          	mv	s8,a1
      a0:	04800593          	li	a1,72
      a4:	410586b3          	sub	a3,a1,a6
      a8:	faf6d2e3          	bge	a3,a5,4c <.L21>
      ac:	00060c93          	mv	s9,a2
      b0:	40e006b3          	neg	a3,a4
      b4:	41f75613          	srai	a2,a4,0x1f
      b8:	00c6f4b3          	and	s1,a3,a2
      bc:	04700613          	li	a2,71
      c0:	00050b93          	mv	s7,a0
      c4:	00088d13          	mv	s10,a7
      c8:	00000413          	li	s0,0
      cc:	00f64463          	blt	a2,a5,d4 <.L6>
      d0:	40f58433          	sub	s0,a1,a5

000000d4 <.L6>:
      d4:	00070993          	mv	s3,a4
      d8:	00075463          	bgez	a4,e0 <.L7>
      dc:	00000993          	li	s3,0

000000e0 <.L7>:
      e0:	00078913          	mv	s2,a5
      e4:	04800793          	li	a5,72
      e8:	00f95463          	bge	s2,a5,f0 <.L8>
      ec:	04800913          	li	s2,72

000000f0 <.L8>:
      f0:	3c000793          	li	a5,960
      f4:	40980733          	sub	a4,a6,s1
      f8:	41378a33          	sub	s4,a5,s3
      fc:	01477463          	bgeu	a4,s4,104 <.L9>
     100:	00070a13          	mv	s4,a4

00000104 <.L9>:
     104:	21c00b13          	li	s6,540
     108:	408807b3          	sub	a5,a6,s0
     10c:	412b0b33          	sub	s6,s6,s2
     110:	0167f463          	bgeu	a5,s6,118 <.L10>
     114:	00078b13          	mv	s6,a5

00000118 <.L10>:
     118:	06012703          	lw	a4,96(sp)
     11c:	fff00793          	li	a5,-1
     120:	0af71c63          	bne	a4,a5,1d8 <.L11>

00000124 <.L14>:
     124:	3c000713          	li	a4,960
     128:	02e90733          	mul	a4,s2,a4
     12c:	004ba683          	lw	a3,4(s7)
     130:	ffc00513          	li	a0,-4
     134:	03040433          	mul	s0,s0,a6
     138:	01370733          	add	a4,a4,s3
     13c:	00171713          	slli	a4,a4,0x1
     140:	01970633          	add	a2,a4,s9
     144:	0006a703          	lw	a4,0(a3)
     148:	00940433          	add	s0,s0,s1
     14c:	00141413          	slli	s0,s0,0x1
     150:	f0ec00e3          	beq	s8,a4,50 <.L1>
     154:	000ba783          	lw	a5,0(s7)
     158:	00170593          	addi	a1,a4,1
     15c:	00471713          	slli	a4,a4,0x4
     160:	00e787b3          	add	a5,a5,a4
     164:	fffa8713          	addi	a4,s5,-1
     168:	00173713          	seqz	a4,a4
     16c:	010d1d13          	slli	s10,s10,0x10
     170:	00871713          	slli	a4,a4,0x8
     174:	015d6d33          	or	s10,s10,s5
     178:	01a768b3          	or	a7,a4,s10
     17c:	010b1713          	slli	a4,s6,0x10
     180:	00b6a023          	sw	a1,0(a3)
     184:	01476733          	or	a4,a4,s4
     188:	00e7a623          	sw	a4,12(a5)
     18c:	0117a023          	sw	a7,0(a5)
     190:	00c7a223          	sw	a2,4(a5)
     194:	0087a423          	sw	s0,8(a5)
     198:	036a07b3          	mul	a5,s4,s6
     19c:	00c6a703          	lw	a4,12(a3)
     1a0:	00f70733          	add	a4,a4,a5
     1a4:	00e6a623          	sw	a4,12(a3)
     1a8:	00100713          	li	a4,1
     1ac:	00ea9e63          	bne	s5,a4,1c8 <.L20>
     1b0:	0086a703          	lw	a4,8(a3)
     1b4:	00170713          	addi	a4,a4,1
     1b8:	00e6a423          	sw	a4,8(a3)
     1bc:	0106a703          	lw	a4,16(a3)
     1c0:	00f707b3          	add	a5,a4,a5
     1c4:	00f6a823          	sw	a5,16(a3)

000001c8 <.L20>:
     1c8:	06412703          	lw	a4,100(sp)
     1cc:	00100793          	li	a5,1
     1d0:	00f72023          	sw	a5,0(a4)
     1d4:	e79ff06f          	j	4c <.L21>

000001d8 <.L11>:
     1d8:	0084edb3          	or	s11,s1,s0
     1dc:	060d9e63          	bnez	s11,258 <.L25>
     1e0:	010a6463          	bltu	s4,a6,1e8 <.L13>
     1e4:	f50b70e3          	bgeu	s6,a6,124 <.L14>

000001e8 <.L13>:
     1e8:	00000793          	li	a5,0
     1ec:	01640733          	add	a4,s0,s6
     1f0:	014488b3          	add	a7,s1,s4
     1f4:	04c0006f          	j	240 <.L17>

000001f8 <.L16>:
     1f8:	06012503          	lw	a0,96(sp)
     1fc:	000d8613          	mv	a2,s11
     200:	01112e23          	sw	a7,28(sp)
     204:	00e12c23          	sw	a4,24(sp)
     208:	01012a23          	sw	a6,20(sp)
     20c:	00f12823          	sw	a5,16(sp)
     210:	00b12623          	sw	a1,12(sp)
     214:	00000097          	auipc	ra,0x0
     218:	000080e7          	jalr	ra # 214 <.L16+0x1c>
     21c:	01412803          	lw	a6,20(sp)
     220:	01812703          	lw	a4,24(sp)
     224:	01c12883          	lw	a7,28(sp)
     228:	02051463          	bnez	a0,250 <.L26>
     22c:	00c12583          	lw	a1,12(sp)
     230:	01012783          	lw	a5,16(sp)
     234:	00158593          	addi	a1,a1,1

00000238 <.L19>:
     238:	fd15e0e3          	bltu	a1,a7,1f8 <.L16>

0000023c <.L15>:
     23c:	001d8d93          	addi	s11,s11,1

00000240 <.L17>:
     240:	02edf063          	bgeu	s11,a4,260 <.L18>
     244:	ee0790e3          	bnez	a5,124 <.L14>
     248:	00048593          	mv	a1,s1
     24c:	fedff06f          	j	238 <.L19>

00000250 <.L26>:
     250:	00100793          	li	a5,1
     254:	fe9ff06f          	j	23c <.L15>

00000258 <.L25>:
     258:	00040d93          	mv	s11,s0
     25c:	f8dff06f          	j	1e8 <.L13>

00000260 <.L18>:
     260:	de0786e3          	beqz	a5,4c <.L21>
     264:	ec1ff06f          	j	124 <.L14>

00000268 <gpu_instances_init>:
     268:	00050793          	mv	a5,a0
     26c:	ff800513          	li	a0,-8
     270:	04078863          	beqz	a5,2c0 <.L33>
     274:	04058663          	beqz	a1,2c0 <.L33>
     278:	0105c703          	lbu	a4,16(a1)
     27c:	04070263          	beqz	a4,2c0 <.L33>
     280:	0005a703          	lw	a4,0(a1)
     284:	0007a223          	sw	zero,4(a5)
     288:	00b7a023          	sw	a1,0(a5)
     28c:	00872683          	lw	a3,8(a4)
     290:	01169613          	slli	a2,a3,0x11
     294:	00064663          	bltz	a2,2a0 <.L35>

00000298 <.L36>:
     298:	00000513          	li	a0,0
     29c:	00008067          	ret

000002a0 <.L35>:
     2a0:	40072683          	lw	a3,1024(a4)
     2a4:	494e5737          	lui	a4,0x494e5
     2a8:	33170713          	addi	a4,a4,817 # 494e5331 <.L278+0x494e4261>
     2ac:	fff00513          	li	a0,-1
     2b0:	00e69863          	bne	a3,a4,2c0 <.L33>
     2b4:	00100713          	li	a4,1
     2b8:	00e78223          	sb	a4,4(a5)
     2bc:	fddff06f          	j	298 <.L36>

000002c0 <.L33>:
     2c0:	00008067          	ret

000002c4 <gpu_instances_templates>:
     2c4:	12058263          	beqz	a1,3e8 <.L49>
     2c8:	ff010113          	addi	sp,sp,-16
     2cc:	00912223          	sw	s1,4(sp)
     2d0:	00112623          	sw	ra,12(sp)
     2d4:	00050493          	mv	s1,a0
     2d8:	00812423          	sw	s0,8(sp)
     2dc:	00100793          	li	a5,1
     2e0:	00000513          	li	a0,0
     2e4:	1097e663          	bltu	a5,s1,3f0 <.L41>
     2e8:	00058413          	mv	s0,a1
     2ec:	1c000613          	li	a2,448
     2f0:	00000593          	li	a1,0
     2f4:	00040513          	mv	a0,s0
     2f8:	00000097          	auipc	ra,0x0
     2fc:	000080e7          	jalr	ra # 2f8 <gpu_instances_templates+0x34>
     300:	0c048063          	beqz	s1,3c0 <.L51>
     304:	02a005b7          	lui	a1,0x2a00
     308:	029007b7          	lui	a5,0x2900

0000030c <.L43>:
     30c:	00f42223          	sw	a5,4(s0)
     310:	78000793          	li	a5,1920
     314:	00f42423          	sw	a5,8(s0)
     318:	00f42623          	sw	a5,12(s0)
     31c:	3c000793          	li	a5,960
     320:	00200713          	li	a4,2
     324:	00f42823          	sw	a5,16(s0)
     328:	000106b7          	lui	a3,0x10
     32c:	21c00793          	li	a5,540
     330:	fffff637          	lui	a2,0xfffff
     334:	00e42023          	sw	a4,0(s0)
     338:	00f42a23          	sw	a5,20(s0)
     33c:	00042c23          	sw	zero,24(s0)
     340:	00100513          	li	a0,1
     344:	01c40413          	addi	s0,s0,28
     348:	00c00713          	li	a4,12
     34c:	50000793          	li	a5,1280
     350:	00100893          	li	a7,1
     354:	78000313          	li	t1,1920
     358:	81f68693          	addi	a3,a3,-2017 # f81f <.L278+0xe74f>
     35c:	00c00e13          	li	t3,12
     360:	00700e93          	li	t4,7
     364:	00800f13          	li	t5,8
     368:	42060613          	addi	a2,a2,1056 # fffff420 <.L278+0xffffe350>

0000036c <.L44>:
     36c:	00300813          	li	a6,3
     370:	01151463          	bne	a0,a7,378 <.L46>
     374:	00400813          	li	a6,4

00000378 <.L46>:
     378:	00b787b3          	add	a5,a5,a1
     37c:	00f42223          	sw	a5,4(s0)
     380:	00171793          	slli	a5,a4,0x1
     384:	01042023          	sw	a6,0(s0)
     388:	00f42423          	sw	a5,8(s0)
     38c:	00642623          	sw	t1,12(s0)
     390:	00e42823          	sw	a4,16(s0)
     394:	00e42a23          	sw	a4,20(s0)
     398:	00d42c23          	sw	a3,24(s0)
     39c:	00150513          	addi	a0,a0,1
     3a0:	01c40413          	addi	s0,s0,28
     3a4:	05c50663          	beq	a0,t3,3f0 <.L41>
     3a8:	02aef263          	bgeu	t4,a0,3cc <.L47>
     3ac:	03e50863          	beq	a0,t5,3dc <.L52>
     3b0:	00951793          	slli	a5,a0,0x9
     3b4:	00c787b3          	add	a5,a5,a2
     3b8:	01000713          	li	a4,16
     3bc:	fb1ff06f          	j	36c <.L44>

000003c0 <.L51>:
     3c0:	02c005b7          	lui	a1,0x2c00
     3c4:	02b007b7          	lui	a5,0x2b00
     3c8:	f45ff06f          	j	30c <.L43>

000003cc <.L47>:
     3cc:	00751793          	slli	a5,a0,0x7
     3d0:	f0078793          	addi	a5,a5,-256 # 2afff00 <.L278+0x2afee30>
     3d4:	00800713          	li	a4,8
     3d8:	f95ff06f          	j	36c <.L44>

000003dc <.L52>:
     3dc:	01000713          	li	a4,16
     3e0:	30000793          	li	a5,768
     3e4:	f89ff06f          	j	36c <.L44>

000003e8 <.L49>:
     3e8:	00000513          	li	a0,0
     3ec:	00008067          	ret

000003f0 <.L41>:
     3f0:	00c12083          	lw	ra,12(sp)
     3f4:	00812403          	lw	s0,8(sp)
     3f8:	00412483          	lw	s1,4(sp)
     3fc:	01010113          	addi	sp,sp,16
     400:	00008067          	ret

00000404 <gpu_instance_expand>:
     404:	28050a63          	beqz	a0,698 <.L69>
     408:	00050713          	mv	a4,a0
     40c:	ff800513          	li	a0,-8
     410:	28058c63          	beqz	a1,6a8 <.L102>
     414:	28068a63          	beqz	a3,6a8 <.L102>
     418:	0005a783          	lw	a5,0(a1) # 2c00000 <.L278+0x2bfef30>
     41c:	fd010113          	addi	sp,sp,-48
     420:	01312e23          	sw	s3,28(sp)
     424:	0187d513          	srli	a0,a5,0x18
     428:	0087d813          	srli	a6,a5,0x8
     42c:	01512a23          	sw	s5,20(sp)
     430:	00060993          	mv	s3,a2
     434:	0107da93          	srli	s5,a5,0x10
     438:	0ff7f613          	zext.b	a2,a5
     43c:	0f07f793          	andi	a5,a5,240
     440:	00f567b3          	or	a5,a0,a5
     444:	02112623          	sw	ra,44(sp)
     448:	02812423          	sw	s0,40(sp)
     44c:	02912223          	sw	s1,36(sp)
     450:	03212023          	sw	s2,32(sp)
     454:	01412c23          	sw	s4,24(sp)
     458:	01612823          	sw	s6,16(sp)
     45c:	01712623          	sw	s7,12(sp)
     460:	01812423          	sw	s8,8(sp)
     464:	01912223          	sw	s9,4(sp)
     468:	0ff87813          	zext.b	a6,a6
     46c:	ff800513          	li	a0,-8
     470:	1e079a63          	bnez	a5,664 <.L59>
     474:	01c00793          	li	a5,28
     478:	02f60633          	mul	a2,a2,a5
     47c:	00c5aa03          	lw	s4,12(a1)
     480:	00200893          	li	a7,2
     484:	010a1793          	slli	a5,s4,0x10
     488:	0107d793          	srli	a5,a5,0x10
     48c:	010a5313          	srli	t1,s4,0x10
     490:	00c70733          	add	a4,a4,a2
     494:	00072903          	lw	s2,0(a4)
     498:	ffe90613          	addi	a2,s2,-2
     49c:	1cc8e463          	bltu	a7,a2,664 <.L59>
     4a0:	ffc90893          	addi	a7,s2,-4
     4a4:	0018b893          	seqz	a7,a7
     4a8:	1b089e63          	bne	a7,a6,664 <.L59>
     4ac:	00400513          	li	a0,4
     4b0:	00a90663          	beq	s2,a0,4bc <.L61>
     4b4:	ff800513          	li	a0,-8
     4b8:	1a0a9663          	bnez	s5,664 <.L59>

000004bc <.L61>:
     4bc:	ff800513          	li	a0,-8
     4c0:	1a078263          	beqz	a5,664 <.L59>
     4c4:	1a030063          	beqz	t1,664 <.L59>
     4c8:	01072803          	lw	a6,16(a4)
     4cc:	00010e37          	lui	t3,0x10
     4d0:	ffee0e13          	addi	t3,t3,-2 # fffe <.L278+0xef2e>
     4d4:	fff80893          	addi	a7,a6,-1
     4d8:	00010f37          	lui	t5,0x10
     4dc:	191e6463          	bltu	t3,a7,664 <.L59>
     4e0:	01472e83          	lw	t4,20(a4)
     4e4:	fffe8893          	addi	a7,t4,-1
     4e8:	171e6e63          	bltu	t3,a7,664 <.L59>
     4ec:	16f86c63          	bltu	a6,a5,664 <.L59>
     4f0:	166eea63          	bltu	t4,t1,664 <.L59>
     4f4:	01872b03          	lw	s6,24(a4)
     4f8:	17eb7663          	bgeu	s6,t5,664 <.L59>
     4fc:	0045ab83          	lw	s7,4(a1)
     500:	0085a583          	lw	a1,8(a1)
     504:	00872403          	lw	s0,8(a4)
     508:	00c72483          	lw	s1,12(a4)
     50c:	00472e03          	lw	t3,4(a4)
     510:	00bbe733          	or	a4,s7,a1
     514:	00876733          	or	a4,a4,s0
     518:	00976733          	or	a4,a4,s1
     51c:	01c76733          	or	a4,a4,t3
     520:	00177713          	andi	a4,a4,1
     524:	14071063          	bnez	a4,664 <.L59>
     528:	00179793          	slli	a5,a5,0x1
     52c:	12f46c63          	bltu	s0,a5,664 <.L59>
     530:	12f4ea63          	bltu	s1,a5,664 <.L59>
     534:	fff30313          	addi	t1,t1,-1
     538:	02830fb3          	mul	t6,t1,s0
     53c:	00be0c33          	add	s8,t3,a1
     540:	01cc3733          	sltu	a4,s8,t3
     544:	00181813          	slli	a6,a6,0x1
     548:	00000f13          	li	t5,0
     54c:	028332b3          	mulhu	t0,t1,s0
     550:	018f8533          	add	a0,t6,s8
     554:	01f53e33          	sltu	t3,a0,t6
     558:	00e28eb3          	add	t4,t0,a4
     55c:	01de0e33          	add	t3,t3,t4
     560:	00f50eb3          	add	t4,a0,a5
     564:	00aeb533          	sltu	a0,t4,a0
     568:	029333b3          	mulhu	t2,t1,s1
     56c:	01c50533          	add	a0,a0,t3
     570:	02930e33          	mul	t3,t1,s1
     574:	01778333          	add	t1,a5,s7
     578:	00f33cb3          	sltu	s9,t1,a5
     57c:	00f587b3          	add	a5,a1,a5
     580:	00b7b5b3          	sltu	a1,a5,a1
     584:	01f78fb3          	add	t6,a5,t6
     588:	005585b3          	add	a1,a1,t0
     58c:	00ffb7b3          	sltu	a5,t6,a5
     590:	00b787b3          	add	a5,a5,a1
     594:	019383b3          	add	t2,t2,s9
     598:	031405b3          	mul	a1,s0,a7
     59c:	006e0333          	add	t1,t3,t1
     5a0:	01c33e33          	sltu	t3,t1,t3
     5a4:	007e0e33          	add	t3,t3,t2
     5a8:	031438b3          	mulhu	a7,s0,a7
     5ac:	01058833          	add	a6,a1,a6
     5b0:	00b835b3          	sltu	a1,a6,a1
     5b4:	011588b3          	add	a7,a1,a7
     5b8:	0ef8e463          	bltu	a7,a5,6a0 <.L92>
     5bc:	01179463          	bne	a5,a7,5c4 <.L94>
     5c0:	0ff86063          	bltu	a6,t6,6a0 <.L92>

000005c4 <.L94>:
     5c4:	fe0005b7          	lui	a1,0xfe000
     5c8:	00bc0833          	add	a6,s8,a1
     5cc:	018837b3          	sltu	a5,a6,s8
     5d0:	fff70893          	addi	a7,a4,-1
     5d4:	011787b3          	add	a5,a5,a7
     5d8:	0c079463          	bnez	a5,6a0 <.L92>
     5dc:	0cb87263          	bgeu	a6,a1,6a0 <.L92>
     5e0:	0c051063          	bnez	a0,6a0 <.L92>
     5e4:	100007b7          	lui	a5,0x10000
     5e8:	0bd7ec63          	bltu	a5,t4,6a0 <.L92>
     5ec:	020005b7          	lui	a1,0x2000
     5f0:	ff800513          	li	a0,-8
     5f4:	06bbe863          	bltu	s7,a1,664 <.L59>
     5f8:	0a0e1463          	bnez	t3,6a0 <.L92>
     5fc:	0a67e263          	bltu	a5,t1,6a0 <.L92>
     600:	ffd67613          	andi	a2,a2,-3
     604:	02061263          	bnez	a2,628 <.L66>
     608:	02071063          	bnez	a4,628 <.L66>
     60c:	006c7e63          	bgeu	s8,t1,628 <.L66>
     610:	01dbfc63          	bgeu	s7,t4,628 <.L66>
     614:	00400793          	li	a5,4
     618:	04f91663          	bne	s2,a5,664 <.L59>
     61c:	098b9263          	bne	s7,s8,6a0 <.L92>
     620:	08ef1063          	bne	t5,a4,6a0 <.L92>
     624:	04941063          	bne	s0,s1,664 <.L59>

00000628 <.L66>:
     628:	02000613          	li	a2,32
     62c:	00000593          	li	a1,0
     630:	00068513          	mv	a0,a3
     634:	00000097          	auipc	ra,0x0
     638:	000080e7          	jalr	ra # 634 <.L66+0xc>
     63c:	01852023          	sw	s8,0(a0)
     640:	01752223          	sw	s7,4(a0)
     644:	00852423          	sw	s0,8(a0)
     648:	00952623          	sw	s1,12(a0)
     64c:	01452823          	sw	s4,16(a0)
     650:	01651b23          	sh	s6,22(a0)
     654:	01351d23          	sh	s3,26(a0)
     658:	01250e23          	sb	s2,28(a0)
     65c:	01550ea3          	sb	s5,29(a0)
     660:	00000513          	li	a0,0

00000664 <.L59>:
     664:	02c12083          	lw	ra,44(sp)
     668:	02812403          	lw	s0,40(sp)
     66c:	02412483          	lw	s1,36(sp)
     670:	02012903          	lw	s2,32(sp)
     674:	01c12983          	lw	s3,28(sp)
     678:	01812a03          	lw	s4,24(sp)
     67c:	01412a83          	lw	s5,20(sp)
     680:	01012b03          	lw	s6,16(sp)
     684:	00c12b83          	lw	s7,12(sp)
     688:	00812c03          	lw	s8,8(sp)
     68c:	00412c83          	lw	s9,4(sp)
     690:	03010113          	addi	sp,sp,48
     694:	00008067          	ret

00000698 <.L69>:
     698:	ff800513          	li	a0,-8
     69c:	00008067          	ret

000006a0 <.L92>:
     6a0:	ff800513          	li	a0,-8
     6a4:	fc1ff06f          	j	664 <.L59>

000006a8 <.L102>:
     6a8:	00008067          	ret

000006ac <gpu_instances_program>:
     6ac:	1c050663          	beqz	a0,878 <.L129>
     6b0:	00052783          	lw	a5,0(a0)
     6b4:	fa010113          	addi	sp,sp,-96
     6b8:	04912a23          	sw	s1,84(sp)
     6bc:	04112e23          	sw	ra,92(sp)
     6c0:	04812c23          	sw	s0,88(sp)
     6c4:	05212823          	sw	s2,80(sp)
     6c8:	05312623          	sw	s3,76(sp)
     6cc:	05412423          	sw	s4,72(sp)
     6d0:	05512223          	sw	s5,68(sp)
     6d4:	05612023          	sw	s6,64(sp)
     6d8:	03712e23          	sw	s7,60(sp)
     6dc:	03812c23          	sw	s8,56(sp)
     6e0:	03912a23          	sw	s9,52(sp)
     6e4:	00050493          	mv	s1,a0
     6e8:	16078c63          	beqz	a5,860 <.L107>
     6ec:	00058993          	mv	s3,a1
     6f0:	16058863          	beqz	a1,860 <.L107>
     6f4:	fff60713          	addi	a4,a2,-1
     6f8:	00f00693          	li	a3,15
     6fc:	00060b93          	mv	s7,a2
     700:	16e6e063          	bltu	a3,a4,860 <.L107>
     704:	00454703          	lbu	a4,4(a0)
     708:	02071e63          	bnez	a4,744 <.L109>

0000070c <.L115>:
     70c:	00000513          	li	a0,0

00000710 <.L105>:
     710:	05c12083          	lw	ra,92(sp)
     714:	05812403          	lw	s0,88(sp)
     718:	05412483          	lw	s1,84(sp)
     71c:	05012903          	lw	s2,80(sp)
     720:	04c12983          	lw	s3,76(sp)
     724:	04812a03          	lw	s4,72(sp)
     728:	04412a83          	lw	s5,68(sp)
     72c:	04012b03          	lw	s6,64(sp)
     730:	03c12b83          	lw	s7,60(sp)
     734:	03812c03          	lw	s8,56(sp)
     738:	03412c83          	lw	s9,52(sp)
     73c:	06010113          	addi	sp,sp,96
     740:	00008067          	ret

00000744 <.L109>:
     744:	00554703          	lbu	a4,5(a0)
     748:	ffd00513          	li	a0,-3
     74c:	fc0712e3          	bnez	a4,710 <.L105>
     750:	0127c703          	lbu	a4,18(a5) # 10000012 <.L278+0xfffef42>
     754:	fa071ee3          	bnez	a4,710 <.L105>
     758:	0007ab03          	lw	s6,0(a5)
     75c:	008b2903          	lw	s2,8(s6)
     760:	08097913          	andi	s2,s2,128
     764:	fa0916e3          	bnez	s2,710 <.L105>
     768:	00010c37          	lui	s8,0x10
     76c:	00058413          	mv	s0,a1
     770:	00058a13          	mv	s4,a1
     774:	00000a93          	li	s5,0
     778:	02000cb7          	lui	s9,0x2000
     77c:	fffc0c13          	addi	s8,s8,-1 # ffff <.L278+0xef2f>

00000780 <.L112>:
     780:	000a2783          	lw	a5,0(s4)
     784:	010a2703          	lw	a4,16(s4)
     788:	01010693          	addi	a3,sp,16
     78c:	ffc78793          	addi	a5,a5,-4
     790:	0017b793          	seqz	a5,a5
     794:	00879793          	slli	a5,a5,0x8
     798:	0157e7b3          	or	a5,a5,s5
     79c:	00f12023          	sw	a5,0(sp)
     7a0:	014a2783          	lw	a5,20(s4)
     7a4:	01877733          	and	a4,a4,s8
     7a8:	00000613          	li	a2,0
     7ac:	01079793          	slli	a5,a5,0x10
     7b0:	00e7e7b3          	or	a5,a5,a4
     7b4:	00010593          	mv	a1,sp
     7b8:	00098513          	mv	a0,s3
     7bc:	01912223          	sw	s9,4(sp)
     7c0:	00012423          	sw	zero,8(sp)
     7c4:	00f12623          	sw	a5,12(sp)
     7c8:	00000097          	auipc	ra,0x0
     7cc:	000080e7          	jalr	ra # 7c8 <.L112+0x48>
     7d0:	08051863          	bnez	a0,860 <.L107>
     7d4:	001a8793          	addi	a5,s5,1
     7d8:	01ca0a13          	addi	s4,s4,28
     7dc:	08fb9663          	bne	s7,a5,868 <.L119>
     7e0:	42cb0693          	addi	a3,s6,1068

000007e4 <.L114>:
     7e4:	00042783          	lw	a5,0(s0)
     7e8:	01010713          	addi	a4,sp,16
     7ec:	00f12823          	sw	a5,16(sp)
     7f0:	00442783          	lw	a5,4(s0)
     7f4:	00f12a23          	sw	a5,20(sp)
     7f8:	00842783          	lw	a5,8(s0)
     7fc:	00f12c23          	sw	a5,24(sp)
     800:	00c42783          	lw	a5,12(s0)
     804:	00f12e23          	sw	a5,28(sp)
     808:	01042783          	lw	a5,16(s0)
     80c:	02f12023          	sw	a5,32(sp)
     810:	01442783          	lw	a5,20(s0)
     814:	02f12223          	sw	a5,36(sp)
     818:	01842783          	lw	a5,24(s0)
     81c:	412b2623          	sw	s2,1036(s6)
     820:	02f12423          	sw	a5,40(sp)
     824:	410b0793          	addi	a5,s6,1040

00000828 <.L113>:
     828:	00072603          	lw	a2,0(a4)
     82c:	00478793          	addi	a5,a5,4
     830:	00470713          	addi	a4,a4,4
     834:	fec7ae23          	sw	a2,-4(a5)
     838:	fef698e3          	bne	a3,a5,828 <.L113>
     83c:	00190793          	addi	a5,s2,1
     840:	01c40413          	addi	s0,s0,28
     844:	032a9663          	bne	s5,s2,870 <.L120>
     848:	0ff0000f          	fence
     84c:	0004a783          	lw	a5,0(s1)
     850:	0007a783          	lw	a5,0(a5)
     854:	4047a783          	lw	a5,1028(a5)
     858:	0087f793          	andi	a5,a5,8
     85c:	ea0788e3          	beqz	a5,70c <.L115>

00000860 <.L107>:
     860:	ff800513          	li	a0,-8
     864:	eadff06f          	j	710 <.L105>

00000868 <.L119>:
     868:	00078a93          	mv	s5,a5
     86c:	f15ff06f          	j	780 <.L112>

00000870 <.L120>:
     870:	00078913          	mv	s2,a5
     874:	f71ff06f          	j	7e4 <.L114>

00000878 <.L129>:
     878:	ff800513          	li	a0,-8
     87c:	00008067          	ret

00000880 <gpu_instances_render>:
     880:	00051663          	bnez	a0,88c <.L134>
     884:	ff800513          	li	a0,-8
     888:	00008067          	ret

0000088c <.L134>:
     88c:	fa010113          	addi	sp,sp,-96
     890:	04812c23          	sw	s0,88(sp)
     894:	00052403          	lw	s0,0(a0)
     898:	04912a23          	sw	s1,84(sp)
     89c:	04112e23          	sw	ra,92(sp)
     8a0:	05212823          	sw	s2,80(sp)
     8a4:	05312623          	sw	s3,76(sp)
     8a8:	05412423          	sw	s4,72(sp)
     8ac:	05512223          	sw	s5,68(sp)
     8b0:	05612023          	sw	s6,64(sp)
     8b4:	03712e23          	sw	s7,60(sp)
     8b8:	03812c23          	sw	s8,56(sp)
     8bc:	00050493          	mv	s1,a0
     8c0:	1a040a63          	beqz	s0,a74 <.L144>
     8c4:	00058a13          	mv	s4,a1
     8c8:	1a058663          	beqz	a1,a74 <.L144>
     8cc:	00060913          	mv	s2,a2
     8d0:	1a060263          	beqz	a2,a74 <.L144>
     8d4:	000027b7          	lui	a5,0x2
     8d8:	00f607b3          	add	a5,a2,a5
     8dc:	4907a783          	lw	a5,1168(a5) # 2490 <.L278+0x13c0>
     8e0:	24800713          	li	a4,584
     8e4:	fff78793          	addi	a5,a5,-1
     8e8:	18f76663          	bltu	a4,a5,a74 <.L144>
     8ec:	00068993          	mv	s3,a3
     8f0:	18068263          	beqz	a3,a74 <.L144>
     8f4:	00554783          	lbu	a5,5(a0)
     8f8:	02078c63          	beqz	a5,930 <.L137>

000008fc <.L138>:
     8fc:	ffd00513          	li	a0,-3

00000900 <.L133>:
     900:	05c12083          	lw	ra,92(sp)
     904:	05812403          	lw	s0,88(sp)
     908:	05412483          	lw	s1,84(sp)
     90c:	05012903          	lw	s2,80(sp)
     910:	04c12983          	lw	s3,76(sp)
     914:	04812a03          	lw	s4,72(sp)
     918:	04412a83          	lw	s5,68(sp)
     91c:	04012b03          	lw	s6,64(sp)
     920:	03c12b83          	lw	s7,60(sp)
     924:	03812c03          	lw	s8,56(sp)
     928:	06010113          	addi	sp,sp,96
     92c:	00008067          	ret

00000930 <.L137>:
     930:	01244783          	lbu	a5,18(s0)
     934:	fc0794e3          	bnez	a5,8fc <.L138>
     938:	00454783          	lbu	a5,4(a0)
     93c:	04078663          	beqz	a5,988 <.L139>
     940:	00042783          	lw	a5,0(s0)
     944:	0087a703          	lw	a4,8(a5)
     948:	08077713          	andi	a4,a4,128
     94c:	fa0718e3          	bnez	a4,8fc <.L138>
     950:	0387a703          	lw	a4,56(a5)
     954:	ff900513          	li	a0,-7
     958:	fa0714e3          	bnez	a4,900 <.L133>
     95c:	00a45703          	lhu	a4,10(s0)
     960:	44e7a223          	sw	a4,1092(a5)
     964:	00100713          	li	a4,1
     968:	40e7a423          	sw	a4,1032(a5)
     96c:	0ff0000f          	fence
     970:	0004a783          	lw	a5,0(s1)
     974:	0007a783          	lw	a5,0(a5)
     978:	4047a783          	lw	a5,1028(a5)
     97c:	0087f793          	andi	a5,a5,8
     980:	0e079a63          	bnez	a5,a74 <.L144>
     984:	00e482a3          	sb	a4,5(s1)

00000988 <.L139>:
     988:	00002b37          	lui	s6,0x2
     98c:	00011723          	sh	zero,14(sp)
     990:	00000a93          	li	s5,0
     994:	01690b33          	add	s6,s2,s6

00000998 <.L140>:
     998:	490b2783          	lw	a5,1168(s6) # 2490 <.L278+0x13c0>
     99c:	04faea63          	bltu	s5,a5,9f0 <.L150>
     9a0:	00e15583          	lhu	a1,14(sp)
     9a4:	00098613          	mv	a2,s3
     9a8:	00040513          	mv	a0,s0
     9ac:	00000097          	auipc	ra,0x0
     9b0:	000080e7          	jalr	ra # 9ac <.L140+0x14>
     9b4:	f40516e3          	bnez	a0,900 <.L133>
     9b8:	0044c783          	lbu	a5,4(s1)
     9bc:	f40782e3          	beqz	a5,900 <.L133>
     9c0:	0004a783          	lw	a5,0(s1)
     9c4:	00200713          	li	a4,2
     9c8:	0007a783          	lw	a5,0(a5)
     9cc:	40e7a423          	sw	a4,1032(a5)
     9d0:	0ff0000f          	fence
     9d4:	0004a783          	lw	a5,0(s1)
     9d8:	0007a783          	lw	a5,0(a5)
     9dc:	4047a783          	lw	a5,1028(a5)
     9e0:	0017f793          	andi	a5,a5,1
     9e4:	f0079ce3          	bnez	a5,8fc <.L138>
     9e8:	000482a3          	sb	zero,5(s1)
     9ec:	f15ff06f          	j	900 <.L133>

000009f0 <.L150>:
     9f0:	00a45603          	lhu	a2,10(s0)
     9f4:	01010693          	addi	a3,sp,16
     9f8:	00090593          	mv	a1,s2
     9fc:	000a0513          	mv	a0,s4
     a00:	00000097          	auipc	ra,0x0
     a04:	000080e7          	jalr	ra # a00 <.L150+0x10>
     a08:	ee051ce3          	bnez	a0,900 <.L133>
     a0c:	0044c783          	lbu	a5,4(s1)
     a10:	02079663          	bnez	a5,a3c <.L154>
     a14:	00e10693          	addi	a3,sp,14
     a18:	00098613          	mv	a2,s3
     a1c:	01010593          	addi	a1,sp,16
     a20:	00040513          	mv	a0,s0
     a24:	00000097          	auipc	ra,0x0
     a28:	000080e7          	jalr	ra # a24 <.L150+0x34>
     a2c:	ec051ae3          	bnez	a0,900 <.L133>

00000a30 <.L149>:
     a30:	001a8a93          	addi	s5,s5,1
     a34:	01090913          	addi	s2,s2,16
     a38:	f61ff06f          	j	998 <.L140>

00000a3c <.L154>:
     a3c:	00098b93          	mv	s7,s3
     a40:	00f00c13          	li	s8,15

00000a44 <.L142>:
     a44:	01244783          	lbu	a5,18(s0)
     a48:	02078a63          	beqz	a5,a7c <.L143>
     a4c:	00e45583          	lhu	a1,14(s0)
     a50:	00040513          	mv	a0,s0
     a54:	00000097          	auipc	ra,0x0
     a58:	000080e7          	jalr	ra # a54 <.L142+0x10>
     a5c:	ea0542e3          	bltz	a0,900 <.L133>

00000a60 <.L146>:
     a60:	0004a783          	lw	a5,0(s1)
     a64:	0007a783          	lw	a5,0(a5)
     a68:	4047a703          	lw	a4,1028(a5)
     a6c:	00877693          	andi	a3,a4,8
     a70:	02068663          	beqz	a3,a9c <.L175>

00000a74 <.L144>:
     a74:	ff800513          	li	a0,-8
     a78:	e89ff06f          	j	900 <.L133>

00000a7c <.L143>:
     a7c:	0004a783          	lw	a5,0(s1)
     a80:	0007a783          	lw	a5,0(a5)
     a84:	0387a783          	lw	a5,56(a5)
     a88:	0ff7f793          	zext.b	a5,a5
     a8c:	00f409a3          	sb	a5,19(s0)
     a90:	fc0788e3          	beqz	a5,a60 <.L146>
     a94:	ff900513          	li	a0,-7
     a98:	e69ff06f          	j	900 <.L133>

00000a9c <.L175>:
     a9c:	00277713          	andi	a4,a4,2
     aa0:	08070e63          	beqz	a4,b3c <.L147>
     aa4:	01244703          	lbu	a4,18(s0)
     aa8:	08ec6a63          	bltu	s8,a4,b3c <.L147>
     aac:	00092703          	lw	a4,0(s2)
     ab0:	42e7a823          	sw	a4,1072(a5)
     ab4:	00492703          	lw	a4,4(s2)
     ab8:	42e7aa23          	sw	a4,1076(a5)
     abc:	00892703          	lw	a4,8(s2)
     ac0:	42e7ac23          	sw	a4,1080(a5)
     ac4:	00c92703          	lw	a4,12(s2)
     ac8:	42e7ae23          	sw	a4,1084(a5)
     acc:	0ff0000f          	fence
     ad0:	0004a783          	lw	a5,0(s1)
     ad4:	00100693          	li	a3,1
     ad8:	0007a783          	lw	a5,0(a5)
     adc:	44d7a023          	sw	a3,1088(a5)
     ae0:	0ff0000f          	fence
     ae4:	0004a783          	lw	a5,0(s1)
     ae8:	0007a783          	lw	a5,0(a5)
     aec:	4047a783          	lw	a5,1028(a5)
     af0:	0087f793          	andi	a5,a5,8
     af4:	f80790e3          	bnez	a5,a74 <.L144>
     af8:	00a45703          	lhu	a4,10(s0)
     afc:	00d408a3          	sb	a3,17(s0)
     b00:	00170793          	addi	a5,a4,1
     b04:	00f41523          	sh	a5,10(s0)
     b08:	00442783          	lw	a5,4(s0)
     b0c:	00e11723          	sh	a4,14(sp)
     b10:	00e41723          	sh	a4,14(s0)
     b14:	00178793          	addi	a5,a5,1
     b18:	00f42223          	sw	a5,4(s0)
     b1c:	01244783          	lbu	a5,18(s0)
     b20:	01444703          	lbu	a4,20(s0)
     b24:	00178793          	addi	a5,a5,1
     b28:	0ff7f793          	zext.b	a5,a5
     b2c:	00f40923          	sb	a5,18(s0)
     b30:	f0f770e3          	bgeu	a4,a5,a30 <.L149>
     b34:	00f40a23          	sb	a5,20(s0)
     b38:	ef9ff06f          	j	a30 <.L149>

00000b3c <.L147>:
     b3c:	fffb8793          	addi	a5,s7,-1
     b40:	000b8663          	beqz	s7,b4c <.L156>
     b44:	00078b93          	mv	s7,a5
     b48:	efdff06f          	j	a44 <.L142>

00000b4c <.L156>:
     b4c:	ffb00513          	li	a0,-5
     b50:	db1ff06f          	j	900 <.L133>

00000b54 <gpu_instances_build_into>:
     b54:	f9010113          	addi	sp,sp,-112
     b58:	06812423          	sw	s0,104(sp)
     b5c:	07012403          	lw	s0,112(sp)
     b60:	06112623          	sw	ra,108(sp)
     b64:	06912223          	sw	s1,100(sp)
     b68:	07212023          	sw	s2,96(sp)
     b6c:	05312e23          	sw	s3,92(sp)
     b70:	05412c23          	sw	s4,88(sp)
     b74:	05512a23          	sw	s5,84(sp)
     b78:	05612823          	sw	s6,80(sp)
     b7c:	05712623          	sw	s7,76(sp)
     b80:	05812423          	sw	s8,72(sp)
     b84:	05912223          	sw	s9,68(sp)
     b88:	05a12023          	sw	s10,64(sp)
     b8c:	03b12e23          	sw	s11,60(sp)
     b90:	04041263          	bnez	s0,bd4 <.L181>

00000b94 <.L183>:
     b94:	ff800513          	li	a0,-8

00000b98 <.L180>:
     b98:	06c12083          	lw	ra,108(sp)
     b9c:	06812403          	lw	s0,104(sp)
     ba0:	06412483          	lw	s1,100(sp)
     ba4:	06012903          	lw	s2,96(sp)
     ba8:	05c12983          	lw	s3,92(sp)
     bac:	05812a03          	lw	s4,88(sp)
     bb0:	05412a83          	lw	s5,84(sp)
     bb4:	05012b03          	lw	s6,80(sp)
     bb8:	04c12b83          	lw	s7,76(sp)
     bbc:	04812c03          	lw	s8,72(sp)
     bc0:	04412c83          	lw	s9,68(sp)
     bc4:	04012d03          	lw	s10,64(sp)
     bc8:	03c12d83          	lw	s11,60(sp)
     bcc:	07010113          	addi	sp,sp,112
     bd0:	00008067          	ret

00000bd4 <.L181>:
     bd4:	00042823          	sw	zero,16(s0)
     bd8:	00042423          	sw	zero,8(s0)
     bdc:	00042623          	sw	zero,12(s0)
     be0:	00042223          	sw	zero,4(s0)
     be4:	00042023          	sw	zero,0(s0)
     be8:	00050493          	mv	s1,a0
     bec:	fa0504e3          	beqz	a0,b94 <.L183>
     bf0:	00088a13          	mv	s4,a7
     bf4:	fa0880e3          	beqz	a7,b94 <.L183>
     bf8:	00003cb7          	lui	s9,0x3
     bfc:	01950cb3          	add	s9,a0,s9
     c00:	00078c13          	mv	s8,a5
     c04:	808ca783          	lw	a5,-2040(s9) # 2808 <.L278+0x1738>
     c08:	00070a93          	mv	s5,a4
     c0c:	1ff00713          	li	a4,511
     c10:	fff78793          	addi	a5,a5,-1
     c14:	f8f760e3          	bltu	a4,a5,b94 <.L183>
     c18:	fff80793          	addi	a5,a6,-1
     c1c:	24800713          	li	a4,584
     c20:	00080993          	mv	s3,a6
     c24:	f6f768e3          	bltu	a4,a5,b94 <.L183>
     c28:	00058913          	mv	s2,a1
     c2c:	00060b93          	mv	s7,a2
     c30:	00068b13          	mv	s6,a3
     c34:	00000097          	auipc	ra,0x0
     c38:	000080e7          	jalr	ra # c34 <.L181+0x60>
     c3c:	f4050ce3          	beqz	a0,b94 <.L183>
     c40:	000a8663          	beqz	s5,c4c <.L184>
     c44:	829cc783          	lbu	a5,-2007(s9)
     c48:	f40796e3          	bnez	a5,b94 <.L183>

00000c4c <.L184>:
     c4c:	016bebb3          	or	s7,s7,s6
     c50:	015bebb3          	or	s7,s7,s5
     c54:	00100793          	li	a5,1
     c58:	f377eee3          	bltu	a5,s7,b94 <.L183>
     c5c:	21b00793          	li	a5,539
     c60:	f387eae3          	bltu	a5,s8,b94 <.L183>
     c64:	ffe00737          	lui	a4,0xffe00
     c68:	fff70713          	addi	a4,a4,-1 # ffdfffff <.L278+0xffdfef2f>
     c6c:	00e97733          	and	a4,s2,a4
     c70:	020007b7          	lui	a5,0x2000
     c74:	f2f710e3          	bne	a4,a5,b94 <.L183>
     c78:	78000693          	li	a3,1920
     c7c:	02dc06b3          	mul	a3,s8,a3
     c80:	21c00713          	li	a4,540
     c84:	418707b3          	sub	a5,a4,s8
     c88:	00042703          	lw	a4,0(s0)
     c8c:	03412423          	sw	s4,40(sp)
     c90:	02812623          	sw	s0,44(sp)
     c94:	ffc00513          	li	a0,-4
     c98:	01268633          	add	a2,a3,s2
     c9c:	04e98263          	beq	s3,a4,ce0 <.L185>
     ca0:	00170593          	addi	a1,a4,1
     ca4:	00471713          	slli	a4,a4,0x4
     ca8:	00ea08b3          	add	a7,s4,a4
     cac:	01079713          	slli	a4,a5,0x10
     cb0:	00b42023          	sw	a1,0(s0)
     cb4:	3c076713          	ori	a4,a4,960
     cb8:	00e8a623          	sw	a4,12(a7)
     cbc:	3c000713          	li	a4,960
     cc0:	02e787b3          	mul	a5,a5,a4
     cc4:	00c42703          	lw	a4,12(s0)
     cc8:	0008a023          	sw	zero,0(a7)
     ccc:	00c8a223          	sw	a2,4(a7)
     cd0:	00d8a423          	sw	a3,8(a7)
     cd4:	00000513          	li	a0,0
     cd8:	00f707b3          	add	a5,a4,a5
     cdc:	00f42623          	sw	a5,12(s0)

00000ce0 <.L185>:
     ce0:	00003c37          	lui	s8,0x3
     ce4:	00010d37          	lui	s10,0x10
     ce8:	00048b93          	mv	s7,s1
     cec:	00048a13          	mv	s4,s1
     cf0:	00000c93          	li	s9,0
     cf4:	01848c33          	add	s8,s1,s8
     cf8:	01c10d93          	addi	s11,sp,28
     cfc:	fff00313          	li	t1,-1
     d00:	00300e13          	li	t3,3
     d04:	fffd0d13          	addi	s10,s10,-1 # ffff <.L278+0xef2f>

00000d08 <.L186>:
     d08:	00051863          	bnez	a0,d18 <.L190>
     d0c:	000b0663          	beqz	s6,d18 <.L190>
     d10:	808c2783          	lw	a5,-2040(s8) # 2808 <.L278+0x1738>
     d14:	1afce063          	bltu	s9,a5,eb4 <.L191>

00000d18 <.L190>:
     d18:	01503cb3          	snez	s9,s5
     d1c:	00003a37          	lui	s4,0x3
     d20:	00010d37          	lui	s10,0x10
     d24:	002c8c93          	addi	s9,s9,2
     d28:	00000c13          	li	s8,0
     d2c:	01448a33          	add	s4,s1,s4
     d30:	00500d93          	li	s11,5
     d34:	00300313          	li	t1,3
     d38:	01c10e13          	addi	t3,sp,28
     d3c:	fffd0d13          	addi	s10,s10,-1 # ffff <.L278+0xef2f>

00000d40 <.L194>:
     d40:	06051e63          	bnez	a0,dbc <.L205>
     d44:	808a2783          	lw	a5,-2040(s4) # 2808 <.L278+0x1738>
     d48:	1efc6463          	bltu	s8,a5,f30 <.L200>
     d4c:	824a4783          	lbu	a5,-2012(s4)
     d50:	040b0c63          	beqz	s6,da8 <.L207>
     d54:	06078263          	beqz	a5,db8 <.L203>
     d58:	80ca2703          	lw	a4,-2036(s4)
     d5c:	810a2783          	lw	a5,-2032(s4)
     d60:	820a5683          	lhu	a3,-2016(s4)
     d64:	ffa70713          	addi	a4,a4,-6
     d68:	ffa78793          	addi	a5,a5,-6 # 1fffffa <.L278+0x1ffef2a>
     d6c:	04000893          	li	a7,64
     d70:	00068463          	beqz	a3,d78 <.L206>
     d74:	0c000893          	li	a7,192

00000d78 <.L206>:
     d78:	01c10693          	addi	a3,sp,28
     d7c:	00d12223          	sw	a3,4(sp)
     d80:	fff00693          	li	a3,-1
     d84:	00d12023          	sw	a3,0(sp)
     d88:	00c00813          	li	a6,12
     d8c:	00100693          	li	a3,1
     d90:	00090613          	mv	a2,s2
     d94:	00098593          	mv	a1,s3
     d98:	02810513          	addi	a0,sp,40
     d9c:	00000097          	auipc	ra,0x0
     da0:	000080e7          	jalr	ra # d9c <.L206+0x24>
     da4:	00051c63          	bnez	a0,dbc <.L205>

00000da8 <.L207>:
     da8:	00003737          	lui	a4,0x3
     dac:	00e48733          	add	a4,s1,a4
     db0:	82474783          	lbu	a5,-2012(a4) # 2824 <.L278+0x1754>
     db4:	20079263          	bnez	a5,fb8 <.L202>

00000db8 <.L203>:
     db8:	00000513          	li	a0,0

00000dbc <.L205>:
     dbc:	000037b7          	lui	a5,0x3
     dc0:	00f487b3          	add	a5,s1,a5
     dc4:	8247c703          	lbu	a4,-2012(a5) # 2824 <.L278+0x1754>
     dc8:	05000b93          	li	s7,80
     dcc:	02070063          	beqz	a4,dec <.L208>
     dd0:	8147a783          	lw	a5,-2028(a5)
     dd4:	03c00713          	li	a4,60
     dd8:	02e7f7b3          	remu	a5,a5,a4
     ddc:	02b00713          	li	a4,43
     de0:	00f77663          	bgeu	a4,a5,dec <.L208>
     de4:	00379793          	slli	a5,a5,0x3
     de8:	ef878b93          	addi	s7,a5,-264

00000dec <.L208>:
     dec:	00000db7          	lui	s11,0x0
     df0:	00003a37          	lui	s4,0x3
     df4:	000d8d93          	mv	s11,s11
     df8:	00000d13          	li	s10,0
     dfc:	00300c13          	li	s8,3
     e00:	fff00c93          	li	s9,-1
     e04:	01448a33          	add	s4,s1,s4

00000e08 <.L209>:
     e08:	22051a63          	bnez	a0,103c <.L216>
     e0c:	d98d06e3          	beq	s10,s8,b98 <.L180>
     e10:	020a8263          	beqz	s5,e34 <.L210>
     e14:	828a4783          	lbu	a5,-2008(s4) # 2828 <.L278+0x1758>
     e18:	00078e63          	beqz	a5,e34 <.L210>
     e1c:	000037b7          	lui	a5,0x3
     e20:	82578793          	addi	a5,a5,-2011 # 2825 <.L278+0x1755>
     e24:	00fd07b3          	add	a5,s10,a5
     e28:	00f487b3          	add	a5,s1,a5
     e2c:	0007c783          	lbu	a5,0(a5)
     e30:	06078c63          	beqz	a5,ea8 <.L211>

00000e34 <.L210>:
     e34:	000da783          	lw	a5,0(s11) # 0 <sprite>
     e38:	02f12023          	sw	a5,32(sp)
     e3c:	004da783          	lw	a5,4(s11)
     e40:	02f12223          	sw	a5,36(sp)
     e44:	000a8e63          	beqz	s5,e60 <.L212>
     e48:	02410693          	addi	a3,sp,36
     e4c:	02010613          	addi	a2,sp,32
     e50:	000d0593          	mv	a1,s10
     e54:	00048513          	mv	a0,s1
     e58:	00000097          	auipc	ra,0x0
     e5c:	000080e7          	jalr	ra # e58 <.L210+0x24>

00000e60 <.L212>:
     e60:	02012703          	lw	a4,32(sp)
     e64:	02412783          	lw	a5,36(sp)
     e68:	180b1a63          	bnez	s6,ffc <.L213>

00000e6c <.L215>:
     e6c:	01c10793          	addi	a5,sp,28
     e70:	02012703          	lw	a4,32(sp)
     e74:	00f12223          	sw	a5,4(sp)
     e78:	02412783          	lw	a5,36(sp)
     e7c:	01912023          	sw	s9,0(sp)
     e80:	00000893          	li	a7,0
     e84:	01000813          	li	a6,16
     e88:	ff878793          	addi	a5,a5,-8
     e8c:	ff870713          	addi	a4,a4,-8
     e90:	009d0693          	addi	a3,s10,9
     e94:	00090613          	mv	a2,s2
     e98:	00098593          	mv	a1,s3
     e9c:	02810513          	addi	a0,sp,40
     ea0:	00000097          	auipc	ra,0x0
     ea4:	000080e7          	jalr	ra # ea0 <.L215+0x34>

00000ea8 <.L211>:
     ea8:	001d0d13          	addi	s10,s10,1
     eac:	008d8d93          	addi	s11,s11,8
     eb0:	f59ff06f          	j	e08 <.L209>

00000eb4 <.L191>:
     eb4:	000a8e63          	beqz	s5,ed0 <.L187>
     eb8:	00ea4783          	lbu	a5,14(s4)
     ebc:	01c78663          	beq	a5,t3,ec8 <.L188>
     ec0:	828c4783          	lbu	a5,-2008(s8)
     ec4:	00078663          	beqz	a5,ed0 <.L187>

00000ec8 <.L188>:
     ec8:	00ca5783          	lhu	a5,12(s4)
     ecc:	05a78c63          	beq	a5,s10,f24 <.L189>

00000ed0 <.L187>:
     ed0:	804c2883          	lw	a7,-2044(s8)
     ed4:	004a2783          	lw	a5,4(s4)
     ed8:	000a2703          	lw	a4,0(s4)
     edc:	00f8f893          	andi	a7,a7,15
     ee0:	01088893          	addi	a7,a7,16
     ee4:	4087d793          	srai	a5,a5,0x8
     ee8:	40875713          	srai	a4,a4,0x8
     eec:	00612023          	sw	t1,0(sp)
     ef0:	01b12223          	sw	s11,4(sp)
     ef4:	00289893          	slli	a7,a7,0x2
     ef8:	00c00813          	li	a6,12
     efc:	ffe78793          	addi	a5,a5,-2
     f00:	ffe70713          	addi	a4,a4,-2
     f04:	00100693          	li	a3,1
     f08:	00090613          	mv	a2,s2
     f0c:	00098593          	mv	a1,s3
     f10:	02810513          	addi	a0,sp,40
     f14:	00000097          	auipc	ra,0x0
     f18:	000080e7          	jalr	ra # f14 <.L187+0x44>
     f1c:	00300e13          	li	t3,3
     f20:	fff00313          	li	t1,-1

00000f24 <.L189>:
     f24:	008c8c93          	addi	s9,s9,8
     f28:	0a0a0a13          	addi	s4,s4,160
     f2c:	dddff06f          	j	d08 <.L186>

00000f30 <.L200>:
     f30:	00ebc783          	lbu	a5,14(s7)
     f34:	12fcc063          	blt	s9,a5,1054 <.L223>
     f38:	00fbc683          	lbu	a3,15(s7)
     f3c:	10ddec63          	bltu	s11,a3,1054 <.L223>
     f40:	00678863          	beq	a5,t1,f50 <.L196>
     f44:	000a8a63          	beqz	s5,f58 <.L197>
     f48:	828a4783          	lbu	a5,-2008(s4)
     f4c:	00078663          	beqz	a5,f58 <.L197>

00000f50 <.L196>:
     f50:	00cbd783          	lhu	a5,12(s7)
     f54:	05a78c63          	beq	a5,s10,fac <.L198>

00000f58 <.L197>:
     f58:	004ba783          	lw	a5,4(s7)
     f5c:	000ba703          	lw	a4,0(s7)
     f60:	00000893          	li	a7,0
     f64:	01c12223          	sw	t3,4(sp)
     f68:	00d12023          	sw	a3,0(sp)
     f6c:	00800813          	li	a6,8
     f70:	4087d793          	srai	a5,a5,0x8
     f74:	40875713          	srai	a4,a4,0x8
     f78:	00268693          	addi	a3,a3,2
     f7c:	00090613          	mv	a2,s2
     f80:	00098593          	mv	a1,s3
     f84:	02810513          	addi	a0,sp,40
     f88:	00000097          	auipc	ra,0x0
     f8c:	000080e7          	jalr	ra # f88 <.L197+0x30>
     f90:	01c10e13          	addi	t3,sp,28
     f94:	00300313          	li	t1,3
     f98:	00051a63          	bnez	a0,fac <.L198>
     f9c:	00442783          	lw	a5,4(s0)
     fa0:	01c12703          	lw	a4,28(sp)
     fa4:	00e787b3          	add	a5,a5,a4
     fa8:	00f42223          	sw	a5,4(s0)

00000fac <.L198>:
     fac:	001c0c13          	addi	s8,s8,1
     fb0:	014b8b93          	addi	s7,s7,20
     fb4:	d8dff06f          	j	d40 <.L194>

00000fb8 <.L202>:
     fb8:	81072783          	lw	a5,-2032(a4)
     fbc:	80c72703          	lw	a4,-2036(a4)
     fc0:	01c10693          	addi	a3,sp,28
     fc4:	00d12223          	sw	a3,4(sp)
     fc8:	fff00693          	li	a3,-1
     fcc:	00d12023          	sw	a3,0(sp)
     fd0:	00000893          	li	a7,0
     fd4:	01000813          	li	a6,16
     fd8:	ff878793          	addi	a5,a5,-8
     fdc:	ff870713          	addi	a4,a4,-8
     fe0:	00800693          	li	a3,8
     fe4:	00090613          	mv	a2,s2
     fe8:	00098593          	mv	a1,s3
     fec:	02810513          	addi	a0,sp,40
     ff0:	00000097          	auipc	ra,0x0
     ff4:	000080e7          	jalr	ra # ff0 <.L202+0x38>
     ff8:	dc5ff06f          	j	dbc <.L205>

00000ffc <.L213>:
     ffc:	01c10693          	addi	a3,sp,28
    1000:	00d12223          	sw	a3,4(sp)
    1004:	fff00693          	li	a3,-1
    1008:	00d12023          	sw	a3,0(sp)
    100c:	000b8893          	mv	a7,s7
    1010:	00c00813          	li	a6,12
    1014:	ffa78793          	addi	a5,a5,-6
    1018:	ffa70713          	addi	a4,a4,-6
    101c:	00100693          	li	a3,1
    1020:	00090613          	mv	a2,s2
    1024:	00098593          	mv	a1,s3
    1028:	02810513          	addi	a0,sp,40
    102c:	00000097          	auipc	ra,0x0
    1030:	000080e7          	jalr	ra # 102c <.L213+0x30>
    1034:	e6051ae3          	bnez	a0,ea8 <.L211>
    1038:	e35ff06f          	j	e6c <.L215>

0000103c <.L216>:
    103c:	00042823          	sw	zero,16(s0)
    1040:	00042423          	sw	zero,8(s0)
    1044:	00042623          	sw	zero,12(s0)
    1048:	00042223          	sw	zero,4(s0)
    104c:	00042023          	sw	zero,0(s0)
    1050:	b49ff06f          	j	b98 <.L180>

00001054 <.L223>:
    1054:	ff800513          	li	a0,-8
    1058:	d65ff06f          	j	dbc <.L205>

0000105c <gpu_instances_build>:
    105c:	06080a63          	beqz	a6,10d0 <.L278>
    1060:	fc010113          	addi	sp,sp,-64
    1064:	02812c23          	sw	s0,56(sp)
    1068:	00080413          	mv	s0,a6
    106c:	01c10813          	addi	a6,sp,28
    1070:	01012023          	sw	a6,0(sp)
    1074:	00040893          	mv	a7,s0
    1078:	00078813          	mv	a6,a5
    107c:	00070793          	mv	a5,a4
    1080:	00000713          	li	a4,0
    1084:	02112e23          	sw	ra,60(sp)
    1088:	00000097          	auipc	ra,0x0
    108c:	000080e7          	jalr	ra # 1088 <gpu_instances_build+0x2c>
    1090:	000027b7          	lui	a5,0x2
    1094:	00f40833          	add	a6,s0,a5
    1098:	01c12783          	lw	a5,28(sp)
    109c:	03c12083          	lw	ra,60(sp)
    10a0:	03812403          	lw	s0,56(sp)
    10a4:	48f82823          	sw	a5,1168(a6)
    10a8:	02012783          	lw	a5,32(sp)
    10ac:	48f82a23          	sw	a5,1172(a6)
    10b0:	02412783          	lw	a5,36(sp)
    10b4:	48f82c23          	sw	a5,1176(a6)
    10b8:	02812783          	lw	a5,40(sp)
    10bc:	48f82e23          	sw	a5,1180(a6)
    10c0:	02c12783          	lw	a5,44(sp)
    10c4:	4af82023          	sw	a5,1184(a6)
    10c8:	04010113          	addi	sp,sp,64
    10cc:	00008067          	ret

000010d0 <.L278>:
    10d0:	ff800513          	li	a0,-8
    10d4:	00008067          	ret