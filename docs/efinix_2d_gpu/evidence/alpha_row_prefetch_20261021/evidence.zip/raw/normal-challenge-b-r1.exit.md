# Collector exit record

Execution session3414 returned exit_code1 at 2026-10-21 12:40:47 +08. Tool-captured error (copied here; this is an execution note, not firmware UART):

```
Exception: scripts/test-game-menu-board.ps1:108
Deadline: automatic search and full3600 verification; raw capture retained
```

No performance-final.json was produced; no new qualified best. HTTP capture records full verification attempts2322,2321,2320,2319 followed by fresh search with best0. Original algorithm and900second search deadline unchanged. No manual restart, threshold edit, or firmware replacement during this collector run.

finally cleanup ran: keepalive.log KEEPALIVE_EXIT,code=0, owner released; independently queried fresh telemetry MENU, owned=false, performance=null, under/error0. No openocd/ftdi_pgm/efx_run processes found. Six-tier START/MENU ACK transitions before challenge retained in transitions.log; do not label the overall collector PASS.
