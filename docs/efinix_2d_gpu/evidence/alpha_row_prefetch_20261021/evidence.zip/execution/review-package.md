# Final whole-round read-only review

Worktree D:/ZYNQ/smallproject/.worktrees/pango-riscv-cpu, branch codex/efinix-2d-gpu. Base3e53d3215972d0546534c825a806d784b9712482, Headc479f38a8c29868e6c8898a1dc84bfe3bb52cf9f. All product/test/report changes committed; unrelated user untracked files preserved. Native package replaces WSL absolute-gitdir helper; no tree/index/branch mutation, no board/COM/JTAG/network-control writes, no subagents/re-review.

Plan docs/superpowers/plans/2026-10-21-alpha-row-prefetch.md; spec docs/superpowers/specs/2026-10-21-alpha-row-prefetch-design.md. Main source4files + existing AlphaPipelineSpec; no firmware/CPU/clock changes. Default-off one-row read lookahead, existing FIFO33/singlewriter, abandonedlookahead drain/flush, only legal smallnonoverlapAlpha.

Review Focus (verbatim):
Late B error with next-row R stalled must drain; abandoned aligner/FIFO data must not poison following Alpha; shared halfword/4KiB edge must preserve adjacent pixels; in-place/wide Alpha must fall back; last row/next AW/completion must not run before required write retirement. Task1 pins each condition.

Evidence root generated/verification/v3/alpha-row-prefetch-20261021. RED missingflag, initialnew3GREEN; affected-generate-r1.log12+1PASS, row-distinct-r1.log1PASS, packed-edges-r1.log1PASS =15unique. Additionalpackedtest Java21vspriorJava17, no productchanges. Real RenderEngine with byte-memory golden, six faults/readBID/stalledfutureR and followingAlpha.

Physical map/interface/pnr/pgmPASS,16finalpositive core+.264/.003ns thinhold disclosed; XLR52866/RAM179/DSP37, CDC1488/2/2 max1.128/.996/.805ns. cdc/resource-gate logs; D:/efinity_builds/alpha_row_prefetch_20261021_r1. CandidateBITd594d3; controlfour-credit07011f.

24boardAlphaoracle old/new PASS, under_offscreen0..22 disclosednotnormalhealth. Same-BIN AXI24windows A/B/A CRC/count/bytesmatch AW/Bbalanced;1040Alpha14.66..15.15% faster/full3.34..3.52%. Ordinary1024sameBIN3600 A/B/A work13776→13408→13784us,59.7→60.0→59.4FPS;Bmiss6/late6 soNOTstable60. Allnormalhealth0/stateCRCmatch.

Unchanged normal33aac challenge failed long2322/2321/2320/2319 and900sdeadlineexit1, rawHTTP14MB retained; no qualifiednewbest/finalJSON. normal-challenge-b-r1.exit.md is manually copied toolerror record, not UART. Do not treat challenge asPASSorold2194asnewBITscore. Board finalMENU/released/noJTAG/health0 freshlyqueried. No push/Flash/release.

Read progress.md Ruling lines: userinline/noapproval authorization+nativeWindows ledger; only targeted affected suites not unchangedCPU/SoC (historictwofailuresnotfixed). Scope limitations explicitly report manualvisual/movement/grayzoom/longduration/otherflags not retested. Archive not yetsealed, will contain finalreview/executionrecords; do not assume reportinsideZIPselfhash.

Review by actual user impact incl legitimateconditions outsidewordedspec; identify concrete failures/coverageissues, severityCritical/Important/Minor withfilelines and rationale. List consideredbutdeclinedbehaviors withreason (emptyifnone), not genericimaginedscope. FinalAssessment ready? Readonly author-independentstaticreview only. Do not run long unchangedsuites or interactwithliveboard.
