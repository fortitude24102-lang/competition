# Task2 brief

Source: docs/superpowers/plans/2026-10-21-alpha-row-prefetch.md; spec is binding. Base56fbafd.

Consume tested trailing enableAlphaRowPrefetch/--alpha-row-prefetch atop four-credit stable options. Produce fresh60-single-module RTL/physical evidence, same-BIN board A/B/A and eligible normal3600 challenge, selected normalMENU/ownerrelease/toolsstopped, report/README/localcommit/sealed records. No remote/Flash/release or CPU workload changes.

Physical expected: allfour compile stages PASS, all16 final setup/hold strictlypositive, XLR<54720, routed1488/2/2 CDC<8ns. Already measuredPASS, corehold+.003ns is thin and must remain disclosed. Do not interpret it as overclock/robustness proof.

Board control BIT07011f, candidate d594d3; identical AXI427430,1024bd5489,normal33aac,Alphaoracle5a841a BIN identities. ControlA1/24Alpha already complete; never redo. Candidate24oracle→AXI24phase→1024 3600; controlA2AXI→1024. If measuredgain/health viable, candidate normal3600+5s challenge. Preserve failed windows; no thresholds/element changes. Restore normal6tier MENU and release lease/stopJTAG. No concurrent board jobs.

One fresh read-only whole-round reviewer after work. ReviewFocus: lateB/nextRstalled drain; no abandonedbuffer poisoning; sharedhalfword/4KiB neighbors; fallbackwide/inplace; noearlynextAW/retirement. Archive rulings and any declinedreview judgments. No repeated unchanged fullSoCsuite or recursivecleanup bypass.
