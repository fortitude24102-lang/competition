# Evidence identity and usage

Production source66e954f; final test/docs snapshot626352d. Reviewrange6c19143..1110f19, review resolutions documented inreview.md. GenerationRTL c5c807b86b51474d904f027dfcbef193. This is evidence for the existing repository/BSP, not a standalone portable Efinity installer.

safe-candidate/efinix_2d_gpu.bit SHA256118491efb159cc4c8ad2f47b42fc073b5d956a43e9d106fe944df4db2f250dce.
safe-candidate/gpu_demo.bin SHA25633aac5fa90d290c3820d9e3c537fe7c8c51785e9409c668410744bf27d42311e.
Only that normal pair is the2065+259Alpha3600/5s qualification pair. JTAG/RAMonly, fullBIT reloadbeforePRESENT firmware; never writeFlash using these notes. Defaultsourcegeneratorflagremainsfalse.

control/efinix_2d_gpu.bit SHA256a476bfaae3c7f1d384ddcd9a7ce78c24498f0e64493be40ad66874989c1cc945.
diagnostic-only/probe1024.bin SHA256bd5489d8a8e39fca40dbbdeed357be035b619204b44a4422fa96bd95d39d77b7.
Otherdiagnostic-only BINs are isolatedHUD/AXI/trace programs, not normal game or independent qualification. The trace BIN alters code layout, never a production score.

negative-staging/ holds rejectedsource/patch ONLY, no deployable stagingBIN. SameBIN6aa08b... A/B/A was slower and productionchange wasreverted. Preserve negative logs; do not re-enablethatpath from snapshot.

Archive README is pre-ZIP snapshot and cannot contain its own finalZIPhash; repository evidence README links finalZIP/SHA separately. Historical sealedZIPs unchanged. No main push/release/Flash replacement. Finalboardstate normalcandidateMENU,ownerreleased,health0; visual/manual/endurance/stack/arbitrarybrokenAXIrecovery remainunmeasured.
