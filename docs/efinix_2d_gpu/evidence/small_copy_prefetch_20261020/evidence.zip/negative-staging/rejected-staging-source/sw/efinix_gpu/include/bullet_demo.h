#ifndef EFINIX_BULLET_DEMO_H
#define EFINIX_BULLET_DEMO_H
#include "gpu.h"
#ifndef BULLET_OBJECT_CAPACITY
#define BULLET_OBJECT_CAPACITY 512u
#endif
#define BULLET_MAX_OBJECTS BULLET_OBJECT_CAPACITY
_Static_assert(BULLET_MAX_OBJECTS>=32 && BULLET_MAX_OBJECTS<=1024,"object capacity bound");
#define BULLET_MAX_TRAILS (BULLET_MAX_OBJECTS/8u)
#define BULLET_MAX_COMMANDS (BULLET_MAX_OBJECTS+8u+BULLET_MAX_TRAILS+1u)
#define BULLET_START_HP 3u
#define BULLET_PROTECTION_TICKS 60u
#define BULLET_RESTART_TICKS 120u
#define BULLET_ENEMY_COUNT 3u
#define BULLET_ENEMY_HP 6u
#define BULLET_PATH_COUNT 6u
#define BULLET_BACKGROUND_ADDR 0x02900000u
#define BULLET_ATLAS_ADDR 0x02a00000u
#define BULLET_LOCAL_BACKGROUND 0x02b00000u
#define BULLET_LOCAL_ATLAS 0x02c00000u
#define BULLET_SHAPE_COUNT 6u
#define BULLET_PLAYER_OFFSET (BULLET_SHAPE_COUNT*128u)
#define BULLET_GLOW_OFFSET (BULLET_PLAYER_OFFSET+512u)
#define BULLET_EMITTER_OFFSET (BULLET_GLOW_OFFSET+288u)
#define BULLET_ATLAS_BYTES (BULLET_EMITTER_OFFSET+3u*512u)
#define BULLET_COLOR_KEY 0xf81fu
#define BULLET_REPLAY_FRAMES 600u
_Static_assert(BULLET_BACKGROUND_ADDR+GPU_FRAME_BYTES<=BULLET_ATLAS_ADDR,"network asset separation");
_Static_assert(BULLET_ATLAS_ADDR+BULLET_ATLAS_BYTES<=BULLET_LOCAL_BACKGROUND,"fallback cannot overlap DMA");
_Static_assert(BULLET_LOCAL_BACKGROUND+GPU_FRAME_BYTES<=BULLET_LOCAL_ATLAS,"local asset separation");
_Static_assert(BULLET_LOCAL_ATLAS+BULLET_ATLAS_BYTES<=GPU_DDR_END_EXCLUSIVE,"asset DDR bounds");
typedef struct { int32_t x,y; int16_t vx,vy; uint16_t age; uint8_t kind,shape,grazed,path; } bullet_object;
typedef struct {
 bullet_object objects[BULLET_MAX_OBJECTS];
 uint32_t seed,tick; unsigned count;
 int player_x,player_y; /* Legacy auto-pilot or explicit interactive coordinates. */
 uint32_t round_tick,score,grazes;
 uint16_t invulnerable,game_over_ticks;
 uint8_t hp;
 uint8_t enemy_hp[BULLET_ENEMY_COUNT],interactive,won;
} bullet_state;
typedef struct {
 union {
  gpu_command commands[BULLET_MAX_COMMANDS];
  gpu_instance instances[BULLET_MAX_COMMANDS]; /* Same storage, GPU-only staging. */
 };
 unsigned count,visible; uint32_t scene_pixels;
 unsigned alpha_commands; uint32_t alpha_pixels;
} bullet_stream;
_Static_assert(offsetof(bullet_stream,count)==BULLET_MAX_COMMANDS*sizeof(gpu_command),"unchanged CPU scene buffer");
int bullet_reset(bullet_state *state,unsigned count,uint32_t seed);
int bullet_reset_player(bullet_state *state,unsigned count,uint32_t seed);
/* Pure seeded waypoints shared by drawing, projectile origins and hit tests. */
int bullet_enemy_position(const bullet_state *state,unsigned enemy,int *x,int *y);
int bullet_campaign_valid(const bullet_state *state);
/* Analytic atlas mask for clipped visibility; zero for invalid shape/texel. */
int bullet_shape_opaque(unsigned shape,unsigned x,unsigned y);
int bullet_step(bullet_state *state);
/* Interactive-only entry: manual coordinates and kind=3 friendly projectiles.
 * The legacy entry above retains its original validation and auto-pilot. */
int bullet_step_player(bullet_state *state,int player_x,int player_y);
/* Optional immutable canonical game-reset snapshot; all normal step validation
 * runs before reuse. Used only by the LIVE runtime, never the CPU renderer. */
int bullet_step_player_cached(bullet_state *state,int player_x,int player_y,const bullet_state *initial);
int bullet_build_frame(const bullet_state *state,uint32_t dst,int network,int glow,
                      unsigned capacity,bullet_stream *stream);
int bullet_build_frame_player(const bullet_state *state,uint32_t dst,int network,int glow,
                             unsigned capacity,bullet_stream *stream);
int bullet_clip_background_for_hud(bullet_stream *stream,unsigned hud_height);
int bullet_prepare_frame(bullet_state *state,unsigned count,unsigned frame,uint32_t seed);
int bullet_finish_window(bullet_state *state,bullet_state *start,int gpu_window);
void bullet_init_local_assets(void);
int bullet_load_network_assets(uintptr_t base,uint32_t session);
/* Failure regenerates disjoint local assets, even if a DMA abort is unfinished. */
int bullet_prepare_assets(uintptr_t base,uint32_t session);
int bullet_prepare_texture_cache(gpu_device *gpu,int network_result,uint32_t poll_limit);
#endif
