#ifndef EFINIX_GPU_H
#define EFINIX_GPU_H
#include "gpu_regs.h"
#ifndef GPU_SUBMIT_SHADOW
#define GPU_SUBMIT_SHADOW 0
#endif
enum gpu_opcode { GPU_OP_NOP=0, GPU_OP_FILL=1, GPU_OP_COPY=2,
    GPU_OP_COLOR_KEY=3, GPU_OP_ALPHA=4, GPU_OP_SPARSE=5, GPU_OP_PRESENT=6,
    GPU_OP_TRANSFORM=7 };
enum gpu_error { GPU_ERROR_NONE=0, GPU_ERROR_INVALID_OPCODE=1,
    GPU_ERROR_ZERO_SIZE=2, GPU_ERROR_MISALIGNED_ADDRESS=3,
    GPU_ERROR_STRIDE_TOO_SMALL=4, GPU_ERROR_ADDRESS_RANGE=5,
    GPU_ERROR_OVERLAPPING_COPY=6, GPU_ERROR_QUEUE_FULL=7,
    GPU_ERROR_SPARSE_FORMAT=8, GPU_ERROR_AXI_RESPONSE=9, GPU_ERROR_TRANSFORM_CONFIG=10 };
enum gpu_transform_flags { GPU_TRANSFORM_HFLIP=1, GPU_TRANSFORM_VFLIP=2,
    GPU_TRANSFORM_COLOR_KEY=16, GPU_TRANSFORM_GRAYSCALE=32, GPU_TRANSFORM_FLAGS_MASK=51 };
/* Field contract, not a packed hardware descriptor. op uses only low 4 bits;
 * flags must be zero for legacy operations; Transform uses gpu_transform_flags.
 * Transform width/height describe OUTPUT pixels, not source dimensions.
 * Transform source sizes alias unused color/tag storage; the driver assigns
 * the hardware submission tag independently of the command's tag member. */
typedef struct {
    uint32_t src_addr, dst_addr, src_stride, dst_stride;
    uint16_t width_pixels, height_pixels;
    union { uint16_t color; uint16_t src_width_pixels; };
    uint16_t color_key, flags;
    union { uint16_t tag; uint16_t src_height_pixels; };
    uint8_t op, alpha;
} gpu_command;
/* Compact GPU front-end record; also a typed view of GPU-only scene scratch. */
typedef struct { uint32_t words[4]; } gpu_instance;
_Static_assert(sizeof(gpu_command)==32, "legacy command extent");
_Static_assert(offsetof(gpu_command,src_addr)==0 && offsetof(gpu_command,dst_addr)==4 &&
               offsetof(gpu_command,src_stride)==8 && offsetof(gpu_command,dst_stride)==12 &&
               offsetof(gpu_command,width_pixels)==16 && offsetof(gpu_command,height_pixels)==18 &&
               offsetof(gpu_command,color)==20 && offsetof(gpu_command,src_width_pixels)==20 &&
               offsetof(gpu_command,color_key)==22 && offsetof(gpu_command,flags)==24 &&
               offsetof(gpu_command,tag)==26 && offsetof(gpu_command,src_height_pixels)==26 &&
               offsetof(gpu_command,op)==28 && offsetof(gpu_command,alpha)==29,
               "legacy command offsets and Transform aliases");
_Static_assert(sizeof(uint32_t)==4 && sizeof(uint16_t)==2 && sizeof(uint8_t)==1,
               "command scalar widths");
_Static_assert((GPU_ALPHA_MASK & (0xffffu << GPU_FLAGS_SHIFT)) == 0,
               "alpha flags fields must not overlap");
_Static_assert((GPU_STATUS_QUEUE_LEVEL_MASK | GPU_STATUS_EMPTY |
                GPU_STATUS_FULL | GPU_STATUS_BUSY) == 0xff, "status fields");
static inline uint32_t gpu_pack_size(uint16_t width, uint16_t height) {
    return (uint32_t)width | ((uint32_t)height << GPU_HEIGHT_SHIFT);
}
static inline uint32_t gpu_pack_color_key(uint16_t color, uint16_t key) {
    return (uint32_t)color | ((uint32_t)key << GPU_COLOR_KEY_SHIFT);
}
static inline uint32_t gpu_pack_alpha_flags(uint8_t alpha, uint16_t flags) {
    return (uint32_t)alpha | ((uint32_t)flags << GPU_FLAGS_SHIFT);
}
static inline uint32_t gpu_pack_qos(uint16_t low, uint16_t high, int adaptive) {
    return (uint32_t)low | ((uint32_t)high << GPU_QOS_HIGH_SHIFT) |
           (adaptive ? GPU_QOS_ADAPTIVE : 0u);
}
typedef struct {
 uint64_t cycles, pixels, read_bytes, write_bytes, stalls;
 uint64_t underflows, render_grants, scanout_grants, cache_bytes;
} gpu_perf_snapshot;
enum gpu_driver_result { GPU_DRIVER_ID=-1, GPU_DRIVER_VERSION=-2,
 GPU_DRIVER_BUSY=-3, GPU_DRIVER_FULL=-4, GPU_DRIVER_TIMEOUT=-5,
 GPU_DRIVER_TAG=-6, GPU_DRIVER_HARDWARE=-7, GPU_DRIVER_ARGUMENT=-8,
 GPU_DRIVER_AGAIN=GPU_DRIVER_FULL, GPU_POLL_PENDING=1 };
#define GPU_COMMAND_QUEUE_DEPTH 16u
/* Exclusive single owner. Completion is inferred from the in-order LAST_DONE
 * register, so callers must not submit through a second producer. */
typedef struct {
 uintptr_t base;
 uint32_t submitted_count;
 uint16_t first_tag, next_tag, last_done, pending_tag;
 uint8_t ready, pending, outstanding, hardware_error, queue_high_watermark;
#if GPU_SUBMIT_SHADOW
 /* Optional GPU-only delta submit. Single owner must use gpu_init after reset
  * or any out-of-driver write to the legacy command shadow registers.
  * Build all translation units with the same GPU_SUBMIT_SHADOW setting. */
 uint8_t shadow_valid;
 uint32_t shadow_words[8];
#endif
} gpu_device;
int gpu_init(gpu_device *d, uintptr_t base);
int gpu_try_submit(gpu_device *d,const gpu_command *command,uint16_t *tag);
/* command must remain immutable until this blocking call returns. */
int gpu_submit(gpu_device *d,const gpu_command *command,uint32_t poll_limit,uint16_t *tag);
int gpu_poll(gpu_device *d,uint16_t tag);
int gpu_fill_async(gpu_device *d,uint32_t dst,uint32_t stride,uint16_t w,uint16_t h,uint16_t color,uint16_t *tag);
int gpu_copy_async(gpu_device *d,uint32_t src,uint32_t dst,uint32_t src_stride,uint32_t dst_stride,uint16_t w,uint16_t h,uint16_t *tag);
int gpu_color_key_async(gpu_device *d,uint32_t src,uint32_t dst,uint32_t src_stride,uint32_t dst_stride,uint16_t w,uint16_t h,uint16_t color_key,uint16_t *tag);
int gpu_alpha_async(gpu_device *d,uint32_t src,uint32_t dst,uint32_t src_stride,uint32_t dst_stride,uint16_t w,uint16_t h,uint8_t alpha,uint16_t *tag);
int gpu_sparse_async(gpu_device *d,uint32_t tokens,uint32_t dst,uint32_t dst_stride,uint16_t w,uint16_t h,uint16_t *tag);
int gpu_present_async(gpu_device *d,uint32_t back_buffer,uint16_t *tag);
/* Requires STATUS.TRANSFORM_PRESENT; GRAYSCALE also needs its own capability.
 * Nearest-neighbor source H/V mirror; source-Key comparison precedes gray.
 * Gray Y8=(R8+2*G8+B8)/4, expanded by bit replication and truncated to RGB565.
 * Source and destination surfaces must not overlap. */
int gpu_transform_blit_async(gpu_device *d,uint32_t src,uint32_t dst,
 uint32_t src_stride,uint32_t dst_stride,uint16_t src_width,uint16_t src_height,
 uint16_t width,uint16_t height,
 uint16_t flags,uint16_t color_key,uint16_t *tag);
int gpu_wait_tag(gpu_device *d,uint16_t tag,uint32_t poll_limit);
int gpu_set_qos(gpu_device *d,uint16_t low,uint16_t high,int adaptive);
int gpu_clear_perf(gpu_device *d);
int gpu_read_perf_snapshot(gpu_device *d,gpu_perf_snapshot *snapshot);
int gpu_texture_cache_load(gpu_device *d,uint32_t base,uint32_t bytes,uint32_t poll_limit);
int gpu_texture_cache_invalidate(gpu_device *d);

#endif
