/* Catch a lost/partial DDR publication, changed descriptor order or clipping,
 * scene-buffer growth, and accidental use of staging for WIN/legacy scenes. */
#define V3_FRAME_LIST 1
#define V3_GPU_STAGED_BUILD 1
#define BULLET_OBJECT_CAPACITY 1024
#include "../src/v3_demo.c"
#include <assert.h>
#include <stdio.h>
#include <string.h>
static bullet_state game;
static bullet_stream actual,reference;
static gpu_instance destination[BULLET_MAX_COMMANDS+1],direct[BULLET_MAX_COMMANDS+1];
static void same_command(const gpu_command *a,const gpu_command *b) {
 assert(a->op==b->op && a->flags==b->flags && a->src_addr==b->src_addr && a->dst_addr==b->dst_addr);
 assert(a->src_stride==b->src_stride && a->dst_stride==b->dst_stride);
 assert(a->width_pixels==b->width_pixels && a->height_pixels==b->height_pixels);
 assert(a->color_key==b->color_key && a->alpha==b->alpha);
}
int main(void) {
 _Static_assert(sizeof(bullet_stream)==BULLET_MAX_COMMANDS*32u+20u,"no extra scene RAM");
 _Static_assert(offsetof(bullet_stream,count)==BULLET_MAX_COMMANDS*32u,"CPU scene layout unchanged");
 assert((void *)actual.instances==(void *)actual.commands);
 const unsigned counts[]={64,512,786,1024};unsigned checked=0;
 for(unsigned c=0;c<4;c++) {
  assert(!game_reset(&game,counts[c],7));
  for(unsigned tick=0;tick<600;tick++) {
   game_input input={.held=V3_KEY_FIRE|(tick%120<60?V3_KEY_LEFT:V3_KEY_RIGHT)};
   assert(!game_update(&game,&input));if(tick%30!=29)continue;
   for(unsigned net=0;net<2;net++)for(unsigned bank=0;bank<2;bank++) {
    uint32_t dst=bank?GPU_FRAMEBUFFER_B:GPU_FRAMEBUFFER_A;int used=0;
    gpu_staged_build=0;
    assert(!v3_build_gpu_scene(&game,dst,net,1,direct,&reference,&used) && used);
    unsigned count=reference.count,visible=reference.visible,alpha=reference.alpha_commands;
    memset(destination,0xa5,sizeof destination);gpu_staged_build=1;
    assert(!v3_build_gpu_scene(&game,dst,net,1,destination,&actual,&used) && used);
    assert(actual.count==count && actual.visible==visible && actual.alpha_commands==alpha);
    assert(!memcmp(destination,direct,count*sizeof *direct));
    for(unsigned w=0;w<4;w++)assert(destination[count].words[w]==0xa5a5a5a5u);
    /* Independent legacy CPU command builder pins geometry, opacity and order. */
    assert(!game_build(&game,dst,net,1,BULLET_MAX_COMMANDS,&reference));
    assert(!bullet_clip_background_for_hud(&reference,72) && reference.count==count);
    gpu_instance_template templates[16];assert(gpu_instances_templates(net,templates)==12);
    for(unsigned i=0;i<count;i++) {
     gpu_command expanded;
     assert(!gpu_instance_expand(templates,destination+i,(uint16_t)(65530u+i),&expanded));
     same_command(&expanded,reference.commands+i);
    }
    ++checked;
   }
  }
 }
 assert(checked==320);
 assert(!game_reset(&game,1024,7));game.objects[1023].shape=255;
 memset(destination,0xa5,sizeof destination);int used=1;gpu_staged_build=1;
 assert(v3_build_gpu_scene(&game,GPU_FRAMEBUFFER_A,1,1,destination,&actual,&used)==GPU_DRIVER_ARGUMENT);
 assert(!used && !actual.count);
 for(unsigned i=0;i<BULLET_MAX_COMMANDS+1;i++)for(unsigned w=0;w<4;w++)assert(destination[i].words[w]==0xa5a5a5a5u);
 assert(!game_reset(&game,64,7));
 assert(v3_build_gpu_scene(&game,GPU_FRAMEBUFFER_A,1,1,0,&actual,&used)==GPU_DRIVER_ARGUMENT && !used && !actual.count);
 assert(!v3_build_gpu_scene(&game,GPU_FRAMEBUFFER_A,1,0,0,&actual,&used) && !used);
 assert(!game_build(&game,GPU_FRAMEBUFFER_A,1,1,BULLET_MAX_COMMANDS,&reference));
 assert(!bullet_clip_background_for_hud(&reference,72));
 for(unsigned i=0;i<actual.count;i++)same_command(actual.commands+i,reference.commands+i);
 game.won=1;memset(game.enemy_hp,0,sizeof game.enemy_hp);
 assert(!v3_build_gpu_scene(&game,GPU_FRAMEBUFFER_B,1,1,destination,&actual,&used) && !used);
 assert(actual.count==33 && actual.commands[0].op==GPU_OP_COPY);
 assert(!game_build(&game,GPU_FRAMEBUFFER_B,1,1,BULLET_MAX_COMMANDS,&reference));
 assert(!bullet_clip_background_for_hud(&reference,72));unsigned fills=0;
 for(unsigned i=0;i<actual.count;i++) {same_command(actual.commands+i,reference.commands+i);fills+=actual.commands[i].op==GPU_OP_FILL;}
 assert(fills);
 puts("PASS GPU staging:320 A/B local/net frames,64/512/786/1024,exact legacy geometry/order,atomic failure,WIN/fallback,no extra RAM");
}
