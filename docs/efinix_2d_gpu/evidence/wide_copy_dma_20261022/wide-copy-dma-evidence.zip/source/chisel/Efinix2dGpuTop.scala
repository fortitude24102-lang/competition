package gpu

import chisel3._
import chisel3.util._

class ApbSlavePort extends Bundle {
  val paddr = Input(UInt(16.W))
  val psel = Input(Bool())
  val penable = Input(Bool())
  val pwrite = Input(Bool())
  val pwdata = Input(UInt(32.W))
  val prdata = Output(UInt(32.W))
  val pready = Output(Bool())
  val pslverror = Output(Bool())
}

class Efinix2dGpuTop(enableCopyStream: Boolean = true, enableInstances: Boolean = false,
  enableFrameLists: Boolean = false, enableKeyPrefetch: Boolean = false,
  enableStripeScratchpad: Boolean = false, enableCopyBurstBuffer: Boolean = false,
  enableScanoutWordPipeline: Boolean = false, enableKeyRowTrim: Boolean = false,
  enableTransformBlit: Boolean = false, enableAlphaPipeline: Boolean = false,
  enableAxiDiagnostics: Boolean = false, enableKeyWritePipeline: Boolean = false,
  enableExtendedListArena: Boolean = false, enableSmallCopyPrefetch: Boolean = false,
  writeCredits: Int = 2, enableAlphaRowPrefetch: Boolean = false,
  enableWideCopyDma: Boolean = false) extends Module {
  require(!enableExtendedListArena || enableFrameLists, "Extended list arena requires frame lists")
  require(!(enableStripeScratchpad && enableWideCopyDma),
    "Wide Copy DMA cannot bypass the narrow-only stripe scratchpad")
  val io = IO(new Bundle {
    val apb = new ApbSlavePort
    val axi = new Axi4MasterPort
    val fabricReset = if(enableWideCopyDma) Some(Input(Bool())) else None
    val legacyDdr = if(enableWideCopyDma) Some(Flipped(new Axi128MasterPort)) else None
    val wideDdr = if(enableWideCopyDma) Some(new Axi128MasterPort) else None
    val vblank = Input(Bool())
    val scanoutLevel = Input(UInt(12.W))
    val underflow_pulse_gpu = Input(Bool())
    val displayReady = Input(Bool())
    val displayPixel = Output(UInt(16.W))
    val displayValid = Output(Bool())
    val displayLineLast = Output(Bool())
    val displayFrameLast = Output(Bool())
    val assetMeta = Flipped(Decoupled(new AssetPacketMeta))
    val assetPayload = Flipped(Decoupled(new AssetPayloadByte))
    val assetStreamError = Input(Bool())
    val assetSession = Output(UInt(32.W))
    val assetActive = Output(Bool())
    val assetDropPacket = Output(Bool())
    val assetAbort = Output(Bool())
    val irq = Output(Bool())
  })

  private val hasFrontend = enableInstances || enableFrameLists
  private val regs = Module(new GpuApbRegs(hasFrontend,enableFrameLists,enableStripeScratchpad,enableTransformBlit,enableAxiDiagnostics,enableExtendedListArena))
  private val diagnostics = if(enableAxiDiagnostics) Some(Module(new AxiDiagnosticRegs)) else None
  private val instances = if (hasFrontend) Some(Module(new InstanceStream(enableFrameLists))) else None
  private val batch = if(enableFrameLists) Some(Module(new FrameListBatch(enableExtendedListArena))) else None
  private val assetRegs = Module(new AssetDmaRegs)
  private val assetWriter = Module(new AssetDmaWriter)
  private val render = Module(new RenderEngine(enableCopyStream,enableFrameLists,enableKeyPrefetch,enableCopyBurstBuffer,
    enableKeyRowTrim,enableTransformBlit,enableAlphaPipeline,enableKeyWritePipeline,enableSmallCopyPrefetch,writeCredits,enableAlphaRowPrefetch,enableWideCopyDma))
  private val scanout = Module(new ScanoutDma(enableWordPipeline=enableScanoutWordPipeline))
  private val ddr = Module(new DdrQosArbiter(enableDiagnostics=enableAxiDiagnostics,
    enableWritePipeline=enableKeyWritePipeline,writeCredits=writeCredits))
  private val renderMemory = if(enableStripeScratchpad) {
    val scratch = Module(new StripeScratchpad)
    scratch.io.in <> render.io.axi
    scratch.io.ddr
  } else render.io.axi
  private val lastDoneTag = RegInit(0.U(16.W))
  private val lastError = RegInit(GpuError.None.U(8.W))
  private val irq = RegInit(false.B)
  private val scanoutStarted = RegInit(false.B)
  private val scanoutEverEnabled = RegInit(false.B)

  private val assetSelect = io.apb.paddr(15, 8) === 1.U
  private val instanceSelect = if (hasFrontend) io.apb.paddr(15, 8) === 4.U else false.B
  private val batchSelect = if(enableFrameLists) io.apb.paddr(15,8)===5.U else false.B
  private val diagnosticSelect = if(enableAxiDiagnostics) io.apb.paddr(15,8)===6.U else false.B
  private val instanceActive = instances.map(_.io.active).getOrElse(false.B) || batch.map(_.io.active).getOrElse(false.B)
  // Candidate-only response stage: break the decoded read mux -> Sapphire
  // path without changing the default legacy APB timing or register ABI.
  private val responseValid = if (hasFrontend) RegInit(false.B) else false.B
  private val localSelect = io.apb.psel && !responseValid
  private val responseData = WireDefault(Mux(assetSelect, assetRegs.io.prdata, regs.io.prdata))
  private val responseReady = WireDefault(Mux(assetSelect, assetRegs.io.pready, regs.io.pready))
  private val responseError = WireDefault(Mux(assetSelect, assetRegs.io.pslverror, regs.io.pslverror))
  regs.io.paddr := io.apb.paddr
  regs.io.psel := localSelect && !assetSelect && !instanceSelect && !batchSelect && !diagnosticSelect
  regs.io.penable := io.apb.penable
  regs.io.pwrite := io.apb.pwrite
  regs.io.pwdata := io.apb.pwdata
  assetRegs.io.paddr := io.apb.paddr
  assetRegs.io.psel := localSelect && assetSelect
  assetRegs.io.penable := io.apb.penable
  assetRegs.io.pwrite := io.apb.pwrite
  assetRegs.io.pwdata := io.apb.pwdata
  diagnostics.foreach { d =>
    d.io.apb.paddr := io.apb.paddr; d.io.apb.psel := localSelect && diagnosticSelect
    d.io.apb.penable := io.apb.penable; d.io.apb.pwrite := io.apb.pwrite; d.io.apb.pwdata := io.apb.pwdata
    d.io.events := ddr.io.diagnostics.get
    when(diagnosticSelect) {
      responseData := d.io.apb.prdata; responseReady := d.io.apb.pready; responseError := d.io.apb.pslverror
    }
  }
  instances.foreach { frontend =>
    frontend.io.apb.paddr := io.apb.paddr
    frontend.io.apb.psel := localSelect && instanceSelect
    frontend.io.apb.penable := io.apb.penable
    frontend.io.apb.pwrite := io.apb.pwrite
    frontend.io.apb.pwdata := io.apb.pwdata
    frontend.io.idle := !render.io.busy && !render.io.textureCacheBusy
    frontend.io.hardwareError := lastError
    when(instanceSelect) {
      responseData := frontend.io.apb.prdata
      responseReady := frontend.io.apb.pready
      responseError := frontend.io.apb.pslverror
    }
  }
  batch.foreach { b =>
    val frontend = instances.get
    val list = frontend.io.list.get
    b.io.apb.paddr := io.apb.paddr;b.io.apb.psel := localSelect && batchSelect
    b.io.apb.penable := io.apb.penable;b.io.apb.pwrite := io.apb.pwrite;b.io.apb.pwdata := io.apb.pwdata
    b.io.idle := !render.io.busy && !render.io.textureCacheBusy
    b.io.frontendActive := frontend.io.active;b.io.frontendEmpty := list.empty
    b.io.frontendError := list.error;b.io.hardwareError := lastError
    b.io.issued := frontend.io.command.fire
    render.io.frontend.get.busy := b.io.active
    render.io.frontend.get.readBeat := b.io.axiR.fire
    render.io.frontend.get.stalled := b.io.active && (
      (b.io.axiAr.valid && !b.io.axiAr.ready) || (b.io.axiR.ready && !b.io.axiR.valid) ||
      (b.io.descriptor.valid && !b.io.descriptor.ready))
    list.begin := b.io.begin;list.end := b.io.end;list.owned := b.io.active
    list.descriptor <> b.io.descriptor
    when(batchSelect) { responseData := b.io.apb.prdata;responseReady := b.io.apb.pready;responseError := b.io.apb.pslverror }
  }
  if (hasFrontend) {
    val data = Reg(UInt(32.W))
    val error = RegInit(false.B)
    when(localSelect && io.apb.penable && responseReady) {
      data := responseData
      error := responseError
      responseValid := true.B
    }
    when(!io.apb.psel || !io.apb.penable || responseValid) {
      responseValid := false.B
    }
    io.apb.prdata := data
    io.apb.pready := responseValid && io.apb.psel && io.apb.penable
    io.apb.pslverror := io.apb.pready && error
  } else {
    io.apb.prdata := responseData
    io.apb.pready := responseReady
    io.apb.pslverror := responseError
  }

  assetRegs.io.metaIn <> io.assetMeta
  assetWriter.io.meta <> assetRegs.io.metaOut
  assetWriter.io.payload <> io.assetPayload
  assetWriter.io.descriptor := assetRegs.io.descriptor
  assetWriter.io.abort := assetRegs.io.abort
  assetWriter.io.streamError := io.assetStreamError
  assetRegs.io.packetCommitted := assetWriter.io.packetCommitted
  assetRegs.io.packetBytes := assetWriter.io.packetBytes
  assetRegs.io.packetLast := assetWriter.io.packetLast
  assetRegs.io.packetFailed := assetWriter.io.packetFailed
  assetRegs.io.packetError := assetWriter.io.packetError
  assetRegs.io.abortDone := assetWriter.io.abortDone
  io.assetSession := Mux(assetRegs.io.active, assetRegs.io.descriptor.session, 0.U)
  io.assetActive := assetRegs.io.active
  io.assetDropPacket := assetRegs.io.dropPacket
  io.assetAbort := assetRegs.io.abort || assetWriter.io.packetFailed

  render.io.command.valid := regs.io.command.valid && !instanceActive
  render.io.command.bits := regs.io.command.bits
  regs.io.command.ready := render.io.command.ready && !instanceActive
  instances.foreach { frontend =>
    frontend.io.command.ready := render.io.command.ready && instanceActive
    when(instanceActive) {
      render.io.command.valid := frontend.io.command.valid
      render.io.command.bits := frontend.io.command.bits
    }
  }
  render.io.vblank := io.vblank
  regs.io.queueLevel := render.io.queueLevel
  regs.io.queueHighWater := render.io.queueHighWater
  regs.io.queueFull := render.io.queueFull || instanceActive
  regs.io.queueEmpty := render.io.queueEmpty && !instanceActive
  regs.io.engineBusy := render.io.busy || instanceActive
  regs.io.irqPending := irq
  regs.io.lastDoneTag := lastDoneTag
  regs.io.lastError := lastError
  regs.io.frontBuffer := render.io.frontBase
  regs.io.backBuffer := render.io.backBase
  regs.io.perfCycles := render.io.perfCycles
  regs.io.perfPixels := render.io.perfPixels
  regs.io.perfReadBytes := render.io.perfReadBytes
  regs.io.perfWriteBytes := render.io.perfWriteBytes
  regs.io.perfStalls := render.io.perfStalls
  regs.io.perfUnderflows := render.io.perfUnderflows
  regs.io.perfRenderGrants := render.io.perfRenderGrants
  regs.io.perfScanoutGrants := render.io.perfScanoutGrants
  regs.io.perfCacheBytes := render.io.perfCacheBytes
  regs.io.textureCacheValid := render.io.textureCacheValid
  regs.io.textureCacheBusy := render.io.textureCacheBusy
  regs.io.textureCacheError := render.io.textureCacheError
  render.io.textureCacheLoad := regs.io.textureCacheLoad
  render.io.textureCacheInvalidate := regs.io.textureCacheInvalidate
  render.io.perfClear := regs.io.perfClear
  render.io.underflowPulse := io.underflow_pulse_gpu
  render.io.renderGrant := ddr.io.renderGrant
  render.io.scanoutGrant := ddr.io.scanoutGrant

  render.io.completion.ready := true.B
  when(regs.io.irqClear) { irq := false.B }
  when(render.io.completion.fire) {
    lastDoneTag := render.io.completion.bits.tag
    // Preserve the first failure across later successful completions. This
    // lets software validate a batch even if LAST_DONE advances by >1 tag.
    when(lastError === GpuError.None.U && render.io.completion.bits.error =/= GpuError.None.U) {
      lastError := render.io.completion.bits.error
    }
    irq := true.B
  }

  if(enableFrameLists) {
    val b = batch.get
    ddr.io.render.aw <> renderMemory.aw;ddr.io.render.w <> renderMemory.w
    renderMemory.b <> ddr.io.render.b
    ddr.io.render.ar.valid := Mux(b.io.fetching,b.io.axiAr.valid,renderMemory.ar.valid)
    ddr.io.render.ar.bits := Mux(b.io.fetching,b.io.axiAr.bits,renderMemory.ar.bits)
    b.io.axiAr.ready := ddr.io.render.ar.ready && b.io.fetching
    renderMemory.ar.ready := ddr.io.render.ar.ready && !b.io.fetching
    b.io.axiR.valid := ddr.io.render.r.valid && b.io.fetching;b.io.axiR.bits := ddr.io.render.r.bits
    renderMemory.r.valid := ddr.io.render.r.valid && !b.io.fetching;renderMemory.r.bits := ddr.io.render.r.bits
    ddr.io.render.r.ready := Mux(b.io.fetching,b.io.axiR.ready,renderMemory.r.ready)
  } else { ddr.io.render <> renderMemory }
  ddr.io.scanout <> scanout.io.axi
  ddr.io.asset <> assetWriter.io.axi
  ddr.io.scanoutLevel := io.scanoutLevel
  ddr.io.lowWatermark := regs.io.qosLowWatermark
  ddr.io.highWatermark := regs.io.qosHighWatermark
  // An empty FIFO before the first frame is not a scanout emergency.
  ddr.io.adaptiveEnable := regs.io.qosAdaptiveEnable && scanoutEverEnabled
  io.axi <> ddr.io.axi
  if(enableWideCopyDma) {
    render.io.fabricReset.get := io.fabricReset.get
    val fabric=withReset(io.fabricReset.get) { Module(new WideDdrMux) }
    fabric.io.legacy <> io.legacyDdr.get
    fabric.io.native <> render.io.wideAxi.get
    io.wideDdr.get <> fabric.io.ddr
    fabric.io.emergency := ddr.io.scanoutPriority || reset.asBool
  }

  when(render.io.swapPending) { scanoutStarted := true.B }
  scanout.io.enable := scanoutStarted && !render.io.swapPending
  when(scanout.io.enable) { scanoutEverEnabled := true.B }
  scanout.io.frontBase := render.io.frontBase
  scanout.io.fifoLevel := io.scanoutLevel
  // Continue refilling through hysteresis: one 960-pixel row alone cannot
  // raise a 256-pixel low level to the default 1536-pixel high watermark.
  // The pixel ready/valid handshake still prevents physical FIFO overflow.
  scanout.io.refill := ddr.io.scanoutPriority
  scanout.io.pixel.ready := io.displayReady

  io.displayPixel := scanout.io.pixel.bits.pixel
  io.displayValid := scanout.io.pixel.valid
  io.displayLineLast := scanout.io.pixel.bits.lineLast
  io.displayFrameLast := scanout.io.pixel.bits.frameLast
  io.irq := irq
}
