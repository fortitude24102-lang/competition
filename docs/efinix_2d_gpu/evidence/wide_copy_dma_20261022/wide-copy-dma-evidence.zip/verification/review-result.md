# Single independent whole-source review

Reviewer: wide_copy_final_review_20261022, fresh context, read-only, most-capable available model, no reviewer subagents or test processes. Range0c87be0..a89189c plus then-uncommitted integration and named new files. Completed2026-10-22 before candidate board use.

Strengths: fixed two-bank retirement, committed banks survive errors/abort, same-ID source attribution without ID truncation, independent mux owners and stable address promises, common-reset fabric and local-abort wiring, correct wide/narrow byte arithmetic. No confirmed protocol/reset defect found in selected stripe-disabled RTL.

Critical: none.

Important1: optional StripeScratchpad's0x02e00000 private window is narrow-only; enabling it together with wideCopy silently splits memory views. Fix: forbid combination at construction, not build a new router. RED compiled old generator accepted both; negative Scala test failed expecting rejection. GREEN constructor require + negative test passes. Selected stripe-disabled68module code unaffected (verified normalized RTL equality).

Important2: original R faults beat3/63 precede AW and all fault/abort runs skipped output-byte checking. Fix: every accepted W byte compared with source even on errors/abort; add Rerror beat70 when another bank owesW and badB while second R is explicitly stalled; assert preconditions, oneAW/no replay, next request clean. GREEN directed cases and all existing strengthened cases pass; source production DMA needed no fix.

Important3: original scoreboard checked address increment before samecycle retirement and never drove W beforeAW. RED extended ownership window reproduces false17>16 on a legal full-credit replacement. GREEN scoreboard combines both handshakes and asserts both full16 replacements happened; added W-beforeAW/competing-owner/finalB/independent-read directed test passes. Production mux needed no fix.

Minor: none.

Declined to judge: board throughput/underflow/qualification; running full-suite/CDC; permanently missing/extra beats outside finite-response contract; +1751XLR vs1500 soft target. Executor separately checked physical/CDC, full40/164 and directed8/8, completed board A/B/A and rejected candidate on net regression; missing/extra responses keep common-reset recovery; net target miss documented without claiming it passed.

Final disposition: all three Important items fixed or evidence completed in one fix pass; no second review. No recommendation to merge or qualify performance: actual normal1024 regressed, candidate stays defaultoff, old primary restored.
