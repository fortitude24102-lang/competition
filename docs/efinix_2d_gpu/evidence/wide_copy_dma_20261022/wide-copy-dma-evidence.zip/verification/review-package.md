# Whole-source review package

Worktree D:/ZYNQ/smallproject/.worktrees/pango-riscv-cpu; do not inspect/change the dirty parent checkout.
Base0c87be0; HEAD a89189c contains Tasks1/2 plus docs; Task3 is UNCOMMITTED and must be reviewed via git diff plus explicit new files:
- chisel/src/test/scala/gpu/WideCopyRenderSpec.scala
- scripts/test-wide-copy-build.ps1

Read plan docs/superpowers/plans/2026-10-22-wide-copy-dma.md and spec docs/superpowers/specs/2026-10-22-wide-copy-dma-design.md completely. Private progress.md contains all Ruling lines and actual partial evidence. Only relevant code sources; no giant generated/outflow/secret/bootstrap scan.

Review Focus (verbatim):
- GPU reset while an address is stalled or while a bank owes W/B: promise remains stable and new GPU cannot see stale completion (Tasks1/3).
- Emergency arrives while waiting to switch to native: legacy display must not wait on prohibited native issue (Task2).
- Simultaneous final response and new address, full16 credits, W before AW, different IDs/direction owners: never route/retire wrong owner (Task2).
- Bad read after AW or bad B with future R: accepted writes drain using intact data; no partial replay (Task1).
- Generated wide ports and board wiring disagree, or high address truncation: preparation fails or validated command rejects, never a downloadable half-enabled build (Task3).

Focused DMA3, mux2, Render2+perf4 have passed. Two new reset tests and all other GPU regressions are running; do not start another sbt or compile while they run. Full-board r1 resource/timing passes, routed CDC pending, no JTAG candidate loaded, no performance claims. Only review production correctness and tests now; integration is not declared complete and board gates remain.
