
generated\verification\v3\logic-invariant-20261026\probe-fast-r1\gpu_demo.elf:     file format elf32-littleriscv


Disassembly of section .init:

Disassembly of section .text:

000055d0 <step>:
    55d0:	f9010113          	addi	sp,sp,-112
    55d4:	05512a23          	sw	s5,84(sp)
    55d8:	06112623          	sw	ra,108(sp)
    55dc:	06812423          	sw	s0,104(sp)
    55e0:	06912223          	sw	s1,100(sp)
    55e4:	07212023          	sw	s2,96(sp)
    55e8:	05312e23          	sw	s3,92(sp)
    55ec:	05412c23          	sw	s4,88(sp)
    55f0:	05612823          	sw	s6,80(sp)
    55f4:	05712623          	sw	s7,76(sp)
    55f8:	05812423          	sw	s8,72(sp)
    55fc:	05912223          	sw	s9,68(sp)
    5600:	05a12023          	sw	s10,64(sp)
    5604:	03b12e23          	sw	s11,60(sp)
    5608:	00e12423          	sw	a4,8(sp)
    560c:	00058a93          	mv	s5,a1
    5610:	76050063          	beqz	a0,5d70 <step+0x7a0>
    5614:	00005437          	lui	s0,0x5
    5618:	00850433          	add	s0,a0,s0
    561c:	00842a03          	lw	s4,8(s0) # 5008 <bullet_enemy_position+0x50>
    5620:	00068993          	mv	s3,a3
    5624:	3ff00713          	li	a4,1023
    5628:	fffa0693          	addi	a3,s4,-1
    562c:	00050493          	mv	s1,a0
    5630:	ff800793          	li	a5,-8
    5634:	18d76e63          	bltu	a4,a3,57d0 <step+0x200>
    5638:	02444b83          	lbu	s7,36(s0)
    563c:	00300713          	li	a4,3
    5640:	19776863          	bltu	a4,s7,57d0 <step+0x200>
    5644:	00060913          	mv	s2,a2
    5648:	8f5ff0ef          	jal	4f3c <bullet_campaign_valid>
    564c:	ff800793          	li	a5,-8
    5650:	18050063          	beqz	a0,57d0 <step+0x200>
    5654:	02045703          	lhu	a4,32(s0)
    5658:	03c00693          	li	a3,60
    565c:	16e6ea63          	bltu	a3,a4,57d0 <step+0x200>
    5660:	00812583          	lw	a1,8(sp)
    5664:	000b9e63          	bnez	s7,5680 <step+0xb0>
    5668:	02245683          	lhu	a3,34(s0)
    566c:	07700613          	li	a2,119
    5670:	fff68693          	addi	a3,a3,-1
    5674:	01069693          	slli	a3,a3,0x10
    5678:	0106d693          	srli	a3,a3,0x10
    567c:	14d66a63          	bltu	a2,a3,57d0 <step+0x200>
    5680:	020a8063          	beqz	s5,56a0 <step+0xd0>
    5684:	ff890693          	addi	a3,s2,-8
    5688:	3b000613          	li	a2,944
    568c:	ff800793          	li	a5,-8
    5690:	14d66063          	bltu	a2,a3,57d0 <step+0x200>
    5694:	fb098693          	addi	a3,s3,-80
    5698:	1c400613          	li	a2,452
    569c:	12d66a63          	bltu	a2,a3,57d0 <step+0x200>
    56a0:	01400693          	li	a3,20
    56a4:	02da06b3          	mul	a3,s4,a3
    56a8:	00005637          	lui	a2,0x5
    56ac:	00048413          	mv	s0,s1
    56b0:	00048793          	mv	a5,s1
    56b4:	001ab893          	seqz	a7,s5
    56b8:	00500813          	li	a6,5
    56bc:	00c48633          	add	a2,s1,a2
    56c0:	009686b3          	add	a3,a3,s1
    56c4:	00e7c303          	lbu	t1,14(a5)
    56c8:	0018b513          	seqz	a0,a7
    56cc:	00250513          	addi	a0,a0,2
    56d0:	6a654063          	blt	a0,t1,5d70 <step+0x7a0>
    56d4:	00f7c503          	lbu	a0,15(a5)
    56d8:	68a86c63          	bltu	a6,a0,5d70 <step+0x7a0>
    56dc:	02864503          	lbu	a0,40(a2) # 5028 <bullet_enemy_position+0x70>
    56e0:	00050663          	beqz	a0,56ec <step+0x11c>
    56e4:	0117c303          	lbu	t1,17(a5)
    56e8:	68686463          	bltu	a6,t1,5d70 <step+0x7a0>
    56ec:	01478793          	addi	a5,a5,20
    56f0:	fcd79ae3          	bne	a5,a3,56c4 <step+0xf4>
    56f4:	000057b7          	lui	a5,0x5
    56f8:	00f487b3          	add	a5,s1,a5
    56fc:	0047ab03          	lw	s6,4(a5) # 5004 <bullet_enemy_position+0x4c>
    5700:	001b0b13          	addi	s6,s6,1
    5704:	0167a223          	sw	s6,4(a5)
    5708:	000a8663          	beqz	s5,5714 <step+0x144>
    570c:	0297c783          	lbu	a5,41(a5)
    5710:	08079e63          	bnez	a5,57ac <step+0x1dc>
    5714:	100b9663          	bnez	s7,5820 <step+0x250>
    5718:	000057b7          	lui	a5,0x5
    571c:	00f48733          	add	a4,s1,a5
    5720:	02275683          	lhu	a3,34(a4)
    5724:	fff68693          	addi	a3,a3,-1
    5728:	01069693          	slli	a3,a3,0x10
    572c:	0106d693          	srli	a3,a3,0x10
    5730:	02d71123          	sh	a3,34(a4)
    5734:	06069c63          	bnez	a3,57ac <step+0x1dc>
    5738:	00072603          	lw	a2,0(a4)
    573c:	0c0a8a63          	beqz	s5,5810 <step+0x240>
    5740:	0c050863          	beqz	a0,5810 <step+0x240>
    5744:	06058863          	beqz	a1,57b4 <step+0x1e4>
    5748:	06b48663          	beq	s1,a1,57b4 <step+0x1e4>
    574c:	00f587b3          	add	a5,a1,a5
    5750:	0287c703          	lbu	a4,40(a5) # 5028 <bullet_enemy_position+0x70>
    5754:	06070063          	beqz	a4,57b4 <step+0x1e4>
    5758:	0087a703          	lw	a4,8(a5)
    575c:	04ea1c63          	bne	s4,a4,57b4 <step+0x1e4>
    5760:	0007a703          	lw	a4,0(a5)
    5764:	04c71863          	bne	a4,a2,57b4 <step+0x1e4>
    5768:	0047a783          	lw	a5,4(a5)
    576c:	04079463          	bnez	a5,57b4 <step+0x1e4>
    5770:	00005437          	lui	s0,0x5
    5774:	008587b3          	add	a5,a1,s0
    5778:	0147a703          	lw	a4,20(a5)
    577c:	02071c63          	bnez	a4,57b4 <step+0x1e4>
    5780:	0247c683          	lbu	a3,36(a5)
    5784:	00300713          	li	a4,3
    5788:	02e69663          	bne	a3,a4,57b4 <step+0x1e4>
    578c:	0297c783          	lbu	a5,41(a5)
    5790:	02079263          	bnez	a5,57b4 <step+0x1e4>
    5794:	00005637          	lui	a2,0x5
    5798:	02c60613          	addi	a2,a2,44 # 502c <bullet_enemy_position+0x74>
    579c:	00048513          	mv	a0,s1
    57a0:	00848433          	add	s0,s1,s0
    57a4:	b61fb0ef          	jal	1304 <memcpy>
    57a8:	01642223          	sw	s6,4(s0) # 5004 <bullet_enemy_position+0x4c>
    57ac:	00000793          	li	a5,0
    57b0:	0200006f          	j	57d0 <step+0x200>
    57b4:	000a0593          	mv	a1,s4
    57b8:	00048513          	mv	a0,s1
    57bc:	d59ff0ef          	jal	5514 <bullet_reset_player>
    57c0:	00005737          	lui	a4,0x5
    57c4:	00e48733          	add	a4,s1,a4
    57c8:	00050793          	mv	a5,a0
    57cc:	01672223          	sw	s6,4(a4) # 5004 <bullet_enemy_position+0x4c>
    57d0:	06c12083          	lw	ra,108(sp)
    57d4:	06812403          	lw	s0,104(sp)
    57d8:	06412483          	lw	s1,100(sp)
    57dc:	06012903          	lw	s2,96(sp)
    57e0:	05c12983          	lw	s3,92(sp)
    57e4:	05812a03          	lw	s4,88(sp)
    57e8:	05412a83          	lw	s5,84(sp)
    57ec:	05012b03          	lw	s6,80(sp)
    57f0:	04c12b83          	lw	s7,76(sp)
    57f4:	04812c03          	lw	s8,72(sp)
    57f8:	04412c83          	lw	s9,68(sp)
    57fc:	04012d03          	lw	s10,64(sp)
    5800:	03c12d83          	lw	s11,60(sp)
    5804:	00078513          	mv	a0,a5
    5808:	07010113          	addi	sp,sp,112
    580c:	00008067          	ret
    5810:	000a0593          	mv	a1,s4
    5814:	00048513          	mv	a0,s1
    5818:	c49ff0ef          	jal	5460 <bullet_reset>
    581c:	fa5ff06f          	j	57c0 <step+0x1f0>
    5820:	000056b7          	lui	a3,0x5
    5824:	00d486b3          	add	a3,s1,a3
    5828:	0146a783          	lw	a5,20(a3) # 5014 <bullet_enemy_position+0x5c>
    582c:	00178793          	addi	a5,a5,1
    5830:	00f6aa23          	sw	a5,20(a3)
    5834:	020a9863          	bnez	s5,5864 <step+0x294>
    5838:	0f000913          	li	s2,240
    583c:	0327f933          	remu	s2,a5,s2
    5840:	03b00693          	li	a3,59
    5844:	1526f063          	bgeu	a3,s2,5984 <step+0x3b4>
    5848:	0b300693          	li	a3,179
    584c:	1326e463          	bltu	a3,s2,5974 <step+0x3a4>
    5850:	07800693          	li	a3,120
    5854:	412686b3          	sub	a3,a3,s2
    5858:	00300613          	li	a2,3
    585c:	02c686b3          	mul	a3,a3,a2
    5860:	1e068913          	addi	s2,a3,480
    5864:	000056b7          	lui	a3,0x5
    5868:	00d486b3          	add	a3,s1,a3
    586c:	0126a623          	sw	s2,12(a3) # 500c <bullet_enemy_position+0x54>
    5870:	000a9463          	bnez	s5,5878 <step+0x2a8>
    5874:	1e000993          	li	s3,480
    5878:	000056b7          	lui	a3,0x5
    587c:	00d486b3          	add	a3,s1,a3
    5880:	0136a823          	sw	s3,16(a3) # 5010 <bullet_enemy_position+0x58>
    5884:	00e03cb3          	snez	s9,a4
    5888:	00070663          	beqz	a4,5894 <step+0x2c4>
    588c:	fff70713          	addi	a4,a4,-1
    5890:	02e69023          	sh	a4,32(a3)
    5894:	01e00713          	li	a4,30
    5898:	02e7f7b3          	remu	a5,a5,a4
    589c:	02079463          	bnez	a5,58c4 <step+0x2f4>
    58a0:	000057b7          	lui	a5,0x5
    58a4:	00f487b3          	add	a5,s1,a5
    58a8:	0187a783          	lw	a5,24(a5) # 5018 <bullet_enemy_position+0x60>
    58ac:	fff00713          	li	a4,-1
    58b0:	00e78463          	beq	a5,a4,58b8 <step+0x2e8>
    58b4:	00178793          	addi	a5,a5,1
    58b8:	00005737          	lui	a4,0x5
    58bc:	00e48733          	add	a4,s1,a4
    58c0:	00f72c23          	sw	a5,24(a4) # 5018 <bullet_enemy_position+0x60>
    58c4:	fed90793          	addi	a5,s2,-19
    58c8:	00005ab7          	lui	s5,0x5
    58cc:	0003cbb7          	lui	s7,0x3c
    58d0:	0001ec37          	lui	s8,0x1e
    58d4:	00f12423          	sw	a5,8(sp)
    58d8:	00010b37          	lui	s6,0x10
    58dc:	00c90793          	addi	a5,s2,12
    58e0:	0f000d93          	li	s11,240
    58e4:	00000d13          	li	s10,0
    58e8:	01548ab3          	add	s5,s1,s5
    58ec:	7feb8b93          	addi	s7,s7,2046 # 3c7fe <__freertos_irq_stack_top+0x1ecce>
    58f0:	bffc0c13          	addi	s8,s8,-1025 # 1dbff <__freertos_irq_stack_top+0xcf>
    58f4:	00f12623          	sw	a5,12(sp)
    58f8:	fffb0b13          	addi	s6,s6,-1 # ffff <__global_pointer$+0x11ef>
    58fc:	00e44683          	lbu	a3,14(s0)
    5900:	00300793          	li	a5,3
    5904:	1cf69863          	bne	a3,a5,5ad4 <step+0x504>
    5908:	00c45683          	lhu	a3,12(s0)
    590c:	05668663          	beq	a3,s6,5958 <step+0x388>
    5910:	00042783          	lw	a5,0(s0)
    5914:	00841303          	lh	t1,8(s0)
    5918:	00442603          	lw	a2,4(s0)
    591c:	00f30333          	add	t1,t1,a5
    5920:	00a41783          	lh	a5,10(s0)
    5924:	00642023          	sw	t1,0(s0)
    5928:	40835313          	srai	t1,t1,0x8
    592c:	00c787b3          	add	a5,a5,a2
    5930:	00f42223          	sw	a5,4(s0)
    5934:	00430313          	addi	t1,t1,4
    5938:	3bf00613          	li	a2,959
    593c:	00666a63          	bltu	a2,t1,5950 <step+0x380>
    5940:	4087d793          	srai	a5,a5,0x8
    5944:	fbc78593          	addi	a1,a5,-68
    5948:	1d300613          	li	a2,467
    594c:	04b67463          	bgeu	a2,a1,5994 <step+0x3c4>
    5950:	fff00793          	li	a5,-1
    5954:	00f41623          	sh	a5,12(s0)
    5958:	16700793          	li	a5,359
    595c:	001d0d13          	addi	s10,s10,1
    5960:	40fd8463          	beq	s11,a5,5d68 <step+0x798>
    5964:	001d8d93          	addi	s11,s11,1
    5968:	01440413          	addi	s0,s0,20
    596c:	f9aa18e3          	bne	s4,s10,58fc <step+0x32c>
    5970:	e3dff06f          	j	57ac <step+0x1dc>
    5974:	00300693          	li	a3,3
    5978:	02d90933          	mul	s2,s2,a3
    597c:	f1090913          	addi	s2,s2,-240
    5980:	ee5ff06f          	j	5864 <step+0x294>
    5984:	00300693          	li	a3,3
    5988:	02d90933          	mul	s2,s2,a3
    598c:	1e090913          	addi	s2,s2,480
    5990:	ed5ff06f          	j	5864 <step+0x294>
    5994:	00168693          	addi	a3,a3,1
    5998:	00d41623          	sh	a3,12(s0)
    599c:	00478893          	addi	a7,a5,4
    59a0:	00000593          	li	a1,0
    59a4:	00300e93          	li	t4,3
    59a8:	028ace03          	lbu	t3,40(s5) # 5028 <bullet_enemy_position+0x70>
    59ac:	020e0c63          	beqz	t3,59e4 <step+0x414>
    59b0:	000057b7          	lui	a5,0x5
    59b4:	02578793          	addi	a5,a5,37 # 5025 <bullet_enemy_position+0x6d>
    59b8:	00f587b3          	add	a5,a1,a5
    59bc:	00f487b3          	add	a5,s1,a5
    59c0:	0007c783          	lbu	a5,0(a5)
    59c4:	02079063          	bnez	a5,59e4 <step+0x414>
    59c8:	00158593          	addi	a1,a1,1
    59cc:	fdd59ee3          	bne	a1,t4,59a8 <step+0x3d8>
    59d0:	000057b7          	lui	a5,0x5
    59d4:	00f487b3          	add	a5,s1,a5
    59d8:	0297c783          	lbu	a5,41(a5) # 5029 <bullet_enemy_position+0x71>
    59dc:	dc0798e3          	bnez	a5,57ac <step+0x1dc>
    59e0:	f79ff06f          	j	5958 <step+0x388>
    59e4:	02c10693          	addi	a3,sp,44
    59e8:	02810613          	addi	a2,sp,40
    59ec:	00048513          	mv	a0,s1
    59f0:	01112e23          	sw	a7,28(sp)
    59f4:	00612c23          	sw	t1,24(sp)
    59f8:	00b12823          	sw	a1,16(sp)
    59fc:	01c12a23          	sw	t3,20(sp)
    5a00:	db8ff0ef          	jal	4fb8 <bullet_enemy_position>
    5a04:	02812683          	lw	a3,40(sp)
    5a08:	01812303          	lw	t1,24(sp)
    5a0c:	01400613          	li	a2,20
    5a10:	02c12783          	lw	a5,44(sp)
    5a14:	40d306b3          	sub	a3,t1,a3
    5a18:	00a68693          	addi	a3,a3,10
    5a1c:	01012583          	lw	a1,16(sp)
    5a20:	01c12883          	lw	a7,28(sp)
    5a24:	00300e93          	li	t4,3
    5a28:	fad660e3          	bltu	a2,a3,59c8 <step+0x3f8>
    5a2c:	40f887b3          	sub	a5,a7,a5
    5a30:	00a78793          	addi	a5,a5,10
    5a34:	f8f66ae3          	bltu	a2,a5,59c8 <step+0x3f8>
    5a38:	fff00793          	li	a5,-1
    5a3c:	00f41623          	sh	a5,12(s0)
    5a40:	000057b7          	lui	a5,0x5
    5a44:	00f487b3          	add	a5,s1,a5
    5a48:	0187a783          	lw	a5,24(a5) # 5018 <bullet_enemy_position+0x60>
    5a4c:	fe600693          	li	a3,-26
    5a50:	01412e03          	lw	t3,20(sp)
    5a54:	00f6f463          	bgeu	a3,a5,5a5c <step+0x48c>
    5a58:	fe600793          	li	a5,-26
    5a5c:	000056b7          	lui	a3,0x5
    5a60:	01978793          	addi	a5,a5,25
    5a64:	00d48533          	add	a0,s1,a3
    5a68:	00f52c23          	sw	a5,24(a0)
    5a6c:	f60e02e3          	beqz	t3,59d0 <step+0x400>
    5a70:	00b485b3          	add	a1,s1,a1
    5a74:	00b68633          	add	a2,a3,a1
    5a78:	02564683          	lbu	a3,37(a2)
    5a7c:	fff68693          	addi	a3,a3,-1 # 4fff <bullet_enemy_position+0x47>
    5a80:	0ff6f693          	zext.b	a3,a3
    5a84:	02d602a3          	sb	a3,37(a2)
    5a88:	f40694e3          	bnez	a3,59d0 <step+0x400>
    5a8c:	f3700693          	li	a3,-201
    5a90:	00f6f463          	bgeu	a3,a5,5a98 <step+0x4c8>
    5a94:	f3700793          	li	a5,-201
    5a98:	0c878793          	addi	a5,a5,200
    5a9c:	000056b7          	lui	a3,0x5
    5aa0:	00f52c23          	sw	a5,24(a0)
    5aa4:	00d486b3          	add	a3,s1,a3
    5aa8:	0246a603          	lw	a2,36(a3) # 5024 <bullet_enemy_position+0x6c>
    5aac:	00000793          	li	a5,0
    5ab0:	00861593          	slli	a1,a2,0x8
    5ab4:	0105d593          	srli	a1,a1,0x10
    5ab8:	00059663          	bnez	a1,5ac4 <step+0x4f4>
    5abc:	0276c783          	lbu	a5,39(a3)
    5ac0:	0017b793          	seqz	a5,a5
    5ac4:	000056b7          	lui	a3,0x5
    5ac8:	00d486b3          	add	a3,s1,a3
    5acc:	02f684a3          	sb	a5,41(a3) # 5029 <bullet_enemy_position+0x71>
    5ad0:	f01ff06f          	j	59d0 <step+0x400>
    5ad4:	028ac603          	lbu	a2,40(s5)
    5ad8:	00060663          	beqz	a2,5ae4 <step+0x514>
    5adc:	00c45783          	lhu	a5,12(s0)
    5ae0:	e7678ce3          	beq	a5,s6,5958 <step+0x388>
    5ae4:	00042503          	lw	a0,0(s0)
    5ae8:	7ff50793          	addi	a5,a0,2047
    5aec:	00fbee63          	bltu	s7,a5,5b08 <step+0x538>
    5af0:	00442583          	lw	a1,4(s0)
    5af4:	ffffc7b7          	lui	a5,0xffffc
    5af8:	00f587b3          	add	a5,a1,a5
    5afc:	00fc6663          	bltu	s8,a5,5b08 <step+0x538>
    5b00:	00c45683          	lhu	a3,12(s0)
    5b04:	01b6ec63          	bltu	a3,s11,5b1c <step+0x54c>
    5b08:	00000613          	li	a2,0
    5b0c:	000d0593          	mv	a1,s10
    5b10:	00048513          	mv	a0,s1
    5b14:	e04ff0ef          	jal	5118 <spawn>
    5b18:	e41ff06f          	j	5958 <step+0x388>
    5b1c:	06060663          	beqz	a2,5b88 <step+0x5b8>
    5b20:	01144783          	lbu	a5,17(s0)
    5b24:	00300893          	li	a7,3
    5b28:	15178e63          	beq	a5,a7,5c84 <step+0x6b4>
    5b2c:	00400893          	li	a7,4
    5b30:	19178e63          	beq	a5,a7,5ccc <step+0x6fc>
    5b34:	00200893          	li	a7,2
    5b38:	05179863          	bne	a5,a7,5b88 <step+0x5b8>
    5b3c:	0000e7b7          	lui	a5,0xe
    5b40:	03c6f893          	andi	a7,a3,60
    5b44:	d9878793          	addi	a5,a5,-616 # dd98 <directions>
    5b48:	011787b3          	add	a5,a5,a7
    5b4c:	00079303          	lh	t1,0(a5)
    5b50:	0cd00793          	li	a5,205
    5b54:	02fd07b3          	mul	a5,s10,a5
    5b58:	00500893          	li	a7,5
    5b5c:	00a7d793          	srli	a5,a5,0xa
    5b60:	031787b3          	mul	a5,a5,a7
    5b64:	06000893          	li	a7,96
    5b68:	40fd07b3          	sub	a5,s10,a5
    5b6c:	ffe78793          	addi	a5,a5,-2
    5b70:	031787b3          	mul	a5,a5,a7
    5b74:	01f35893          	srli	a7,t1,0x1f
    5b78:	006888b3          	add	a7,a7,t1
    5b7c:	4018d893          	srai	a7,a7,0x1
    5b80:	011787b3          	add	a5,a5,a7
    5b84:	00f41423          	sh	a5,8(s0)
    5b88:	00841883          	lh	a7,8(s0)
    5b8c:	00a41783          	lh	a5,10(s0)
    5b90:	00168693          	addi	a3,a3,1
    5b94:	00a88533          	add	a0,a7,a0
    5b98:	00b787b3          	add	a5,a5,a1
    5b9c:	00a42023          	sw	a0,0(s0)
    5ba0:	00f42223          	sw	a5,4(s0)
    5ba4:	00d41623          	sh	a3,12(s0)
    5ba8:	02060063          	beqz	a2,5bc8 <step+0x5f8>
    5bac:	01144603          	lbu	a2,17(s0)
    5bb0:	00500693          	li	a3,5
    5bb4:	00d61a63          	bne	a2,a3,5bc8 <step+0x5f8>
    5bb8:	12055863          	bgez	a0,5ce8 <step+0x718>
    5bbc:	00042023          	sw	zero,0(s0)
    5bc0:	411008b3          	neg	a7,a7
    5bc4:	01141423          	sh	a7,8(s0)
    5bc8:	00042683          	lw	a3,0(s0)
    5bcc:	00812703          	lw	a4,8(sp)
    5bd0:	4086d693          	srai	a3,a3,0x8
    5bd4:	d8e6c2e3          	blt	a3,a4,5958 <step+0x388>
    5bd8:	00c12703          	lw	a4,12(sp)
    5bdc:	d6d74ee3          	blt	a4,a3,5958 <step+0x388>
    5be0:	4087d793          	srai	a5,a5,0x8
    5be4:	fed98613          	addi	a2,s3,-19
    5be8:	d6c7c8e3          	blt	a5,a2,5958 <step+0x388>
    5bec:	00c98613          	addi	a2,s3,12
    5bf0:	d6f644e3          	blt	a2,a5,5958 <step+0x388>
    5bf4:	412686b3          	sub	a3,a3,s2
    5bf8:	01368613          	addi	a2,a3,19
    5bfc:	00f44683          	lbu	a3,15(s0)
    5c00:	413787b3          	sub	a5,a5,s3
    5c04:	01378793          	addi	a5,a5,19
    5c08:	00669693          	slli	a3,a3,0x6
    5c0c:	00f687b3          	add	a5,a3,a5
    5c10:	02078693          	addi	a3,a5,32
    5c14:	0000e5b7          	lui	a1,0xe
    5c18:	dd858593          	addi	a1,a1,-552 # ddd8 <bullet_contact_masks>
    5c1c:	00279793          	slli	a5,a5,0x2
    5c20:	00269693          	slli	a3,a3,0x2
    5c24:	00d586b3          	add	a3,a1,a3
    5c28:	00f585b3          	add	a1,a1,a5
    5c2c:	0005a783          	lw	a5,0(a1)
    5c30:	0006a683          	lw	a3,0(a3)
    5c34:	00c7d7b3          	srl	a5,a5,a2
    5c38:	0017f793          	andi	a5,a5,1
    5c3c:	0c078863          	beqz	a5,5d0c <step+0x73c>
    5c40:	0c0c9263          	bnez	s9,5d04 <step+0x734>
    5c44:	00005cb7          	lui	s9,0x5
    5c48:	01948cb3          	add	s9,s1,s9
    5c4c:	024cc783          	lbu	a5,36(s9) # 5024 <bullet_enemy_position+0x6c>
    5c50:	00000613          	li	a2,0
    5c54:	000d0593          	mv	a1,s10
    5c58:	fff78793          	addi	a5,a5,-1
    5c5c:	0ff7f793          	zext.b	a5,a5
    5c60:	02fc8223          	sb	a5,36(s9)
    5c64:	00048513          	mv	a0,s1
    5c68:	00f12823          	sw	a5,16(sp)
    5c6c:	cacff0ef          	jal	5118 <spawn>
    5c70:	01012783          	lw	a5,16(sp)
    5c74:	08079463          	bnez	a5,5cfc <step+0x72c>
    5c78:	007807b7          	lui	a5,0x780
    5c7c:	02fca023          	sw	a5,32(s9)
    5c80:	b2dff06f          	j	57ac <step+0x1dc>
    5c84:	2ab00893          	li	a7,683
    5c88:	031d07b3          	mul	a5,s10,a7
    5c8c:	031688b3          	mul	a7,a3,a7
    5c90:	00b7d793          	srli	a5,a5,0xb
    5c94:	00d8d893          	srli	a7,a7,0xd
    5c98:	011787b3          	add	a5,a5,a7
    5c9c:	00f7f793          	andi	a5,a5,15
    5ca0:	0000e8b7          	lui	a7,0xe
    5ca4:	d9888893          	addi	a7,a7,-616 # dd98 <directions>
    5ca8:	00279793          	slli	a5,a5,0x2
    5cac:	00f887b3          	add	a5,a7,a5
    5cb0:	0007d883          	lhu	a7,0(a5) # 780000 <__freertos_irq_stack_top+0x7624d0>
    5cb4:	0027d783          	lhu	a5,2(a5)
    5cb8:	00189893          	slli	a7,a7,0x1
    5cbc:	01141423          	sh	a7,8(s0)
    5cc0:	00179793          	slli	a5,a5,0x1
    5cc4:	00f41523          	sh	a5,10(s0)
    5cc8:	ec1ff06f          	j	5b88 <step+0x5b8>
    5ccc:	0076f793          	andi	a5,a3,7
    5cd0:	ea079ce3          	bnez	a5,5b88 <step+0x5b8>
    5cd4:	00a41783          	lh	a5,10(s0)
    5cd8:	37f00893          	li	a7,895
    5cdc:	eaf8c6e3          	blt	a7,a5,5b88 <step+0x5b8>
    5ce0:	02078793          	addi	a5,a5,32
    5ce4:	fe1ff06f          	j	5cc4 <step+0x6f4>
    5ce8:	0003c6b7          	lui	a3,0x3c
    5cec:	80068693          	addi	a3,a3,-2048 # 3b800 <__freertos_irq_stack_top+0x1dcd0>
    5cf0:	eca6dce3          	bge	a3,a0,5bc8 <step+0x5f8>
    5cf4:	00d42023          	sw	a3,0(s0)
    5cf8:	ec9ff06f          	j	5bc0 <step+0x5f0>
    5cfc:	03c00793          	li	a5,60
    5d00:	02fc9023          	sh	a5,32(s9)
    5d04:	00100c93          	li	s9,1
    5d08:	c51ff06f          	j	5958 <step+0x388>
    5d0c:	00c6d7b3          	srl	a5,a3,a2
    5d10:	0017f793          	andi	a5,a5,1
    5d14:	c40782e3          	beqz	a5,5958 <step+0x388>
    5d18:	01044783          	lbu	a5,16(s0)
    5d1c:	c2079ee3          	bnez	a5,5958 <step+0x388>
    5d20:	00100793          	li	a5,1
    5d24:	00f40823          	sb	a5,16(s0)
    5d28:	000057b7          	lui	a5,0x5
    5d2c:	00f487b3          	add	a5,s1,a5
    5d30:	01c7a683          	lw	a3,28(a5) # 501c <bullet_enemy_position+0x64>
    5d34:	fff00613          	li	a2,-1
    5d38:	00c68663          	beq	a3,a2,5d44 <step+0x774>
    5d3c:	00168693          	addi	a3,a3,1
    5d40:	00d7ae23          	sw	a3,28(a5)
    5d44:	000056b7          	lui	a3,0x5
    5d48:	00d486b3          	add	a3,s1,a3
    5d4c:	0186a783          	lw	a5,24(a3) # 5018 <bullet_enemy_position+0x60>
    5d50:	ff500613          	li	a2,-11
    5d54:	00f67463          	bgeu	a2,a5,5d5c <step+0x78c>
    5d58:	ff500793          	li	a5,-11
    5d5c:	00a78793          	addi	a5,a5,10
    5d60:	00f6ac23          	sw	a5,24(a3)
    5d64:	bf5ff06f          	j	5958 <step+0x388>
    5d68:	0f000d93          	li	s11,240
    5d6c:	bfdff06f          	j	5968 <step+0x398>
    5d70:	ff800793          	li	a5,-8
    5d74:	a5dff06f          	j	57d0 <step+0x200>
