#include <assert.h>
#include <stdio.h>
#include "interactive_game.h"
int ref_game_reset(bullet_state *,unsigned,uint32_t);
int ref_game_update_cached(bullet_state *,const game_input *,const bullet_state *);
int ref_game_build(const bullet_state *,uint32_t,int,int,unsigned,bullet_stream *);
static bullet_state actual,reference,initial_a,initial_r;
static bullet_stream stream_a,stream_r;
static void same_state(const bullet_state *a,const bullet_state *b) {
#define S(f) assert(a->f==b->f)
 S(seed);S(tick);S(count);S(player_x);S(player_y);S(round_tick);S(score);S(grazes);
 S(invulnerable);S(game_over_ticks);S(hp);S(interactive);S(won);
 for(unsigned i=0;i<3;i++)assert(a->enemy_hp[i]==b->enemy_hp[i]);
 for(unsigned i=0;i<a->count;i++) {
  const bullet_object *x=&a->objects[i],*y=&b->objects[i];
#define O(f) assert(x->f==y->f)
  O(x);O(y);O(vx);O(vy);O(age);O(kind);O(shape);O(grazed);O(path);
#undef O
 }
#undef S
}
static void same_stream(const bullet_stream *a,const bullet_stream *b) {
#define S(f) assert(a->f==b->f)
 S(count);S(visible);S(scene_pixels);S(alpha_commands);S(alpha_pixels);
 for(unsigned i=0;i<a->count;i++) {
  const gpu_command *x=&a->commands[i],*y=&b->commands[i];
#define O(f) assert(x->f==y->f)
  O(src_addr);O(dst_addr);O(src_stride);O(dst_stride);O(width_pixels);O(height_pixels);
  O(color);O(color_key);O(flags);O(tag);O(op);O(alpha);
#undef O
 }
#undef S
}
int main(void) {
 const unsigned counts[]={1,32,64,128,256,512,786,1024};
 const uint32_t seeds[]={0,7,UINT32_C(0xdeadbeef),UINT32_MAX};
 unsigned steps=0,frames=0;
 for(unsigned c=0;c<8;c++)for(unsigned seed=0;seed<4;seed++) {
  assert(!game_reset(&actual,counts[c],seeds[seed]));
  assert(!ref_game_reset(&reference,counts[c],seeds[seed]));
  initial_a=actual;initial_r=reference;same_state(&actual,&reference);
  for(unsigned tick=0;tick<600;tick++) {
   const unsigned directions[]={V3_KEY_LEFT,V3_KEY_UP,V3_KEY_RIGHT,V3_KEY_DOWN};
   game_input in={.held=(uint16_t)(directions[(tick/20)%4]|V3_KEY_FIRE|((tick/60)&1?V3_KEY_SLOW:0)),
    .pressed=(uint16_t)(tick==333?V3_KEY_RESTART:tick==500?V3_KEY_COMPARE:0)};
   assert(game_update_cached(&actual,&in,&initial_a)==ref_game_update_cached(&reference,&in,&initial_r));
   same_state(&actual,&reference);++steps;
   if(tick%31==0)for(unsigned net=0;net<2;net++) {
    uint32_t dst=(tick&1)?GPU_FRAMEBUFFER_A:GPU_FRAMEBUFFER_B;
    assert(!game_build(&actual,dst,(int)net,tick&1,BULLET_MAX_COMMANDS,&stream_a));
    assert(!ref_game_build(&reference,dst,(int)net,tick&1,BULLET_MAX_COMMANDS,&stream_r));
    same_stream(&stream_a,&stream_r);++frames;
   }
  }
 }
 printf("PASS frozen49a77ec reference: %u complete state steps, %u full ordered command streams, 8 counts/4 seeds, movement/fire/slow/restart/compare\n",steps,frames);
}
