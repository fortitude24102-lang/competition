$ErrorActionPreference='Stop'
Set-Location 'D:/ZYNQ/smallproject/.worktrees/pango-riscv-cpu'
$out='generated/verification/v3/logic-invariant-20261026'
$bit='D:/efinity_builds/local_keys_20261026_r2/outflow/efinix_2d_gpu.bit'
$control="$out/probe-control-r1/gpu_demo.bin"
$fast="$out/probe-fast-r1/gpu_demo.bin"
$oldNormal='generated/verification/v3/local-keys-20261026/normal-r2/gpu_demo.bin'
$newNormal="$out/normal-fast-r1/gpu_demo.bin"
foreach($pair in @(@($bit,'a98148a59541161874a5f8685c5338b3742b6e553c4ba2d3718f3d25a7c98436'),@($control,'40db4f913715f28e7d8298f47bb6e6bddd8d3ffca8967883566666e3904147ce'),@($fast,'52258c56ccf84797faa106097d9a5de71455e8b9276b60c9cc204ec70a3d6c6e'),@($oldNormal,'70addf7858d5dd6cbd9cf29ae1ed7212b36c72b0554aa08f11efbbe7dc847ea3'),@($newNormal,'a6489281abd9aaa148e6293a85cde232b71da97ce10799b77947f194ce86513a'))) {
 if((Get-FileHash -LiteralPath $pair[0]).Hash.ToLowerInvariant() -ne $pair[1]){throw 'Cohort input identity mismatch'}
}
if(Test-Path -LiteralPath "$out/board-summary-r1.json"){throw 'Fresh board cohort required'}
if('COM9' -notin [IO.Ports.SerialPort]::GetPortNames()){throw 'Required serial device absent'}
& C:/Users/fortiutde/AppData/Local/Programs/Python/Python39/python.exe generated/verification/v3/local-keys-20261026/check-inputs.py
if($LASTEXITCODE){throw 'Hardware input verification failed'}
$state=Invoke-RestMethod http://127.0.0.1:8765/api/status -TimeoutSec 3
if($state.simulated -or $state.owned -or $state.stale -or !(1024 -band $state.telemetry.raw.status_flags)){throw 'Fresh real released MENU required'}
$rows=@();$accepted=$false
try {
 & D:/efinity/pgm/bin/ftdi_pgm.bat $bit -m jtag *> "$out/bit-load-r1.log"
 if($LASTEXITCODE){throw 'Cohort BIT load failed'}
 Start-Sleep -Seconds 3
 foreach($name in 'control-a1','fast-b1','control-a2','fast-b2') {
  $bin=if($name.StartsWith('fast')){$fast}else{$control}
  & scripts/capture-game-probe.ps1 -Bin $bin -Log "$out/$name-uart.log" -SerialPort COM9 -LogicCopy 1 -SealWords 256 -HudDirect 1 -Seconds 140 *> "$out/$name-capture.log"
  if($LASTEXITCODE){throw "Capture failed: $name"}
  $raw=Get-Content -LiteralPath "$out/$name-uart.log" -Raw
  foreach($record in @('V3_PROBE_STOP,result=0','V3_SEAL_STATE,count=600,sealed=1,words=256,offset=9836,crc=a7bd652f','V3_READY,build=20261015,epoch=00030002,network=1,state=02d00000,mode=LIVE,count=1024')) {
   if(@($raw -split '\r?\n'|Where-Object {$_ -eq $record}).Count -ne 1){throw "Missing/duplicate workload record: $name $record"}
  }
  $matches=[regex]::Matches($raw,'(?m)^V3_PROBE,target=1024,frames=3600,[^\r\n]+')
  if($matches.Count -ne 1){throw 'Missing/duplicate complete3600 probe'}
  $row=[ordered]@{name=$name}
  foreach($field in $matches[0].Value.Split(',')|Select-Object -Skip 1) {
   $parts=$field.Split('=',2);if($parts.Count -ne 2 -or $row.Contains($parts[0])){throw 'Malformed probe field'}
   $row[$parts[0]]=[long]$parts[1]
  }
  foreach($p in @{work_miss=0;late_present=0;under=0;errors=0;visible_min=1006;visible_max=1016;alpha_min=130;alpha_max=131}.GetEnumerator()) {
   if(!$row.Contains($p.Key) -or $row[$p.Key] -ne $p.Value){throw "Changed workload/health: $name $($p.Key)"}
  }
  if($row.work_max_us -ge 16666 -or $row.wall_max_us -ge 16666){throw 'Strict ordinary frame maximum failed'}
  $rows+=[pscustomobject]$row
  $rows|ConvertTo-Json -Depth 4|Set-Content "$out/board-summary-r1.json" -Encoding utf8
  $matches[0].Value
 }
 $meanA=($rows[0].work_mean_us+$rows[2].work_mean_us)/2.0
 $meanB=($rows[1].work_mean_us+$rows[3].work_mean_us)/2.0
 $accepted=$rows[1].work_mean_us -lt $rows[0].work_mean_us -and $rows[3].work_mean_us -lt $rows[2].work_mean_us -and $meanB -lt $meanA
 [ordered]@{accepted=$accepted;control_mean_us=$meanA;candidate_mean_us=$meanB;reduction_percent=100.0*($meanA-$meanB)/$meanA;frames=14400;bit_sha256=(Get-FileHash $bit).Hash.ToLowerInvariant()}|ConvertTo-Json|Set-Content "$out/board-comparison-r1.json" -Encoding utf8
 if($accepted){'PASS repeated lower ordinary-frame mean work, same BIT/input/workload and zero health failures'}else{'REJECT no repeated lower mean; restore old normal'}
} catch {
 $_|Out-String|Set-Content "$out/board-failure-r1.txt" -Encoding utf8
 throw
} finally {
 $restore=if($accepted){$newNormal}else{$oldNormal}
 & scripts/test-game-menu-board.ps1 -Bin $restore -SerialPort COM9 -ExpectedBuild 0x20261015 -LevelCount 6 -Python C:/Users/fortiutde/AppData/Local/Programs/Python/Python39/python.exe -OutDirectory "$out/final-menu-r1" *> "$out/final-menu-r1.log"
 $state=Invoke-RestMethod http://127.0.0.1:8765/api/status -TimeoutSec 3
 if($state.simulated -or $state.stale -or $state.owned -or !(1024 -band $state.telemetry.raw.status_flags)){throw 'Final normal MENU not fresh/released'}
 $state|ConvertTo-Json -Depth 8|Set-Content "$out/final-state-r1.json" -Encoding utf8
 [ordered]@{candidate_accepted=$accepted;normal_sha256=(Get-FileHash $restore).Hash.ToLowerInvariant();bit_sha256=(Get-FileHash $bit).Hash.ToLowerInvariant();fresh_released_menu=$true}|ConvertTo-Json|Set-Content "$out/selected-r1.json" -Encoding utf8
 'PASS qualified normal six-tier MENU restored and released; no debugger connected afterward'
}
