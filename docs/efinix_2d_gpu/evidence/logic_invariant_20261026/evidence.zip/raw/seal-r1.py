import hashlib
import json
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

root=Path.cwd()
raw=root/'generated/verification/v3/logic-invariant-20261026'
dest=root/'docs/efinix_2d_gpu/evidence/logic_invariant_20261026'
bit=Path('D:/efinity_builds/local_keys_20261026_r2/outflow/efinix_2d_gpu.bit')
checks={bit:'a98148a59541161874a5f8685c5338b3742b6e553c4ba2d3718f3d25a7c98436',
 raw/'probe-control-r1/gpu_demo.bin':'40db4f913715f28e7d8298f47bb6e6bddd8d3ffca8967883566666e3904147ce',
 raw/'probe-fast-r1/gpu_demo.bin':'52258c56ccf84797faa106097d9a5de71455e8b9276b60c9cc204ec70a3d6c6e',
 raw/'normal-fast-r1/gpu_demo.bin':'a6489281abd9aaa148e6293a85cde232b71da97ce10799b77947f194ce86513a',
 root/'generated/verification/v3/local-keys-20261026/normal-r2/gpu_demo.bin':'70addf7858d5dd6cbd9cf29ae1ed7212b36c72b0554aa08f11efbbe7dc847ea3',
 root/'sw/efinix_gpu/src/bullet_demo.c':'f0399b92eb74bf20e4762ce48586c96248683c41dbad244a892d10bf903f3b33'}
for path,digest in checks.items():
 assert hashlib.sha256(path.read_bytes()).hexdigest()==digest,str(path)
rows=json.loads((raw/'board-summary-r1.json').read_text(encoding='utf-8-sig'))
assert [r['name'] for r in rows]==['control-a1','fast-b1','control-a2','fast-b2']
for row in rows:
 for key,value in dict(target=1024,frames=3600,work_miss=0,late_present=0,under=0,errors=0,visible_min=1006,visible_max=1016,alpha_min=130,alpha_max=131).items():
  assert row[key]==value
 assert row['work_max_us']<16666 and row['wall_max_us']<16666
 assert (raw/(row['name']+'-uart.log')).read_text(encoding='utf-8-sig').splitlines().count('V3_PROBE_STOP,result=0')==1
assert rows[1]['work_mean_us']<rows[0]['work_mean_us'] and rows[3]['work_mean_us']<rows[2]['work_mean_us']
selected=json.loads((raw/'selected-r1.json').read_text(encoding='utf-8-sig'))
assert selected['candidate_accepted'] and selected['fresh_released_menu']
assert selected['normal_sha256']==checks[raw/'normal-fast-r1/gpu_demo.bin']
assert 'PASS requested V3 integration checks: SoftwareOnly=True' in (raw/'software-all-r1.log').read_text(encoding='utf-8-sig')
assert 'PASS real 6-tier START/MENU ACK+snapshot.' in (raw/'final-menu-r1.log').read_text(encoding='utf-8-sig')
files={'README.md':dest/'README.md','artifacts/efinix_2d_gpu.bit':bit,
 'artifacts/fallback-normal.bin':root/'generated/verification/v3/local-keys-20261026/normal-r2/gpu_demo.bin',
 'physical-inputs.json':root/'generated/verification/v3/local-keys-20261026/physical-inputs-after-launch-r2.json'}
for p in raw.rglob('*'):
 if p.is_file():files['raw/'+p.relative_to(raw).as_posix()]=p
for directory in ('sw/efinix_gpu/include','sw/efinix_gpu/src','sw/efinix_gpu/tests','sw/efinix_gpu/assets/v2'):
 for p in (root/directory).rglob('*'):
  if p.is_file() and p.suffix in ('.c','.h'):files['source/'+p.relative_to(root).as_posix()]=p
for name in ('sw/efinix_gpu/Makefile','scripts/test-v3-integration.ps1','scripts/test-efinix-software.ps1','scripts/capture-game-probe.ps1','scripts/test-game-menu-board.ps1','docs/superpowers/plans/2026-10-26-invariant-path-math.md'):
 files['source/'+name]=root/name
archive=dest/'evidence.zip';assert not archive.exists();inventory={}
with ZipFile(archive,'w',ZIP_DEFLATED,compresslevel=6) as zipped:
 for name,path in sorted(files.items()):
  data=path.read_bytes();inventory[name]=hashlib.sha256(data).hexdigest();zipped.writestr(name,data)
 zipped.writestr('inventory.json',json.dumps(inventory,indent=2))
with ZipFile(archive) as zipped:
 assert zipped.testzip() is None
 for name,digest in inventory.items():assert hashlib.sha256(zipped.read(name)).hexdigest()==digest
digest=hashlib.sha256(archive.read_bytes()).hexdigest()
(dest/'evidence.sha256').write_text(digest+'  evidence.zip\n')
print(json.dumps(dict(entries=len(inventory)+1,bytes=archive.stat().st_size,sha256=digest,verified=True)))
