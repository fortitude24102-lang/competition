import json
from pathlib import Path
import re
import subprocess
import sys
elf = Path(sys.argv[1])
assembly = subprocess.check_output(['D:/efinity/risc_v_gcc/toolchain/bin/riscv-none-elf-objdump.exe', '-d', '--disassemble=step', str(elf)], text=True)
assert '<step>:' in assembly
instructions = re.findall(r'\b(?:div|divu|rem|remu)\b', assembly)
elf.with_suffix('.step.asm').write_text(assembly)
print(json.dumps(dict(elf=str(elf), step_div_rem_sites=len(instructions), maximum=2)))
assert len(instructions) <= 2, 'Steady path math still emits division/remainder instructions'
