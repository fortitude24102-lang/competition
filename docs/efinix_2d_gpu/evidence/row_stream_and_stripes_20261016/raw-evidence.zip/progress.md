# SDD ledger — plan: docs/superpowers/plans/2026-10-16-row-stream-and-stripes.md

BASE 53bcd61. Inline execution, existing isolated worktree retained.
Pre-flight: Task1 cache stream and Task2 AXI bridge meet at Render master, no source-cache address change.
Pre-flight: Task2 STATUS bit16/alias consumed by Task3, explicit feature gates and unchanged old BIT default.
Pre-flight: Task3 crop bins copy into original list banks, no list-reader ABI/range extension.
Ruling: WSL helpers require explicit POSIX GIT_DIR/GIT_WORK_TREE — Windows absolute gitfile cannot resolve in Linux — bookkeeping only, no hardware cost.
Task1 started. Baseline CopyStream 4/4 pass. RED CachedKeyStreamSpec missing CachedKeyStream class (key-red.log).
Task1 module GREEN2/2. Integrated candidate targeted regressions running.
Task2 RED missing StripeScratchpad class (stripe-red.log); Task3 RED missing gpu_stripes.h (compiler output); planner/pixel oracle now GREEN.
Task2/3 in progress, no board loads. Single960x8 strip, originals retained by explicit flags.
Task1 targeted 33/33 across6 suites pass; 8x8 cached strided Key125->100cycles, pixels/write sequence identical. Task2 local bridge and list-enabled Top Alpha/Key/local-copy pass.
Final review: one Important StripeRender+HudList MENU/WIN private-bank leak. Real V3 loop boundary regression RED assertion exit134 (hud-route-red.log), moving bank restoration outside list_frame is the minimal fix; GREEN pending. No Critical/Minor findings.
Final review set aside board resource/timing and sustained qualification — these remain gated by actual Efinity and board evidence, not assumed from unit tests.
Final: fixed MENU/WIN HUD bank leak — test-stripe-hud-route.sh real V3 loop RED bank02d40000/exit134 -> GREEN bank02d20000 for MENU+WIN. No additional production refactor. Full28C/27protocol suite added these checks.
Efinity candidate4e9001a4c346dda1eb5ddfd5600d8b03a4be7f96af2a7910c4ddc15fca1c0d94: compile PASS; XLR49923/60800 RAM192/256 DSP33/160; core100MHz setup1.022/hold0.026ns; all16 setup/holdrelationships positive. Interface/route/PGM pass. RAM-only baseline board probe in progress; no Flash/push.
Old BIT + identical dc82...BIN 512/HUD-on3600:60.1fps,mean11552us,max14964us,0miss/late/under/error,CRCc0ecf1df,visible499..504 Alpha66..67.
Board oracle first failure line33 is fixture preflight: deliberately setting pc_sprite.y79 violates existing pc_build min80, before any GPU issue (LAST_DONE0/ERROR0). Correct fixture to80; its Alpha starts78 and still crosses strips. Not a GPU failure; preserve first raw capture.
Board oracle r2 PASS four full framebuffer CRCs/guards,64/512/1024/1819 active+8/64/128/228Alpha. DDR vs stripe ticks385625/643496,580020/1088503,803564/1589329,1150152/2319732. Stripes loses, stays experimental/off; no false physical-DDR bytes claim (render counters include local traffic).
CombinedBIT same terminal512 BIN3600:60.1fps,mean11526us,max15884us,0miss/late/under/error,CRCc0ecf1df. Compared11552us old mean,26us difference is too small to claim robust whole-game gain. Native challenge running, key-only BIT generating to avoid shipping unused stripeRAM.
Task1: complete (commit0b439ee, integration flag commit6efd0a2); fullGPU91/91 and targeted33/33, all final productionRTL covered. Key-only BIT7898424a... compiled core setup0.411/hold0.026ns XLR49738 RAM176 DSP33; terminal512sameBIN3600mean11527us/max14445us,60.1fps,0four-errors.
Task2: complete (commit6efd0a2); fullGPU21suites91/91 + finalStripeScratchpadSpec1/1 extended invalidFIXED/4KiB/reserved-tail cases. No RTL changes after fullsuite; full suite not redundantly repeated for test-only additions.
Task3: code/host/board validation complete, docs/evidence/commit pending. Full28C/27actualUDP/HTTP pass. Stripe complete native app ADC0... realfourtiers/resource/MENU pass, but30fps already at lower tiers; keepdisabled.
Native key-only BIT + original95b...BIN:1047 long confirmation failed; final1040+130Alpha confirmed3600@60.10fps,workmax16451us/wall16639us,0miss/late/under/error,5secondpostholdPASS, safelyMENU exported exactstats. Firstcombined run interruptedat1048 byrenewedcontrolsession, noqual andrawpreserved; collectoridentity verifiedbeforestop.
Final review: noCritical/Minor, soleImportant fixed RED->GREEN, finalGPU91/91+C28/28+protocol27/27 green. Boardtiming and qualification set-asides now backed by measurements, not inferred. ManualHDMI/stack/endurance remain outside verified window.
