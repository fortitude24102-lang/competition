import json
import sys
from pathlib import Path

for name in sys.argv[1:]:
    path = Path(name)
    transitions = []
    rows = 0
    last = None
    for line in path.read_text(encoding='utf-8-sig').splitlines():
        state = json.loads(line)
        perf = state.get('performance')
        if not perf or perf.get('stale') or state.get('stale'):
            continue
        rows += 1
        signature = (perf['target'], perf['stage'])
        if signature != last:
            transitions.append({'target': perf['target'], 'stage': perf['stage'],
                                'first_frame': perf['frames'], 'last_frame': perf['frames']})
            last = signature
        else:
            transitions[-1]['last_frame'] = perf['frames']
    print(json.dumps({'file': str(path), 'fresh_rows': rows, 'transitions': transitions}, ensure_ascii=False))
