$ErrorActionPreference='Stop'
Set-Location 'D:/ZYNQ/smallproject/.worktrees/pango-riscv-cpu'
$out='generated/verification/v3/alpha-early-20261025'
$bin="$out/input-bins/normal.bin"
$restore='D:/efinity_builds/wide_copy_fair_20261024_r1/outflow/efinix_2d_gpu.bit'
if((Get-FileHash -LiteralPath $bin -Algorithm SHA256).Hash.ToLowerInvariant() -ne 'e0520e3ed17aa850395906c9f26ef574a3acbdd5224daf69828a29cf30036c94'){throw 'Normal BIN identity mismatch'}
if((Get-FileHash -LiteralPath $restore -Algorithm SHA256).Hash.ToLowerInvariant() -ne '4f19579ced2d8d08a2281292847d56d08c8bc767cc7253a9623c2c389aa81f3a'){throw 'Fallback BIT identity mismatch'}
if(!(Select-String -LiteralPath "$out/board-analysis-r1.log" -SimpleMatch 'BOARD_IDENTITIES_GOLDEN_AND_HEALTH,PASS')){throw 'Pixel/normal A/B/A incomplete'}
if(!(Select-String -LiteralPath "$out/repeat-detail-exec-r1.log" -SimpleMatch 'PASS repeated candidate and diagnostic returned')){throw 'Repeated candidate writer not completed'}
$state=Invoke-RestMethod 'http://127.0.0.1:8765/api/status' -TimeoutSec 5
if($state.simulated -or $state.owned -or $state.stale -or !(1024 -band $state.telemetry.raw.status_flags)){throw 'Fresh real released MENU required'}
try {
 foreach($name in @('challenge-control-a1-r2','challenge-candidate-b1-r2','challenge-control-a2-r2')) {
  $variant=if($name -eq 'challenge-candidate-b1-r2'){'candidate'}else{'control'}
  $build="D:/efinity_builds/alpha_early_${variant}_20261025_r1"
  $gate=Get-Content -LiteralPath "$out/resource-cdc-$variant-r1.log" -Raw
  if($gate -notmatch 'PASS routed data CDC: 1488 paths' -or $gate -notmatch 'PASS final setup/hold'){throw 'Physical acceptance missing'}
  if((Get-FileHash -LiteralPath "$build/gpu-build.json" -Algorithm SHA256).Hash -ne (Get-FileHash -LiteralPath "$out/rtl-$variant-r1/gpu-build.json" -Algorithm SHA256).Hash){throw 'Selected physical manifest changed'}
  & scripts/test-game-menu-board.ps1 -Bin $bin -Bit "$build/outflow/efinix_2d_gpu.bit" -LoadBit -SerialPort COM9 -OutDirectory "$out/$name" -ExpectedBuild 0x20261015 -LevelCount 6 -PerformanceChallenge -QualifiedHoldSeconds 5 -Python C:/Users/fortiutde/AppData/Local/Programs/Python/Python39/python.exe *> "$out/$name.log"
  $raw=Get-Content -LiteralPath "$out/$name.log" -Raw
  if($raw -notmatch 'PASS real performance: best=' -or $raw -notmatch 'PASS qualified hold seconds=5' -or $raw -notmatch 'PASS real 6-tier'){throw "Full challenge not qualified: $name"}
  $raw -split '\r?\n' | Where-Object {$_ -match '^PASS real performance|^PASS qualified hold'}
 }
} finally {
 & scripts/test-game-menu-board.ps1 -Bin $bin -Bit $restore -LoadBit -SerialPort COM9 -OutDirectory "$out/after-challenge-menu-r2" -ExpectedBuild 0x20261015 -LevelCount 6 -Python C:/Users/fortiutde/AppData/Local/Programs/Python/Python39/python.exe *> "$out/after-challenge-menu-r2.log"
 $state=Invoke-RestMethod 'http://127.0.0.1:8765/api/status' -TimeoutSec 5
 if($state.simulated -or $state.owned -or $state.stale -or !(1024 -band $state.telemetry.raw.status_flags)){throw 'Final real normal MENU not fresh/released'}
 $state|ConvertTo-Json -Depth 8|Set-Content -LiteralPath "$out/after-challenge-state-r2.json" -Encoding utf8
 'PASS full challenge cohort returned to known normal MENU'
}
