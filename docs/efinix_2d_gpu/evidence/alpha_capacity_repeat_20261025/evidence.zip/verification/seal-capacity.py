import hashlib
import json
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

root = Path.cwd()
alpha = root / 'generated/verification/v3/alpha-early-20261025'
cpu = root / 'generated/verification/v3/cpu-builder-20261025'
dest = root / 'docs/efinix_2d_gpu/evidence/alpha_capacity_repeat_20261025'
archive = dest / 'evidence.zip'
assert not archive.exists(), 'Never overwrite sealed evidence'
files = {}

def add(path, name):
    assert path.is_file(), path
    assert name not in files, name
    files[name] = path

def tree(path, prefix):
    assert path.is_dir(), path
    for child in sorted(path.rglob('*')):
        if child.is_file():
            add(child, prefix + '/' + child.relative_to(path).as_posix())

for name in ('challenge-control-a1', 'challenge-control-a1-r2', 'challenge-candidate-b1-r2',
             'challenge-control-a2-r2', 'challenge-control-a2-r3-long',
             'challenge-control-a2-r4-long', 'challenge-candidate-b2-r4-long',
             'after-challenge-menu-r1', 'after-challenge-menu-r2'):
    tree(alpha / name, 'alpha/' + name)
for name in ('challenge-aba-exec-r1.log', 'challenge-aba-exec-r2.log',
             'challenge-control-a1.log', 'challenge-control-a1-r2.log',
             'challenge-candidate-b1-r2.log', 'challenge-control-a2-r2.log',
             'challenge-control-a2-r3-long.log', 'challenge-control-a2-r4-long.log',
             'challenge-candidate-b2-r4-long.log', 'control-a2-timeout-analysis.json',
             'analyze-search-transitions.py', 'run-challenge-aba.ps1', 'run-challenge-aba-r2.ps1',
             'after-challenge-menu-r1.log', 'after-challenge-menu-r2.log',
             'after-challenge-state-r1.json', 'after-challenge-state-r2.json'):
    add(alpha / name, 'alpha/' + name)
for name in ('after-long-control-menu-r1', 'after-capacity-pair-r4-menu'):
    tree(cpu / name, 'cpu/' + name)
for name in ('run-menu-and-long-control.ps1', 'run-capacity-pair-r4.ps1',
             'test-game-menu-board-long-search.ps1', 'control-keepalive.py',
             'control-keepalive-before-budget.py', 'long-control-exec-r1.log',
             'capacity-pair-r4-exec.log', 'after-long-control-menu-r1.log',
             'after-long-control-state-r1.json', 'selected-after-long-control.json',
             'after-capacity-pair-r4-menu.log', 'after-capacity-pair-r4-state.json',
             'selected-after-capacity-pair-r4.json', 'heartbeat-slow-red-clean.log',
             'heartbeat-green-r1.log', 'heartbeat-process-green-r1.log',
             'software-after-heartbeat-r1.log'):
    add(cpu / name, 'cpu/' + name)
for name in ('scripts/control-keepalive.py', 'scripts/test-game-menu-board.ps1',
             'sw/efinix_gpu/tests/test_control_keepalive.py'):
    add(root / name, 'source/' + name)
add(dest / 'README.md', 'README.md')
add(Path(__file__), 'verification/seal-capacity.py')

def private_fields(value):
    if isinstance(value, dict):
        for key, child in value.items():
            assert key.lower() not in ('token', 'password', 'secret', 'authorization', 'cookie'), key
            private_fields(child)
    elif isinstance(value, list):
        for child in value:
            private_fields(child)

manifest = []
rows = 0
with ZipFile(archive, 'x', ZIP_DEFLATED, compresslevel=9) as zipped:
    for name, path in sorted(files.items()):
        data = path.read_bytes()
        if path.suffix == '.jsonl':
            for line in data.decode('utf-8-sig').splitlines():
                private_fields(json.loads(line))
                rows += 1
        elif path.suffix == '.json':
            private_fields(json.loads(data.decode('utf-8-sig')))
        manifest.append(dict(path=name, size=len(data), sha256=hashlib.sha256(data).hexdigest()))
        zipped.writestr(name, data)
    body = json.dumps(dict(payloads=manifest, parsed_status_rows=rows), indent=2).encode()
    zipped.writestr('manifest.json', body)
with ZipFile(archive) as zipped:
    assert len(zipped.namelist()) == len(manifest) + 1
    assert len(set(zipped.namelist())) == len(zipped.namelist())
    for record in manifest:
        data = zipped.read(record['path'])
        assert len(data) == record['size']
        assert hashlib.sha256(data).hexdigest() == record['sha256']
digest = hashlib.sha256(archive.read_bytes()).hexdigest()
(dest / 'SHA256SUMS').write_text(digest + '  evidence.zip\n')
(dest / 'manifest.json').write_bytes(body)
summary = dict(sha256=digest, bytes=archive.stat().st_size, entries=len(manifest)+1, parsed_status_rows=rows)
(cpu / 'capacity-seal-summary.json').write_text(json.dumps(summary, indent=2))
print(json.dumps(summary))
