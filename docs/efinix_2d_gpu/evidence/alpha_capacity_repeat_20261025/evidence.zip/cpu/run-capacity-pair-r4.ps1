$ErrorActionPreference='Stop'
Set-Location 'D:/ZYNQ/smallproject/.worktrees/pango-riscv-cpu'
$out='generated/verification/v3/cpu-builder-20261025'
$alpha='generated/verification/v3/alpha-early-20261025'
$normal="$out/normal-shift-r1/gpu_demo.bin"
$oldNormal="$alpha/input-bins/normal.bin"
$candidate='D:/efinity_builds/alpha_early_candidate_20261025_r1/outflow/efinix_2d_gpu.bit'
$control='D:/efinity_builds/alpha_early_control_20261025_r1/outflow/efinix_2d_gpu.bit'
$fallback='D:/efinity_builds/wide_copy_fair_20261024_r1/outflow/efinix_2d_gpu.bit'
$python='C:/Users/fortiutde/AppData/Local/Programs/Python/Python39/python.exe'
foreach($file in @(@($normal,'0070c5e03300e920d25ac84d1ffae3cebaa17111a7e20143fd535d315844efb1'),@($oldNormal,'e0520e3ed17aa850395906c9f26ef574a3acbdd5224daf69828a29cf30036c94'),@($candidate,'ef240664097d115b1e2fbc60f336a9190d4e8a2941a760642627e3563fcebcb1'),@($control,'e448ea3c872d0254cd22fd2ea2927ab2fe18df85e26a259e878331e86f6840ae'),@($fallback,'4f19579ced2d8d08a2281292847d56d08c8bc767cc7253a9623c2c389aa81f3a'))) {
 if((Get-FileHash -LiteralPath $file[0] -Algorithm SHA256).Hash.ToLowerInvariant() -ne $file[1]){throw 'Capacity pair input identity mismatch'}
}
if((Get-FileHash -LiteralPath "$out/control-keepalive.py").Hash -ne (Get-FileHash -LiteralPath 'scripts/control-keepalive.py').Hash){throw 'Capacity helper snapshot differs from reviewed source'}
if(!(Select-String -LiteralPath "$out/shift-normal-menu-r1.log" -SimpleMatch 'PASS real 6-tier')){throw 'New normal MENU acceptance missing'}
$state=Invoke-RestMethod 'http://127.0.0.1:8765/api/status' -TimeoutSec 5
if($state.simulated -or $state.owned -or $state.stale -or !(1024 -band $state.telemetry.raw.status_flags)){throw 'Fresh real released MENU required'}
$accepted=$false
try {
 foreach($variant in @('control','candidate')) {
  $bit=if($variant -eq 'control'){$control}else{$candidate}
  $name=if($variant -eq 'control'){'challenge-control-a2-r4-long'}else{'challenge-candidate-b2-r4-long'}
  & "$out/test-game-menu-board-long-search.ps1" -Bin $oldNormal -Bit $bit -LoadBit -SerialPort COM9 -OutDirectory "$alpha/$name" -ExpectedBuild 0x20261015 -LevelCount 6 -PerformanceChallenge -QualifiedHoldSeconds 5 -Python $python *> "$alpha/$name.log"
  $raw=Get-Content -LiteralPath "$alpha/$name.log" -Raw
  if($raw -notmatch 'PASS real performance: best=' -or $raw -notmatch 'PASS qualified hold seconds=5' -or $raw -notmatch 'PASS real 6-tier'){throw "Extended full qualification missing: $name"}
  $raw -split '\r?\n'|Where-Object {$_ -match '^PASS real performance|^PASS qualified hold'}
 }
 $accepted=$true
} finally {
 $restoreBit=if($accepted){$candidate}else{$fallback}
 $restoreBin=if($accepted){$normal}else{$oldNormal}
 & scripts/test-game-menu-board.ps1 -Bin $restoreBin -Bit $restoreBit -LoadBit -SerialPort COM9 -OutDirectory "$out/after-capacity-pair-r4-menu" -ExpectedBuild 0x20261015 -LevelCount 6 -Python $python *> "$out/after-capacity-pair-r4-menu.log"
 $state=Invoke-RestMethod 'http://127.0.0.1:8765/api/status' -TimeoutSec 5
 if($state.simulated -or $state.owned -or $state.stale -or !(1024 -band $state.telemetry.raw.status_flags)){throw 'Final real MENU not fresh/released'}
 $state|ConvertTo-Json -Depth 8|Set-Content -LiteralPath "$out/after-capacity-pair-r4-state.json" -Encoding utf8
 [ordered]@{pair_qualified=$accepted;bit=$restoreBit;bin=$restoreBin;bit_sha256=(Get-FileHash -LiteralPath $restoreBit -Algorithm SHA256).Hash.ToLowerInvariant();bin_sha256=(Get-FileHash -LiteralPath $restoreBin -Algorithm SHA256).Hash.ToLowerInvariant();fresh_released_menu=$true}|ConvertTo-Json|Set-Content -LiteralPath "$out/selected-after-capacity-pair-r4.json" -Encoding utf8
 'PASS capacity pair cleanup returned to a verified normal MENU'
}
