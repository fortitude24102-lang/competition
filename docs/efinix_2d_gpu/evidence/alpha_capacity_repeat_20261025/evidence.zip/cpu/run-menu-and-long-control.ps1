$ErrorActionPreference='Stop'
Set-Location 'D:/ZYNQ/smallproject/.worktrees/pango-riscv-cpu'
$out='generated/verification/v3/cpu-builder-20261025'
$alpha='generated/verification/v3/alpha-early-20261025'
$normal="$out/normal-shift-r1/gpu_demo.bin"
$oldNormal="$alpha/input-bins/normal.bin"
$candidate='D:/efinity_builds/alpha_early_candidate_20261025_r1/outflow/efinix_2d_gpu.bit'
$control='D:/efinity_builds/alpha_early_control_20261025_r1/outflow/efinix_2d_gpu.bit'
$fallback='D:/efinity_builds/wide_copy_fair_20261024_r1/outflow/efinix_2d_gpu.bit'
$python='C:/Users/fortiutde/AppData/Local/Programs/Python/Python39/python.exe'
foreach($file in @(@($normal,'0070c5e03300e920d25ac84d1ffae3cebaa17111a7e20143fd535d315844efb1'),@($oldNormal,'e0520e3ed17aa850395906c9f26ef574a3acbdd5224daf69828a29cf30036c94'),@($candidate,'ef240664097d115b1e2fbc60f336a9190d4e8a2941a760642627e3563fcebcb1'),@($control,'e448ea3c872d0254cd22fd2ea2927ab2fe18df85e26a259e878331e86f6840ae'))) {
 if((Get-FileHash -LiteralPath $file[0] -Algorithm SHA256).Hash.ToLowerInvariant() -ne $file[1]){throw 'Long-control input identity mismatch'}
}
$state=Invoke-RestMethod 'http://127.0.0.1:8765/api/status' -TimeoutSec 5
if($state.simulated -or $state.owned -or $state.stale -or !(1024 -band $state.telemetry.raw.status_flags)){throw 'Fresh real released MENU required'}
$accepted=$false
try {
 & scripts/test-game-menu-board.ps1 -Bin $normal -Bit $candidate -LoadBit -SerialPort COM9 -OutDirectory "$out/shift-normal-menu-r1" -ExpectedBuild 0x20261015 -LevelCount 6 -Python $python *> "$out/shift-normal-menu-r1.log"
 'PASS new normal shift BIN real six-tier MENU'
 & "$out/test-game-menu-board-long-search.ps1" -Bin $oldNormal -Bit $control -LoadBit -SerialPort COM9 -OutDirectory "$alpha/challenge-control-a2-r3-long" -ExpectedBuild 0x20261015 -LevelCount 6 -PerformanceChallenge -QualifiedHoldSeconds 5 -Python $python *> "$alpha/challenge-control-a2-r3-long.log"
 $raw=Get-Content -LiteralPath "$alpha/challenge-control-a2-r3-long.log" -Raw
 if($raw -notmatch 'PASS real performance: best=' -or $raw -notmatch 'PASS qualified hold seconds=5' -or $raw -notmatch 'PASS real 6-tier'){throw 'Extended observer did not obtain full qualification'}
 $accepted=$true
 $raw -split '\r?\n'|Where-Object {$_ -match '^PASS real performance|^PASS qualified hold'}
} finally {
 $restoreBit=if($accepted){$candidate}else{$fallback}
 $restoreBin=if($accepted){$normal}else{$oldNormal}
 & scripts/test-game-menu-board.ps1 -Bin $restoreBin -Bit $restoreBit -LoadBit -SerialPort COM9 -OutDirectory "$out/after-long-control-menu-r1" -ExpectedBuild 0x20261015 -LevelCount 6 -Python $python *> "$out/after-long-control-menu-r1.log"
 $state=Invoke-RestMethod 'http://127.0.0.1:8765/api/status' -TimeoutSec 5
 if($state.simulated -or $state.owned -or $state.stale -or !(1024 -band $state.telemetry.raw.status_flags)){throw 'Final real MENU not fresh/released'}
 $state|ConvertTo-Json -Depth 8|Set-Content -LiteralPath "$out/after-long-control-state-r1.json" -Encoding utf8
 [ordered]@{control_qualified=$accepted;bit=$restoreBit;bin=$restoreBin;bit_sha256=(Get-FileHash -LiteralPath $restoreBit -Algorithm SHA256).Hash.ToLowerInvariant();bin_sha256=(Get-FileHash -LiteralPath $restoreBin -Algorithm SHA256).Hash.ToLowerInvariant();fresh_released_menu=$true}|ConvertTo-Json|Set-Content -LiteralPath "$out/selected-after-long-control.json" -Encoding utf8
 'PASS long-control cleanup returned to a verified normal MENU'
}
