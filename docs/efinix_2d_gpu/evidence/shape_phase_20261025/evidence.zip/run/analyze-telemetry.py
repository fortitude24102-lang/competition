"""Summarize unique, fresh, same-cohort telemetry windows; not per-frame maxima."""
import json
import statistics
from collections import defaultdict
from pathlib import Path

root = Path(__file__).resolve().parent
output = {}
for name in ("baseline-challenge-r2", "phase-challenge-r1", "baseline-challenge-a2"):
    groups = defaultdict(list)
    seen = set()
    with (root / name / "http.jsonl").open(encoding="utf-8-sig") as source:
        for line in source:
            try:
                s = json.loads(line)
            except json.JSONDecodeError:
                continue  # Reader may observe the final line while capture appends.
            p = s.get("performance")
            t = s.get("telemetry") or {}
            r = t.get("raw") or {}
            if (not p or s.get("stale") or p.get("stale") or
                    not s.get("owned") or not s.get("acknowledged") or
                    s.get("session") != p.get("session") or
                    s.get("session") != t.get("session") or
                    p.get("stage") not in (2, 3) or p.get("frames", 0) < 60):
                continue
            target = p["target"]
            if (r.get("requested_sprites") != target or r.get("visible_sprites") != target or
                    r.get("alpha_commands") != (target + 7) // 8 or
                    r.get("gpu_error_delta") or r.get("scanout_underflow_delta")):
                continue
            identity = (s["session"], t["sequence"])
            if identity in seen:
                continue
            seen.add(identity)
            groups[(target, p["stage"])].append(r)
    output[name] = [dict(target=target, stage=stage, windows=len(rows), **{
        field: round(statistics.median(row[field] for row in rows), 1)
        for field in ("pre_present_us", "command_build_us", "gpu_busy_us")
    }) for (target, stage), rows in sorted(groups.items())]
(root / "telemetry-window-summary.json").write_text(json.dumps(output, indent=2))
for name, rows in output.items():
    print(name)
    print(json.dumps([row for row in rows if row["target"] in (1024, 2048, 2615) or row["stage"] == 3]))
