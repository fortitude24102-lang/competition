"""Observe completed original-policy hold; do not invent per-frame maxima."""
import json
from pathlib import Path

root = Path(__file__).resolve().parent
rows = []
seen = set()
for line in (root / "phase-endurance-r2/http.jsonl").open(encoding="utf-8-sig"):
    s = json.loads(line)
    p = s.get("performance") or {}
    t = s.get("telemetry") or {}
    r = t.get("raw") or {}
    if (s.get("stale") or p.get("stale") or not s.get("owned") or
            not s.get("acknowledged") or p.get("stage") != 4 or
            p.get("target") != 2759 or p.get("best") != 2759 or p.get("frames") != 3600 or
            s.get("session") != p.get("session") or s.get("session") != t.get("session") or
            r.get("requested_sprites") != 2759 or r.get("visible_sprites") != 2759):
        continue
    key = (s["session"], t["sequence"])
    if key not in seen:
        seen.add(key)
        rows.append(r)
if not rows:
    raise SystemExit("No fresh qualified hold telemetry")
result = dict(target=2759, qualification_frames=3600, requested_hold_seconds=1800,
              fresh_unique_windows=len(rows),
              first_tick=rows[0]["simulation_tick"], last_tick=rows[-1]["simulation_tick"],
              observed_tick_span=(rows[-1]["simulation_tick"]-rows[0]["simulation_tick"]) & 0xffffffff,
              min_reported_window_fps_x100=min(r["gpu_full_frame_fps_x100"] for r in rows),
              max_reported_window_p95_us=max(r["p95_work_us"] for r in rows),
              max_reported_under_delta=max(r["scanout_underflow_delta"] for r in rows),
              max_reported_error_delta=max(r["gpu_error_delta"] for r in rows),
              policy="original: work<=hz/60, wall<=hz/40; initial3600 also average>=60",
              per_frame_wall_16_67ms_proven=False)
(root / "completed-endurance-summary.json").write_text(json.dumps(result, indent=2))
print(json.dumps(result, indent=2))
