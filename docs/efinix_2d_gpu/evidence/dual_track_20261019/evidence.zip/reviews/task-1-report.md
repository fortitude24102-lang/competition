# Task 1: cached Key row trimming

Scope: `CachedKeyStream.scala`, `DenseBlitEngine.scala`, `CachedKeyStreamSpec.scala`, and new `KeyRowTrimSpec.scala` only. Ponytail full applied: reuse the FIFO, RGB565 aligner, existing AXI writer, existing progress/completion interfaces, and existing test runner; no new dependency or abstraction in production.

Committed as `bdf9d22` (`Add opt-in cached Key row trimming with full pixel accounting`), exactly the four owned Scala files. Owned paths are clean after commit.

## Implementation

- `CachedKeyStream(trimTransparentRows: Boolean = false)` preserves its old default branch and exact IO layout. Eligibility remains packed, even-width, <=16x16, cache-source aligned, even destination/stride, sufficient destination stride, and non-overlapping source/destination.
- Enabled path collects the complete aligned destination row into nine data/strobe registers before offering a write request. Nine words cover 16 RGB565 pixels beginning in an upper halfword. Empty rows advance without any write. Nonempty rows issue one contiguous first-through-last nonzero-strobe span; interior zero-strobe words remain in that span.
- Offered request/data stay stable under backpressure. A source error after a request is offered does not cancel its reserved write data. Error handling waits for the writer response and drains unused source input before the single held completion.
- Enabled progress counts each internally consumed aligned word, including trimmed edge words and empty rows. `DenseBlitEngine(..., enableKeyRowTrim: Boolean = false)` forwards the option and requires Key prefetch. Its streaming-Key `copyWordDone` gate follows nonzero `wordPixelsDone`, so RenderEngine's existing counter mux counts progress even with no W transaction.

## Real RED before production edits

Command (PowerShell, repository root):

```powershell
& ./scripts/test-v3-gpu.ps1 -Suite @('gpu.KeyRowTrimSpec','gpu.CachedKeyStreamSpec') -LogPath generated/verification/v3/dual-track-20261018/key-red.log
```

The test harness originally instantiated the unchanged `new CachedKeyStream` (its test `trim` selection was intentionally not wired until the opt-in production constructor existed). It connects the real `AxiWriteEngine` and records actual AXI AW/W/B handshakes, not inferred byte counters.

Result: exit 1, 10 tests run, 8 passed and 2 intended assertion failures. Empty rows produced the old four AW spans rather than an empty request sequence. Mixed rows produced old spans `(0x02000100,5), (0x02000114,4), (0x02000124,5), (0x02000138,4)` rather than `(0x02000118,1), (0x02000128,3), (0x02000144,1)`. The default-path comparison, source/B errors, and all five original CachedKeyStream tests passed. Log: `generated/verification/v3/dual-track-20261018/key-red.log`.

## GREEN and coverage

Initial GREEN command:

```powershell
& ./scripts/test-v3-gpu.ps1 -Suite @('gpu.KeyRowTrimSpec','gpu.CachedKeyStreamSpec') -LogPath generated/verification/v3/dual-track-20261018/key-green.log
```

Result: exit 0, 12/12 tests passed (two suites), 2m16s simulation / 157s sbt total. This includes the original five CachedKeyStream regressions, six trim/A-B/error cases, and an actual DenseBlitEngine cache-load integration proving eight processed pixels with no AW/W and 16 cache-hit bytes.

Final focused rerun after strengthening the test fixture with seeded random source/AW/W pacing, source-valid hold during stalls, an explicit full-row-before-AW progress check, and a maximum opaque 16x16 case:

```powershell
& ./scripts/test-v3-gpu.ps1 -Suite @('gpu.KeyRowTrimSpec') -LogPath generated/verification/v3/dual-track-20261018/key-green-final.log
```

Final result: exit 0, 7/7 tests passed, one suite, 1m21s simulation / 97s sbt total. Final source/test revisions are covered by this run; the unchanged Dense/legacy integration cases are covered by the preceding 12/12 GREEN run.

Direct bus/statistics evidence asserted by the suites:

| Fixture | AW | W | B | Processed pixels |
| --- | ---: | ---: | ---: | ---: |
| 8x4 mixed, original default | 4 | 18 | 4 | 32 |
| Same 8x4 mixed, trim enabled | 3 | 5 | 3 | 32 |
| 8x4 all transparent, trim enabled | 0 | 0 | 0 | 32 |
| 16x16 all transparent, trim enabled | 0 | 0 | 0 | 256 |
| 16x16 opaque, trim enabled, alternating destination halfword phase | 16 | 136 | 16 | 256 |
| Dense cache-loaded 8x1 all transparent, trim enabled | 0 | 0 | 0 | 8 |

The mixed fixture has a destination starting at upper-halfword phase and a destination stride of 18 bytes (odd pixel stride), so row phases alternate. Its trimmed strobes are literally checked as `15,12,0,3,12`: the zero-strobe interior word remains. Every source pixel and the halfword sentinels before/after each row are checked against independent source fixtures. Successful direct-stream cases submit a second command without reset and hold completion before accepting it. Error cases hold real AW until the entire 8x4 source and its error signal have arrived, require the already promised write to finish, accept exactly one B, drain all 16 source words, count the first processed row, and retire one error completion.

Each runner invocation also runs the existing damage software checks; logs show `DAMAGE_SUITE,PASS,C_suites=8,golden_frames=18000,UBSan`.

## Self-review and limits

- Checked the full default branch against the original flow, all nine buffer slots, first/last same-cycle updates, halfword masks, stable offered request/data during source errors, row reset between commands, and progress-count gating.
- Owned-file `git diff --check` passes; only normal repository LF/CRLF notices occur.
- No top/Render/generator/C changes, generated RTL/release changes, new dependencies, board access, Flash, or GUI programming performed by this task.
- Parent owns final full GPU regression after all tasks, top-level option propagation, and integration. No full GPU suite was run independently here. No synthesis/resource/timing or board A/B/A measurements were performed; fewer simulated W beats are not a claim of board speedup or FPS improvement.
- Workspace `.superpowers/` and generated verification logs are ignored local artifacts. This report remains at the required path; the code commit includes only the four owned Scala files.
