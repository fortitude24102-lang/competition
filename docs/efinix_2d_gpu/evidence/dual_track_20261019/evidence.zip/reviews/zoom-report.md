# Onboard hold-to-zoom control

## Source evidence and pin choice

- `D:/ZYNQ/smallproject/Ti60F225_DemoBoard_v4/TI60F225I3-V4 DEMO板软硬件设计说明-260813-1.pdf`, PDF page 34 (printed page 33), user IO pin tables: KEY1 = GPIOR_22 / P14, KEY2 = GPIOR_21 / N14, bank BR, 3.3 V. LED0 = GPIOR_27 / P13 and LED1 = GPIOR_24 / N13.
- `D:/ZYNQ/smallproject/Ti60F225_DemoBoard_v4/01_Ti60F225_Key_led_osc_demo/01_Ti60F225_key_demo/LED_8bit_Test.peri.xml`, lines 97/100: `key_i[1]` / `key_i[2]` are input-only GPIOR_22 / GPIOR_21; lines 106/109: LED0/1 use GPIOR_27 / GPIOR_24. The shipped executable constraints agree with the newer guide.
- `D:/ZYNQ/smallproject/Ti60F225_DemoBoard_v4/Ti60F225A_V4_SCH.pdf`, PDF page 6 (sheet 5), visually inspected: KEY1 and KEY2 use R100/R101 10 kohm pullups to VCC_3V3, switches SW1/SW2 short to ground. Pressed polarity is low.
- **Source discrepancy:** that schematic's PDF page 8 (sheet 7, March 6, 2026) labels N14/P14 as LED0/LED1 and P13/N13 as KEY1/KEY2, conflicting with the guide and official key demo. Implementation follows the two agreeing sources; physical button validation is still required. Rendered pages were inspected, not inferred from extracted net order.

`efinix_2d_gpu.peri.xml` adds dedicated input-only `user_keys_n[0]` on GPIOR_22 and `[1]` on GPIOR_21, 3.3 V LVCMOS, no internal pull (board has external pullups). Existing GPIO0/1 LED pad constraints and GPIO OUT/OE connections are preserved. KEY0 reset mapping is unchanged.

`efinix_user_keys_gpio.v` uses two flip-flops on `core_clk`, asynchronously resets both stages to released (`11`) while `user_pll_locked` is low, then supplies Sapphire `{soc_gpio_IN[3:2], keys_sync_n}`. Neither GPIO OUT nor OE has a path to the new key input ports. Add only `rtl/efinix_user_keys_gpio.v` to the Efinity project source list; the testbench is simulation-only.

## C API and behavior

`zoom_control_init(zoom_control *state, uint32_t now_ms)` starts at Q8.8 scale 256 (1x). `zoom_control_update(state, pressed_mask, now_ms)` returns the current scale. Caller converts GPIO active-low lower bits using `(~gpio_input) & 3`.

- Bit 0 / KEY1 shrinks; bit 1 / KEY2 grows; zero or both freeze. Other bits are ignored.
- Every raw mask transition pauses movement immediately and must remain stable for 20 ms before a direction starts. A bounced release/re-press must earn the full interval again.
- Steady hold changes scale by 128 Q8.8 units per second (0.5x/s), keeping the sub-unit remainder across polls. Clamp 64..1024 (0.25x..4x). A direction change or neutral period clears the old remainder; outward saturation clears accumulated excess.
- Poll regularly. Each stable-direction update counts at most 250 ms and consumes the timestamp, so a stalled application cannot queue a large later jump. New-direction debounce completion does not retroactively count the unobserved interval.
- Unsigned timestamp subtraction supports millisecond wrap. No dynamic allocation, busy wait, hardware dependency, or float.

## Verification

TDD RED: C test ran against a zero-scale/no-motion stub and failed all 21 expected-value checks. Later release/re-press debounce test failed three checks against the initial implementation, then passed after requiring the full candidate stability interval. RTL test ran against a combinational pass-through stub and failed five checks (reset and missing two-cycle delay), then passed with the synchronizer.

GREEN commands from the worktree root:

```powershell
wsl gcc -std=c11 -O2 -Wall -Wextra -Werror '-fsanitize=address,undefined' -fno-omit-frame-pointer -Isw/efinix_gpu/include sw/efinix_gpu/tests/test_zoom_control.c sw/efinix_gpu/src/zoom_control.c -o tmp/test_zoom_control
wsl ./tmp/test_zoom_control
& 'D:/efinity/risc_v_gcc/toolchain/bin/riscv-none-elf-gcc.exe' -std=c11 -Os -Wall -Wextra -Werror -march=rv32im_zicsr -mabi=ilp32 -ffreestanding -Isw/efinix_gpu/include -c sw/efinix_gpu/src/zoom_control.c -o tmp/zoom_control.rv32.o
iverilog -g2012 -s tb_efinix_user_keys_gpio -o tmp/test_user_keys.vvp board/efinix_ti60/rtl/efinix_user_keys_gpio.v board/efinix_ti60/rtl/tb_efinix_user_keys_gpio.v
vvp tmp/test_user_keys.vvp
```

All commands above passed. C covers initial value, short/bounced press, duration rate, fractional accumulation, release freeze, both-key cancellation, both clamps, reversing from saturation, direction remainder clearing, release/re-press debounce, bounded stall and fresh recovery, unrelated bits, and timestamp wrap. RTL covers released reset value, two-stage delay, active-low preservation, asynchronous input isolation and upper GPIO preservation. XML parsed successfully and has no duplicate `gpio_def` assignments. Board-top syntax parsed with `iverilog -g2012 -i -s board_top -I board/efinix_ti60/vendor/sapphire_ddr3/rtl` plus board_top and the new module (the `-i` check deliberately does not elaborate unavailable external modules). Native MinGW GCC was incomplete (`CreateProcess` failure); WSL GCC is the existing project host-test route.

The existing `scripts/test-efinix-verilog.ps1 -IcarusHome C:/iverilog -EvidenceDirectory tmp/zoom-rtl-regression` broader offline regression was also launched. Its module-structure check and RGB565, HDMI adapter, pixel pipe, vblank CDC, underflow CDC and scale2x simulations passed. The longer unchanged HDMI subsystem simulation was stopped by this agent after approximately five minutes without new output, after confirming the spawned process command line. The wrapper reported `Icarus simulation failed for hdmi-subsystem (exit -1)` because of that deliberate stop. HDMI subsystem and following warm-reset simulation remain unverified in this run; this is not a full-suite pass. The simulation emitted the existing vendor FIFO warning about anachronistic begin/end around generate schemes.

No synthesis, PnR, board execution, programming, or network operation was performed. Tests establish software and RTL behavior, not physical switch identity or electrical validation.

## Standalone zoom demo follow-on, 2026-10-19

Added `sw/efinix_gpu/tests/test_board_zoom.c` and `Test zoom` in `scripts/build-board-hud-dma-test.ps1`. Existing parent-authored `Test transform` support is preserved in this script handoff. Zoom links `zoom_control.c` only for this standalone target; no normal game/performance entry or CPU renderer changes. The zoom default output appends a GUID, and explicit output directories retain the existing refusal to overwrite.

The dedicated firmware initializes local bullet artwork and the existing glyph atlas. It disables GPIO output enables, polls inverted GPIO bits 0/1 continuously between render calls, and redraws only when `scale_q8_8 / 16` changes (4..64 pixels). It copies the full local background with GPU Copy, clears the 72-pixel HUD via GPU Fill, copies the existing glyph cells for instructions and size, then uses `gpu_transform_blit_async` with source16x16, source stride32, arbitrary square output dimensions and color key0xf81f for the centered airplane at `BULLET_LOCAL_ATLAS+BULLET_PLAYER_OFFSET`. Each full frame completes before `framebuffer_present`; first PRESENT follows a complete rendered frame. This first-scanout guarantee assumes a reset candidate FPGA design, rather than an already-running old scanout engine.

HUD scale is the actual output-side/16 ratio (rounded to two decimals), which remains correct while hidden fractional controller scale accumulates. UART logs the raw controller Q8.8 value and visible side, first frame then at most one frame event per250ms using the post-PRESENT timestamp. Startup and terminal error logs are bounded one-offs. Blocking GPU retirement/PRESENT can defer GPIO sampling for a render interval; the controller's existing250ms stall cap bounds a large delayed jump.

The small shared atlas-text command builder was host-tested in the same file using `ZOOM_HOST_TEST`. RED against a zero-command stub failed the expected seven-glyph assertion. GREEN under AddressSanitizer and UndefinedBehaviorSanitizer checks exact atlas addresses for alphabet/digits/punctuation/space, framebuffer row/column addresses, strides, dimensions,64-column bounds, empty text and unsupported-character fallback. The build script automatically runs this test for `Test zoom`. The existing zoom-controller sanitizer test also passed again on October19.

Build results, all exit0 using final arbitrary-dimension GPU API:

- Explicit final zoom: `generated/verification/v3/dual-track-20261018/board-zoom-final-20261019-7b3f70fa0b9840ebb73e6868ec72ffc8/test.elf` and `test.bin`; log `tmp/zoom-build-final-20261019.log`. Binary SHA256 `4d495a0f5eb74fccb63fd58968a691c4f8b3cdc98d4ae082f0b56be769fd8f46`. ELF text61296/data4968/BSS6784 bytes.
- Preserved transform target with explicit unique output: `generated/verification/v3/dual-track-20261018/board-transform-20261019-c0a19751d7134c50ae14f8d31ca77c6b/test.elf` and `test.bin`; log `tmp/zoom-transform-build-20261019.log`.
- Default fresh zoom path was exercised successfully: `generated/verification/v3/dual-track-20261018/board-zoom-ae3c2cbe36aa4d76b8903ab2cdc5c6f1/`; log `tmp/zoom-build-default-20261019.log` (this precedes the final UART-timestamp refinement, so use the explicit final binary above).

Commands: `./scripts/build-board-hud-dma-test.ps1 -Test zoom -OutDirectory <fresh path>` and `-Test transform -OutDirectory <fresh path>`; default generation was checked with `-Test zoom` alone. Both firmware targets emitted the existing linker warning about a LOAD segment with RWX permissions. No compile/stack warnings, sanitizer findings, hardware programming, Scala invocation or new broad HDL run occurred in this follow-on. Physical button behavior and screen output remain for parent-led board validation.
