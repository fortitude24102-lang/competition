from pathlib import Path
import json,re,hashlib,zipfile,subprocess,posixpath,shutil
root=Path.cwd();base=root/'generated/verification/v3/split-compare-20261027'
raw=(base/'board-web-final-r1-uart.log').read_text(encoding='utf-8-sig')
rows=[]
for line in re.findall(r'(?m)^SPLIT_COMPARE_RESULT,([^\r\n]+)',raw):
 r={k:int(v) if v.isdigit() else v for k,v in (p.split('=',1) for p in line.split(','))};rows.append(r)
assert [r['target'] for r in rows]==[256,512]
hashfile=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
fw=base/'normal-web-final-r1/gpu_demo.bin';bit=Path('D:/efinity_builds/key_row_handoff_20261026_r1/outflow/efinix_2d_gpu.bit')
p=root/'sw/efinix_gpu/tools/control_gateway/web/benchmarks.json';data=json.loads(p.read_text(encoding='utf-8'))
data['final_release']={'recorded_on':'2026-10-27','firmware_build_id':'0x20261027','viewport':'480x270 per renderer','window_ms':15000,'scope':'independent cooperative displayed-frame FPS; not isolated renderer throughput','bit_sha256':hashfile(bit),'firmware_sha256':hashfile(fw),'evidence':'docs/efinix_2d_gpu/evidence/split_comparison_20261027/','rows':rows,'errors':0,'underflows':0}
p.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
p=root/'README.md';old=p.read_text(encoding='utf-8')
history=root/'docs/efinix_2d_gpu/README.history.md';assert not history.exists()
def relocate(m):
 target=m.group(2)
 if ':' in target or target.startswith(('#','/')):return m.group(0)
 return m.group(1)+posixpath.relpath(target,'docs/efinix_2d_gpu')+m.group(3)
history.write_text('> 历史开发记录，保存至 2026-10-23。当前交付与操作请以[最终版 README](../../README.md)为准。下文“当前”“下一步”“未推送”均指对应历史日期。\n\n'+re.sub(r'(\]\()([^\)]+)(\))',relocate,old),encoding='utf-8')
names=['a_days14_15_acceptance.md','a_days16_17_acceptance.md','a_days18_19_acceptance.md','a_days6_8_pixel_acceptance.md','a_final_three_day_acceptance.md','b_days16_20_acceptance.md','bullet_demo_plan.md','days1_8_acceptance.md','game_menu_plan_20261008.md','lead_acceptance.md','lead_day18_acceptance.md','lead_days16_17_acceptance.md','official_demo_inventory_local.md','software_acceptance.md','v3_ab_execution_20261005.md']
archive_dir=root/'docs/efinix_2d_gpu/archive';archive_dir.mkdir(exist_ok=True)
archive=archive_dir/'superseded-stage-reports-20261027.zip';assert not archive.exists()
files=[root/'docs/efinix_2d_gpu'/n for n in names]
manifest={p.name:hashfile(p) for p in files}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p in files:z.write(p,p.name)
 z.writestr('SHA256SUMS.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for p in files:assert hashlib.sha256(z.read(p.name)).hexdigest()==manifest[p.name]
for p in files:
 assert p.resolve().parent==(root/'docs/efinix_2d_gpu').resolve();p.unlink()
(archive_dir/'README.md').write_text('# 历史阶段报告归档\n\n`superseded-stage-reports-20261027.zip` 保存 15 份已被后续版本取代、清理时无外部文件名引用的计划/验收报告。散落副本已删除，原文与逐文件 SHA256 保留在 ZIP 内；历史失败证据和实际板测数据未删除。\n\nZIP SHA256：`'+hashfile(archive)+'`。\n\n当前操作与成绩见[最终版 README](../../../README.md)。\n',encoding='utf-8')
release=root/'release/final-20261027';assert not release.exists();release.mkdir()
for src,name in [(bit,'efinix_2d_gpu.bit'),(fw,'gpu_demo.bin'),(fw.with_suffix('.hex'),'gpu_demo.hex')]:shutil.copy2(src,release/name)
(release/'SHA256SUMS.txt').write_text(''.join(hashfile(p)+'  '+p.name+'\n' for p in sorted(release.iterdir())),encoding='utf-8')
(release/'README.md').write_text('# 2026-10-27 最终演示文件\n\n本目录为新增交付包，既有 V1/V2 release 未覆盖。BIT：Ti60F225 官方 Sapphire/DDR/HDMI 基础上的二维 GPU，提交 `0c47970` 的行交接候选；BIN/HEX：六档游戏与独立 15 秒 CPU/GPU 同屏展示。\n\n板 IP 192.168.1.3，PC 192.168.1.2；管理 UDP8090，资源 UDP8080，网页 http://127.0.0.1:8765/#game 。只用 JTAG 加载 BIT 与 RAM 固件；未写 Flash。不要把原生六档游戏与 480×270 同屏展示成绩混算。\n\n身份见 `SHA256SUMS.txt`；构建、实测和限制见[根 README](../../README.md)与[同屏证据](../../docs/efinix_2d_gpu/evidence/split_comparison_20261027/README.md)。\n',encoding='utf-8')
print(json.dumps({'rows':rows,'bit':hashfile(bit),'bin':hashfile(fw),'reports_archived':len(files)},ensure_ascii=True))
