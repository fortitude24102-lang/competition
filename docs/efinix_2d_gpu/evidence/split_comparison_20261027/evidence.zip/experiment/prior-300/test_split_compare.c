#include "split_compare.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>
static uint64_t clock_ticks;
static unsigned cpu_calls,gpu_calls,scaled,presents;
static gpu_command pair[BULLET_MAX_COMMANDS];
static unsigned pair_count;
static int fail_cpu,fail_gpu;
static unsigned serviced;
static int service(void *context){serviced++;return context?1:0;}
uint64_t gpu_platform_cycles(void){return clock_ticks;}
void gpu_platform_sync(void){}
int game_reset(bullet_state *s,unsigned n,uint32_t seed){memset(s,0,sizeof *s);s->count=n;s->seed=seed;return 0;}
int game_update(bullet_state *s,const game_input *in){assert(!in->held);s->tick++;return 0;}
int game_build(const bullet_state *s,uint32_t dst,int network,int glow,unsigned cap,bullet_stream *out){
 assert(network==1 && glow==1 && cap==BULLET_MAX_COMMANDS);out->count=2;out->visible=s->count;
 out->commands[0]=(gpu_command){.op=GPU_OP_COPY,.src_addr=BULLET_BACKGROUND_ADDR,.dst_addr=dst,.dst_stride=GPU_FRAME_STRIDE,.width_pixels=960,.height_pixels=540};
 out->commands[1]=(gpu_command){.op=GPU_OP_COLOR_KEY,.src_addr=BULLET_ATLAS_ADDR,.dst_addr=dst+144002,.dst_stride=GPU_FRAME_STRIDE,.width_pixels=8,.height_pixels=8};
 memcpy(pair,out->commands,2*sizeof *pair);pair_count=2;return 0;
}
int perf_render_cpu_surface(const gpu_command *c,unsigned n,uint32_t base){
 assert(base==SPLIT_CPU_SURFACE && n==1 && c->height_pixels<=32);
 cpu_calls++;clock_ticks+=c->height_pixels*100;return fail_cpu?GPU_DRIVER_ARGUMENT:0;
}
int perf_render_gpu(gpu_device *d,const gpu_command *c,unsigned n,uint32_t polls){
 (void)d;assert(polls);if(c[0].dst_addr==SPLIT_GPU_SURFACE){assert(n==pair_count);for(unsigned i=0;i<n;i++){gpu_command expected=pair[i];expected.dst_addr+=SPLIT_GPU_SURFACE-GPU_FRAMEBUFFER_A;assert(!memcmp(&expected,c+i,sizeof expected));}gpu_calls++;clock_ticks+=1000;if(fail_gpu)return GPU_DRIVER_TIMEOUT;}return 0;
}
int gpu_transform_blit_async(gpu_device *d,uint32_t src,uint32_t dst,uint32_t ss,uint32_t ds,uint16_t sw,uint16_t sh,uint16_t w,uint16_t h,uint16_t flags,uint16_t key,uint16_t *tag){
 (void)d;unsigned side=src>=SPLIT_GPU_SURFACE;uint32_t base=side?SPLIT_GPU_SURFACE:SPLIT_CPU_SURFACE;
 unsigned y=(src-base)/(2*1920);assert(y<270 && !(y%32));
 assert(dst==GPU_FRAMEBUFFER_B+(144+y)*1920+side*960);
 assert(ss==1920 && ds==1920 && sw==960 && sh==h*2 && w==480 && h<=32 && y+h<=270 && !flags && !key);*tag=1;scaled++;return 0;
}
int gpu_wait_tag(gpu_device *d,uint16_t tag,uint32_t polls){(void)d;assert(tag && polls);return 0;}
int framebuffer_present(gpu_device *d,framebuffer_pair *b,uint32_t polls){(void)d;(void)b;assert(polls);presents++;return 0;}
static split_compare_state state;static bullet_stream stream;static hud_command_stream scratch;
int main(void){
 gpu_device gpu={.ready=1};framebuffer_pair fb={GPU_FRAMEBUFFER_A,GPU_FRAMEBUFFER_B};
 assert(split_compare_init(&state)==0);
 for(unsigned i=0;i<600;i++){assert(split_compare_step(&state,&gpu,&fb,1,&stream,&scratch,1000000,100,service,NULL)==0);if(i==299){assert(state.frames[0]==300 && state.frames[1]==0 && !state.done);}}
 assert(state.done && state.frames[0]==300 && state.frames[1]==300);
 assert(cpu_calls==10800 && gpu_calls==600 && scaled==10800 && presents==600 && serviced==23400);
 assert(state.cpu_ticks[0]==16440000 && state.gpu_ticks[0]==300000);
 assert(split_compare_step(&state,&gpu,&fb,1,&stream,&scratch,1000000,100,service,NULL)==0);
 assert(cpu_calls==10800 && presents==600);assert(split_compare_init(&state)==0 && !state.done && !state.frames[0]);
 fail_cpu=1;assert(split_compare_step(&state,&gpu,&fb,1,&stream,&scratch,1000000,100,service,NULL)==GPU_DRIVER_ARGUMENT);
 assert(!state.frames[0] && !state.cpu_ticks[0] && presents==600);fail_cpu=0;
 fail_gpu=1;assert(split_compare_step(&state,&gpu,&fb,1,&stream,&scratch,1000000,100,service,NULL)==GPU_DRIVER_TIMEOUT);
 assert(!state.frames[0] && !state.gpu_ticks[0] && presents==600);fail_gpu=0;
 assert(split_compare_step(&state,&gpu,&fb,1,&stream,&scratch,1000000,100,service,&state)==1);
 assert(!state.frames[0] && presents==600);
 puts("PASS split comparison: identical native commands,2x300 pairs,half-size views,render-only timing,no extra completed frame");return 0;
}
