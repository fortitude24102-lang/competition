#ifndef SPLIT_COMPARE_H
#define SPLIT_COMPARE_H
#include "interactive_game.h"
#include "framebuffer.h"
#include "hud.h"
#define SPLIT_CPU_SURFACE 0x03000000u
#define SPLIT_GPU_SURFACE 0x03200000u
#define SPLIT_STATE_ADDRESS 0x03400000u
#define SPLIT_COMPARE_FRAMES 300u
typedef struct {
 bullet_state game;
 uint64_t cpu_ticks[2],gpu_ticks[2];
 unsigned frames[2],tier;
 uint8_t done;
} split_compare_state;
_Static_assert(SPLIT_CPU_SURFACE+GPU_FRAME_BYTES<=SPLIT_GPU_SURFACE,"split surfaces overlap");
_Static_assert(SPLIT_GPU_SURFACE+GPU_FRAME_BYTES<=SPLIT_STATE_ADDRESS,"split state overlap");
_Static_assert(SPLIT_STATE_ADDRESS+sizeof(split_compare_state)<=GPU_DDR_END_EXCLUSIVE,"split DDR bound");
int split_compare_init(split_compare_state *);
/* Native renders run sequentially, with synchronized half-size presentation.
 * Timing excludes composition/PRESENT; it is not independent display FPS. */
int split_compare_step(split_compare_state *,gpu_device *,framebuffer_pair *,int network,
 bullet_stream *,hud_command_stream *,uint32_t hz,uint32_t polls,int (*service)(void *),void *context);
#endif
