#include "split_compare.h"
#include "perf_demo.h"
#include "benchmark.h"
#include <string.h>
static const unsigned targets[2]={256,512};
/* Same small integer-only formatting pattern as the existing HUD; full
 * newlib snprintf pulls floating-point/locale code beyond Sapphire RAM. */
static char *label(char *p,const char *s){while(*s)*p++=*s++;*p=0;return p;}
static char *number(char *p,uint32_t value) {
 char reverse[10];unsigned n=0;do{reverse[n++]=(char)('0'+value%10u);value/=10u;}while(value);
 while(n)*p++=reverse[--n];
 *p=0;return p;
}
static char *decimal(char *p,uint32_t tenths){p=number(p,tenths/10u);p=label(p,".");return number(p,tenths%10u);}
int split_compare_init(split_compare_state *s) {
 if(!s)return GPU_DRIVER_ARGUMENT;
 memset(s,0,sizeof *s);return game_reset(&s->game,targets[0],7);
}
static void text(hud_command_stream *s,uint32_t dst,unsigned x,unsigned y,const char *line,int green) {
 for(unsigned i=0;line[i] && i<32;i++) {
  const char *g=strchr(HUD_GLYPH_CHARACTERS,line[i]);unsigned index=g?(unsigned)(g-HUD_GLYPH_CHARACTERS):38;
  s->commands[s->count++]=(gpu_command){.op=GPU_OP_COPY,
   .src_addr=HUD_GLYPH_ATLAS_ADDR+(green?HUD_GLYPH_BANK_BYTES:0)+index*HUD_GLYPH_CELL_BYTES,
   .dst_addr=dst+y*GPU_FRAME_STRIDE+(x+i*HUD_GLYPH_WIDTH)*2u,
   .src_stride=HUD_GLYPH_WIDTH*2,.dst_stride=GPU_FRAME_STRIDE,
   .width_pixels=HUD_GLYPH_WIDTH,.height_pixels=HUD_GLYPH_HEIGHT};
 }
}
static void metric(hud_command_stream *s,uint32_t dst,unsigned x,unsigned y,
 uint64_t ticks,unsigned frames,uint32_t hz) {
 char line[48];
 uint32_t time=frames?(uint32_t)(ticks*1000000u/((uint64_t)frames*hz)):0;
 uint32_t fps=ticks?(uint32_t)((uint64_t)frames*hz*10u/ticks):0;
 char *p=label(line,"RENDER ");p=decimal(p,time/100u);p=label(p," MS - ");p=decimal(p,fps);label(p," FPS");
 text(s,dst,x,y,line,0);
}
int split_compare_step(split_compare_state *s,gpu_device *gpu,framebuffer_pair *fb,int network,
 bullet_stream *scene,hud_command_stream *scratch,uint32_t hz,uint32_t polls,int (*service)(void *),void *context) {
 if(!s || !gpu || !fb || !scene || !scratch || !hz || !polls ||
    s->tier>1 || (network!=0 && network!=1))return GPU_DRIVER_ARGUMENT;
 if(s->done)return 0;
 if(!s->tier && s->frames[0]==SPLIT_COMPARE_FRAMES) {
  int e=game_reset(&s->game,targets[1],7);if(e)return e;s->tier=1;
 }
 unsigned tier=s->tier,n=s->frames[tier]+1;
 if(n>SPLIT_COMPARE_FRAMES)return GPU_DRIVER_ARGUMENT;
 game_input neutral={0};int e=game_update(&s->game,&neutral);if(e<0)return e;
 e=game_build(&s->game,GPU_FRAMEBUFFER_A,network,1,BULLET_MAX_COMMANDS,scene);if(e)return e;
 for(unsigned i=0;i<scene->count;i++)scene->commands[i].dst_addr+=SPLIT_CPU_SURFACE-GPU_FRAMEBUFFER_A;
 gpu_platform_sync();uint64_t start=gpu_platform_cycles();
 /* Bound control latency even for the full background. Pixel loops and
  * ordering remain the original golden rasterizer; service time is measured. */
 for(unsigned i=0;i<scene->count;i++) {
  const gpu_command *c=scene->commands+i;
  for(unsigned y=0;y<c->height_pixels;y+=32) {
   gpu_command part=*c;part.dst_addr+=y*c->dst_stride;part.src_addr+=y*c->src_stride;
   part.height_pixels=(uint16_t)(c->height_pixels-y>32?32:c->height_pixels-y);
   e=perf_render_cpu_surface(&part,1,SPLIT_CPU_SURFACE);if(e)return e;
   if(service && (e=service(context)))return e;
  }
 }
 gpu_platform_sync();uint64_t cpu=gpu_platform_cycles()-start;if(e)return e;
 for(unsigned i=0;i<scene->count;i++)scene->commands[i].dst_addr+=SPLIT_GPU_SURFACE-SPLIT_CPU_SURFACE;
 gpu_platform_sync();start=gpu_platform_cycles();
 e=perf_render_gpu(gpu,scene->commands,scene->count,polls);
 if(!e && service)e=service(context);
 gpu_platform_sync();uint64_t hardware=gpu_platform_cycles()-start;if(e)return e;
 scratch->count=1;scratch->commands[0]=(gpu_command){.op=GPU_OP_FILL,.dst_addr=fb->back,
  .dst_stride=GPU_FRAME_STRIDE,.width_pixels=GPU_FRAME_WIDTH,.height_pixels=GPU_FRAME_HEIGHT};
 e=perf_render_gpu(gpu,scratch->commands,1,polls);if(e)return e;
 if(service && (e=service(context)))return e;
 uint16_t tag=0;
 /* Exact2:1 sampling permits independent horizontal bands. Retire each
  * band and service control instead of blocking for both whole views. */
 for(unsigned side=0;side<2;side++)for(unsigned y=0;y<270;y+=32) {
  unsigned h=270-y>32?32:270-y;
  e=gpu_transform_blit_async(gpu,(side?SPLIT_GPU_SURFACE:SPLIT_CPU_SURFACE)+y*2u*GPU_FRAME_STRIDE,
   fb->back+(144u+y)*GPU_FRAME_STRIDE+side*960u,GPU_FRAME_STRIDE,GPU_FRAME_STRIDE,
   960,(uint16_t)(h*2u),480,(uint16_t)h,0,0,&tag);if(e)return e;
  e=gpu_wait_tag(gpu,tag,polls);if(e)return e;
  if(service && (e=service(context)))return e;
 }
 scratch->count=0;char line[48];
 text(scratch,fb->back,28,16,"CPU VS GPU - SAME FRAME",1);
 char *p=number(line,targets[tier]);p=label(p," SPRITES - ");p=number(p,n);label(p," OF 300");text(scratch,fb->back,28,44,line,0);
 text(scratch,fb->back,28,78,"CPU - SOFTWARE",0);text(scratch,fb->back,508,78,"GPU - HARDWARE",1);
 metric(scratch,fb->back,28,108,s->cpu_ticks[tier]+cpu,n,hz);
 metric(scratch,fb->back,508,108,s->gpu_ticks[tier]+hardware,n,hz);
 text(scratch,fb->back,28,430,"NATIVE 960X540 - VIEW 480X270",1);
 for(unsigned row=0;row<2;row++) {
  unsigned f=row==tier?n:s->frames[row];if(!f)continue;
  uint64_t ct=s->cpu_ticks[row]+(row==tier?cpu:0),gt=s->gpu_ticks[row]+(row==tier?hardware:0);
  p=number(line,targets[row]);p=label(p," - ");p=number(p,f);label(p," FRAMES");text(scratch,fb->back,28,458+row*36,line,1);
  uint32_t cu=(uint32_t)(ct*1000000u/((uint64_t)f*hz)),gu=(uint32_t)(gt*1000000u/((uint64_t)f*hz));
  p=label(line,"CPU ");p=decimal(p,cu/100u);p=label(p," MS GPU ");p=decimal(p,gu/100u);label(p," MS");
  text(scratch,fb->back,312,458+row*36,line,0);
 }
 text(scratch,fb->back,28,522,tier==1 && n==300?"DONE - WEB MENU TO EXIT":"SYNC DISPLAY - RENDER COST ONLY",0);
 e=perf_render_gpu(gpu,scratch->commands,scratch->count,polls);if(e)return e;
 if(service && (e=service(context)))return e;
 gpu_platform_sync();e=framebuffer_present(gpu,fb,polls);if(e)return e;
 s->cpu_ticks[tier]+=cpu;s->gpu_ticks[tier]+=hardware;s->frames[tier]=n;
 s->done=(uint8_t)(tier==1 && n==SPLIT_COMPARE_FRAMES);return 0;
}
