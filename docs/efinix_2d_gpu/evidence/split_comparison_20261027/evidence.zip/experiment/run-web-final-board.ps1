$ErrorActionPreference='Stop'
$base='generated/verification/v3/split-compare-20261027'
$out=Join-Path $base 'board-web-final-r1'
$env:NODE_PATH='C:/Users/fortiutde/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules'
$serial=New-Object IO.Ports.SerialPort 'COM9',115200,'None',8,'One'
$serial.Open()
try {
 $child=Start-Process -FilePath 'E:/node.exe' -ArgumentList @('scripts/test-split-comparison-board.js',$out) -WindowStyle Hidden -PassThru -RedirectStandardOutput "$base/board-web-final-r1.stdout.log" -RedirectStandardError "$base/board-web-final-r1.stderr.log"
 while(!$child.HasExited){$chunk=$serial.ReadExisting();if($chunk){[IO.File]::AppendAllText("$base/board-web-final-r1-uart.log",$chunk)};Start-Sleep -Milliseconds 30}
 $chunk=$serial.ReadExisting();if($chunk){[IO.File]::AppendAllText("$base/board-web-final-r1-uart.log",$chunk)}
 $child.WaitForExit();$code=$child.ExitCode
 Get-Content "$base/board-web-final-r1.stdout.log" -Tail 5
 Get-Content "$base/board-web-final-r1.stderr.log" -Tail 12
 if($code -ne 0){throw "Browser board verification failed: $code"}
} finally {$serial.Close();$serial.Dispose()}
