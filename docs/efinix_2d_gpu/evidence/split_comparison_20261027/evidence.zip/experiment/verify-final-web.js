const assert=require('node:assert/strict');
const {chromium}=require('playwright');
(async()=>{
 const browser=await chromium.launch({headless:true,executablePath:'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe'});
 try {
  const page=await browser.newPage({viewport:{width:1280,height:1100}}),errors=[];
  page.on('pageerror',e=>errors.push(e.message));
  await page.goto('http://127.0.0.1:8765/');
  await page.waitForFunction(()=>document.querySelectorAll('#release-scores tr').length===2);
  await page.waitForFunction(()=>document.querySelector('#banner').classList.contains('healthy') && !document.querySelector('#level-1').disabled);
  assert.match(await page.locator('#release-scores').innerText(),/4.60\s+60.06/);
  assert.match(await page.locator('#release-scores').innerText(),/2.33\s+60.06/);
  assert.equal(await page.locator('#difficulty-options button').count(),6);
  assert.equal(await page.locator('#game #split-start').count(),1);
  assert.equal(await page.locator('#comparison').isVisible(),false);
  const main='generated/verification/v3/split-compare-20261027/';
  await page.screenshot({path:main+'web-final-desktop.png',fullPage:true});
  await page.setViewportSize({width:390,height:844});
  assert(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),'Mobile page overflows');
  await page.screenshot({path:main+'web-final-mobile.png',fullPage:true});
  assert.deepEqual(errors,[]);
  const state=await(await fetch('http://127.0.0.1:8765/api/status')).json();
  assert(!state.simulated && !state.stale && !state.owned && state.telemetry.raw.status_flags&1024);
  console.log('PASS final archive data, original six buttons, separate entry, collapsed history, mobile width, fresh released MENU');
 }finally{await browser.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});
