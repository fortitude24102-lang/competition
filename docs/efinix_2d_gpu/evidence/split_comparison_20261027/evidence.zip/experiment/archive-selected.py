import hashlib,json,re,subprocess,urllib.request,zipfile
from pathlib import Path
root=Path.cwd();src=root/'generated/verification/v3/split-compare-20261027'
dst=root/'docs/efinix_2d_gpu/evidence/split_comparison_20261027';dst.mkdir(parents=True,exist_ok=True)
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
protected=json.loads((root/'generated/verification/v3/wide-copy-fair-20261024/preexisting-file-hashes.json').read_text(encoding='utf-8-sig'))
for f in protected:
 if Path(f['Path']).resolve()!=root/'README.md':assert digest(Path(f['Path']))==f['Hash'].lower()
result=json.loads((src/'board-web-final-r1/result.json').read_text(encoding='utf-8-sig'))
assert result['passed'] and result['original_six_games_after_display']
raw=(src/'board-web-final-r1-uart.log').read_text(encoding='utf-8-sig')
rows=[]
for line in re.findall(r'(?m)^SPLIT_COMPARE_RESULT,([^\r\n]+)',raw):
 row={}
 for part in line.split(','):
  k,v=part.split('=',1);row[k]=int(v) if v.isdigit() else v
 rows.append(row)
assert [r['target'] for r in rows]==[256,512]
for r in rows:
 assert r['window_ms']==15000 and r['gpu_frames']>300 and r['cpu_frames']>0 and r['gpu_fps_x100']>=5990 and r['cache_bytes']>0
 assert r['cpu_fps_x100']==r['cpu_frames']*100//15 and r['gpu_fps_x100']==r['gpu_frames']*100//15
assert 'SPLIT_FAILURE' not in raw and 'V3_FAIL' not in raw
state=json.load(urllib.request.urlopen('http://127.0.0.1:8765/api/status',timeout=3))
assert not state['simulated'] and not state['stale'] and not state['owned'] and state['telemetry']['raw']['status_flags']&1024
assert state['telemetry']['raw']['gpu_error_delta']==state['telemetry']['raw']['scanout_underflow_delta']==0
(src/'final-menu-state.json').write_text(json.dumps(state,indent=2))
fw=src/'normal-web-final-r1/gpu_demo.bin';bit=Path('D:/efinity_builds/key_row_handoff_20261026_r1/outflow/efinix_2d_gpu.bit')
assert digest(bit)=='c9c55d8a022e9fa226aa6168185743af67c1a83470bc7f1709c89bbd1f09e94f'
changed=subprocess.check_output(['git','diff','--name-only'],text=True).splitlines()
owned=[p for p in changed if p.startswith(('sw/efinix_gpu/','scripts/'))]
owned+=['sw/efinix_gpu/'+p for p in ('include/split_compare.h','include/split_view.h','src/split_compare.c','src/split_view.c','tests/test_split_timed.c','tests/test_split_view.c','tests/test_completion_progress.c','tests/test_game_clock_cached.c')]
owned+=['scripts/test-split-comparison-board.js','docs/superpowers/plans/2026-10-27-split-comparison.md']
owned=sorted(set(owned));assert all((root/p).is_file() for p in owned)
plan=root/'docs/superpowers/plans/2026-10-27-split-comparison.md'
plan.write_text(plan.read_text(encoding='utf-8').replace('- [ ] Final selected firmware:','- [x] Final selected firmware:'),encoding='utf-8')
(src/'owned-source-paths.json').write_text(json.dumps(owned,indent=2))
manifest={p:digest(root/p) for p in owned};(src/'selected-source-hashes.json').write_text(json.dumps(manifest,indent=2))
summary=dict(firmware_sha256=digest(fw),bit_sha256=digest(bit),firmware_path=str(fw),bit_path=str(bit),window_ms=15000,viewport='480x270 per renderer',scope='independent cooperative displayed-frame FPS; not isolated renderer throughput',rows=rows,cancel_ms=result['cancel_ms'],original_six_games_after_display=True,health_errors=0,underflows=0,final_fresh_released_menu=True,protected_user_files_unchanged=len(protected)-1,root_readme_update='user-authorized; original content preserved in README.history.md',further_hardware_optimization='stopped',source_files=len(owned))
(dst/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
table='\n'.join('|{target}|{cpu_frames}|{gpu_frames}|{cpu}|{gpu}|'.format(**r,cpu=f"{r['cpu_fps_x100']/100:.2f}",gpu=f"{r['gpu_fps_x100']/100:.2f}") for r in rows)
readme=f'''# Independent CPU/GPU exhibition — final selected firmware

Final web telemetry now reports mode-scoped raw viewport FPS with native validity bits clear. The256 terminal score is held300ms outside timing; native960x540 cards/charts remain separate. Freshness/simulated checks hide live values, completed windows hide live cards, and MENU/disconnect clears cross-run identity before accepting another run. Final recorded data is in benchmarks.json; old optimization history is collapsed.

Open http://127.0.0.1:8765/#game and select the separate CPU/GPU exhibition in difficulty selection. The HDMI menu adds a separate card below the six original game tiers; move the stick down to it and press MID. CPU is left, GPU right. Each tier runs15seconds, then retains both scores; web MENU exits. No300-frame cap remains. The six original games and gameplay C replay remain separate.

|Target|New CPU images|GPU scene PRESENTs|CPU reported FPS|GPU reported FPS|
|---|---:|---:|---:|---:|
{table}

Both use the same exact480x270 scene/assets. Counts describe this single-core cooperative same-screen workload, including GPU command-driving cost; they are not isolated renderer throughput. Count only new CPU images actually presented and GPU scene PRESENTs observed within the15-second window. A boundary observation may conservatively omit one frame. Static UI setup/final-score PRESENTs are excluded; no animated frame or complete CPU render is prepared before timing.

Real browser entry and cancellation passed ({result['cancel_ms']}ms). Both windows had zero new underflow/hardware error. All six original games were started after exhibition/native-cache restoration, reached their normal reported cadence, and returned to a fresh released MENU. No new endurance or hardware-limit claim. HDMI photography was not captured; pixel/geometry/ownership tests and real PRESENT/UART records provide the stated evidence.

The slow initial exhibition used uncached mini-assets, a legacy full-command builder/conversion and full HUD redraws. Final code packs four source phases into the existing3104-byte texture cache, reuses the normal compact builder/cached logical clock, copies left only on CPU-generation changes and changes only dirty glyph cells. Original CPU pixel loops remain. Cache restores to the native atlas before any original game render. Fast cached commands also exposed a driver false TAG failure from requiring repeated identical DONE samples; atomic DONE followed by sticky ERROR now retains real-error/wrap/future-tag checks.

Verification: native full-frame/nearest oracle checks32 scenes and all129600 pixels/scene (odd/clipped/overlapped Key/Alpha);2400 cached-clock differential updates; continuously advancing/wrapping driver completion RED→GREEN; two timed windows/independent frame counts; positive/negative cancellation during pending PRESENT; per-frame independent HUD glyph model; no active-front writes; control and original-game regressions. Review caught static-front setup writes; a failing ownership assertion preceded the fix to retire a static back-buffer PRESENT before reusing the former front.

Selected BIN SHA256 `{digest(fw)}` at `{fw.as_posix()}`. Selected BIT SHA256 `{digest(bit)}` at `{bit.as_posix()}`. Four-KiB stack retained; selected map bounds it below128KiB RAM. Unused AUTO initialization is omitted only in the interactive FrameList-only build; legacy/profile initialization stays. Hardware is the qualified0c47970 row-handoff selection; further hardware optimization stopped.

Archive includes exact changed sources/hashes, selected ELF/BIN/HEX/map, tests and diagnostic history. Prior synchronized300-frame/uncached versions are superseded and not current results. Three protected user files were hash-checked unchanged; the user authorized the root README rewrite, and its original content/corrections are preserved in README.history.md. A new release/final-20261027 package is added without overwriting earlier releases. JTAG only; no Flash. The user authorized final GitHub publication. Gateway restart was automatically rejected with only“blocked by policy”; existing wire/status compatibility and service were retained without a restart.
'''
(dst/'README.md').write_text(readme,encoding='utf-8')
archive=dst/'evidence.zip';assert not archive.exists()
ext={'.log','.json','.jsonl','.txt','.c','.h','.js','.py','.ps1','.sh','.md','.png'}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(src.rglob('*')):
  if p.is_file() and p.suffix.lower() in ext:z.write(p,'experiment/'+p.relative_to(src).as_posix())
 for p in owned:z.write(root/p,'selected-source/'+p)
 for name in ('gpu_demo.bin','gpu_demo.elf','gpu_demo.hex','gpu_demo.map'):z.write(src/'normal-web-final-r1'/name,'selected-firmware/'+name)
with zipfile.ZipFile(archive) as z:assert z.testzip() is None;entries=len(z.namelist())
(dst/'evidence.sha256.txt').write_text(digest(archive)+'  evidence.zip\n')
assert all(digest(root/p)==h for p,h in manifest.items())
print(json.dumps(dict(summary=summary,archive_bytes=archive.stat().st_size,archive_entries=entries,archive_sha256=digest(archive))))
