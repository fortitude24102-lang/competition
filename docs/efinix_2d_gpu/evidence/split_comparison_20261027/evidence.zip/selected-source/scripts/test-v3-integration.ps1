param([string]$IcarusRoot='C:/iverilog',[switch]$SoftwareOnly,[switch]$RtlOnly,[switch]$ReplayCrcNibble,[switch]$ShapeLut)
$ErrorActionPreference='Stop'
Push-Location (Split-Path $PSScriptRoot -Parent)
try {
 $out='generated/verification/v3/integration'
 New-Item -ItemType Directory -Force $out,'generated/verification/v3/game' | Out-Null
 function Check([string]$name) {if($LASTEXITCODE -ne 0){throw "$name failed ($LASTEXITCODE)"}}
 $flags=@('-std=c11','-O2','-Wall','-Wextra','-Werror','-fsanitize=undefined',
  '-ffunction-sections','-fdata-sections','-Wl,--gc-sections','-Isw/efinix_gpu/include')
 if($ReplayCrcNibble) {$flags+='-DREPLAY_CRC_NIBBLE=1'}
 if($ShapeLut) {$flags+='-DV3_SHAPE_LUT=1'}
 $cases=@(
  @{name='split_timed';modules=@('split_compare')},
  @{name='completion_progress';modules=@('gpu');extra=@('-DGPU_TEST_BACKEND')},
  @{name='game_clock_cached';modules=@('interactive_game','bullet_demo')},
  @{name='split_view';modules=@('split_view','perf_demo','interactive_game','bullet_demo','gpu_instances','golden_renderer','rgb565');extra=@('-DGPU_TEST_BACKEND','-Isw/efinix_gpu/assets/v2')},
  @{name='net_control';modules=@('net_control','asset_protocol');extra=@('-DNC_TEST_BACKEND')},
  @{name='input_state';modules=@('input_state')},
  @{name='local_keys';modules=@('local_keys','v3_runtime','bullet_demo','interactive_game','replay_input','input_state')},
  @{name='bullet_path_math';modules=@('bullet_demo');extra=@('-DBULLET_OBJECT_CAPACITY=1024')},
  @{name='bullet_validation';modules=@('bullet_demo');extra=@('-DBULLET_OBJECT_CAPACITY=1024')},
  @{name='r7_frozen';modules=@('bullet_demo')},
  @{name='interactive_game';modules=@('bullet_demo','interactive_game')},
  @{name='enemy_campaign';modules=@('bullet_demo','interactive_game','replay_input')},
  @{name='input_replay';modules=@('bullet_demo','interactive_game','replay_input')},
  @{name='replay_crc';modules=@('bullet_demo','interactive_game');extra=@('-DREPLAY_CRC_NIBBLE=1')},
  @{name='interactive_pixels';modules=@('bullet_demo','interactive_game','replay_input','golden_renderer','rgb565')},
  @{name='v3_runtime';modules=@('v3_runtime','bullet_demo','interactive_game','replay_input','input_state')},
  @{name='v3_ab_lifecycle';modules=@('net_control','asset_protocol','input_state','v3_runtime','bullet_demo','interactive_game','replay_input');extra=@('-DNC_TEST_BACKEND')},
  @{name='v3_hud';modules=@('hud')}
  @{name='game_menu';modules=@('game_menu','gpu');extra=@('-DGPU_TEST_BACKEND')}
  @{name='v3_menu_integration';modules=@('v3_demo','net_control','asset_protocol','v3_runtime','bullet_demo','interactive_game','replay_input');extra=@('-DNC_TEST_BACKEND','-Isw/efinix_gpu/tests/include')}
  @{name='v3_frame_stats';modules=@()},
  @{name='performance_challenge';modules=@('performance_challenge')},
  @{name='performance_trace';modules=@('performance_challenge')},
  @{name='reset_work';modules=@();extra=@('-finstrument-functions')},
  @{name='runtime_reset_cache';modules=@('v3_runtime','bullet_demo','interactive_game','replay_input');extra=@('-finstrument-functions')},
  @{name='gpu_frame_list_driver';modules=@('gpu','gpu_instances','gpu_frame_list','bullet_demo');extra=@('-DGPU_TEST_BACKEND')},
  @{name='hud_gpu_list';modules=@('hud','hud_cache','hud_gpu_cache','gpu','gpu_instances','gpu_frame_list','bullet_demo','perf_demo','golden_renderer','rgb565');extra=@('-DGPU_TEST_BACKEND','-DV3_HUD_LIST=1','-Isw/efinix_gpu/assets/v2')},
  @{name='hud_direct';modules=@('hud','hud_cache','hud_gpu_cache','gpu','perf_demo','golden_renderer','rgb565');extra=@('-DGPU_TEST_BACKEND','-DV3_HUD_DIRECT=1','-Isw/efinix_gpu/assets/v2')},
  @{name='live_phase_stats';modules=@()},
  @{name='copy_ahead';modules=@('gpu','perf_demo','bullet_demo','interactive_game','v3_runtime','replay_input','golden_renderer','rgb565');extra=@('-DGPU_TEST_BACKEND','-Isw/efinix_gpu/tests/include','-Isw/efinix_gpu/assets/v2')},
  @{name='render_phase_health';modules=@()},
  @{name='v3_capacity';modules=@('v3_runtime','bullet_demo','interactive_game','replay_input');extra=@('-DBULLET_OBJECT_CAPACITY=1024')},
  @{name='submit_validation';modules=@();extra=@('-finstrument-functions','-DGPU_SUBMIT_REVALIDATE=0')}
  @{name='submit_shadow';modules=@('gpu','bullet_demo');extra=@('-DGPU_TEST_BACKEND','-DGPU_SUBMIT_SHADOW=1')}
  @{name='transform_driver';modules=@('gpu');extra=@('-DGPU_TEST_BACKEND')}
  @{name='zoom_control';modules=@('zoom_control')}
 )
 if(!$RtlOnly) { foreach($test in $cases) {
  $sources=@("sw/efinix_gpu/tests/test_$($test.name).c")+@($test.modules|ForEach-Object {"sw/efinix_gpu/src/$_.c"})
  & wsl gcc @flags @($test.extra) @sources -o "$out/test_$($test.name)"
  Check "compile $($test.name)"
  & wsl "./$out/test_$($test.name)" | Tee-Object "$out/test_$($test.name).log"
  Check $test.name
 }
 & wsl bash scripts/test-gpu-stripes.sh
 Check 'stable stripe bins and exact Alpha/Key pixels'
 & wsl bash scripts/test-stripe-hud-route.sh
 Check 'stripe plus list HUD real MENU/WIN routing'
 & python sw/efinix_gpu/tests/test_control_gateway.py
 Check 'real UDP/HTTP gateway contracts'
 & python sw/efinix_gpu/tests/test_control_keepalive.py
 Check 'independent collector heartbeat'
 & python sw/efinix_gpu/tests/test_v3_detail_counters.py
 Check 'complete diagnostic endpoints and GPU traffic scope'
 & powershell.exe -NoProfile -ExecutionPolicy Bypass -File scripts/test-game-menu-board-cache.ps1
 Check 'challenge collector freshness and cleanup'
 & powershell.exe -NoProfile -ExecutionPolicy Bypass -File scripts/test-game-menu-board-keepalive.ps1
 Check 'actual collector child launch and failed-launch cleanup'
 & powershell.exe -NoProfile -ExecutionPolicy Bypass -File scripts/tests/test-game-probe-identity.ps1
 Check 'terminal cohort identity guard'
 & powershell.exe -NoProfile -ExecutionPolicy Bypass -File scripts/test-board-stop-framing.ps1
 Check 'newline-complete board capture STOP records'
 }
 if(!$SoftwareOnly) {
  $net=@(Get-ChildItem board/efinix_ti60/rtl/net/*.v | ForEach-Object FullName)
  $mac=@(Get-ChildItem board/efinix_ti60/vendor/ge_udp/rtl/heijin_test/mac -Filter *.v -Recurse | ForEach-Object FullName)
  $ErrorActionPreference='Continue' # Read-only vendor warnings are native stderr in PS5.
  & "$IcarusRoot/bin/iverilog.exe" -g2012 -s tb_v3_network_subsystem -o "$out/subsystem.vvp" tb/verilog/tb_v3_network_subsystem.sv @net board/efinix_ti60/rtl/display/pixel_async_fifo.v board/efinix_ti60/vendor/sapphire_ddr3/rtl/ddr3_controller/common/efx_fifo_v2.3/efx_fifo_wrapper.v @mac 2> "$out/subsystem-build.log"
  $ErrorActionPreference='Stop'
  Check 'owner subsystem elaboration'
  & "$IcarusRoot/bin/vvp.exe" "$out/subsystem.vvp" | Tee-Object "$out/subsystem.log"
  Check 'actual owner APB/MAC glue'
 }
 Write-Output "PASS requested V3 integration checks: SoftwareOnly=$SoftwareOnly RtlOnly=$RtlOnly. Not board qualification."
} finally {Pop-Location}
